package com.terror2d.world

import com.terror2d.draw.Cr
import com.terror2d.draw.CrayonBuilder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Biblioteca de objetos de la casa, dibujados a crayón. Cada función devuelve un [DrawnProp]; el dibujo
 * se genera con la semilla al cargar la habitación. Los "pequeños errores" (proporciones raras,
 * sonrisas demasiado grandes, un tic de más en el reloj, una mano con seis dedos) están en el diseño
 * y deben parecer accidentes de un dibujo infantil, no monstruos.
 */
object HouseProps {

    const val F = 146f
    private const val INK = CrayonBuilder.INK

    private fun prop(
        x: Float, y: Float, w: Float, h: Float,
        layer: Int = Layer.OBJECT,
        build: (CrayonBuilder, Float, Float) -> Unit
    ): DrawnProp = DrawnProp(x, y, w, h, layer, build)

    private fun d(c: Int): Int = CrayonBuilder.darker(c)

    // ================================================================== suelo y paredes comunes

    fun rug(x: Float, w: Float, c: Int, c2: Int) = prop(x, F - 8f, w, 8f, Layer.DECOR) { b, x0, y0 ->
        b.box(x0, y0, w, 8f, c)
        b.hatchRect(x0 + 3f, y0 + 2f, w - 6f, 4f, c2, 2.2f)
        b.dots(x0 + 2f, y0 + 1f, w - 4f, 6f, (w / 6f).toInt(), c2, 1.6f)
    }

    fun windowFrame(x: Float, y: Float, w: Float, h: Float, curtain: Int) = prop(x - 6f, y - 4f, w + 12f, h + 12f, Layer.DECOR) { b, _, _ ->
        b.box(x, y, w, h, Cr.CREAM)
        b.fillRect(x + 3f, y + 3f, w - 6f, h - 6f, Cr.NIGHT)
        b.dots(x + 3f, y + 3f, w - 6f, h - 6f, 9, 0xFFFFF2B0.toInt(), 1.6f)
        b.ball(x + w * 0.7f, y + h * 0.3f, 5f, 5f, Cr.YELLOW)
        b.fillOval(x + w * 0.7f + 2.4f, y + h * 0.3f - 1f, 4.6f, 4.4f, Cr.NIGHT)
        b.line(x + w / 2f, y + 3f, x + w / 2f, y + h - 3f, Cr.CREAM, 2.5f)
        b.line(x + 3f, y + h / 2f, x + w - 3f, y + h / 2f, Cr.CREAM, 2.5f)
        b.box(x - 3f, y + h, w + 6f, 4f, Cr.WOOD)
        b.poly(floatArrayOf(x - 4f, y - 3f, x + w * 0.3f, y - 3f, x + w * 0.2f, y + h + 2f, x - 4f, y + h + 2f), curtain)
        b.poly(floatArrayOf(x + w + 4f, y - 3f, x + w * 0.7f, y - 3f, x + w * 0.8f, y + h + 2f, x + w + 4f, y + h + 2f), curtain)
    }

    fun mirror(x: Float, y: Float, w: Float, h: Float) = prop(x, y, w, h, Layer.DECOR) { b, x0, y0 ->
        b.box(x0, y0, w, h, Cr.PURPLE)
        b.fillRect(x0 + 3f, y0 + 3f, w - 6f, h - 6f, Cr.GLASS)
        b.line(x0 + 6f, y0 + 6f, x0 + w * 0.45f, y0 + h * 0.4f, 0xAAFFFFFF.toInt(), 1.6f)
        b.line(x0 + 9f, y0 + 6f, x0 + w * 0.6f, y0 + h * 0.34f, 0x88FFFFFF.toInt(), 1.2f)
        // una silueta borrosa que no coincide con nada de la habitación
        b.smudge(x0 + w * 0.58f, y0 + h * 0.58f, w * 0.17f, h * 0.3f, 0x38102030)
        b.smudge(x0 + w * 0.58f, y0 + h * 0.3f, w * 0.1f, h * 0.1f, 0x38102030)
    }

    fun clock(x: Float, y: Float) = prop(x, y, 24f, 24f, Layer.DECOR) { b, x0, y0 ->
        val cx = x0 + 12f
        val cy = y0 + 12f
        b.ball(cx, cy, 11f, 11f, Cr.CREAM)
        val ticks = FloatArray(13 * 4) // trece marcas: una de más
        for (i in 0 until 13) {
            val a = i * 2f * PI.toFloat() / 13f
            ticks[i * 4] = cx + cos(a) * 8f
            ticks[i * 4 + 1] = cy + sin(a) * 8f
            ticks[i * 4 + 2] = cx + cos(a) * 10f
            ticks[i * 4 + 3] = cy + sin(a) * 10f
        }
        b.strokes(ticks, INK, 1f)
        b.line(cx, cy, cx, cy - 7f, INK, 1.4f, 0.1f)
        b.line(cx, cy, cx + 5f, cy + 2f, INK, 1.2f, 0.1f)
    }

    fun doorSign(x: Float, y: Float, kind: Int) = prop(x, y, 24f, 18f, Layer.DECOR) { b, x0, y0 ->
        b.fillRect(x0, y0, 24f, 18f, 0xFFFFF3C4.toInt())
        b.hatchRect(x0, y0, 24f, 18f, 0xFFE8D48A.toInt(), 3f)
        b.outlineRect(x0, y0, 24f, 18f)
        val cx = x0 + 12f
        val cy = y0 + 9f
        when (kind) {
            0 -> b.star(cx, cy, 5.5f, Cr.ORANGE, 1.4f)
            1 -> b.poly(floatArrayOf(cx, cy - 6f, cx + 4f, cy + 1f, cx + 2f, cy + 5f, cx - 2f, cy + 5f, cx - 4f, cy + 1f), Cr.BLUE)
            2 -> {
                b.ball(cx - 2.5f, cy - 1.5f, 3f, 3f, Cr.RED)
                b.ball(cx + 2.5f, cy - 1.5f, 3f, 3f, Cr.RED)
                b.poly(floatArrayOf(cx - 5.4f, cy, cx + 5.4f, cy, cx, cy + 6f), Cr.RED)
            }
            3 -> {
                b.ball(cx - 3f, cy + 1f, 3f, 3f, Cr.LILAC)
                b.ball(cx + 3f, cy - 2f, 2.4f, 2.4f, Cr.BLUE)
                b.ball(cx + 1f, cy + 4f, 1.8f, 1.8f, Cr.MINT)
            }
            4 -> {
                b.ball(cx - 3f, cy - 2f, 2.6f, 3.2f, Cr.METAL)
                b.line(cx - 3f, cy + 1f, cx - 3f, cy + 6f, INK, 1.4f, 0.1f)
                b.line(cx + 3f, cy - 5f, cx + 3f, cy + 6f, INK, 1.4f, 0.1f)
            }
            5 -> {
                b.ball(cx, cy, 5.5f, 5.5f, Cr.WHITE)
                b.ball(cx, cy, 2.8f, 2.8f, Cr.CREAM)
            }
            else -> b.spiral(cx, cy, 5.5f, Cr.DGRAY, 1.3f)
        }
    }

    fun photoFrame(x: Float, y: Float, w: Float, h: Float, smileIdx: Int) = prop(x, y, w, h, Layer.DECOR) { b, x0, y0 ->
        b.box(x0, y0, w, h, Cr.WOOD)
        b.fillRect(x0 + 3f, y0 + 3f, w - 6f, h - 6f, Cr.CREAM)
        val r = min(w / 8f, h / 4.4f)
        for (i in 0 until 3) {
            val cx = x0 + w * (2 * i + 1) / 6f
            val cy = y0 + h * 0.46f
            b.face(cx, cy, r, if (i == 1) Cr.CORAL else Cr.SKIN, if (i == smileIdx) 1 else 0)
            b.line(cx, cy + r * 1.1f, cx, y0 + h - 5f, INK, 1.1f, 0.2f)
        }
    }

    fun kidDrawing(x: Float, y: Float, w: Float, h: Float, variant: Int) = prop(x, y, w, h, Layer.DECOR) { b, x0, y0 ->
        b.fillRect(x0, y0, w, h, Cr.CREAM)
        b.hatchRect(x0, y0, w, h, 0xFFEBD590.toInt(), 4f)
        b.outlineRect(x0, y0, w, h)
        b.fillRect(x0 + w / 2f - 5f, y0 - 2f, 10f, 5f, 0x99FFE9A8.toInt())
        when (variant) {
            0 -> { // mamá y yo, con el sol
                b.face(x0 + w - 9f, y0 + 9f, 5.5f, Cr.YELLOW, 1)
                val mx = x0 + w * 0.32f
                b.face(mx, y0 + h * 0.3f, 4.6f, Cr.SKIN, 0)
                b.poly(floatArrayOf(mx - 4f, y0 + h * 0.45f, mx + 4f, y0 + h * 0.45f, mx + 8f, y0 + h - 4f, mx - 8f, y0 + h - 4f), Cr.PURPLE)
                val kx = x0 + w * 0.64f
                b.face(kx, y0 + h * 0.5f, 3.4f, Cr.SKIN, 0)
                b.poly(floatArrayOf(kx - 3f, y0 + h * 0.62f, kx + 3f, y0 + h * 0.62f, kx + 5f, y0 + h - 4f, kx - 5f, y0 + h - 4f), Cr.TEAL)
                b.line(mx + 6f, y0 + h * 0.58f, kx - 4f, y0 + h * 0.7f, INK, 1.2f)
            }
            1 -> { // una rana con una cruz, sonriendo
                b.ball(x0 + w * 0.5f, y0 + h * 0.62f, w * 0.3f, h * 0.24f, Cr.GREEN)
                b.ball(x0 + w * 0.36f, y0 + h * 0.3f, 4f, 4f, Cr.GREEN)
                b.ball(x0 + w * 0.64f, y0 + h * 0.3f, 4f, 4f, Cr.GREEN)
                b.fillOval(x0 + w * 0.36f, y0 + h * 0.3f, 2.2f, 2.2f, Cr.WHITE)
                b.fillOval(x0 + w * 0.64f, y0 + h * 0.3f, 2.2f, 2.2f, Cr.WHITE)
                b.smile(x0 + w * 0.5f, y0 + h * 0.58f, w * 0.26f, h * 0.12f, INK, true)
                b.cross(x0 + w * 0.5f, y0 + h * 0.8f, 3.2f, Cr.RED, 1.8f)
            }
            else -> { // la casa, y alguien muy alto en la ventana
                b.box(x0 + w * 0.2f, y0 + h * 0.4f, w * 0.6f, h * 0.5f, Cr.CORAL)
                b.poly(floatArrayOf(x0 + w * 0.15f, y0 + h * 0.42f, x0 + w * 0.5f, y0 + h * 0.12f, x0 + w * 0.85f, y0 + h * 0.42f), Cr.RED)
                b.fillRect(x0 + w * 0.44f, y0 + h * 0.5f, w * 0.14f, h * 0.26f, Cr.NIGHT)
                b.line(x0 + w * 0.51f, y0 + h * 0.5f, x0 + w * 0.51f, y0 + h * 0.2f, INK, 1.4f)
                b.ball(x0 + w * 0.51f, y0 + h * 0.18f, 2.4f, 2.4f, Cr.SKIN)
            }
        }
    }

    // ================================================================== pasillo

    fun coatRack(x: Float) = prop(x, F - 86f, 30f, 86f) { b, x0, y0 ->
        b.line(x0 + 15f, y0 + 4f, x0 + 15f, y0 + 82f, Cr.DBROWN, 3f)
        b.box(x0 + 6f, y0 + 80f, 18f, 5f, Cr.DBROWN)
        b.line(x0 + 15f, y0 + 10f, x0 + 4f, y0 + 6f, Cr.DBROWN, 2f)
        b.line(x0 + 15f, y0 + 10f, x0 + 26f, y0 + 6f, Cr.DBROWN, 2f)
        b.poly(floatArrayOf(x0 + 2f, y0 + 8f, x0 + 12f, y0 + 10f, x0 + 13f, y0 + 52f, x0 - 2f, y0 + 54f), Cr.RED)
        b.poly(floatArrayOf(x0 + 18f, y0 + 10f, x0 + 28f, y0 + 8f, x0 + 33f, y0 + 46f, x0 + 19f, y0 + 50f), Cr.BLUE)
        b.ball(x0 + 15f, y0 + 3f, 7f, 3f, Cr.YELLOW)
    }

    fun hallTable(x: Float) = prop(x, F - 42f, 54f, 42f) { b, x0, y0 ->
        b.box(x0, y0 + 24f, 54f, 5f, Cr.WOOD)
        b.box(x0 + 4f, y0 + 29f, 4f, 13f, Cr.DBROWN)
        b.box(x0 + 46f, y0 + 29f, 4f, 13f, Cr.DBROWN)
        b.box(x0 + 6f, y0 + 16f, 14f, 8f, Cr.GRAY)
        b.ball(x0 + 13f, y0 + 15f, 4f, 2f, Cr.DGRAY)
        b.box(x0 + 34f, y0 + 12f, 8f, 12f, Cr.BLUE)
        b.line(x0 + 38f, y0 + 12f, x0 + 36f, y0 + 3f, Cr.DGREEN, 1.4f)
        b.line(x0 + 38f, y0 + 12f, x0 + 42f, y0 + 4f, Cr.DGREEN, 1.4f)
        b.ball(x0 + 36f, y0 + 2f, 4.5f, 3.5f, Cr.PINK)
        b.ball(x0 + 43f, y0 + 1f, 2.6f, 5.4f, Cr.YELLOW) // un pétalo demasiado largo
    }

    fun plant(x: Float) = prop(x, F - 46f, 28f, 46f) { b, x0, y0 ->
        b.box(x0 + 6f, y0 + 32f, 16f, 14f, Cr.ORANGE)
        b.poly(floatArrayOf(x0 + 14f, y0 + 32f, x0 + 2f, y0 + 18f, x0 + 9f, y0 + 8f, x0 + 15f, y0 + 24f), Cr.GREEN)
        b.poly(floatArrayOf(x0 + 14f, y0 + 32f, x0 + 26f, y0 + 16f, x0 + 20f, y0 + 6f, x0 + 13f, y0 + 24f), Cr.DGREEN)
        b.ball(x0 + 14f, y0 + 6f, 4.4f, 4.4f, Cr.PINK)
        b.dots(x0 + 8f, y0 + 1f, 12f, 10f, 9, Cr.PINK, 2.6f) // demasiados pétalos
    }

    fun shoeRack(x: Float) = prop(x, F - 26f, 44f, 26f) { b, x0, y0 ->
        b.box(x0, y0 + 12f, 44f, 3f, Cr.DBROWN)
        b.box(x0 + 2f, y0 + 15f, 3f, 11f, Cr.DBROWN)
        b.box(x0 + 39f, y0 + 15f, 3f, 11f, Cr.DBROWN)
        b.box(x0 + 3f, y0 + 21f, 9f, 5f, Cr.RED)
        b.box(x0 + 15f, y0 + 1f, 15f, 11f, Cr.DBLUE)
        b.box(x0 + 33f, y0 + 6f, 8f, 6f, Cr.RED)
    }

    fun umbrellaStand(x: Float) = prop(x, F - 40f, 18f, 40f) { b, x0, y0 ->
        b.line(x0 + 7f, y0 + 4f, x0 + 9f, y0 + 26f, Cr.DBLUE, 3f)
        b.line(x0 + 12f, y0 + 8f, x0 + 11f, y0 + 26f, Cr.RED, 3f)
        b.box(x0, y0 + 24f, 18f, 16f, Cr.TEAL)
    }

    // ================================================================== cuarto del niño

    fun kidBed(x: Float, blanket: Int) = prop(x - 2f, F - 40f, 96f, 40f) { b, x0, y0 ->
        b.box(x0 + 4f, y0 + 30f, 4f, 10f, Cr.DBROWN)
        b.box(x0 + 88f, y0 + 30f, 4f, 10f, Cr.DBROWN)
        b.box(x0 + 2f, y0 + 22f, 92f, 10f, Cr.WOOD)
        b.box(x0, y0 + 4f, 8f, 34f, Cr.BROWN)
        b.box(x0 + 16f, y0 + 12f, 76f, 14f, blanket)
        b.star(x0 + 34f, y0 + 19f, 3.4f, Cr.YELLOW)
        b.star(x0 + 58f, y0 + 18f, 3f, Cr.YELLOW)
        b.star(x0 + 78f, y0 + 20f, 3.4f, Cr.YELLOW)
        b.ball(x0 + 16f, y0 + 13f, 9f, 5f, Cr.WHITE)
    }

    fun toyChest(x: Float) = prop(x, F - 38f, 40f, 38f) { b, x0, y0 ->
        b.box(x0, y0 + 14f, 40f, 24f, Cr.PURPLE)
        b.line(x0, y0 + 24f, x0 + 40f, y0 + 24f, INK, 1.2f)
        b.poly(floatArrayOf(x0 - 1f, y0 + 14f, x0 + 41f, y0 + 14f, x0 + 38f, y0 + 8f, x0 + 2f, y0 + 8f), Cr.LILAC)
        b.ball(x0 + 8f, y0 + 6f, 4f, 4f, Cr.RED)
        b.ball(x0 + 31f, y0 + 1f, 7f, 6.5f, Cr.BROWN)     // osito con la cabeza enorme
        b.ball(x0 + 31f, y0 + 10f, 3.4f, 3.4f, Cr.BROWN)
        b.fillOval(x0 + 28.5f, y0 - 1f, 1.2f, 1.2f, INK)
        b.fillOval(x0 + 33.8f, y0 - 1f, 2.3f, 2.3f, INK)  // ojos de distinto tamaño
        b.box(x0 + 14f, y0 + 3f, 8f, 7f, Cr.BLUE)
    }

    fun smallTable(x: Float) = prop(x, F - 30f, 42f, 30f) { b, x0, y0 ->
        b.box(x0, y0 + 14f, 42f, 4f, Cr.WOOD)
        b.box(x0 + 3f, y0 + 18f, 4f, 12f, Cr.DBROWN)
        b.box(x0 + 35f, y0 + 18f, 4f, 12f, Cr.DBROWN)
        b.fillRect(x0 + 4f, y0 + 11f, 18f, 3f, Cr.WHITE)
        b.scribble(x0 + 5f, y0 + 11f, 16f, 3f, Cr.RED, 4, 1f)
        b.box(x0 + 26f, y0 + 6f, 12f, 8f, Cr.RED)
        b.line(x0 + 29f, y0 + 6f, x0 + 29f, y0 + 1f, Cr.BLUE, 1.6f, 0.1f)
        b.line(x0 + 32f, y0 + 6f, x0 + 33f, y0 + 1f, Cr.GREEN, 1.6f, 0.1f)
        b.line(x0 + 35f, y0 + 6f, x0 + 36f, y0 + 2f, Cr.YELLOW, 1.6f, 0.1f)
    }

    /** La ranita de peluche: la rana de la farmacia (una cruz verde en la barriga). Solo objeto ambiental. */
    fun plushFrog(x: Float, y: Float) = prop(x, y, 26f, 24f) { b, x0, y0 ->
        b.ball(x0 + 13f, y0 + 15f, 11f, 8.5f, Cr.GREEN)
        b.ball(x0 + 6f, y0 + 6f, 4.6f, 4.6f, Cr.GREEN)
        b.ball(x0 + 20f, y0 + 6f, 4.6f, 4.6f, Cr.GREEN)
        b.fillOval(x0 + 6f, y0 + 6f, 3f, 3f, Cr.WHITE)
        b.fillOval(x0 + 20f, y0 + 6f, 3f, 3f, Cr.WHITE)
        b.fillOval(x0 + 6.6f, y0 + 6.4f, 1.3f, 1.5f, INK)
        b.fillOval(x0 + 19.6f, y0 + 6.4f, 1.3f, 1.5f, INK)
        b.smile(x0 + 13f, y0 + 14f, 9f, 3.4f, INK, false)
        b.cross(x0 + 13f, y0 + 20f, 3.2f, Cr.WHITE, 1.8f)
    }

    fun bookshelf(x: Float, y: Float, w: Float) = prop(x, y, w, 36f, Layer.DECOR) { b, x0, y0 ->
        val cols = intArrayOf(Cr.RED, Cr.BLUE, Cr.GREEN, Cr.YELLOW, Cr.PURPLE, Cr.ORANGE, Cr.TEAL)
        val hs = intArrayOf(14, 11, 15, 12, 13, 10, 15)
        for (row in 0 until 2) {
            val ry = y0 + 16f + row * 20f
            var bx = x0 + 3f
            var i = row * 3
            while (bx < x0 + w - 8f) {
                val bh = hs[i % hs.size].toFloat()
                b.box(bx, ry - bh, 5.5f, bh, cols[i % cols.size])
                bx += 6.2f
                i++
            }
            b.box(x0, ry, w, 3.5f, Cr.BROWN)
        }
    }

    fun poster(x: Float, y: Float, w: Float, h: Float) = prop(x, y, w, h, Layer.DECOR) { b, x0, y0 ->
        b.fillRect(x0, y0, w, h, Cr.WHITE)
        b.outlineRect(x0, y0, w, h)
        b.ball(x0 + w * 0.3f, y0 + h * 0.3f, w * 0.18f, w * 0.18f, Cr.RED)
        b.poly(floatArrayOf(x0 + w * 0.55f, y0 + h * 0.5f, x0 + w * 0.9f, y0 + h * 0.5f, x0 + w * 0.72f, y0 + h * 0.14f), Cr.YELLOW)
        b.box(x0 + w * 0.15f, y0 + h * 0.58f, w * 0.34f, h * 0.3f, Cr.BLUE)
        b.scribble(x0 + 3f, y0 + h * 0.9f, w - 6f, 3f, Cr.DGRAY, 4, 1f)
    }

    fun toyBlocks(x: Float) = prop(x, F - 24f, 30f, 24f) { b, x0, y0 ->
        b.box(x0, y0 + 14f, 10f, 10f, Cr.RED)
        b.box(x0 + 11f, y0 + 14f, 10f, 10f, Cr.BLUE)
        b.box(x0 + 5f, y0 + 4f, 10f, 10f, Cr.YELLOW)
        b.box(x0 + 21f, y0 + 17f, 9f, 7f, Cr.GREEN)
    }

    // ================================================================== cocina

    fun fridge(x: Float) = prop(x, F - 88f, 38f, 88f) { b, x0, y0 ->
        b.box(x0, y0, 38f, 88f, Cr.WHITE, 0xFFB8C4CC.toInt())
        b.line(x0 + 1f, y0 + 30f, x0 + 37f, y0 + 30f, INK, 1.4f)
        b.box(x0 + 31f, y0 + 12f, 3f, 12f, Cr.DGRAY)
        b.box(x0 + 31f, y0 + 40f, 3f, 20f, Cr.DGRAY)
        // dibujos y imanes
        b.fillRect(x0 + 5f, y0 + 38f, 14f, 12f, Cr.CREAM)
        b.scribble(x0 + 6f, y0 + 39f, 12f, 10f, Cr.BLUE, 4, 1f)
        b.outlineRect(x0 + 5f, y0 + 38f, 14f, 12f)
        b.ball(x0 + 12f, y0 + 38f, 2.2f, 2.2f, Cr.RED)
        b.ball(x0 + 8f, y0 + 12f, 3f, 3f, Cr.GREEN)
        b.ball(x0 + 16f, y0 + 16f, 3f, 3f, Cr.GREEN)
        b.ball(x0 + 10f, y0 + 21f, 3f, 3f, Cr.GREEN)
    }

    fun counterSink(x: Float, w: Float) = prop(x, F - 54f, w, 54f) { b, x0, y0 ->
        b.box(x0, y0 + 16f, w, 38f, Cr.WOOD)
        b.box(x0 - 2f, y0 + 12f, w + 4f, 6f, Cr.GRAY)
        // puertas de los muebles
        var dx = x0 + 6f
        while (dx < x0 + w - 18f) {
            b.outlineRect(dx, y0 + 24f, 22f, 26f, Cr.DBROWN)
            b.ball(dx + 17f, y0 + 36f, 1.4f, 1.4f, Cr.YELLOW)
            dx += 28f
        }
        // fregadero y grifo
        b.box(x0 + w * 0.45f, y0 + 9f, 26f, 5f, Cr.METAL)
        b.line(x0 + w * 0.45f + 13f, y0 + 9f, x0 + w * 0.45f + 13f, y0 + 0f, Cr.METAL, 2.4f, 0.1f)
        b.line(x0 + w * 0.45f + 13f, y0 + 0f, x0 + w * 0.45f + 19f, y0 + 0f, Cr.METAL, 2.4f, 0.1f)
        b.ball(x0 + w * 0.45f + 19f, y0 + 4f, 1.2f, 1.8f, Cr.BLUE) // la gota
        // cinco vasos IGUALES en fila
        for (i in 0 until 5) {
            b.box(x0 + 5f + i * 6.4f, y0 + 1f, 5f, 11f, Cr.GLASS)
        }
    }

    fun stove(x: Float) = prop(x, F - 48f, 40f, 48f) { b, x0, y0 ->
        b.box(x0, y0 + 8f, 40f, 40f, Cr.WHITE, 0xFFB8C4CC.toInt())
        b.box(x0 + 5f, y0 + 20f, 30f, 20f, Cr.DARK)
        b.line(x0 + 8f, y0 + 18f, x0 + 32f, y0 + 18f, Cr.METAL, 2f, 0.1f)
        for (i in 0 until 4) b.ball(x0 + 7f + i * 8.6f, y0 + 13f, 1.8f, 1.8f, Cr.DGRAY)
        b.ball(x0 + 12f, y0 + 4f, 7f, 4f, Cr.RED)           // olla
        b.box(x0 + 5f, y0 + 1f, 14f, 6f, Cr.RED)
        b.box(x0 + 24f, y0 + 4f, 12f, 4f, Cr.DGRAY)          // sartén
    }

    fun wallCabinet(x: Float, y: Float, w: Float) = prop(x, y, w, 32f, Layer.DECOR) { b, x0, y0 ->
        b.box(x0, y0, w, 32f, Cr.WOOD)
        b.line(x0 + w / 2f, y0 + 1f, x0 + w / 2f, y0 + 31f, INK, 1.2f)
        b.ball(x0 + w / 2f - 4f, y0 + 18f, 1.4f, 1.4f, Cr.YELLOW)
        b.ball(x0 + w / 2f + 4f, y0 + 18f, 1.4f, 1.4f, Cr.YELLOW)
    }

    fun kitchenTable(x: Float) = prop(x, F - 46f, 90f, 46f) { b, x0, y0 ->
        b.box(x0, y0 + 24f, 90f, 6f, Cr.RED)
        b.hatchRect(x0 + 2f, y0 + 25f, 86f, 4f, Cr.WHITE, 2.4f, true)
        b.box(x0 + 6f, y0 + 30f, 4f, 16f, Cr.DBROWN)
        b.box(x0 + 80f, y0 + 30f, 4f, 16f, Cr.DBROWN)
        // tres platos para dos personas
        for (i in 0 until 3) {
            b.ball(x0 + 18f + i * 26f, y0 + 22f, 9f, 2.6f, Cr.WHITE)
            b.ball(x0 + 18f + i * 26f, y0 + 21.5f, 5f, 1.4f, Cr.CREAM)
        }
        b.box(x0 + 78f, y0 + 14f, 6f, 8f, Cr.BLUE)
        b.box(x0 + 2f, y0 + 14f, 6f, 8f, Cr.BLUE)
    }

    fun chair(x: Float, color: Int) = prop(x, F - 40f, 24f, 40f) { b, x0, y0 ->
        b.box(x0, y0, 5f, 22f, color)
        b.box(x0, y0 + 20f, 24f, 4f, color)
        b.box(x0 + 1f, y0 + 24f, 3.5f, 16f, Cr.DBROWN)
        b.box(x0 + 19f, y0 + 24f, 3.5f, 16f, Cr.DBROWN)
    }

    fun hangingPots(x: Float, y: Float) = prop(x, y, 54f, 30f, Layer.DECOR) { b, x0, y0 ->
        b.line(x0, y0 + 2f, x0 + 54f, y0 + 2f, Cr.DGRAY, 2f, 0.2f)
        for (i in 0 until 3) {
            val px = x0 + 8f + i * 18f
            b.line(px, y0 + 2f, px, y0 + 8f, Cr.DGRAY, 1.2f, 0.1f)
            b.ball(px, y0 + 15f, 7f - i, 7f, if (i == 1) Cr.ORANGE else Cr.METAL)
        }
    }

    fun calendar(x: Float, y: Float) = prop(x, y, 22f, 26f, Layer.DECOR) { b, x0, y0 ->
        b.fillRect(x0, y0, 22f, 26f, Cr.WHITE)
        b.fillRect(x0, y0, 22f, 6f, Cr.RED)
        b.outlineRect(x0, y0, 22f, 26f)
        for (i in 1 until 4) b.line(x0 + 1f, y0 + 6f + i * 5f, x0 + 21f, y0 + 6f + i * 5f, Cr.GRAY, 1f, 0.1f)
        for (i in 1 until 4) b.line(x0 + i * 5.2f, y0 + 6f, x0 + i * 5.2f, y0 + 25f, Cr.GRAY, 1f, 0.1f)
        b.outlineOval(x0 + 11f, y0 + 17f, 3.4f, 3.2f, Cr.RED, 1.2f)
    }

    // ================================================================== baño

    fun bathSink(x: Float) = prop(x, F - 48f, 44f, 48f) { b, x0, y0 ->
        b.box(x0 + 14f, y0 + 22f, 16f, 26f, Cr.WHITE, 0xFFB8C4CC.toInt())
        b.ball(x0 + 22f, y0 + 18f, 22f, 7f, Cr.WHITE, 0xFFB8C4CC.toInt())
        b.line(x0 + 22f, y0 + 12f, x0 + 22f, y0 + 4f, Cr.METAL, 2.4f, 0.1f)
        b.line(x0 + 22f, y0 + 4f, x0 + 28f, y0 + 4f, Cr.METAL, 2.4f, 0.1f)
        b.ball(x0 + 14f, y0 + 8f, 2f, 2f, Cr.BLUE)
        b.ball(x0 + 30f, y0 + 8f, 2f, 2f, Cr.RED)
    }

    fun toilet(x: Float) = prop(x, F - 40f, 30f, 40f) { b, x0, y0 ->
        b.box(x0 + 2f, y0 + 4f, 12f, 18f, Cr.WHITE, 0xFFB8C4CC.toInt())
        b.ball(x0 + 17f, y0 + 28f, 13f, 7f, Cr.WHITE, 0xFFB8C4CC.toInt())
        b.box(x0 + 8f, y0 + 32f, 12f, 8f, Cr.WHITE, 0xFFB8C4CC.toInt())
        b.line(x0 + 6f, y0 + 22f, x0 + 28f, y0 + 22f, Cr.GRAY, 2.4f, 0.2f)
    }

    fun bathtub(x: Float, w: Float) = prop(x, F - 44f, w, 44f) { b, x0, y0 ->
        b.box(x0 + 6f, y0 + 36f, 8f, 8f, Cr.YELLOW)
        b.box(x0 + w - 14f, y0 + 36f, 8f, 8f, Cr.YELLOW)
        b.box(x0, y0 + 16f, w, 24f, Cr.WHITE, 0xFFB8C4CC.toInt())
        b.fillRect(x0 + 4f, y0 + 16f, w - 8f, 6f, Cr.GLASS)
        b.line(x0 + w - 10f, y0 + 16f, x0 + w - 10f, y0 + 4f, Cr.METAL, 2.4f, 0.1f)
        b.line(x0 + w - 10f, y0 + 4f, x0 + w - 18f, y0 + 4f, Cr.METAL, 2.4f, 0.1f)
        // burbujas y un patito con una sonrisa demasiado grande
        for (i in 0 until 5) b.ball(x0 + 8f + i * 7f, y0 + 14f - (i % 2) * 3f, 3.4f, 3.4f, 0xFFEAF6FF.toInt())
        b.ball(x0 + w * 0.55f, y0 + 12f, 7f, 5.5f, Cr.YELLOW)
        b.ball(x0 + w * 0.55f + 6f, y0 + 6f, 4.4f, 4.4f, Cr.YELLOW)
        b.poly(floatArrayOf(x0 + w * 0.55f + 9f, y0 + 6f, x0 + w * 0.55f + 14f, y0 + 7f, x0 + w * 0.55f + 9f, y0 + 9f), Cr.ORANGE)
        b.smile(x0 + w * 0.55f + 7f, y0 + 7.5f, 5f, 2.2f, INK, true)
    }

    fun towelRack(x: Float, y: Float) = prop(x, y, 30f, 30f, Layer.DECOR) { b, x0, y0 ->
        b.line(x0, y0 + 2f, x0 + 30f, y0 + 2f, Cr.METAL, 2.4f, 0.2f)
        b.poly(floatArrayOf(x0 + 4f, y0 + 2f, x0 + 16f, y0 + 2f, x0 + 17f, y0 + 28f, x0 + 3f, y0 + 29f), Cr.PINK)
        b.poly(floatArrayOf(x0 + 17f, y0 + 2f, x0 + 28f, y0 + 2f, x0 + 29f, y0 + 24f, x0 + 18f, y0 + 25f), Cr.TEAL)
        b.dots(x0 + 4f, y0 + 6f, 12f, 20f, 5, Cr.WHITE, 2f)
    }

    fun medCabinet(x: Float, y: Float) = prop(x, y, 28f, 36f, Layer.DECOR) { b, x0, y0 ->
        b.box(x0, y0, 28f, 36f, Cr.WHITE, 0xFFB8C4CC.toInt())
        b.cross(x0 + 14f, y0 + 14f, 6f, Cr.DGREEN, 3f)
        b.box(x0 + 22f, y0 + 18f, 3f, 6f, Cr.DGRAY)
        b.line(x0 + 3f, y0 + 28f, x0 + 25f, y0 + 28f, Cr.GRAY, 1.2f, 0.2f)
    }

    // ================================================================== bodega

    fun crateStack(x: Float) = prop(x, F - 54f, 60f, 54f) { b, x0, y0 ->
        b.box(x0, y0 + 28f, 30f, 26f, Cr.WOOD)
        b.line(x0, y0 + 28f, x0 + 30f, y0 + 54f, Cr.DBROWN, 1.4f)
        b.line(x0 + 30f, y0 + 28f, x0, y0 + 54f, Cr.DBROWN, 1.4f)
        b.box(x0 + 30f, y0 + 34f, 28f, 20f, Cr.BROWN)
        b.box(x0 + 6f, y0 + 4f, 26f, 24f, Cr.WOOD)
        b.line(x0 + 6f, y0 + 4f, x0 + 32f, y0 + 28f, Cr.DBROWN, 1.4f)
        b.dots(x0, y0, 60f, 54f, 6, 0x66000000, 2.4f)
    }

    fun coveredFurniture(x: Float, w: Float, h: Float) = prop(x, F - h, w, h) { b, x0, y0 ->
        // patas asomando debajo de la sábana
        b.box(x0 + 3f, y0 + h - 8f, 3f, 8f, Cr.DBROWN)
        b.box(x0 + w - 6f, y0 + h - 8f, 3f, 8f, Cr.DBROWN)
        b.poly(
            floatArrayOf(
                x0, y0 + h - 6f, x0 + 3f, y0 + h * 0.4f, x0 + w * 0.25f, y0 + 6f, x0 + w * 0.55f, y0 + 2f,
                x0 + w * 0.8f, y0 + h * 0.3f, x0 + w - 1f, y0 + h * 0.6f, x0 + w + 2f, y0 + h - 6f
            ),
            0xFFD8D4DE.toInt(), 0xFFA9A3B8.toInt()
        )
        b.line(x0 + w * 0.3f, y0 + 10f, x0 + w * 0.34f, y0 + h - 8f, 0x66000000, 1.2f)
        b.line(x0 + w * 0.62f, y0 + 6f, x0 + w * 0.66f, y0 + h - 8f, 0x55000000, 1.2f)
        b.smudge(x0 + w * 0.5f, y0 + h * 0.5f, w * 0.14f, h * 0.1f, 0x30000000)
    }

    fun toolWall(x: Float, y: Float, w: Float) = prop(x, y, w, 40f, Layer.DECOR) { b, x0, y0 ->
        b.box(x0, y0, w, 40f, 0xFF8E7C68.toInt())
        b.dots(x0 + 2f, y0 + 2f, w - 4f, 36f, 14, 0x66000000, 2f)
        // martillo
        b.line(x0 + 8f, y0 + 6f, x0 + 8f, y0 + 30f, Cr.DBROWN, 2.4f)
        b.box(x0 + 3f, y0 + 4f, 12f, 6f, Cr.DGRAY)
        // llave inglesa
        b.line(x0 + 24f, y0 + 10f, x0 + 24f, y0 + 34f, Cr.METAL, 3f)
        b.ball(x0 + 24f, y0 + 8f, 4f, 4f, Cr.METAL)
        // sierra
        b.poly(floatArrayOf(x0 + 36f, y0 + 8f, x0 + w - 4f, y0 + 6f, x0 + w - 4f, y0 + 26f, x0 + 36f, y0 + 30f), Cr.METAL)
    }

    fun oldDoll(x: Float) = prop(x, F - 34f, 34f, 34f) { b, x0, y0 ->
        b.box(x0, y0 + 20f, 34f, 14f, Cr.BROWN)
        b.poly(floatArrayOf(x0 + 8f, y0 + 20f, x0 + 24f, y0 + 20f, x0 + 28f, y0 + 34f, x0 + 4f, y0 + 34f), Cr.PINK)
        b.face(x0 + 16f, y0 + 10f, 8f, Cr.CREAM, 0)
        b.fillOval(x0 + 12.8f, y0 + 8.7f, 3.2f, 3.5f, Cr.CREAM) // le falta un ojo
        b.line(x0 + 10f, y0 + 7f, x0 + 15f, y0 + 11f, INK, 1.2f, 0.1f)
        b.line(x0 + 15f, y0 + 7f, x0 + 10f, y0 + 11f, INK, 1.2f, 0.1f)
    }

    fun barrel(x: Float) = prop(x, F - 38f, 26f, 38f) { b, x0, y0 ->
        b.box(x0, y0, 26f, 38f, Cr.BROWN)
        b.line(x0, y0 + 9f, x0 + 26f, y0 + 9f, Cr.DGRAY, 2f, 0.3f)
        b.line(x0, y0 + 28f, x0 + 26f, y0 + 28f, Cr.DGRAY, 2f, 0.3f)
        b.ball(x0 + 13f, y0 + 1f, 12f, 3f, Cr.DBROWN)
    }

    // ================================================================== cuarto de mamá

    fun bigBed(x: Float, blanket: Int) = prop(x, F - 46f, 118f, 46f) { b, x0, y0 ->
        b.box(x0 + 5f, y0 + 36f, 5f, 10f, Cr.DBROWN)
        b.box(x0 + 108f, y0 + 36f, 5f, 10f, Cr.DBROWN)
        b.box(x0 + 2f, y0 + 26f, 114f, 12f, Cr.BROWN)
        b.box(x0, y0 + 2f, 9f, 40f, Cr.DBROWN)
        b.box(x0 + 14f, y0 + 14f, 100f, 16f, blanket)
        b.dots(x0 + 18f, y0 + 16f, 92f, 12f, 14, CrayonBuilder.lighter(blanket), 3f)
        b.ball(x0 + 17f, y0 + 14f, 10f, 6f, Cr.WHITE)
    }

    /** Mamá acostada (solo un bulto bajo la manta, con la cabeza sobre la almohada). */
    fun momFigure(x: Float, y: Float, blanket: Int) = prop(x, y, 80f, 26f) { b, x0, y0 ->
        b.ball(x0 + 12f, y0 + 12f, 11f, 10f, 0xFF5A3A2A.toInt())   // pelo
        b.ball(x0 + 13f, y0 + 14f, 8f, 8f, Cr.SKIN)
        b.line(x0 + 10f, y0 + 12f, x0 + 14f, y0 + 12f, INK, 1.2f, 0.1f)    // ojos cerrados
        b.line(x0 + 15f, y0 + 12f, x0 + 19f, y0 + 12f, INK, 1.2f, 0.1f)
        b.smile(x0 + 14f, y0 + 17f, 3f, 1.4f, INK, false)
        b.poly(
            floatArrayOf(x0 + 22f, y0 + 14f, x0 + 40f, y0 + 6f, x0 + 64f, y0 + 10f, x0 + 80f, y0 + 18f, x0 + 80f, y0 + 26f, x0 + 22f, y0 + 26f),
            blanket
        )
    }

    fun nightstand(x: Float) = prop(x, F - 60f, 34f, 60f) { b, x0, y0 ->
        b.box(x0, y0 + 26f, 34f, 34f, Cr.WOOD)
        b.outlineRect(x0 + 3f, y0 + 30f, 28f, 12f, Cr.DBROWN)
        b.ball(x0 + 17f, y0 + 36f, 1.5f, 1.5f, Cr.YELLOW)
        b.outlineRect(x0 + 3f, y0 + 44f, 28f, 12f, Cr.DBROWN)
        // lámpara
        b.box(x0 + 5f, y0 + 20f, 7f, 6f, Cr.DGRAY)
        b.poly(floatArrayOf(x0 + 3f, y0 + 20f, x0 + 14f, y0 + 20f, x0 + 12f, y0 + 8f, x0 + 5f, y0 + 8f), Cr.YELLOW)
        // pastillas (cajitas) y un vaso vacío
        b.box(x0 + 16f, y0 + 17f, 7f, 9f, Cr.WHITE)
        b.cross(x0 + 19.5f, y0 + 21.5f, 2f, Cr.DGREEN, 1.4f)
        b.box(x0 + 22f, y0 + 20f, 6f, 6f, Cr.ORANGE)
        b.box(x0 + 28f, y0 + 14f, 5f, 12f, Cr.GLASS)
    }

    fun dresser(x: Float, w: Float) = prop(x, F - 46f, w, 46f) { b, x0, y0 ->
        b.box(x0, y0 + 4f, w, 42f, Cr.BROWN)
        for (i in 0 until 3) {
            b.outlineRect(x0 + 4f, y0 + 8f + i * 12f, w - 8f, 10f, Cr.DBROWN)
            b.ball(x0 + w / 2f, y0 + 13f + i * 12f, 1.5f, 1.5f, Cr.YELLOW)
        }
        b.poly(floatArrayOf(x0 + 8f, y0 + 20f, x0 + 18f, y0 + 20f, x0 + 20f, y0 + 26f, x0 + 6f, y0 + 26f), Cr.LILAC)
    }

    fun medShelf(x: Float, y: Float, w: Float) = prop(x, y, w, 34f, Layer.DECOR) { b, x0, y0 ->
        val cols = intArrayOf(Cr.WHITE, Cr.ORANGE, Cr.BLUE, Cr.WHITE, Cr.PINK, Cr.GREEN, Cr.WHITE)
        for (row in 0 until 2) {
            val ry = y0 + 15f + row * 18f
            var bx = x0 + 3f
            var i = row * 2
            while (bx < x0 + w - 9f) {
                val bh = 10f + (i % 3) * 2f
                b.box(bx, ry - bh, 7f, bh, cols[i % cols.size])
                b.cross(bx + 3.5f, ry - bh / 2f, 1.6f, Cr.DGREEN, 1.1f)
                bx += 8.4f
                i++
            }
            b.box(x0, ry, w, 3.5f, Cr.DBROWN)
        }
        b.ball(x0 + w - 6f, y0 + 20f, 3.4f, 4.2f, Cr.ORANGE) // un frasco
    }

    /** Póster de la rana de la farmacia: sonríe y lleva un gorro con una cruz. Anomalía temprana. */
    fun frogPoster(x: Float, y: Float, w: Float, h: Float) = prop(x, y, w, h, Layer.DECOR) { b, x0, y0 ->
        b.fillRect(x0, y0, w, h, Cr.WHITE)
        b.hatchRect(x0, y0, w, h, 0xFFDDE8D2.toInt(), 4f)
        b.outlineRect(x0, y0, w, h)
        val cx = x0 + w / 2f
        b.ball(cx, y0 + h * 0.62f, w * 0.3f, h * 0.22f, Cr.GREEN)
        b.ball(cx - w * 0.14f, y0 + h * 0.4f, 5f, 5f, Cr.GREEN)
        b.ball(cx + w * 0.14f, y0 + h * 0.4f, 5f, 5f, Cr.GREEN)
        b.fillOval(cx - w * 0.14f, y0 + h * 0.4f, 3.2f, 3.2f, Cr.WHITE)
        b.fillOval(cx + w * 0.14f, y0 + h * 0.4f, 3.2f, 3.2f, Cr.WHITE)
        b.fillOval(cx - w * 0.14f + 0.6f, y0 + h * 0.4f + 0.4f, 1.4f, 1.6f, INK)
        b.fillOval(cx + w * 0.14f - 0.6f, y0 + h * 0.4f + 0.4f, 1.4f, 1.6f, INK)
        b.smile(cx, y0 + h * 0.58f, w * 0.27f, h * 0.1f, INK, true)
        b.box(cx - 8f, y0 + h * 0.1f, 16f, 9f, Cr.WHITE)
        b.cross(cx, y0 + h * 0.1f + 4.5f, 3f, Cr.DGREEN, 1.8f)
        b.scribble(x0 + 4f, y0 + h - 7f, w - 8f, 3f, Cr.DGRAY, 5, 1f)
    }

    // ================================================================== lavandería

    fun washer(x: Float) = prop(x, F - 52f, 46f, 52f) { b, x0, y0 ->
        b.box(x0, y0, 46f, 50f, Cr.WHITE, 0xFFB8C4CC.toInt())
        b.line(x0 + 1f, y0 + 12f, x0 + 45f, y0 + 12f, INK, 1.3f)
        for (i in 0 until 3) b.ball(x0 + 8f + i * 6f, y0 + 6f, 1.8f, 1.8f, Cr.DGRAY)
        b.ball(x0 + 36f, y0 + 6f, 3f, 3f, Cr.RED)
        b.ball(x0 + 23f, y0 + 30f, 15f, 15f, Cr.BLUE)
        b.ball(x0 + 23f, y0 + 30f, 11f, 11f, Cr.GLASS)
        b.spiral(x0 + 23f, y0 + 30f, 8f, Cr.CORAL, 1.8f)    // la ropa dando vueltas
        b.box(x0 + 3f, y0 + 50f, 6f, 2f, Cr.DGRAY)
        b.box(x0 + 37f, y0 + 50f, 6f, 2f, Cr.DGRAY)
    }

    fun basket(x: Float) = prop(x, F - 30f, 36f, 30f) { b, x0, y0 ->
        b.poly(floatArrayOf(x0 + 6f, y0 + 12f, x0 + 30f, y0 + 12f, x0 + 33f, y0 + 30f, x0 + 3f, y0 + 30f), Cr.ORANGE)
        b.hatchRect(x0 + 4f, y0 + 14f, 28f, 14f, Cr.BROWN, 2.6f, true)
        b.ball(x0 + 13f, y0 + 9f, 9f, 5f, Cr.RED)
        b.ball(x0 + 24f, y0 + 8f, 8f, 5f, Cr.BLUE)
        b.poly(floatArrayOf(x0 + 14f, y0 + 6f, x0 + 22f, y0 + 1f, x0 + 25f, y0 + 6f), Cr.YELLOW)
    }

    fun laundryShelf(x: Float, y: Float, w: Float) = prop(x, y, w, 36f, Layer.DECOR) { b, x0, y0 ->
        b.box(x0, y0 + 16f, w, 3.5f, Cr.DBROWN)
        b.box(x0, y0 + 33f, w, 3.5f, Cr.DBROWN)
        b.box(x0 + 4f, y0 + 2f, 10f, 14f, Cr.BLUE)
        b.ball(x0 + 9f, y0 + 6f, 3f, 3f, Cr.WHITE)
        b.box(x0 + 17f, y0 + 4f, 9f, 12f, Cr.YELLOW)
        b.box(x0 + 29f, y0 + 6f, 8f, 10f, Cr.GREEN)
        b.box(x0 + 6f, y0 + 22f, 12f, 11f, Cr.WOOD)
        b.box(x0 + 20f, y0 + 24f, 12f, 9f, Cr.WOOD)
        b.box(x0 + 34f, y0 + 21f, 11f, 12f, Cr.WOOD)
    }

    /** Tendedero con ropa de niño colgando. */
    fun clothesLine(x: Float, y: Float, w: Float) = prop(x, y, w, 30f, Layer.DECOR) { b, x0, y0 ->
        b.line(x0, y0 + 2f, x0 + w, y0 + 6f, Cr.DGRAY, 1.2f, 0.4f)
        val n = (w / 34f).toInt()
        for (i in 0 until n) {
            val px = x0 + 10f + i * 34f
            val py = y0 + 4f + (px - x0) / w * 4f
            when (i % 3) {
                0 -> b.poly(floatArrayOf(px, py, px + 14f, py, px + 18f, py + 6f, px + 12f, py + 8f, px + 12f, py + 20f, px + 2f, py + 20f, px + 2f, py + 8f, px - 4f, py + 6f), Cr.TEAL)
                1 -> b.poly(floatArrayOf(px, py, px + 8f, py, px + 8f, py + 15f, px + 6f, py + 20f, px, py + 20f), Cr.RED)
                else -> b.poly(floatArrayOf(px, py, px + 16f, py, px + 18f, py + 14f, px - 2f, py + 14f), Cr.YELLOW)
            }
            b.fillRect(px + 2f, py - 2f, 3f, 4f, Cr.WHITE)
        }
    }

    /** Huella de mano infantil: [fingers] suele ser 5... y a veces no. */
    fun handprint(x: Float, y: Float, color: Int, fingers: Int) = prop(x, y, 16f, 18f, Layer.DECOR) { b, x0, y0 ->
        b.ball(x0 + 8f, y0 + 12f, 5.5f, 5f, color)
        for (i in 0 until fingers) {
            val a = (-160f + i * (140f / (fingers - 1).coerceAtLeast(1))) * PI.toFloat() / 180f
            val fx = x0 + 8f + cos(a) * 9f
            val fy = y0 + 12f + sin(a) * 9f
            b.line(x0 + 8f + cos(a) * 4f, y0 + 12f + sin(a) * 4f, fx, fy, color, 2.2f, 0.3f)
        }
    }

    // ================================================================== comedor

    fun diningTable(x: Float, w: Float) = prop(x, F - 50f, w, 50f) { b, x0, y0 ->
        b.box(x0, y0 + 26f, w, 6f, Cr.WHITE)
        b.hatchRect(x0 + 2f, y0 + 27f, w - 4f, 4f, Cr.CORAL, 2.4f, true)
        b.box(x0 + 8f, y0 + 32f, 5f, 18f, Cr.DBROWN)
        b.box(x0 + w - 13f, y0 + 32f, 5f, 18f, Cr.DBROWN)
        b.poly(floatArrayOf(x0 + 4f, y0 + 32f, x0 + w - 4f, y0 + 32f, x0 + w - 10f, y0 + 41f, x0 + 10f, y0 + 41f), Cr.WHITE)
        // platos, un florero y una vela
        for (i in 0 until 2) {
            b.ball(x0 + 16f + i * (w - 44f), y0 + 24f, 9f, 2.6f, Cr.WHITE)
            b.ball(x0 + 16f + i * (w - 44f), y0 + 23.5f, 5f, 1.4f, Cr.CREAM)
        }
        b.box(x0 + w / 2f - 4f, y0 + 14f, 8f, 12f, Cr.TEAL)
        b.line(x0 + w / 2f, y0 + 14f, x0 + w / 2f - 3f, y0 + 5f, Cr.DGREEN, 1.4f)
        b.line(x0 + w / 2f, y0 + 14f, x0 + w / 2f + 4f, y0 + 4f, Cr.DGREEN, 1.4f)
        b.ball(x0 + w / 2f - 3f, y0 + 4f, 3.6f, 3.6f, Cr.YELLOW)
        b.ball(x0 + w / 2f + 4f, y0 + 3f, 3.6f, 3.6f, Cr.PINK)
    }

    fun sideboard(x: Float, w: Float) = prop(x, F - 44f, w, 44f) { b, x0, y0 ->
        b.box(x0, y0 + 6f, w, 38f, Cr.WOOD)
        var dx = x0 + 5f
        while (dx < x0 + w - 20f) {
            b.outlineRect(dx, y0 + 12f, 24f, 28f, Cr.DBROWN)
            b.ball(dx + 20f, y0 + 26f, 1.4f, 1.4f, Cr.YELLOW)
            dx += 30f
        }
        b.box(x0 + 8f, y0 - 4f, 12f, 10f, Cr.PINK)
        b.box(x0 + w - 24f, y0 - 6f, 14f, 12f, Cr.BLUE)
    }

    fun balloon(x: Float, y: Float) = prop(x, y, 20f, 52f) { b, x0, y0 ->
        b.line(x0 + 10f, y0 + 26f, x0 + 8f, y0 + 52f, INK, 1f, 0.5f)
        b.ball(x0 + 10f, y0 + 13f, 9f, 11f, Cr.RED)               // el globo del cumpleaños, ya más chiquito
        b.outlineOval(x0 + 10f, y0 + 9f, 2.6f, 2.6f, Cr.WHITE, 1.2f) // un "8" hecho con dos círculos
        b.outlineOval(x0 + 10f, y0 + 15f, 3.2f, 3.2f, Cr.WHITE, 1.2f)
        b.line(x0 + 3f, y0 + 18f, x0 + 6f, y0 + 20f, 0x66000000, 1f)
    }

    fun garland(x: Float, y: Float, w: Float) = prop(x, y, w, 16f, Layer.DECOR) { b, x0, y0 ->
        b.line(x0, y0 + 2f, x0 + w, y0 + 2f, INK, 1f, 0.4f)
        val cols = intArrayOf(Cr.RED, Cr.YELLOW, Cr.BLUE, Cr.GREEN)
        var i = 0
        var px = x0 + 4f
        while (px < x0 + w - 8f) {
            b.poly(floatArrayOf(px, y0 + 2f, px + 8f, y0 + 2f, px + 4f, y0 + 13f), cols[i % cols.size])
            px += 11f
            i++
        }
    }
}
