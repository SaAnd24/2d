package com.terror2d.world

import com.terror2d.events.EventType
import com.terror2d.interaction.Interactable
import com.terror2d.interaction.InteractionContext
import com.terror2d.interaction.InteractionIcon
import com.terror2d.interaction.InteractionResult
import com.terror2d.render.WorldRenderer

/**
 * Zona invisible que se puede examinar: muestra un texto breve. Se coloca sobre un mueble o
 * decoración existente ("Una silla de madera."). Sin dibujo propio.
 */
class ExamineSpot(
    val id: String,
    x: Float,
    y: Float,
    w: Float,
    h: Float,
    val text: String,
    private val margin: Float = 8f
) : WorldObject(x, y, w, h), Interactable {

    init {
        collidable = false
        visible = false
    }

    override val interactionId: String get() = id
    override val promptText: String get() = "EXAMINAR"
    override val promptIcon: InteractionIcon get() = InteractionIcon.EXAMINE
    override val zoneLeft: Float get() = x - margin
    override val zoneRight: Float get() = right + margin
    override val markerX: Float get() = centerX
    override val markerY: Float get() = y - 4f

    override fun executeInteraction(ctx: InteractionContext): InteractionResult {
        ctx.post(EventType.ON_OBJECT_EXAMINED, id)
        return InteractionResult.message(text)
    }

    override fun prepareVisuals(rng: com.terror2d.util.SeededRandom) {}

    override fun render(r: WorldRenderer) {}
}

/** Interruptor de pared que enciende y apaga una [LightSource]. */
class LightSwitch(
    val id: String,
    x: Float,
    y: Float,
    val light: LightSource
) : WorldObject(x, y, WIDTH, HEIGHT), Interactable {

    init {
        collidable = false
        layer = Layer.DECOR
    }

    override val interactionId: String get() = id
    override val promptText: String get() = if (light.active) "APAGAR" else "ENCENDER"
    override val promptIcon: InteractionIcon get() = InteractionIcon.USE
    override val zoneLeft: Float get() = x - 16f
    override val zoneRight: Float get() = right + 16f
    override val markerX: Float get() = centerX
    override val markerY: Float get() = y - 6f

    override fun executeInteraction(ctx: InteractionContext): InteractionResult {
        light.active = !light.active
        return InteractionResult.DONE
    }

    override fun prepareVisuals(rng: com.terror2d.util.SeededRandom) {
        outline = SketchBuilder.buildOutline(x, y, width, height, rng)
        hatch = EMPTY
    }

    override fun render(r: WorldRenderer) {
        r.drawSwitch(this)
    }

    companion object {
        const val WIDTH = 10f
        const val HEIGHT = 16f
    }
}

/**
 * Zona invisible cuya interacción la define una función: sirve para objetos narrativos (el grifo, las
 * pastillas de mamá, hablar con ella) sin crear una clase nueva para cada uno. La lógica de estado
 * va en la función ([InteractionContext.setFlag] / [InteractionContext.hasFlag]).
 */
class ScriptedSpot(
    val id: String,
    x: Float,
    y: Float,
    w: Float,
    h: Float,
    private val prompt: String = "EXAMINAR",
    private val icon: InteractionIcon = InteractionIcon.EXAMINE,
    private val margin: Float = 8f,
    private val action: (InteractionContext) -> InteractionResult
) : WorldObject(x, y, w, h), Interactable {

    init {
        collidable = false
        visible = false
    }

    override val interactionId: String get() = id
    override val promptText: String get() = prompt
    override val promptIcon: InteractionIcon get() = icon
    override val zoneLeft: Float get() = x - margin
    override val zoneRight: Float get() = right + margin
    override val markerX: Float get() = centerX
    override val markerY: Float get() = y - 4f

    override fun executeInteraction(ctx: InteractionContext): InteractionResult {
        ctx.post(EventType.ON_OBJECT_EXAMINED, id)
        return action(ctx)
    }

    override fun prepareVisuals(rng: com.terror2d.util.SeededRandom) {}

    override fun render(r: WorldRenderer) {}
}
