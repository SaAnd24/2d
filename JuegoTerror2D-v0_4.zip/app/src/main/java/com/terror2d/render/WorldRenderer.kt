package com.terror2d.render

import android.graphics.Paint
import com.terror2d.core.GameConfig
import com.terror2d.draw.CrayonSprite
import com.terror2d.pixel.PixelCharacterData
import com.terror2d.pixel.PixelPose
import com.terror2d.scene.RoomSegment
import com.terror2d.world.DarkZone
import com.terror2d.world.Door
import com.terror2d.world.LightSource
import com.terror2d.world.LightSwitch
import com.terror2d.world.Player
import com.terror2d.world.PlayerState
import com.terror2d.world.Wardrobe
import com.terror2d.world.WardrobePhase

/**
 * Renderizador del MUNDO. Pipeline de un frame (lo orquesta la escena):
 *
 *   fondo -> decoración y muebles -> personaje (pixel art) -> primer plano -> iluminación (máscara de oscuridad)
 *
 * Esta clase aporta las piezas genéricas (puertas, armarios, bombillas, iluminación, personaje) con
 * formas planas; el ESTILO lo ponen sus hijos: [CrayonRenderer] (v0.4) y, en el futuro,
 * Graphite / Scratch / Distortion, que podrán sustituir [drawBackdrop] y [drawSprite] sin tocar el motor.
 * El personaje se dibuja con [PlayerPixelRenderer], independiente del estilo del mundo.
 */
open class WorldRenderer : BaseRenderer() {

    protected val lighting = LightingRenderer()
    protected val playerPixels = PlayerPixelRenderer()

    /** Fondo del segmento (pared y suelo). Versión plana; [CrayonRenderer] la sustituye por trazos de crayón. */
    open fun drawBackdrop(seg: RoomSegment, chunks: Array<CrayonSprite>, camX: Float) {
        val w = seg.width
        val fy = seg.floorY
        paint.style = Paint.Style.FILL
        paint.color = tint(seg.wallColor)
        canvas.drawRect(0f, 0f, w, fy, paint)
        paint.color = tint(seg.floorColor)
        canvas.drawRect(0f, fy, w, seg.height, paint)
        paint.color = tint(Palette.EDGE_WALL)
        if (seg.leftBoundary > 0f) canvas.drawRect(0f, 0f, seg.leftBoundary, seg.height, paint)
        if (seg.rightBoundary < w) canvas.drawRect(seg.rightBoundary, 0f, w, seg.height, paint)
    }

    /** Dibujo de crayón precalculado. Lo implementa el estilo concreto. */
    open fun drawSprite(sprite: CrayonSprite) {}

    /**
     * Personaje pixelado: usa los datos de pose del jugador y la iluminación que recibe en su posición
     * (la misma que oscurece el resto del mundo).
     */
    open fun drawPlayer(p: Player) {
        val pose = when {
            p.state == PlayerState.ENTERING_HIDE || p.state == PlayerState.LEAVING_HIDE -> PixelPose.HIDE
            p.walkFrame == 1 -> PixelPose.WALK_1
            p.walkFrame == 2 -> PixelPose.WALK_2
            p.walkFrame == 3 -> PixelPose.WALK_3
            else -> PixelPose.IDLE
        }
        drawPixelCharacter(p.sprite, pose, p.facing < 0f, p.centerX, p.bottom, p.visibilityAlpha, p)
    }

    /** Dibuja cualquier [PixelCharacterData] (el renderer no depende de que sea "el niño"). */
    open fun drawPixelCharacter(
        data: PixelCharacterData,
        pose: PixelPose,
        flip: Boolean,
        centerX: Float,
        bottomY: Float,
        alpha: Float,
        p: Player
    ) {
        playerPixels.render(canvas, data, pose, flip, centerX, bottomY, alpha, p.light, corruption)
    }

    /**
     * Capa de iluminación del segmento (coordenadas del mundo), tras dibujar objetos y personaje:
     * la oscuridad se abre solo alrededor de las luces activas. [camX]/[camY] = esquina de la cámara.
     */
    open fun drawLighting(seg: RoomSegment, camX: Float, camY: Float, extra: LightSource?) {
        lighting.drawWorldLighting(
            canvas, camX, camY, seg.ambientDark, seg.ambientColor,
            seg.darkZones, seg.lights, extra, renderTime
        )
    }

    /** Viñeta de pantalla (coordenadas lógicas). */
    open fun drawVignette() {
        lighting.drawVignette(canvas)
    }

    /** Fundido a negro de las transiciones (coordenadas lógicas). */
    open fun drawFade(alpha: Float) {
        if (alpha <= 0.003f) return
        paint.style = Paint.Style.FILL
        paint.color = (alpha.coerceIn(0f, 1f) * 255f).toInt() shl 24
        canvas.drawRect(0f, 0f, GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat(), paint)
    }

    /** Puerta de frente: marco, hueco oscuro y hoja que se abre con [Door.openProgress]. */
    open fun drawDoor(d: Door) {
        val x = d.x
        val y = d.y
        val w = d.width

        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.DOOR_FRAME)
        canvas.drawRect(x - 3f, y - 3f, d.right + 3f, d.bottom, paint)
        paint.color = tint(Palette.DOOR_INSIDE)
        canvas.drawRect(x, y, d.right, d.bottom, paint)

        val pw = w * (1f - 0.8f * d.openProgress)
        if (pw > 0.5f) {
            paint.color = tint(d.panelColor)
            canvas.drawRect(x, y, x + pw, d.bottom, paint)
            canvas.save()
            canvas.clipRect(x, y, x + pw, d.bottom)
            drawStrokes(d.hatch, d.panelHatch, 1.3f)
            canvas.restore()

            // Dos paneles hundidos
            if (pw > 12f) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1f
                paint.color = tint(d.panelHatch)
                val pl = x + pw * 0.16f
                val pr = x + pw * 0.84f
                canvas.drawRect(pl, y + 7f, pr, y + d.height * 0.42f, paint)
                canvas.drawRect(pl, y + d.height * 0.5f, pr, d.bottom - 7f, paint)
            }

            // Pomo (o placa de cerradura si está bloqueada)
            paint.style = Paint.Style.FILL
            val kx = x + pw - 5f
            val ky = y + d.height * 0.55f
            if (d.locked) {
                paint.color = tint(0xFF4A4458.toInt())
                canvas.drawRect(kx - 3f, ky - 5f, kx + 3f, ky + 5f, paint)
                paint.color = tint(Palette.OUTLINE)
                canvas.drawCircle(kx, ky - 1f, 1.1f, paint)
                canvas.drawRect(kx - 0.5f, ky - 1f, kx + 0.5f, ky + 3f, paint)
            } else {
                paint.color = tint(Palette.DOOR_KNOB)
                canvas.drawCircle(kx, ky, 2.4f, paint)
            }
        }
        drawStrokes(d.outline, Palette.OUTLINE, 1.1f)
    }

    /** Armario: cuerpo de crayón, una o dos puertas que se abren, interior oscuro, decoración y ojos si hay alguien. */
    open fun drawWardrobe(w: Wardrobe) {
        val st = w.style
        val x = w.x
        val y = w.y
        val r = w.right
        val b = w.bottom

        // Cuerpo
        paint.style = Paint.Style.FILL
        paint.color = tint(st.bodyFill)
        canvas.drawRect(x, y, r, b - 4f, paint)
        drawStrokes(w.hatch, st.bodyHatch, 1.4f)

        // Cornisa y pies
        paint.style = Paint.Style.FILL
        paint.color = tint(st.trim)
        canvas.drawRect(x - 2f, y - 3f, r + 2f, y + 4f, paint)
        canvas.drawRect(x + 3f, b - 4f, x + 9f, b, paint)
        canvas.drawRect(r - 9f, b - 4f, r - 3f, b, paint)

        // Hueco interior (se ve al abrir)
        val inL = x + 4f
        val inR = r - 4f
        val inT = y + 9f
        val inB = b - 8f
        paint.color = tint(Palette.WARDROBE_INSIDE)
        canvas.drawRect(inL, inT, inR, inB, paint)

        val open = w.visualOpen
        val k = 1f - 0.86f * open

        var gapCenter: Float
        if (st.doorCount >= 2) {
            val half = (inR - inL) / 2f
            val pw = half * k
            drawWardrobeDoor(w, inL, inT, inL + pw, inB)
            drawWardrobeDoor(w, inR - pw, inT, inR, inB)
            if (pw > 4f) {
                paint.style = Paint.Style.FILL
                paint.color = tint(Palette.DOOR_KNOB)
                canvas.drawCircle(inL + pw - 2.5f, inT + (inB - inT) * 0.52f, 1.7f, paint)
                canvas.drawCircle(inR - pw + 2.5f, inT + (inB - inT) * 0.52f, 1.7f, paint)
            }
            gapCenter = (inL + inR) / 2f
        } else {
            val pw = (inR - inL) * k
            drawWardrobeDoor(w, inL, inT, inL + pw, inB)
            if (pw > 5f) {
                paint.style = Paint.Style.FILL
                paint.color = tint(Palette.DOOR_KNOB)
                canvas.drawCircle(inL + pw - 3f, inT + (inB - inT) * 0.52f, 1.8f, paint)
            }
            gapCenter = (inL + pw + inR) / 2f
        }

        // Decoración y arañazos (solo con la puerta casi cerrada)
        if (open < 0.3f) {
            drawStrokes(w.deco, st.decoColor, 1.5f)
            drawStrokes(w.scratches, st.bodyHatch, 1f)
        }

        // Alguien dentro: dos ojos que brillan en la rendija (y parpadean de vez en cuando)
        val inside = w.phase == WardrobePhase.OCCUPIED || w.phase == WardrobePhase.CLOSING_BEHIND
        if (inside && open in 0.05f..0.5f) {
            val ey = inT + (inB - inT) * 0.30f
            val blink = (renderTime % 3.6f) > 3.46f
            paint.style = Paint.Style.FILL
            paint.color = tint(Palette.EYE_WHITE)
            if (blink) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 0.9f
                canvas.drawLine(gapCenter - 2.6f, ey, gapCenter - 0.6f, ey, paint)
                canvas.drawLine(gapCenter + 0.6f, ey, gapCenter + 2.6f, ey, paint)
            } else {
                oval.set(gapCenter - 2.7f, ey - 1.5f, gapCenter - 0.7f, ey + 1.5f)
                canvas.drawOval(oval, paint)
                oval.set(gapCenter + 0.7f, ey - 1.5f, gapCenter + 2.7f, ey + 1.5f)
                canvas.drawOval(oval, paint)
            }
        }

        drawStrokes(w.outline, Palette.OUTLINE, 1.1f)
    }

    /** Hoja de armario entre [l,r] x [t,bt]: relleno, trazos de crayón recortados, panel hundido y contorno. */
    private fun drawWardrobeDoor(w: Wardrobe, l: Float, t: Float, r: Float, bt: Float) {
        if (r - l < 0.8f) return
        paint.style = Paint.Style.FILL
        paint.color = tint(w.style.doorFill)
        canvas.drawRect(l, t, r, bt, paint)
        canvas.save()
        canvas.clipRect(l, t, r, bt)
        drawStrokes(w.hatch, w.style.bodyHatch, 1.2f)
        canvas.restore()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawRect(l, t, r, bt, paint)
        if (r - l > 9f) {
            paint.color = tint(w.style.bodyHatch)
            canvas.drawRect(l + 3f, t + 4f, r - 3f, bt - 4f, paint)
        }
    }

    /** Bombilla de una lámpara: se apaga y enciende según el nivel de la luz (0..1). */
    open fun drawBulb(cx: Float, cy: Float, level: Float) {
        paint.style = Paint.Style.FILL
        paint.color = tint(lerpColor(0xFF5A4A34.toInt(), 0xFFFFF2B0.toInt(), level))
        canvas.drawCircle(cx, cy, 4.4f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawCircle(cx, cy, 4.4f, paint)
    }

    /** Interruptor de pared: placa y palanca arriba (encendido) o abajo (apagado). */
    open fun drawSwitch(s: LightSwitch) {
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.SWITCH_PLATE)
        canvas.drawRect(s.x, s.y, s.right, s.bottom, paint)
        drawStrokes(s.outline, Palette.OUTLINE, 1f)
        val on = s.light.active
        val ly = if (on) s.y + 3f else s.y + 9f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawRect(s.x + 3f, ly, s.right - 3f, ly + 4f, paint)
    }
}
