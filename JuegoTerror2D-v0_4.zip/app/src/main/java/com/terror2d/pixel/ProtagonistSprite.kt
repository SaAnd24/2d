package com.terror2d.pixel

/** Lienzo de índices de paleta con primitivas mínimas (solo para construir los datos del personaje). */
class PixelCanvas(val w: Int, val h: Int) {
    val px = IntArray(w * h)

    fun set(x: Int, y: Int, c: Int) {
        if (x in 0 until w && y in 0 until h) px[y * w + x] = c
    }

    fun get(x: Int, y: Int): Int = if (x in 0 until w && y in 0 until h) px[y * w + x] else 0

    fun rect(x0: Int, y0: Int, x1: Int, y1: Int, c: Int) {
        for (y in y0..y1) for (x in x0..x1) set(x, y, c)
    }

    fun ellipse(cx: Int, cy: Int, rx: Int, ry: Int, c: Int) {
        for (y in cy - ry..cy + ry) for (x in cx - rx..cx + rx) {
            val dx = (x - cx).toFloat() / (rx + 0.5f)
            val dy = (y - cy).toFloat() / (ry + 0.5f)
            if (dx * dx + dy * dy <= 1f) set(x, y, c)
        }
    }

    /** Contorno de 1 píxel alrededor de todo lo dibujado (4 vecinos). */
    fun outline(c: Int) {
        val snap = px.copyOf()
        for (y in 0 until h) for (x in 0 until w) {
            if (snap[y * w + x] != 0) continue
            val n = (y > 0 && snap[(y - 1) * w + x] != 0) ||
                (y < h - 1 && snap[(y + 1) * w + x] != 0) ||
                (x > 0 && snap[y * w + x - 1] != 0) ||
                (x < w - 1 && snap[y * w + x + 1] != 0)
            if (n) px[y * w + x] = c
        }
    }
}

/**
 * El protagonista: un niño de 8 años, pixel art de 48x64 (unos 49 px visibles de alto), de PERFIL
 * mirando a la derecha (el renderer lo voltea). Se genera una vez a partir de primitivas simples y
 * queda como una matriz de índices de paleta (13 colores): el renderer no sabe quién es.
 */
object ProtagonistSprite {

    const val W = 48
    const val H = 64
    const val CX = 23

    val PALETTE: IntArray = intArrayOf(
        0x00000000,
        0xFF2B1A22.toInt(), // 1 contorno
        0xFF6B3E26.toInt(), // 2 cabello
        0xFFFFD2A8.toInt(), // 3 piel
        0xFFE5A57F.toInt(), // 4 sombra de piel
        0xFF4FB3A5.toInt(), // 5 camisa
        0xFF2F8A80.toInt(), // 6 sombra de camisa
        0xFF4C5BA8.toInt(), // 7 pantalón
        0xFF343F7C.toInt(), // 8 sombra de pantalón
        0xFFD9553C.toInt(), // 9 zapatos
        0xFF1C1424.toInt(), // 10 ojo
        0xFFF2C14E.toInt(), // 11 detalle (franja)
        0xFFFFF6D8.toInt()  // 12 brillo
    )

    /** Paleta alternativa (recuerdos): mismos datos, otros colores. */
    val PALETTE_FLASHBACK: IntArray = intArrayOf(
        0x00000000,
        0xFF3A2A20.toInt(), 0xFF7A6A52.toInt(), 0xFFE8D8B8.toInt(), 0xFFC8B590.toInt(),
        0xFFB8A888.toInt(), 0xFF8E7F63.toInt(), 0xFF9A8E78.toInt(), 0xFF6F644F.toInt(),
        0xFF5A4E3C.toInt(), 0xFF2A2018.toInt(), 0xFFD8C898.toInt(), 0xFFFFF8E8.toInt()
    )

    private class PoseParams(
        val bob: Int = 0,
        val frontLeg: Int = 0,
        val backLeg: Int = 0,
        val headDx: Int = 0,
        val crouch: Int = 0,
        val eyesClosed: Boolean = false
    )

    fun create(): PixelCharacterData {
        val frames = arrayOfNulls<IntArray>(PixelPose.values().size)
        frames[PixelPose.IDLE.ordinal] = paint(PoseParams())
        frames[PixelPose.WALK_1.ordinal] = paint(PoseParams(bob = 0, frontLeg = 4, backLeg = -4))
        frames[PixelPose.WALK_2.ordinal] = paint(PoseParams(bob = -1, frontLeg = 1, backLeg = -1))
        frames[PixelPose.WALK_3.ordinal] = paint(PoseParams(bob = 0, frontLeg = -4, backLeg = 4))
        frames[PixelPose.HIDE.ordinal] = paint(PoseParams(crouch = 5, headDx = -1))
        frames[PixelPose.HURT.ordinal] = paint(PoseParams(bob = 1, headDx = 1, eyesClosed = true))
        frames[PixelPose.FLASHBACK.ordinal] = paint(PoseParams())
        return PixelCharacterData("protagonista", W, H, PALETTE, frames, CX)
    }

    private fun paint(p: PoseParams): IntArray {
        val c = PixelCanvas(W, H)
        val cx = CX
        val top = p.bob + p.crouch  // desplazamiento vertical del tronco y la cabeza

        // brazo trasero (más oscuro)
        arm(c, cx - 1, 34 + top, -p.frontLeg / 2, PixelIndex.SHIRT_SHADOW, PixelIndex.SKIN_SHADOW)

        // pierna trasera y zapato
        leg(c, cx - 3 + p.backLeg, PixelIndex.SKIN_SHADOW, 0)

        // torso y camiseta con franja
        c.rect(cx - 5, 32 + top, cx + 4, 46 + top, PixelIndex.SHIRT)
        c.rect(cx - 5, 32 + top, cx - 4, 46 + top, PixelIndex.SHIRT_SHADOW)
        c.rect(cx - 5, 38 + top, cx + 4, 39 + top, PixelIndex.DETAIL)
        // pantalón corto
        c.rect(cx - 5, 47 + top, cx + 4, 54 + top, PixelIndex.PANTS)
        c.rect(cx - 5, 47 + top, cx - 4, 54 + top, PixelIndex.PANTS_SHADOW)
        c.rect(cx - 5, 53 + top, cx + 4, 54 + top, PixelIndex.PANTS_SHADOW)

        // pierna delantera y zapato
        leg(c, cx + 1 + p.frontLeg, PixelIndex.SKIN, 1)

        // cuello y cabeza (cabeza grande: es un niño)
        c.rect(cx - 1, 30 + top, cx + 2, 33 + top, PixelIndex.SKIN_SHADOW)
        val hx = cx + 1 + p.headDx
        val hy = 23 + top
        c.ellipse(hx, hy, 8, 8, PixelIndex.SKIN)
        // pelo: casquete, nuca y flequillo
        for (y in hy - 8..hy + 8) for (x in hx - 9..hx + 9) {
            if (c.get(x, y) != PixelIndex.SKIN) continue
            val back = x <= hx - 3 && y <= hy + 4
            val capTop = y <= hy - 4
            val fringe = y <= hy - 2 && x >= hx + 1 && ((x + y) % 3 != 0)
            if (back || capTop || fringe) c.set(x, y, PixelIndex.HAIR)
        }
        c.set(hx, hy - 6, PixelIndex.HIGHLIGHT)
        c.set(hx + 1, hy - 6, PixelIndex.HIGHLIGHT)
        // oreja, nariz, ojo, mejilla y boca
        c.rect(hx - 2, hy + 1, hx - 1, hy + 3, PixelIndex.SKIN_SHADOW)
        c.set(hx + 8, hy + 2, PixelIndex.SKIN_SHADOW)
        if (p.eyesClosed) {
            c.rect(hx + 4, hy + 2, hx + 6, hy + 2, PixelIndex.EYE)
        } else {
            c.rect(hx + 5, hy, hx + 6, hy + 3, PixelIndex.EYE)
            c.set(hx + 6, hy, PixelIndex.HIGHLIGHT)
        }
        c.rect(hx + 4, hy + 5, hx + 5, hy + 5, PixelIndex.SKIN_SHADOW)
        c.rect(hx + 6, hy + 6, hx + 7, hy + 6, PixelIndex.OUTLINE)

        // brazo delantero
        arm(c, cx + 1, 34 + top, -p.backLeg / 2, PixelIndex.SHIRT, PixelIndex.SKIN)

        c.outline(PixelIndex.OUTLINE)
        return c.px
    }

    /** Brazo de 2 px de ancho: manga arriba y mano abajo; [swing] desplaza la mano. */
    private fun arm(c: PixelCanvas, x: Int, y: Int, swing: Int, sleeve: Int, hand: Int) {
        for (i in 0..10) {
            val xx = x + swing * i / 10
            val col = if (i <= 4) sleeve else hand
            c.set(xx, y + i, col)
            c.set(xx + 1, y + i, col)
        }
    }

    /** Pierna de 3 px (rows 55..60) y zapato (rows 61..63) que apunta hacia delante. */
    private fun leg(c: PixelCanvas, x: Int, skin: Int, front: Int) {
        c.rect(x, 55, x + 2, 60, skin)
        c.rect(x - 1, 61, x + 4, 63, PixelIndex.SHOES)
        c.set(x + 4, 61, PixelIndex.TRANSPARENT)
        if (front == 1) c.set(x, 61, PixelIndex.HIGHLIGHT)
    }
}
