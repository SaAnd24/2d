package com.terror2d.pixel

import kotlin.math.roundToInt

/** Poses de un personaje pixelado. HIDE, HURT y FLASHBACK están preparadas para el futuro. */
enum class PixelPose { IDLE, WALK_1, WALK_2, WALK_3, HIDE, HURT, FLASHBACK }

/** Índices de paleta del protagonista (0 = transparente). Cualquier personaje puede usar su propia paleta. */
object PixelIndex {
    const val TRANSPARENT = 0
    const val OUTLINE = 1
    const val HAIR = 2
    const val SKIN = 3
    const val SKIN_SHADOW = 4
    const val SHIRT = 5
    const val SHIRT_SHADOW = 6
    const val PANTS = 7
    const val PANTS_SHADOW = 8
    const val SHOES = 9
    const val EYE = 10
    const val DETAIL = 11
    const val HIGHLIGHT = 12
}

/**
 * Datos de un personaje pixelado: tamaño, paleta y una matriz de índices por pose.
 * No depende de Android ni de "ser el niño": cualquier [PixelCharacterData] se puede dibujar con
 * [com.terror2d.render.PlayerPixelRenderer].
 *
 * [anchorX] es la columna que se alinea con el centro del cuerpo; la última fila es el suelo.
 */
class PixelCharacterData(
    val name: String,
    val width: Int,
    val height: Int,
    val palette: IntArray,
    private val frames: Array<IntArray?>,
    val anchorX: Int = width / 2
) {
    init {
        require(palette.isNotEmpty() && palette[0] ushr 24 == 0) { "el índice 0 debe ser transparente" }
        for (f in frames) if (f != null) require(f.size == width * height) { "matriz con tamaño incorrecto" }
    }

    fun hasPose(pose: PixelPose): Boolean = frames[pose.ordinal] != null

    /** Matriz de índices de la pose (si falta, IDLE). */
    fun frame(pose: PixelPose): IntArray = frames[pose.ordinal] ?: frames[PixelPose.IDLE.ordinal]!!

    /** Mismo personaje con otra paleta (flashbacks, otros niños, versiones del protagonista). */
    fun withPalette(newPalette: IntArray, newName: String = name): PixelCharacterData =
        PixelCharacterData(newName, width, height, newPalette, frames, anchorX)

    /** Cuántos píxeles no transparentes tiene una pose. */
    fun filledPixels(pose: PixelPose): Int {
        val f = frame(pose)
        var n = 0
        for (v in f) if (v != PixelIndex.TRANSPARENT) n++
        return n
    }

    /** Fila de la primera y de la última fila con píxeles (altura visible = last - first + 1). */
    fun visibleRows(pose: PixelPose): IntArray {
        val f = frame(pose)
        var first = -1
        var last = -1
        for (y in 0 until height) {
            var any = false
            for (x in 0 until width) if (f[y * width + x] != PixelIndex.TRANSPARENT) { any = true; break }
            if (any) {
                if (first < 0) first = y
                last = y
            }
        }
        return intArrayOf(first, last)
    }
}

/**
 * Iluminación que recibe un personaje: brillo (0..1) y tinte (multiplicador por canal, 1 = neutro).
 * Se calcula con [com.terror2d.world.LightField] a partir de las MISMAS luces que usa la máscara de oscuridad.
 */
class LightingSample {
    var brightness: Float = 1f
    var tintR: Float = 1f
    var tintG: Float = 1f
    var tintB: Float = 1f

    fun set(b: Float, r: Float, g: Float, bl: Float) {
        brightness = b
        tintR = r
        tintG = g
        tintB = bl
    }

    fun copyFrom(o: LightingSample) = set(o.brightness, o.tintR, o.tintG, o.tintB)

    /** Clave discreta (para cachear bitmaps): 3 bits de brillo + 2 bits por canal del tinte. */
    fun key(): Int {
        val b = (brightness.coerceIn(0f, 1f) * 7f).roundToInt()
        val r = (((tintR - 0.4f) / 0.6f).coerceIn(0f, 1f) * 3f).roundToInt()
        val g = (((tintG - 0.4f) / 0.6f).coerceIn(0f, 1f) * 3f).roundToInt()
        val bl = (((tintB - 0.4f) / 0.6f).coerceIn(0f, 1f) * 3f).roundToInt()
        return b or (r shl 3) or (g shl 5) or (bl shl 7)
    }

    /** Escribe en [dst] el valor al que corresponde la clave (así el bitmap cacheado es siempre el mismo). */
    fun quantizeInto(dst: LightingSample) {
        val k = key()
        dst.brightness = (k and 7) / 7f
        dst.tintR = 0.4f + ((k shr 3) and 3) / 3f * 0.6f
        dst.tintG = 0.4f + ((k shr 5) and 3) / 3f * 0.6f
        dst.tintB = 0.4f + ((k shr 7) and 3) / 3f * 0.6f
    }

    companion object {
        val NEUTRAL: LightingSample = LightingSample()
    }
}

/**
 * Convierte la matriz de índices en píxeles ARGB reales. Lógica PURA (sin Android): el renderer solo
 * vuelca el resultado a un Bitmap. Aplica la iluminación (brillo + tinte) y la corrupción visual.
 */
object PixelRasterizer {

    /** Con brillo 0 el personaje conserva este porcentaje de su color; con brillo 1 se ve entero. */
    const val SHADE_FLOOR = 0.62f

    /** Cuánto del tinte de la luz se aplica con brillo 1. */
    const val TINT_STRENGTH = 1f

    fun rasterize(
        data: PixelCharacterData,
        pose: PixelPose,
        flip: Boolean,
        light: LightingSample?,
        corruption: Float = 0f,
        out: IntArray? = null
    ): IntArray {
        val w = data.width
        val h = data.height
        val result = if (out != null && out.size >= w * h) out else IntArray(w * h)
        val frame = data.frame(pose)
        val pal = data.palette

        val shade = if (light == null) 1f else SHADE_FLOOR + (1f - SHADE_FLOOR) * light.brightness.coerceIn(0f, 1f)
        val tr = if (light == null) 1f else 1f + (light.tintR - 1f) * TINT_STRENGTH
        val tg = if (light == null) 1f else 1f + (light.tintG - 1f) * TINT_STRENGTH
        val tb = if (light == null) 1f else 1f + (light.tintB - 1f) * TINT_STRENGTH
        val k = (corruption * 0.85f).coerceIn(0f, 1f)

        for (y in 0 until h) {
            for (x in 0 until w) {
                val sx = if (flip) data.anchorX * 2 - x else x
                val idx = if (sx in 0 until w) frame[y * w + sx] else 0
                val c = if (idx in pal.indices) pal[idx] else 0
                val a = (c ushr 24) and 0xFF
                if (idx == PixelIndex.TRANSPARENT || a == 0) {
                    result[y * w + x] = 0
                    continue
                }
                var r = (c shr 16) and 0xFF
                var g = (c shr 8) and 0xFF
                var b = c and 0xFF
                if (k > 0f) {
                    val gray = r * 0.30f + g * 0.59f + b * 0.11f
                    r = (r + (gray - r) * k).toInt()
                    g = (g + (gray - g) * k).toInt()
                    b = (b + (gray - b) * k).toInt()
                }
                r = (r * shade * tr).toInt().coerceIn(0, 255)
                g = (g * shade * tg).toInt().coerceIn(0, 255)
                b = (b * shade * tb).toInt().coerceIn(0, 255)
                result[y * w + x] = (a shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        return result
    }

    fun hash(pixels: IntArray): Long {
        var h = 1125899906842597L
        for (v in pixels) h = 31L * h + v
        return h
    }
}
