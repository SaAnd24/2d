# Juego de Terror 2D — v0.4 — La casa

Juego de terror psicológico 2D para Android. Kotlin + Android Canvas, motor propio, 100 % offline
(sin Internet, sin backend, sin assets descargados). Resolución lógica 320×180, landscape, 16:9.

## Versión actual: v0.4.0
La escena de prueba de v0.3 se convierte en **la casa del protagonista**: un niño de 8 años en una casa
que parece normal. El mundo está dibujado a crayón; el niño es pixel art. Empiezas en tu cuarto, mamá te
llama desde otra habitación y recorres la casa observando, escuchando y examinando.
Sin monstruo, sin persecución, sin sustos: el malestar sale de la luz, la composición y los detalles.

### La casa
Un **pasillo principal** largo (960 px, `SIDE_SCROLLING`) con acceso directo a siete espacios:

| Espacio | Luz | Notas |
|---|---|---|
| `KidRoom` (inicio) | cálida | cama, juguetes, dibujos, libros, ventana, **Ranita** (peluche de rana/farmacia, solo objeto ambiental), armario |
| `Bathroom` | blanca/fría | pequeño (`FIXED`), espejo, botiquín, bañera con patito |
| `MomRoom` | tenue | cama de mamá, mesita con pastillas como props, póster de la rana, armario |
| `Laundry` | fría/artificial | estrecha (`FIXED`), lavadora, cesto, tendedero, armario |
| `Kitchen` | cálida | refri con dibujos, fregadero, estufa, mesa con tres platos |
| `Dining` | cálida apagada | mesa familiar, fotos, dibujo del niño, globo de cumpleaños |
| `Cellar` | oscuridad fuerte | cajas, mueble tapado, herramientas, muñeca vieja, armario |

Armarios (esconderse como en v0.3) en: habitación del niño, de mamá, bodega y lavandería.
Cada espacio tiene 4–11 puntos examinables con la voz de un niño de 8 años (frases breves y simples).

### Introducción
`IntroScript` (guion de escena basado en hitos `StoryFlags`): ~5 s después de empezar, mamá dice
*«Cariño, ¿puedes ayudarme?»*, luego *«Ya es hora de mis pastillas.»* y *«¿Me traes un poco de agua también?»*.
Cada línea ocurre **una sola vez**. Puedes tomar agua en la cocina (grifo) y llevársela a mamá.
No hay inventario ni puzzle: solo hitos narrativos (`StoryState`), la base sobre la que v0.5/v0.6 construirán.

### Nuevo estilo visual: crayón detallado
`draw/CrayonBuilder`: rellenos de trazos en dos pasadas con distinta presión, contornos dobles que se pasan
de las esquinas, manchas, garabatos, caritas de dibujo infantil. Todo se genera **una vez** al cargar el segmento
con `SeededRandom` (misma semilla = mismo dibujo); el renderer solo recorre las operaciones.
`BackdropBuilder` dibuja paredes (rayas, lunares, flores irregulares, azulejos, tablones) y suelos
(madera, baldosas, cemento) en tramos de 160 px; solo se pintan los visibles.
Lo "grotesco bonito" es sutil y parece accidental: un tic de más en el reloj, flores con demasiados pétalos,
un patito con sonrisa demasiado grande, una silueta borrosa en el espejo, cinco vasos iguales, tres platos,
la persona demasiado alta en la ventana del dibujo, la rana de la farmacia que siempre sonríe.

### Protagonista pixel art
`pixel/`: `PixelCharacterData` (48×64, paleta de 13 colores, matriz de índices por pose), `PixelPose`
(`IDLE`, `WALK_1..3`, y preparadas `HIDE`, `HURT`, `FLASHBACK`), `PixelRasterizer` (matriz → ARGB, lógica pura)
y `render/PlayerPixelRenderer` (bitmap cacheado por pose y luz, sin allocations por frame).
El renderer **no sabe quién es el personaje**: sirve para flashbacks, otros niños o versiones del protagonista
(`withPalette`). ~50 px visibles: la cámara cercana de v0.3 no cambia.

### La luz afecta al personaje
`world/LightField` calcula la luz que recibe un punto con las **mismas luces y la misma caída** que la máscara de
oscuridad. Esa muestra (`LightingSample`: brillo + tinte) se aplica a los píxeles del niño: se oscurece en la
sombra y se tiñe con lámparas cálidas/frías. Además lo cubre la propia máscara de oscuridad de v0.3.

### Arquitectura de render
```
GameRenderer → BaseRenderer (lienzo, tint/visualCorruption, HUD, texto)
                 └ WorldRenderer (puertas, armarios, luces, personaje)
                      └ CrayonRenderer (fondos y objetos de crayón)
PlayerPixelRenderer · LightingRenderer · máscara de oscuridad
Futuro: GraphiteRenderer · ScratchRenderer · DistortionRenderer (heredan de WorldRenderer)
```
`visualCorruption` sigue en `0.0` (`BaseRenderer.tint` ya lo respeta, también en el personaje).

### Se conserva de v0.3
Cámara cercana, movimiento lateral, `RoomSegment`, puertas y transiciones con fundido, colisiones, interacción
contextual y botón de acción genérico, texto con borde de crayón, `EventBus` (+ `ON_STORY_FLAG`), `ExamineSpot`,
`Wardrobe`, `LightSwitch`, iluminación localizada, ocultarse (HIDDEN, ojos en la rendija), `SeededRandom`
(solo para trazos y detalles, nunca posiciones, puertas, colisiones ni progreso) y separación update/render.

## Tests
`./gradlew testDebugUnitTest`: 8 espacios y conexiones con el pasillo, destinos y spawns de cada puerta,
recorrido completo de la casa, límites y colisiones, cámara cercana/FIXED/SIDE_SCROLLING, interacción,
`ExamineSpot`, `Wardrobe` en las cuatro habitaciones, intro de una sola vez, agua + mamá, matriz pixel
(misma matriz = mismo personaje, otras paletas = otro resultado), iluminación sobre el personaje,
crayón y fondos deterministas, estructura independiente de la semilla, transiciones sin romper el estado.

## Build
`.github/workflows/build.yml` (sin cambios): Actions → `assembleDebug` → artifact **JuegoTerror2D-debug-apk**
→ tests unitarios. La raíz del ZIP es la raíz del repositorio.

## Hoja de ruta (todo sobre esta misma arquitectura)
- **v0.5 — medicamentos** (cajas, reconocerlas, inventario básico)
- **v0.6 — puzzle de medicamentos**
- **v0.7 — peluche** (la ranita habla; hoy es solo un objeto)
- Todas las versiones futuras continúan sobre esta base: `StoryState`, `SceneScript`, `Interactable`,
  `PixelCharacterData` y la cadena de renderers (`visualCorruption` irá de crayón a grafito, rasguños y distorsión).
