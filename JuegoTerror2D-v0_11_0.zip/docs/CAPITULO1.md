# MYMom — Capítulo I: la casa de los dos mundos (v0.11.0)

Implementación del documento maestro sobre la base de la v0.10.1. **No se ha podido compilar ni ejecutar en este entorno**
(sin Gradle/Android SDK): compílalo y mira `docs`/consola; los errores, si los hay, serán de sintaxis/firmas.

## Qué hay
- **Casa**: `scene/ChapterHouse.kt` extiende la casa de siempre (que no se toca) hasta 20 segmentos: Pasillo = distribuidor del
  2º piso; Cocina/Comedor ampliados; nuevas: Foyer, Living, Pantry, ServiceBath, Closet, Study, Electric, Boiler, Storage,
  Foundation, Roof, Impossible. Todas (salvo Impossible) tienen versión TRAUMA con las mismas dimensiones y colisiones.
  Las conexiones nuevas son pasos del niño (`ScriptedSpot`), no puertas de la IA: la criatura sigue en la parte antigua.
- **Espejo**: el fragmento está en el baño familiar. Botón redondo arriba a la derecha (tecla M) alterna NORMAL/TRAUMA
  manteniendo la X, buscando hueco libre; no responde si la criatura está en la sala.
- **15 puzles** (`chapter/PuzzleBook.kt`) con un panel genérico (`PuzzlePanel`): toca piezas, PROBAR; pistas escalonadas; T1 y T4 con ritmo.
  Cadena: N1→lámina; N2→carta A; N3→N4→llave→N5; T1..T5; C1(N1+T1), C2(T2+T3), C3(T4), C4(carta A+B), C5(N5,T5,C1,C3,C4).
  Los CROSS se observan en un mundo y se resuelven en el otro (hito `obs_*`).
- **22 documentos** (`chapter/ChapterDocuments.kt`) con variantes TRAUMA (`_t`).
- **Micro-sustos** (`chapter/MicroScares.kt`): una vez cada uno, separados ≥5 s, sin apilar, solo síntesis (`SfxSynth`).
- **Seis estados visuales** (`render/ChapterRenderer.kt`): nivel = capturas (0→1, 1→2, ≥2→3). NORMAL: crayón / tela + papel
  desgarrado / ojos que siguen y música fuera con sollozos. TRAUMA: grafito (filtro de grises) / trazos rojos / sombras,
  muebles en el techo y bocas. Solo presentación: ninguna lógica los lee.
- **Final**: puerta principal libre tras C5 → tarjeta «Fin del capítulo I».

## Decisiones / límites
- `D01` usa `MOM_NOTE_READ` (idempotente: ya está activo tras la intro); la frase «Esta pastilla sabe feo» NO se ha añadido a la
  intro existente para no tocar su secuencia (los micro-sustos A/B/C sí cuelgan de sus eventos).
- Los puzles viven en un panel de selección, no como minijuegos físicos.
- Nada de esto se ha probado en dispositivo: ajustar posiciones de pasos/spots en `ChapterHouse.kt` si algo se solapa.
- Tests nuevos: `ChapterTest.kt` (sin ejecutar).
