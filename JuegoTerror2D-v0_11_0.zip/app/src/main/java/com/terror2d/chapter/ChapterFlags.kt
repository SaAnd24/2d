package com.terror2d.chapter

/**
 * Capítulo I (la casa de los dos mundos): todos los hitos viven en el [com.terror2d.story.StoryState] de siempre,
 * como simples nombres. NINGUNO depende del nivel visual de deterioro (regla de los seis estados).
 */
object ChapterFlags {
    const val MIRROR_FRAGMENT_OBTAINED = "mirror_fragment_obtained"
    const val MIRROR_USED = "mirror_used_once"
    const val HOUSE_EXIT_UNLOCKED = "house_exit_unlocked"
    const val CHAPTER_COMPLETE = "chapter1_complete"

    // piezas y datos que dan los puzles (no son un inventario: son hitos)
    const val GOT_BRASS = "got_brass_strip"          // N1
    const val GOT_LETTER_A = "got_letter_a"          // N2
    const val N3_PATTERN_KNOWN = "n3_pattern_known"  // N3
    const val GOT_PANEL_KEY = "got_panel_key"        // N4
    const val GOT_LETTER_B = "got_letter_b"          // estudio (TRAUMA)
    const val GOT_GLASS = "got_glass_water"          // cocina (NORMAL)
    const val GOT_WASHER = "got_washer"              // C3

    fun solved(id: String) = "puzzle_" + id + "_solved"
    fun started(id: String) = "puzzle_" + id + "_started"

    /** Dato observado en el OTRO mundo (los puzles CROSS se preparan mirando en un mundo y actuando en el otro). */
    fun observed(id: String) = "obs_" + id

    val PUZZLE_IDS: List<String> = listOf(
        "N1", "N2", "N3", "N4", "N5",
        "T1", "T2", "T3", "T4", "T5",
        "C1", "C2", "C3", "C4", "C5"
    )
}

/**
 * Nivel visual (1..3) de cada mundo. Es PURAMENTE visual: lo calcula la capa de presentación a partir de las capturas
 * del sistema de progresión ya existente ([com.terror2d.core.GameState.captureCount]); nada de la lógica lo lee.
 */
object VisualLevels {
    fun of(captureCount: Int): Int = when {
        captureCount <= 0 -> 1
        captureCount == 1 -> 2
        else -> 3
    }
}
