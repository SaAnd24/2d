package com.terror2d.chapter

/** En qué mundo se resuelve el puzle (CROSS = se prepara en uno y se resuelve en el otro). */
enum class PuzzleWorld { NORMAL, TRAUMA, CROSS }

/** Una pieza ajustable del puzle: cada toque pasa a la siguiente opción. */
class SlotDef(val label: String, val options: List<String>)

/**
 * Datos de un puzle del capítulo. Todos los puzles comparten UN mismo mecanismo (el panel de [PuzzlePanel]): lo que
 * cambia son las piezas, la solución y de dónde sale cada pista. La solución es determinista y se deduce de los
 * documentos y de los objetos examinables de la casa (nunca de adivinar al azar).
 */
class PuzzleDef(
    val id: String,
    val title: String,
    val world: PuzzleWorld,
    /** Lo que se lee al abrir el panel. */
    val intro: String,
    val slots: List<SlotDef>,
    val solution: IntArray,
    /** Hitos que hacen falta para poder resolverlo (otros puzles, objetos, observaciones). */
    val requires: List<String>,
    /** Lo que dice el niño si todavía le falta algo. */
    val lockedText: String,
    /** Pistas que se dan tras los fallos (se reparten por orden). */
    val hints: List<String>,
    val solvedText: String,
    /** Hitos que se activan al resolverlo (la lámina, la llave, la carta...). */
    val rewards: List<String> = emptyList(),
    /** T1: el ritmo de golpes del otro lado de la pared (true = golpe, false = pausa). */
    val rhythm: BooleanArray? = null,
    /** T1: longitud (1..3) de cada marca raspada, dibujada sobre su placa. */
    val marks: IntArray? = null
) {
    /** Valores iniciales: todo en la primera opción, salvo que eso ya fuese la solución (nunca nace resuelto). */
    val startValues: IntArray
        get() {
            val v = IntArray(slots.size)
            if (v.contentEquals(solution) && v.isNotEmpty()) v[0] = 1
            return v
        }

    val solvedFlag: String get() = ChapterFlags.solved(id)
}

/** Los quince puzles de la casa. */
object PuzzleBook {

    private fun s(label: String, vararg options: String) = SlotDef(label, options.toList())

    val N1 = PuzzleDef(
        id = "N1", title = "La mesa para dos", world = PuzzleWorld.NORMAL,
        intro = "La mesa está preparada para dos, pero no como en el mantel dibujado. ¿Qué va dónde?",
        slots = listOf(
            s("Taza azul", "Centro de la mesa", "Junto a la pared", "Junto a la ventana"),
            s("Plato con muesca", "Ante la silla pequeña", "Ante la silla de mamá", "Ante la silla del niño"),
            s("Silla pequeña", "Arrimada a la pared", "Junto al brazo de mamá", "Bajo la ventana")
        ),
        solution = intArrayOf(1, 1, 0),
        requires = emptyList(),
        lockedText = "",
        hints = listOf(
            "El mantel dibujado dice dónde iba la taza azul.",
            "El plato con muesca nunca iba delante de la silla pequeña. Y era de mamá.",
            "Mamá necesitaba espacio para mover el brazo."
        ),
        solvedText = "Se abre una hendidura bajo el borde de la mesa. Dentro hay una lámina de latón.",
        rewards = listOf(ChapterFlags.GOT_BRASS)
    )

    val N2 = PuzzleDef(
        id = "N2", title = "El horario que nadie escribió", world = PuzzleWorld.NORMAL,
        intro = "Tres discos con dibujos en la mesita. Hay que ponerlos en el orden en que pasaba todo.",
        slots = listOf(
            s("Primero", "El pasillo a oscuras", "La luz en la cortina", "La taza ya no está caliente", "El reloj se detiene"),
            s("Después", "El pasillo a oscuras", "La luz en la cortina", "La taza ya no está caliente", "El reloj se detiene"),
            s("Al final", "El pasillo a oscuras", "La luz en la cortina", "La taza ya no está caliente", "El reloj se detiene")
        ),
        solution = intArrayOf(1, 2, 0),
        requires = emptyList(),
        lockedText = "",
        hints = listOf(
            "Mi horario empieza con la luz llegando a la cortina.",
            "Después la taza deja de estar caliente. El reloj no cuenta.",
            "Al final, el pasillo vuelve a quedarse oscuro."
        ),
        solvedText = "El cajón se abre con un sonido suave. Hay un trozo de papel arrugado que parece llevar mucho tiempo ahí.",
        rewards = listOf(ChapterFlags.GOT_LETTER_A)
    )

    val N3 = PuzzleDef(
        id = "N3", title = "Los cuatro dibujos", world = PuzzleWorld.NORMAL,
        intro = "Cuatro dibujos de mi cuarto. No sé cuál hice primero. Las sombras sí lo saben.",
        slots = listOf(
            s("1º", "Dibujo A", "Dibujo B", "Dibujo C", "Dibujo D"),
            s("2º", "Dibujo A", "Dibujo B", "Dibujo C", "Dibujo D"),
            s("3º", "Dibujo A", "Dibujo B", "Dibujo C", "Dibujo D"),
            s("4º", "Dibujo A", "Dibujo B", "Dibujo C", "Dibujo D")
        ),
        solution = intArrayOf(1, 0, 2, 3),
        requires = emptyList(),
        lockedText = "",
        hints = listOf(
            "La sombra de la ventana va creciendo de un dibujo al siguiente.",
            "La sombra más corta apenas sale de la ventana: la de la taza junto a la cama.",
            "Después cruza media alfombra, luego llega al armario, y al final se come todo el cuarto."
        ),
        solvedText = "Los bordes de las hojas forman un dibujo: inclinado a la izquierda, recto, muy inclinado a la izquierda, inclinado a la derecha.",
        rewards = listOf(ChapterFlags.N3_PATTERN_KNOWN)
    )

    val N4 = PuzzleDef(
        id = "N4", title = "Los retratos torcidos", world = PuzzleWorld.NORMAL,
        intro = "Cuatro marcos torcidos. Detrás de cada uno hay una marca. Las sombras tienen que coincidir con las líneas del papel pintado.",
        slots = listOf(
            s("Marco 1", "Muy a la izquierda", "A la izquierda", "A la derecha", "Recto"),
            s("Marco 2", "Muy a la izquierda", "A la izquierda", "A la derecha", "Recto"),
            s("Marco 3", "Muy a la izquierda", "A la izquierda", "A la derecha", "Recto"),
            s("Marco 4", "Muy a la izquierda", "A la izquierda", "A la derecha", "Recto")
        ),
        solution = intArrayOf(1, 3, 0, 2),
        requires = listOf(ChapterFlags.solved("N3")),
        lockedText = "No sé cómo ponerlos. Los dibujos de mi cuarto tenían un patrón en los bordes.",
        hints = listOf(
            "Dos líneas se acercan, pero todavía no se alinean.",
            "El patrón de los bordes de mis dibujos va de izquierda a derecha, un marco por cada borde.",
            "Hay que seguir la marca pequeña de atrás, no el clavo."
        ),
        solvedText = "Una sección del revestimiento se desplaza y deja ver la llave del panel eléctrico.",
        rewards = listOf(ChapterFlags.GOT_PANEL_KEY)
    )

    val N5 = PuzzleDef(
        id = "N5", title = "El cuadro eléctrico", world = PuzzleWorld.NORMAL,
        intro = "Cuatro interruptores sin nombre. Hay que accionarlos en el orden en que las luces de la casa se estabilizan.",
        slots = listOf(
            s("1º", "Cocina", "Sótano", "Vestíbulo", "Pasillo"),
            s("2º", "Cocina", "Sótano", "Vestíbulo", "Pasillo"),
            s("3º", "Cocina", "Sótano", "Vestíbulo", "Pasillo"),
            s("4º", "Cocina", "Sótano", "Vestíbulo", "Pasillo")
        ),
        solution = intArrayOf(2, 0, 3, 1),
        requires = listOf(ChapterFlags.solved("N4")),
        lockedText = "El panel está cerrado. Me falta la llave.",
        hints = listOf(
            "La nota del electricista dice que hay que mirar las luces antes de tocar nada.",
            "La del vestíbulo zumba siempre igual. La de la cocina tarda en estabilizarse.",
            "La del pasillo cambia pasado un rato. La del sótano es la última."
        ),
        solvedText = "Un zumbido se afina. La luz fija del vestíbulo queda estable.",
        rewards = emptyList()
    )

    val T1 = PuzzleDef(
        id = "T1", title = "Las siete marcas", world = PuzzleWorld.TRAUMA,
        intro = "Siete marcas raspadas y siete placas hundidas. Los golpes salen del otro lado de la pared.",
        slots = List(7) { i -> s("Placa " + (i + 1), "Silencio", "Golpe") },
        solution = intArrayOf(1, 0, 1, 0, 1, 1, 0),
        requires = emptyList(),
        lockedText = "",
        hints = listOf(
            "No cuentes lo que escuchas. Escucha lo que falta.",
            "Las marcas largas son golpes. Las cortas son esperas.",
            "Pulsa ESCUCHAR y compara el ritmo con las placas."
        ),
        solvedText = "Se abre una pequeña cavidad en la pared. Ahí se ve el lado oculto del muro: tres puntos alineados.",
        rewards = emptyList(),
        rhythm = booleanArrayOf(true, false, true, false, true, true, false),
        marks = intArrayOf(3, 1, 3, 1, 3, 3, 1)
    )

    val T2 = PuzzleDef(
        id = "T2", title = "El retrato sin rostro", world = PuzzleWorld.TRAUMA,
        intro = "Cuatro piezas de madera sobre la cómoda. El retrato tiene cuatro huecos blancos.",
        slots = listOf(
            s("Hueco 1 (tiene una esquina)", "Pieza redonda", "Pieza alargada", "Pieza en L", "Pieza en cruz"),
            s("Hueco 2 (cuatro brazos)", "Pieza redonda", "Pieza alargada", "Pieza en L", "Pieza en cruz"),
            s("Hueco 3 (borde curvo)", "Pieza redonda", "Pieza alargada", "Pieza en L", "Pieza en cruz"),
            s("Hueco 4 (largo y delgado)", "Pieza redonda", "Pieza alargada", "Pieza en L", "Pieza en cruz")
        ),
        solution = intArrayOf(2, 3, 0, 1),
        requires = emptyList(),
        lockedText = "",
        hints = listOf(
            "Si tapas lo que falta, todavía puedes reconocer el borde.",
            "Cada pieza comparte un borde con un hueco. Mira solo el borde.",
            "El hueco curvo pide la pieza redonda."
        ),
        solvedText = "Las piezas forman un símbolo: tres líneas y un punto. Es el mismo que hay junto a la puerta del estudio.",
        rewards = emptyList()
    )

    val T3 = PuzzleDef(
        id = "T3", title = "El pasillo que no cabe", world = PuzzleWorld.TRAUMA,
        intro = "Tres puertas que no están donde las recuerdo. Si me equivoco, vuelvo al distribuidor. Hay que seguir la grieta.",
        slots = listOf(
            s("Primera puerta", "La de la izquierda", "La del medio", "La de la derecha"),
            s("Segunda puerta", "La de la izquierda", "La del medio", "La de la derecha"),
            s("Tercera puerta", "La de la izquierda", "La del medio", "La de la derecha")
        ),
        solution = intArrayOf(1, 0, 2),
        requires = listOf(ChapterFlags.observed("T3")),
        lockedText = "Las puertas cambian de sitio. Antes tengo que mirar bien las grietas de las paredes.",
        hints = listOf(
            "No sigas las puertas. Sigue la marca que no cambia.",
            "La grieta baja por el medio...",
            "...se desvía a la izquierda y termina a la derecha."
        ),
        solvedText = "La puerta correcta da al reverso del estudio. Desde ahí se ve una parte de la cerradura que nunca se ve desde el otro lado.",
        rewards = emptyList()
    )

    val T4 = PuzzleDef(
        id = "T4", title = "La caldera que respira", world = PuzzleWorld.TRAUMA,
        intro = "Cuatro válvulas con ritmos distintos y cuatro dibujos al lado. No hay que ajustarlas todas a la vez.",
        slots = listOf(
            s("Válvula 1", "Callada", "Continua", "Dos golpes y espera", "Ciclo incompleto"),
            s("Válvula 2", "Callada", "Continua", "Dos golpes y espera", "Ciclo incompleto"),
            s("Válvula 3", "Callada", "Continua", "Dos golpes y espera", "Ciclo incompleto"),
            s("Válvula 4", "Callada", "Continua", "Dos golpes y espera", "Ciclo incompleto")
        ),
        solution = intArrayOf(2, 3, 1, 0),
        requires = emptyList(),
        lockedText = "",
        hints = listOf(
            "La presión no es constante. Mira cada válvula por separado.",
            "Una golpea dos veces y espera. Otra no completa el ciclo.",
            "La tubería más cercana a la pared deja de sonar antes que las demás."
        ),
        solvedText = "Un ruido profundo recorre las tuberías. El agua del pasadizo baja y el paso bajo los cimientos queda abierto.",
        rewards = emptyList()
    )

    val T5 = PuzzleDef(
        id = "T5", title = "La antena de la azotea", world = PuzzleWorld.TRAUMA,
        intro = "La antena tiene tres brazos. Lejos hay una ventana iluminada, una torre oscura y una línea quebrada.",
        slots = listOf(
            s("Brazo corto", "Ventana iluminada", "Torre oscura", "Línea quebrada", "Edificio cercano"),
            s("Brazo medio", "Ventana iluminada", "Torre oscura", "Línea quebrada", "Edificio cercano"),
            s("Brazo largo", "Ventana iluminada", "Torre oscura", "Línea quebrada", "Edificio cercano")
        ),
        solution = intArrayOf(0, 2, 1),
        requires = emptyList(),
        lockedText = "",
        hints = listOf(
            "La antena se orienta por la forma que comparte con el dibujo, no por la distancia.",
            "El brazo más corto no apunta al edificio más cercano.",
            "La sombra más larga tampoco apunta al horizonte."
        ),
        solvedText = "La antena queda fija y proyecta una sombra larga y estrecha sobre la azotea.",
        rewards = emptyList()
    )

    val C1 = PuzzleDef(
        id = "C1", title = "La puerta detrás de la pared", world = PuzzleWorld.CROSS,
        intro = "Tres puntos de la pared. Con la lámina de latón puedo probar cada junta, en el orden correcto.",
        slots = listOf(
            s("Primer punto", "Alto", "Medio", "Bajo", "Esquina"),
            s("Segundo punto", "Alto", "Medio", "Bajo", "Esquina"),
            s("Tercer punto", "Alto", "Medio", "Bajo", "Esquina")
        ),
        solution = intArrayOf(0, 2, 1),
        requires = listOf(ChapterFlags.GOT_BRASS, ChapterFlags.solved("T1"), ChapterFlags.observed("C1")),
        lockedText = "Necesito algo fino para probar la junta, saber dónde mirar, y comparar la pared en el otro mundo.",
        hints = listOf(
            "Las grietas de aquí coinciden con las hendiduras del otro mundo.",
            "De izquierda a derecha: una alta, una baja y una a media altura.",
            "El primer punto cede; el segundo suena; el tercero suelta el mecanismo."
        ),
        solvedText = "Se oye un mecanismo antiguo. La pared se abre lo bastante para pasar entre la sala y la despensa.",
        rewards = emptyList()
    )

    val C2 = PuzzleDef(
        id = "C2", title = "Las huellas que retroceden", world = PuzzleWorld.CROSS,
        intro = "Las huellas terminan frente a la caja. Hay que moverla y orientar bien la marca del retrato.",
        slots = listOf(
            s("Empujar la caja", "Hacia la izquierda", "Hacia la derecha", "Hacia el fondo"),
            s("Marca del retrato", "Vertical", "Horizontal", "Girada")
        ),
        solution = intArrayOf(1, 2),
        requires = listOf(ChapterFlags.solved("T2"), ChapterFlags.solved("T3"), ChapterFlags.observed("C2")),
        lockedText = "No entiendo estas huellas. Necesito el símbolo del retrato, la regla de las grietas y mirarlas en el otro mundo.",
        hints = listOf(
            "Las huellas del otro mundo entran en la pared por la derecha.",
            "Empiezan donde nadie quiere mirar.",
            "El símbolo del retrato estaba girado, igual que la marca de la puerta del estudio."
        ),
        solvedText = "Detrás de la caja aparece un pestillo pequeño. Se abre una puerta secundaria hacia la parte de atrás del estudio.",
        rewards = emptyList()
    )

    val C3 = PuzzleDef(
        id = "C3", title = "El vaso de agua", world = PuzzleWorld.CROSS,
        intro = "El reflejo me dijo hacia dónde mirar. Ahora hay que encontrar el panel exacto.",
        slots = listOf(
            s("Pared", "Izquierda", "Fondo", "Derecha"),
            s("Panel nº", "Primero", "Segundo", "Tercero", "Cuarto")
        ),
        solution = intArrayOf(1, 2),
        requires = listOf(ChapterFlags.solved("T4"), ChapterFlags.GOT_GLASS, ChapterFlags.observed("C3")),
        lockedText = "Necesito el vaso con agua, saber hacia dónde apunta su reflejo en el otro mundo, y que el pasadizo esté abierto.",
        hints = listOf(
            "El agua quieta refleja la lámpara. En el otro mundo ese reflejo se vuelve una figura que señala.",
            "La figura apuntaba al fondo del pasadizo.",
            "Contando desde la izquierda, el tercer panel."
        ),
        solvedText = "Detrás del panel hay una cavidad. Dentro, una arandela metálica que puede encajar en la base de la antena.",
        rewards = listOf(ChapterFlags.GOT_WASHER)
    )

    val C4 = PuzzleDef(
        id = "C4", title = "La carta partida", world = PuzzleWorld.CROSS,
        intro = "Dos mitades de la carta. Los trazos del margen forman una secuencia. ¿En qué orden van las tres señales?",
        slots = listOf(
            s("Primera señal", "Ventana iluminada", "Torre oscura", "Línea quebrada", "Un punto"),
            s("Segunda señal", "Ventana iluminada", "Torre oscura", "Línea quebrada", "Un punto"),
            s("Tercera señal", "Ventana iluminada", "Torre oscura", "Línea quebrada", "Un punto")
        ),
        solution = intArrayOf(2, 0, 1),
        requires = listOf(ChapterFlags.GOT_LETTER_A, ChapterFlags.GOT_LETTER_B),
        lockedText = "Solo tengo una mitad de la carta. Me falta la otra.",
        hints = listOf(
            "Los trazos del margen también están en la ilustración de la antena.",
            "El margen empieza con un zigzag.",
            "Después un rectángulo, y al final una línea alta."
        ),
        solvedText = "Al unir las mitades se lee: «Mira desde donde la casa no debería tener ventanas».",
        rewards = emptyList()
    )

    val C5 = PuzzleDef(
        id = "C5", title = "El reflejo que no pertenece a la casa", world = PuzzleWorld.CROSS,
        intro = "La arandela encaja en la base. Hay que alinear las tres señales de la carta, en su orden.",
        slots = listOf(
            s("Primera señal", "Línea de luz del vestíbulo", "Reflejo del espejo", "Sombra de la antena", "Grieta de la pared"),
            s("Segunda señal", "Línea de luz del vestíbulo", "Reflejo del espejo", "Sombra de la antena", "Grieta de la pared"),
            s("Tercera señal", "Línea de luz del vestíbulo", "Reflejo del espejo", "Sombra de la antena", "Grieta de la pared")
        ),
        solution = intArrayOf(2, 0, 1),
        requires = listOf(
            ChapterFlags.solved("N5"), ChapterFlags.solved("T5"), ChapterFlags.solved("C1"),
            ChapterFlags.GOT_WASHER, ChapterFlags.solved("C4"), ChapterFlags.observed("C5")
        ),
        lockedText = "Todavía me falta algo: la luz del sótano, la antena, la pared, la arandela, la carta y mirar la luz desde el otro mundo.",
        hints = listOf(
            "El mecanismo no reacciona si solo giro los brazos hacia las figuras. Primero hay que alinear las sombras.",
            "La antena marca el camino, la luz de la casa lo confirma...",
            "...y el espejo es lo último que se alinea."
        ),
        solvedText = "El reflejo del espejo se oscurece un instante. Se oye un golpe sordo dentro de la casa.",
        rewards = listOf(ChapterFlags.HOUSE_EXIT_UNLOCKED)
    )

    val ALL: List<PuzzleDef> = listOf(N1, N2, N3, N4, N5, T1, T2, T3, T4, T5, C1, C2, C3, C4, C5)

    fun get(id: String): PuzzleDef? = ALL.firstOrNull { it.id == id }
}
