package com.terror2d.scene

import com.terror2d.chapter.ChapterDocuments
import com.terror2d.chapter.ChapterFlags
import com.terror2d.core.CameraMode
import com.terror2d.core.WorldMode
import com.terror2d.events.EventType
import com.terror2d.interaction.InteractionContext
import com.terror2d.interaction.InteractionIcon
import com.terror2d.interaction.InteractionResult
import com.terror2d.render.Palette
import com.terror2d.story.StoryFlags
import com.terror2d.ui.DialogueLine
import com.terror2d.world.DarkZone
import com.terror2d.world.Door
import com.terror2d.world.DoorTarget
import com.terror2d.world.ExamineSpot
import com.terror2d.world.HouseProps
import com.terror2d.world.Lamp
import com.terror2d.world.Prop
import com.terror2d.world.ScriptedSpot
import com.terror2d.world.StoryGate
import com.terror2d.world.WorldObject

/**
 * CAPÍTULO I — «La casa de los dos mundos». Extiende la casa de siempre ([HouseDefinition]) SIN tocarla:
 *  - el Pasillo hace de distribuidor del segundo piso; Cocina y Comedor se amplían hacia la planta baja;
 *  - nacen 12 estancias: Foyer (vestíbulo), Living (sala), Pantry (despensa), ServiceBath, Closet (armario de
 *    almacenaje), Study (estudio), Electric, Boiler, Storage, Foundation (espacio bajo los cimientos), Roof (azotea)
 *    e Impossible (la estancia imposible);
 *  - cada estancia tiene su versión TRAUMA (mismas dimensiones y mismo recorrido; solo cambian el aspecto y los
 *    objetos propios de ese mundo).
 * Las conexiones nuevas son pasos del niño ([ScriptedSpot]), no puertas de la IA: la criatura sigue patrullando la
 * parte antigua de la casa y las estancias nuevas son suyas de recorrer en calma.
 */
object ChapterHouse {

    const val FOYER = "Foyer"
    const val LIVING = "Living"
    const val PANTRY = "Pantry"
    const val SERVICE_BATH = "ServiceBath"
    const val STUDY = "Study"
    const val CLOSET = "Closet"
    const val ELECTRIC = "Electric"
    const val BOILER = "Boiler"
    const val STORAGE = "Storage"
    const val FOUNDATION = "Foundation"
    const val ROOF = "Roof"
    const val IMPOSSIBLE = "Impossible"

    val NEW_ROOMS = listOf(FOYER, LIVING, PANTRY, SERVICE_BATH, STUDY, CLOSET, ELECTRIC, BOILER, STORAGE, FOUNDATION, ROOF, IMPOSSIBLE)

    private const val F = 146f
    private const val WALL = 12f
    private val WARM = Palette.LIGHT_WARM or 0xFF000000.toInt()
    private val COLD = Palette.LIGHT_COLD or 0xFF000000.toInt()
    private val PALE = Palette.LIGHT_PALE or 0xFF000000.toInt()

    // ------------------------------------------------------------------ ayudas de objetos

    private val ready: (InteractionContext) -> Boolean = { it.hasFlag(StoryFlags.SURVIVAL_READY) }

    private fun sp(
        id: String, x: Float, w: Float, prompt: String, icon: InteractionIcon,
        enabled: ((InteractionContext) -> Boolean)? = null,
        action: (InteractionContext) -> InteractionResult
    ): ScriptedSpot = ScriptedSpot(id, x, F - 70f, w, 70f, prompt, icon, 6f, null, null, enabled, action)

    private fun ex(id: String, x: Float, w: Float, text: String) = ExamineSpot(id, x, F - 70f, w, 70f, text, 6f)

    private fun doc(id: String, base: String, x: Float, w: Float) =
        sp(id, x, w, "LEER", InteractionIcon.EXAMINE, ready) { ctx ->
            InteractionResult.document(ChapterDocuments.idFor(base, ctx.state.worldMode))
        }

    private fun puzzle(id: String, pid: String, x: Float, w: Float, prompt: String = "EXAMINAR") =
        sp(id, x, w, prompt, InteractionIcon.USE, ready) { InteractionResult.panel(pid) }

    /** Dato que se observa en un mundo y se usa en el otro. */
    private fun observe(id: String, obsId: String, x: Float, w: Float, text: String, needs: String? = null, missing: String = "") =
        sp(id, x, w, "OBSERVAR", InteractionIcon.EXAMINE, ready) { ctx ->
            if (needs != null && !ctx.hasFlag(needs)) InteractionResult.message(missing)
            else {
                ctx.setFlag(ChapterFlags.observed(obsId))
                InteractionResult.message(text)
            }
        }

    /** Un paso entre estancias (escalera, puerta, trampilla...). */
    private fun passage(
        id: String, x: Float, label: String, seg: String, spawn: String,
        enabled: ((InteractionContext) -> Boolean)? = null
    ): ScriptedSpot = ScriptedSpot(id, x, F - 70f, 34f, 70f, label, InteractionIcon.DOOR, 6f, null, null, enabled) { ctx ->
        ctx.post(EventType.ON_DOOR_OPEN, id)
        InteractionResult.transition(DoorTarget(seg, spawn))
    }

    private fun box(x: Float, w: Float, h: Float, fill: Int, hatch: Int): WorldObject = Prop(x, F - h, w, h, fill, hatch)

    private fun wallPlate(x: Float, y: Float, w: Float, h: Float, fill: Int, hatch: Int): WorldObject = Prop(x, y, w, h, fill, hatch).also { it.layer = com.terror2d.world.Layer.DECOR }

    private fun doorArt(x: Float, fill: Int, w: Float = 34f, h: Float = 72f): WorldObject =
        Prop(x, F - h, w, h, fill, 0xCC000000.toInt() or ((fill and 0xFEFEFE) shr 1))

    /** Muestra [o] solo mientras se cumple [flag]. */
    private fun whenFlag(flag: String, o: WorldObject): WorldObject = StoryGate(o) { st -> st.has(flag) }

    private fun lamp(x: Float, cord: Float = 38f, radius: Float = 120f, intensity: Float = 0.9f, color: Int = WARM, flicker: Float = 0f) =
        Lamp(x, cord, radius, intensity, color, flicker)

    private fun sd(vararg lines: String): List<DialogueLine> = lines.map { DialogueLine(null, it) }

    // ------------------------------------------------------------------ colores

    private fun gray(c: Int): Int {
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        val l = ((r * 0.30f + g * 0.59f + b * 0.11f) * 0.92f).toInt().coerceIn(0, 255)
        return (0xFF shl 24) or (l shl 16) or (l shl 8) or l
    }

    private class Mood(
        val wall: Int, val wallStroke: Int, val floor: Int, val floorStroke: Int,
        val wallPat: WallPattern, val floorPat: FloorPattern, val dark: Float, val darkColor: Int,
        val wallAccent: Int = 0xFFFFFFFF.toInt(), val floorAccent: Int = 0xFF000000.toInt()
    )

    private class Built(val normal: RoomSegment, val trauma: RoomSegment?)

    private fun cracks(width: Float): List<WorldObject> {
        val out = ArrayList<WorldObject>()
        val dark = 0xFF2A2A2A.toInt()
        for (k in 0 until 3) {
            val x = width * (0.22f + 0.30f * k)
            out.add(Prop(x, 6f, 2f, 60f + 14f * k, dark, dark).also { it.layer = com.terror2d.world.Layer.DECOR })
        }
        return out
    }

    private fun seg(
        id: String, width: Float, camera: CameraMode, m: Mood, trauma: Boolean,
        objects: List<WorldObject>, doors: List<Door>, spawns: Map<String, SpawnPoint>, darkZones: List<DarkZone>
    ): RoomSegment {
        val lights = objects.filterIsInstance<Lamp>().map { it.light }
        return RoomSegment(
            id = id, width = width, floorY = F,
            leftBoundary = WALL, rightBoundary = width - WALL, cameraMode = camera,
            objects = objects, doors = doors, spawnPoints = spawns,
            lights = lights, darkZones = darkZones,
            ambientDark = if (trauma) (m.dark + 0.05f).coerceAtMost(0.97f) else m.dark,
            ambientColor = m.darkColor,
            wallColor = if (trauma) gray(m.wall) else m.wall,
            wallStrokeColor = if (trauma) gray(m.wallStroke) else m.wallStroke,
            floorColor = if (trauma) gray(m.floor) else m.floor,
            floorStrokeColor = if (trauma) gray(m.floorStroke) else m.floorStroke,
            wallPattern = m.wallPat, wallAccent = if (trauma) gray(m.wallAccent) else m.wallAccent,
            floorPattern = m.floorPat, floorAccent = if (trauma) gray(m.floorAccent) else m.floorAccent,
            worldMode = if (trauma) WorldMode.TRAUMA else WorldMode.NORMAL
        )
    }

    /** Estancia nueva: objetos compartidos + los propios de cada mundo. */
    private fun room(
        id: String, width: Float, camera: CameraMode, m: Mood, spawns: Map<String, SpawnPoint>,
        shared: List<WorldObject>, onlyNormal: List<WorldObject> = emptyList(), onlyTrauma: List<WorldObject> = emptyList(),
        hasTrauma: Boolean = true
    ): Built {
        val dz = listOf(DarkZone(width - 50f, 0f, 38f, F, 0.3f))
        val n = seg(id, width, camera, m, false, shared + onlyNormal, emptyList(), spawns, dz)
        val t = if (hasTrauma) seg(id, width, camera, m, true, shared + onlyTrauma + cracks(width), emptyList(), spawns, dz) else null
        return Built(n, t)
    }

    /** Copia de un segmento de siempre con más objetos / más ancho; y su versión TRAUMA. */
    private fun extend(
        base: RoomSegment, newWidth: Float, remove: Set<String>, shared: List<WorldObject>,
        onlyNormal: List<WorldObject>, onlyTrauma: List<WorldObject>, addSpawns: Map<String, SpawnPoint>
    ): Built {
        val baseObjs = base.objects.filterNot { it is ExamineSpot && remove.contains(it.id) }
        val spawns = HashMap<String, SpawnPoint>(base.spawnPoints)
        spawns.putAll(addSpawns)
        fun make(trauma: Boolean, extra: List<WorldObject>) = RoomSegment(
            id = base.id, width = newWidth, floorY = base.floorY, height = base.height,
            leftBoundary = base.leftBoundary, rightBoundary = if (newWidth != base.width) newWidth - WALL else base.rightBoundary,
            cameraMode = base.cameraMode, objects = baseObjs + shared + extra, doors = base.doors, spawnPoints = spawns,
            lights = base.lights, darkZones = base.darkZones,
            ambientDark = if (trauma) (base.ambientDark + 0.05f).coerceAtMost(0.97f) else base.ambientDark,
            ambientColor = base.ambientColor,
            wallColor = if (trauma) gray(base.wallColor) else base.wallColor,
            wallStrokeColor = if (trauma) gray(base.wallStrokeColor) else base.wallStrokeColor,
            floorColor = if (trauma) gray(base.floorColor) else base.floorColor,
            floorStrokeColor = if (trauma) gray(base.floorStrokeColor) else base.floorStrokeColor,
            wallPattern = base.wallPattern, wallAccent = if (trauma) gray(base.wallAccent) else base.wallAccent,
            floorPattern = base.floorPattern, floorAccent = if (trauma) gray(base.floorAccent) else base.floorAccent,
            worldMode = if (trauma) WorldMode.TRAUMA else WorldMode.NORMAL
        )
        return Built(make(false, onlyNormal), make(true, onlyTrauma + cracks(newWidth)))
    }

    // ------------------------------------------------------------------ la casa completa

    fun create(seed: Long = HouseDefinition.DEFAULT_SEED): SceneDefinition {
        val base = HouseDefinition.create(seed)
        val byId = base.segments.associateBy { it.id }
        fun b(id: String) = byId[id] ?: throw IllegalStateException("Falta el segmento $id")

        val built = ArrayList<Built>()
        built.add(hall(b(HouseDefinition.HALL)))
        built.add(kid(b(HouseDefinition.KID)))
        built.add(bath(b(HouseDefinition.BATH)))
        built.add(mom(b(HouseDefinition.MOM)))
        built.add(extend(b(HouseDefinition.LAUNDRY), b(HouseDefinition.LAUNDRY).width, emptySet(), emptyList(), emptyList(), emptyList(), emptyMap()))
        built.add(kitchen(b(HouseDefinition.KITCHEN)))
        built.add(dining(b(HouseDefinition.DINING)))
        built.add(cellar(b(HouseDefinition.CELLAR)))
        built.add(foyer()); built.add(living()); built.add(pantry()); built.add(serviceBath())
        built.add(closet()); built.add(study()); built.add(electric()); built.add(boiler())
        built.add(storage()); built.add(foundation()); built.add(roof()); built.add(impossible())

        val normals = built.map { it.normal }
        val traumas = built.mapNotNull { it.trauma }
        return SceneDefinition(
            id = base.id, seed = base.seed, segments = normals,
            startSegmentId = base.startSegmentId, startSpawnId = base.startSpawnId,
            triggers = base.triggers, scripts = base.scripts, traumaSegments = traumas,
            conversations = base.conversations, creature = base.creature, pointsOfInterest = base.pointsOfInterest
        )
    }

    // ------------------------------------------------------------------ segundo piso (existente)

    private fun hall(s: RoomSegment): Built {
        val shared = ArrayList<WorldObject>()
        // pasos del niño (NO puertas de la criatura): estudio cerrado, armario, escalera a la planta baja, azotea
        shared.add(doorArt(265f, 0xFF8A6A4A.toInt()))
        shared.add(sp("hall_study_door", 265f, 34f, "PUERTA", InteractionIcon.DOOR, ready) { ctx ->
            InteractionResult.message(
                if (ctx.state.worldMode == WorldMode.TRAUMA) "Aquí la cerradura ni siquiera está en la puerta. Una línea de grietas se va por otro lado."
                else "La puerta del estudio está cerrada con llave."
            )
        })
        shared.add(doorArt(525f, 0xFF7A8A6A.toInt()))
        shared.add(passage("hall_to_closet", 525f, "ARMARIO", CLOSET, "from_hall", ready))
        shared.add(doorArt(655f, 0xFF5A4A3A.toInt()))
        shared.add(passage("hall_to_stairs", 655f, "ESCALERAS", FOYER, "from_stairs", ready))
        shared.add(doorArt(914f, 0xFF4A5A6A.toInt(), 32f))
        shared.add(passage("hall_to_roof", 914f, "A LA AZOTEA", ROOF, "from_hall", ready))
        shared.add(doc("doc_d05", "d05", 806f, 24f))
        val normal = ArrayList<WorldObject>()
        normal.add(puzzle("spot_N4", "N4", 776f, 30f, "ALINEAR"))
        val trauma = ArrayList<WorldObject>()
        trauma.add(puzzle("spot_T3", "T3", 150f, 70f, "SEGUIR LA GRIETA"))
        trauma.add(observe("obs_T3", "T3", 300f, 40f,
            "Las puertas cambian de sitio, pero una grieta sigue siendo la misma: baja por el medio, se desvía a la izquierda y termina a la derecha."))
        trauma.add(doc("doc_d09", "d09", 240f, 24f))
        val spawns = mapOf("from_stairs" to SpawnPoint(712f, 1), "from_closet" to SpawnPoint(580f, 1), "from_roof" to SpawnPoint(880f, -1))
        return extend(s, s.width, emptySet(), shared, normal, trauma, spawns)
    }

    private fun kid(s: RoomSegment): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(doc("doc_d01", "d01", 196f, 22f))
        shared.add(doc("doc_d19", "d19", 300f, 18f))
        val normal = ArrayList<WorldObject>()
        normal.add(doc("doc_d04", "d04", 100f, 28f))
        normal.add(ex("ex_kid_shadows", 132f, 28f,
            "A: la sombra cruza media alfombra. B: apenas sale de la ventana. C: llega hasta el armario. D: se come todo el cuarto."))
        normal.add(sp("spot_N3", 330f, 40f, "ORDENAR", InteractionIcon.USE, ready) { ctx ->
            if (ctx.hasFlag(ChapterFlags.solved("N3"))) {
                InteractionResult.message("Los bordes de las hojas: inclinado a la izquierda, recto, muy inclinado a la izquierda, inclinado a la derecha.")
            } else InteractionResult.panel("N3")
        })
        normal.add(doc("doc_d16", "d16", 262f, 20f))
        val trauma = ArrayList<WorldObject>()
        trauma.add(doc("doc_d04t", "d04", 100f, 28f))
        return extend(s, s.width, emptySet(), shared, normal, trauma, emptyMap())
    }

    private fun bath(s: RoomSegment): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(sp("spot_mirror_fragment", 98f, 40f, "EXAMINAR", InteractionIcon.EXAMINE, null) { ctx ->
            if (!ctx.hasFlag(StoryFlags.SURVIVAL_READY)) InteractionResult.message("No me gusta ese espejo.")
            else if (!ctx.hasFlag(ChapterFlags.MIRROR_FRAGMENT_OBTAINED)) {
                ctx.setFlag(ChapterFlags.MIRROR_FRAGMENT_OBTAINED)
                InteractionResult.message("El espejo mostró un pasillo que no es este. Me llevo un trocito. Con él puedo cambiar de mundo (botón del espejo).")
            } else InteractionResult.message("Mi reflejo termina el gesto un poquito tarde.")
        })
        return extend(s, s.width, setOf("ex_bath_mirror"), shared, emptyList(), emptyList(), emptyMap())
    }

    private fun mom(s: RoomSegment): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(doc("doc_d17", "d17", 322f, 30f))
        shared.add(doc("doc_d20", "d20", 130f, 20f))
        shared.add(doc("doc_d22", "d22", 250f, 18f))
        val normal = ArrayList<WorldObject>()
        normal.add(sp("spot_N2", 76f, 50f, "DISCOS", InteractionIcon.USE, ready) { ctx ->
            if (ctx.hasFlag(ChapterFlags.solved("N2"))) InteractionResult.document("d14a") else InteractionResult.panel("N2")
        })
        val trauma = ArrayList<WorldObject>()
        trauma.add(puzzle("spot_T2", "T2", 206f, 48f, "PIEZAS"))
        trauma.add(doc("doc_d08", "d08", 176f, 24f))
        trauma.add(ex("ex_mom_portrait_gaps", 280f, 24f,
            "Los huecos del retrato: uno con una esquina, uno con cuatro brazos, uno de borde curvo y uno largo y delgado."))
        return extend(s, s.width, emptySet(), shared, normal, trauma, emptyMap())
    }

    // ------------------------------------------------------------------ planta baja

    private fun kitchen(s: RoomSegment): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(doorArt(452f, 0xFF8A7A5A.toInt()))
        shared.add(passage("kitchen_to_pantry", 452f, "DESPENSA", PANTRY, "from_kitchen", ready))
        shared.add(ex("ex_kitchen_cup", 312f, 22f, "La taza azul tiene una marca en el borde. Alguien bebió de ahí."))
        shared.add(doc("doc_d15", "d15", 410f, 22f))
        shared.add(doc("doc_d18", "d18", 62f, 14f))
        shared.add(doc("doc_d03", "d03", 258f, 20f))
        shared.add(sp("spot_glass", 200f, 22f, "TOMAR VASO", InteractionIcon.PICK, ready) { ctx ->
            if (ctx.hasFlag(ChapterFlags.GOT_GLASS)) InteractionResult.message("Ya miré el techo dentro del vaso.")
            else {
                ctx.setFlag(ChapterFlags.GOT_GLASS)
                InteractionResult.document("d13")
            }
        })
        return extend(s, 520f, emptySet(), shared, emptyList(), emptyList(), mapOf("from_pantry" to SpawnPoint(420f, 1)))
    }

    private fun dining(s: RoomSegment): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(doorArt(452f, 0xFF9A6A5A.toInt()))
        shared.add(passage("dining_to_living", 452f, "SALA", LIVING, "from_dining", ready))
        val normal = ArrayList<WorldObject>()
        normal.add(doc("doc_d02", "d02", 128f, 24f))
        normal.add(puzzle("spot_N1", "N1", 176f, 24f, "ARREGLAR MESA"))
        normal.add(ex("ex_dining_plate", 222f, 24f, "Mi plato es liso. El que tiene una muesca es el de mamá."))
        return extend(s, 520f, emptySet(), shared, normal, emptyList(), mapOf("from_living" to SpawnPoint(420f, 1)))
    }

    private fun cellar(s: RoomSegment): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(doorArt(430f, 0xFF5A5A6A.toInt()))
        shared.add(passage("cellar_to_electric", 430f, "CUARTO ELÉCTRICO", ELECTRIC, "from_cellar", ready))
        shared.add(doorArt(510f, 0xFF6A5A5A.toInt()))
        shared.add(passage("cellar_to_boiler", 510f, "CALDERA", BOILER, "from_cellar", ready))
        shared.add(doorArt(590f, 0xFF5A6A5A.toInt()))
        shared.add(passage("cellar_to_storage", 590f, "ALMACÉN", STORAGE, "from_cellar", ready))
        shared.add(ex("ex_cellar_lamp", 200f, 40f, "La luz del sótano es la última en estabilizarse."))
        val spawns = mapOf("from_electric" to SpawnPoint(400f, 1), "from_boiler" to SpawnPoint(480f, 1), "from_storage" to SpawnPoint(565f, 1))
        return extend(s, 640f, emptySet(), shared, emptyList(), emptyList(), spawns)
    }

    private val foyerMood = Mood(0xFFE6D6B8.toInt(), 0xFFC4B08C.toInt(), 0xFF9A7A56.toInt(), 0xFF6E5438.toInt(),
        WallPattern.STRIPES, FloorPattern.WOOD, 0.80f, Palette.DARK_WARM, 0xFFB09870.toInt(), 0xFF4A3322.toInt())

    private fun foyer(): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(HouseProps.rug(120f, 140f, 0xFFC87050.toInt(), 0xFF8A4A30.toInt()))
        shared.add(HouseProps.coatRack(160f))
        shared.add(HouseProps.umbrellaStand(290f))
        shared.add(lamp(200f, 40f, 130f, 0.9f, WARM))
        shared.add(doorArt(22f, 0xFF6A5A4A.toInt()))
        shared.add(passage("foyer_to_stairs", 22f, "ESCALERAS", HouseDefinition.HALL, "from_stairs"))
        shared.add(doorArt(130f, 0xFF7A8A9A.toInt()))
        shared.add(passage("foyer_to_service", 130f, "BAÑO", SERVICE_BATH, "from_foyer"))
        shared.add(Prop(214f, F - 80f, 44f, 80f, 0xFF7A3A30.toInt(), 0xFF4A2018.toInt()))
        shared.add(sp("foyer_main_door", 214f, 44f, "PUERTA", InteractionIcon.DOOR, ready) { ctx ->
            if (ctx.hasFlag(ChapterFlags.HOUSE_EXIT_UNLOCKED)) {
                ctx.post(EventType.ON_DOOR_OPEN, "foyer_main_door")
                ctx.setFlag("house_exit_used")
                InteractionResult.message("La puerta está libre. Salgo.")
            } else InteractionResult.message("La puerta no se abre. La cerradura y el marco no coinciden.")
        })
        shared.add(doorArt(340f, 0xFF8A6A5A.toInt()))
        shared.add(passage("foyer_to_living", 340f, "SALA", LIVING, "from_foyer"))
        shared.add(ex("ex_foyer_light", 176f, 40f, "La lámpara del vestíbulo zumba siempre igual. Esa va primero."))
        val spawns = mapOf("from_stairs" to SpawnPoint(90f, 1), "from_svc" to SpawnPoint(185f, 1),
            "from_living" to SpawnPoint(300f, -1), "from_impossible" to SpawnPoint(275f, 1))
        return room(FOYER, 400f, CameraMode.SIDE_SCROLLING, foyerMood, spawns, shared)
    }

    private val livingMood = Mood(0xFFD8E0C8.toInt(), 0xFFB0BC98.toInt(), 0xFFA88458.toInt(), 0xFF7A5C38.toInt(),
        WallPattern.PLAIN, FloorPattern.WOOD, 0.80f, Palette.DARK_WARM)

    private fun living(): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(180f, 38f, 140f, 0.85f, WARM))
        shared.add(box(60f, 92f, 36f, 0xFFB86A5A.toInt(), 0xFF8A4A3A.toInt()))
        shared.add(box(170f, 42f, 26f, 0xFF9A7A52.toInt(), 0xFF6E5030.toInt()))
        shared.add(box(236f, 36f, 30f, 0xFF3A3A44.toInt(), 0xFF22222A.toInt()))
        shared.add(doorArt(20f, 0xFF8A6A5A.toInt()))
        shared.add(passage("living_to_foyer", 20f, "VESTÍBULO", FOYER, "from_living"))
        shared.add(doorArt(300f, 0xFF9A7A5A.toInt()))
        shared.add(passage("living_to_dining", 300f, "COMEDOR", HouseDefinition.DINING, "from_living"))
        shared.add(ex("ex_living_tv", 236f, 36f, "El televisor está apagado."))
        shared.add(whenFlag(ChapterFlags.solved("C1"), doorArt(372f, 0xFF2A2018.toInt(), 36f)))
        shared.add(passage("living_to_pantry", 372f, "PASO ESTRECHO", PANTRY, "from_living", { it.hasFlag(ChapterFlags.solved("C1")) }))
        shared.add(sp("spot_C1_wall", 372f, 52f, "EXAMINAR PARED", InteractionIcon.EXAMINE, { it.hasFlag(StoryFlags.SURVIVAL_READY) && !it.hasFlag(ChapterFlags.solved("C1")) }) { ctx ->
            if (ctx.state.worldMode == WorldMode.TRAUMA) {
                ctx.setFlag(ChapterFlags.observed("C1"))
                InteractionResult.message("Las tres grietas son hendiduras de un marco. De izquierda a derecha: una alta, una baja y una a media altura.")
            } else InteractionResult.panel("C1")
        })
        val spawns = mapOf("from_foyer" to SpawnPoint(70f, 1), "from_dining" to SpawnPoint(330f, -1), "from_pantry" to SpawnPoint(420f, -1))
        return room(LIVING, 440f, CameraMode.SIDE_SCROLLING, livingMood, spawns, shared)
    }

    private val pantryMood = Mood(0xFFD0C4A8.toInt(), 0xFFA89C80.toInt(), 0xFF8A7656.toInt(), 0xFF605038.toInt(),
        WallPattern.PLANKS, FloorPattern.WOOD, 0.86f, Palette.DARK_DEEP)

    private fun pantry(): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(150f, 50f, 100f, 0.75f, WARM, 0.06f))
        shared.add(box(60f, 50f, 70f, 0xFF9A8460.toInt(), 0xFF6A5438.toInt()))
        shared.add(box(220f, 40f, 56f, 0xFFA89070.toInt(), 0xFF7A6040.toInt()))
        shared.add(doorArt(20f, 0xFF8A7A5A.toInt()))
        shared.add(passage("pantry_to_kitchen", 20f, "COCINA", HouseDefinition.KITCHEN, "from_pantry"))
        shared.add(whenFlag(ChapterFlags.solved("C1"), doorArt(240f, 0xFF2A2018.toInt(), 36f)))
        shared.add(passage("pantry_to_living", 240f, "PASO ESTRECHO", LIVING, "from_pantry", { it.hasFlag(ChapterFlags.solved("C1")) }))
        val normal = listOf<WorldObject>(
            ex("ex_pantry_cracks", 140f, 70f, "En la pared hay grietas finas. Parecen defectos de la pintura.")
        )
        val trauma = listOf<WorldObject>(
            doc("doc_d07", "d07", 100f, 30f),
            puzzle("spot_T1", "T1", 140f, 70f, "PLACAS")
        )
        val spawns = mapOf("from_kitchen" to SpawnPoint(90f, 1), "from_living" to SpawnPoint(200f, -1))
        return room(PANTRY, 300f, CameraMode.FIXED, pantryMood, spawns, shared, normal, trauma)
    }

    private val svcMood = Mood(0xFFDCE6EA.toInt(), 0xFFB4C6CE.toInt(), 0xFFC4D2D6.toInt(), 0xFFA0B2B8.toInt(),
        WallPattern.TILES, FloorPattern.TILES, 0.74f, Palette.DARK_COLD)

    private fun serviceBath(): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(130f, 32f, 110f, 0.95f, PALE))
        shared.add(HouseProps.bathSink(70f))
        shared.add(HouseProps.toilet(150f))
        shared.add(doorArt(20f, 0xFF7A8A9A.toInt()))
        shared.add(passage("service_to_foyer", 20f, "VESTÍBULO", FOYER, "from_svc"))
        shared.add(ex("ex_svc_note", 70f, 44f, "Una nota: «Limpiar las manchas pequeñas y recoger lo que se cae cuando mamá no puede levantarse». Es mi letra."))
        shared.add(ex("ex_svc_mirror", 100f, 24f, "Este espejo es normal. Solo me refleja a mí."))
        return room(SERVICE_BATH, 260f, CameraMode.FIXED, svcMood, mapOf("from_foyer" to SpawnPoint(80f, 1)), shared)
    }

    // ------------------------------------------------------------------ segundo piso (nuevo)

    private val closetMood = Mood(0xFFCDBFAA.toInt(), 0xFFA89880.toInt(), 0xFF8A6E4E.toInt(), 0xFF624A32.toInt(),
        WallPattern.PLAIN, FloorPattern.WOOD, 0.86f, Palette.DARK_DEEP)

    private fun closet(): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(160f, 50f, 100f, 0.7f, WARM))
        shared.add(HouseProps.crateStack(120f))
        shared.add(box(200f, 30f, 60f, 0xFF8A7A66.toInt(), 0xFF5E5040.toInt()))
        shared.add(doorArt(20f, 0xFF7A8A6A.toInt()))
        shared.add(passage("closet_to_hall", 20f, "PASILLO", HouseDefinition.HALL, "from_closet"))
        shared.add(doc("doc_d12", "d12", 70f, 30f))
        shared.add(whenFlag(ChapterFlags.solved("C2"), doorArt(250f, 0xFF1E1812.toInt(), 34f)))
        shared.add(passage("closet_to_study", 250f, "AL ESTUDIO", STUDY, "from_closet", { it.hasFlag(ChapterFlags.solved("C2")) }))
        shared.add(whenFlag(ChapterFlags.HOUSE_EXIT_UNLOCKED, Prop(298f, F - 76f, 34f, 76f, 0xFF101010.toInt(), 0xFF000000.toInt())))
        shared.add(passage("closet_to_impossible", 298f, "PUERTA SIN MARCO", IMPOSSIBLE, "from_closet", { it.hasFlag(ChapterFlags.HOUSE_EXIT_UNLOCKED) }))
        shared.add(sp("spot_C2_box", 140f, 56f, "EXAMINAR CAJA", InteractionIcon.EXAMINE,
            { it.hasFlag(StoryFlags.SURVIVAL_READY) && !it.hasFlag(ChapterFlags.solved("C2")) }) { ctx ->
            if (ctx.state.worldMode == WorldMode.TRAUMA) {
                ctx.setFlag(ChapterFlags.observed("C2"))
                InteractionResult.message("Las huellas entran en la pared por la derecha. El símbolo del retrato está girado, como la marca del estudio.")
            } else InteractionResult.panel("C2")
        })
        val normal = listOf<WorldObject>(
            ex("ex_closet_prints", 60f, 50f, "Unas huellas terminan frente a la caja. Las mías.")
        )
        val trauma = listOf<WorldObject>(
            ex("ex_closet_symbol", 200f, 30f, "Una marca de tres líneas y un punto, girada.")
        )
        val spawns = mapOf("from_hall" to SpawnPoint(80f, 1), "from_study" to SpawnPoint(215f, -1))
        return room(CLOSET, 340f, CameraMode.FIXED, closetMood, spawns, shared, normal, trauma)
    }

    private val studyMood = Mood(0xFFD6CCB8.toInt(), 0xFFB0A48C.toInt(), 0xFF7E6446.toInt(), 0xFF584632.toInt(),
        WallPattern.PLAIN, FloorPattern.WOOD, 0.84f, Palette.DARK_WARM)

    private fun study(): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(170f, 40f, 120f, 0.8f, WARM))
        shared.add(box(150f, 80f, 40f, 0xFF8A6A44.toInt(), 0xFF5E4426.toInt()))
        shared.add(HouseProps.crateStack(260f))
        shared.add(doorArt(20f, 0xFF7A8A6A.toInt()))
        shared.add(passage("study_to_closet", 20f, "ARMARIO", CLOSET, "from_study"))
        shared.add(sp("spot_C4", 150f, 80f, "CARTA", InteractionIcon.USE, ready) { ctx ->
            if (ctx.hasFlag(ChapterFlags.solved("C4"))) InteractionResult.document("d14c") else InteractionResult.panel("C4")
        })
        val normal = emptyList<WorldObject>()
        val trauma = listOf<WorldObject>(
            sp("spot_letter_b", 100f, 30f, "RECOGER", InteractionIcon.PICK, ready) { ctx ->
                if (ctx.hasFlag(ChapterFlags.GOT_LETTER_B)) InteractionResult.message("Ya tengo la segunda mitad de la carta.")
                else {
                    ctx.setFlag(ChapterFlags.GOT_LETTER_B)
                    InteractionResult.document("d14b")
                }
            },
            doc("doc_d21", "d21", 270f, 30f),
            ex("ex_study_margin", 200f, 30f, "Los trazos del margen de la carta: un zigzag, un rectángulo y una línea alta."),
            ex("ex_study_antenna_drawing", 230f, 30f, "Un dibujo infantil de la antena: brazo corto → ventana iluminada, brazo medio → línea quebrada, brazo largo → torre oscura.")
        )
        return room(STUDY, 360f, CameraMode.SIDE_SCROLLING, studyMood, mapOf("from_closet" to SpawnPoint(80f, 1)), shared, normal, trauma)
    }

    // ------------------------------------------------------------------ sótano (nuevo)

    private val basementMood = Mood(0xFF8A8294.toInt(), 0xFF5E566E.toInt(), 0xFF6A6672.toInt(), 0xFF46424E.toInt(),
        WallPattern.PLANKS, FloorPattern.CONCRETE, 0.88f, Palette.DARK_DEEP)

    private fun electric(): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(130f, 50f, 90f, 0.7f, COLD, 0.08f))
        shared.add(wallPlate(110f, 40f, 70f, 70f, 0xFF6A7078.toInt(), 0xFF3E434A.toInt()))
        shared.add(doorArt(20f, 0xFF5A5A6A.toInt()))
        shared.add(passage("electric_to_cellar", 20f, "SÓTANO", HouseDefinition.CELLAR, "from_electric"))
        val normal = listOf<WorldObject>(
            doc("doc_d06", "d06", 60f, 28f),
            sp("spot_N5", 110f, 70f, "INTERRUPTORES", InteractionIcon.USE, ready) { InteractionResult.panel("N5") }
        )
        return room(ELECTRIC, 260f, CameraMode.FIXED, basementMood, mapOf("from_cellar" to SpawnPoint(80f, 1)), shared, normal)
    }

    private fun boiler(): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(170f, 60f, 100f, 0.65f, WARM, 0.1f))
        shared.add(box(150f, 80f, 70f, 0xFF8A5A4A.toInt(), 0xFF5A3428.toInt()))
        shared.add(doorArt(20f, 0xFF6A5A5A.toInt()))
        shared.add(passage("boiler_to_cellar", 20f, "SÓTANO", HouseDefinition.CELLAR, "from_boiler"))
        shared.add(ex("ex_boiler_old", 150f, 80f, "La caldera es vieja y ruidosa. Tiene cuatro válvulas."))
        val trauma = listOf<WorldObject>(
            doc("doc_d10", "d10", 56f, 28f),
            ex("valve_1", 90f, 22f, "Válvula 1: golpea dos veces y espera."),
            ex("valve_2", 118f, 22f, "Válvula 2: no llega a completar el ciclo."),
            ex("valve_3", 250f, 22f, "Válvula 3: un silbido continuo."),
            ex("valve_4", 278f, 22f, "Válvula 4, la más cercana a la pared: deja de sonar antes que las demás."),
            puzzle("spot_T4", "T4", 170f, 50f, "AJUSTAR")
        )
        return room(BOILER, 340f, CameraMode.FIXED, basementMood, mapOf("from_cellar" to SpawnPoint(80f, 1)), shared, emptyList(), trauma)
    }

    private fun storage(): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(170f, 55f, 100f, 0.65f, WARM))
        shared.add(HouseProps.crateStack(100f))
        shared.add(HouseProps.barrel(200f))
        shared.add(doorArt(20f, 0xFF5A6A5A.toInt()))
        shared.add(passage("storage_to_cellar", 20f, "SÓTANO", HouseDefinition.CELLAR, "from_storage"))
        shared.add(whenFlag(ChapterFlags.solved("T4"), doorArt(300f, 0xFF1A1A22.toInt(), 34f, 50f)))
        shared.add(passage("storage_to_foundation", 300f, "PASO BAJO", FOUNDATION, "from_storage", { it.hasFlag(ChapterFlags.solved("T4")) }))
        shared.add(ex("ex_storage_gap", 296f, 40f, "Hay un hueco en la pared que no corresponde al almacén."))
        return room(STORAGE, 360f, CameraMode.SIDE_SCROLLING, basementMood, mapOf("from_cellar" to SpawnPoint(80f, 1), "from_foundation" to SpawnPoint(250f, -1)), shared)
    }

    private fun foundation(): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(180f, 70f, 90f, 0.6f, COLD, 0.12f))
        shared.add(wallPlate(120f, 60f, 200f, 60f, 0xFF3E4650.toInt(), 0xFF22282E.toInt()))
        shared.add(doorArt(20f, 0xFF5A6A5A.toInt(), 34f, 50f))
        shared.add(passage("foundation_to_storage", 20f, "ALMACÉN", STORAGE, "from_foundation"))
        val normal = listOf<WorldObject>(
            Prop(60f, F - 8f, 280f, 8f, 0x886A8AAA.toInt(), 0xAA4A6A8A.toInt()).also { it.layer = com.terror2d.world.Layer.DECOR },
            sp("spot_C3", 200f, 90f, "PANELES", InteractionIcon.USE, ready) { InteractionResult.panel("C3") }
        )
        val trauma = listOf<WorldObject>(
            observe("obs_C3", "C3", 200f, 90f,
                "El agua desapareció. El reflejo del vaso se vuelve una figura que señala hacia el fondo, al tercer panel contando desde la izquierda.",
                needs = ChapterFlags.GOT_GLASS, missing = "Aquí hay algo que se parece al reflejo del vaso. No tengo con qué compararlo.")
        )
        return room(FOUNDATION, 360f, CameraMode.SIDE_SCROLLING, basementMood, mapOf("from_storage" to SpawnPoint(80f, 1)), shared, normal, trauma)
    }

    // ------------------------------------------------------------------ azotea e imposible

    private val roofMood = Mood(0xFF8AA0B8.toInt(), 0xFF6A809A.toInt(), 0xFF5A5E66.toInt(), 0xFF3E4248.toInt(),
        WallPattern.PLAIN, FloorPattern.CONCRETE, 0.55f, Palette.DARK_COLD)

    private fun roof(): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(300f, 36f, 140f, 0.55f, COLD))
        shared.add(box(60f, 56f, 54f, 0xFF7A8A94.toInt(), 0xFF50606A.toInt()))
        shared.add(box(360f, 26f, 60f, 0xFF8A6A5A.toInt(), 0xFF5E4236.toInt()))
        shared.add(box(205f, 8f, 84f, 0xFF4A4A52.toInt(), 0xFF2A2A30.toInt()))
        shared.add(wallPlate(180f, 52f, 60f, 4f, 0xFF4A4A52.toInt(), 0xFF2A2A30.toInt()))
        shared.add(doorArt(20f, 0xFF4A5A6A.toInt(), 34f, 40f))
        shared.add(passage("roof_to_hall", 20f, "BAJAR", HouseDefinition.HALL, "from_roof"))
        shared.add(ex("ex_roof_antenna", 190f, 44f, "La antena tiene tres brazos que giran. A lo lejos: una ventana iluminada, una torre oscura y una línea quebrada."))
        val normal = listOf<WorldObject>(
            observe("obs_C5", "C5", 300f, 50f,
                "La lámpara del vestíbulo proyecta una línea de luz desde dentro de la casa que coincide con la sombra de la antena.",
                needs = ChapterFlags.solved("N5"), missing = "Desde aquí no veo ninguna línea. Quizá si la luz del sótano estuviera estable.")
        )
        val trauma = listOf<WorldObject>(
            puzzle("spot_T5", "T5", 150f, 40f, "GIRAR BRAZOS"),
            doc("doc_d11", "d11", 110f, 24f),
            ex("ex_roof_drawing", 250f, 30f, "El dibujo de la antena: brazo corto → ventana iluminada, brazo medio → línea quebrada, brazo largo → torre oscura."),
            puzzle("spot_C5", "C5", 220f, 40f, "ARANDELA")
        )
        return room(ROOF, 440f, CameraMode.SIDE_SCROLLING, roofMood, mapOf("from_hall" to SpawnPoint(80f, 1)), shared, normal, trauma)
    }

    private val impossibleMood = Mood(0xFFE8E4DC.toInt(), 0xFFC8C4BC.toInt(), 0xFFD0CCC4.toInt(), 0xFFB0ACA4.toInt(),
        WallPattern.PLAIN, FloorPattern.CONCRETE, 0.45f, Palette.DARK_COLD)

    private fun impossible(): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(150f, 30f, 150f, 0.95f, PALE))
        shared.add(wallPlate(100f, 30f, 60f, 50f, 0xFFB8B4AC.toInt(), 0xFF8A867E.toInt()))
        shared.add(doorArt(240f, 0xFF3A3A44.toInt()))
        shared.add(sp("impossible_exit", 240f, 34f, "ABRIR", InteractionIcon.DOOR, null) { ctx ->
            ctx.post(EventType.ON_DOOR_OPEN, "impossible_exit")
            InteractionResult.transition(DoorTarget(FOYER, "from_impossible"))
        })
        shared.add(ex("ex_impossible_window", 100f, 60f, "La ventana no da a la calle. Da a una pared de esta misma casa, desde un ángulo que no existe."))
        return room(IMPOSSIBLE, 300f, CameraMode.FIXED, impossibleMood, mapOf("from_closet" to SpawnPoint(60f, 1)), shared, hasTrauma = false)
    }
}
