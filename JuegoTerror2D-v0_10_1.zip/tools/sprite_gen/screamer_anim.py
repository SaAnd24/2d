"""SCREAMER v0.10.1: secuencia cinematográfica a partir del rostro canónico de screamer_face.py.

Cada fotograma es el MISMO rostro (misma definición en espacio de cara) visto con otra cámara/pose: aproximación en
perspectiva, mandíbula que se abre y tiembla, ojos que se desorbitan, cabeza ladeada, brazos y manos largas que
entran por los lados y un último plano de impacto. Los brazos usan el mismo material de piel que el rostro.

Salida: app/.../pixel/ScreamerArtData.kt (índices de paleta, zlib + base64, ver ScreamerCodec) y vistas previas PNG
para la carpeta docs (NO forman parte del APK).

Uso:  python3 screamer_anim.py [carpeta_docs]
"""
import base64
import math
import os
import sys
import zlib

import numpy as np
from PIL import Image
from scipy import ndimage as ndi

import screamer_face as F
from screamer_face import W, H, sstep, gauss, ramp_color, SKIN, SKIN_WARM, WART, TOOTH, fbm, seg_dist, paint

# ------------------------------------------------------------------ tiempos y fotogramas
# (distancia D, mirada u0/v0, desplazamiento sx/sy, guiñada, cabeceo, alabeo, mandíbula, ojos, párpado, mirada, luz, temblor, manos)
FRAME_START = [0.0, 0.18, 0.30, 0.40, 0.48, 0.56, 0.64, 0.72, 0.82, 0.92, 1.02, 1.14, 1.26, 1.40, 1.56, 1.72, 1.90, 2.10]
DURATION = 2.45
CUES = {'impact': 5, 'roar': 7, 'grab': 11, 'final': 17}

#            D     u0     v0     yaw    pitch  roll   jaw   eyew  lid   lkx   lky   lum  shake hands
KEYS = [
    dict(D=3.88, u0=0.00, v0=0.00, sy=0, yaw=0.00, pitch=0.00, roll=0.000, jaw=0.00, eyew=0.00, lid=0.00, lookx=0.0, looky=0.0, lum=1.00, shake=0.0),   # 0 = referencia
    dict(D=3.30, u0=0.00, v0=-0.03, sy=2, yaw=0.00, pitch=0.00, roll=0.010, jaw=0.04, eyew=0.06, lid=0.05, lookx=0.0, looky=0.0, lum=1.00, shake=0.5),
    dict(D=2.70, u0=0.00, v0=-0.10, sy=8, yaw=0.02, pitch=0.01, roll=-0.015, jaw=0.09, eyew=0.14, lid=0.10, lookx=0.0, looky=0.0, lum=1.00, shake=0.7),
    dict(D=2.20, u0=0.00, v0=-0.20, sy=12, yaw=-0.03, pitch=0.02, roll=0.025, jaw=0.17, eyew=0.24, lid=0.18, lookx=0.0, looky=0.0, lum=1.00, shake=0.9),
    dict(D=1.85, u0=0.00, v0=-0.25, sy=16, yaw=0.04, pitch=0.00, roll=-0.035, jaw=0.30, eyew=0.40, lid=0.28, lookx=0.0, looky=0.1, lum=1.00, shake=1.1),
    dict(D=1.55, u0=0.00, v0=-0.28, sy=22, yaw=-0.06, pitch=-0.03, roll=0.050, jaw=0.55, eyew=0.65, lid=0.45, lookx=0.0, looky=0.0, lum=1.00, shake=2.2),   # 5 IMPACTO
    dict(D=1.40, u0=0.00, v0=-0.25, sy=24, yaw=0.07, pitch=-0.02, roll=-0.060, jaw=0.85, eyew=0.80, lid=0.55, lookx=0.2, looky=0.1, lum=1.00, shake=1.4),
    dict(D=1.28, u0=0.00, v0=-0.10, sy=30, yaw=0.10, pitch=0.00, roll=0.040, jaw=1.18, eyew=1.00, lid=0.65, lookx=0.0, looky=0.0, lum=1.00, shake=1.8,
         hands=[dict(x=64, y=96, size=78, ang=-16, curl=0.7, side=-1), dict(x=576, y=96, size=78, ang=16, curl=0.7, side=1)]),                      # 7 RUGIDO
    dict(D=1.20, u0=0.00, v0=0.00, sy=24, yaw=-0.14, pitch=0.02, roll=-0.090, jaw=1.36, eyew=1.00, lid=0.70, lookx=-0.3, looky=0.1, lum=1.00, shake=1.4,
         hands=[dict(x=92, y=118, size=92, ang=-24, curl=0.6, side=-1), dict(x=548, y=108, size=92, ang=22, curl=0.6, side=1)]),
    dict(D=1.15, u0=0.00, v0=0.05, sy=20, yaw=0.18, pitch=-0.02, roll=0.100, jaw=0.98, eyew=1.00, lid=0.70, lookx=0.3, looky=0.0, lum=1.00, shake=1.8,
         hands=[dict(x=128, y=140, size=108, ang=-32, curl=0.5, side=-1), dict(x=516, y=130, size=108, ang=28, curl=0.5, side=1)]),
    dict(D=1.10, u0=0.00, v0=0.08, sy=18, yaw=-0.10, pitch=0.03, roll=-0.050, jaw=1.42, eyew=1.00, lid=0.75, lookx=0.0, looky=-0.1, lum=1.00, shake=1.6,
         hands=[dict(x=170, y=168, size=126, ang=-38, curl=0.4, side=-1), dict(x=476, y=156, size=126, ang=36, curl=0.4, side=1)]),
    dict(D=1.05, u0=0.05, v0=0.10, sy=12, yaw=0.12, pitch=0.00, roll=0.070, jaw=1.20, eyew=1.00, lid=0.75, lookx=0.4, looky=0.0, lum=0.95, shake=2.6,
         hands=[dict(x=250, y=190, size=190, ang=-52, curl=0.25, side=-1), dict(x=584, y=160, size=150, ang=40, curl=0.4, side=1)]),               # 11 AGARRE
    dict(D=1.00, u0=0.10, v0=0.12, sy=6, yaw=0.34, pitch=0.04, roll=0.180, jaw=1.55, eyew=1.10, lid=0.80, lookx=-0.6, looky=0.2, lum=0.92, shake=2.2,
         hands=[dict(x=300, y=206, size=250, ang=-60, curl=0.2, side=-1)]),
    dict(D=0.95, u0=0.10, v0=0.12, sy=4, yaw=0.28, pitch=0.05, roll=0.140, jaw=1.12, eyew=1.10, lid=0.80, lookx=-0.5, looky=0.1, lum=0.9, shake=1.8,
         hands=[dict(x=330, y=216, size=280, ang=-64, curl=0.2, side=-1)]),
    dict(D=0.62, u0=-0.32, v0=-0.58, sy=0, yaw=0.10, pitch=0.00, roll=-0.060, jaw=1.00, eyew=1.15, lid=0.85, lookx=0.0, looky=0.0, lum=0.9, shake=1.5),   # ojo gigante
    dict(D=1.10, u0=0.00, v0=0.80, sy=0, yaw=-0.06, pitch=-0.02, roll=0.050, jaw=0.45, eyew=1.15, lid=0.85, lookx=0.2, looky=0.0, lum=0.88, shake=2.0),   # gaznate y lengua
    dict(D=1.30, u0=0.00, v0=-0.05, sy=40, yaw=0.15, pitch=-0.03, roll=-0.100, jaw=1.20, eyew=1.20, lid=0.9, lookx=0.0, looky=0.0, lum=0.9, shake=3.0),
    dict(D=1.45, u0=0.00, v0=-0.05, sy=70, yaw=0.03, pitch=-0.04, roll=0.050, jaw=1.80, eyew=1.25, lid=0.9, lookx=0.0, looky=0.0, lum=0.95, shake=1.0),   # 17 FINAL
]
assert len(KEYS) == len(FRAME_START)
FRAME_COUNT = len(KEYS)


# ------------------------------------------------------------------ brazos y manos largos (mismo material que el rostro)
def capsule_h(X, Y, p0, p1, r0, r1):
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    L2 = dx * dx + dy * dy + 1e-6
    t = np.clip(((X - p0[0]) * dx + (Y - p0[1]) * dy) / L2, 0, 1)
    px, py = p0[0] + t * dx, p0[1] + t * dy
    r = r0 + (r1 - r0) * t
    d = np.hypot(X - px, Y - py) / np.maximum(r, 1e-3)
    return np.where(d < 1.0, r * np.sqrt(np.clip(1 - d * d, 0, 1)), 0.0), d < 1.0, t, r


def hand_layer(img, hd, seed):
    """Brazo largo + mano de dedos finos con uñas, desde el borde de la pantalla. Se pinta sobre img."""
    X, Y = np.meshgrid(np.arange(W, dtype=np.float32) + 0.5, np.arange(H, dtype=np.float32) + 0.5)
    x, y, size, ang, curl, side = hd['x'], hd['y'], hd['size'], hd['ang'], hd['curl'], hd['side']
    a0 = math.radians(ang - 90.0)
    ux, uy = math.cos(a0), math.sin(a0)
    px, py = -uy, ux
    hmap = np.zeros((H, W), dtype=np.float32)
    mask = np.zeros((H, W), dtype=bool)
    nails = []
    # brazo: del borde inferior/lateral hasta la muñeca
    wrist = (x - ux * size * 0.55, y - uy * size * 0.55)
    start = (x - ux * size * 3.6 + side * size * 0.9, y - uy * size * 3.6 + size * 1.3)
    mid = ((start[0] + wrist[0]) / 2 + side * size * 0.15, (start[1] + wrist[1]) / 2)
    for (a, b, r0, r1) in ((start, mid, size * 0.62, size * 0.52), (mid, wrist, size * 0.52, size * 0.42)):
        hh, mm, t, r = capsule_h(X, Y, a, b, r0, r1)
        hmap = np.maximum(hmap, hh)
        mask |= mm
    # palma
    pd = np.hypot((X - x) / (size * 0.66), (Y - y) / (size * 0.58))
    hp = np.where(pd < 1, size * 0.5 * np.sqrt(np.clip(1 - pd * pd, 0, 1)), 0.0)
    hmap = np.maximum(hmap, hp)
    mask |= pd < 1
    # dedos (largos y finos, con una falange media curvada)
    for i, off in enumerate((-1.5, -0.5, 0.5, 1.5)):
        base = (x + px * off * size * 0.27 + ux * size * 0.25, y + py * off * size * 0.27 + uy * size * 0.25)
        ln = size * (1.25 - 0.14 * abs(off)) * (1.08 if i in (1, 2) else 1.0)
        bend = curl * (0.35 + 0.18 * off)
        mid2 = (base[0] + ux * ln * 0.52 + px * off * size * 0.10, base[1] + uy * ln * 0.52 + py * off * size * 0.10)
        tip = (mid2[0] + ux * ln * 0.48 * (1 - bend) + px * bend * size * 0.30, mid2[1] + uy * ln * 0.48 * (1 - bend) + py * bend * size * 0.30 + bend * ln * 0.18)
        for (a, b, r0, r1) in ((base, mid2, size * 0.185, size * 0.150), (mid2, tip, size * 0.150, size * 0.105)):
            hh, mm, t, r = capsule_h(X, Y, a, b, r0, r1)
            hmap = np.maximum(hmap, hh)
            mask |= mm
        nails.append(tip)
    tb = (x + px * size * 0.55 * -side * -1, y + py * size * 0.12)
    tt_ = (tb[0] + px * size * 0.50 * -side * -1 + ux * size * 0.40, tb[1] + py * size * 0.5 + uy * size * 0.40)
    hh, mm, t, r = capsule_h(X, Y, tb, tt_, size * 0.14, size * 0.09)
    hmap = np.maximum(hmap, hh)
    mask |= mm
    nails.append(tt_)
    # sombreado
    hs = ndi.gaussian_filter(hmap, 0.8)
    gy, gx = np.gradient(hs)
    k = 1.15
    nx, ny, nz = -gx * k, -gy * k, np.ones_like(hs)
    inv = 1 / np.sqrt(nx * nx + ny * ny + nz * nz)
    L = np.array([-0.35, -0.70, 0.62])
    lam = np.clip((nx * L[0] + ny * L[1] + nz * L[2]) * inv, 0, 1)
    ao = np.clip((ndi.gaussian_filter(hs, size * 0.08) - hs) * 0.06, 0, 0.5)
    n1 = fbm(X / size, Y / size, seed, 10.0, 4)
    tt = np.clip((lam - 0.08) * 1.35, 0, 1) * (1 - ao) * (0.80 + 0.2 * n1) * 0.92
    col = ramp_color(SKIN, tt) * 0.82 + ramp_color(SKIN_WARM, tt) * 0.18
    pores = fbm(X / size, Y / size, seed + 5, 55.0, 2) > 0.78
    col[pores] *= 0.8
    paint(img, mask, col, outline=0.30)
    # uñas, nudillos y verrugas
    for (tx, ty) in nails:
        m = np.hypot((X - tx) / (size * 0.085), (Y - ty) / (size * 0.115)) < 1
        img[m & mask] = ramp_color(TOOTH, np.full((H, W), 0.36, dtype=np.float32))[m & mask]
        hi = (np.hypot(X - tx + size * 0.03, Y - ty + size * 0.04) < size * 0.025) & m
        img[hi] = ramp_color(TOOTH, np.full((H, W), 0.8, dtype=np.float32))[hi]
    rng = np.random.RandomState(seed)
    for j in range(7):
        wx = x + px * (rng.rand() - 0.5) * size * 1.2 + ux * (rng.rand() * 0.9 - 0.2) * size
        wy = y + py * (rng.rand() - 0.5) * size * 1.2 + uy * (rng.rand() * 0.9 - 0.2) * size
        r = size * (0.035 + 0.02 * rng.rand())
        m = (np.hypot(X - wx, Y - wy) < r) & mask
        img[m] = ramp_color(WART, np.full((H, W), 0.6, dtype=np.float32))[m]
    return mask


# ------------------------------------------------------------------ composición de un fotograma
def frame(i):
    k = dict(KEYS[i])
    rng = np.random.RandomState(100 + i)
    sh = k.pop('shake', 0.0)
    hands = k.pop('hands', [])
    k['shx'] = float(rng.randn() * 3.0 * sh)
    k['shy'] = float(rng.randn() * 2.4 * sh)
    k['roll'] = k['roll'] + float(rng.randn() * 0.006 * sh)
    k['seed'] = 2
    img = F.render(k)
    for j, hd in enumerate(hands):
        hand_layer(img, hd, 30 + i * 3 + j)
    # viñeta: más densa cuanto más cerca (el borde de la pantalla se oscurece, el centro queda cargado)
    yy, xx = np.mgrid[0:H, 0:W]
    r = np.hypot((xx - W / 2) / (W / 2), (yy - H / 2) / (H / 2))
    near = np.clip((3.9 - k['D']) / 3.4, 0, 1)
    vig = 1.0 - (0.18 + 0.40 * near) * sstep(0.55, 1.25, r)
    img = img * vig[..., None]
    if i == FRAME_COUNT - 1:
        img = img * np.array([1.0, 0.88, 0.86])           # último plano virado a rojo oscuro
    return img


def build_all():
    imgs, idxs = [], []
    for i in range(FRAME_COUNT):
        im = frame(i)
        imgs.append(im)
        idxs.append(F.quantize(im))
        print('frame', i, 'ok', flush=True)
    return imgs, idxs


# ------------------------------------------------------------------ salida
def encode_frame(idx):
    raw = idx.astype(np.uint8).tobytes()
    z = zlib.compress(raw, 9)
    b64 = base64.b64encode(z).decode('ascii')
    return [b64[i:i + 60000] for i in range(0, len(b64), 60000)], len(z)


def emit(idxs, path):
    L = []
    w = L.append
    w('package com.terror2d.pixel')
    w('')
    w('/**')
    w(' * DATOS GENERADOS por tools/sprite_gen/screamer_anim.py (+ screamer_face.py). NO editar a mano: edita el generador.')
    w(' * Arte del SCREAMER de captura (v0.10.1): %d fotogramas de %dx%d (1 px = 0,5 px lógicos) como índices de paleta (1 byte por' % (len(idxs), W, H))
    w(' * píxel), comprimidos con zlib y escritos en base64 (cadenas de <= 60000 caracteres). Decodificación: [ScreamerCodec].')
    w(' * El rostro se reconstruyó de forma procedural a partir de la imagen de referencia; la imagen NO está en el proyecto.')
    w(' */')
    w('object ScreamerArtData {')
    w(f'    const val WIDTH = {W}')
    w(f'    const val HEIGHT = {H}')
    w(f'    const val FRAME_COUNT = {len(idxs)}')
    w('    /** Colores ARGB opacos de la paleta de índices. */')
    w('    val PALETTE: IntArray = intArrayOf(' + ', '.join('0xFF%02X%02X%02X.toInt()' % tuple(int(c) for c in col) for col in F.PALETTE) + ')')
    w('    /** Por fotograma: trozos base64 de los bytes zlib de HEIGHT*WIDTH índices. */')
    w('    val FRAME_DATA: Array<Array<String>> = arrayOf(')
    blocks, total = [], 0
    for im in idxs:
        chunks, zn = encode_frame(im)
        total += zn
        blocks.append('        arrayOf(\n' + ',\n'.join('            "%s"' % c for c in chunks) + '\n        )')
    w(',\n'.join(blocks))
    w('    )')
    w('}')
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    return total


def sheet(idxs, path, cols=3, scale=0.5):
    tw, th = int(W * scale), int(H * scale)
    rows = (len(idxs) + cols - 1) // cols
    out = Image.new('RGB', (tw * cols, th * rows), (0, 0, 0))
    for i, im in enumerate(idxs):
        t = Image.fromarray(F.to_rgb(im)).resize((tw, th), Image.NEAREST if scale >= 1 else Image.BOX)
        out.paste(t, ((i % cols) * tw, (i // cols) * th))
    out.save(path)


if __name__ == '__main__':
    docs = sys.argv[1] if len(sys.argv) > 1 else '/home/claude'
    imgs, idxs = build_all()
    out = os.path.join(os.path.dirname(__file__), '..', '..', 'app', 'src', 'main', 'java', 'com', 'terror2d', 'pixel', 'ScreamerArtData.kt')
    zn = emit(idxs, os.path.abspath(out))
    print('ScreamerArtData.kt', os.path.getsize(out), 'bytes; zlib total', zn)
    np.save('/home/claude/screamer_idx.npy', np.stack(idxs))
    Image.fromarray(F.to_rgb(idxs[0])).resize((W * 2, H * 2), Image.NEAREST).save(os.path.join(docs, 'screamer_first_frame_v0_10_1.png'))
    sheet(idxs, os.path.join(docs, 'screamer_sequence_v0_10_1.png'), cols=3, scale=0.5)
