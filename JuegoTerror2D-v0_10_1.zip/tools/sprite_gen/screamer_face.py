"""SCREAMER v0.10.1: rostro canónico del monstruo, reconstruido PROCEDURALMENTE a partir de la imagen de referencia.

La imagen de referencia NO se usa en tiempo de ejecución ni se incluye en el proyecto: aquí solo se codifican, como
números, las medidas que se tomaron de ella (posición y tamaño de ojos, cejas, nariz, línea de la boca, número y
largo de dientes, paleta). El rostro se define UNA vez en un "espacio de cara" (u derecha, v abajo; 1 unidad = medio
ancho de la imagen de referencia) y todos los fotogramas lo vuelven a evaluar bajo una cámara en perspectiva
(distancia, guiñada, cabeceo, alabeo), con la mandíbula, los párpados y la mirada animados. Así cada fotograma es el
MISMO organismo visto de otra manera, no un rediseño.

Técnica: sombreador por píxel en numpy -> color flotante -> cuantización a una paleta fija con tramado ordenado
(Bayer 4x4) y contornos duros. El juego solo recibe índices de paleta (ScreamerArtData).

Dependencias (solo del generador, no del juego): numpy, scipy, Pillow.
"""
import math
import numpy as np
from scipy import ndimage as ndi

W, H = 640, 360
FOCAL = 520.0

# ------------------------------------------------------------------ paleta (RGB). Medida de la referencia + rampas propias
def _ramp(*cols):
    return [tuple(c) for c in cols]

SKIN = _ramp((12, 10, 12), (34, 28, 22), (58, 52, 34), (84, 80, 46), (108, 110, 62), (134, 138, 80), (158, 164, 100), (184, 190, 128))
SKIN_WARM = _ramp((14, 9, 10), (40, 26, 22), (66, 46, 32), (92, 70, 42), (116, 90, 52), (140, 110, 66), (164, 130, 84), (186, 152, 106))
LIP = _ramp((22, 8, 12), (52, 20, 22), (84, 34, 30), (116, 52, 42), (142, 72, 54), (168, 96, 70))
MAW = _ramp((4, 3, 7), (12, 7, 11), (26, 11, 15), (44, 16, 19), (66, 24, 25), (92, 34, 32), (120, 48, 42))
TOOTH = _ramp((38, 30, 24), (74, 62, 42), (112, 98, 62), (150, 138, 92), (186, 176, 126), (214, 206, 158), (238, 230, 184))
EYE = _ramp((18, 8, 12), (58, 20, 24), (96, 34, 36), (130, 50, 46), (160, 74, 62), (190, 108, 90))
TEAR = _ramp((14, 16, 24), (32, 38, 54), (56, 64, 84), (84, 94, 112))
WART = _ramp((70, 34, 20), (128, 70, 30), (186, 118, 46), (222, 168, 82), (246, 206, 130))
SORE = _ramp((60, 16, 16), (110, 30, 26), (156, 52, 38), (190, 82, 54))
EXTRA = [(0, 0, 0), (6, 5, 10), (10, 9, 14), (238, 226, 186), (255, 244, 214), (134, 131, 122), (255, 255, 255), (200, 40, 30)]


def build_palette():
    cols = []
    for r in (SKIN, SKIN_WARM, LIP, MAW, TOOTH, EYE, TEAR, WART, SORE):
        cols.extend(r)
    cols.extend(EXTRA)
    # sin duplicados exactos, orden estable
    out = []
    for c in cols:
        if c not in out:
            out.append(c)
    return out


PALETTE = build_palette()
PAL_ARR = np.array(PALETTE, dtype=np.float32)


# ------------------------------------------------------------------ utilidades matemáticas
def sstep(a, b, x):
    t = np.clip((x - a) / (b - a + 1e-9), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def gauss(x, s):
    return np.exp(-(x / s) ** 2)


def lerp(a, b, t):
    return a + (b - a) * t


def ramp_color(ramp, t):
    """t en [0,1] -> color RGB interpolado en la rampa (arrays)."""
    r = np.array(ramp, dtype=np.float32)
    n = len(r) - 1
    x = np.clip(t, 0.0, 1.0) * n
    i0 = np.clip(np.floor(x).astype(np.int32), 0, n - 1)
    f = (x - i0)[..., None]
    return r[i0] * (1 - f) + r[i0 + 1] * f


def _hash2(ix, iy, seed):
    h = (ix.astype(np.int64) * 374761393 + iy.astype(np.int64) * 668265263 + seed * 2246822519) & 0xFFFFFFFF
    h = ((h ^ (h >> 13)) * 1274126177) & 0xFFFFFFFF
    h = h ^ (h >> 16)
    return (h & 0xFFFF).astype(np.float32) / 65535.0


def vnoise(x, y, seed):
    ix, iy = np.floor(x), np.floor(y)
    fx, fy = x - ix, y - iy
    fx = fx * fx * (3 - 2 * fx)
    fy = fy * fy * (3 - 2 * fy)
    a = _hash2(ix, iy, seed)
    b = _hash2(ix + 1, iy, seed)
    c = _hash2(ix, iy + 1, seed)
    d = _hash2(ix + 1, iy + 1, seed)
    return lerp(lerp(a, b, fx), lerp(c, d, fx), fy)


def fbm(u, v, seed, freq, octaves=4):
    s, amp, tot = 0.0, 1.0, 0.0
    for o in range(octaves):
        s = s + amp * vnoise(u * freq, v * freq, seed + o * 17)
        tot += amp
        amp *= 0.5
        freq *= 2.03
    return s / tot


def seg_dist(u, v, p0, p1):
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    L2 = dx * dx + dy * dy
    t = np.clip(((u - p0[0]) * dx + (v - p0[1]) * dy) / L2, 0.0, 1.0)
    return np.hypot(u - (p0[0] + t * dx), v - (p0[1] + t * dy)), t


BAYER = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]], dtype=np.float32) / 16.0 - 0.5


# ------------------------------------------------------------------ medidas de la referencia (espacio de cara)
EYES = [  # (u, v, inclinación rad, lado) lado -1 izq / +1 der
    (-0.397, -0.703, 0.16, -1), (0.373, -0.725, -0.16, 1)]
EYE_RX, EYE_RY = 0.190, 0.098
BROWS = [((-0.15, -1.03), (-0.74, -0.80)), ((0.15, -1.04), (0.74, -0.80))]
BROW_R = 0.185
NOSTRILS = [(-0.075, -0.350, 0.22), (0.105, -0.348, -0.22)]
WARTS = [(-0.76, -1.07, 0.040), (-0.52, -0.90, 0.036), (-0.28, -1.30, 0.034), (0.25, -1.31, 0.034), (0.72, -1.08, 0.042),
         (-0.89, -0.69, 0.034), (-0.62, -1.26, 0.030), (0.60, -1.30, 0.028), (0.86, -0.90, 0.030), (-0.87, -0.46, 0.026),
         (0.35, -1.07, 0.022), (-0.34, -0.99, 0.020), (0.82, -0.55, 0.024)]
SORES = [(0.07, -0.20, 0.05), (0.46, -0.24, 0.045), (-0.34, -0.19, 0.045), (-0.46, -0.30, 0.04), (0.62, -0.38, 0.04),
         (-0.18, -0.22, 0.03), (0.30, -0.18, 0.03)]
HEAD_RX, HEAD_RY, HEAD_CY = 1.13, 1.62, 0.02


def head_halfwidth(v):
    """Semiancho de la cabeza a cada altura: estrecha en la frente, ancha en las mejillas, se cierra en la papada."""
    return (0.80 + 0.34 * sstep(-1.35, -0.55, v) + 0.18 * sstep(-0.35, 0.5, v) - 0.60 * sstep(0.85, 1.65, v))
N_UP, N_LO = 17, 21
UP_L, LO_L = 0.34, 0.23


def lip_up(u):
    """Línea del labio superior (v) — la sonrisa en U de la referencia."""
    return 0.09 - 0.52 * np.abs(u) ** 1.8


def lip_lo(u, jaw):
    """Labio inferior: arco profundo; la mandíbula (jaw) lo baja (más en el centro)."""
    return 1.12 - 1.2 * np.abs(u) ** 2.1 + jaw_drop(u, jaw)


def jaw_drop(u, jaw):
    return jaw * 0.62 * (1.0 - 0.55 * np.minimum(np.abs(u), 1.2) ** 2) * sstep(1.12, 0.70, np.abs(u))


def lip_lo0(u):
    return 1.12 - 1.2 * np.abs(u) ** 2.1


# ------------------------------------------------------------------ cámara en perspectiva
def rot(yaw, pitch, roll):
    cy, sy = math.cos(yaw), math.sin(yaw)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cr, sr = math.cos(roll), math.sin(roll)
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rx = np.array([[1, 0, 0], [0, cp, -sp], [0, sp, cp]])
    Rz = np.array([[cr, -sr, 0], [sr, cr, 0], [0, 0, 1]])
    return Rz @ Rx @ Ry


def face_coords(p):
    """Para cada píxel de pantalla devuelve (u, v) del plano de la cara y la validez."""
    X, Y = np.meshgrid(np.arange(W, dtype=np.float32) + 0.5 - W / 2 - p.get('shx', 0.0),
                       np.arange(H, dtype=np.float32) + 0.5 - H / 2 - p.get('shy', 0.0))
    R = rot(p.get('yaw', 0.0), p.get('pitch', 0.0), p.get('roll', 0.0))
    eu, ev, n = R[:, 0], R[:, 1], R[:, 2]
    D = p['D']
    sx, sy = p.get('sx', 0.0), p.get('sy', 0.0)
    u0, v0 = p.get('u0', 0.0), p.get('v0', 0.0)
    P0 = np.array([sx * D / FOCAL, sy * D / FOCAL, D])
    C = P0 - u0 * eu - v0 * ev
    dx, dy = X / FOCAL, Y / FOCAL
    nd = n[0] * dx + n[1] * dy + n[2]
    t = (n @ C) / np.where(np.abs(nd) < 1e-4, 1e-4, nd)
    Px, Py, Pz = t * dx - C[0], t * dy - C[1], t - C[2]
    u = (Px * eu[0] + Py * eu[1] + Pz * eu[2]).astype(np.float32)
    v = (Px * ev[0] + Py * ev[1] + Pz * ev[2]).astype(np.float32)
    return u, v, (t > 0)


# ------------------------------------------------------------------ campo de altura de la cara (volumen)
def height_field(u, v, eye_w):
    """Relieve del rostro: cráneo, cejas enormes, puente de la nariz, cuencas, mejillas, rodillos de los labios."""
    h = 0.55 * np.sqrt(np.clip(1 - (u / head_halfwidth(v)) ** 2, 0, 1)) * sstep(-1.9, -1.2, v)
    for (a, b) in BROWS:
        a = (a[0], a[1] - 0.05 * eye_w)
        b = (b[0], b[1] - 0.06 * eye_w)
        d, _ = seg_dist(u, v, a, b)
        h += 0.30 * sstep(1.0, 0.0, d / BROW_R) ** 0.6
    d, _ = seg_dist(u, v, (0.0, -1.02), (0.0, -0.36))
    h += 0.14 * gauss(d, 0.11)
    for (ex, ey, tilt, side) in EYES:
        ue, ve = u - ex, v - ey
        h -= 0.20 * gauss(np.hypot(ue / 0.30, ve / 0.20), 1.0)       # cuenca hundida
    for sgn in (-1, 1):
        h += 0.17 * gauss(np.hypot((u - sgn * 0.55) / 0.34, (v + 0.12) / 0.30), 1.0)   # pómulos
    # rodillos de los labios
    up = lip_up(u)
    h += 0.16 * gauss(v - (up - 0.07), 0.07) * sstep(1.3, 0.8, np.abs(u))
    h += 0.10 * gauss(v - (lip_lo0(u) + 0.05), 0.07) * sstep(1.3, 0.8, np.abs(u))
    h += 0.10 * gauss(np.hypot(u / 0.5, (v - 1.22) / 0.18), 1.0)   # mentón
    h += 0.028 * (fbm(u, v, 5, 6.0, 3) - 0.5)
    for (wx, wy, r) in WARTS:
        h += 0.11 * gauss(np.hypot(u - wx, v - wy), r * 1.0)
    return h


def shade_height(h, s_eff, light=(-0.35, -0.70, 0.62)):
    gy, gx = np.gradient(h)
    k = s_eff * 0.70
    nx, ny, nz = -gx * k, -gy * k, np.ones_like(h)
    inv = 1.0 / np.sqrt(nx * nx + ny * ny + nz * nz)
    nx, ny, nz = nx * inv, ny * inv, nz * inv
    L = np.array(light, dtype=np.float32)
    L = L / np.linalg.norm(L)
    lam = np.clip(nx * L[0] + ny * L[1] + nz * L[2], 0.0, 1.0)
    sig = max(2.0, 0.05 * s_eff)
    ao = np.clip((ndi.gaussian_filter(h, sig) - h) * 3.2, 0.0, 0.5)
    return lam, ao


# ------------------------------------------------------------------ pintura por capas
def paint(img, m, col, outline=None):
    img[m] = col[m] if col.ndim == 3 else col
    if outline is not None:
        edge = m & ~ndi.binary_erosion(m, iterations=1, border_value=1)
        img[edge] = img[edge] * outline


def rot2(du, dv, a):
    c, s = math.cos(a), math.sin(a)
    return du * c + dv * s, -du * s + dv * c


def render(p):
    """Un fotograma: dict de parámetros -> (índices uint8 HxW, RGB flotante HxWx3 antes de cuantizar)."""
    u, v, valid = face_coords(p)
    D = p['D']
    s_eff = FOCAL / D
    jaw = p.get('jaw', 0.0)
    eye_w = p.get('eyew', 0.0)
    lid = p.get('lid', 0.0)               # 0 = párpado canon, 1 = ojo muy abierto, <0 = entornado
    lookx, looky = p.get('lookx', 0.0), p.get('looky', 0.0)
    seed = p.get('seed', 1)
    lum = p.get('lum', 1.0)

    up = lip_up(u)
    lo0 = lip_lo0(u)
    wj = jaw_drop(u, jaw)
    vm = 0.5 * (up + lo0 + wj)
    vs = np.where(v < vm, v, v - wj)            # coordenada "canon" de la piel (la mandíbula arrastra la parte baja)
    vl = v - wj

    # ---- piel: relieve, luz y color
    h = height_field(u, vs, eye_w)
    # pliegues y arrugas bajan el relieve
    crease = gauss(vs - (up - 0.21), 0.022) * sstep(0.40, 0.72, np.abs(u)) * sstep(1.15, 0.9, np.abs(u))
    wr = np.abs(fbm(u * 1.0, vs * 3.2, seed + 3, 3.0, 3) - 0.5)
    wr = sstep(0.04, 0.0, wr) * sstep(-0.9, -1.15, vs) * 0.5
    h -= 0.08 * crease + 0.018 * wr
    for off, amp in ((-0.34, 0.05), (-0.46, 0.04)):
        h -= amp * gauss(vs - (lip_up(u) + off + 0.10 * np.abs(u)), 0.016) * sstep(0.25, 0.55, np.abs(u)) * sstep(1.1, 0.9, np.abs(u))
    for fy in (-1.18, -1.30):
        h -= 0.05 * gauss(vs - (fy + 0.10 * (u / 0.8) ** 2), 0.014) * sstep(0.9, 0.5, np.abs(u))
    for off, amp in ((0.20, 0.05), (0.42, 0.045), (0.64, 0.035)):
        h -= amp * gauss(vs - (lip_lo0(u) + off - 0.25 * np.abs(u) ** 2), 0.018) * sstep(0.1, 0.4, vs) * sstep(1.0, 0.7, np.abs(u))
    lam, ao = shade_height(h, s_eff)
    ao = np.clip(ao + 0.35 * crease, 0, 0.85)
    tt = np.clip((lam - 0.08) * 1.45, 0, 1)
    g = 1.0 - 0.42 * sstep(0.0, 1.35, vs) + 0.08 * sstep(-0.7, -1.3, vs)
    n1 = fbm(u, vs, seed, 7.0, 3)
    pores = (fbm(u, vs, seed + 9, 34.0, 2) > 0.80).astype(np.float32)
    tt = tt * (1 - ao) * g * (0.88 + 0.24 * n1) - 0.10 * pores
    warm = np.clip(0.05 + 0.32 * sstep(0.1, 1.25, vs) + 0.28 * sstep(0.9, 1.2, np.abs(u)), 0, 1)[..., None]
    skin = ramp_color(SKIN, tt) * (1 - warm) + ramp_color(SKIN_WARM, tt) * warm
    img = skin.copy()

    # ---- crestas verticales del labio superior (como dientes de calavera, en la referencia)
    band_top = up - 0.235 + 0.02 * np.abs(u)
    band_bot = up - 0.085
    in_band = (vs > band_top) & (vs < band_bot) & (np.abs(u) < 0.66)
    ph = u * (2 * math.pi / 0.082) + 1.1 * np.sin(vs * 14 + u * 5)
    groove = np.sin(ph)
    bandf = in_band.astype(np.float32) * sstep(0.7, 0.5, np.abs(u))
    gdark = (groove < -0.35) & in_band
    glite = (groove > 0.5) & in_band
    img[gdark] = img[gdark] * 0.55
    img[glite] = np.minimum(img[glite] * 1.12 + 6, 255)

    for bi, (a, b) in enumerate(BROWS):
        a2 = (a[0], a[1] - 0.05 * eye_w)
        b2 = (b[0], b[1] - 0.06 * eye_w)
        d, t = seg_dist(u, vs, a2, b2)
        linev = a2[1] + (b2[1] - a2[1]) * t
        cs = np.clip((vs - linev) / BROW_R, -1.2, 1.2)           # -1 arriba, +1 abajo
        mb = d < BROW_R * (1.0 - 0.18 * t * 0 )
        tcb = np.clip(0.80 - 0.34 * np.clip(cs, -1, 1) + 0.10 * (fbm(u, vs, seed + 60 + bi, 12.0, 3) - 0.5) - 0.10 * t * (1 - 1) , 0, 1)
        tcb *= (1.0 - 0.22 * sstep(0.55, 1.0, cs))
        colb = ramp_color(SKIN, tcb) * (1 - warm * 0.7) + ramp_color(SKIN_WARM, tcb) * (warm * 0.7)
        paint(img, mb, colb, outline=0.42)
        crest = mb & (np.abs(cs + 0.55) < 0.07)
        img[crest] = np.minimum(img[crest] * 1.12 + 5, 255)
    # ---- pliegue/rodillo bajo cada ceja y cuencas: oscurecer la sombra bajo la ceja
    for (a, b) in BROWS:
        d, _ = seg_dist(u, vs, (a[0], a[1] + 0.12), (b[0], b[1] + 0.10))
        sh = gauss(d, 0.05) * 0.50
        img *= (1 - sh)[..., None]

    # ---- verrugas ámbar
    for (wx, wy, r) in WARTS:
        d = np.hypot(u - wx, vs - wy) / r
        m = d < 1.15
        if not m.any():
            continue
        tw = np.clip(0.55 + 0.5 * (1 - d) * 0.8 + (lam - 0.6) * 0.9, 0, 1)
        col = ramp_color(WART, tw)
        paint(img, m, col, outline=0.55)
        hi = (np.hypot(u - wx + r * 0.35, vs - wy + r * 0.35) / r < 0.28) & m
        img[hi] = ramp_color(WART, np.full(hi.sum(), 0.97))

    # ---- llagas rojizas
    for k, (sx_, sy_, r) in enumerate(SORES):
        d = np.hypot((u - sx_) / 1.6, vs - sy_) / (r * 0.62)
        nz = fbm(u, vs, seed + 40 + k, 30.0, 2)
        m = d < (0.7 + 0.8 * nz)
        if m.any():
            tsore = np.clip(0.2 + 0.5 * (1 - d) + 0.2 * nz, 0, 1)
            paint(img, m, ramp_color(SORE, tsore))

    # ---- ojos
    eye_masks = []
    for (ex, ey, tilt, side) in EYES:
        ue, ve = rot2(u - ex, vs - ey, tilt * side * -1.0 if False else tilt)
        ry = EYE_RY * (1.0 + 0.7 * eye_w)
        rx = EYE_RX * (1.0 + 0.12 * eye_w)
        ell = (ue / rx) ** 2 + (ve / ry) ** 2
        # sombra de la cuenca (alrededor del ojo)
        ring = gauss(np.sqrt(np.maximum(ell, 0)) - 1.0, 0.55) * 0.72
        img *= (1 - ring * (ell > 1))[..., None]
        eye = ell < 1.0
        # párpado superior pesado (cae hacia fuera)
        lid_line = -ry * (0.30 - 0.75 * lid) + 0.14 * side * (ue / rx) * (-1) * 0.0 + 0.10 * (ue / rx) * -side * 0.0
        outer = (ue / rx) * (-1.0 if side < 0 else 1.0)
        lid_line = lid_line + 0.10 * ry * outer * 1.6
        lidm = eye & (ve < lid_line)
        eyeball = eye & ~lidm
        # esclerótica roja con venas y borde oscuro
        te = np.clip(0.62 - 0.45 * ell ** 1.2 + 0.12 * (fbm(u, vs, seed + 7, 26.0, 3) - 0.5), 0, 1)
        vein = (np.abs(fbm(ue * 1.0, ve * 1.0, seed + 5, 22.0, 2) - 0.5) < 0.018) & (ell > 0.25)
        te = np.where(vein, te * 0.55, te)
        col = ramp_color(EYE, te)
        paint(img, eyeball, col, outline=0.4)
        # iris/pupila
        pcx, pcy = ex + lookx * 0.075, ey + looky * 0.055
        pr = np.hypot(u - pcx, vs - pcy)
        iris = eyeball & (pr < 0.082)
        paint(img, iris, ramp_color(EYE, np.clip(0.30 + 0.5 * (pr / 0.082) + 0.1 * np.sin(np.arctan2(vs - pcy, u - pcx) * 14), 0, 1)))
        pupil = eyeball & (pr < 0.042 * (1 + 0.3 * eye_w))
        img[pupil] = np.array(EXTRA[1], dtype=np.float32)
        gl = eyeball & (np.hypot(u - pcx - 0.016, vs - pcy + 0.018) < 0.011)
        img[gl] = np.array(EXTRA[3], dtype=np.float32)
        # párpado como piel oscura y gruesa con borde
        lcol = ramp_color(SKIN, np.clip(0.24 + 0.2 * (lam - 0.5), 0, 1)) * 0.8
        paint(img, lidm, lcol, outline=0.35)
        eye_masks.append((eye, ue, ve, ell, ex, ey, side))

    # ---- lágrimas: escalera ancha de barras oscuras bajo cada ojo (como la referencia) + regueros
    for (eye, ue, ve, ell, ex, ey, side) in eye_masks:
        taper = 0.205 - 0.45 * np.maximum(vs - ey - 0.08, 0)
        region = (np.abs(u - (ex + 0.02 * side)) < taper) & (vs > ey + 0.085) & (vs < ey + 0.30) & ~eye
        k = (vs - ey - 0.085) / 0.040 + 0.35 * np.sin(u * 23 + side)
        fr = np.mod(k, 1.0)
        bar = (fr < 0.62) & region
        tc = np.clip(0.55 - 0.45 * fr + 0.25 * (lam - 0.5), 0, 1)
        paint(img, bar, ramp_color(TEAR, tc), outline=0.55)
        for j, du_ in enumerate((-0.17, 0.0, 0.17)):
            x0 = ex + (du_ + 0.02) * side
            dd, _ = seg_dist(u, vs, (x0, ey + 0.20), (x0 + 0.012 * side, ey + 0.38 + 0.04 * j))
            m = (dd < 0.009) & ~eye
            paint(img, m, ramp_color(TEAR, np.full((H, W), 0.25, dtype=np.float32)))
            tip = (np.hypot(u - (x0 + 0.012 * side), vs - (ey + 0.38 + 0.04 * j)) < 0.017) & ~eye
            paint(img, tip, ramp_color(TEAR, np.full((H, W), 0.45, dtype=np.float32)), outline=0.5)

    # ---- nariz de calavera: dos ranuras
    for (nx_, ny_, tl) in NOSTRILS:
        a, b = rot2(u - nx_, vs - ny_, tl)
        m = (a / 0.050) ** 2 + (b / 0.112) ** 2 < 1
        rim = (a / 0.072) ** 2 + (b / 0.138) ** 2 < 1
        img[rim & ~m] *= 0.55
        paint(img, m, np.array(EXTRA[2], dtype=np.float32))

    # ---- boca: región interior, labios y dientes
    inside = (v > up) & (vl < lo0) & (np.abs(u) < 1.13)
    lipw = 0.070
    rim_up = (v > up - lipw * 0.6) & (v <= up + 0.012) & (np.abs(u) < 1.1)
    rim_lo = (vl >= lo0 - 0.012) & (vl < lo0 + lipw) & (np.abs(u) < 1.1)
    # interior
    dl = np.maximum(v - up, 0)
    dl2 = np.maximum(lo0 - vl, 0)
    glow = 0.22 * np.exp(-dl / 0.07) + 0.20 * np.exp(-dl2 / 0.08) + 0.06 * fbm(u, v, seed + 12, 6.0, 3)
    maw = ramp_color(MAW, np.clip(glow * 1.5, 0, 1))
    # lengua
    tcx, tcy = 0.0, 0.70
    te_ = np.hypot(u / 0.50, (vl - tcy) / 0.26)
    tongue = inside & (te_ < 1)
    tl = np.clip(0.55 - 0.45 * te_ + 0.35 * (lam * 0 + 0.5) + 0.08 * np.sin(u * 60) * (te_ < 0.8) - 0.12 * ((vl - tcy) / 0.26 > 0.3), 0, 1)
    tcol = ramp_color(MAW, np.clip(0.30 + 0.55 * np.clip(1 - te_, 0, 1) ** 0.7 - 0.22 * gauss(u, 0.018) - 0.10 * (te_ > 0.9), 0, 1))
    tcol = tcol * (0.9 + 0.2 * (fbm(u, vl, seed + 21, 24.0, 3) - 0.5) * 2)[..., None]
    maw[tongue] = tcol[tongue]
    paint(img, inside, maw)
    # labios
    lcol_up = ramp_color(LIP, np.clip(0.62 - (up - v) / lipw * 0.35 + 0.15 * (fbm(u, v, seed + 15, 18.0, 3) - 0.5), 0, 1))
    lcol_lo = ramp_color(LIP, np.clip(0.50 + (lo0 - vl) / lipw * 0.25 + 0.15 * (fbm(u, vl, seed + 16, 18.0, 3) - 0.5), 0, 1))
    paint(img, rim_up, lcol_up, outline=0.5)
    paint(img, rim_lo & ~rim_up, lcol_lo, outline=0.5)

    # dientes superiores (de más lejanos a centrales)
    tl_scale = p.get('teeth', 1.0)
    idx = sorted(range(N_UP), key=lambda i: -abs(i - (N_UP - 1) / 2))
    for i in idx:
        ui = -0.86 + 1.72 * i / (N_UP - 1)
        m_ = (lip_up(ui + 0.01) - lip_up(ui - 0.01)) / 0.02
        L = UP_L * (1.0 - 0.52 * (ui / 0.9) ** 2) * (1.0 + 0.08 * math.sin(i * 2.1)) * tl_scale
        w = 0.062 * (1.0 - 0.18 * abs(ui))
        ax = -0.5 * m_ / math.hypot(1.0, 0.5 * m_)
        ay = 1.0 / math.hypot(1.0, 0.5 * m_)
        pu, pv = u - ui, v - lip_up(ui) + 0.01
        along = pu * ax + pv * ay                  # profundidad a lo largo del eje
        across = pu * ay - pv * ax                 # ancho
        hw = w * np.clip(1 - along / L, 0, 1) ** 0.46
        m = (along > -0.012) & (along < L) & (np.abs(across) < hw) & inside
        if not m.any():
            continue
        ur = np.clip(across / np.maximum(hw, 1e-4), -1, 1)
        tcl = 0.78 - 0.30 * (ur * 0.7 + 0.45) ** 2 * 0 - 0.22 * np.clip(ur, -1, 1) + 0.12 * np.clip(along / L, 0, 1) - 0.32 * (along < 0.05).astype(np.float32)
        tcl = np.clip(tcl, 0, 1) * (1 - 0.35 * (np.abs(ur) > 0.82))
        paint(img, m, ramp_color(TOOTH, tcl), outline=0.38)

    # dientes inferiores (finos, hacia arriba)
    idx = sorted(range(N_LO), key=lambda i: -abs(i - (N_LO - 1) / 2))
    for i in idx:
        ui = -0.80 + 1.60 * i / (N_LO - 1)
        base = lip_lo0(ui)
        L = LO_L * (1.0 - 0.45 * (ui / 0.85) ** 2) * (1.0 + 0.10 * math.sin(i * 1.7)) * tl_scale
        w = 0.040
        pu, pv = u - ui, vl - base - 0.01
        along = -pv
        hw = w * np.clip(1 - along / L, 0, 1) ** 0.7
        m = (along > -0.01) & (along < L) & (np.abs(pu) < hw) & inside
        if not m.any():
            continue
        ur = np.clip(pu / np.maximum(hw, 1e-4), -1, 1)
        tcl = np.clip(0.62 - 0.2 * ur + 0.15 * np.clip(along / L, 0, 1), 0, 1) * (1 - 0.35 * (np.abs(ur) > 0.8))
        paint(img, m, ramp_color(TOOTH, tcl), outline=0.38)

    # ---- hilos de baba brillantes colgando de los colmillos
    if jaw > 0.5:
        for q in range(7):
            ui = -0.62 + 0.21 * q + 0.04 * math.sin(q * 3.7)
            top = lip_up(ui) + 0.20 * (1.0 - 0.52 * (ui / 0.9) ** 2)
            ln = (0.18 + 0.30 * min(jaw, 1.6)) * (0.6 + 0.4 * math.sin(q * 2.3 + 1.0) ** 2)
            dd, tt2 = seg_dist(u, v, (ui, top), (ui + 0.01 * (q % 3 - 1), top + ln))
            m = (dd < 0.0075) & inside
            img[m] = np.array(EXTRA[3], dtype=np.float32) * (0.55 + 0.45 * np.clip(1 - tt2[m] * 0.5, 0, 1))[..., None]
            drop = (np.hypot(u - (ui + 0.01 * (q % 3 - 1)), v - (top + ln)) < 0.016) & inside
            img[drop] = np.array(EXTRA[4], dtype=np.float32) * 0.85
    # ---- silueta de la cabeza: negro fuera, bordes en sombra
    rr = np.abs(u) / head_halfwidth(vs if False else v)
    head = (rr < 1.0) & valid
    edge = sstep(1.0, 0.45, rr)
    img *= (0.18 + 0.82 * edge)[..., None]
    img = 255.0 * np.power(np.clip(img, 0, 255) / 255.0, 1.28)
    img[~head] = np.array(EXTRA[1], dtype=np.float32)
    img *= lum
    return img


def quantize(img, amp=13.0):
    h, w, _ = img.shape
    b = np.tile(BAYER, (h // 4 + 1, w // 4 + 1))[:h, :w][..., None] * amp
    x = np.clip(img + b, 0, 255)
    out = np.zeros((h, w), dtype=np.uint8)
    best = np.full((h, w), 1e18, dtype=np.float32)
    for i, c in enumerate(PAL_ARR):
        d = ((x - c) ** 2).sum(axis=2)
        m = d < best
        best[m] = d[m]
        out[m] = i
    return out


def to_rgb(idx):
    return PAL_ARR[idx].astype(np.uint8)


if __name__ == '__main__':
    import sys
    from PIL import Image
    p = dict(D=FOCAL / 134.0, seed=2)
    img = render(p)
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8)).save('/home/claude/f0_float.png')
    q = quantize(img)
    Image.fromarray(to_rgb(q)).resize((W * 2, H * 2), Image.NEAREST).save('/home/claude/f0_q.png')
    print('ok', len(PALETTE), 'colores')
