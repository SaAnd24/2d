"""ARMARIO v0.10.1: arte en primera persona de los brazos del niño escondido (composición PROPIA del escondite).

NO reutiliza la pose ni el encuadre de la escena de Ranita (manos que sostienen desde abajo con los pulgares delante):
aquí los ANTEBRAZOS cruzan el pecho vistos desde los ojos del niño, con las mangas del suéter en las esquinas inferiores y
las manos aferrando por los lados. Dos capas:

  hug_self   : sin peluche. Los brazos se cruzan en X sobre el pecho (cada mano agarra el hombro contrario).
  hug_plush  : con Ranita. Los antebrazos suben por los lados y se cruzan por DELANTE de ella apretándola; las manos
               aprietan sus costados. El peluche NO se dibuja aquí: el juego dibuja la capa 'plush' del arte canónico
               (ConversationArtData) detrás de esta capa, menor y ladeada, para que sea la misma Ranita.

Salida: app/.../pixel/ClosetArtData.kt (índices de paleta, zlib + base64, 0 = transparente) y una vista previa PNG.
Dependencias (solo del generador): numpy, scipy, Pillow.
"""
import base64
import math
import os
import sys
import zlib

import numpy as np
from PIL import Image
from scipy import ndimage as ndi

W, H = 640, 360

SKIN = [(60, 36, 34), (110, 70, 56), (158, 104, 78), (204, 142, 104), (236, 180, 138), (250, 214, 176)]
SLEEVE = [(46, 24, 10), (96, 50, 16), (150, 82, 24), (196, 110, 36), (232, 146, 58)]
NAIL = [(150, 110, 96), (222, 186, 170)]
PALETTE = [(0, 0, 0)] + [c for r in (SKIN, SLEEVE, NAIL) for c in r] + [(10, 6, 8)]
IDX = {}
_i = 1
for nm, r in (('skin', SKIN), ('sleeve', SLEEVE), ('nail', NAIL)):
    IDX[nm] = _i
    _i += len(r)
IDX['dark'] = _i


def ramp(arr, t):
    a = np.array(arr, dtype=np.float32)
    n = len(a) - 1
    x = np.clip(t, 0, 1) * n
    i0 = np.clip(np.floor(x).astype(np.int32), 0, n - 1)
    f = (x - i0)[..., None]
    return a[i0] * (1 - f) + a[i0 + 1] * f


def vnoise(x, y, seed):
    rng = np.random.RandomState(seed)
    g = rng.rand(int(y.max()) + 3, int(x.max()) + 3)
    return ndi.map_coordinates(g, [y, x], order=1)


class Canvas:
    def __init__(self):
        self.Y, self.X = np.mgrid[0:H, 0:W].astype(np.float32)
        self.h = np.zeros((H, W), dtype=np.float32)
        self.mat = np.zeros((H, W), dtype=np.int8)      # 0 nada, 1 piel, 2 manga, 3 uña
        self.z = np.full((H, W), -1.0, dtype=np.float32)  # orden de dibujo: lo último tapa

    def cap(self, p0, p1, r0, r1, mat, order):
        dx, dy = p1[0] - p0[0], p1[1] - p0[1]
        L2 = dx * dx + dy * dy + 1e-6
        t = np.clip(((self.X - p0[0]) * dx + (self.Y - p0[1]) * dy) / L2, 0, 1)
        px, py = p0[0] + t * dx, p0[1] + t * dy
        r = r0 + (r1 - r0) * t
        d = np.hypot(self.X - px, self.Y - py) / np.maximum(r, 1e-3)
        m = d < 1.0
        hh = r * np.sqrt(np.clip(1 - d * d, 0, 1))
        self.stamp(m, hh, mat, order)

    def ell(self, c, rx, ry, ang, mat, order, hz=1.0):
        ca, sa = math.cos(ang), math.sin(ang)
        u = (self.X - c[0]) * ca + (self.Y - c[1]) * sa
        v = -(self.X - c[0]) * sa + (self.Y - c[1]) * ca
        d = np.hypot(u / rx, v / ry)
        m = d < 1.0
        self.stamp(m, hz * min(rx, ry) * np.sqrt(np.clip(1 - d * d, 0, 1)), mat, order)

    def stamp(self, m, hh, mat, order):
        m = m & (order >= self.z)
        self.h[m] = hh[m]
        self.mat[m] = mat
        self.z[m] = order


def arm(c, start, elbow, wrist, r_arm, sleeve_end, order):
    """Brazo: manga desde el borde hasta el codo (y un poco más), antebrazo de piel hasta la muñeca."""
    c.cap(start, elbow, r_arm * 1.25, r_arm * 1.15, 2, order)
    mid = (elbow[0] + (wrist[0] - elbow[0]) * sleeve_end, elbow[1] + (wrist[1] - elbow[1]) * sleeve_end)
    c.cap(elbow, mid, r_arm * 1.15, r_arm * 1.08, 2, order)
    c.cap(mid, wrist, r_arm * 0.92, r_arm * 0.62, 1, order + 0.1)


def hand(c, wrist, ang, size, order, grip=0.8, flip=1):
    """Mano que AGARRA: palma + cuatro dedos curvados por delante del objeto/hombro + pulgar al otro lado."""
    ux, uy = math.cos(ang), math.sin(ang)
    px, py = -uy * flip, ux * flip
    pc = (wrist[0] + ux * size * 0.55, wrist[1] + uy * size * 0.55)
    c.ell(pc, size * 0.62, size * 0.52, ang, 1, order + 0.2, hz=0.9)
    for i, off in enumerate((-1.5, -0.5, 0.5, 1.5)):
        b = (pc[0] + px * off * size * 0.30 + ux * size * 0.35, pc[1] + py * off * size * 0.30 + uy * size * 0.35)
        ln = size * (0.80 - 0.07 * abs(off))
        m = (b[0] + ux * ln * 0.6 + px * grip * size * 0.10 * (off + 0.2), b[1] + uy * ln * 0.6 + py * grip * size * 0.10 * (off + 0.2))
        t = (m[0] + (-uy * 0.0 + px * grip * ln * 0.55) * 0.9 + ux * ln * 0.15, m[1] + (py * grip * ln * 0.55) * 0.9 + uy * ln * 0.15)
        c.cap(b, m, size * 0.17, size * 0.145, 1, order + 0.3 + i * 0.01)
        c.cap(m, t, size * 0.145, size * 0.115, 1, order + 0.3 + i * 0.01)
        c.ell(t, size * 0.10, size * 0.085, ang, 3, order + 0.4 + i * 0.01, hz=0.5)
    th0 = (pc[0] - px * size * 0.5, pc[1] - py * size * 0.5)
    th1 = (th0[0] + ux * size * 0.55 - px * size * 0.15, th0[1] + uy * size * 0.55 - py * size * 0.15)
    c.cap(th0, th1, size * 0.18, size * 0.13, 1, order + 0.35)


def render(c, seed):
    hh = ndi.gaussian_filter(c.h, 0.9)
    gy, gx = np.gradient(hh)
    k = 0.55
    nx, ny, nz = -gx * k, -gy * k, np.ones_like(hh)
    inv = 1 / np.sqrt(nx * nx + ny * ny + nz * nz)
    L = np.array([-0.30, -0.78, 0.55])
    lam = np.clip((nx * L[0] + ny * L[1] + nz * L[2]) * inv, 0, 1)
    ao = np.clip((ndi.gaussian_filter(hh, 7) - hh) * 0.05, 0, 0.55)
    n1 = vnoise(c.X / 6, c.Y / 6, seed) * 0.5 + vnoise(c.X / 2, c.Y / 2, seed + 1) * 0.5
    t = np.clip((lam - 0.12) * 1.35, 0, 1) * (1 - ao) * (0.86 + 0.16 * n1)
    col = np.zeros((H, W, 3), dtype=np.float32)
    for mat, r in ((1, SKIN), (2, SLEEVE), (3, NAIL)):
        m = c.mat == mat
        col[m] = ramp(r, t if mat != 3 else np.clip(t * 1.1, 0, 1))[m]
    # sombra de contacto/arrugas en las mangas
    sl = c.mat == 2
    fold = np.sin((c.X * 0.35 + c.Y * 0.22) + n1 * 5) > 0.7
    col[sl & fold] *= 0.78
    solid = c.mat > 0
    edge = solid & ~ndi.binary_erosion(solid, iterations=1, border_value=0)
    edge2 = (c.z[:, :] != ndi.maximum_filter(c.z, size=3)) & solid
    col[edge | edge2] *= 0.35
    return col, solid


def quantize(col, solid):
    pal = np.array(PALETTE, dtype=np.float32)
    out = np.zeros((H, W), dtype=np.uint8)
    best = np.full((H, W), 1e18, dtype=np.float32)
    bay = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]], dtype=np.float32) / 16 - 0.5
    x = np.clip(col + np.tile(bay, (H // 4, W // 4))[..., None] * 9, 0, 255)
    for i in range(1, len(pal)):
        d = ((x - pal[i]) ** 2).sum(axis=2)
        m = d < best
        best[m] = d[m]
        out[m] = i
    out[~solid] = 0
    return out


def hug_self():
    c = Canvas()
    # brazo izquierdo del niño (queda DEBAJO): sube desde la esquina inferior izquierda y cruza hacia el hombro derecho
    arm(c, (-40, 400), (150, 292), (336, 190), 25, 0.35, 1)
    hand(c, (336, 190), math.radians(-28), 40, 1.5, grip=0.7, flip=1)
    # brazo derecho (ENCIMA): desde la esquina inferior derecha cruza hacia el hombro izquierdo
    arm(c, (680, 410), (490, 296), (292, 196), 25, 0.35, 4)
    hand(c, (292, 196), math.radians(208), 40, 4.5, grip=0.7, flip=-1)
    return c


def hug_plush():
    c = Canvas()
    # los antebrazos suben por los lados y se cruzan DELANTE del peluche, apretándolo; manos aferrando los costados
    arm(c, (-30, 380), (96, 290), (300, 250), 24, 0.30, 1)
    hand(c, (300, 250), math.radians(-12), 38, 1.5, grip=0.9, flip=1)
    arm(c, (670, 384), (546, 290), (340, 254), 24, 0.30, 4)
    hand(c, (340, 254), math.radians(192), 38, 4.5, grip=0.9, flip=-1)
    return c


def build():
    layers = {}
    for name, fn, seed in (('hug_self', hug_self, 5), ('hug_plush', hug_plush, 9)):
        c = fn()
        col, solid = render(c, seed)
        layers[name] = quantize(col, solid)
        print(name, 'ok', flush=True)
    return layers


def encode(idx):
    z = zlib.compress(idx.astype(np.uint8).tobytes(), 9)
    b64 = base64.b64encode(z).decode('ascii')
    return [b64[i:i + 60000] for i in range(0, len(b64), 60000)]


def emit(layers, path):
    L = ['package com.terror2d.pixel', '', '/**',
         ' * DATOS GENERADOS por tools/sprite_gen/closet_art.py. NO editar a mano: edita el generador.',
         ' * Arte en primera persona del ESCONDITE (v0.10.1): brazos del niño abrazando. Capas de %dx%d (1 px = 0,5 px lógicos),' % (W, H),
         ' * índices de paleta (0 = transparente) en zlib + base64. Decodificación: [ScreamerCodec.decode].', ' */',
         'object ClosetArtData {', f'    const val WIDTH = {W}', f'    const val HEIGHT = {H}',
         '    val PALETTE: IntArray = intArrayOf(' + ', '.join(('0x00000000.toInt()' if i == 0 else '0xFF%02X%02X%02X.toInt()' % c) for i, c in enumerate(PALETTE)) + ')']
    for name, idx in layers.items():
        const = name.upper()
        L.append('    val %s: Array<String> = arrayOf(%s)' % (const, ', '.join('"%s"' % s for s in encode(idx))))
    L.append('}')
    open(path, 'w', encoding='utf-8').write('\n'.join(L) + '\n')


def preview(layers, path):
    pal = np.array(PALETTE, dtype=np.uint8)
    tiles = []
    for name, idx in layers.items():
        rgb = pal[idx]
        bg = np.full_like(rgb, (14, 10, 16))
        m = (idx > 0)[..., None]
        tiles.append(Image.fromarray(np.where(m, rgb, bg).astype(np.uint8)))
    sheet = Image.new('RGB', (W * len(tiles), H))
    for i, t in enumerate(tiles):
        sheet.paste(t, (i * W, 0))
    sheet.save(path)


if __name__ == '__main__':
    layers = build()
    out = os.path.join(os.path.dirname(__file__), '..', '..', 'app', 'src', 'main', 'java', 'com', 'terror2d', 'pixel', 'ClosetArtData.kt')
    emit(layers, os.path.abspath(out))
    preview(layers, sys.argv[1] if len(sys.argv) > 1 else '/home/claude/closet_preview.png')
    print('ClosetArtData.kt', os.path.getsize(out), 'bytes')
