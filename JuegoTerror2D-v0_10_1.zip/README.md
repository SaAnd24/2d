# MYMom — v0.7 — El peluche y el sistema de audio procedural

Juego de terror psicológico 2D para Android. Kotlin + Android Canvas, motor propio, 100 % offline
(sin Internet, sin backend, sin assets descargados). Resolución lógica 320×180, landscape, 16:9.

## Versión actual: v0.10.1 (ver "v0.10.1" al final)
Extiende v0.6 sin reescribirla (todo lo de v0.6 y v0.4 sigue ahí, más abajo). **Dirección narrativa completa en
[`docs/DESIGN_BIBLE.md`](docs/DESIGN_BIBLE.md)** (canon, arco, reglas, los dos mundos).

### Novedades de v0.7 (compañero persistente + conversaciones + identidad sonora)
0.7 no es una colección de funciones: es el momento en que MYMom adquiere **un compañero persistente, conversaciones
reales e identidad sonora propia**. El mundo sigue siendo de papel y crayón y el protagonista pixel art de 96×128.

**Compañero (peluche) — `companion/`**
- **Dos espacios conceptuales**: **COMPANION SLOT** (`Inventory.companion`, reservado al peluche, no consume las manos,
  nada lo reemplaza) y **HAND SLOT** (`Inventory.held`, un único objeto físico: vaso, cajas de medicina, futuros).
  El inventario de 0.5 no cambia: se **extiende** (`ItemDef.companion`, `Inventory.add` rechaza compañeros).
- `CompanionState`: `NOT_FOUND → ON_FLOOR → (PICKUP) → ON_BACK ↔ TALKING`. `HandState`: `EMPTY, HOLDING_WATER,
  HOLDING_MEDICINE, HOLDING_OBJECT` (`Inventory.handState`). Añadir estados no obliga a rehacer nada.
- Al recogerlo va **a la espalda** del niño (`Player.companionItemId`): MISMO sprite 32×32 y MISMA escala que siempre,
  dibujado detrás del cuerpo, con la **misma iluminación** que el niño, balanceo sutil al caminar (sube/baja con los
  pasos, se rezaga al arrancar, respira apenas quieto) y posición pegada a la cabeza de cada pose. No se teletransporta.
- **Diseño**: sigue siendo claramente una ranita de peluche infantil, pero **ligeramente incómoda desde su primera
  aparición**: cabeza grande y ancha, ojos saltones y desiguales con **pupilas pequeñas**, **sonrisa cosida demasiado
  ancha** (con un hilo suelto), asimetrías, costuras visibles, remiendo, tela con trama, colores apagados. Sin sangre,
  ojos rojos ni deformaciones. (`tools/sprite_gen/items.py` → `SpriteData.kt`.)

**HABLAR y conversación — `conversation/`**
- Con el peluche `ON_BACK` y **las manos vacías** aparece el botón contextual **«HABLAR CON RANITA»** (segundo botón sobre el
  de acción; tecla T/Q). Con un objeto en las manos no aparece: primero hay que dejarlo.
- `ConversationView` (primera persona, mismo patrón que `FirstPersonView`): fundido a **negro casi absoluto**; solo las
  **dos manos del niño sosteniendo el peluche**. Sin habitación, sin HUD, sin caja de texto del mundo.
- **Arte hiperdetallado** (`tools/sprite_gen/conversation_art.py` → `ConversationArtData.kt`): 640×360 (1 px de arte =
  0,5 px lógicos), 176 colores, sombreado por mapa de alturas (dedos separados con 3 falanges, uñas con cutícula y
  brillo, nudillos, arrugas, tendones, pecas, un rasguño, una marca de bolígrafo, una uña mordida, manga de lana; peluche
  con trama, fibras, costuras, ojos de plástico con reflejo, parche y sombras de contacto). Se decodifica al entrar y
  se **libera** al salir.
- **Manos vivas, peluche inmóvil**: respiración y temblor por dedo, con `breathingIntensity` y `handTremorIntensity`
  configurables por escena (`ConversationView.setHandState`, `ConversationLine.tremor/breathing`). El peluche **no**
  parpadea, no mueve pupilas, boca, cabeza ni respira: la inquietud sale de que el niño está vivo y nervioso.
- **Sistema de conversaciones** (datos, no código): `ConversationDef` = trigger, condición, líneas, perfil de voz,
  intensidad, pausa previa, transición, cooldown, repetible, prioridad, contexto (mundo). `ConversationSystem` gestiona
  cola, calma, condición y «solo una vez». Las definiciones viven en `Conversations.kt`.
- **Triggers temporales (solo para demostrar el sistema)**: **A** `WATER_DELIVERED` (tras entregar el agua a mamá, pausa,
  escena breve «¿Ya terminaste?»); **B** `MEDICINE_PUZZLE_COMPLETED` (sonido suave → silencio → respiración/temblor →
  «Sabía que eres un niño especial.»). Si el peluche aún no va a la espalda o hay un objeto en las manos, esperan.
  Se sustituyen por condiciones narrativas cambiando definiciones, sin tocar el sistema.

**Audio procedural — `audio/`** (sin MP3/WAV: el APK no incluye ningún archivo de audio)
```
GAMEPLAY → EVENTO → AudioDirector → AudioPort (AudioEngine) → cola de comandos → hilo de audio → SÍNTESIS
AudioEngine ├─ VoiceSynth    perfiles CHILD, MOTHER, FROG (+ DOCTOR, NEIGHBOR, MONSTER preparados)
            ├─ SfxSynth      pasos (WOOD/TILE/GROUND/HOSPITAL), recoger/dejar, interacción, papel, vaso, agua,
            │                medicina, puerta, respiración, latido, tela, peluche…
            ├─ MusicSynth    secuenciador por capas (PAD, CHILD, FROG, TENSION): HOME, CHILD_THEME, FROG_SCENE, TENSION, SILENCE
            ├─ AmbienceSynth viento, zumbido de casa, reloj, tuberías, electricidad, crujidos, respiración
            └─ AudioEffects  reverb, eco, resonancia, distorsión suave, paso-bajo; perfiles de MUNDO NORMAL / TRAUMA
```
- `AudioPort` es la API de alto nivel (`playVoice`, `playSfx`, `playMusic`, `setAmbience`, `setWorld`, `duck`).
  `GameState.audio` la expone; el GameLogic no contiene síntesis. `AudioDirector` es el único sitio que sabe qué suena
  con cada evento (`FOOTSTEP`, `ON_ITEM_PICKED` ≡ OBJECT_PICKED_UP, `ON_ITEM_GIVEN/PLACED` ≡ OBJECT_DROPPED, `WATER_DELIVERED`,
  `MEDICINE_PUZZLE_COMPLETED`, `FROG_TALK`, `COMPANION_PICKED_UP`, `DIALOGUE_LINE`, `CONVERSATION_*`…).
- **Voz**: balbuceo de sílabas no lingüísticas + «mmm» (`HUM`) + «hm» (`HM`); oscilador → formantes de vocal → bitcrusher
  → envolvente ADSR; pitch, velocidad, duración, intensidad, timbre, vibrato, ruido de aire y envíos de reverb/eco por
  perfil y por emoción. El texto no se pronuncia: la voz es feedback emocional. La del niño es suave, corta y aguda;
  la de mamá, cálida y más grave; la de la rana, artificial, pequeña y algo extraña (FM + bitcrusher suave + eco), **no** terrorífica.
- **Motor**: PCM 16 bit mono 44,1 kHz en `AudioTrack` (modo STREAM, escritura bloqueante **solo en su hilo**), bloques de 512
  muestras, 56 voces prealocadas (sin objetos por muestra, voz robada si se llena), limitador final y protección NaN.
  El hilo del juego solo encola comandos. Arranca en `onResume`, se detiene y libera la salida en `onPause`, `release()` en `onDestroy`.
- **NORMAL / TRAUMA**: mismos eventos con otros parámetros (`WorldAudioProfile`: tono, reverb, eco, distorsión, brillo, resonancia).
  `GameState.worldMode` ya se refleja en el audio; todavía no existe ningún mapa Trauma.

**Deliberadamente fuera de 0.7**: criatura, persecución, muerte, desaparición de mamá, espejo, mundo Trauma, hospital,
parque, cementerio, transformación o rotura del peluche, sangre, explicación de la enfermedad, personalidad completa del
peluche y memoria narrativa. Tampoco se rehacen las animaciones del protagonista (caminar, idle, pickup, hurt, hide,
flashback) ni se tocan `Player.paperEffects` (conservado sin activar nada).

### Novedades de v0.6 (puzzle de medicamentos + correcciones visuales)
- **Protagonista a 96×128 píxeles internos** (antes 48×64), dibujado a **escala 0.5**: ocupa la misma silueta en pantalla
  (~50 px lógicos) con el DOBLE de detalle. Pixel art real, `nearest-neighbor`, sin blur ni antialiasing, 38 colores.
  Mechones de pelo, oreja, rubor y marca de la mejilla, bufanda con vueltas de lana, suéter con trama, pliegues, línea roja
  con relieve y dobladillo acanalado, manos con dedos, pantalón con rodilla y dobladillo, zapatillas con suela, puntera y cordones.
- **Cara intercambiable** (`FaceLayer`): ojos (`OPEN/HALF/CLOSED/WIDE/DOWN`: esclerótica, iris, pupila, brillo, párpados, cejas)
  y boca (`NEUTRAL/SMILE/SAD/OPEN/SPEAK`) son parches sobre la cabeza de cada pose. **Parpadea** solo (intervalo variable
  determinista) y la boca se mueve cuando el niño habla. HURT cierra los ojos, HIDE los abre mucho, PICKUP mira al suelo.
- **Objetos bien sujetos**: el objeto se dibuja entre el cuerpo y la **mano delantera** (capa de primer plano), así los dedos
  quedan por encima del vaso, las cajas y el peluche.
- **Escala canónica única** (`ItemSprites`): ranita 32×32 px = 16×16 lógicos, caja 16×22 = 8×11, vaso 14×22 = 7×11.
  El MISMO sprite sirve para el suelo, la cama, la mano, el inventario, `HOLD_ITEM` y `PLACED`.
- **Efectos de papel** (`PaperEffects`): lágrimas, sudor, temblor, marcas de dolor y respiración fría como recortes de papel
  pegados sobre la cabeza (bordes irregulares, fibras, sombra mínima). Preparados (`Player.paperEffects`, máscara de bits); aún sin disparador.
- **Puzzle de las 3 cajas** en la mesita de mamá (tras la introducción, botón `ORDENAR`): cambio **temporal a primera persona**
  (`FirstPersonView`: la cámara se acerca y se funde con la mesa vista desde los ojos del niño). Se ven la mesa, un pastillero de papel
  con 3 huecos, las 3 cajas, la hoja de la farmacia y las manos del niño. **Tocar + mantener + arrastrar + soltar**; un toque corto
  da la vuelta a la caja. Sin menús ni mensajes de error. Al resolver: brillo discreto, evento `MEDICINE_PUZZLE_COMPLETED` y vuelta a tercera persona.
- **Tres documentos** (`Documents`): médico (cómoda de mamá), económico (mesa de la cocina) y farmacia/tratamiento (la hoja de la mesita,
  pista del puzzle). Nombres inventados, sin logos. El niño reacciona como un niño de 8 años.
- Los datos de sprites los genera `tools/sprite_gen` (Python, solo para generar; el juego no lo usa): `python3 emit_kotlin.py`
  reescribe `pixel/SpriteData.kt`.

### Novedades de v0.5
- **Protagonista definitivo** (48×64, 17 colores): pelo castaño despeinado, suéter naranja de lana con línea roja,
  pantalón caqui, zapatos blancos, bufanda corta rojo oscuro y una pequeña marca en la mejilla.
  Poses: `IDLE`, `WALK_1..3`, `PICKUP`, `HOLD_ITEM`, `GIVE_ITEM`, `HURT`, `HIDE`, `FLASHBACK` y `HOLD_WALK_1..3`
  (caminar con un objeto). `Player.pose` las elige según estado y objeto en mano; `Player.poseOverride` queda
  para HURT/FLASHBACK en eventos futuros. Las manos tienen punto de agarre por pose (`PixelCharacterData.hand`).
- **Inventario reutilizable** (`inventory/`): `ItemDef` (id, nombre, icono, descripción, apilable, usable, mundo),
  `ItemRegistry`, `Inventory` (cantidad, capacidad, objeto en las manos). Vive en `GameState.inventory`; el HUD
  dibuja el objeto en una casilla discreta arriba a la derecha.
- **Recoger y entregar con animación**: `InteractionResult.pickup(...)` / `give(...)` (+ continuación con texto o hitos).
  El niño se agacha (`PICKUP`), el objeto pasa a su mano (`HOLD_ITEM`) y entrega con `GIVE_ITEM`.
  Eventos `ON_ITEM_PICKED`, `ON_ITEM_GIVEN`, `ON_ITEM_PLACED`.
- **Vaso de agua**: en la cocina (grifo, "TOMAR AGUA") tras pedirlo mamá; se ve en la mano y se entrega a mamá.
- **Medicamentos como objetos**: tres cajitas (azul, naranja, blanca) en la mesita de mamá (`WorldPickup`: recoger,
  dejar en su sitio, "Tengo las manos ocupadas."). Mamá pide la azul; otra caja la rechaza ("Esa no, cariño. La azul.").
  **Sin puzzle ni contraseña**: eso es v0.6.
- **Base de objetos utilizables**: `Interactable.promptFor/iconFor` (botón según estado), `ScriptedSpot` con prompts
  dinámicos y receptores de objetos (mamá, la cama del niño).
- **Peluche de rana completo** (`PlushFrog`): `ON_FLOOR → HELD → PLACED`; se recoge, se transporta y se deja en la cama.
  No habla ni tiene personalidad todavía (v0.7).
- **Preparación NORMAL/TRAUMA**: `WorldMode`, `GameState.worldMode`, `RoomSegment.worldMode`,
  `SceneDefinition.traumaSegments` + `segmentFor`. Sin mapas ni transición del Mundo Trauma.

### Flujo de la introducción (v0.5)
mamá llama → agua en la cocina → entregar el agua → mamá pide la cajita azul → recoger la azul en la mesita →
entregarla → «Estas cosas saben feo. No sé por qué mamá toma tantas.»

---

## Versión v0.4.0 (base)
La escena de prueba de v0.3 se convierte en **la casa del protagonista**: un niño de 8 años en una casa
que parece normal. El mundo está dibujado a crayón; el niño es pixel art. Empiezas en tu cuarto, mamá te
llama desde otra habitación y recorres la casa observando, escuchando y examinando.
Sin monstruo, sin persecución, sin sustos: el malestar sale de la luz, la composición y los detalles.

### La casa
Un **pasillo principal** largo (960 px, `SIDE_SCROLLING`) con acceso directo a siete espacios:

| Espacio | Luz | Notas |
|---|---|---|
| `KidRoom` (inicio) | cálida | cama, juguetes, dibujos, libros, ventana, **Ranita** (peluche de rana/farmacia, solo objeto ambiental), armario |
| `Bathroom` | blanca/fría | pequeño (`FIXED`), espejo, botiquín, bañera con patito |
| `MomRoom` | tenue | cama de mamá, mesita con pastillas como props, póster de la rana, armario |
| `Laundry` | fría/artificial | estrecha (`FIXED`), lavadora, cesto, tendedero, armario |
| `Kitchen` | cálida | refri con dibujos, fregadero, estufa, mesa con tres platos |
| `Dining` | cálida apagada | mesa familiar, fotos, dibujo del niño, globo de cumpleaños |
| `Cellar` | oscuridad fuerte | cajas, mueble tapado, herramientas, muñeca vieja, armario |

Armarios (esconderse como en v0.3) en: habitación del niño, de mamá, bodega y lavandería.
Cada espacio tiene 4–11 puntos examinables con la voz de un niño de 8 años (frases breves y simples).

### Introducción
`IntroScript` (guion de escena basado en hitos `StoryFlags`): ~5 s después de empezar, mamá dice
*«Cariño, ¿puedes ayudarme?»*, luego *«Ya es hora de mis pastillas.»* y *«¿Me traes un poco de agua también?»*.
Cada línea ocurre **una sola vez**. Puedes tomar agua en la cocina (grifo) y llevársela a mamá.
No hay inventario ni puzzle: solo hitos narrativos (`StoryState`), la base sobre la que v0.5/v0.6 construirán.

### Nuevo estilo visual: crayón detallado
`draw/CrayonBuilder`: rellenos de trazos en dos pasadas con distinta presión, contornos dobles que se pasan
de las esquinas, manchas, garabatos, caritas de dibujo infantil. Todo se genera **una vez** al cargar el segmento
con `SeededRandom` (misma semilla = mismo dibujo); el renderer solo recorre las operaciones.
`BackdropBuilder` dibuja paredes (rayas, lunares, flores irregulares, azulejos, tablones) y suelos
(madera, baldosas, cemento) en tramos de 160 px; solo se pintan los visibles.
Lo "grotesco bonito" es sutil y parece accidental: un tic de más en el reloj, flores con demasiados pétalos,
un patito con sonrisa demasiado grande, una silueta borrosa en el espejo, cinco vasos iguales, tres platos,
la persona demasiado alta en la ventana del dibujo, la rana de la farmacia que siempre sonríe.

### Protagonista pixel art
`pixel/`: `PixelCharacterData` (48×64, paleta de 13 colores, matriz de índices por pose), `PixelPose`
(`IDLE`, `WALK_1..3`, y preparadas `HIDE`, `HURT`, `FLASHBACK`), `PixelRasterizer` (matriz → ARGB, lógica pura)
y `render/PlayerPixelRenderer` (bitmap cacheado por pose y luz, sin allocations por frame).
El renderer **no sabe quién es el personaje**: sirve para flashbacks, otros niños o versiones del protagonista
(`withPalette`). ~50 px visibles: la cámara cercana de v0.3 no cambia.

### La luz afecta al personaje
`world/LightField` calcula la luz que recibe un punto con las **mismas luces y la misma caída** que la máscara de
oscuridad. Esa muestra (`LightingSample`: brillo + tinte) se aplica a los píxeles del niño: se oscurece en la
sombra y se tiñe con lámparas cálidas/frías. Además lo cubre la propia máscara de oscuridad de v0.3.

### Arquitectura de render
```
GameRenderer → BaseRenderer (lienzo, tint/visualCorruption, HUD, texto)
                 └ WorldRenderer (puertas, armarios, luces, personaje)
                      └ CrayonRenderer (fondos y objetos de crayón)
PlayerPixelRenderer · LightingRenderer · máscara de oscuridad
Futuro: GraphiteRenderer · ScratchRenderer · DistortionRenderer (heredan de WorldRenderer)
```
`visualCorruption` sigue en `0.0` (`BaseRenderer.tint` ya lo respeta, también en el personaje).

### Se conserva de v0.3
Cámara cercana, movimiento lateral, `RoomSegment`, puertas y transiciones con fundido, colisiones, interacción
contextual y botón de acción genérico, texto con borde de crayón, `EventBus` (+ `ON_STORY_FLAG`), `ExamineSpot`,
`Wardrobe`, `LightSwitch`, iluminación localizada, ocultarse (HIDDEN, ojos en la rendija), `SeededRandom`
(solo para trazos y detalles, nunca posiciones, puertas, colisiones ni progreso) y separación update/render.

## Tests
`./gradlew testDebugUnitTest` (v0.7: `CompanionAudioTest` — slots, HABLAR, conversaciones y su ritmo, triggers A/B, arte, motor de audio offline: determinismo, superficies, mundos, voces, música, ambiente, ciclo de vida; incluye v0.5: inventario, flujo agua → mamá → cajita azul, peluche, poses, NORMAL/TRAUMA): 8 espacios y conexiones con el pasillo, destinos y spawns de cada puerta,
recorrido completo de la casa, límites y colisiones, cámara cercana/FIXED/SIDE_SCROLLING, interacción,
`ExamineSpot`, `Wardrobe` en las cuatro habitaciones, intro de una sola vez, agua + mamá, matriz pixel
(misma matriz = mismo personaje, otras paletas = otro resultado), iluminación sobre el personaje,
crayón y fondos deterministas, estructura independiente de la semilla, transiciones sin romper el estado.

## Build
`.github/workflows/build.yml` (sin cambios): Actions → `assembleDebug` → artifact **JuegoTerror2D-debug-apk**
→ tests unitarios. La raíz del ZIP es la raíz del repositorio.

## Hoja de ruta (todo sobre esta misma arquitectura)
- **v0.5 — inventario y medicamentos como objetos** (hecho)
- **v0.6 — puzzle de medicamentos** (hecho: cajas arrastrables en primera persona, letras S-O-L, 3 documentos)
- **v0.7 — compañero persistente + conversaciones + audio procedural** (hecho: COMPANION/HAND slot, HABLAR, escena en primera persona, voz y motor de audio)
- Todas las versiones futuras continúan sobre esta base: `StoryState`, `SceneScript`, `Interactable`,
  `PixelCharacterData` y la cadena de renderers (`visualCorruption` irá de crayón a grafito, rasguños y distorsión).

---

## v0.8 — Primera criatura

La primera criatura de MYMom: una **gran rana deforme, triste y con muchas bocas**, con IA jugable completa
(patrulla, oído, vista, investigación, persecución, pérdida del objetivo, captura). Todo se integra con los
sistemas de 0.7 (Scene, Renderer, iluminación, AudioEngine, ruido); no se reescribió nada.

**Código nuevo** (`app/src/main/java/com/terror2d/creature/`): `Noise.kt` (ruido con posición/intensidad/duración/tipo y
oído aproximado), `CreatureBrain.kt` (máquina de estados), `MouthAnimator.kt` (bocas independientes y deterministas),
`CaptureSequence.kt` (captura sin Game Over), `Creature.kt` (animación, ojos, brazos con inercia), `CreatureAudio.kt`.
Dibujo: `pixel/CreatureSprite.kt`, `render/CreatureRenderer.kt`. Datos generados: `pixel/CreatureSpriteData.kt`
(`tools/sprite_gen/creature.py` + `emit_creature.py`; **no editar a mano**).

**Cómo probarla** (condición técnica, no narrativa): al terminar el puzzle de medicinas se activa
`StoryFlags.CREATURE_ACTIVE` y la criatura patrulla el pasillo. En código, `Scene.forceCreature(...)`.
El pasillo tiene un **hueco bajo** (`NarrowGap`, x=410..440) por el que el niño pasa y el cuerpo grande NO cabe.

**Regenerar sprites:** `cd tools/sprite_gen && python3 emit_creature.py` (criatura) y `python3 conversation_art.py` (manos de Ranita).

**Tests nuevos:** `CreatureTest`, `CreatureSceneTest`, `HandsFixTest`. `CompanionAudioTest` se actualizó a 13 capas de arte.

**Estado de verificación:** esta versión se escribió sin poder compilar en el entorno de trabajo. Compila con GitHub Actions
y corrige cualquier error de compilación antes de dar 0.8 por cerrada.

## Criatura v0.8 (diseño canónico de las imágenes de referencia)
La criatura es la traducción FIEL, píxel a píxel, de las dos imágenes de referencia (frontal y caminando) al motor
pixelado: `tools/sprite_gen/refrig.py` (recorte del fondo, espejo, reducción x6 con prioridad al contorno, paleta de 30
colores), `refparts.py` (piezas) y `creature_ref.py` (rig). `python3 emit_creature.py` regenera `CreatureSpriteData.kt`.
Las imágenes NO están en la app: solo las matrices de paleta (RLE) que el motor dibuja y anima.
- Cabeza frontal y cabeza girada (las de cada imagen); ojos y sonrisa con estados que comprimen/estiran los propios
  píxeles de la referencia; 7 bocas del vientre, cada una con 4 estados y animación asíncrona (`MouthAnimator`).
- Caminar y correr: 8 frames cada uno con piernas por IK sobre las piezas de la imagen, rebote de peso, vientre y cabeza
  con retraso; la fase avanza por distancia (sin patinar) y se detiene siempre en un apoyo.
- Brazos: péndulos (`ArmPendulum`) colgados del hombro de cada pose; reaccionan al paso y al movimiento del cuerpo.


## v0.9 — La noche en que mamá desaparece

Puente narrativo entre la rutina inicial y la primera aparición de la criatura. Sin criatura persiguiendo todavía:
el survival es de 0.10/0.11.

**Flujo**: Ranita visible pero bloqueada (`PLUSH_AVAILABLE` sin poner) -> mamá llama, agua, pastillas -> puzzle de
medicamentos (sin cambios) -> hito `MEDICINE_PUZZLE_COMPLETED` (el mismo que `MEDICINE_PUZZLE_DONE`) -> el niño dice
"Bueno... debería irme a mi habitación ya. Es tarde.", pierde el control y camina solo hasta su cama (por las puertas que
haga falta) -> sube, se acomoda, se acuesta -> fundido a negro, silencio, **grito de mamá** (una sola vez) y cristales ->
despierta con el control (Ranita ya se puede recoger) -> habitación de mamá vacía: cama revuelta, ventana rota con lluvia,
nota -> al leer la nota (`MOM_NOTE_READ`) y tras un intervalo, `CREATURE_INTRO_UNLOCKED` -> al cruzar el pasillo la criatura
entra despacio, se queda mirando al niño y se va (sin IA, sin captura) -> `SURVIVAL_READY` (preparado para 0.10).

**Arquitectura desacoplada del mapa**
- `story/Narrative.kt`: `NarrativePhase` (INITIAL_ROUTINE ... SURVIVAL_READY; monótona y persistente, vive en los hitos de
  `StoryState`: `phase`, `isAtLeast`, `advanceTo`), `PointOfInterest`, `Poi` (CHILD_BED, MOTHER_BEDROOM, MOTHER_BED,
  MOTHER_WINDOW, MOTHER_NOTE, HALLWAY_CREATURE_TRIGGER...) y `PointsOfInterest`.
- `HouseDefinition.pointsOfInterest()` es la ÚNICA tabla que une narrativa y mapa. Para la casa definitiva solo hay que
  recolocar estos puntos. `SceneDefinition.routeDoor(from, to)` calcula la ruta por puertas.
- `scene/NarrativeDirector.kt` (orquestador, sin nombres de habitaciones ni coordenadas), `story/BedtimeSequence.kt` y
  `story/CreatureIntro.kt` (lógica pura, probada sin Android).
- Objetos que dependen del progreso: `NarrativeAware` + `StoryGate` (mamá, cama revuelta, charco, nota, ventana).
- `PlushFrog` recibe `enabledWhen`: bloqueada por **estado**, sin mensaje tutorial.

**Procedural**: `ProceduralWindow` (marco, cristal roto, hueco, cortina con viento, luz fría) + `WindowRainOverlay` y
`RainField` (lluvia y salpicaduras generadas por el motor). El niño acostado usa las MISMAS poses (WALK, PICKUP, HIDE, IDLE)
con elevación y giro (`Player.bodyLift/bodyAngle`). La nota usa el sistema de documentos (`DocumentStyle.SCRAWL`).
**Audio** (todo procedural): `MOM_SCREAM`, `WINDOW_CRASH`, `BED_CLIMB`, `BED_SETTLE`, `CREATURE_REVEAL`, ambientes
`STORM_FAR` y `STORM` (lluvia, viento, goteo, cortina) y eventos de alto nivel que traduce el `AudioDirector`.

**Cambios respecto a 0.8**: terminar el puzzle ya NO activa la patrulla de la criatura (`CREATURE_ACTIVE` queda para 0.10;
los tests de 0.8 lo ponen a mano). La criatura de 0.8 no se toca (solo `updateScripted` y `gaze`).

**Tests**: `NarrativeTest` (nuevo) y ajustes en `EngineTest`/`CompanionAudioTest` (Ranita bloqueada hasta el grito).

## v0.10 — Survival: criatura, persecución, ruido, armario, luz y captura

> **Estado:** implementación escrita pero **no compilada ni probada** (el entorno de desarrollo no tenía Kotlin/Gradle). Ejecutar `./gradlew test` y corregir lo que salga antes de dar la versión por buena.

**Persecución (carrera de desgaste).** `CreatureBrain`: al ver al niño la criatura se detiene 0,45 s (`REACTION_TIME`) y arranca a 50 px/s acelerando hasta 84 px/s en 1,6 s (`CHASE_START_SPEED`, `CHASE_SPEED`, `RAMP_TIME`). El niño va a 68. Rango de captura 17 px. Quien duda o elige mal la ruta es alcanzado; quien decide rápido gana distancia.

**Criatura persistente entre habitaciones.** `CreatureTracker` (`creature/CreatureWorld.kt`) la mantiene viva fuera de pantalla; la escena solo simula la habitación del niño y la "materializa" al llegar. Las conexiones (`Connector`, puertas y ventanas) se derivan de la definición de la casa (`buildConnectors()`); la IA no conoce habitaciones concretas. Puerta: si te perseguía, te sigue en CHASE. **Ventana: rompe la persecución** (pierde el foco → `LOST_TARGET`, conserva la última posición conocida = la ventana, la investiga, la cruza en 1,9 s y sigue buscando; sin invulnerabilidad ni teletransporte). Vista y ruido la reactivan.

**Ventanas del laboratorio.** `WindowPassage`: una por habitación (`HouseDefinition.LAB_CHAIN`), cada una lleva a la siguiente (la última a la primera), aterrizando en el spawn `from_window`. Conectores provisionales; en 0.11 se sustituyen por rutas reales.

**Ruido.** Tipos nuevos: `WINDOW`, `INTERACT`, `LIGHT_BREAK`, `CLOSET`. El ruido se oye con posición imperfecta (como en 0.8).

**Armario.** Al esconderse, `ClosetView`/`ClosetRenderer`: primera persona casi a oscuras con una rendija; con Ranita se reutilizan las manos abrazándola; sin Ranita no se dibuja nada de ella. Si la criatura **vio entrar** al niño (`Senses.playerHiding` + línea de visión) lo recuerda y lo saca (`closetCapture`); si no, se detiene a escuchar. `ClosetMemory` prepara la escalada por armario `PASS → SUSPICION → WARNING → CAPTURE` (en 0.10 SUSPICION hace que se asome, CAPTURE equivale a haber visto).

**Luces.** Las lámparas con `intensity ≥ 0.8` son refugio (`LightHealth`): la criatura no entra en su zona (`Blocker.isLight`), se queda frenada y se rinde. Cada foco tiene salud propia: OK → parpadea (3 usos) → dañado (5) → roto (7); roto no protege. Sin tutorial.

**Captura.** `CaptureSequence`: pausa → **SCREAMER** (`ScreamerView`; en v0.10.1 son 18 fotogramas de la cara canónica, ver la sección v0.10.1; la v0.10 usaba 6 de `screamer.py`, ya retirado; sacudida, destello y 3 sonidos sincronizados) → negro → respiración → silencio → despertar en el dormitorio. Sin Game Over; no se tocan las banderas narrativas.

**Estados.** `CREATURE_ACTIVE` se activa al cambiar de habitación tras `SURVIVAL_READY` (nunca antes de la introducción).

**Ranita.** Las dos cinemáticas de prueba ya no se disparan por gameplay: solo con `EventType.CINEMATIC_REQUESTED` (sourceId = id de la conversación).

**Audio.** Pasos pesados y desiguales; respiración distinta por estado (`CREATURE_BREATH_SEARCH`, `_CHASE`); olfateo; pasos y respiración a través de paredes; ventana, armario, foco, screamer; crujidos y golpes lejanos espaciados. Todo procedural.

**Preparado para 0.11.** Conexiones como datos (`Connector`), refugios por intensidad de luz, `ClosetMemory`, `LightHealth` con umbrales configurables, `CINEMATIC_REQUESTED`.

**Pendiente / limitaciones conocidas.** Ver `tests` (`SurvivalTest`); no hay animación de la criatura abriendo el armario (solo ojo/sonrisa en la rendija); el screamer es mejorable en pulido; no se ha medido el tirón al decodificar los fotogramas (se prepara durante la pausa previa).

## v0.10.1 — Screamer cinematográfico, visión del monstruo y refugio interactivo

Cambios sobre v0.10.0 (sin empezar la 0.11):

1. **Screamer: la imagen de referencia 1:1, animada por deformación.**
   - `tools/sprite_gen/screamer_ref_warp.py` carga la referencia (se le pasa la ruta; la imagen NO está en el proyecto) en su rejilla nativa de
     120x160 píxeles y la paleta de la imagen (205 colores + 43 para manos y efectos = 248). **El fotograma 0 es la imagen sin cambios**
     (error medio 4/255 frente a la imagen reducida, debido solo a la cuantización de paleta y al JPEG).
   - Los otros 17 fotogramas salen de ese MISMO fotograma (`screamer_anim.py`): cámara en perspectiva (acercamiento, guiñada, cabeceo,
     alabeo), mandíbula que baja (la parte baja del rostro desciende y el hueco se rellena con gaznate oscuro), ojos que se abultan,
     temblor, viñeta, baba, brazos y manos largos (pixelados a 3 px) y un último plano virado a rojo. No se redibuja la cara.
   - Los píxeles de la referencia viven en el juego como datos de arte (`pixel/ScreamerArtData.kt`, índices de paleta en zlib + base64;
     ~0,8 MB de código fuente). **La imagen original no se incluye ni se carga**; sí lo están sus píxeles, porque pediste la copia 1:1.
   - `pixel/ScreamerCodec.kt` decodifica los datos (JVM estándar, comprobable en pruebas). `ScreamerRenderer` descomprime
     durante la pausa previa y crea cada bitmap al necesitarlo.
   - Vistas previas en `docs/` (`screamer_first_frame_v0_10_1.png`, `screamer_sequence_v0_10_1.png`), no son recursos del juego.
   - `screamer_face.py` queda solo como biblioteca de utilidades (cámara, paletas de manos, ruido); su antiguo renderizado paramétrico no se usa.
2. **Audio del screamer** (`SfxSynth`): ahora suena como un **grito/llanto desesperado**, no como un rugido grave. Voz humana sintetizada
   (diente de sierra con formantes de vocal abierta «aaah» y otra aguda «iii», vibrato irregular, aliento rasposo), coro de tres gargantas
   desafinadas que sube de tono, se quiebra y cae; un gruñido grave por debajo; golpe seco en el impacto; chillido que se rompe en el
   agarre; y en el último plano un grito final agudo seguido de **sollozos entrecortados** que bajan de tono (se oyen en la transición a
   negro). Cues en el instante exacto de su fotograma (`ScreamerView.CUE_TIMES`) y niveles repartidos bajo el limitador suave (`softClip`).
   Estilo FNAF: además del grito hay capas crudas (`growl` rugido ronco con FM y cuantización, `screech` ráfagas de chillidos metálicos,
   `staticBurst` estallido de ruido) que suman por encima del limitador a propósito para saturar. Sigue siendo síntesis, no una grabación.
   **Sin ejecutar ni escuchar**: lo ajusté por cálculo, no de oído; si algo suena demasiado agudo o saturado, los niveles y tonos están al
   principio de cada función (`screamVoice`, `screamBody`, `screamImpact`, `screamRoar`, `screamGrab`, `screamFinal`).
3. **Campo de visión** (`VisionConfig`): alcance 300 (antes 190), `darkFactor` 0,5 (antes 0,35), visión trasera 40 (antes 14),
   histéresis (`holdMargin` 15 % y `holdWindow` 0,6 s) para que la detección no parpadee en el límite, intervalo de comprobación
   configurable. Todo se pasa por `Creature(vision = ...)`. Paredes (`Blocker.blocksSight`), luz, ventanas, pérdida y búsqueda sin cambios.
4. **Escondite en primera persona con composición propia**: `tools/sprite_gen/closet_art.py` → `pixel/ClosetArtData.kt`: antebrazos que cruzan
   el pecho (mangas del suéter en las esquinas). Con Ranita: se reutiliza SOLO la capa `plush` del arte canónico (menor y pegada al pecho, DELANTE de los antebrazos;
   y con los dedos por encima de su borde); sin Ranita no se dibuja nada de ella. Ya no se usa la escena de conversación en el armario.
5. **Máscara negra con rendija arrastrable**: `ClosetRenderer` dibuja dos rectángulos negros pegados a los bordes de la rendija
   (sin imagen enorme). `InputController.closetMode` desactiva los botones de movimiento mientras se está escondido; un dedo que
   empieza a arrastrar nunca cuenta como botón de acción. Teclado: A/D desplazan la rendija. El armario propio y el niño no se
   dibujan desde dentro. El rostro de la criatura solo aparece si está a ≤ 90 px de la puerta, se asomó y su cabeza cae frente a la rendija.
6. Pasos y respiración cercanos solo con la criatura cerca y en movimiento (silencio el resto del tiempo).

### Verificación realizada en este entorno
- Se generó y revisó visualmente el primer fotograma frente a la referencia, la secuencia y los brazos del armario.
- Primer fotograma: error medio 4/255 frente a la referencia (cuantización a 248 colores + JPEG). Los demás fotogramas son deformaciones
  de él; al acercarse se ven los bloques del pixel art original, ampliados.
- Abrazo de Ranita: se comprobó en una composición local (no en el juego) y con Python que ninguna capa de brazos cubre la cara.
- **No se pudo compilar ni ejecutar `./gradlew test`** (sin Gradle/JDK de Android ni red). Las pruebas nuevas (`ClosetTest`,
  `CreatureTest`, `SurvivalTest`) están escritas pero **sin ejecutar**; el código Kotlin se revisó solo de forma estática. El algoritmo
  de decodificación de `ScreamerCodec` se verificó en Python contra los datos generados (los 18 fotogramas coinciden).

### Corrección posterior (mismo v0.10.1)
- **Abrazo de Ranita**: ahora Ranita va DELANTE de los brazos y pegada al pecho. `closet_art.py` genera tres capas: `hug_self` (sin Ranita, sin
  cambios), `hug_plush_back` (antebrazos desde las esquinas inferiores y palmas, por detrás/debajo) y `hug_plush_front` (dedos y pulgares
  que se curvan sobre el vientre). Orden de dibujo: back → Ranita → front. Los brazos rodean por los costados y por debajo y la cara
  (mitad superior) queda despejada (prueba `ranitaStaysInFrontOfTheArmsAndHerFaceIsClear`).
- **Screamer**: se sustituyó la versión paramétrica por la imagen 1:1 deformada descrita arriba (un intento previo de trazado vectorial y otro de dibujo manual por partes se descartaron por no parecerse lo bastante).
