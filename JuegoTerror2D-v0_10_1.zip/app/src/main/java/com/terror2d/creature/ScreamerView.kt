package com.terror2d.creature

import kotlin.math.sin

/**
 * v0.10.1: estado del SCREAMER de captura. El arte (18 fotogramas de la MISMA cara reconstruida de forma procedural, con
 * cámara en perspectiva; ver tools/sprite_gen/screamer_face.py y screamer_anim.py) lo dibuja
 * [com.terror2d.render.ScreamerRenderer]; aquí solo viven los TIEMPOS: qué fotograma toca, la sacudida, el destello y
 * las marcas de audio, que coinciden con el instante exacto en que cambia el fotograma correspondiente.
 *
 *  fotograma 0      la cara tal cual (primer fotograma canónico), emergiendo de la oscuridad
 *  fotogramas 1-4   aproximación en perspectiva, la mandíbula empieza a abrirse
 *  fotograma 5      IMPACTO: la cara llena la pantalla                                   (CUE_IMPACT)
 *  fotograma 7      RUGIDO: boca abierta, los brazos largos entran por los lados          (CUE_ROAR)
 *  fotograma 11     AGARRE: la mano cae sobre la pantalla                                 (CUE_GRAB)
 *  fotogramas 12-16 cabeza ladeada, ojo gigante, gaznate, mandíbula temblando
 *  fotograma 17     último plano de impacto                                               (CUE_FINAL)
 */
class ScreamerView {
    var active = false
        private set
    var time = 0f
        private set
    private var cueIndex = 0

    /** Fotograma de arte (0 until [FRAME_COUNT]) que toca ahora. */
    val frame: Int
        get() {
            var f = 0
            for (i in FRAME_START.indices) if (time >= FRAME_START[i]) f = i
            return f
        }

    /** 0..1 sacudida de pantalla (mayor en los impactos). */
    val shake: Float
        get() {
            var s = 0f
            for (c in CUE_TIMES) {
                val d = time - c
                if (d in 0f..0.28f) s = maxOf(s, 1f - d / 0.28f)
            }
            return s * (0.75f + 0.25f * sin(time * 90f))
        }

    /** 0..1 destello rojo/blanco del impacto (solo ~0.12 s tras la embestida y el agarre). */
    val flash: Float
        get() {
            var f = 0f
            for (c in CUE_TIMES) { val d = time - c; if (d in 0f..0.12f) f = maxOf(f, 1f - d / 0.12f) }
            return f
        }

    /** Zoom del primerísimo plano: crece durante la embestida. */
    val zoom: Float get() = 1f + 0.06f * (time / DURATION).coerceIn(0f, 1f) + 0.05f * shake

    val done: Boolean get() = active && time >= DURATION

    fun begin() { active = true; time = 0f; cueIndex = 0 }
    fun end() { active = false }

    fun update(dt: Float) {
        if (!active) return
        time += dt
    }

    /** Devuelve (una vez) el siguiente cue de audio cuyo instante ya pasó, o -1. Los cues coinciden con cambios de fotograma. */
    fun consumeCue(): Int {
        if (!active || cueIndex >= CUE_TIMES.size) return -1
        if (time >= CUE_TIMES[cueIndex]) return cueIndex++
        return -1
    }

    companion object {
        const val FRAME_COUNT = 18
        const val DURATION = 2.45f
        /** Instante de inicio de cada fotograma (mismos valores que FRAME_START de screamer_anim.py). */
        val FRAME_START = floatArrayOf(0f, 0.18f, 0.30f, 0.40f, 0.48f, 0.56f, 0.64f, 0.72f, 0.82f, 0.92f, 1.02f, 1.14f, 1.26f, 1.40f, 1.56f, 1.72f, 1.90f, 2.10f)
        /** Fotogramas en los que cae cada cue de audio. */
        const val FRAME_IMPACT = 5
        const val FRAME_ROAR = 7
        const val FRAME_GRAB = 11
        const val FRAME_FINAL = 17
        /** Cues de audio: sincronizados con el inicio de su fotograma (sin retraso). */
        val CUE_TIMES = floatArrayOf(FRAME_START[FRAME_IMPACT], FRAME_START[FRAME_ROAR], FRAME_START[FRAME_GRAB], FRAME_START[FRAME_FINAL])
        const val CUE_IMPACT = 0
        const val CUE_ROAR = 1
        const val CUE_GRAB = 2
        const val CUE_FINAL = 3
    }
}
