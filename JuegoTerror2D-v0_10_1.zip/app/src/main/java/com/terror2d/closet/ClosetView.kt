package com.terror2d.closet

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * v0.10.1: estado de la ESCENA DEL ARMARIO en primera persona. Mientras el niño está escondido el mundo se cubre con una
 * MÁSCARA NEGRA ANCHA y solo queda una RENDIJA estrecha por la que se ve el exterior; el jugador arrastra el dedo en
 * horizontal para desplazarla y mirar otras zonas. En la parte baja se ven sus brazos abrazando algo contra el pecho
 * (a Ranita si la lleva; si no, nada: nunca se muestra un peluche que no lleva).
 *
 * No tiene lógica de IA y mirar NO altera nada del juego: el desplazamiento de la rendija es solo visión. La escena le
 * dice si hay peligro cerca ([danger], 0..1) y si la criatura se asoma ([peek]); la posición real de la criatura en
 * pantalla llega por [setFace], de modo que su ojo/sonrisa solo aparece donde de verdad está.
 */
class ClosetView {
    var active = false
        private set
    /** 0..1: fundido hacia/desde la escena. */
    var blend = 0f
        private set
    var time = 0f
        private set
    /** true = Ranita acompaña al niño (la escena la muestra abrazada). */
    var withFrog = false
        private set
    /** 0..1: cercanía de la criatura (la rendija se estrecha, el niño respira más y tiembla). */
    var danger = 0f
        private set
    /** 0..1: la criatura abre la puerta un poco y se asoma (ojo y sonrisa en la rendija si pasa por delante). */
    var peek = 0f
        private set

    /** Centro objetivo de la rendija (px lógicos de pantalla) y centro suavizado que se dibuja. */
    var slitTarget = DEFAULT_SLIT_X
        private set
    var slitCenter = DEFAULT_SLIT_X
        private set
    /** Posición en pantalla (px lógicos) del rostro de la criatura si puede verse desde la puerta; NaN si no. */
    var faceX = Float.NaN
        private set
    /** Distancia total arrastrada (para pruebas y para que el audio sepa que el niño está mirando). */
    var dragTotal = 0f
        private set

    private var wantPeek = false
    private var wantActive = false

    val breathingIntensity: Float get() = 0.25f + 0.75f * danger
    val tremorIntensity: Float get() = 0.1f + 0.9f * danger

    /** Ancho de la rendija (px lógicos): se estrecha un poco con el peligro y se abre al asomarse la criatura. */
    val slitWidth: Float get() = (BASE_WIDTH - 3f * danger + 5f * peek).coerceIn(MIN_WIDTH, MAX_WIDTH)
    val slitLeft: Float get() = slitCenter - slitWidth / 2f
    val slitRight: Float get() = slitCenter + slitWidth / 2f

    fun begin(frogAccompanies: Boolean) {
        withFrog = frogAccompanies
        wantActive = true
        active = true
        time = 0f
        peek = 0f
        slitTarget = DEFAULT_SLIT_X
        slitCenter = DEFAULT_SLIT_X
        faceX = Float.NaN
    }

    fun end() { wantActive = false }

    /** Corta de golpe (descarga de la escena / captura). */
    fun abort() { wantActive = false; active = false; blend = 0f; peek = 0f; danger = 0f; wantPeek = false; faceX = Float.NaN }

    fun setPeeking(v: Boolean) { wantPeek = v }

    /** La escena indica dónde está el rostro de la criatura en pantalla (o NaN si no se asoma / no es visible). */
    fun setFace(screenX: Float) { faceX = screenX }

    /** Desplazamiento horizontal del dedo (px lógicos): mueve la rendija sin saltos y sin salirse de los límites. */
    fun drag(dx: Float) {
        if (!active || !wantActive || dx == 0f) return
        slitTarget = (slitTarget + dx).coerceIn(SLIT_MIN, SLIT_MAX)
        dragTotal += abs(dx)
    }

    fun update(dt: Float, dangerNow: Float) {
        if (!active) return
        time += dt
        val target = if (wantActive) 1f else 0f
        blend = if (blend < target) min(target, blend + dt / FADE_IN) else max(target, blend - dt / FADE_OUT)
        if (!wantActive && blend <= 0f) { active = false; peek = 0f; danger = 0f; faceX = Float.NaN; return }
        danger += (dangerNow.coerceIn(0f, 1f) - danger) * min(1f, 3f * dt)
        val pt = if (wantPeek) 1f else 0f
        peek += (pt - peek) * min(1f, 2.4f * dt)
        // la rendija sigue al dedo con un suavizado corto: continuidad visual, sin saltos ni huecos
        val k = min(1f, 22f * dt)
        slitCenter += (slitTarget - slitCenter) * k
    }

    companion object {
        const val FADE_IN = 0.45f
        const val FADE_OUT = 0.3f
        const val DEFAULT_SLIT_X = 160f
        const val SLIT_MIN = 14f
        const val SLIT_MAX = 306f
        const val BASE_WIDTH = 13f
        const val MIN_WIDTH = 8f
        const val MAX_WIDTH = 22f
    }
}
