package com.terror2d.input

import android.view.KeyEvent
import android.view.MotionEvent
import com.terror2d.core.Viewport
import com.terror2d.interaction.InteractionIcon

/** Acciones del juego. En v0.3 INTERACT es el botón de acción genérico (puertas, armarios, objetos...). */
enum class InputAction { INTERACT, RUN, HIDE, EXAMINE, CONFIRM, CANCEL, TALK }

/**
 * Traduce eventos táctiles/teclado a un estado de entrada abstracto: izquierda, derecha y acción.
 * La lógica del juego solo lee [moveX] y las acciones; nunca MotionEvent.
 *
 * Controles táctiles (coordenadas lógicas 320x180, zona inferior):
 *  - botón izquierdo y derecho abajo a la izquierda (discretos);
 *  - botón de acción abajo a la derecha, visible solo cuando hay algo con lo que actuar.
 * Las zonas de toque se extienden a las barras negras para que el pulgar nunca falle.
 */
class InputController {

    /** Dirección horizontal: -1 (izquierda), 0 o 1 (derecha). No existe eje vertical. */
    @Volatile var moveX: Float = 0f
        private set

    @Volatile var leftHeld: Boolean = false
        private set
    @Volatile var rightHeld: Boolean = false
        private set

    /** Lo escribe la escena: true cuando el botón de acción debe mostrarse y aceptar toques. */
    @Volatile var actionEnabled: Boolean = false

    /**
     * v0.7: botón contextual HABLAR (compañero a la espalda y manos vacías). Lo escribe la escena. Es un segundo botón
     * encima del de acción para que se pueda hablar con el peluche aunque haya algo con lo que interactuar cerca.
     */
    @Volatile var talkEnabled: Boolean = false
    @Volatile var talkLabel: String = ""

    /** Lo escribe la escena (genérico, viene del interactuable enfocado): icono y texto del botón. */
    @Volatile var actionIcon: InteractionIcon = InteractionIcon.DOOR
    @Volatile var actionLabel: String = ""

    /** Lo escribe la escena: objeto que lleva en las manos (el HUD dibuja su icono). */
    @Volatile var heldItemId: String? = null

    /**
     * Lo escribe la escena: true durante la PRIMERA PERSONA (puzzle o conversación). Entonces los botones de la pantalla se
     * ignoran y el dedo se lee como puntero para arrastrar (ver [pointerDown], [pointerX], [pointerY]).
     */
    @Volatile var puzzleMode: Boolean = false

    /** Puntero primario (coordenadas lógicas 320x180): dedo apoyado, su posición y los flancos de pulsar / soltar. */
    @Volatile var pointerDown: Boolean = false
        private set
    @Volatile var pointerX: Float = 0f
        private set
    @Volatile var pointerY: Float = 0f
        private set
    @Volatile var pointerPressed: Boolean = false
        private set
    @Volatile var pointerReleased: Boolean = false
        private set

    /**
     * v0.10.1: true mientras el niño está ESCONDIDO en un armario. El dedo deja de ser un mando: los botones de
     * movimiento y de hablar se ignoran y arrastrar en horizontal desplaza la rendija de la máscara ([consumeClosetDrag]).
     * Un dedo que empezó a arrastrar nunca cuenta como pulsación del botón de acción, aunque pase por encima de él;
     * el botón de acción (salir del armario) sigue funcionando con un dedo distinto que lo pulse.
     */
    @Volatile var closetMode: Boolean = false

    private var dragId = -1
    private var dragLastX = 0f
    private var dragAcc = 0f

    /** Desplazamiento horizontal acumulado del dedo de arrastre desde la última lectura (px lógicos). */
    fun consumeClosetDrag(): Float { val d = dragAcc; dragAcc = 0f; return d }

    /** Simula el dedo de arrastre sin MotionEvent (pruebas, mandos): flancos pulsar / mover / soltar. */
    fun closetDragPoint(down: Boolean, x: Float) {
        if (!closetMode) { dragId = -1; return }
        if (down) {
            if (dragId == -1) { dragId = 0; dragLastX = x } else { dragAcc += x - dragLastX; dragLastX = x }
        } else dragId = -1
    }

    private val actionDown = BooleanArray(InputAction.values().size)
    private val actionPressed = BooleanArray(InputAction.values().size)

    private var touchLeft = false
    private var touchRight = false
    private var touchAction = false
    private var touchTalk = false
    private var keyLeft = false
    private var keyRight = false
    private var keyAction = false
    private var keyTalk = false

    fun isDown(action: InputAction): Boolean = actionDown[action.ordinal]

    /** true durante el primer update tras pulsar. */
    fun wasPressed(action: InputAction): Boolean = actionPressed[action.ordinal]

    fun setAction(action: InputAction, down: Boolean) {
        val i = action.ordinal
        if (down && !actionDown[i]) actionPressed[i] = true
        actionDown[i] = down
    }

    /** Se llama al final de cada update para limpiar las pulsaciones puntuales. */
    fun endFrame() {
        for (i in actionPressed.indices) actionPressed[i] = false
        pointerPressed = false
        pointerReleased = false
    }

    /**
     * Fija el puntero directamente (tests y mandos). Detecta los flancos: pulsar (down tras up) y soltar.
     * El dedo se mantiene en la última posición al soltar para que [pointerReleased] sepa dónde se soltó.
     */
    fun setPointer(down: Boolean, x: Float, y: Float) {
        pointerX = x
        pointerY = y
        if (down && !pointerDown) pointerPressed = true
        if (!down && pointerDown) pointerReleased = true
        pointerDown = down
    }

    /** Fija la dirección directamente (útil para tests y mandos). */
    fun setDirection(left: Boolean, right: Boolean) {
        keyLeft = left
        keyRight = right
        publish()
    }

    /**
     * Recalcula el estado táctil con TODOS los dedos activos, de modo que deslizar el dedo
     * de un botón a otro cambia de dirección y varios dedos conviven (mover + actuar).
     */
    fun onTouchEvent(e: MotionEvent, viewport: Viewport): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_CANCEL) {
            touchLeft = false
            touchRight = false
            touchAction = false
            touchTalk = false
            dragId = -1
            if (pointerDown) setPointer(false, pointerX, pointerY)
            publish()
            return true
        }
        val lifting = e.actionMasked == MotionEvent.ACTION_UP ||
            e.actionMasked == MotionEvent.ACTION_POINTER_UP
        val skip = if (lifting) e.actionIndex else -1
        var l = false
        var r = false
        var a = false
        var tk = false
        // puntero primario: el primer dedo que sigue apoyado (para arrastrar las cajas del puzzle)
        var primary = -1
        for (i in 0 until e.pointerCount) {
            if (i != skip) { primary = i; break }
        }
        if (primary >= 0) setPointer(true, viewport.toLogicalX(e.getX(primary)), viewport.toLogicalY(e.getY(primary)))
        else setPointer(false, pointerX, pointerY)
        if (closetMode) {
            touchLeft = false
            touchRight = false
            touchTalk = false
            val di = e.actionIndex
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    val lx0 = viewport.toLogicalX(e.getX(di))
                    val ly0 = viewport.toLogicalY(e.getY(di))
                    val inAction = lx0 >= ACTION_ZONE_START && ly0 >= HUD_TOP
                    if (!inAction && dragId == -1) { dragId = e.getPointerId(di); dragLastX = lx0 }
                }
                MotionEvent.ACTION_MOVE -> {
                    val k = e.findPointerIndex(dragId)
                    if (k >= 0) {
                        val lx0 = viewport.toLogicalX(e.getX(k))
                        dragAcc += lx0 - dragLastX
                        dragLastX = lx0
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> if (e.getPointerId(di) == dragId) dragId = -1
            }
            for (i in 0 until e.pointerCount) {
                if (i == skip) continue
                if (e.getPointerId(i) == dragId) continue
                val lx0 = viewport.toLogicalX(e.getX(i))
                val ly0 = viewport.toLogicalY(e.getY(i))
                if (ly0 >= HUD_TOP && lx0 >= ACTION_ZONE_START && actionEnabled) a = true
            }
            touchAction = a
            publish()
            return true
        }
        if (puzzleMode) {
            touchLeft = false
            touchRight = false
            touchAction = false
            touchTalk = false
            publish()
            return true
        }
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            val lx = viewport.toLogicalX(e.getX(i))
            val ly = viewport.toLogicalY(e.getY(i))
            if (ly < HUD_TOP) continue
            if (lx < LEFT_ZONE_END) l = true
            else if (lx < RIGHT_ZONE_END) r = true
            else if (lx >= ACTION_ZONE_START) {
                // con HABLAR visible, la zona superior del lado derecho es HABLAR y la inferior la acción
                if (talkEnabled && ly < TALK_ZONE_END_Y) tk = true
                else if (actionEnabled) a = true
            }
        }
        touchLeft = l
        touchRight = r
        touchAction = a
        touchTalk = tk
        publish()
        return true
    }

    /** Teclado (emulador / mando): flechas o A/D; ESPACIO, ENTER o E = acción. */
    fun onKey(keyCode: Int, down: Boolean): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_A -> keyLeft = down
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_D -> keyRight = down
            KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_E -> keyAction = down
            KeyEvent.KEYCODE_T, KeyEvent.KEYCODE_Q -> keyTalk = down
            else -> return false
        }
        publish()
        return true
    }

    private fun publish() {
        leftHeld = touchLeft || keyLeft
        rightHeld = touchRight || keyRight
        var mx = 0f
        if (leftHeld) mx -= 1f
        if (rightHeld) mx += 1f
        moveX = mx
        setAction(InputAction.INTERACT, touchAction || keyAction)
        setAction(InputAction.TALK, touchTalk || keyTalk)
    }

    companion object {
        // Posición de los botones en coordenadas lógicas (para el HUD).
        const val BTN_Y = 158f
        const val LEFT_X = 20f
        const val RIGHT_X = 58f
        const val ACTION_X = 296f
        const val TALK_Y = 126f
        const val TALK_ZONE_END_Y = 141f
        const val BTN_RADIUS = 12f

        // Zonas de toque (generosas, incluyen las barras negras laterales).
        const val HUD_TOP = 100f
        const val LEFT_ZONE_END = 39f
        const val RIGHT_ZONE_END = 80f
        const val ACTION_ZONE_START = 240f
    }
}
