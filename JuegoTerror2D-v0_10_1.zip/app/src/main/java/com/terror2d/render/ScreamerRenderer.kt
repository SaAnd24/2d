package com.terror2d.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import com.terror2d.core.GameConfig
import com.terror2d.creature.ScreamerView
import com.terror2d.pixel.ScreamerArtData
import com.terror2d.pixel.ScreamerCodec
import kotlin.math.cos
import kotlin.math.sin

/**
 * Dibuja el SCREAMER de captura: los fotogramas dedicados de [ScreamerArtData] (arte 640x360 de la cara reconstruida
 * de forma procedural; zlib+base64, ver [ScreamerCodec]), con sacudida, zoom de embestida, destello de impacto y viñeta. El arte solo ocupa
 * memoria durante la captura ([prepare] al empezar, [release] al terminar).
 */
class ScreamerRenderer {
    private val frames = arrayOfNulls<Bitmap>(ScreamerArtData.FRAME_COUNT)
    private val paint = Paint().apply { isAntiAlias = false; isFilterBitmap = false; isDither = false }
    /** Índices ya descomprimidos (1 byte por píxel, ~4 MB en total): se hace durante la pausa previa, no durante el susto. */
    private val raw = arrayOfNulls<ByteArray>(ScreamerArtData.FRAME_COUNT)

    /** Descomprime todos los fotogramas (la captura tiene una pausa de 0,5 s antes del screamer). */
    fun prepare() {
        for (i in raw.indices) if (raw[i] == null) raw[i] = ScreamerCodec.indices(i)
    }

    fun release() {
        for (i in frames.indices) { frames[i]?.recycle(); frames[i] = null; raw[i] = null }
    }

    /** Bitmap del fotograma [index] (se crea al necesitarlo y se descartan los anteriores para no acumular memoria). */
    private fun bitmapFor(index: Int): Bitmap? {
        frames[index]?.let { return it }
        val idx = raw[index] ?: ScreamerCodec.indices(index).also { raw[index] = it }
        val pal = ScreamerArtData.PALETTE
        val px = IntArray(idx.size) { pal[idx[it].toInt() and 0xFF] }
        val bmp = Bitmap.createBitmap(ScreamerArtData.WIDTH, ScreamerArtData.HEIGHT, Bitmap.Config.ARGB_8888)
        bmp.setPixels(px, 0, ScreamerArtData.WIDTH, 0, 0, ScreamerArtData.WIDTH, ScreamerArtData.HEIGHT)
        for (k in frames.indices) if (k < index - 1 && frames[k] != null) { frames[k]?.recycle(); frames[k] = null }
        frames[index] = bmp
        return bmp
    }

    fun draw(canvas: Canvas, v: ScreamerView) {
        if (!v.active) return
        val bmp = bitmapFor(v.frame.coerceIn(0, frames.size - 1)) ?: return
        val w = GameConfig.LOGICAL_WIDTH.toFloat()
        val h = GameConfig.LOGICAL_HEIGHT.toFloat()
        paint.style = Paint.Style.FILL
        paint.color = 0xFF020102.toInt()
        canvas.drawRect(0f, 0f, w, h, paint)
        val shake = v.shake
        val dx = sin(v.time * 131f) * 5f * shake
        val dy = cos(v.time * 97f) * 4f * shake
        canvas.save()
        canvas.translate(w / 2f + dx, h / 2f + dy)
        canvas.scale(v.zoom, v.zoom)
        canvas.translate(-w / 2f, -h / 2f)
        canvas.scale(0.5f, 0.5f)                // 640x360 de arte -> 320x180 lógicos
        paint.alpha = 255
        canvas.drawBitmap(bmp, 0f, 0f, paint)
        canvas.restore()
        // viñeta de bordes oscuros (ocupa la pantalla y deja el centro cargado)
        for (i in 0 until 5) {
            paint.color = ((26 + i * 7) shl 24) or 0x020102
            val e = 3f + i * 5f
            canvas.drawRect(0f, 0f, e, h, paint); canvas.drawRect(w - e, 0f, w, h, paint)
            canvas.drawRect(0f, 0f, w, e * 0.6f, paint); canvas.drawRect(0f, h - e * 0.6f, w, h, paint)
        }
        val f = v.flash
        if (f > 0.01f) {
            paint.color = ((f * 150f).toInt() shl 24) or 0xE8D4C0
            canvas.drawRect(0f, 0f, w, h, paint)
        }
    }
}
