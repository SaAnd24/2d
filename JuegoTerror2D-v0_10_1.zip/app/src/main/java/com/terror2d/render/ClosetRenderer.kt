package com.terror2d.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LightingColorFilter
import android.graphics.Paint
import com.terror2d.closet.ClosetView
import com.terror2d.core.GameConfig
import com.terror2d.pixel.ClosetArtData
import com.terror2d.pixel.ConversationArtData
import com.terror2d.pixel.ScreamerArtData
import com.terror2d.pixel.ScreamerCodec
import kotlin.math.sin

/**
 * v0.10.1: dibuja el INTERIOR DEL ARMARIO en primera persona.
 *
 * Composición PROPIA (no la de Ranita): el exterior (el mundo ya dibujado debajo) queda tapado por una máscara negra
 * ancha con una RENDIJA estrecha y desplazable ([ClosetView.slitLeft]..[ClosetView.slitRight]). Se construye con recortes
 * (rectángulos negros a ambos lados), sin ninguna imagen enorme: la rendija es simplemente el hueco entre ellos y, como
 * los rectángulos se pegan al mismo borde, no puede parpadear ni dejar huecos involuntarios al moverse.
 *
 * Abajo se ven los brazos del niño ([ClosetArtData]: capas propias) abrazando contra el pecho: a Ranita (la misma capa
 * "plush" del arte canónico, menor y ladeada, detrás de los antebrazos) si la lleva, o a nada si no. Si la criatura se
 * asoma a la puerta y su cabeza queda frente a la rendija se ve un trozo de SU rostro canónico (mismo arte del screamer).
 */
class ClosetRenderer(@Suppress("UNUSED_PARAMETER") conversation: ConversationRenderer? = null) {
    private val paint = Paint().apply { isAntiAlias = false; isFilterBitmap = false; isDither = false }
    private val dimArms = LightingColorFilter(0xFF6A6A78.toInt(), 0x00000000)
    private val dimPlush = LightingColorFilter(0xFF5C6258.toInt(), 0x00000000)
    private val dimFace = LightingColorFilter(0xFF8A8478.toInt(), 0x00000000)

    private var armsSelf: Bitmap? = null
    private var armsPlush: Bitmap? = null
    private var plush: Bitmap? = null
    private var face: Bitmap? = null

    fun draw(canvas: Canvas, v: ClosetView) {
        val b = v.blend
        if (b <= 0.002f) return
        val w = GameConfig.LOGICAL_WIDTH.toFloat()
        val h = GameConfig.LOGICAL_HEIGHT.toFloat()
        val a255 = (b.coerceIn(0f, 1f) * 255f).toInt()

        val sl = v.slitLeft
        val sr = v.slitRight
        paint.style = Paint.Style.FILL
        paint.colorFilter = null

        // 1) el exterior visto por la rendija se oscurece (casi no entra luz) y sus bordes se funden en la máscara
        paint.color = ((a255 * 0.45f).toInt() shl 24) or 0x040306
        canvas.drawRect(sl, 0f, sr, h, paint)
        // 2) rostro de la criatura si de verdad está frente a la puerta (recortado a la rendija)
        if (v.peek > 0.35f && !v.faceX.isNaN() && b > 0.6f) drawFace(canvas, v, sl, sr, h)
        // 3) máscara negra ancha a ambos lados (mismos bordes que la rendija: sin huecos ni parpadeo)
        paint.color = (a255 shl 24) or 0x020203
        canvas.drawRect(0f, 0f, sl, h, paint)
        canvas.drawRect(sr, 0f, w, h, paint)
        // 4) bordes de la rendija: rebaje suave y un hilo de luz fría/cálida según el peligro
        for (i in 1..3) {
            paint.color = (((4 - i) * 0.18f * a255).toInt() shl 24) or 0x020203
            canvas.drawRect(sl, 0f, sl + i, h, paint)
            canvas.drawRect(sr - i, 0f, sr, h, paint)
        }
        val warm = (1f - v.danger * 0.7f).coerceIn(0.2f, 1f)
        val edge = (0x58 * warm).toInt() shl 16 or ((0x4A * warm).toInt() shl 8) or ((0x3A * warm).toInt() + (v.danger * 16f).toInt())
        paint.color = ((a255 * 0.55f).toInt() shl 24) or edge
        canvas.drawRect(sl, 0f, sl + 1f, h, paint)
        canvas.drawRect(sr - 1f, 0f, sr, h, paint)

        // 5) los brazos del niño abrazando (respiran y tiemblan más con el peligro)
        val aArms = ((b - 0.4f) / 0.6f).coerceIn(0f, 1f)
        if (aArms > 0.01f) drawArms(canvas, v, aArms)
    }

    private fun drawArms(canvas: Canvas, v: ClosetView, alpha: Float) {
        ensureArms(v.withFrog)
        val breathe = sin(v.time * 1.9f) * 1.1f * v.breathingIntensity
        val tremX = sin(v.time * 37f) * 0.35f * v.tremorIntensity
        val tremY = sin(v.time * 31f + 1.3f) * 0.30f * v.tremorIntensity
        canvas.save()
        canvas.translate(tremX, breathe * 0.5f + tremY)
        paint.alpha = (alpha * 255f).toInt()
        if (v.withFrog) {
            val pl = plush
            if (pl != null) {
                // Ranita apretada contra el pecho: menor que en la conversación, ladeada y más abajo (es otra composición)
                canvas.save()
                canvas.translate(160f, 104f + breathe * 0.35f)
                canvas.rotate(-9f)
                canvas.scale(0.5f * 0.80f, 0.5f * 0.80f)
                canvas.translate(-(212f + 221f * 0.5f), -(64f + 265f * 0.5f))
                paint.colorFilter = dimPlush
                canvas.drawBitmap(pl, 212f, 64f, paint)
                canvas.restore()
            }
            armsPlush?.let {
                canvas.save(); canvas.scale(0.5f, 0.5f)
                paint.colorFilter = dimArms
                canvas.drawBitmap(it, 0f, breathe, paint)
                canvas.restore()
            }
        } else {
            armsSelf?.let {
                canvas.save(); canvas.scale(0.5f, 0.5f)
                paint.colorFilter = dimArms
                canvas.drawBitmap(it, 0f, breathe, paint)
                canvas.restore()
            }
        }
        canvas.restore()
        paint.colorFilter = null
        paint.alpha = 255
    }

    /**
     * Un trozo del rostro canónico (primer fotograma del screamer) sobre la posición real de la cabeza de la criatura.
     * Solo se ve lo que cae dentro de la rendija: según su posición y el ángulo de la abertura, un ojo, la nariz o la sonrisa.
     */
    private fun drawFace(canvas: Canvas, v: ClosetView, sl: Float, sr: Float, h: Float) {
        val f = face ?: decodeFace().also { face = it }
        val k = ((v.peek - 0.35f) / 0.65f).coerceIn(0f, 1f)
        val scale = 0.62f                                   // 360 px de arte -> ~112 px lógicos de alto de cara
        val fw = ScreamerArtData.WIDTH * 0.5f * scale
        val fh = ScreamerArtData.HEIGHT * 0.5f * scale
        val look = sin(v.time * 0.7f) * 1.2f
        canvas.save()
        canvas.clipRect(sl, 0f, sr, h)
        canvas.translate(v.faceX + look - fw * 0.5f, h * 0.36f - fh * 0.5f)
        canvas.scale(0.5f * scale, 0.5f * scale)
        paint.colorFilter = dimFace
        paint.alpha = (k * 255f).toInt()
        canvas.drawBitmap(f, 0f, 0f, paint)
        canvas.restore()
        paint.colorFilter = null
        paint.alpha = 255
    }

    private fun decodeFace(): Bitmap {
        val px = ScreamerCodec.argb(0)
        val bmp = Bitmap.createBitmap(ScreamerArtData.WIDTH, ScreamerArtData.HEIGHT, Bitmap.Config.ARGB_8888)
        bmp.setPixels(px, 0, ScreamerArtData.WIDTH, 0, 0, ScreamerArtData.WIDTH, ScreamerArtData.HEIGHT)
        return bmp
    }

    private fun ensureArms(withFrog: Boolean) {
        if (withFrog) {
            if (armsPlush == null) armsPlush = layer(ClosetArtData.HUG_PLUSH)
            if (plush == null) plush = decodePlush()
        } else if (armsSelf == null) armsSelf = layer(ClosetArtData.HUG_SELF)
    }

    private fun layer(chunks: Array<String>): Bitmap {
        val w = ClosetArtData.WIDTH
        val h = ClosetArtData.HEIGHT
        val idx = ScreamerCodec.decode(chunks, w * h)
        val pal = ClosetArtData.PALETTE
        val px = IntArray(w * h) { pal[idx[it].toInt() and 0xFF] }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(px, 0, w, 0, 0, w, h)
        return bmp
    }

    /** Solo la capa "plush" del arte canónico de Ranita (sin decodificar las manos de la conversación). */
    private fun decodePlush(): Bitmap? {
        val d = ConversationArtData
        val i = d.LAYER_NAMES.indexOf("plush")
        if (i < 0) return null
        val r = d.LAYER_RECT[i]
        val w = r[2]
        val h = r[3]
        val out = IntArray(w * h)
        var pos = 0
        val alphabet = d.ALPHABET
        for (s in d.LAYER_DATA[i]) {
            var k = 0
            while (k + 2 < s.length && pos < out.size) {
                val idx = alphabet.indexOf(s[k]) * 64 + alphabet.indexOf(s[k + 1])
                val run = s[k + 2].code - 48
                val color = d.PALETTE[idx]
                var n = 0
                while (n < run && pos < out.size) { out[pos++] = color; n++ }
                k += 3
            }
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(out, 0, w, 0, 0, w, h)
        return bmp
    }

    /** Libera los bitmaps (al salir del armario). */
    fun release() {
        armsSelf?.recycle(); armsSelf = null
        armsPlush?.recycle(); armsPlush = null
        plush?.recycle(); plush = null
        face?.recycle(); face = null
    }
}
