package com.terror2d.scene

import com.terror2d.closet.ClosetView
import com.terror2d.creature.Arrival
import com.terror2d.creature.Blocker
import com.terror2d.creature.ClosetMemory
import com.terror2d.creature.ClosetReaction
import com.terror2d.creature.Connector
import com.terror2d.creature.ConnectorKind
import com.terror2d.creature.CreatureState
import com.terror2d.creature.CreatureTracker
import com.terror2d.creature.ScreamerView
import com.terror2d.world.BulbState
import com.terror2d.world.LightHealth
import com.terror2d.world.WindowTarget
import com.terror2d.creature.CaptureSequence
import com.terror2d.creature.Creature
import com.terror2d.creature.NoiseBus
import com.terror2d.creature.NoiseEvent
import com.terror2d.creature.NoiseType
import com.terror2d.creature.Senses

import com.terror2d.audio.Surface
import com.terror2d.conversation.ConversationDef
import com.terror2d.conversation.ConversationSystem
import com.terror2d.conversation.ConversationView
import com.terror2d.core.Camera
import com.terror2d.core.GameConfig
import com.terror2d.core.GameState
import com.terror2d.draw.BackdropBuilder
import com.terror2d.draw.CrayonSprite
import com.terror2d.events.EventBus
import com.terror2d.events.EventListener
import com.terror2d.events.EventType
import com.terror2d.events.GameEvent
import com.terror2d.events.TriggerContext
import com.terror2d.input.InputAction
import com.terror2d.input.InputController
import com.terror2d.interaction.Interactable
import com.terror2d.interaction.InteractionContext
import com.terror2d.interaction.InteractionIcon
import com.terror2d.interaction.PlayerActionKind
import com.terror2d.interaction.PlayerActionRequest
import com.terror2d.interaction.InteractionResult
import com.terror2d.inventory.ItemRegistry
import com.terror2d.world.PlushFrog
import com.terror2d.render.WorldRenderer
import com.terror2d.render.Palette
import com.terror2d.puzzle.MedicinePuzzle
import com.terror2d.story.DocumentDef
import com.terror2d.story.Documents
import com.terror2d.story.ScriptContext
import com.terror2d.story.StoryFlags
import com.terror2d.ui.DialogueManager
import com.terror2d.util.SeededRandom
import com.terror2d.world.Layer
import com.terror2d.world.LightField
import com.terror2d.world.LightSource
import com.terror2d.world.LightType
import com.terror2d.world.Player
import com.terror2d.world.PlayerState
import com.terror2d.world.SketchBuilder
import com.terror2d.world.Wardrobe
import com.terror2d.world.WorldObject

/**
 * Escena base (vista LATERAL): contiene el segmento activo, jugador, cámara, colisiones y el
 * sistema de interacción. Una escena (p. ej. la casa) se compone de varios [RoomSegment]
 * conectados por puertas; solo uno está cargado a la vez.
 *
 * Interacción (v0.3): cada frame la escena busca el [Interactable] más cercano al jugador, publica su
 * acción en el botón (genérico) y, al pulsar, llama a executeInteraction() e interpreta el
 * [InteractionResult] (texto, transición...). No hay lógica por tipo de objeto.
 */
abstract class Scene(val definition: SceneDefinition) {

    val id: String get() = definition.id

    lateinit var currentSegment: RoomSegment
        private set
    val width: Float get() = currentSegment.width
    val height: Float get() = currentSegment.height

    val camera = Camera(GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat())
    lateinit var player: Player
        private set

    /** Bus de eventos de esta escena. */
    val events = EventBus()

    /** Texto del juego: mensajes breves y base de diálogos. */
    val dialogue = DialogueManager()

    /** Transición entre segmentos (puerta -> fundido -> carga -> fundido). */
    val transition = SceneTransition()

    /** Resplandor tenue alrededor del jugador (nunca se pierde del todo de vista en la oscuridad). */
    val playerGlow = LightSource(
        x = 0f, y = 0f,
        radius = PLAYER_GLOW_RADIUS,
        color = Palette.LIGHT_GLOW or 0xFF000000.toInt(),
        intensity = PLAYER_GLOW_INTENSITY,
        type = LightType.GLOW,
        tintStrength = 0f
    )

    /** Interactuable enfocado ahora mismo (el que mostraría el botón de acción). */
    var focused: Interactable? = null
        private set

    /** El negro de la captura se suma al fundido de transición (la captura no es un Game Over: es un despertar). */
    val transitionAlpha: Float get() = maxOf(transition.fadeAlpha, capture.blackAlpha, narrative.blackAlpha)

    /** v0.9: director de la secuencia narrativa (dormir, grito, habitación de mamá, primera aparición de la criatura). */
    val narrative: NarrativeDirector = NarrativeDirector(this)

    private var lastWeather = "CALM"

    /**
     * v0.9: la escena está en calma para la narrativa: sin transición, texto, documento, primera persona, conversación,
     * captura ni escondite. Las secuencias esperan a esto para no pisar nada.
     */
    val isFreeForNarrative: Boolean
        get() = ::player.isInitialized && !transition.isActive && !dialogue.isActive && reading == null &&
            !firstPerson.isActive && !conversation.isActive && !capture.active &&
            player.state == PlayerState.NORMAL && !player.isHidden

    // ---- v0.8: la criatura ----
    /** Ruidos recientes del niño y del mundo (la criatura los oye con posición aproximada). */
    val noise = NoiseBus()

    /** Criatura del segmento actual (null si no hay o aún no se activó). */
    var creature: Creature? = null
        private set

    /** Secuencia de captura: sin Game Over, termina despertando en el dormitorio. */
    val capture = CaptureSequence()

    private val creatureSenses = Senses()

    // ---- v0.10: survival
    /** Escena del armario en primera persona (la dibuja el renderer mientras el niño está escondido). */
    val closetView = ClosetView()
    /** Usos acumulados de cada armario (base de la escalada SUSPICION -> WARNING -> CAPTURE). */
    val closets = ClosetMemory()
    /** Presencia persistente de la criatura en toda la casa (la simulada en pantalla es [creature]). */
    var tracker: CreatureTracker? = null
        private set
    private val connectors: List<Connector> by lazy { definition.buildConnectors() }
    private val lightHealth = java.util.IdentityHashMap<LightSource, LightHealth>()
    private var lightBlockers: List<Blocker> = emptyList()
    private var lightSig = -1
    private var allBlockers: List<Blocker> = emptyList()
    private var playerInRefuge = false
    private var lastLightHits = 0
    private var pendingConnectorId: String? = null
    private var hidingClosetId: String? = null
    private var hideReaction = ClosetReaction.PASS
    private var prevHideState = PlayerState.NORMAL
    private var peekTimer = 0f
    private var offStepT = 0f
    private var offBreathT = 2f
    private var ambientT = 14f
    private var closetBreathT = 1f
    private var gapBlockers: List<Blocker> = emptyList()
    private var captureRelocated = false
    private var lastDuck = 1f
    private var creatureAudio: com.terror2d.creature.CreatureAudio? = null
    private var creatureAudioPort: com.terror2d.audio.AudioPort? = null
    private var lastCapturePhase = CaptureSequence.Phase.IDLE
    private var creatureDist = 9999f

    /** value del evento de paso: bit0 = persecución, resto = cercanía al niño (0..100) para el volumen. */
    private fun stepValue(chasing: Boolean): Int =
        (if (chasing) 1 else 0) or ((com.terror2d.creature.CreatureAudio.proximity(creatureDist) * 100f).toInt() shl 1)

    /** Cambio temporal a primera persona (puzzle de medicamentos). */
    val firstPerson = FirstPersonView()

    /** Puzzle activo (null fuera de la primera persona). */
    var puzzle: MedicinePuzzle? = null
        private set

    /** Documento abierto para leer (null = ninguno). */
    var reading: DocumentDef? = null
        private set

    /** Segundos desde que se abrió el documento (el renderer anima el papel). */
    var readingTime: Float = 0f
        private set

    /** v0.7: escena de conversación en primera persona (manos + peluche sobre negro). */
    val conversation = ConversationView()

    /** v0.7: reglas y cola de conversaciones del compañero. */
    val conversations = ConversationSystem(definition.conversations)

    private var activeConversation: ConversationDef? = null
    private var lastLineSerial = 0
    private var lastStepFrame = 0

    /** Superficie bajo los pies del niño (para los pasos): se deduce del suelo del segmento. */
    val footstepSurface: Surface
        get() = when (currentSegment.floorPattern) {
            FloorPattern.TILES -> Surface.TILE
            FloorPattern.CONCRETE -> Surface.GROUND
            else -> Surface.WOOD
        }

    private var puzzleEndPending = false

    private var stateRef: GameState? = null
    private var interactionContext: InteractionContext? = null

    private val objects = ArrayList<WorldObject>()
    private val solids = ArrayList<WorldObject>()
    private val backObjects = ArrayList<WorldObject>()   // FLOOR / DECOR (detrás de todo)
    private val midObjects = ArrayList<WorldObject>()    // OBJECT (muebles, puertas)
    private val frontObjects = ArrayList<WorldObject>()  // FOREGROUND (delante del jugador)
    private val interactables = ArrayList<Interactable>()

    /** Fondo de crayón del segmento, en tramos de 160 px (se genera una vez al cargar). */
    private var backdrop: Array<CrayonSprite> = emptyArray()
    private var scriptContext: ScriptContext? = null

    init {
        events.subscribeAll(EventListener { e -> dispatch(e) })
        events.subscribeAll(EventListener { e -> conversations.onEvent(e) })
    }

    fun load(state: GameState) {
        stateRef = state
        state.audioListener?.let { events.subscribeAll(it) }
        loadSegment(definition.startSegmentId, definition.startSpawnId, state)
    }

    /**
     * Carga un segmento y coloca al jugador en el spawn indicado (la transición con fundido la
     * gestiona [SceneTransition]; este método es la carga en sí).
     */
    fun loadSegment(segmentId: String, spawnId: String, state: GameState) {
        stateRef = state
        // v0.10: si se llegó por una puerta/ventana, la criatura decide qué hace (la ventana rompe la persecución)
        val usedConnectorId = pendingConnectorId
        pendingConnectorId = null
        var windowUsed: String? = null
        var focusLost = false
        val tr0 = tracker
        if (usedConnectorId != null && tr0 != null) {
            val cn = tr0.connectorById(usedConnectorId)
            if (cn != null) {
                val wasChasing = tr0.state == CreatureState.CHASE && tr0.segId == cn.fromSeg
                tr0.onPlayerLeft(cn)
                if (cn.kind == ConnectorKind.WINDOW) { windowUsed = cn.id; focusLost = wasChasing }
            }
        } else if (usedConnectorId != null && usedConnectorId.startsWith("window_")) windowUsed = usedConnectorId
        closetView.abort()
        hidingClosetId = null
        prevHideState = PlayerState.NORMAL
        peekTimer = 0f
        val ctx: InteractionContext = interactionContext?.takeIf { it.state === state }
            ?: InteractionContext(events, state).also { interactionContext = it }

        val seg = definition.segmentFor(segmentId, state.worldMode)
        currentSegment = seg
        focused = null
        dialogue.clear()
        val sc = scriptContext?.takeIf { it.state === state } ?: ScriptContext(dialogue, state, events).also { scriptContext = it }
        sc.segmentId = seg.id

        objects.clear()
        solids.clear()
        backObjects.clear()
        midObjects.clear()
        frontObjects.clear()
        interactables.clear()

        // Todas las puertas y armarios vuelven a su estado inicial al cambiar de segmento.
        for (si in 0 until definition.segments.size) {
            val other = definition.segments[si]
            for (di in 0 until other.doors.size) other.doors[di].reset()
            for (oi in 0 until other.objects.size) {
                val o = other.objects[oi]
                if (o is Wardrobe) o.reset()
            }
        }
        objects.addAll(seg.objects)
        objects.addAll(seg.doors)
        // v0.7: si el compañero está en esta habitación, el mundo lo "descubre" (NOT_FOUND -> ON_FLOOR)
        for (i in 0 until seg.objects.size) if (seg.objects[i] is PlushFrog) state.inventory.companion.discover()

        // Imperfecciones visuales deterministas: dependen de la semilla de la escena, del índice
        // del segmento y del índice del objeto (nunca del orden de ejecución).
        var segIndex = definition.segments.indexOf(seg)
        if (segIndex < 0) segIndex = 1000 + definition.traumaSegments.indexOf(seg)
        val segSeed = SeededRandom.derive(definition.seed, SEGMENT_SALT + segIndex)
        for (i in 0 until objects.size) {
            objects[i].prepareVisuals(SeededRandom(SeededRandom.derive(segSeed, i + 1)))
        }
        backdrop = BackdropBuilder.build(seg, SeededRandom.derive(segSeed, BACKDROP_SALT))

        for (i in 0 until objects.size) {
            val o = objects[i]
            if (o.collidable) solids.add(o)
            if (o is Interactable) interactables.add(o)
            when {
                o.layer < Layer.OBJECT -> backObjects.add(o)
                o.layer == Layer.OBJECT -> midObjects.add(o)
                else -> frontObjects.add(o)
            }
        }
        // Las luces de la habitación empiezan en su estado real (sin fundido desde apagado).
        for (i in 0 until seg.lights.size) seg.lights[i].update(10f)

        val sp = seg.spawn(spawnId)
        player = Player(sp.x - Player.WIDTH / 2f, seg.floorY - Player.HEIGHT)
        player.facing = if (sp.facing < 0) -1f else 1f
        camera.configure(seg.width, seg.height, seg.cameraMode)
        camera.snapTo(player.centerX)
        syncGlow()
        playerGlow.update(10f)

        ctx.player = player
        ctx.segment = seg

        state.currentSceneId = id
        state.currentSegmentId = seg.id
        state.playerX = player.x
        state.playerY = player.y
        state.playerHidden = false
        onLoad(state)
        // v0.10: tras la introducción, el survival se activa al cambiar de habitación (nunca antes de tiempo)
        if (state.story.has(StoryFlags.SURVIVAL_READY) && !state.story.has(StoryFlags.CREATURE_ACTIVE) && !narrative.creatureIntro.active) {
            state.story.set(StoryFlags.CREATURE_ACTIVE)
            events.post(EventType.CREATURE_ACTIVATED, "creature", seg.id)
        }
        setupCreature(seg, state)
        refreshNarrative(state)
        narrative.onSegmentLoaded(state)
        if (windowUsed != null) {
            events.post(EventType.WINDOW_CROSSED, windowUsed, seg.id)
            makeNoise(NoiseType.WINDOW, player.centerX)
            if (focusLost) events.post(EventType.CREATURE_FOCUS_LOST, "creature", seg.id)
        }

        events.post(EventType.ON_ENTER_ROOM, seg.id, seg.id)
    }

    open fun onLoad(state: GameState) {}

    /**
     * v0.9: avisa a los objetos que dependen del progreso (mamá, cama, ventana, nota) y recalcula el tiempo que se oye
     * en esta habitación. Se llama al cargar un segmento y cada vez que avanza una fase.
     */
    fun refreshNarrative(state: GameState) {
        val story = state.story
        var rainHere = false
        for (i in 0 until objects.size) {
            val o = objects[i]
            if (o is com.terror2d.world.NarrativeAware) o.onNarrative(story)
        }
        // los objetos de TODOS los segmentos reflejan la fase (p. ej. la ventana rota ya está rota al volver a entrar)
        for (si in 0 until definition.segments.size) {
            val os = definition.segments[si].objects
            for (oi in 0 until os.size) {
                val o = os[oi]
                if (o is com.terror2d.world.NarrativeAware) o.onNarrative(story)
            }
        }
        for (i in 0 until objects.size) {
            val o = objects[i]
            if (o is com.terror2d.world.RainSource && o.isRaining) rainHere = true
        }
        val weather = when {
            rainHere -> "STORM_INSIDE"
            story.isAtLeast(com.terror2d.story.NarrativePhase.PLUSH_UNLOCKED) -> "STORM_FAR"
            else -> "CALM"
        }
        if (weather != lastWeather) {
            lastWeather = weather
            events.post(EventType.WEATHER_CHANGED, weather, currentSegment.id)
        }
    }

    /** v0.9: la criatura de 0.8, sin cambios, colocada para su primera aparición guionizada (la IA no corre). */
    fun spawnScriptedCreature(x: Float) {
        val seg = currentSegment
        val c = Creature(x, seg.id, x - 400f, x + 400f, 8)
        c.floorY = seg.floorY
        c.onStep = { _, chasing -> events.postTransient(EventType.CREATURE_STEP, "creature", seg.id, stepValue(chasing)) }
        creature = c
    }

    fun clearCreature() {
        creature = null
    }

    /**
     * Coloca a la criatura si su condición (CREATURE_ACTIVE) se cumple y está en este segmento. v0.10: la criatura es
     * persistente en toda la casa ([tracker]); aquí solo se "materializa" si está en la habitación del niño.
     * Los huecos estrechos son bloqueos para ella.
     */
    private fun setupCreature(seg: RoomSegment, state: GameState) {
        creature = null
        val blockers = ArrayList<Blocker>()
        for (i in 0 until seg.objects.size) {
            val o = seg.objects[i]
            if (o is com.terror2d.world.NarrowGap) blockers.add(Blocker(o.x, o.x + o.width, blocksSight = false))
        }
        gapBlockers = blockers
        allBlockers = blockers
        lightSig = -1
        lightBlockers = emptyList()
        playerInRefuge = false
        val spawn = definition.creature ?: return
        val flag = spawn.requiredFlag
        if (flag != null && !state.story.has(flag)) { tracker = null; return }
        val tr = tracker ?: CreatureTracker(connectors, spawn.segmentId, spawn.x).also { tracker = it }
        tr.setLive(false)
        if (tr.segId == seg.id) {
            materialize(seg, tr.x, tr.state, tr.lastKnownX, tr.facing, tr.arousal, spawn.seed, spawn.segmentId == seg.id, spawn.minX, spawn.maxX)
        }
    }

    private fun materialize(seg: RoomSegment, x: Float, st: CreatureState, known: Float, face: Float, arousal: Float,
                            seed: Int, home: Boolean, homeMin: Float, homeMax: Float) {
        val pMin = if (home) homeMin else seg.leftBoundary + 70f
        val pMax = if (home) homeMax else seg.rightBoundary - 70f
        val c = Creature(x, seg.id, pMin, pMax, seed, seg.leftBoundary + 30f, seg.rightBoundary - 30f)
        c.floorY = seg.floorY
        c.onStep = { _, chasing -> events.postTransient(EventType.CREATURE_STEP, "creature", seg.id, stepValue(chasing)) }
        c.onStateChanged = { _, to -> events.postTransient(EventType.CREATURE_STATE, to.name, seg.id) }
        if (st != CreatureState.PATROL) c.brain.restore(st, known, face, arousal)
        lastLightHits = c.brain.lightHits
        creature = c
        tracker?.setLive(true)
    }

    private fun materializeArrival(arr: Arrival, seg: RoomSegment, state: GameState) {
        val spawn = definition.creature
        materialize(seg, arr.x, arr.state, arr.lastKnownX, arr.facing, 0.6f, spawn?.seed ?: 8, false, 0f, 0f)
    }

    /** Prueba/depuración: coloca a la criatura en el segmento actual aunque no se haya cumplido su condición. */
    fun forceCreature(state: GameState, x: Float, minX: Float, maxX: Float, seed: Int = 8) {
        val seg = currentSegment
        val c = Creature(x, seg.id, minX, maxX, seed)
        c.floorY = seg.floorY
        c.onStep = { _, chasing -> events.postTransient(EventType.CREATURE_STEP, "creature", seg.id, stepValue(chasing)) }
        c.onStateChanged = { _, to -> events.postTransient(EventType.CREATURE_STATE, to.name, seg.id) }
        creature = c
    }

    /** Emite un ruido con posición (la criatura investigará la posición aproximada, nunca la del niño directamente). */
    fun makeNoise(type: NoiseType, x: Float, intensity: Float = type.base) {
        noise.emit(NoiseEvent(x, currentSegment.id, type, intensity, type.duration, stateRef?.elapsedTime ?: 0f))
    }

    private fun updateCreature(dt: Float, state: GameState) {
        val seg = currentSegment
        updateLights(dt, seg)
        updateClosetScene(dt, state)
        // la captura tiene prioridad: avanza sola, recoloca al niño en su dormitorio y devuelve el control
        if (capture.active) {
            capture.update(dt)
            if (capture.phase != lastCapturePhase) {
                lastCapturePhase = capture.phase
                if (lastCapturePhase == CaptureSequence.Phase.FREEZE && capture.fromCloset) {
                    state.audio.playSfx(com.terror2d.audio.SfxId.CLOSET_CREAK, 1f)
                    state.audio.playSfx(com.terror2d.audio.SfxId.CLOSET_DOOR, 1f)
                }
                // el niño respira en la oscuridad; luego silencio
                if (lastCapturePhase == CaptureSequence.Phase.BREATH) state.audio.playSfx(com.terror2d.audio.SfxId.BREATH, 0.9f)
                if (lastCapturePhase == CaptureSequence.Phase.IDLE) {
                    state.audio.playMusic(com.terror2d.audio.MusicId.HOME, 4f)
                    state.audio.duck(1f, 1.5f)
                    lastDuck = 1f
                }
                if (lastCapturePhase == CaptureSequence.Phase.WAKE) {
                    state.audio.playMusic(com.terror2d.audio.MusicId.SILENCE, 0.5f)
                    state.audio.playSfx(com.terror2d.audio.SfxId.CLOTH, 0.7f)
                }
            }
            // sonido SINCRONIZADO con los fotogramas del screamer (embestida, rugido, agarre)
            if (capture.phase == CaptureSequence.Phase.SCREAMER) {
                when (capture.screamer.consumeCue()) {
                    ScreamerView.CUE_IMPACT -> state.audio.playSfx(com.terror2d.audio.SfxId.SCREAM_IMPACT, 1f)
                    ScreamerView.CUE_ROAR -> state.audio.playSfx(com.terror2d.audio.SfxId.SCREAM_ROAR, 1f)
                    ScreamerView.CUE_GRAB -> state.audio.playSfx(com.terror2d.audio.SfxId.SCREAM_GRAB, 1f)
                    ScreamerView.CUE_FINAL -> state.audio.playSfx(com.terror2d.audio.SfxId.SCREAM_FINAL, 1f)
                }
            }
            if (kotlin.math.abs(capture.audioDuck - lastDuck) > 0.08f) { lastDuck = capture.audioDuck; state.audio.duck(lastDuck, 0.25f) }
            if (capture.shouldRelocate && !captureRelocated) {
                captureRelocated = true
                state.captureCount++
                state.story.set(StoryFlags.CREATURE_FIRST_CAPTURE)
                // la criatura vuelve a su sitio y el armario "olvida" (el niño despierta a salvo; el progreso NO se toca)
                val home = definition.creature
                if (home != null) tracker?.resetTo(home.segmentId, home.x)
                hidingClosetId?.let { closets.forgive(it) }
                closetView.abort()
                loadSegment(definition.startSegmentId, definition.startSpawnId, state)
            }
            if (capture.done) captureRelocated = false
            return
        }
        val intro = narrative.creatureIntro
        if (creature == null) {
            val tr = tracker
            if (tr != null && !intro.active) {
                val arr = tr.update(dt, seg.id)
                if (arr != null) materializeArrival(arr, seg, state)
                offscreenAudio(dt, state, tr)
            }
            ambientHouse(dt, state)
        }
        val c = creature ?: return
        noise.prune(state.elapsedTime)
        val s = creatureSenses
        val hiding = player.state == PlayerState.ENTERING_HIDE || player.state == PlayerState.HIDDEN
        s.playerX = player.centerX
        s.playerSegmentId = seg.id
        s.playerHidden = player.isHidden
        s.playerHiding = hiding
        s.playerInRefuge = playerInRefuge
        s.closetReaction = if (hiding) hideReaction.ordinal else 0
        s.playerLight = player.light.brightness
        s.blockers = allBlockers
        s.now = state.elapsedTime
        // la criatura recibe la MISMA iluminación del mundo que el niño
        LightField.sample(c.x, seg.floorY - Creature.HEIGHT * 0.5f, seg.lights, seg.ambientDark, seg.darkZones, state.elapsedTime, c.light)
        creatureDist = c.distanceTo(player.centerX)
        if (intro.active) {
            // v0.9: primera aparición guionizada: no ve, no oye, no persigue, no captura
            c.gaze = intro.gaze
            c.updateScripted(dt, intro.goalX, intro.speed, intro.facing)
        } else {
            c.gaze = false
            c.update(dt, s, noise.recent)
            // v0.10: la presencia persistente copia el estado real de la criatura en pantalla
            tracker?.syncLive(seg.id, c.x, c.state, c.brain.lastKnownX, c.facing, c.arousal)
            tracker?.setLive(true)
            if (c.brain.consumePeek()) {
                peekTimer = 2.4f
                events.post(EventType.CREATURE_CLOSET_PEEK, hidingClosetId ?: "closet", seg.id)
            }
            if (c.brain.lightHits != lastLightHits) {
                lastLightHits = c.brain.lightHits
                wearNearestRefuge(c.x, seg)
            }
        }
        if (creatureAudioPort !== state.audio) {
            creatureAudioPort = state.audio
            creatureAudio = com.terror2d.creature.CreatureAudio(state.audio)
        }
        creatureAudio?.update(dt, c, creatureDist)
        if (!intro.active && c.brain.captured && !c.capturing) {
            c.capturing = true
            capture.start(c.brain.closetCapture)
            captureRelocated = false
            events.post(EventType.CREATURE_CAPTURE, "creature", seg.id)
        }
    }

    // ------------------------------------------------------------------ v0.10: luces de refugio

    /** Salud y zonas seguras de los focos fuertes de este segmento. Cada foco tiene su propio estado. */
    private fun updateLights(dt: Float, seg: RoomSegment) {
        var sig = 0
        var idx = 0
        var inRefuge = false
        for (i in 0 until seg.lights.size) {
            val l = seg.lights[i]
            if (!LightHealth.isRefugeCandidate(l)) continue
            val h = lightHealth.getOrPut(l) { LightHealth(l, seg.id + "#" + i) }
            h.update(dt)
            if (idx < 30 && h.protects()) {
                sig = sig or (1 shl idx)
                if (kotlin.math.abs(player.centerX - l.x) < LightHealth.refugeHalfWidth(l) - 4f) inRefuge = true
            }
            idx++
        }
        playerInRefuge = inRefuge
        if (sig != lightSig) {
            lightSig = sig
            val lb = ArrayList<Blocker>()
            for (i in 0 until seg.lights.size) {
                val l = seg.lights[i]
                if (!LightHealth.isRefugeCandidate(l)) continue
                val h = lightHealth[l] ?: continue
                if (h.protects()) {
                    val half = LightHealth.refugeHalfWidth(l)
                    lb.add(Blocker(l.x - half, l.x + half, blocksSight = false, isLight = true))
                }
            }
            lightBlockers = lb
            allBlockers = gapBlockers + lb
        }
    }

    /** Cada vez que la luz detiene a la criatura el foco más cercano se desgasta (parpadea, se daña, se rompe). */
    private fun wearNearestRefuge(cx: Float, seg: RoomSegment) {
        var best: LightHealth? = null
        var bd = 9999f
        for (i in 0 until seg.lights.size) {
            val l = seg.lights[i]
            if (!LightHealth.isRefugeCandidate(l)) continue
            val h = lightHealth[l] ?: continue
            if (!h.protects()) continue
            val d = kotlin.math.abs(l.x - cx)
            if (d < bd) { bd = d; best = h }
        }
        val h = best ?: return
        val st = h.use()
        if (st == BulbState.BROKEN) {
            events.post(EventType.LIGHT_BROKEN, h.id, seg.id)
            makeNoise(NoiseType.LIGHT_BREAK, h.source.x)
            lightSig = -1
        } else if (st != BulbState.OK) events.post(EventType.LIGHT_DEGRADED, h.id, seg.id, st.ordinal)
    }

    /** Estado de un foco de refugio por índice (pruebas/depuración). */
    fun lightHealthOf(segmentId: String, index: Int): LightHealth? {
        val seg = definition.segments.firstOrNull { it.id == segmentId } ?: return null
        return lightHealth[seg.lights.getOrNull(index) ?: return null]
    }

    // ------------------------------------------------------------------ v0.10: armario (primera persona)

    /** Desde DENTRO del armario no se ve el propio mueble (ni al niño): solo el exterior por la rendija. */
    private fun isOwnClosetSeenFromInside(o: WorldObject): Boolean =
        closetView.active && closetView.blend > 0.05f && o is Wardrobe && o.id == hidingClosetId

    private fun updateClosetScene(dt: Float, state: GameState) {
        val ps = player.state
        if (ps == PlayerState.ENTERING_HIDE && prevHideState == PlayerState.NORMAL) {
            var best: Wardrobe? = null
            var bd = 9999f
            for (i in 0 until objects.size) {
                val o = objects[i]
                if (o is Wardrobe) {
                    val d = kotlin.math.abs(o.centerX - player.centerX)
                    if (d < bd) { bd = d; best = o }
                }
            }
            val w = best
            hidingClosetId = w?.id
            hideReaction = if (w != null) closets.register(w.id) else ClosetReaction.PASS
        }
        if (ps == PlayerState.HIDDEN && prevHideState != PlayerState.HIDDEN) closetView.begin(state.inventory.companion.isCarried)
        if (ps == PlayerState.LEAVING_HIDE && prevHideState == PlayerState.HIDDEN) closetView.end()
        if (ps == PlayerState.NORMAL && closetView.active) closetView.end()
        prevHideState = ps
        if (peekTimer > 0f) peekTimer -= dt
        closetView.setPeeking(peekTimer > 0f)
        val c = creature
        val danger = if (c != null && ps == PlayerState.HIDDEN) com.terror2d.creature.CreatureAudio.proximity(creatureDist) else 0f
        // v0.10.1: el dedo desplaza la rendija; los botones de movimiento quedan desactivados mientras está escondido
        val inCloset = closetView.active && ps == PlayerState.HIDDEN
        val inp = inputRef
        if (inp != null) {
            inp.closetMode = inCloset
            var dragDx = inp.consumeClosetDrag()
            if (inCloset) {
                if (inp.leftHeld) dragDx -= KEY_SLIT_SPEED * dt          // teclado / emulador
                if (inp.rightHeld) dragDx += KEY_SLIT_SPEED * dt
                closetView.drag(dragDx)
            }
        }
        // el rostro de la criatura solo aparece si de verdad está junto a la puerta, mirando hacia el armario
        val faceNear = c != null && inCloset && peekTimer > 0f && kotlin.math.abs(c.x - player.centerX) < FACE_PEEK_RANGE
        closetView.setFace(if (faceNear && c != null) c.x - camera.snappedX else Float.NaN)
        closetView.update(dt, danger)
        // sonido de la criatura cerca (pasos y respiración), solo si de verdad está cerca; el silencio también cuenta
        if (inCloset && c != null && danger > 0.12f) {
            closetStepT -= dt
            if (closetStepT <= 0f && c.brain.speed > 1f) {
                state.audio.playSfx(com.terror2d.audio.SfxId.CREATURE_STEP, 0.15f + 0.45f * danger)
                closetStepT = 0.75f - 0.3f * danger
            }
            closetNearBreathT -= dt
            if (closetNearBreathT <= 0f && danger > 0.35f) {
                state.audio.playSfx(com.terror2d.audio.SfxId.CREATURE_BREATH_SEARCH, 0.25f + 0.4f * danger)
                closetNearBreathT = 4.2f
            }
        }
        if (closetView.active && closetView.blend > 0.6f) {
            closetBreathT -= dt
            if (closetBreathT <= 0f) {
                state.audio.playSfx(com.terror2d.audio.SfxId.BREATH, 0.25f + 0.5f * closetView.danger)
                closetBreathT = 3.4f - 2.0f * closetView.danger
            }
        }
        // el niño contiene la respiración mientras la criatura escucha junto al armario
        val listening = c != null && c.brain.listening
        if (listening != holdingBreath) { holdingBreath = listening; state.audio.duck(if (listening) 0.35f else 1f, 0.4f) }
    }
    private var holdingBreath = false
    /** Último controlador de entrada recibido en [update] (el armario necesita el arrastre del dedo). */
    private var inputRef: InputController? = null
    private var closetStepT = 0f
    private var closetNearBreathT = 2f

    // ------------------------------------------------------------------ v0.10: audio fuera de pantalla

    private fun isAdjacent(a: String, b: String): Boolean {
        for (i in 0 until connectors.size) {
            val c = connectors[i]
            if ((c.fromSeg == a && c.toSeg == b) || (c.fromSeg == b && c.toSeg == a)) return true
        }
        return false
    }

    /** Se oye a la criatura a través de la pared cuando está en una habitación conectada (o a punto de entrar). */
    private fun offscreenAudio(dt: Float, state: GameState, tr: CreatureTracker) {
        val here = currentSegment.id
        val near = isAdjacent(tr.segId, here) || (tr.isCrossing && tr.plannedConnector?.toSeg == here)
        if (!near) return
        offStepT -= dt
        if (offStepT <= 0f) {
            val chasing = tr.state == CreatureState.CHASE
            offStepT = if (chasing) 0.42f else if (tr.isCrossing) 0.8f else 1.4f
            state.audio.playSfx(com.terror2d.audio.SfxId.CREATURE_STEP_FAR, if (chasing) 0.5f else 0.3f)
        }
        offBreathT -= dt
        if (offBreathT <= 0f) { offBreathT = 4.5f; state.audio.playSfx(com.terror2d.audio.SfxId.CREATURE_BREATH_FAR, 0.35f) }
    }

    /** Sonidos lejanos de la casa, espaciados y con silencios entre ellos (solo con el survival activo). */
    private fun ambientHouse(dt: Float, state: GameState) {
        if (!state.story.has(StoryFlags.CREATURE_ACTIVE)) return
        ambientT -= dt
        if (ambientT <= 0f) {
            ambientT = 11f + ((state.elapsedTime * 7.3f) % 1f) * 16f
            val id = if (((state.elapsedTime * 3.1f) % 1f) < 0.5f) com.terror2d.audio.SfxId.FAR_CREAK else com.terror2d.audio.SfxId.FAR_THUD
            state.audio.playSfx(id, 0.35f)
        }
    }

    open fun unload(state: GameState) {
        // v0.7: al salir de la escena la conversación se corta y el compañero vuelve a la espalda
        conversation.abort()
        activeConversation = null
        state.inventory.companion.endTalk()
    }

    /**
     * Orden: texto -> transición -> jugador -> objetos/luces -> enfoque -> acción -> cámara.
     * Con una transición o un diálogo en curso el jugador no se mueve.
     */
    open fun update(dt: Float, input: InputController, state: GameState) {
        inputRef = input
        dialogue.update(dt)
        if (dialogue.lineSerial != lastLineSerial) {
            lastLineSerial = dialogue.lineSerial
            val cur = dialogue.current
            // el sistema de audio da voz (balbuceo) al niño ("KID") y a los personajes; la lógica solo avisa
            if (cur != null) events.postTransient(EventType.DIALOGUE_LINE, cur.speaker ?: "KID", currentSegment.id, cur.text.length)
        }

        if (transition.update(dt)) {
            val t = transition.target
            if (t != null) {
                loadSegment(t.segmentId, t.spawnId, state)
                input.actionEnabled = false
                return
            }
        }

        val seg = currentSegment
        val ctx = interactionContext ?: return
        ctx.time = state.elapsedTime
        val sc = scriptContext
        if (sc != null) {
            val scripts = definition.scripts
            for (i in 0 until scripts.size) scripts[i].update(dt, sc)
        }
        val doc = reading
        val fp = firstPerson
        val conv = conversation
        narrative.update(dt, state)
        val locked = transition.isActive || dialogue.blocksInput || fp.isActive || doc != null || conv.isActive || capture.active ||
            narrative.controlLocked
        // la conversación, como el puzzle, es primera persona: los botones se ignoran y el dedo es un puntero
        input.puzzleMode = fp.isActive || conv.isActive
        if (doc != null) readingTime += dt
        // la boca del niño se mueve mientras habla (sus líneas no llevan nombre de personaje)
        val cur = dialogue.current
        player.speaking = cur != null && cur.speaker == null && !dialogue.isFullyRevealed
        if (fp.update(dt)) {
            puzzle = null
            puzzleEndPending = false
            events.post(EventType.ON_PUZZLE_ENDED, MedicinePuzzle.ID, currentSegment.id)
        }
        if (fp.isActive) updatePuzzle(dt, input, ctx)
        if (conv.isActive && conv.update(dt, input.pointerPressed)) endConversation(state, input)

        player.heldItemId = state.inventory.held
        player.companionItemId = if (state.inventory.companion.isCarried) state.inventory.companion.itemId else null
        input.heldItemId = state.inventory.held
        val moveCmd = if (narrative.autoWalking) narrative.walkDir else if (locked) 0f else input.moveX
        player.update(dt, moveCmd, solids, seg.floorY, seg.leftBoundary, seg.rightBoundary)
        for (i in 0 until objects.size) objects[i].update(dt)
        for (i in 0 until seg.lights.size) seg.lights[i].update(dt)
        // pasos: un evento por cada vez que un pie toca el suelo (el audio decide cómo suenan según la superficie)
        val wf = player.walkFrame
        if (wf != lastStepFrame) {
            lastStepFrame = wf
            if ((wf == 1 || wf == 3) && (!locked || narrative.autoWalking) && player.state == PlayerState.NORMAL) {
                events.postTransient(EventType.FOOTSTEP, "player", seg.id)
                makeNoise(NoiseType.WALK, player.centerX)
            }
        }
        syncGlow()
        playerGlow.update(dt)

        // El personaje recibe la MISMA iluminación que el resto del mundo (luces de la habitación).
        LightField.sample(
            player.centerX, player.y + Player.HEIGHT * 0.5f,
            seg.lights, seg.ambientDark, seg.darkZones, state.elapsedTime, player.light
        )

        // --- Enfoque: el interactuable más cercano al alcance ---
        focused = if (locked) null else findFocus(ctx)

        // --- Botón de acción (genérico: icono y texto vienen del interactuable) ---
        val f = focused
        // HABLAR con el compañero: solo a la espalda, con las manos vacías y el mundo en calma
        val inv = state.inventory
        val canTalk = !locked && player.state == PlayerState.NORMAL && !player.isHidden && inv.companion.canTalk(inv.handState)
        input.talkEnabled = canTalk
        if (canTalk) input.talkLabel = inv.companion.talkLabel
        if (doc != null) {
            input.actionEnabled = !fp.isActive
            input.actionIcon = InteractionIcon.NEXT
            input.actionLabel = "CERRAR"
        } else if (conv.isActive) {
            input.actionEnabled = false
        } else if (fp.isActive) {
            input.actionEnabled = false
        } else if (dialogue.blocksInput) {
            input.actionEnabled = true
            input.actionIcon = InteractionIcon.NEXT
            input.actionLabel = "SEGUIR"
        } else if (f != null) {
            input.actionEnabled = true
            input.actionIcon = f.iconFor(ctx)
            input.actionLabel = f.promptFor(ctx)
        } else {
            input.actionEnabled = false
        }

        // --- Pulsación ---
        if (doc != null) {
            val close = if (fp.isActive) input.pointerPressed else input.wasPressed(InputAction.INTERACT)
            if (close && readingTime > 0.25f) closeDocument(ctx)
        } else if (fp.isActive) {
            // en primera persona no hay botón de acción: el dedo arrastra las cajas (updatePuzzle)
        } else if (input.wasPressed(InputAction.INTERACT)) {
            if (dialogue.blocksInput) {
                dialogue.advance()
            } else if (f != null && !transition.isActive) {
                interact(f, ctx)
            }
        }

        // --- v0.7: conversaciones del compañero (HABLAR a mano o disparadas por eventos) ---
        if (canTalk && input.wasPressed(InputAction.TALK) && !transition.isActive) startManualTalk(state)
        val quiet = !locked && !conv.isActive && player.state == PlayerState.NORMAL && !player.isHidden
        val next = conversations.update(dt, quiet, state)
        if (next != null) startConversation(next, state)

        updateCreature(dt, state)
        camera.follow(player.centerX, dt)
        state.playerX = player.x
        state.playerY = player.y
        state.playerHidden = player.isHidden
    }

    /** Ejecuta un interactuable e interpreta el resultado. Público para poder probarlo. */
    fun interact(target: Interactable, ctx: InteractionContext) {
        val res = target.executeInteraction(ctx)
        applyResult(target, res, ctx)
    }

    private fun applyResult(target: Interactable?, res: InteractionResult, ctx: InteractionContext) {
        if (!res.handled) return
        if (target != null) events.post(EventType.ON_INTERACT, target.interactionId, currentSegment.id)
        val msg = res.message
        if (msg != null) dialogue.showMessage(msg, res.speaker)
        val ls = res.lines
        if (ls != null) dialogue.startDialogue(ls)
        val t = res.transition
        if (t != null) {
            pendingConnectorId = (t as? WindowTarget)?.windowId ?: res.transitionDoor?.id
            transition.start(t, res.transitionDoor)
        }
        val req = res.action
        if (req != null) startPlayerAction(req, ctx)
        val docId = res.documentId
        if (docId != null) openDocument(docId, ctx)
        if (res.startPuzzle) beginPuzzle(ctx)
    }

    // ------------------------------------------------------------------ conversación con el compañero (v0.7)

    private fun startManualTalk(state: GameState) {
        val def = conversations.requestManual(state) ?: return
        events.post(EventType.FROG_TALK, state.inventory.companion.itemId ?: "companion", currentSegment.id)
        startConversation(def, state)
    }

    /** TERCERA PERSONA -> escena de conversación en primera persona. El compañero pasa a TALKING. */
    fun startConversation(def: ConversationDef, state: GameState) {
        if (conversation.isActive) return
        if (!state.inventory.companion.beginTalk()) return
        conversations.markStarted(def)
        activeConversation = def
        player.speaking = false
        conversation.begin(def, state.audio)
        events.post(EventType.CONVERSATION_STARTED, def.id, currentSegment.id)
    }

    /** Conversación -> gameplay: el compañero vuelve a ON_BACK y se anuncia el final. */
    private fun endConversation(state: GameState, input: InputController) {
        val d = activeConversation
        activeConversation = null
        state.inventory.companion.endTalk()
        input.actionEnabled = false
        if (d != null) {
            conversations.markEnded(d)
            events.post(EventType.CONVERSATION_ENDED, d.id, currentSegment.id)
        }
    }

    // ------------------------------------------------------------------ documentos (v0.6)

    /** Abre un documento para leerlo. El niño solo reacciona al cerrarlo, como un niño de 8 años. */
    fun openDocument(id: String, ctx: InteractionContext) {
        val d = Documents.get(id) ?: return
        reading = d
        readingTime = 0f
        ctx.post(EventType.ON_DOCUMENT_READ, id)
        ctx.setFlag(d.readFlag)
    }

    fun closeDocument(ctx: InteractionContext) {
        val d = reading ?: return
        reading = null
        readingTime = 0f
        if (firstPerson.isActive) {
            val first = d.reaction.firstOrNull()
            if (first != null) dialogue.showMessage(first.text, first.speaker)
        } else {
            dialogue.startDialogue(d.reaction)
        }
    }

    // ------------------------------------------------------------------ puzzle de medicamentos (v0.6)

    /** TERCERA PERSONA -> PRIMERA PERSONA: la cámara se acerca a la mesita y se ve desde los ojos del niño. */
    fun beginPuzzle(ctx: InteractionContext) {
        if (firstPerson.isActive) return
        puzzle = MedicinePuzzle()
        puzzleEndPending = false
        firstPerson.begin()
        ctx.setFlag(StoryFlags.PUZZLE_STARTED)
        ctx.post(EventType.ON_PUZZLE_STARTED, MedicinePuzzle.ID)
        dialogue.showMessage("Las cajitas están todas revueltas. Las pongo en su sitio.")
    }

    /** PRIMERA PERSONA -> TERCERA PERSONA. */
    fun endPuzzle() {
        if (!firstPerson.isActive || puzzleEndPending) return
        puzzleEndPending = true
        firstPerson.end()
    }

    private fun updatePuzzle(dt: Float, input: InputController, ctx: InteractionContext) {
        val p = puzzle ?: return
        if (firstPerson.isPlayable && reading == null && !puzzleEndPending) {
            // el dedo = la mano del niño: tocar, mantener, arrastrar y soltar
            if (input.pointerPressed) p.onPress(input.pointerX, input.pointerY)
            if (input.pointerDown) p.onDrag(input.pointerX, input.pointerY)
            if (input.pointerReleased) p.onRelease(input.pointerX, input.pointerY)
            val req = p.requestedDocument
            if (req != null) {
                p.requestedDocument = null
                openDocument(req, ctx)
            }
            if (p.wantsExit) {
                p.wantsExit = false
                endPuzzle()
            }
        }
        p.update(dt)
        if (p.justSolved) {
            p.justSolved = false
            ctx.setFlag(StoryFlags.MEDICINE_PUZZLE_DONE)
            ctx.setFlag(StoryFlags.MEDICINE_CODE_KNOWN)
            ctx.post(EventType.MEDICINE_PUZZLE_COMPLETED, MedicinePuzzle.ID)
            // feedback discreto: las cajas quedan en su sitio, brillan suavemente y el niño lo nota
            dialogue.showMessage("S… O… L. Cada una en su sitio.")
        }
        if (p.solved && p.solvedTime >= MedicinePuzzle.SOLVED_HOLD) endPuzzle()
        val hint = p.pendingHint
        if (hint != 0) {
            p.pendingHint = 0
            dialogue.showMessage(if (hint == 1) "Mejor miro las cajitas por detrás." else "La hoja de la farmacia dice algo.")
        }
    }

    /** Recoger / entregar: animación del niño y, al acabar, cambios de inventario y la continuación. */
    private fun startPlayerAction(req: PlayerActionRequest, ctx: InteractionContext) {
        val newState = if (req.kind == PlayerActionKind.PICKUP) PlayerState.PICKING_UP else PlayerState.GIVING
        val seconds = if (req.kind == PlayerActionKind.PICKUP) PICKUP_TIME else GIVE_TIME
        player.beginAction(newState, seconds) {
            val inv = ctx.inventory
            val segId = currentSegment.id
            if (req.kind == PlayerActionKind.PICKUP) {
                val def = ItemRegistry.get(req.itemId)
                if (def != null && def.companion) {
                    // v0.7: un COMPAÑERO va a su espacio propio (a la espalda); las manos siguen libres
                    if (inv.companion.pickUp(req.itemId)) {
                        events.post(EventType.ON_ITEM_PICKED, req.itemId, segId)
                        events.post(EventType.COMPANION_PICKED_UP, req.itemId, segId)
                    }
                } else if (inv.add(req.itemId)) {
                    inv.hold(req.itemId)
                    events.post(EventType.ON_ITEM_PICKED, req.itemId, segId)
                }
            } else {
                inv.remove(req.itemId, 1)
                if (inv.held == req.itemId) inv.release()
                events.post(EventType.ON_ITEM_GIVEN, req.itemId, segId)
            }
            val follow = req.after?.invoke(ctx)
            if (follow != null) applyResult(null, follow, ctx)
        }
    }

    /** Interactuable más cercano al que el jugador puede llegar y usar ahora. */
    private fun findFocus(ctx: InteractionContext): Interactable? {
        var best: Interactable? = null
        var bestDist = Float.MAX_VALUE
        val px = player.centerX
        val usable = player.state == com.terror2d.world.PlayerState.NORMAL
        for (i in 0 until interactables.size) {
            val cand = interactables[i]
            if (!usable && !cand.worksWhileHidden) continue
            if (!cand.isInRange(player)) continue
            if (!cand.canInteract(ctx)) continue
            val d = kotlin.math.abs((cand.zoneLeft + cand.zoneRight) * 0.5f - px)
            if (d < bestDist) {
                bestDist = d
                best = cand
            }
        }
        return best
    }

    private fun syncGlow() {
        playerGlow.x = player.centerX
        playerGlow.y = player.bottom - Player.HEIGHT * 0.55f
        playerGlow.active = player.visibilityAlpha > 0.5f
    }

    private fun dispatch(e: GameEvent) {
        // eventos transitorios de audio (pasos, líneas de texto): ni depuración ni reglas narrativas
        if (e.type == EventType.FOOTSTEP || e.type == EventType.DIALOGUE_LINE || e.type == EventType.CREATURE_STEP) return
        val st = stateRef ?: return
        st.lastEvent = e.toString()
        if (e.type == EventType.ON_DOOR_OPEN && ::player.isInitialized) makeNoise(NoiseType.DOOR, player.centerX)
        // la entrega del agua tiene evento propio de alto nivel (disparador de la conversación A y del audio)
        if (e.type == EventType.ON_STORY_FLAG && e.sourceId == StoryFlags.WATER_DELIVERED) {
            events.post(EventType.WATER_DELIVERED, e.sourceId, e.segmentId)
        }
        narrative.onEvent(e, st)
        val ts = definition.triggers
        for (i in 0 until ts.size) {
            val t = ts[i]
            if (t.matches(e)) t.fire(TriggerContext(e, dialogue, st))
        }
        val sc = scriptContext
        if (sc != null) {
            val scripts = definition.scripts
            for (i in 0 until scripts.size) scripts[i].onEvent(e, sc)
        }
    }

    /**
     * Dibuja en coordenadas del mundo (la transformación de cámara ya está aplicada). Pipeline:
     * fondo -> decoración -> objetos -> jugador -> primer plano -> ILUMINACIÓN (máscara de oscuridad
     * abierta por las luces) -> marca de interacción (encima de la oscuridad, para poder encontrarla).
     */
    open fun render(r: WorldRenderer) {
        val seg = currentSegment
        r.drawBackdrop(seg, backdrop, camera.snappedX)

        for (i in 0 until backObjects.size) {
            val o = backObjects[i]
            if (o.visible && camera.isVisible(o) && !isOwnClosetSeenFromInside(o)) o.render(r)
        }
        for (i in 0 until midObjects.size) {
            val o = midObjects[i]
            if (o.visible && camera.isVisible(o) && !isOwnClosetSeenFromInside(o)) o.render(r)
        }
        creature?.let { r.drawCreature(it) }
        if (!(closetView.active && closetView.blend > 0.05f)) player.render(r)
        for (i in 0 until frontObjects.size) {
            val o = frontObjects[i]
            if (o.visible && camera.isVisible(o) && !isOwnClosetSeenFromInside(o)) o.render(r)
        }

        r.drawLighting(seg, camera.snappedX, camera.snappedY, playerGlow)

        val f = focused
        if (f != null && !transition.isActive && !dialogue.blocksInput) r.drawInteractMarker(f.markerX, f.markerY)
    }

    /** Huella de todo el aspecto generado del segmento cargado: misma semilla => mismo valor (tests). */
    fun visualFingerprint(): Long {
        var h = 1125899906842597L
        for (i in 0 until backdrop.size) h = backdrop[i].hash(h)
        for (i in 0 until objects.size) h = objects[i].visualHash(h)
        return h
    }

    companion object {
        private const val SEGMENT_SALT = 0x5E60
        private const val BACKDROP_SALT = 0x7F10

        /** Duración de las animaciones de recoger y entregar. */
        const val PICKUP_TIME = 0.7f
        const val GIVE_TIME = 0.6f

        /** v0.10.1: velocidad de la rendija con el teclado (px lógicos/s) y alcance en que el rostro se asoma a la puerta. */
        const val KEY_SLIT_SPEED = 70f
        const val FACE_PEEK_RANGE = 90f

        const val PLAYER_GLOW_RADIUS = 36f
        const val PLAYER_GLOW_INTENSITY = 0.42f
    }
}
