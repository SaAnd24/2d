package com.terror2d.pixel

import java.util.zip.Inflater

/**
 * v0.10.1: decodifica los fotogramas de [ScreamerArtData] (base64 -> zlib -> un byte de paleta por píxel).
 * Solo usa la JVM estándar (sin android.*), de modo que las pruebas unitarias pueden comprobar el arte.
 */
object ScreamerCodec {
    private val B64 = IntArray(128) { -1 }.also { t ->
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
        for (i in chars.indices) t[chars[i].code] = i
    }

    fun base64(chunks: Array<String>): ByteArray {
        var n = 0
        for (c in chunks) n += c.length
        val out = ByteArray(n / 4 * 3 + 3)
        var o = 0
        var acc = 0
        var bits = 0
        for (c in chunks) for (ch in c) {
            val v = if (ch.code < 128) B64[ch.code] else -1
            if (v < 0) continue                       // '=' y cualquier otro carácter
            acc = (acc shl 6) or v
            bits += 6
            if (bits >= 8) { bits -= 8; out[o++] = ((acc shr bits) and 0xFF).toByte() }
        }
        return out.copyOf(o)
    }

    /** Índices de paleta (WIDTH*HEIGHT bytes) del fotograma [index]. */
    fun indices(index: Int): ByteArray = decode(ScreamerArtData.FRAME_DATA[index], ScreamerArtData.WIDTH * ScreamerArtData.HEIGHT)

    /** base64 -> zlib -> [size] bytes. También lo usa el arte del armario ([ClosetArtData]). */
    fun decode(chunks: Array<String>, size: Int): ByteArray {
        val z = base64(chunks)
        val inf = Inflater()
        inf.setInput(z)
        val out = ByteArray(size)
        var pos = 0
        while (pos < out.size && !inf.finished()) {
            val n = inf.inflate(out, pos, out.size - pos)
            if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break
            pos += n
        }
        inf.end()
        return out
    }

    /** Píxeles ARGB opacos del fotograma [index]. */
    fun argb(index: Int): IntArray {
        val idx = indices(index)
        val pal = ScreamerArtData.PALETTE
        return IntArray(idx.size) { pal[idx[it].toInt() and 0xFF] }
    }
}
