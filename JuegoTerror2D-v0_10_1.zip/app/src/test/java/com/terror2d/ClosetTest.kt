package com.terror2d

import com.terror2d.closet.ClosetView
import com.terror2d.input.InputController
import com.terror2d.pixel.ClosetArtData
import com.terror2d.pixel.ScreamerCodec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** v0.10.1: interior del armario (máscara negra con rendija arrastrable) y su arte propio. */
class ClosetTest {
    private val dt = 1f / 60f

    private fun active(frog: Boolean = false): ClosetView {
        val v = ClosetView()
        v.begin(frog)
        repeat(40) { v.update(dt, 0f) }
        return v
    }

    @Test fun slitStartsCenteredAndDragMovesIt() {
        val v = active()
        assertEquals(ClosetView.DEFAULT_SLIT_X, v.slitCenter, 0.5f)
        v.drag(60f)
        repeat(60) { v.update(dt, 0f) }
        assertEquals(ClosetView.DEFAULT_SLIT_X + 60f, v.slitCenter, 0.6f)
        v.drag(-100f)
        repeat(60) { v.update(dt, 0f) }
        assertEquals(ClosetView.DEFAULT_SLIT_X - 40f, v.slitCenter, 0.6f)
    }

    @Test fun slitNeverLeavesTheScreen() {
        val v = active()
        v.drag(5000f); repeat(120) { v.update(dt, 0f) }
        assertTrue(v.slitRight <= 320f && v.slitCenter <= ClosetView.SLIT_MAX + 0.01f)
        v.drag(-9000f); repeat(120) { v.update(dt, 0f) }
        assertTrue(v.slitLeft >= 0f && v.slitCenter >= ClosetView.SLIT_MIN - 0.01f)
    }

    @Test fun slitIsNarrowAndStaysContinuousWhileMoving() {
        val v = active()
        assertTrue("rendija estrecha", v.slitWidth in ClosetView.MIN_WIDTH..ClosetView.MAX_WIDTH)
        v.drag(120f)
        var prev = v.slitCenter
        var maxStep = 0f
        var monotonic = true
        repeat(90) {
            v.update(dt, 0f)
            val c = v.slitCenter
            if (c < prev - 0.0001f) monotonic = false
            maxStep = maxOf(maxStep, c - prev)
            prev = c
            assertTrue("sin huecos: los bordes son exactamente centro ± ancho/2", Math.abs((v.slitRight - v.slitLeft) - v.slitWidth) < 0.001f)
        }
        assertTrue("avanza sin retroceder (sin parpadeo)", monotonic)
        assertTrue("sin saltos bruscos entre fotogramas (paso acotado)", maxStep < 60f)
    }

    @Test fun dragDoesNothingWhenNotHidden() {
        val v = ClosetView()
        v.drag(50f)
        assertEquals(ClosetView.DEFAULT_SLIT_X, v.slitTarget, 0.001f)
        val w = active()
        w.end()
        w.drag(50f)
        assertEquals("al salir ya no obedece al dedo", ClosetView.DEFAULT_SLIT_X, w.slitTarget, 0.001f)
    }

    @Test fun lookingAroundDoesNotChangeDangerOrPeek() {
        val a = active(); val b = active()
        b.drag(80f)
        repeat(60) { a.update(dt, 0.2f); b.update(dt, 0.2f) }
        assertEquals(a.danger, b.danger, 0.0001f)
        assertEquals(a.peek, b.peek, 0.0001f)
        assertTrue("mirar no es un ruido ni una acción del juego: el estado de peligro es el mismo", b.dragTotal > 0f)
    }

    @Test fun frogIsOnlyShownIfTheChildCarriesHer() {
        assertTrue(active(true).withFrog)
        assertFalse(active(false).withFrog)
    }

    @Test fun creatureFaceOnlyAppearsWhereTheSceneSaysItReallyIs() {
        val v = active()
        assertTrue(v.faceX.isNaN())
        v.setFace(150f)
        assertEquals(150f, v.faceX, 0.001f)
        v.setFace(Float.NaN)
        assertTrue(v.faceX.isNaN())
        v.setFace(90f)
        v.abort()
        assertTrue("al abortar no queda rostro", v.faceX.isNaN())
    }

    // ------------------------------------------------------------------ entrada táctil

    @Test fun dragFeedsTheSlitAndNeverMovesTheChild() {
        val input = InputController()
        input.closetMode = true
        input.closetDragPoint(true, 100f)
        input.closetDragPoint(true, 140f)
        input.closetDragPoint(true, 150f)
        assertEquals(50f, input.consumeClosetDrag(), 0.001f)
        assertEquals("consumir limpia el acumulado", 0f, input.consumeClosetDrag(), 0.001f)
        assertEquals("el arrastre no genera movimiento", 0f, input.moveX, 0f)
        assertFalse(input.leftHeld || input.rightHeld)
        input.closetDragPoint(false, 150f)
        input.closetDragPoint(true, 20f)               // un dedo nuevo no hereda la posición anterior
        assertEquals(0f, input.consumeClosetDrag(), 0.001f)
    }

    @Test fun dragIsIgnoredOutsideTheCloset() {
        val input = InputController()
        input.closetMode = false
        input.closetDragPoint(true, 100f)
        input.closetDragPoint(true, 200f)
        assertEquals(0f, input.consumeClosetDrag(), 0.001f)
    }

    // ------------------------------------------------------------------ arte propio del escondite

    @Test fun closetArmsHaveTheirOwnArtAndAreDifferentFromEachOther() {
        val n = ClosetArtData.WIDTH * ClosetArtData.HEIGHT
        val self = ScreamerCodec.decode(ClosetArtData.HUG_SELF, n)
        val plush = ScreamerCodec.decode(ClosetArtData.HUG_PLUSH, n)
        fun opaque(a: ByteArray) = a.count { it.toInt() != 0 }
        assertTrue("brazos visibles", opaque(self) > 4000 && opaque(plush) > 4000)
        var diff = 0
        for (i in 0 until n) if (self[i] != plush[i]) diff++
        assertTrue("las dos composiciones no son la misma ilustración", diff > 4000)
        // casi toda la pantalla queda negra/transparente: solo se distinguen los brazos
        assertTrue(opaque(self) < n / 3 && opaque(plush) < n / 3)
        // y los brazos están en la mitad inferior (se ven desde el pecho, no flotando arriba)
        var top = 0
        for (y in 0 until ClosetArtData.HEIGHT / 3) for (x in 0 until ClosetArtData.WIDTH) if (self[y * ClosetArtData.WIDTH + x].toInt() != 0) top++
        assertEquals("el tercio superior del arte sin Ranita está vacío", 0, top)
    }
}
