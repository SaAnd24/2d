package com.terror2d

import com.terror2d.core.GameState
import com.terror2d.creature.Blocker
import com.terror2d.creature.CaptureSequence
import com.terror2d.creature.ClosetMemory
import com.terror2d.creature.ClosetReaction
import com.terror2d.creature.Connector
import com.terror2d.creature.ConnectorKind
import com.terror2d.creature.CreatureAudio
import com.terror2d.creature.CreatureBrain
import com.terror2d.creature.CreatureState
import com.terror2d.creature.CreatureTracker
import com.terror2d.creature.NoiseEvent
import com.terror2d.creature.NoiseType
import com.terror2d.creature.ScreamerView
import com.terror2d.creature.Senses
import com.terror2d.audio.SfxId
import com.terror2d.input.InputAction
import com.terror2d.input.InputController
import com.terror2d.pixel.ScreamerArtData
import com.terror2d.pixel.ScreamerCodec
import com.terror2d.scene.HouseDefinition
import com.terror2d.scene.HouseScene
import com.terror2d.scene.buildConnectors
import com.terror2d.story.StoryFlags
import com.terror2d.world.BulbState
import com.terror2d.world.LightHealth
import com.terror2d.world.LightSource
import com.terror2d.world.LightType
import com.terror2d.world.Player
import com.terror2d.world.WindowPassage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pruebas de 0.10: carrera de desgaste, ventanas que rompen la persecución, armario, captura, luces y audio. */
class SurvivalTest {

    private val dt = 1f / 60f

    private fun brain(x: Float = 400f) = CreatureBrain(x, "hall", 100f, 3000f, seed = 3)

    /** Avanza la IA [seconds] segundos. [onTick] puede mover al niño. */
    private fun run(b: CreatureBrain, s: Senses, seconds: Float, noises: List<NoiseEvent> = emptyList(), onTick: (Float) -> Unit = {}) {
        var t = 0f
        while (t < seconds && !b.captured) {
            s.now += dt
            onTick(t)
            b.update(dt, s, noises)
            t += dt
        }
    }

    // ------------------------------------------------------------------ velocidad / desgaste

    @Test fun creatureIsFasterThanTheChildButNotByTooMuch() {
        val ratio = CreatureBrain.CHASE_SPEED / Player.SPEED
        assertTrue("más rápida que el niño", ratio > 1.1f)
        assertTrue("pero no abrumadora (carrera de desgaste)", ratio < 1.45f)
        assertTrue("arranca más lenta que el niño: hay ventana para escapar", CreatureBrain.CHASE_START_SPEED < Player.SPEED)
    }

    @Test fun runningChildIsNotCaughtInstantly() {
        val b = brain(400f)
        val s = Senses(playerX = 560f, playerSegmentId = "hall")
        run(b, s, 6f) { s.playerX += Player.SPEED * dt }
        assertFalse("un niño que corre sin dudar no es alcanzado en 6 s", b.captured)
    }

    @Test fun childWhoHesitatesIsEventuallyCaught() {
        val b = brain(400f)
        val s = Senses(playerX = 560f, playerSegmentId = "hall")
        run(b, s, 20f)          // el niño se queda quieto
        assertTrue(b.captured)
    }

    @Test fun childGainsDistanceAtTheStartOfTheChase() {
        val b = brain(400f)
        val s = Senses(playerX = 520f, playerSegmentId = "hall")
        run(b, s, 1.2f) { s.playerX += Player.SPEED * dt }
        assertTrue("al principio la distancia crece", s.playerX - b.x > 120f)
    }

    // ------------------------------------------------------------------ ventanas: rompen la persecución

    private val window = Connector("w1", ConnectorKind.WINDOW, "a", 300f, "b", 100f)
    private val door = Connector("d1", ConnectorKind.DOOR, "a", 40f, "hall", 80f)

    @Test fun windowBreaksChaseIntoLostTargetKeepingLastKnownPosition() {
        val tr = CreatureTracker(listOf(window, door), "a", 200f)
        tr.syncLive("a", 200f, CreatureState.CHASE, 300f, 1f, 1f)
        assertTrue(tr.onPlayerLeft(window))
        assertEquals(CreatureState.LOST_TARGET, tr.state)
        assertEquals(300f, tr.lastKnownX, 0.01f)
    }

    @Test fun creatureCrossesTheWindowLaterAndKeepsSearchingNotChasing() {
        val tr = CreatureTracker(listOf(window, door), "a", 200f)
        tr.syncLive("a", 200f, CreatureState.CHASE, 300f, 1f, 1f)
        tr.onPlayerLeft(window)
        var arrival = tr.update(0f, "b")
        var t = 0f
        while (arrival == null && t < 20f) { arrival = tr.update(dt, "b"); t += dt }
        assertNotNull(arrival)
        assertEquals("b", arrival!!.segmentId)
        assertEquals(CreatureState.LOST_TARGET, arrival.state)
        assertTrue("tarda: el niño gana unos segundos", t > 1.5f)
    }

    @Test fun doorDoesNotBreakTheChase() {
        val tr = CreatureTracker(listOf(window, door), "a", 200f)
        tr.syncLive("a", 200f, CreatureState.CHASE, 40f, -1f, 1f)
        assertTrue(tr.onPlayerLeft(door))
        var arrival = tr.update(0f, "hall")
        var t = 0f
        while (arrival == null && t < 20f) { arrival = tr.update(dt, "hall"); t += dt }
        assertEquals(CreatureState.CHASE, arrival!!.state)
    }

    @Test fun windowOnlyAffectsACreatureInTheSameRoom() {
        val tr = CreatureTracker(listOf(window, door), "c", 100f)
        tr.syncLive("c", 100f, CreatureState.PATROL, 100f, 1f, 0f)
        assertFalse(tr.onPlayerLeft(window))
    }

    @Test fun brainLoseFocusLeavesChaseAndInvestigatesLastKnownPosition() {
        val b = brain(400f)
        val s = Senses(playerX = 520f, playerSegmentId = "hall")
        run(b, s, 1.5f)
        assertEquals(CreatureState.CHASE, b.state)
        b.loseFocus(700f)
        s.playerSegmentId = "other"
        assertEquals(CreatureState.LOST_TARGET, b.state)
        assertEquals(700f, b.lastKnownX, 0.01f)
        val before = Math.abs(b.x - 700f)
        run(b, s, 2f)
        assertTrue(Math.abs(b.x - 700f) < before)
        run(b, s, 40f)
        assertTrue(b.state == CreatureState.RETURN_TO_PATROL || b.state == CreatureState.PATROL)
    }

    @Test fun afterLosingFocusNoiseOrSightFindsTheChildAgain() {
        // por sonido
        val b = brain(400f)
        val s = Senses(playerX = 900f, playerSegmentId = "hall")
        b.loseFocus(300f)
        run(b, s, 0.5f, listOf(NoiseEvent(520f, "hall", NoiseType.OBJECT_BROKEN, 1f, 1.5f, s.now)))
        assertTrue(b.state == CreatureState.INVESTIGATE || b.state == CreatureState.LOST_TARGET && b.targetX > 400f)
        // por vista
        val b2 = brain(400f)
        val s2 = Senses(playerX = 480f, playerSegmentId = "hall")
        b2.loseFocus(300f)
        run(b2, s2, 1.0f)
        assertEquals(CreatureState.CHASE, b2.state)
    }

    @Test fun everyLabRoomHasAWindowToTheNextOne() {
        val def = HouseScene(HouseDefinition.DEFAULT_SEED).also { it.load(GameState()) }.definition
        val conns = def.buildConnectors()
        val chain = HouseDefinition.LAB_CHAIN
        for ((i, room) in chain.withIndex()) {
            val next = chain[(i + 1) % chain.size]
            val w = def.segment(room).objects.filterIsInstance<WindowPassage>()
            assertEquals("una ventana en $room", 1, w.size)
            assertEquals(next, w[0].target.segmentId)
            assertNotNull(def.segment(next).spawnPoints[HouseDefinition.WINDOW_SPAWN])
            assertTrue(conns.any { it.kind == ConnectorKind.WINDOW && it.fromSeg == room && it.toSeg == next })
        }
    }

    // ------------------------------------------------------------------ armario

    @Test fun creatureCapturesWhenItSawTheChildHide() {
        val b = brain(400f)
        val s = Senses(playerX = 520f, playerSegmentId = "hall")
        run(b, s, 1.0f)
        s.playerHiding = true
        run(b, s, 0.2f)
        s.playerHidden = true
        run(b, s, 8f)
        assertTrue(b.captured)
        assertTrue(b.closetCapture)
    }

    @Test fun creatureDoesNotCaptureWhenItDidNotSeeHim() {
        val b = brain(250f)
        val s = Senses(playerX = 520f, playerSegmentId = "hall", playerHidden = true, playerHiding = true)
        b.loseFocus(300f)
        run(b, s, 25f)
        assertFalse(b.captured)
        assertNotEquals(CreatureState.CHASE, b.state)
    }

    @Test fun creatureStopsToListenNextToAnOccupiedCloset() {
        val b = brain(470f)
        val s = Senses(playerX = 520f, playerSegmentId = "hall", playerHidden = true, playerHiding = true)
        b.loseFocus(520f)
        var listened = false
        run(b, s, 4f) { if (b.listening) listened = true }
        assertTrue(listened)
        assertFalse(b.captured)
    }

    @Test fun closetAbuseEscalatesPerCloset() {
        val m = ClosetMemory()
        assertEquals(ClosetReaction.PASS, m.register("a"))
        assertEquals(ClosetReaction.PASS, m.register("a"))
        assertEquals(ClosetReaction.SUSPICION, m.register("a"))
        assertEquals(ClosetReaction.WARNING, m.register("a"))
        assertEquals("otro armario, otro contador", ClosetReaction.PASS, m.register("b"))
        m.register("a"); assertEquals(ClosetReaction.CAPTURE, m.register("a"))
        m.forgive("a")
        assertEquals(ClosetReaction.PASS, m.current("a"))
    }

    // ------------------------------------------------------------------ luces

    @Test fun lightBlocksTheCreatureAndItGivesUp() {
        val b = brain(400f)
        val s = Senses(playerX = 560f, playerSegmentId = "hall", playerInRefuge = true,
            blockers = listOf(Blocker(500f, 620f, false, true)))
        run(b, s, 4f)
        assertTrue("no entra en la zona iluminada", b.x + CreatureBrain.HALF_BODY <= 500.5f)
        assertTrue(b.lightHits >= 1)
        run(b, s, 3.5f)
        assertNotEquals("acaba rindiéndose", CreatureState.CHASE, b.state)
        assertFalse(b.captured)
    }

    @Test fun eachBulbHasItsOwnHealth() {
        val l1 = LightSource(100f, 40f, 100f, 0xFFFFFFFF.toInt(), 0.9f, LightType.LAMP)
        val l2 = LightSource(300f, 40f, 100f, 0xFFFFFFFF.toInt(), 0.9f, LightType.LAMP)
        val h1 = LightHealth(l1, "l1")
        val h2 = LightHealth(l2, "l2")
        repeat(3) { h1.use() }
        assertEquals(BulbState.FLICKERING, h1.state)
        assertEquals(BulbState.OK, h2.state)
        repeat(4) { h1.use() }
        assertEquals(BulbState.BROKEN, h1.state)
        assertFalse(h1.protects())
        assertEquals(BulbState.OK, h2.state)
        assertTrue(LightHealth.isRefugeCandidate(l1))
    }

    // ------------------------------------------------------------------ captura / screamer

    @Test fun screamerHasManyDedicatedFramesAndSyncedAudioCues() {
        assertEquals(ScreamerView.FRAME_COUNT, ScreamerArtData.FRAME_COUNT)
        assertTrue("secuencia larga y fluida", ScreamerView.FRAME_COUNT >= 16)
        assertEquals(ScreamerView.FRAME_COUNT, ScreamerArtData.FRAME_DATA.size)
        assertEquals(ScreamerView.FRAME_COUNT, ScreamerView.FRAME_START.size)
        val v = ScreamerView()
        v.begin()
        val frames = HashSet<Int>()
        val cues = ArrayList<Int>()
        val cueFrames = ArrayList<Int>()
        var t = 0f
        while (t < ScreamerView.DURATION) {
            v.update(dt); t += dt
            frames.add(v.frame)
            val c = v.consumeCue()
            if (c >= 0) { cues.add(c); cueFrames.add(v.frame) }
        }
        assertEquals(ScreamerView.FRAME_COUNT, frames.size)
        assertEquals(listOf(0, 1, 2, 3), cues)
        // cada cue suena en el fotograma exacto en que cambia la imagen (sin desfase)
        assertEquals(listOf(ScreamerView.FRAME_IMPACT, ScreamerView.FRAME_ROAR, ScreamerView.FRAME_GRAB, ScreamerView.FRAME_FINAL), cueFrames)
    }

    @Test fun screamerFramesAreStrictlyIncreasingInTime() {
        for (i in 1 until ScreamerView.FRAME_START.size) assertTrue(ScreamerView.FRAME_START[i] > ScreamerView.FRAME_START[i - 1])
        assertTrue(ScreamerView.FRAME_START.last() < ScreamerView.DURATION)
    }

    @Test fun screamerArtDecodesAndEveryFrameIsDenseAndDistinct() {
        val w = ScreamerArtData.WIDTH
        val h = ScreamerArtData.HEIGHT
        var prev: ByteArray? = null
        for (i in 0 until ScreamerArtData.FRAME_COUNT) {
            val idx = ScreamerCodec.indices(i)
            assertEquals(w * h, idx.size)
            val used = HashSet<Int>()
            for (b in idx) used.add(b.toInt() and 0xFF)
            assertTrue("fotograma $i con paleta rica (no un sprite plano)", used.size >= 14)
            for (k in used) assertTrue(k < ScreamerArtData.PALETTE.size)
            val p = prev
            if (p != null) {
                var diff = 0
                for (k in idx.indices) if (idx[k] != p[k]) diff++
                assertTrue("el fotograma $i cambia respecto al anterior", diff > w * h / 20)
            }
            prev = idx
        }
    }

    @Test fun screamerFirstFrameKeepsTheCanonicalFaceLayout() {
        // el primer fotograma es la cara canónica completa: ojos rojos arriba, boca de dientes claros abajo y negro a los lados
        val idx = ScreamerCodec.indices(0)
        val w = ScreamerArtData.WIDTH
        val h = ScreamerArtData.HEIGHT
        val pal = ScreamerArtData.PALETTE
        fun lum(x: Int, y: Int): Int { val c = pal[idx[y * w + x].toInt() and 0xFF]; return ((c shr 16) and 255) + ((c shr 8) and 255) + (c and 255) }
        assertTrue("bordes laterales casi negros", lum(10, h / 2) < 60 && lum(w - 10, h / 2) < 60)
        var bright = 0
        for (y in h / 2 until h) for (x in w / 2 - 100 until w / 2 + 100) if (lum(x, y) > 330) bright++
        assertTrue("dientes claros en la mitad inferior central", bright > 400)
        var red = 0
        for (y in 20 until h / 2) for (x in w / 2 - 140 until w / 2 + 140) { val c = pal[idx[y * w + x].toInt() and 0xFF]; if (((c shr 16) and 255) > ((c shr 8) and 255) + 40) red++ }
        assertTrue("ojos rojizos en la mitad superior", red > 150)
    }

    @Test fun screamerAudioIsStrongButNotClipping() {
        // todas las voces del screamer se renderizan y el mezclador las pasa por su limitador suave (|x| < 1)
        for (id in listOf(SfxId.SCREAM_IMPACT, SfxId.SCREAM_ROAR, SfxId.SCREAM_GRAB, SfxId.SCREAM_FINAL)) {
            assertTrue(SfxId.values().contains(id))
        }
        val v = com.terror2d.audio.softClip(4f)
        assertTrue("el limitador acota incluso picos muy altos", Math.abs(v) <= 1.0f)
    }

    @Test fun captureGoesThroughScreamerAndEndsWithoutGameOver() {
        val c = CaptureSequence()
        c.start()
        val seen = HashSet<CaptureSequence.Phase>()
        var n = 0
        while (!c.done && n < 60 * 20) {
            c.update(dt); seen.add(c.phase); assertFalse(c.isGameOver); n++
        }
        assertTrue(seen.contains(CaptureSequence.Phase.SCREAMER))
        assertTrue(c.done)
    }

    // ------------------------------------------------------------------ audio

    @Test fun creatureBreathingChangesCharacterWithState() {
        val a = CreatureAudio(com.terror2d.audio.NullAudioPort)
        assertEquals(SfxId.CREATURE_BREATH_CHASE, a.breathFor(CreatureState.CHASE))
        assertEquals(SfxId.CREATURE_BREATH_SEARCH, a.breathFor(CreatureState.LOST_TARGET))
        assertEquals(SfxId.CREATURE_BREATH, a.breathFor(CreatureState.PATROL))
        assertTrue(a.breathPeriod(CreatureState.CHASE, 1f) < a.breathPeriod(CreatureState.LOST_TARGET, 0.5f))
    }

    // ------------------------------------------------------------------ escena

    private class World(active: Boolean = true) {
        val state = GameState()
        val input = InputController()
        val scene = HouseScene(HouseDefinition.DEFAULT_SEED).also { it.load(state) }
        init { if (active) state.story.set(StoryFlags.CREATURE_ACTIVE) }
        fun step(n: Int = 1) = repeat(n) { scene.update(1f / 60f, input, state); input.endFrame() }
        fun press() { input.setAction(InputAction.INTERACT, true); step(1); input.setAction(InputAction.INTERACT, false); step(1) }
        fun go(seg: String, spawn: String) { scene.loadSegment(seg, spawn, state); scene.dialogue.clear() }
    }

    @Test fun playerCrossesAWindowAndLandsInTheNextRoom() {
        val w = World()
        w.go(HouseDefinition.KID, "start")
        val win = w.scene.currentSegment.objects.filterIsInstance<WindowPassage>().first()
        w.scene.player.x = win.centerX - w.scene.player.width / 2f
        w.step(2)
        w.press()
        w.step(120)
        assertEquals(HouseDefinition.BATH, w.scene.currentSegment.id)
    }

    @Test fun windowCrossingMakesTheChasingCreatureLoseFocus() {
        val w = World()
        w.go(HouseDefinition.HALL, w.scene.definition.segment(HouseDefinition.HALL).spawnPoints.keys.first())
        val tr = w.scene.tracker!!
        // la criatura persigue en el trastero; el niño cruza su ventana
        w.go(HouseDefinition.KITCHEN, "from_hall")
        tr.syncLive(HouseDefinition.KITCHEN, 200f, CreatureState.CHASE, 330f, 1f, 1f)
        w.scene.player.x = 300f
        val win = w.scene.currentSegment.objects.filterIsInstance<WindowPassage>().first()
        w.scene.player.x = win.centerX - w.scene.player.width / 2f
        w.step(2)
        w.press()
        w.step(120)
        assertEquals(HouseDefinition.DINING, w.scene.currentSegment.id)
        assertTrue(w.scene.events.wasPosted(com.terror2d.events.EventType.CREATURE_FOCUS_LOST))
        assertNotEquals(CreatureState.CHASE, tr.state)
    }

    @Test fun survivalActivatesOnlyAfterTheIntro() {
        val w = World(active = false)
        w.go(HouseDefinition.KID, "start")
        assertFalse(w.state.story.has(StoryFlags.CREATURE_ACTIVE))
        w.state.story.set(StoryFlags.SURVIVAL_READY)
        w.go(HouseDefinition.BATH, "from_hall")
        assertTrue(w.state.story.has(StoryFlags.CREATURE_ACTIVE))
    }

    @Test fun captureKeepsNarrativeProgress() {
        val w = World()
        w.state.story.set(StoryFlags.MOM_NOTE_READ)
        w.state.story.set(StoryFlags.CREATURE_INTRO_UNLOCKED)
        w.go(HouseDefinition.HALL, w.scene.definition.segment(HouseDefinition.HALL).spawnPoints.keys.first())
        val c = w.scene.creature!!
        w.scene.player.x = c.x + 40f
        var n = 0
        var saw = false
        while (n < 60 * 25 && !(saw && !w.scene.capture.active)) { w.step(); if (w.scene.capture.active) saw = true; n++ }
        assertTrue(saw)
        assertTrue(w.state.story.has(StoryFlags.MOM_NOTE_READ))
        assertTrue(w.state.story.has(StoryFlags.CREATURE_INTRO_UNLOCKED))
    }

    @Test fun pickingUpRanitaDoesNotTriggerTheTestCinematics() {
        val w = World()
        w.state.story.set(StoryFlags.PLUSH_AVAILABLE)
        w.go(HouseDefinition.KID, "start")
        w.scene.events.post(com.terror2d.events.EventType.WATER_DELIVERED, "x", HouseDefinition.KID)
        w.scene.events.post(com.terror2d.events.EventType.MEDICINE_PUZZLE_COMPLETED, "x", HouseDefinition.KID)
        w.step(600)
        assertFalse(w.scene.conversation.isActive)
        assertEquals(0, w.scene.conversations.pendingCount)
    }
}
