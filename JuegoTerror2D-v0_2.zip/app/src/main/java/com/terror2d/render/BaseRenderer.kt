package com.terror2d.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.terror2d.core.GameConfig
import com.terror2d.input.InputAction
import com.terror2d.input.InputController
import com.terror2d.scene.RoomSegment
import com.terror2d.world.Door
import com.terror2d.world.Player
import com.terror2d.world.WorldObject
import kotlin.math.round

/**
 * Renderizador base (etapa crayón). Todo el dibujo del mundo pasa por aquí.
 * Futuro: CrayonRenderer, GraphiteRenderer, ShadowRenderer, DistortionRenderer y
 * ScratchRenderer pueden heredar o componerse sobre esta clase. La iluminación ya tiene su
 * propia pieza ([LightingRenderer]) con puntos de integración en [drawLighting]/[drawVignette].
 * No crea objetos en el bucle de dibujo (Paint/Path/RectF reutilizados).
 */
open class BaseRenderer {

    protected lateinit var canvas: Canvas
    protected var corruption: Float = 0f

    protected val paint = Paint().apply {
        isAntiAlias = false
        isFilterBitmap = false
        isDither = false
        strokeCap = Paint.Cap.SQUARE
        strokeJoin = Paint.Join.MITER
    }

    private val textPaint = Paint().apply {
        isAntiAlias = true
        textSize = 7f
        typeface = Typeface.MONOSPACE
        color = Palette.OUTLINE
    }

    private val path = Path()
    private val oval = RectF()
    protected val lighting = LightingRenderer()

    open fun beginFrame(canvas: Canvas, visualCorruption: Float) {
        this.canvas = canvas
        this.corruption = visualCorruption
    }

    /**
     * Gancho de corrupción visual: 0.0 devuelve el color intacto.
     * Futuro: más saturación perdida, tintes, grafito...
     */
    protected open fun tint(c: Int): Int {
        val k = corruption
        if (k <= 0.001f) return c
        val a = (c ushr 24) and 0xFF
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        val gray = r * 0.30f + g * 0.59f + b * 0.11f
        val t = k * 0.85f
        val nr = (r + (gray - r) * t).toInt()
        val ng = (g + (gray - g) * t).toInt()
        val nb = (b + (gray - b) * t).toInt()
        return (a shl 24) or (nr shl 16) or (ng shl 8) or nb
    }

    /** Fondo de papel (zona lógica completa, coordenadas de pantalla lógica). */
    open fun drawBackground() {
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.PAPER)
        canvas.drawRect(0f, 0f, GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat(), paint)
    }

    /**
     * Fondo del segmento lateral (coordenadas del mundo): pared de papel pintado a crayón,
     * sombra en el techo, rodapié, suelo de madera y muros laterales oscuros en los límites.
     */
    open fun drawBackdrop(seg: RoomSegment, wall: FloatArray, floor: FloatArray, speckles: FloatArray) {
        val w = seg.width
        val h = seg.height
        val fy = seg.floorY

        // Pared
        paint.style = Paint.Style.FILL
        paint.color = tint(seg.wallColor)
        canvas.drawRect(0f, 0f, w, fy, paint)
        drawStrokes(wall, seg.wallStrokeColor, 1.4f)

        // Sombra del techo (contraste): tres bandas translúcidas
        paint.style = Paint.Style.FILL
        paint.color = 0x22000000
        canvas.drawRect(0f, 0f, w, 6f, paint)
        canvas.drawRect(0f, 0f, w, 13f, paint)
        canvas.drawRect(0f, 0f, w, 22f, paint)

        // Suelo
        paint.color = tint(seg.floorColor)
        canvas.drawRect(0f, fy, w, h, paint)
        drawStrokes(floor, seg.floorStrokeColor, 1.5f)

        // Rodapié y línea de suelo
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.SKIRTING)
        canvas.drawRect(0f, fy - 4f, w, fy, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.2f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawLine(0f, fy - 4f, w, fy - 4f, paint)
        canvas.drawLine(0f, fy, w, fy, paint)

        // Motas de papel
        if (speckles.isNotEmpty()) {
            paint.strokeWidth = 1f
            paint.color = tint(Palette.SPECKLE)
            canvas.drawPoints(speckles, paint)
        }

        // Muros laterales (límites del segmento)
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.EDGE_WALL)
        if (seg.leftBoundary > 0f) canvas.drawRect(0f, 0f, seg.leftBoundary, h, paint)
        if (seg.rightBoundary < w) canvas.drawRect(seg.rightBoundary, 0f, w, h, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint(Palette.WALL_LINE)
        if (seg.leftBoundary > 0f) canvas.drawLine(seg.leftBoundary, 0f, seg.leftBoundary, h, paint)
        if (seg.rightBoundary < w) canvas.drawLine(seg.rightBoundary, 0f, seg.rightBoundary, h, paint)
    }

    /** Capa de iluminación del segmento (coordenadas del mundo), tras dibujar los objetos. */
    open fun drawLighting(seg: RoomSegment) {
        lighting.drawWorldLighting(canvas, seg.width, seg.height, seg.ambientDark, seg.darkZones, seg.lights)
    }

    /** Viñeta de pantalla (coordenadas lógicas). */
    open fun drawVignette() {
        lighting.drawVignette(canvas)
    }

    /** Puerta de perfil frontal: marco, hueco oscuro y hoja que se abre con [Door.openProgress]. */
    open fun drawDoor(d: Door) {
        val x = d.x
        val y = d.y
        val w = d.width

        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.DOOR_FRAME)
        canvas.drawRect(x - 2f, y - 2f, d.right + 2f, d.bottom, paint)
        paint.color = tint(Palette.DOOR_INSIDE)
        canvas.drawRect(x, y, d.right, d.bottom, paint)

        val pw = w * (1f - 0.8f * d.openProgress)
        if (pw > 0.5f) {
            paint.color = tint(Palette.DOOR_PANEL)
            canvas.drawRect(x, y, x + pw, d.bottom, paint)
            canvas.save()
            canvas.clipRect(x, y, x + pw, d.bottom)
            drawStrokes(d.hatch, Palette.DOOR_HATCH, 1.3f)
            canvas.restore()
            paint.style = Paint.Style.FILL
            paint.color = tint(Palette.DOOR_KNOB)
            canvas.drawCircle(x + pw - 3f, y + d.height * 0.55f, 1.6f, paint)
        }
        drawStrokes(d.outline, Palette.OUTLINE, 1f)
    }

    /** Líneas sueltas (pares x1,y1,x2,y2). */
    open fun drawStrokes(lines: FloatArray, color: Int, strokeWidth: Float) {
        if (lines.isEmpty()) return
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = strokeWidth
        paint.color = tint(color)
        canvas.drawLines(lines, paint)
    }

    /** Caja con relleno de crayón, trazos de sombreado y contorno doble imperfecto. */
    open fun drawSketchBox(o: WorldObject) {
        paint.style = Paint.Style.FILL
        paint.color = tint(o.fillColor)
        canvas.drawRect(o.x, o.y, o.right, o.bottom, paint)
        drawStrokes(o.hatch, o.hatchColor, 1.4f)
        drawStrokes(o.outline, o.lineColor, 1f)
    }

    /**
     * Personaje placeholder de PERFIL con aire de dibujo infantil.
     * Fotogramas: idle (0), walk_1 (1), walk_2 (2) según [Player.walkFrame].
     */
    open fun drawPlayer(p: Player) {
        val f = if (p.facing < 0f) -1f else 1f
        val bx = round(p.x + p.width * 0.5f)
        val by = round(p.bottom)
        val frame = p.walkFrame
        val bob = if (frame == 1) -1f else 0f
        val stride = when (frame) {
            1 -> 2.5f
            2 -> -2.5f
            else -> 0f
        }

        // Sombra en el suelo
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.SHADOW)
        oval.set(bx - 6f, by - 1.5f, bx + 6f, by + 1.5f)
        canvas.drawOval(oval, paint)

        // Piernas (perfil: una adelante y otra atrás)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.6f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawLine(bx - 0.5f, by - 8f, bx - 0.5f + f * stride, by, paint)
        canvas.drawLine(bx + 0.5f, by - 8f, bx + 0.5f - f * stride, by, paint)

        // Vestido
        path.reset()
        path.moveTo(bx - 3.5f, by - 17f + bob)
        path.lineTo(bx + 3.5f, by - 17f + bob)
        path.lineTo(bx + 5.5f, by - 8f)
        path.lineTo(bx - 5.5f, by - 8f)
        path.close()
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.PLAYER_DRESS)
        canvas.drawPath(path, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawPath(path, paint)

        // Brazo (se balancea al caminar)
        canvas.drawLine(bx, by - 15f + bob, bx - f * stride * 0.7f + f * 0.5f, by - 9f + bob, paint)

        // Cabeza
        val hy = by - 21.5f + bob
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.PLAYER_SKIN)
        canvas.drawCircle(bx, hy, 4.5f, paint)

        // Pelo: casquete superior y un moño en la parte de atrás
        paint.color = tint(Palette.PLAYER_HAIR)
        oval.set(bx - 4.5f, hy - 4.5f, bx + 4.5f, hy + 4.5f)
        canvas.drawArc(oval, 180f, 180f, true, paint)
        canvas.drawCircle(bx - f * 4f, hy - 1.5f, 2.4f, paint)

        // Contorno doble (trazo duplicado sutil)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawCircle(bx, hy, 4.5f, paint)
        canvas.drawCircle(bx + 0.5f, hy + 0.4f, 4.3f, paint)

        // Ojo (mira hacia donde camina)
        paint.style = Paint.Style.FILL
        canvas.drawRect(bx + f * 2f - 0.5f, hy, bx + f * 2f + 0.5f, hy + 1.6f, paint)
    }

    /** HUD discreto (coordenadas lógicas): ← → abajo a la izquierda y acción abajo a la derecha. */
    open fun drawHud(input: InputController) {
        drawArrowButton(InputController.LEFT_X, -1f, input.leftHeld)
        drawArrowButton(InputController.RIGHT_X, 1f, input.rightHeld)
        if (input.actionEnabled) drawActionButton(input.isDown(InputAction.INTERACT))
    }

    private fun drawArrowButton(cx: Float, dir: Float, pressed: Boolean) {
        val cy = InputController.BTN_Y
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f
        paint.color = if (pressed) 0xAA402A1E.toInt() else 0x55402A1E
        canvas.drawCircle(cx, cy, InputController.BTN_RADIUS, paint)
        path.reset()
        path.moveTo(cx + dir * 4f, cy)
        path.lineTo(cx - dir * 3f, cy - 5f)
        path.lineTo(cx - dir * 3f, cy + 5f)
        path.close()
        paint.style = Paint.Style.FILL
        canvas.drawPath(path, paint)
    }

    private fun drawActionButton(pressed: Boolean) {
        val cx = InputController.ACTION_X
        val cy = InputController.BTN_Y
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f
        paint.color = if (pressed) 0xCC402A1E.toInt() else 0x88402A1E.toInt()
        canvas.drawCircle(cx, cy, InputController.BTN_RADIUS + 2f, paint)
        // Icono de puerta
        canvas.drawRect(cx - 4f, cy - 7f, cx + 4f, cy + 7f, paint)
        paint.style = Paint.Style.FILL
        canvas.drawCircle(cx + 2f, cy + 1f, 1f, paint)
    }

    open fun drawDebug(text: CharSequence) {
        canvas.drawText(text, 0, text.length, 3f, 9f, textPaint)
    }
}
