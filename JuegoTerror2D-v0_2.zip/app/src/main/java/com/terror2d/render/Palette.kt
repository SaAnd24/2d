package com.terror2d.render

/** Paleta inicial (etapa crayón). Valores ARGB. Futuras etapas aportarán paletas de grafito. */
object Palette {
    const val PAPER = 0xFFF4ECD8.toInt()
    const val FLOOR = 0xFFF3E0A8.toInt()
    const val FLOOR_STROKE = 0x66E0A84A.toInt()
    const val SPECKLE = 0x44806040.toInt()
    const val OUTLINE = 0xFF3A2A20.toInt()

    const val WALL_FILL = 0xB07B5FC7.toInt()
    const val WALL_HATCH = 0xCC5B3FA8.toInt()
    const val WALL_LINE = 0xFF2B2140.toInt()

    const val CRATE_FILL = 0xB0E8944A.toInt()
    const val CRATE_HATCH = 0xCCC46A1F.toInt()

    const val BLUE_FILL = 0xB05AA6E8.toInt()
    const val BLUE_HATCH = 0xCC2F7BC4.toInt()

    const val GREEN_FILL = 0xB07CC96B.toInt()
    const val GREEN_HATCH = 0xCC4F9A3E.toInt()

    const val RUG_FILL = 0x80E8604C.toInt()
    const val RUG_HATCH = 0xAAC93B2E.toInt()

    const val PLAYER_DRESS = 0xFFE8604C.toInt()
    const val PLAYER_SKIN = 0xFFFFD9B3.toInt()
    const val PLAYER_HAIR = 0xFF6B4226.toInt()
    const val SHADOW = 0x33000000

    // --- v0.2: escenarios laterales (coloridos, con un punto inquietante) ---
    const val WALL_A = 0xFFA9D2BC.toInt()          // menta apagado
    const val WALL_A_STROKE = 0x669BBFA6.toInt()
    const val WALL_B = 0xFFD6A9C9.toInt()          // rosa polvoriento
    const val WALL_B_STROKE = 0x66B27FA3.toInt()
    const val FLOOR_WOOD = 0xFFD8B278.toInt()
    const val FLOOR_WOOD_STROKE = 0x66A8722C.toInt()
    const val SKIRTING = 0xFF7A5238.toInt()
    const val EDGE_WALL = 0xFF3A2C52.toInt()

    const val DOOR_FRAME = 0xFF5A3A2A.toInt()
    const val DOOR_PANEL = 0xFFC9782E.toInt()
    const val DOOR_HATCH = 0xCC8F4A18.toInt()
    const val DOOR_INSIDE = 0xFF1E1230.toInt()
    const val DOOR_KNOB = 0xFFF3D26B.toInt()

    const val PICTURE_FRAME_FILL = 0xB07A4B2B.toInt()
    const val PICTURE_FRAME_HATCH = 0xCC4F2F18.toInt()
    const val PICTURE_INNER_FILL = 0xB0F5E6A8.toInt()
    const val PICTURE_INNER_HATCH = 0xCCE0B84A.toInt()

    const val LAMP_SHADE_FILL = 0xB0F5C85A.toInt()
    const val LAMP_SHADE_HATCH = 0xCCD99A2B.toInt()
    const val LAMP_CORD = 0xFF3A2A20.toInt()

    // Iluminación (la capa de luz usa estos colores sin pasar por tint)
    const val DARK_ZONE = 0x1B0F2E
    const val LIGHT_WARM = 0xFFD27A
    const val LIGHT_COLD = 0x9FD0FF
    const val VIGNETTE_EDGE = 0x5A120A22

}
