package com.terror2d.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import com.terror2d.core.GameConfig
import com.terror2d.world.DarkZone
import com.terror2d.world.Light

/**
 * Capa de iluminación sencilla (v0.2): oscuridad ambiental, zonas oscuras con borde suave
 * y luces localizadas con degradado cálido/frío. Es el punto de integración del futuro
 * sistema de terror (v0.10): lámparas que parpadean, linternas, sombras proyectadas...
 *
 * Orden de dibujo: escena -> objetos -> ESTA capa -> viñeta -> HUD.
 * Los shaders se crean una sola vez (perezosamente) y se reutilizan; sin allocations por frame.
 */
class LightingRenderer {

    private val paint = Paint().apply {
        isAntiAlias = true
        style = Paint.Style.FILL
    }

    private var vignette: RadialGradient? = null

    /** En coordenadas del MUNDO (la transformación de cámara ya está aplicada). */
    fun drawWorldLighting(
        canvas: Canvas,
        width: Float,
        height: Float,
        ambientDark: Float,
        zones: List<DarkZone>,
        lights: List<Light>
    ) {
        paint.shader = null
        if (ambientDark > 0.001f) {
            paint.color = argb(ambientDark * 255f, Palette.DARK_ZONE)
            canvas.drawRect(0f, 0f, width, height, paint)
        }
        for (i in 0 until zones.size) drawDarkZone(canvas, zones[i])
        for (i in 0 until lights.size) drawLight(canvas, lights[i])
    }

    /** Zona oscura con borde "de crayón": tres capas apiladas, cada una más pequeña. */
    private fun drawDarkZone(canvas: Canvas, z: DarkZone) {
        val a = z.strength.coerceIn(0f, 1f) * 255f
        var inset = 0f
        for (layer in 0 until 3) {
            val w = z.width - inset * 2f
            val h = z.height - inset * 2f
            if (w <= 0f || h <= 0f) break
            paint.color = argb(a * 0.34f, Palette.DARK_ZONE)
            canvas.drawRect(z.x + inset, z.y + inset, z.x + z.width - inset, z.y + z.height - inset, paint)
            inset += 6f
        }
    }

    private fun drawLight(canvas: Canvas, l: Light) {
        var g = l.renderCache as RadialGradient?
        if (g == null) {
            val rgb = l.color and 0x00FFFFFF
            val centerAlpha = (l.intensity.coerceIn(0f, 1f) * 112f).toInt()
            g = RadialGradient(0f, 0f, l.radius, (centerAlpha shl 24) or rgb, rgb, Shader.TileMode.CLAMP)
            l.renderCache = g
        }
        paint.shader = g
        canvas.save()
        canvas.translate(l.x, l.y)
        canvas.drawCircle(0f, 0f, l.radius, paint)
        canvas.restore()
        paint.shader = null
    }

    /** Viñeta de pantalla (coordenadas lógicas): bordes algo más oscuros, centro intacto. */
    fun drawVignette(canvas: Canvas) {
        var g = vignette
        if (g == null) {
            val cx = GameConfig.LOGICAL_WIDTH / 2f
            val cy = GameConfig.LOGICAL_HEIGHT / 2f
            val edge = Palette.VIGNETTE_EDGE
            g = RadialGradient(
                cx, cy, 190f,
                intArrayOf(edge and 0x00FFFFFF, edge and 0x00FFFFFF, edge),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            vignette = g
        }
        paint.shader = g
        canvas.drawRect(0f, 0f, GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat(), paint)
        paint.shader = null
    }

    private fun argb(alpha: Float, rgb: Int): Int =
        (alpha.toInt().coerceIn(0, 255) shl 24) or (rgb and 0x00FFFFFF)
}
