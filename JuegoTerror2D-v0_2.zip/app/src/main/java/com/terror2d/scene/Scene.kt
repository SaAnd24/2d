package com.terror2d.scene

import com.terror2d.core.Camera
import com.terror2d.core.GameConfig
import com.terror2d.core.GameState
import com.terror2d.input.InputAction
import com.terror2d.input.InputController
import com.terror2d.render.BaseRenderer
import com.terror2d.util.SeededRandom
import com.terror2d.world.Door
import com.terror2d.world.Layer
import com.terror2d.world.Player
import com.terror2d.world.SketchBuilder
import com.terror2d.world.WorldObject

/**
 * Escena base (vista LATERAL): contiene el segmento activo, jugador, cámara y colisiones.
 * Una escena (p. ej. la casa) se compone de varios [RoomSegment] conectados por puertas;
 * solo uno está cargado a la vez. Las escenas concretas heredan de aquí.
 */
abstract class Scene(val definition: SceneDefinition) {

    val id: String get() = definition.id

    lateinit var currentSegment: RoomSegment
        private set
    val width: Float get() = currentSegment.width
    val height: Float get() = currentSegment.height

    val camera = Camera(GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat())
    lateinit var player: Player
        private set

    private val objects = ArrayList<WorldObject>()
    private val solids = ArrayList<WorldObject>()
    private val backObjects = ArrayList<WorldObject>()   // FLOOR / DECOR (detrás de todo)
    private val midObjects = ArrayList<WorldObject>()    // OBJECT (muebles, puertas)
    private val frontObjects = ArrayList<WorldObject>()  // FOREGROUND (delante del jugador)

    private var wallStrokes: FloatArray = WorldObject.EMPTY
    private var floorStrokes: FloatArray = WorldObject.EMPTY
    private var speckles: FloatArray = WorldObject.EMPTY

    /** Puerta ya abierta cuyo destino se cargará al terminar su animación. */
    private var pendingDoor: Door? = null

    fun load(state: GameState) {
        loadSegment(definition.startSegmentId, definition.startSpawnId, state)
    }

    /**
     * Carga un segmento y coloca al jugador en el spawn indicado. Es la transición mínima de v0.2
     * (corte directo). Futuro: fundidos y transiciones más completas (v0.3+).
     */
    fun loadSegment(segmentId: String, spawnId: String, state: GameState) {
        val seg = definition.segment(segmentId)
        currentSegment = seg
        pendingDoor = null

        objects.clear()
        solids.clear()
        backObjects.clear()
        midObjects.clear()
        frontObjects.clear()
        // Todas las puertas vuelven a estar cerradas al cambiar de segmento (estado persistente: v0.3+).
        for (si in 0 until definition.segments.size) {
            val ds = definition.segments[si].doors
            for (di in 0 until ds.size) ds[di].reset()
        }
        objects.addAll(seg.objects)
        objects.addAll(seg.doors)

        // Imperfecciones visuales deterministas: dependen de la semilla de la escena, del índice
        // del segmento y del índice del objeto (nunca del orden de ejecución).
        val segIndex = definition.segments.indexOf(seg)
        val segSeed = SeededRandom.derive(definition.seed, SEGMENT_SALT + segIndex)
        for (i in 0 until objects.size) {
            objects[i].prepareVisuals(SeededRandom(SeededRandom.derive(segSeed, i + 1)))
        }
        val bgRng = SeededRandom(SeededRandom.derive(segSeed, BACKDROP_SALT))
        wallStrokes = SketchBuilder.buildVerticalHatch(0f, 0f, seg.width, seg.floorY, 7f, bgRng)
        floorStrokes = SketchBuilder.buildHatch(0f, seg.floorY, seg.width, seg.height - seg.floorY, 5f, bgRng)
        speckles = SketchBuilder.buildSpeckles(seg.width, seg.height, (seg.width * seg.height / 450f).toInt(), bgRng)

        for (i in 0 until objects.size) {
            val o = objects[i]
            if (o.collidable) solids.add(o)
            when {
                o.layer < Layer.OBJECT -> backObjects.add(o)
                o.layer == Layer.OBJECT -> midObjects.add(o)
                else -> frontObjects.add(o)
            }
        }

        val sp = seg.spawn(spawnId)
        player = Player(sp.x - Player.WIDTH / 2f, seg.floorY - Player.HEIGHT)
        player.facing = if (sp.facing < 0) -1f else 1f
        camera.configure(seg.width, seg.height, seg.cameraMode)
        camera.snapTo(player.centerX)

        state.currentSceneId = id
        state.currentSegmentId = seg.id
        state.playerX = player.x
        state.playerY = player.y
        onLoad(state)
    }

    open fun onLoad(state: GameState) {}

    open fun unload(state: GameState) {}

    /** Orden: jugador -> objetos -> puertas/acción -> cámara. */
    open fun update(dt: Float, input: InputController, state: GameState) {
        val seg = currentSegment
        val waiting = pendingDoor
        val dir = if (waiting != null) 0f else input.moveX
        player.update(dt, dir, solids, seg.floorY, seg.leftBoundary, seg.rightBoundary)
        for (i in 0 until objects.size) objects[i].update(dt)

        // ¿Hay una puerta al alcance? El botón de acción solo existe en ese caso.
        var near: Door? = null
        if (waiting == null) {
            for (i in 0 until seg.doors.size) {
                val d = seg.doors[i]
                if (d.isPlayerNear(player)) {
                    near = d
                    break
                }
            }
        }
        input.actionEnabled = near != null && !near.isOpen

        if (near != null && input.wasPressed(InputAction.INTERACT) && near.activate()) {
            if (near.target != null) pendingDoor = near
        }

        // La puerta termina de abrirse -> se carga el segmento destino y el jugador aparece en su spawn.
        val pd = pendingDoor
        if (pd != null && pd.openProgress >= 1f) {
            val t = pd.target
            if (t != null) {
                input.actionEnabled = false
                loadSegment(t.segmentId, t.spawnId, state)
                return
            }
            pendingDoor = null
        }

        camera.follow(player.centerX, dt)
        state.playerX = player.x
        state.playerY = player.y
    }

    /**
     * Dibuja en coordenadas del mundo (la transformación de cámara ya está aplicada).
     * Capas: fondo -> decoración -> objetos -> jugador -> primer plano -> iluminación.
     */
    open fun render(r: BaseRenderer) {
        val seg = currentSegment
        r.drawBackdrop(seg, wallStrokes, floorStrokes, speckles)

        for (i in 0 until backObjects.size) {
            val o = backObjects[i]
            if (o.visible && camera.isVisible(o)) o.render(r)
        }
        for (i in 0 until midObjects.size) {
            val o = midObjects[i]
            if (o.visible && camera.isVisible(o)) o.render(r)
        }
        player.render(r)
        for (i in 0 until frontObjects.size) {
            val o = frontObjects[i]
            if (o.visible && camera.isVisible(o)) o.render(r)
        }

        r.drawLighting(seg)
    }

    /** Huella de todo el aspecto generado del segmento cargado: misma semilla => mismo valor (tests). */
    fun visualFingerprint(): Long {
        var h = 1125899906842597L
        h = WorldObject.hashFloats(h, wallStrokes)
        h = WorldObject.hashFloats(h, floorStrokes)
        h = WorldObject.hashFloats(h, speckles)
        for (i in 0 until objects.size) h = objects[i].visualHash(h)
        return h
    }

    companion object {
        private const val SEGMENT_SALT = 0x5E60
        private const val BACKDROP_SALT = 0x7F10
    }
}
