package com.terror2d.scene

import com.terror2d.core.CameraMode
import com.terror2d.render.Palette
import com.terror2d.world.Block
import com.terror2d.world.Chair
import com.terror2d.world.DarkZone
import com.terror2d.world.Doodle
import com.terror2d.world.Door
import com.terror2d.world.DoorTarget
import com.terror2d.world.Lamp
import com.terror2d.world.Light
import com.terror2d.world.PictureFrame
import com.terror2d.world.WorldObject

/**
 * Prueba técnica de v0.2: dos segmentos laterales conectados por puertas.
 *
 *  Segmento A (480 px, scroll horizontal)  --puerta-->  Segmento B (320 px, composición fija)
 *
 * Todas las posiciones son literales: ninguna usa aleatoriedad (la semilla solo afecta al trazo).
 */
object TestRoomDefinition {
    const val ID = "test_room"
    const val SEGMENT_A = "segment_a"
    const val SEGMENT_B = "segment_b"
    const val DOOR_A_TO_B = "door_a_to_b"
    const val DOOR_B_TO_A = "door_b_to_a"
    const val DEFAULT_SEED = 20260101L

    const val FLOOR_Y = 140f
    const val WIDTH_A = 480f
    const val WIDTH_B = 320f
    private const val WALL = 12f // grosor de los muros laterales

    /** Crea objetos NUEVOS en cada llamada (cada carga de escena parte limpia). */
    fun create(seed: Long = DEFAULT_SEED): SceneDefinition =
        SceneDefinition(
            id = ID,
            seed = seed,
            segments = listOf(segmentA(), segmentB()),
            startSegmentId = SEGMENT_A,
            startSpawnId = "start"
        )

    private fun segmentA(): RoomSegment {
        val objects = ArrayList<WorldObject>()
        objects.add(Doodle(40f, 40f, 34f))                       // dibujo infantil en la pared
        val lamp = Lamp(250f, 30f)
        objects.add(lamp)
        objects.add(Block(60f, FLOOR_Y - 18f, 24f, 18f, Palette.CRATE_FILL, Palette.CRATE_HATCH)) // caja de juguetes (sólida)
        objects.add(Chair(180f, FLOOR_Y))

        val door = Door(DOOR_A_TO_B, 424f, FLOOR_Y, target = DoorTarget(SEGMENT_B, "from_a"))

        return RoomSegment(
            id = SEGMENT_A,
            width = WIDTH_A,
            floorY = FLOOR_Y,
            leftBoundary = WALL,
            rightBoundary = WIDTH_A - WALL,
            cameraMode = CameraMode.SIDE_SCROLLING,
            objects = objects,
            doors = listOf(door),
            spawnPoints = mapOf(
                "start" to SpawnPoint(150f, 1),
                "from_b" to SpawnPoint(398f, -1)
            ),
            lights = listOf(
                lamp.light,
                Light(436f, 62f, 52f, Palette.LIGHT_COLD or 0xFF000000.toInt(), 0.5f) // luz fría junto a la puerta
            ),
            darkZones = listOf(DarkZone(WALL, 0f, 96f, FLOOR_Y, 0.55f)),
            ambientDark = 0.08f,
            wallColor = Palette.WALL_A,
            wallStrokeColor = Palette.WALL_A_STROKE
        )
    }

    private fun segmentB(): RoomSegment {
        val objects = ArrayList<WorldObject>()
        objects.add(PictureFrame(110f, 36f, 30f, 24f))
        // Torre de cubos de juguete (sólida)
        objects.add(Block(236f, FLOOR_Y - 16f, 16f, 16f, Palette.BLUE_FILL, Palette.BLUE_HATCH))
        objects.add(Block(252f, FLOOR_Y - 16f, 16f, 16f, Palette.GREEN_FILL, Palette.GREEN_HATCH))
        objects.add(Block(244f, FLOOR_Y - 32f, 16f, 16f, Palette.CRATE_FILL, Palette.CRATE_HATCH))

        val door = Door(DOOR_B_TO_A, 16f, FLOOR_Y, target = DoorTarget(SEGMENT_A, "from_b"))

        return RoomSegment(
            id = SEGMENT_B,
            width = WIDTH_B,
            floorY = FLOOR_Y,
            leftBoundary = WALL,
            rightBoundary = WIDTH_B - WALL,
            cameraMode = CameraMode.FIXED,
            objects = objects,
            doors = listOf(door),
            spawnPoints = mapOf("from_a" to SpawnPoint(64f, 1)),
            lights = listOf(Light(125f, 48f, 62f, Palette.LIGHT_WARM or 0xFF000000.toInt(), 0.5f)),
            darkZones = listOf(DarkZone(200f, 0f, 108f, FLOOR_Y, 0.7f)),
            ambientDark = 0.18f,
            wallColor = Palette.WALL_B,
            wallStrokeColor = Palette.WALL_B_STROKE
        )
    }
}
