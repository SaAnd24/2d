package com.terror2d.scene

import com.terror2d.core.CameraMode
import com.terror2d.core.GameConfig
import com.terror2d.render.Palette
import com.terror2d.world.DarkZone
import com.terror2d.world.Door
import com.terror2d.world.Light
import com.terror2d.world.WorldObject

/**
 * Un tramo lateral independiente (dormitorio, pasillo, cocina...). Una [SceneDefinition]
 * agrupa varios, conectados por [Door]s. Es solo DATOS: la lógica vive en [Scene].
 *
 * Sistema de coordenadas: X crece a la derecha, Y hacia abajo. El suelo está en [floorY]:
 * los pies del jugador y la base de los objetos se apoyan en esa línea.
 */
class RoomSegment(
    val id: String,
    val width: Float,
    val floorY: Float,
    val height: Float = GameConfig.LOGICAL_HEIGHT.toFloat(),
    /** Límites horizontales del cuerpo del jugador. */
    val leftBoundary: Float = 0f,
    val rightBoundary: Float = width,
    val cameraMode: CameraMode = CameraMode.SIDE_SCROLLING,
    val objects: List<WorldObject> = emptyList(),
    val doors: List<Door> = emptyList(),
    val spawnPoints: Map<String, SpawnPoint>,
    // Iluminación (solo datos; el dibujo lo hace la capa de iluminación)
    val lights: List<Light> = emptyList(),
    val darkZones: List<DarkZone> = emptyList(),
    val ambientDark: Float = 0f,
    // Aspecto
    val wallColor: Int = Palette.WALL_A,
    val wallStrokeColor: Int = Palette.WALL_A_STROKE,
    val floorColor: Int = Palette.FLOOR_WOOD,
    val floorStrokeColor: Int = Palette.FLOOR_WOOD_STROKE
) {
    fun spawn(spawnId: String): SpawnPoint =
        spawnPoints[spawnId] ?: throw IllegalArgumentException("Spawn no definido en $id: $spawnId")
}
