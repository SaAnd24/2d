package com.terror2d.scene

/** Punto de aparición: X del CENTRO de los pies y hacia dónde mira. La Y la da el suelo del segmento. */
class SpawnPoint(val x: Float, val facing: Int = 1)

/**
 * Descripción de una escena (p. ej. una casa): una semilla y una lista de segmentos laterales
 * conectados por puertas. Futuras escenas solo necesitan crear una definición, sin tocar el motor.
 */
class SceneDefinition(
    val id: String,
    val seed: Long,
    val segments: List<RoomSegment>,
    val startSegmentId: String,
    val startSpawnId: String = "start"
) {
    fun segment(id: String): RoomSegment =
        segments.firstOrNull { it.id == id }
            ?: throw IllegalArgumentException("Segmento no definido en $id: $id")
}
