package com.terror2d.core

import android.graphics.Canvas
import com.terror2d.input.InputController
import com.terror2d.render.GameRenderer
import com.terror2d.scene.SceneManager
import com.terror2d.scene.TestRoomDefinition
import com.terror2d.scene.TestScene

/**
 * Controlador principal: coordina estado, escena actual, input, update y render.
 * No contiene lógica de juego; la delega en SceneManager / Scene.
 */
class Game {
    val state = GameState()
    val input = InputController()
    val viewport = Viewport()
    val sceneManager = SceneManager(state)
    private val gameRenderer = GameRenderer(viewport)

    // Debug (sin allocations por frame: StringBuilder reutilizado)
    private val debugText = StringBuilder(96)
    private var fpsFrames = 0
    private var fpsTimer = 0L
    private var fps = 0

    init {
        sceneManager.register(TestRoomDefinition.ID) { TestScene() }
        sceneManager.loadScene(TestRoomDefinition.ID)
    }

    /** Un paso de simulación con deltaTime (segundos). */
    fun update(dt: Float) {
        state.elapsedTime += dt
        sceneManager.update(dt, input)
        input.endFrame()
    }

    fun render(canvas: Canvas) {
        if (GameConfig.DEBUG_OVERLAY) updateDebug()
        gameRenderer.render(canvas, sceneManager, state, input, if (GameConfig.DEBUG_OVERLAY) debugText else null)
    }

    private fun updateDebug() {
        val now = System.nanoTime()
        fpsFrames++
        if (fpsTimer == 0L) fpsTimer = now
        if (now - fpsTimer >= 500_000_000L) {
            fps = (fpsFrames * 1_000_000_000L / (now - fpsTimer)).toInt()
            fpsFrames = 0
            fpsTimer = now
            debugText.setLength(0)
            debugText.append("FPS ").append(fps)
                .append("  ").append(state.currentSegmentId)
                .append("  X ").append(state.playerX.toInt())
                .append("  C ").append(state.visualCorruption)
        }
    }
}
