package com.terror2d.world

import com.terror2d.render.BaseRenderer
import kotlin.math.min

/** Destino de una puerta: segmento y punto de aparición dentro de él. */
class DoorTarget(val segmentId: String, val spawnId: String)

/**
 * Puerta de un segmento lateral. Representa posición, estado abierto/cerrado, destino y
 * la animación de apertura. No tiene colisión: es una zona con la que el jugador interactúa.
 *
 * v0.2: abrir = activar la transición. v0.3 podrá añadir llaves, puertas cerradas, eventos...
 */
class Door(
    val id: String,
    x: Float,
    floorY: Float,
    width: Float = DEFAULT_WIDTH,
    height: Float = DEFAULT_HEIGHT,
    val target: DoorTarget? = null
) : WorldObject(x, floorY - height, width, height) {

    var isOpen: Boolean = false
        private set

    /** 0 = cerrada, 1 = completamente abierta. */
    var openProgress: Float = 0f
        private set

    init {
        collidable = false
        layer = Layer.OBJECT
    }

    /** ¿Está el jugador lo bastante cerca como para usarla? */
    fun isPlayerNear(p: Player): Boolean =
        p.right > x - NEAR_MARGIN && p.x < right + NEAR_MARGIN

    /** Abre la puerta. Devuelve true si cambió de estado. */
    fun activate(): Boolean {
        if (isOpen) return false
        isOpen = true
        return true
    }

    /** Vuelve a cerrarla (se llama al cargar el segmento). */
    fun reset() {
        isOpen = false
        openProgress = 0f
    }

    override fun update(dt: Float) {
        if (isOpen && openProgress < 1f) openProgress = min(1f, openProgress + dt / OPEN_TIME)
    }

    override fun render(r: BaseRenderer) {
        r.drawDoor(this)
    }

    companion object {
        const val DEFAULT_WIDTH = 24f
        const val DEFAULT_HEIGHT = 46f
        const val NEAR_MARGIN = 6f

        /** Segundos que tarda la animación de apertura antes de cargar el destino. */
        const val OPEN_TIME = 0.3f
    }
}
