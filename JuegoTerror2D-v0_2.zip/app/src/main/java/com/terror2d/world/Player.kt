package com.terror2d.world

import com.terror2d.render.BaseRenderer
import kotlin.math.abs

/**
 * Jugador placeholder en vista LATERAL. La caja de colisión es el cuerpo completo
 * (WIDTH x HEIGHT) y siempre está apoyada en el suelo del segmento: la Y no la controla
 * ningún input, la fija el suelo.
 *
 * Solo hay velocidad horizontal ([velocityX]). Sin salto ni plataformas en v0.2.
 */
class Player(x: Float, y: Float) : WorldObject(x, y, WIDTH, HEIGHT) {

    var velocityX: Float = 0f

    /** +1 mira a la derecha, -1 a la izquierda. */
    var facing: Float = 1f
    var moving: Boolean = false
    var animTime: Float = 0f

    /** 0 = idle, 1 = walk_1, 2 = walk_2. */
    var walkFrame: Int = 0
        private set

    /** Futuro: correr, ralentizar, etc. */
    var speedMultiplier: Float = 1f

    init {
        collidable = false // el jugador no está en la lista de sólidos
    }

    /**
     * Un paso de simulación. [dirX] en [-1, 1]. Movimiento deliberado y suave:
     * aceleración corta, sin deslizamiento largo.
     */
    fun update(
        dt: Float,
        dirX: Float,
        solids: List<WorldObject>,
        floorY: Float,
        leftBoundary: Float,
        rightBoundary: Float
    ) {
        val dir = dirX.coerceIn(-1f, 1f)
        val target = dir * SPEED * speedMultiplier
        val rate = (if (dir == 0f) DECEL else ACCEL) * dt
        velocityX = when {
            velocityX < target - rate -> velocityX + rate
            velocityX > target + rate -> velocityX - rate
            else -> target
        }

        CollisionSystem.snapToFloor(this, floorY)
        val blocked = CollisionSystem.moveHorizontal(this, velocityX * dt, solids, leftBoundary, rightBoundary)
        if (blocked) velocityX = 0f
        CollisionSystem.snapToFloor(this, floorY)

        if (dir != 0f) facing = if (dir < 0f) -1f else 1f
        moving = abs(velocityX) > MOVING_EPS
        if (moving) {
            animTime += dt
            walkFrame = 1 + ((animTime / STEP_TIME).toInt() and 1)
        } else {
            animTime = 0f
            walkFrame = 0
        }
    }

    override fun prepareVisuals(rng: com.terror2d.util.SeededRandom) {
        // El personaje se dibuja proceduralmente; no necesita trazos precalculados.
    }

    override fun render(r: BaseRenderer) {
        r.drawPlayer(this)
    }

    companion object {
        const val WIDTH = 10f
        const val HEIGHT = 26f

        /** Velocidad máxima en píxeles lógicos por segundo (paseo tranquilo). */
        const val SPEED = 50f
        const val ACCEL = 420f
        const val DECEL = 520f
        const val MOVING_EPS = 2f

        /** Segundos por fotograma de la animación de caminar. */
        const val STEP_TIME = 0.16f
    }
}
