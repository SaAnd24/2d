package com.terror2d.world

import com.terror2d.render.BaseRenderer
import com.terror2d.render.Palette
import com.terror2d.util.SeededRandom
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Pared sólida. */
class Wall(x: Float, y: Float, w: Float, h: Float) : WorldObject(x, y, w, h) {
    init {
        collidable = true
        fillColor = Palette.WALL_FILL
        hatchColor = Palette.WALL_HATCH
        lineColor = Palette.WALL_LINE
    }
}

/** Objeto sólido genérico (caja, cubo de juguete, pilar...). */
class Block(
    x: Float, y: Float, w: Float, h: Float,
    fill: Int, hatchTone: Int
) : WorldObject(x, y, w, h) {
    init {
        collidable = true
        fillColor = fill
        hatchColor = hatchTone
    }
}

/** Alfombra: decoración sin colisión, siempre bajo el jugador. */
class Rug(x: Float, y: Float, w: Float, h: Float) : WorldObject(x, y, w, h) {
    init {
        collidable = false
        layer = Layer.DECOR
        fillColor = Palette.RUG_FILL
        hatchColor = Palette.RUG_HATCH
        hatchSpacing = 2.5f
    }
}

/** Garabato en espiral: decoración infantil determinista (sin colisión). */
class Doodle(x: Float, y: Float, size: Float) : WorldObject(x, y, size, size) {
    init {
        collidable = false
        layer = Layer.DECOR
        lineColor = Palette.BLUE_HATCH
    }

    override fun prepareVisuals(rng: SeededRandom) {
        val segs = 36
        val arr = FloatArray(segs * 4)
        val cx = centerX
        val cy = centerY
        val maxR = min(width, height) / 2f
        var px = cx
        var py = cy
        for (i in 0 until segs) {
            val t = (i + 1) / segs.toFloat()
            val ang = t * 3.5f * 2f * PI.toFloat()
            val r = maxR * t + rng.nextSigned() * 0.6f
            val nx = cx + cos(ang) * r
            val ny = cy + sin(ang) * r
            arr[i * 4] = px
            arr[i * 4 + 1] = py
            arr[i * 4 + 2] = nx
            arr[i * 4 + 3] = ny
            px = nx
            py = ny
        }
        hatch = arr
        outline = EMPTY
    }

    override fun render(r: BaseRenderer) {
        r.drawStrokes(hatch, lineColor, 1.3f)
    }
}

/**
 * Objeto formado por varias piezas dibujadas (silla, cuadro, lámpara...). Cada pieza deriva su
 * semilla del generador del objeto, así que el resultado es determinista. Sin colisión propia:
 * la colisión, si existe, la define el objeto compuesto.
 */
open class CompositeObject(x: Float, y: Float, w: Float, h: Float) : WorldObject(x, y, w, h) {
    protected val parts = ArrayList<WorldObject>()

    protected fun part(px: Float, py: Float, pw: Float, ph: Float, fill: Int, hatchTone: Int): WorldObject {
        val b = Block(px, py, pw, ph, fill, hatchTone)
        b.collidable = false
        parts.add(b)
        return b
    }

    override fun prepareVisuals(rng: SeededRandom) {
        for (i in 0 until parts.size) parts[i].prepareVisuals(SeededRandom(rng.nextLong()))
        outline = EMPTY
        hatch = EMPTY
    }

    override fun render(r: BaseRenderer) {
        for (i in 0 until parts.size) parts[i].render(r)
    }

    override fun visualHash(seed: Long): Long {
        var h = seed
        for (i in 0 until parts.size) h = parts[i].visualHash(h)
        return h
    }
}

/** Silla de perfil apoyada en el suelo. Decoración sin colisión (el jugador pasa por delante). */
class Chair(x: Float, floorY: Float) : CompositeObject(x, floorY - HEIGHT, WIDTH, HEIGHT) {
    init {
        collidable = false
        layer = Layer.OBJECT
        part(x, floorY - 24f, 3f, 14f, Palette.CRATE_FILL, Palette.CRATE_HATCH)        // respaldo
        part(x, floorY - 11f, WIDTH, 3f, Palette.CRATE_FILL, Palette.CRATE_HATCH)      // asiento
        part(x + 1f, floorY - 8f, 2f, 8f, Palette.CRATE_FILL, Palette.CRATE_HATCH)     // pata trasera
        part(x + WIDTH - 3f, floorY - 8f, 2f, 8f, Palette.CRATE_FILL, Palette.CRATE_HATCH) // pata delantera
    }

    companion object {
        const val WIDTH = 16f
        const val HEIGHT = 24f
    }
}

/** Cuadro de pared con un garabato dentro. Decoración (detrás del jugador). */
class PictureFrame(x: Float, y: Float, w: Float, h: Float) : CompositeObject(x, y, w, h) {
    init {
        collidable = false
        layer = Layer.DECOR
        part(x, y, w, h, Palette.PICTURE_FRAME_FILL, Palette.PICTURE_FRAME_HATCH)
        part(x + 3f, y + 3f, w - 6f, h - 6f, Palette.PICTURE_INNER_FILL, Palette.PICTURE_INNER_HATCH)
        val d = minOf(w, h) - 10f
        parts.add(Doodle(x + (w - d) / 2f, y + (h - d) / 2f, d))
    }
}

/** Lámpara colgante. Lleva su [light] asociada para que el segmento la registre. */
class Lamp(x: Float, cordLength: Float) : CompositeObject(x - 8f, 0f, 16f, cordLength + 9f) {
    val light = Light(x, cordLength + 12f, 85f, Palette.LIGHT_WARM or 0xFF000000.toInt(), 1f)

    init {
        collidable = false
        layer = Layer.DECOR
        part(x - 0.75f, 0f, 1.5f, cordLength, Palette.LAMP_CORD, Palette.LAMP_CORD)
        part(x - 8f, cordLength, 16f, 9f, Palette.LAMP_SHADE_FILL, Palette.LAMP_SHADE_HATCH)
    }
}
