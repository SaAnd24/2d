package com.terror2d.world

/**
 * Luz localizada (solo datos). El dibujo lo hace la capa de iluminación del renderizador.
 * Futuro: parpadeo, luces que se apagan, linterna.
 */
class Light(
    val x: Float,
    val y: Float,
    val radius: Float,
    val color: Int,
    val intensity: Float = 1f
) {
    /** Caché reservada al renderizador (shader del degradado); la lógica no la toca. */
    @JvmField var renderCache: Any? = null
}

/** Zona oscura rectangular (solo datos). strength: 0 (nada) a 1 (muy oscura). */
class DarkZone(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val strength: Float
)
