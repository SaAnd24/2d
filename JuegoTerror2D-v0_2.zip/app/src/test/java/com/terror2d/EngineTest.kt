package com.terror2d

import com.terror2d.core.CameraMode
import com.terror2d.core.GameConfig
import com.terror2d.core.GameState
import com.terror2d.core.Viewport
import com.terror2d.input.InputAction
import com.terror2d.input.InputController
import com.terror2d.scene.TestRoomDefinition
import com.terror2d.scene.TestScene
import com.terror2d.util.SeededRandom
import com.terror2d.world.Block
import com.terror2d.world.Door
import com.terror2d.world.DoorTarget
import com.terror2d.world.Player
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineTest {

    private val dt = 1f / 60f

    private class World {
        val state = GameState()
        val input = InputController()
        val scene = TestScene().also { it.load(state) }

        fun step(n: Int = 1) {
            repeat(n) {
                scene.update(1f / 60f, input, state)
                input.endFrame()
            }
        }

        fun walk(left: Boolean, right: Boolean, steps: Int) {
            input.setDirection(left, right)
            step(steps)
            input.setDirection(false, false)
        }

        fun pressAction() {
            input.setAction(InputAction.INTERACT, true)
            step(1)
            input.setAction(InputAction.INTERACT, false)
        }
    }

    // ---------- SeededRandom (v0.1, intacto) ----------

    @Test
    fun sameSeedProducesSameSequence() {
        val a = SeededRandom(42L)
        val b = SeededRandom(42L)
        for (i in 0 until 1000) assertEquals(a.nextLong(), b.nextLong())
    }

    @Test
    fun differentSeedsProduceDifferentSequences() {
        assertNotEquals(SeededRandom(1L).nextLong(), SeededRandom(2L).nextLong())
    }

    @Test
    fun floatsStayInRange() {
        val r = SeededRandom(7L)
        for (i in 0 until 1000) {
            val f = r.nextFloat()
            assertTrue(f >= 0f && f < 1f)
        }
    }

    // ---------- Seed visual ----------

    @Test
    fun sameSeedProducesSameVisuals() {
        val a = TestScene(123L).also { it.load(GameState()) }
        val b = TestScene(123L).also { it.load(GameState()) }
        assertEquals(a.visualFingerprint(), b.visualFingerprint())
    }

    @Test
    fun differentSeedProducesDifferentVisuals() {
        val a = TestScene(123L).also { it.load(GameState()) }
        val b = TestScene(124L).also { it.load(GameState()) }
        assertNotEquals(a.visualFingerprint(), b.visualFingerprint())
    }

    @Test
    fun sameSeedSameVisualsAfterTransitionsBackAndForth() {
        val state = GameState()
        val scene = TestScene(55L).also { it.load(state) }
        val before = scene.visualFingerprint()
        scene.loadSegment(TestRoomDefinition.SEGMENT_B, "from_a", state)
        scene.loadSegment(TestRoomDefinition.SEGMENT_A, "start", state)
        assertEquals(before, scene.visualFingerprint())
    }

    // ---------- Movimiento lateral ----------

    @Test
    fun walksRight() {
        val w = World()
        val x0 = w.scene.player.x
        w.walk(left = false, right = true, steps = 30)
        assertTrue("no avanzó a la derecha", w.scene.player.x > x0 + 5f)
        assertEquals(1f, w.scene.player.facing, 0f)
    }

    @Test
    fun walksLeft() {
        val w = World()
        val x0 = w.scene.player.x
        w.walk(left = true, right = false, steps = 30)
        assertTrue("no avanzó a la izquierda", w.scene.player.x < x0 - 5f)
        assertEquals(-1f, w.scene.player.facing, 0f)
    }

    @Test
    fun noFreeVerticalMovement() {
        val w = World()
        val y0 = w.scene.player.y
        w.walk(left = false, right = true, steps = 120)
        w.walk(left = true, right = false, steps = 60)
        assertEquals(y0, w.scene.player.y, 0f)
        assertEquals(y0, w.state.playerY, 0f)
    }

    @Test
    fun movementIsDeterministic() {
        val a = World()
        val b = World()
        a.walk(false, true, 200)
        b.walk(false, true, 200)
        assertEquals(a.scene.player.x, b.scene.player.x, 0f)
    }

    @Test
    fun speedIsGentleAndStopsWhenReleased() {
        val w = World()
        w.walk(false, true, 120)
        assertTrue(w.scene.player.velocityX <= Player.SPEED + 0.001f)
        w.step(30)
        assertEquals(0f, w.scene.player.velocityX, 0.001f)
    }

    // ---------- Suelo ----------

    @Test
    fun playerStaysOnFloor() {
        val w = World()
        val floor = w.scene.currentSegment.floorY
        for (i in 0 until 300) {
            w.input.setDirection(left = i % 120 >= 60, right = i % 120 < 60)
            w.step()
            assertEquals(floor, w.scene.player.bottom, 0.0001f)
        }
    }

    // ---------- Límites horizontales ----------

    @Test
    fun rightBoundaryStopsPlayer() {
        val w = World()
        w.walk(false, true, 1500)
        val seg = w.scene.currentSegment
        assertEquals(seg.rightBoundary - Player.WIDTH, w.scene.player.x, 0.01f)
    }

    @Test
    fun leftBoundaryStopsPlayerInSegmentB() {
        val w = World()
        w.scene.loadSegment(TestRoomDefinition.SEGMENT_B, "from_a", w.state)
        w.walk(true, false, 600)
        assertEquals(w.scene.currentSegment.leftBoundary, w.scene.player.x, 0.01f)
    }

    // ---------- Colisiones ----------

    @Test
    fun solidObjectBlocksPlayerFromTheRight() {
        val w = World()
        val box = w.scene.currentSegment.objects.filterIsInstance<Block>().first()
        w.walk(true, false, 600)
        assertEquals(box.right, w.scene.player.x, 0.01f)
        assertTrue(w.scene.player.x >= box.right - 0.001f)
    }

    @Test
    fun solidObjectBlocksPlayerFromTheLeft() {
        val w = World()
        w.scene.loadSegment(TestRoomDefinition.SEGMENT_B, "from_a", w.state)
        val firstCube = w.scene.currentSegment.objects.filterIsInstance<Block>().minByOrNull { it.x }!!
        w.walk(false, true, 800)
        assertEquals(firstCube.x - Player.WIDTH, w.scene.player.x, 0.01f)
    }

    // ---------- Cámara ----------

    @Test
    fun cameraFollowsHorizontallyAndStaysInBounds() {
        val w = World()
        val cam = w.scene.camera
        val y0 = cam.y
        assertEquals(CameraMode.SIDE_SCROLLING, cam.mode)
        w.walk(false, true, 25)
        assertEquals("la cámara no debe moverse dentro de la zona muerta", 0f, cam.x, 0.001f)
        w.walk(false, true, 400)
        assertTrue("la cámara debe seguir al jugador", cam.x > 20f)
        assertTrue(cam.x <= w.scene.width - cam.viewWidth + 0.001f)
        assertTrue(w.scene.player.centerX >= cam.x && w.scene.player.centerX <= cam.x + cam.viewWidth)
        w.walk(true, false, 200)
        assertTrue(cam.x >= 0f)
        assertEquals("la cámara no debe moverse en vertical", y0, cam.y, 0f)
    }

    @Test
    fun cameraNeverLeavesSegmentOnEitherEnd() {
        val w = World()
        w.walk(false, true, 1500)
        assertEquals(w.scene.width - w.scene.camera.viewWidth, w.scene.camera.x, 0.5f)
        w.walk(true, false, 1500)
        assertEquals(0f, w.scene.camera.x, 0.5f)
    }

    @Test
    fun smallSegmentUsesFixedCamera() {
        val w = World()
        w.scene.loadSegment(TestRoomDefinition.SEGMENT_B, "from_a", w.state)
        val cam = w.scene.camera
        assertEquals(CameraMode.FIXED, cam.mode)
        val x0 = cam.x
        val y0 = cam.y
        w.walk(false, true, 120)
        w.walk(true, false, 120)
        assertEquals(x0, cam.x, 0f)
        assertEquals(y0, cam.y, 0f)
    }

    // ---------- Puertas ----------

    @Test
    fun doorChangesState() {
        val d = Door("d", 10f, 140f, target = DoorTarget("x", "y"))
        assertFalse(d.isOpen)
        assertTrue(d.activate())
        assertTrue(d.isOpen)
        assertFalse("activar una puerta ya abierta no cambia nada", d.activate())
        repeat(30) { d.update(dt) }
        assertEquals(1f, d.openProgress, 0f)
        d.reset()
        assertFalse(d.isOpen)
        assertEquals(0f, d.openProgress, 0f)
    }

    @Test
    fun actionIsOnlyAvailableNearADoor() {
        val w = World()
        w.step()
        assertFalse(w.input.actionEnabled)
        val door = w.scene.currentSegment.doors[0]
        w.scene.player.x = door.x + 2f
        w.step()
        assertTrue(w.input.actionEnabled)
    }

    @Test
    fun actionFarFromDoorDoesNothing() {
        val w = World()
        val door = w.scene.currentSegment.doors[0]
        w.pressAction()
        assertFalse(door.isOpen)
        assertEquals(TestRoomDefinition.SEGMENT_A, w.scene.currentSegment.id)
    }

    @Test
    fun doorTransitionLoadsTargetSegmentAtSpawn() {
        val w = World()
        val doorA = w.scene.currentSegment.doors[0]
        w.scene.player.x = doorA.x + 2f
        w.step()
        w.pressAction()
        assertTrue(doorA.isOpen)
        assertEquals("aún debe estar abriéndose", TestRoomDefinition.SEGMENT_A, w.scene.currentSegment.id)
        w.step(40)
        assertEquals(TestRoomDefinition.SEGMENT_B, w.scene.currentSegment.id)
        assertEquals(TestRoomDefinition.SEGMENT_B, w.state.currentSegmentId)
        assertEquals(64f, w.scene.player.centerX, 0.01f)
        assertEquals(w.scene.currentSegment.floorY, w.scene.player.bottom, 0f)
        assertEquals(1f, w.scene.player.facing, 0f)
    }

    @Test
    fun canGoThereAndBackAndDoorsResetClosed() {
        val w = World()
        val doorA = w.scene.currentSegment.doors[0]
        w.scene.player.x = doorA.x + 2f
        w.step()
        w.pressAction()
        w.step(40)
        assertEquals(TestRoomDefinition.SEGMENT_B, w.scene.currentSegment.id)

        val doorB = w.scene.currentSegment.doors[0]
        w.scene.player.x = doorB.x + 2f
        w.step()
        w.pressAction()
        w.step(40)
        assertEquals(TestRoomDefinition.SEGMENT_A, w.scene.currentSegment.id)
        assertEquals(398f, w.scene.player.centerX, 0.01f)
        assertEquals(-1f, w.scene.player.facing, 0f)
        assertFalse(doorA.isOpen)
        assertFalse(doorB.isOpen)
    }

    @Test
    fun playerCannotMoveWhileDoorOpens() {
        val w = World()
        val doorA = w.scene.currentSegment.doors[0]
        w.scene.player.x = doorA.x + 2f
        w.step()
        w.pressAction()
        val x = w.scene.player.x
        w.walk(true, false, 5)
        assertEquals(x, w.scene.player.x, 0.5f)
    }

    // ---------- Render / configuración ----------

    @Test
    fun logicalResolutionIs320x180() {
        assertEquals(320, GameConfig.LOGICAL_WIDTH)
        assertEquals(180, GameConfig.LOGICAL_HEIGHT)
        val w = World()
        assertEquals(320f, w.scene.camera.viewWidth, 0f)
        assertEquals(180f, w.scene.camera.viewHeight, 0f)
    }

    @Test
    fun viewportScalesWithoutDistortion() {
        val v = Viewport()
        v.update(1920, 1080)
        assertEquals(6f, v.scale, 0.001f)
        assertEquals(0f, v.offsetX, 0.001f)
        assertEquals(0f, v.offsetY, 0.001f)
        v.update(2400, 1080)
        assertEquals(6f, v.scale, 0.001f)
        assertEquals(240f, v.offsetX, 0.001f)
    }

    @Test
    fun visualCorruptionStaysAtZero() {
        val w = World()
        w.walk(false, true, 100)
        assertEquals(0f, w.state.visualCorruption, 0f)
    }
}
