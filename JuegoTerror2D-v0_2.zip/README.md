# Juego de Terror 2D — v0.2 (Movimiento lateral y estructura de habitaciones)

## Proyecto
Juego de terror psicológico 2D para Android, con estética de dibujo infantil sobre papel que irá
degenerándose (crayón → crayón + grafito → grafito, rasguños y papel deteriorado).
100 % nativo (Kotlin + Android Canvas), sin motores externos, sin internet, sin backend.

## Versión actual
**v0.2.0** — El motor deja de ser top-down y pasa a ser una **aventura 2D lateral**. Al abrirla
caminas de perfil por una habitación, con puertas que conectan dos segmentos.

## Cambios en v0.2
Se corrigió el lenguaje espacial del juego:

- **Movimiento top-down → lateral.** El jugador solo se mueve en el eje X. La Y la fija el suelo del
  segmento: no hay movimiento vertical ni diagonal. Atributos: `x, y, width, height, velocityX`.
  Aceleración corta y velocidad tranquila (50 px/s) para un movimiento deliberado.
- **Controles.** Se eliminó el joystick de 360°. Ahora hay `←` `→` discretos abajo a la izquierda y un
  botón de acción abajo a la derecha que **solo aparece cuando hay una puerta al alcance**.
  Las zonas táctiles se extienden a las barras negras; funciona con varios dedos a la vez.
  Teclado (emulador): flechas o A/D; Espacio, Enter o E = acción.
- **Cámara lateral.** Solo sigue en horizontal (zona muerta + suavizado) y respeta los límites del
  segmento. La Y está bloqueada por segmento. Modos: `FIXED` (composición fija) y `SIDE_SCROLLING`.
  Un segmento que cabe en pantalla se muestra centrado y sin scroll.
- **Estructura espacial: `RoomSegment`.** Una `SceneDefinition` ahora agrupa varios segmentos laterales
  (`id, width, floorY, leftBoundary, rightBoundary, cameraMode, objects, doors, spawnPoints, luces...`).
  `Scene` sigue existiendo y carga un segmento a la vez.
- **Suelo y límites.** Cada segmento define su suelo (`floorY`) y límites horizontales; el jugador no
  puede atravesarlos ni quedar flotando.
- **Colisiones.** `CollisionSystem` se conserva; se añadieron `snapToFloor` y `moveHorizontal`
  (límites + objetos sólidos).
- **Puertas.** Nueva clase `Door` (`id, x, y, width, height, isOpen, target`) con animación de apertura.
  El destino es un `DoorTarget(segmentId, spawnId)`.
- **Transición básica.** Segmento A → puerta → Segmento B: el jugador pulsa acción junto a la puerta,
  esta se abre y se carga el segmento destino en su punto de spawn (corte directo, sin cinemática).
- **Escena de prueba.** `TestRoomDefinition` ahora contiene el Segmento A (480 px, con scroll: dibujo en
  la pared, silla, caja de juguetes sólida, lámpara y puerta) y el Segmento B (320 px, composición fija:
  cuadro, torre de cubos sólida y puerta de vuelta).
- **Objetos laterales.** `WorldObject` se conserva. Nuevos: `Chair`, `PictureFrame`, `Lamp`,
  `CompositeObject` (base para muebles de varias piezas). Capas: `DECOR`, `OBJECT`, `FOREGROUND`.
- **Personaje de perfil** con animación mínima: idle, walk_1, walk_2.
- **Dirección artística.** Se mantiene el crayón y la paleta colorida, con un punto inquietante: tonos de
  pared algo enfermizos, sombra en el techo, zonas oscuras, luz localizada cálida/fría y viñeta.
- **Iluminación preparada.** `LightingRenderer` dibuja oscuridad ambiental, zonas oscuras y luces
  (`Light`, `DarkZone`) en una capa propia: escena → objetos → iluminación → viñeta → HUD. Es el punto
  de integración del sistema de terror de v0.10 (parpadeos, linternas, sombras).
- Se conservan `SeededRandom` (solo para trazos/decoración; ninguna posición, puerta ni colisión es
  aleatoria), `visualCorruption = 0.0f`, la resolución 320×180 y GitHub Actions.

## Arquitectura
Paquete `com.terror2d`:

| Pieza | Archivo | Responsabilidad |
|---|---|---|
| Canvas | `core/GameView.kt` | `SurfaceView`; conecta Android (superficie, touch, teclas) con `Game`. |
| Game | `core/Game.kt` | Coordina estado, escena, input, update y render. |
| Game Loop | `core/GameLoop.kt` | Hilo propio, simulación a paso fijo de 60 Hz. |
| GameState | `core/GameState.kt` | Estado global mínimo (+ segmento actual) y `visualCorruption`. |
| Viewport | `core/Viewport.kt` | Resolución lógica **320×180** escalada sin deformar. |
| Camera | `core/Camera.kt` | Cámara lateral (`FIXED` / `SIDE_SCROLLING`), Y bloqueada. |
| InputController | `input/InputController.kt` | `left`, `right`, `action` (táctil y teclado). |
| SceneManager / Scene | `scene/` | Carga de escenas; `Scene` gestiona el segmento activo, puertas y transición. |
| SceneDefinition / RoomSegment | `scene/` | Datos: escena = lista de segmentos laterales. |
| WorldObject, Door, Player | `world/` | Objetos, puertas y jugador (solo X). |
| CollisionSystem | `world/CollisionSystem.kt` | AABB: suelo, límites y sólidos. |
| SeededRandom | `util/SeededRandom.kt` | SplitMix64: misma semilla = mismo resultado. |
| Renderers | `render/` | `BaseRenderer` (crayón), `LightingRenderer` (luces), `GameRenderer` (frame). |

## Tests
`./gradlew testDebugUnitTest` — cubren movimiento (izquierda/derecha, sin Y libre), suelo, límites,
colisiones sólidas, cámara (horizontal, límites, sin vertical, modo fijo), puertas (estado, acción,
transición ida y vuelta), seed determinista, resolución 320×180 y `visualCorruption`.

## Build (GitHub Actions)
El workflow `.github/workflows/build.yml` (sin cambios) se ejecuta en cada push a `main`/`master`, en
pull requests y manualmente. Instala JDK 17 y Gradle 8.7, regenera `gradle-wrapper.jar` si falta,
ejecuta `./gradlew assembleDebug`, publica el APK como artifact **`JuegoTerror2D-debug-apk`** y después
ejecuta los tests unitarios (`testDebugUnitTest`).

Para descargar el APK: pestaña **Actions** → ejecución más reciente → sección **Artifacts**.

## Flujo recomendado
```
Claude → ZIP → Descomprimir → Subir a GitHub → Actions → build.yml → APK
```
La raíz del ZIP es directamente la raíz del repositorio.

## Próximo paso
**v0.3** añadirá: interacción, objetos interactuables, texto, diálogos, eventos y transiciones más
completas.
