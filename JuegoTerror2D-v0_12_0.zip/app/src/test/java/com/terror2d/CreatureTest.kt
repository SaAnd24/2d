package com.terror2d

import com.terror2d.creature.Blocker
import com.terror2d.creature.CaptureSequence
import com.terror2d.creature.ArmPendulum
import com.terror2d.creature.Creature
import com.terror2d.creature.CreatureBrain
import com.terror2d.creature.CreaturePose
import com.terror2d.creature.CreatureState
import com.terror2d.creature.MouthAnimator
import com.terror2d.creature.NoiseEvent
import com.terror2d.creature.NoiseType
import com.terror2d.creature.Senses
import com.terror2d.creature.VisionConfig
import com.terror2d.world.Player
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CreatureTest {
    private val seg = "hall"

    private fun brain(x: Float = 400f) = CreatureBrain(x, seg, 100f, 700f, seed = 3)
    private fun senses(px: Float, now: Float = 0f) = Senses(playerX = px, playerSegmentId = seg, now = now)

    private fun run(b: CreatureBrain, s: Senses, seconds: Float, noises: List<NoiseEvent> = emptyList()) {
        var t = 0f
        while (t < seconds) { b.update(1f / 60f, s, noises); t += 1f / 60f }
    }

    @Test fun patrolMovesAndStaysPatrol() {
        val b = brain()
        val x0 = b.x
        run(b, senses(5000f), 8f)
        assertEquals(CreatureState.PATROL, b.state)
        assertNotEquals(x0, b.x)
        assertTrue(b.speed <= CreatureBrain.PATROL_SPEED + 0.01f)
    }

    @Test fun noiseTriggersInvestigateNotChase() {
        val b = brain()
        val n = NoiseEvent(250f, seg, NoiseType.VASE_FALL, time = 0f)
        run(b, senses(5000f), 0.3f, listOf(n))
        assertEquals(CreatureState.INVESTIGATE, b.state)
        assertNotEquals(5000f, b.lastKnownX)
    }

    @Test fun noiseHasPositionAndIsHeardApproximately() {
        val n = NoiseEvent(250f, seg, NoiseType.DOOR, time = 1f)
        assertEquals(250f, n.x, 0f)
        assertEquals(seg, n.segmentId)
        assertTrue(n.intensity > 0f && n.duration > 0f)
        val b = brain()
        run(b, senses(5000f), 0.3f, listOf(n))
        assertTrue(Math.abs(b.targetX - 250f) < 60f)
    }

    @Test fun visionTriggersChase() {
        val b = brain(400f)
        b.update(0.2f, senses(480f), emptyList())
        run(b, senses(480f), 0.3f)
        assertEquals(CreatureState.CHASE, b.state)
    }

    @Test fun visionDoesNotCrossWalls() {
        val b = brain(400f)
        val s = senses(500f)
        s.blockers = listOf(Blocker(440f, 460f, blocksSight = true))
        run(b, s, 1f)
        assertFalse(b.canSee(s))
        assertNotEquals(CreatureState.CHASE, b.state)
    }

    @Test fun hiddenPlayerIsNotSeenAndOtherSegmentIsNot() {
        val b = brain(400f)
        val s = senses(380f); s.playerHidden = true
        assertFalse(b.canSee(s))
        val s2 = Senses(playerX = 380f, playerSegmentId = "kitchen")
        assertFalse(b.canSee(s2))
    }

    @Test fun darknessShortensVision() {
        val b = brain(400f)
        val lit = senses(550f)
        val dark = senses(550f).also { it.playerLight = 0f }
        assertTrue(b.canSee(lit))
        assertTrue("en oscuridad total aún ve a corta distancia", b.canSee(dark))
        val farDark = senses(400f + b.vision.range * 0.8f).also { it.playerLight = 0f }
        assertTrue("a 0,8 del alcance con luz sí", b.canSee(senses(400f + b.vision.range * 0.8f)))
        assertFalse("pero a 0,8 del alcance en oscuridad no", b.canSee(farDark))
    }

    @Test fun chaseIsAlwaysFasterThanChild() {
        assertTrue(CreatureBrain.CHASE_SPEED > Player.SPEED * 1.2f)
        assertTrue(CreatureBrain.PATROL_SPEED < Player.SPEED * 0.5f)
    }

    @Test fun losingTargetGoesLostThenReturnsToPatrol() {
        val b = brain(400f)
        run(b, senses(480f), 0.5f)
        assertEquals(CreatureState.CHASE, b.state)
        val hidden = senses(480f).also { it.playerHidden = true }
        run(b, hidden, 2f)
        assertEquals(CreatureState.LOST_TARGET, b.state)
        run(b, hidden, 12f)
        assertTrue(b.state == CreatureState.RETURN_TO_PATROL || b.state == CreatureState.PATROL)
        run(b, hidden, 20f)
        assertEquals(CreatureState.PATROL, b.state)
    }

    @Test fun smallGapBlocksTheBigBody() {
        val b = brain(400f)
        val s = senses(120f)
        s.blockers = listOf(Blocker(200f, 230f, blocksSight = false)) // ventilación: se ve, pero no cabe
        run(b, s, 6f)
        assertTrue(b.x > 230f)
    }

    @Test fun captureReturnsToBedroomWithoutGameOver() {
        val c = CaptureSequence()
        c.start()
        var relocated = false
        var t = 0f
        var maxBlack = 0f
        while (!c.done && t < 20f) {
            c.update(1f / 60f)
            if (c.shouldRelocate) relocated = true
            maxBlack = maxOf(maxBlack, c.blackAlpha)
            assertFalse(c.isGameOver)
            t += 1f / 60f
        }
        assertTrue(c.done)
        assertTrue(relocated)
        assertEquals(1f, maxBlack, 0.001f)
    }

    @Test fun capturingSetsFlagWhenReached() {
        val b = brain(400f)
        run(b, senses(410f), 0.5f)
        assertTrue(b.captured)
    }

    @Test fun mouthsUseDifferentPhasesAndNeverAllOpenTogether() {
        val m = MouthAnimator(9, 42)
        val phases = m.params.map { it.phaseOffset }.toSet()
        assertTrue(phases.size > 6)
        var maxOpen = 0
        var t = 0f
        while (t < 120f) { maxOpen = maxOf(maxOpen, m.openCount(t, 0.15f)); t += 0.05f }
        assertTrue(maxOpen < 9)
    }

    @Test fun mouthAnimationIsDeterministic() {
        val a = MouthAnimator(6, 7)
        val b = MouthAnimator(6, 7)
        for (i in 0 until 6) assertEquals(a.openness(i, 3.3f, 0.5f), b.openness(i, 3.3f, 0.5f), 0f)
    }

    private fun walker(): Creature {
        val c = Creature(400f, seg, 100f, 700f, seed = 3)
        return c
    }

    private fun stepCreature(c: Creature, seconds: Float, px: Float = 5000f) {
        var t = 0f
        while (t < seconds) { c.update(1f / 60f, senses(px, c.time), emptyList()); t += 1f / 60f }
    }

    @Test fun walkCyclesThroughAllEightFramesWithBodyPoses() {
        val c = walker()
        val seen = HashSet<Int>()
        var t = 0f
        while (t < 12f) { c.update(1f / 60f, senses(5000f, c.time), emptyList()); if (c.gaitActive) seen.add(c.bodyPose()); t += 1f / 60f }
        assertTrue(seen.containsAll((0 until 8).map { CreaturePose.WALK0 + it }))
    }

    @Test fun creatureSettlesOnAFootContactBeforeIdle() {
        val c = walker()
        stepCreature(c, 4f)
        // detenerla: la criatura llega al destino y se queda quieta; nunca queda a mitad de zancada
        var t = 0f
        while (t < 30f) { c.update(1f / 60f, senses(5000f, c.time), emptyList()); t += 1f / 60f }
        if (!c.gaitActive) assertTrue(c.gaitFrame == 0 || c.gaitFrame == 4)
    }

    @Test fun armsReactToTheBodyAndStayQuantized() {
        val a = ArmPendulum()
        for (i in 0 until 5) a.update(1f / 60f, 0f)
        a.kick(120f)
        var maxAngle = 0f
        for (i in 0 until 120) { a.update(1f / 60f, 0f); maxAngle = maxOf(maxAngle, a.angle) }
        assertTrue("el empujón balancea el brazo", maxAngle > 5f)
        for (i in 0 until 600) a.update(1f / 60f, 0f)
        assertEquals(ArmPendulum.REST_SWING, a.swingIdx)          // vuelve a colgar quieto
        assertEquals(ArmPendulum.REST_BEND, a.bendIdx)
    }

    @Test fun walkingArmsSwingAndMouthsStayAsynchronousWhileWalking() {
        val c = walker()
        val idx = HashSet<Int>()
        var maxOpen = 0
        var t = 0f
        while (t < 30f) {
            c.update(1f / 60f, senses(5000f, c.time), emptyList())
            idx.add(c.leadArmIndex())
            maxOpen = maxOf(maxOpen, c.mouths.openCount(c.time, c.arousal))
            t += 1f / 60f
        }
        assertTrue("los brazos cambian de sprite al caminar", idx.size > 1)
        assertTrue("nunca todas las bocas a la vez", maxOpen < Creature.SECONDARY)
    }

    // ------------------------------------------------------------------ v0.10.1: campo de visión ampliado

    @Test fun visionRangeIsNoticeablyLargerThanV010() {
        assertTrue("v0.10 veía a 190 px", CreatureBrain.VISION_RANGE >= 190f * 1.4f)
        val b = brain(200f)
        assertTrue("a 250 px y con luz: antes no se veía", b.canSee(senses(450f)))
        assertFalse("más allá del alcance no", b.canSee(senses(200f + b.vision.range * 1.3f)))
    }

    @Test fun visionBehindIsShortButNotZero() {
        val b = brain(400f)
        assertTrue(b.canSee(senses(400f - b.vision.rearAwareness * 0.8f)))
        assertFalse("a la espalda y lejos no", b.canSee(senses(400f - 150f)))
    }

    @Test fun visionRangeIsConfigurable() {
        val short = CreatureBrain(400f, seg, 100f, 700f, seed = 3, vision = VisionConfig(range = 100f))
        val long = CreatureBrain(400f, seg, 100f, 700f, seed = 3, vision = VisionConfig(range = 500f))
        assertFalse(short.canSee(senses(560f)))
        assertTrue(long.canSee(senses(560f)))
    }

    @Test fun solidWallBlocksTheWideVisionButGlassDoesNot() {
        val b = brain(400f)
        val s = senses(650f)
        s.blockers = listOf(Blocker(500f, 520f, blocksSight = true))
        assertFalse(b.canSee(s))
        s.blockers = listOf(Blocker(500f, 520f, blocksSight = false))
        assertTrue(b.canSee(s))
    }

    @Test fun detectionDoesNotFlickerAtTheRangeLimit() {
        val b = brain(400f)
        val edge = b.vision.range
        val s = senses(400f + edge * 1.05f)               // justo fuera del alcance normal
        assertFalse(b.canSee(s))
        run(b, senses(400f + edge * 0.9f), 0.3f)           // lo ve y empieza a seguirlo
        assertEquals(CreatureState.CHASE, b.state)
        assertTrue("siguiéndolo, el margen de histéresis sigue viéndolo", b.canSee(s))
    }

    @Test fun losingSightThenReacquiring() {
        val b = brain(400f)
        val s = senses(520f)
        run(b, s, 0.6f)
        assertEquals(CreatureState.CHASE, b.state)
        s.playerSegmentId = "kitchen"                      // el niño desaparece de su vista
        run(b, s, 1.2f)
        assertNotEquals(CreatureState.CHASE, b.state)
        s.playerSegmentId = seg
        s.playerX = b.x + 30f
        run(b, s, 1.0f)
        assertEquals("lo recupera al verlo de nuevo", CreatureState.CHASE, b.state)
    }
}
