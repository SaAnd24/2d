package com.terror2d.render

import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.terror2d.chapter.PanelLayout
import com.terror2d.chapter.PuzzlePanel
import com.terror2d.chapter.PuzzleWorld
import com.terror2d.scene.RoomSegment
import kotlin.math.abs
import kotlin.math.sin

/**
 * Capítulo I — dibujo del panel de puzles, del final y de los SEIS estados visuales (NORMAL 1-3, TRAUMA 1-3).
 * Todo es capa artística: no lee ni cambia colisiones, puertas, puzles ni IA. Determinista (mismo segmento => mismos
 * trazos) y sin allocations de Paint por frame.
 */
class ChapterRenderer {

    private val fill = Paint().apply { style = Paint.Style.FILL; isAntiAlias = true }
    private val stroke = Paint().apply { style = Paint.Style.STROKE; isAntiAlias = true; strokeCap = Paint.Cap.ROUND }
    private val text = Paint().apply {
        isAntiAlias = true
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.LEFT
    }
    private val rect = RectF()
    private val path = Path()

    /** Paint con el filtro de grafito: grises casi sin color y algo más de contraste. */
    val graphitePaint: Paint = Paint().apply {
        val cm = ColorMatrix()
        cm.setSaturation(0.04f)
        cm.postConcat(ColorMatrix(floatArrayOf(
            1.18f, 0f, 0f, 0f, -18f,
            0f, 1.18f, 0f, 0f, -18f,
            0f, 0f, 1.18f, 0f, -16f,
            0f, 0f, 0f, 1f, 0f
        )))
        colorFilter = ColorMatrixColorFilter(cm)
    }

    private fun hash(a: Int, b: Int): Int {
        var h = a * 374761393 + b * 668265263
        h = (h xor (h ushr 13)) * 1274126177
        return h xor (h ushr 16)
    }

    /** 0..1 determinista. */
    private fun rnd(a: Int, b: Int): Float = (hash(a, b) and 0xFFFF) / 65535f

    // ------------------------------------------------------------------ panel de puzles

    private fun wrap(s: String, maxChars: Int): List<String> {
        val out = ArrayList<String>()
        var line = StringBuilder()
        for (w in s.split(" ")) {
            if (w.isEmpty()) continue
            if (line.isNotEmpty() && line.length + 1 + w.length > maxChars) {
                out.add(line.toString())
                line = StringBuilder()
            }
            if (line.isNotEmpty()) line.append(' ')
            line.append(w)
        }
        if (line.isNotEmpty()) out.add(line.toString())
        return out
    }

    fun drawPanel(canvas: Canvas, p: PuzzlePanel, time: Float) {
        val def = p.def
        fill.color = 0xCC000000.toInt()
        canvas.drawRect(0f, 0f, PanelLayout.W, PanelLayout.H, fill)
        val sx = if (p.shake > 0f) sin(time * 70f) * 3f * (p.shake / 0.45f) else 0f
        canvas.save()
        canvas.translate(sx, 0f)
        val trauma = def.world == PuzzleWorld.TRAUMA
        fill.color = if (trauma) 0xFFC9C9C6.toInt() else 0xFFFFF6DC.toInt()
        canvas.drawRect(PanelLayout.PAPER_L, PanelLayout.PAPER_T, PanelLayout.PAPER_R, PanelLayout.PAPER_B, fill)
        stroke.strokeWidth = 1.2f
        stroke.color = if (trauma) 0xFF3A3A3A.toInt() else 0xFF8A7A6A.toInt()
        canvas.drawRect(PanelLayout.PAPER_L, PanelLayout.PAPER_T, PanelLayout.PAPER_R, PanelLayout.PAPER_B, stroke)
        val ink = if (trauma) 0xFF202020.toInt() else 0xFF3A2A20.toInt()

        text.textAlign = Paint.Align.CENTER
        text.textSize = 8f
        text.color = ink
        canvas.drawText(def.id + " · " + def.title, PanelLayout.W / 2f, 20f, text)

        text.textAlign = Paint.Align.LEFT
        text.textSize = 5.6f
        text.typeface = Typeface.MONOSPACE
        text.color = ink
        var y = 32f
        val lines = wrap(p.message, 64)
        for (k in 0 until minOf(lines.size, 5)) {
            canvas.drawText(lines[k], 18f, y, text)
            y += 7f
        }
        text.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

        // piezas
        val n = def.slots.size
        val w = PanelLayout.slotWidth(n)
        val maxChars = maxOf(4, (w / 3.1f).toInt())
        for (i in 0 until n) {
            val l = PanelLayout.slotLeft(i, n)
            fill.color = if (p.solved) 0xFFCFE8B8.toInt() else if (trauma) 0xFFE4E4E2.toInt() else 0xFFFFFFFF.toInt()
            rect.set(l, PanelLayout.SLOT_TOP, l + w, PanelLayout.SLOT_BOTTOM)
            canvas.drawRoundRect(rect, 3f, 3f, fill)
            stroke.strokeWidth = 1f
            stroke.color = ink
            canvas.drawRoundRect(rect, 3f, 3f, stroke)
            // marcas de T1
            val marks = def.marks
            if (marks != null && i < marks.size) {
                stroke.strokeWidth = 1.6f
                val len = 3f + marks[i] * (w - 8f) / 3.4f
                canvas.drawLine(l + 4f, PanelLayout.SLOT_TOP - 5f, l + 4f + len.coerceAtMost(w - 8f), PanelLayout.SLOT_TOP - 5f, stroke)
            }
            text.textSize = 4.6f
            text.textAlign = Paint.Align.CENTER
            text.color = 0xFF6A5A4A.toInt()
            val lab = wrap(def.slots[i].label, maxChars)
            var ly = PanelLayout.SLOT_TOP + 7f
            for (k in 0 until minOf(lab.size, 2)) {
                canvas.drawText(lab[k], l + w / 2f, ly, text)
                ly += 5.4f
            }
            text.textSize = 5.4f
            text.color = ink
            val opt = wrap(def.slots[i].options[p.values[i]], maxChars)
            var oy = PanelLayout.SLOT_TOP + 24f
            for (k in 0 until minOf(opt.size, 4)) {
                canvas.drawText(opt[k], l + w / 2f, oy, text)
                oy += 6.4f
            }
            text.textSize = 4.2f
            text.color = 0xFF9A8A7A.toInt()
            canvas.drawText((p.values[i] + 1).toString() + "/" + def.slots[i].options.size, l + w / 2f, PanelLayout.SLOT_BOTTOM - 3f, text)
        }

        // botones
        button(canvas, PanelLayout.CLOSE_X, "CERRAR", ink, true)
        if (def.rhythm != null) button(canvas, PanelLayout.LISTEN_X, if (p.isListening) "..." else "ESCUCHAR", ink, !p.isListening)
        button(canvas, PanelLayout.TEST_X, if (p.solved) "LISTO" else "PROBAR", ink, !p.solved)
        text.textSize = 4.8f
        text.textAlign = Paint.Align.CENTER
        text.color = 0xFF6A5A4A.toInt()
        canvas.drawText(if (p.solved) "toca para continuar" else "toca una pieza para cambiarla", PanelLayout.W / 2f, 134f, text)
        canvas.restore()
    }

    private fun button(canvas: Canvas, left: Float, label: String, ink: Int, enabled: Boolean) {
        rect.set(left, PanelLayout.BTN_Y, left + PanelLayout.BTN_W, PanelLayout.BTN_Y + PanelLayout.BTN_H)
        fill.color = if (enabled) 0xFFE8DCB8.toInt() else 0xFFCFC8B4.toInt()
        canvas.drawRoundRect(rect, 4f, 4f, fill)
        stroke.strokeWidth = 1.2f
        stroke.color = ink
        canvas.drawRoundRect(rect, 4f, 4f, stroke)
        text.textSize = 6.4f
        text.textAlign = Paint.Align.CENTER
        text.color = ink
        canvas.drawText(label, left + PanelLayout.BTN_W / 2f, PanelLayout.BTN_Y + 14f, text)
    }

    // ------------------------------------------------------------------ final del capítulo

    fun drawEnding(canvas: Canvas, t: Float) {
        val a = (t / 1.6f).coerceIn(0f, 1f)
        fill.color = ((a * 255f).toInt() shl 24)
        canvas.drawRect(0f, 0f, PanelLayout.W, PanelLayout.H, fill)
        if (t < 2.2f) return
        val k = ((t - 2.2f) / 1.5f).coerceIn(0f, 1f)
        val alpha = (k * 230f).toInt() shl 24
        text.textAlign = Paint.Align.CENTER
        text.typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
        text.textSize = 11f
        text.color = alpha or 0xF4ECD8
        canvas.drawText("Fin del capítulo I", PanelLayout.W / 2f, 78f, text)
        text.textSize = 7f
        text.color = alpha or 0xBBB09C
        canvas.drawText("La casa no desaparece. Sigue ahí, detrás.", PanelLayout.W / 2f, 98f, text)
        canvas.drawText("La calle está vacía y llueve.", PanelLayout.W / 2f, 109f, text)
        text.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }

    // ------------------------------------------------------------------ estados visuales

    /** Capa de PARED (detrás de los muebles): papel desgarrado y ojos (NORMAL), grafito rayado y bocas (TRAUMA). */
    fun drawWall(canvas: Canvas, seg: RoomSegment, trauma: Boolean, level: Int, px: Float, py: Float, time: Float) {
        val sid = seg.id.hashCode()
        val wallBottom = seg.floorY - 4f
        if (!trauma) {
            if (level >= 2) tears(canvas, seg, sid, if (level >= 3) 2 else 1, wallBottom)
            if (level >= 3) eyes(canvas, seg, sid, px, py, time)
        } else {
            scribbles(canvas, seg, sid, wallBottom)
            if (level >= 3) mouths(canvas, seg, sid, time, wallBottom)
        }
    }

    private fun tears(canvas: Canvas, seg: RoomSegment, sid: Int, density: Int, wallBottom: Float) {
        val step = if (density >= 2) 46f else 78f
        var i = 0
        var x = 14f
        while (x < seg.width - 20f) {
            val r1 = rnd(sid, i)
            val r2 = rnd(sid, i + 500)
            val bx = x + r1 * 24f
            val hh = (16f + r2 * (if (density >= 2) 46f else 26f)).coerceAtMost(wallBottom * 0.7f)
            val ww = 14f + r1 * 18f
            if (density >= 2) {
                // zona desgarrada: se ve lo de debajo (papel oscuro y manchado)
                fill.color = 0xAA2A1E1C.toInt()
                path.reset()
                path.moveTo(bx - 2f, 0f)
                path.lineTo(bx + ww + 2f, 0f)
                path.lineTo(bx + ww * 0.8f, hh * 0.6f)
                path.lineTo(bx + ww * 0.45f, hh * 0.9f)
                path.lineTo(bx + ww * 0.2f, hh * 0.55f)
                path.close()
                canvas.drawPath(path, fill)
            }
            fill.color = 0xFFEFE2C4.toInt()
            path.reset()
            path.moveTo(bx, 0f)
            path.lineTo(bx + ww, 0f)
            path.lineTo(bx + ww * 0.55f, hh * 0.55f)
            path.lineTo(bx + ww * 0.3f, hh * 0.42f)
            path.close()
            canvas.drawPath(path, fill)
            stroke.strokeWidth = 0.8f
            stroke.color = 0xFF9A8460.toInt()
            canvas.drawLine(bx + ww * 0.3f, hh * 0.42f, bx + ww * 0.55f, hh * 0.55f, stroke)
            x += step
            i++
        }
    }

    private fun eyes(canvas: Canvas, seg: RoomSegment, sid: Int, px: Float, py: Float, time: Float) {
        val count = (seg.width / 64f).toInt().coerceAtLeast(2)
        for (i in 0 until count) {
            val ex = 28f + i * (seg.width - 56f) / count + rnd(sid, i + 900) * 26f
            val ey = 26f + rnd(sid, i + 950) * (seg.floorY - 90f).coerceAtLeast(20f)
            val sz = 0.8f + rnd(sid, i + 970) * 0.5f
            val dx = ((px - ex) / 90f).coerceIn(-1f, 1f)
            val dy = ((py + 22f - ey) / 90f).coerceIn(-1f, 1f)
            val bob = sin(time * 1.3f + i) * 0.35f
            canvas.save()
            canvas.translate(ex, ey + bob)
            canvas.scale(sz, sz)
            // párpados y carne alrededor (húmedo, oscuro)
            fill.color = 0xFF4A2626.toInt()
            rect.set(-10f, -6.5f, 10f, 6.5f)
            canvas.drawOval(rect, fill)
            fill.color = 0x55FF9A9A
            rect.set(-9f, -5.5f, 9f, 3f)
            canvas.drawOval(rect, fill)
            // esclerótica
            fill.color = 0xFFEEE6DA.toInt()
            rect.set(-8.2f, -4.6f, 8.2f, 4.6f)
            canvas.drawOval(rect, fill)
            // venitas
            stroke.strokeWidth = 0.5f
            stroke.color = 0x99B84040.toInt()
            canvas.drawLine(-8f, -1f, -4.5f, 0.4f, stroke)
            canvas.drawLine(8f, 1f, 4.8f, -0.3f, stroke)
            canvas.drawLine(-7f, 2.2f, -4f, 1.4f, stroke)
            // iris, pupila y brillo siguen al niño
            val ix = dx * 3.4f
            val iy = dy * 1.5f
            fill.color = 0xFF5E7A3A.toInt()
            canvas.drawCircle(ix, iy, 3.5f, fill)
            fill.color = 0xFF2E4020.toInt()
            canvas.drawCircle(ix, iy, 2.6f, fill)
            fill.color = 0xFF050505.toInt()
            canvas.drawCircle(ix + dx * 0.4f, iy, 1.5f, fill)
            fill.color = 0xFFFFFFFF.toInt()
            canvas.drawCircle(ix - 1f, iy - 1.1f, 0.7f, fill)
            // línea de las pestañas
            stroke.strokeWidth = 0.9f
            stroke.color = 0xFF1E1010.toInt()
            rect.set(-8.2f, -4.6f, 8.2f, 4.6f)
            canvas.drawOval(rect, stroke)
            canvas.restore()
        }
    }

    private fun scribbles(canvas: Canvas, seg: RoomSegment, sid: Int, wallBottom: Float) {
        stroke.strokeWidth = 0.7f
        stroke.color = 0x30101010
        val n = (seg.width / 10f).toInt()
        for (i in 0 until n) {
            val x = rnd(sid, i + 1300) * seg.width
            val y = 4f + rnd(sid, i + 1400) * (wallBottom - 8f)
            val l = 6f + rnd(sid, i + 1500) * 14f
            canvas.drawLine(x, y, x + l, y + l * 0.6f, stroke)
        }
    }

    private fun mouths(canvas: Canvas, seg: RoomSegment, sid: Int, time: Float, wallBottom: Float) {
        val count = (seg.width / 150f).toInt().coerceAtLeast(1)
        for (i in 0 until count) {
            val cx = 40f + i * (seg.width - 80f) / count + rnd(sid, i + 2000) * 40f
            val cy = 40f + rnd(sid, i + 2100) * (wallBottom - 90f).coerceAtLeast(10f)
            // hueco con el fondo arrancado: borde irregular de papel roto y capas inferiores
            path.reset()
            val pts = 10
            for (k in 0 until pts) {
                val ang = (k / pts.toFloat()) * 6.2832f
                val rr = 17f + rnd(sid, i * 31 + k + 2200) * 7f
                val px = cx + kotlin.math.cos(ang) * rr * 1.3f
                val py = cy + sin(ang) * rr * 0.85f
                if (k == 0) path.moveTo(px, py) else path.lineTo(px, py)
            }
            path.close()
            fill.color = 0xFFD8D8D2.toInt()
            canvas.save()
            canvas.translate(0f, 0f)
            canvas.drawPath(path, fill)
            canvas.restore()
            fill.color = 0xFF160A0A.toInt()
            canvas.save()
            canvas.translate(cx, cy)
            canvas.scale(0.88f, 0.88f)
            canvas.translate(-cx, -cy)
            canvas.drawPath(path, fill)
            canvas.restore()
            // boca hiperrealista: labios, dientes y cavidad que se abre y se tensa
            val open = (sin(time * 2.3f + i * 1.7f) + 1f) * 0.5f
            val gape = 1.2f + open * 7.5f
            fill.color = 0xFF3A0E10.toInt()
            rect.set(cx - 9f, cy - gape * 0.5f, cx + 9f, cy + gape * 0.5f)
            canvas.drawOval(rect, fill)
            fill.color = 0xFFEDE6D4.toInt()
            canvas.drawRect(cx - 6f, cy - gape * 0.5f + 0.4f, cx + 6f, cy - gape * 0.5f + 2.4f, fill)
            fill.color = 0xFFB8605E.toInt()
            rect.set(cx - 10.5f, cy - gape * 0.5f - 3.2f, cx + 10.5f, cy - gape * 0.5f + 1.2f)
            canvas.drawOval(rect, fill)
            fill.color = 0xFF9A4A4A.toInt()
            rect.set(cx - 9.5f, cy + gape * 0.5f - 1.4f, cx + 9.5f, cy + gape * 0.5f + 3.6f)
            canvas.drawOval(rect, fill)
            stroke.strokeWidth = 0.6f
            stroke.color = 0xFF5A2020.toInt()
            canvas.drawLine(cx - 10.4f, cy, cx - 8.5f, cy + open * 1.5f, stroke)
            canvas.drawLine(cx + 10.4f, cy, cx + 8.5f, cy + open * 1.5f, stroke)
        }
    }

    /** Capa SUPERIOR (delante de todo, bajo la iluminación): trazos rojos y sombras inofensivas de TRAUMA. */
    fun drawTop(canvas: Canvas, seg: RoomSegment, trauma: Boolean, level: Int, time: Float) {
        if (!trauma || level < 2) return
        val sid = seg.id.hashCode()
        // trazos rojos: solo en la franja alta y en la del suelo, para no tapar ninguna pista de pared ni de objeto
        stroke.strokeWidth = 2.4f
        stroke.color = 0xDDB01818.toInt()
        val n = (seg.width / 46f).toInt().coerceAtLeast(3)
        for (i in 0 until n) {
            val x = rnd(sid, i + 3000) * (seg.width - 30f)
            val top = rnd(sid, i + 3100) < 0.6f
            val y = if (top) 3f + rnd(sid, i + 3200) * 16f else seg.floorY + 6f + rnd(sid, i + 3300) * (seg.height - seg.floorY - 12f).coerceAtLeast(2f)
            val l = 18f + rnd(sid, i + 3400) * 36f
            canvas.drawLine(x, y, x + l * 0.5f, y + (rnd(sid, i + 3500) - 0.5f) * 8f, stroke)
            canvas.drawLine(x + l * 0.5f, y + (rnd(sid, i + 3500) - 0.5f) * 8f, x + l, y + (rnd(sid, i + 3600) - 0.5f) * 6f, stroke)
        }
        if (level < 3) return
        // sombras inofensivas: formas largas que se estiran y se doblan, con un retraso extraño
        fill.color = 0x70000000
        val m = (seg.width / 130f).toInt().coerceAtLeast(1)
        for (i in 0 until m) {
            val bx = 30f + i * (seg.width - 60f) / m + rnd(sid, i + 4000) * 30f
            val wob = sin(time * 0.45f + i * 2.1f)
            val h = 50f + 22f * sin(time * 0.3f + i)
            path.reset()
            path.moveTo(bx, seg.floorY)
            path.quadTo(bx + 10f * wob, seg.floorY - h * 0.5f, bx + 4f + 14f * wob, seg.floorY - h)
            path.quadTo(bx + 16f + 6f * wob, seg.floorY - h * 0.5f, bx + 14f, seg.floorY)
            path.close()
            canvas.drawPath(path, fill)
        }
    }

    /** Textura de tela sobre un mueble (NORMAL nivel 2 y 3): trama, costuras y pliegues; no cambia su silueta. */
    fun drawFabric(canvas: Canvas, x: Float, y: Float, w: Float, h: Float) {
        if (w < 8f || h < 8f) return
        canvas.save()
        canvas.clipRect(x, y, x + w, y + h)
        stroke.strokeWidth = 0.5f
        stroke.color = 0x38604030
        var d = -h
        while (d < w) {
            canvas.drawLine(x + d, y + h, x + d + h, y, stroke)
            d += 3f
        }
        stroke.color = 0x30203040
        d = 0f
        while (d < w) {
            canvas.drawLine(x + d, y, x + d, y + h, stroke)
            d += 4.5f
        }
        stroke.strokeWidth = 0.9f
        stroke.color = 0x66403028
        canvas.drawLine(x + 2f, y + h * 0.5f, x + w - 2f, y + h * 0.5f, stroke)
        canvas.restore()
    }

    /** Dibuja con [draw] el objeto vuelto del revés: lo que estaba apoyado en el suelo queda pegado al techo. */
    fun withCeilingFlip(canvas: Canvas, floorY: Float, draw: () -> Unit) {
        canvas.save()
        canvas.translate(0f, floorY)
        canvas.scale(1f, -1f)
        draw()
        canvas.restore()
    }

    @Suppress("unused")
    private fun near(a: Float, b: Float) = abs(a - b) < 1f
}
