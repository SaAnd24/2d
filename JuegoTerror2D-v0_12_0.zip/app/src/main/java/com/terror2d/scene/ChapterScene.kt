package com.terror2d.scene

/** La casa completa del Capítulo I: la casa de siempre más las estancias, los puzles y los dos mundos. */
class ChapterScene(seed: Long = HouseDefinition.DEFAULT_SEED) : Scene(ChapterHouse.create(seed))
