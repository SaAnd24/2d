package com.terror2d.chapter

import com.terror2d.audio.SfxId
import com.terror2d.core.WorldMode

/** Qué dispara un micro-susto. */
enum class ScareTrigger { ENTER_ROOM, EXAMINE, DOCUMENT, FLAG, EVENT, MIRROR }

/** Un sonido de la secuencia de un micro-susto: [after] segundos tras el anterior. [traumaOnly] = solo en TRAUMA. */
class ScareStep(val after: Float, val sfx: SfxId, val intensity: Float = 1f, val traumaOnly: Boolean = false)

/**
 * Un micro-susto narrativo (Parte IX del documento maestro). Reglas que cumplen TODOS:
 *  - se activa por un evento narrativo o al visitar un punto por primera vez, y ocurre UNA sola vez (hito "ms_<id>");
 *  - nunca cambia un puzle, una ruta, una captura ni el comportamiento de la criatura (solo suena);
 *  - usa sonidos suaves y dudosos distintos de los de persecución, captura y búsqueda de la criatura;
 *  - se espacian: nunca hay dos a la vez ni menos de [MicroScareDirector.MIN_GAP] segundos entre ellos.
 */
class MicroScare(
    val id: String,
    val trigger: ScareTrigger,
    /** Segmento (ENTER_ROOM), id del punto examinable (EXAMINE), id del documento, hito (FLAG), tipo de evento (EVENT) o "" (MIRROR). */
    val key: String,
    val delay: Float,
    val steps: List<ScareStep>,
    /** Solo en este mundo (null = en cualquiera). */
    val world: WorldMode? = null,
    /** Hito que debe estar activo para que se dispare (null = ninguno). */
    val requiresFlag: String? = null
) {
    val flag: String get() = "ms_" + id
}

object MicroScares {
    private const val SURV = "survival_ready"

    private fun one(sfx: SfxId, i: Float = 1f) = listOf(ScareStep(0f, sfx, i))

    val ALL: List<MicroScare> = listOf(
        // ---- despertar (se apoyan en eventos de la secuencia ya existente; no se repiten)
        MicroScare("awake_pill", ScareTrigger.EVENT, "ON_ITEM_PICKED", 0.2f,
            listOf(ScareStep(0f, SfxId.MS_RUSTLE, 0.5f), ScareStep(0.35f, SfxId.CLICK, 0.35f))),
        MicroScare("awake_glass", ScareTrigger.EVENT, "WINDOW_CRASH", 0.9f, one(SfxId.MS_TINKLE, 0.6f)),
        MicroScare("awake_wake", ScareTrigger.EVENT, "CHILD_WAKES", 1.2f,
            listOf(ScareStep(0f, SfxId.FAR_CREAK, 0.7f), ScareStep(0.7f, SfxId.MS_RUSTLE, 0.5f))),
        // ---- planta baja
        MicroScare("foyer_coatrack", ScareTrigger.ENTER_ROOM, "Foyer", 3.2f, one(SfxId.MS_KNOCK, 0.55f), requiresFlag = SURV),
        MicroScare("living_tv", ScareTrigger.EXAMINE, "ex_living_tv", 0.4f,
            listOf(ScareStep(0f, SfxId.MS_RUSTLE, 0.35f, traumaOnly = true), ScareStep(0.25f, SfxId.MS_VOICE_CLICK, 0.8f))),
        MicroScare("dining_chair", ScareTrigger.FLAG, ChapterFlags.solved("N1"), 4.0f, one(SfxId.MS_RUSTLE, 0.8f)),
        MicroScare("kitchen_cup", ScareTrigger.EXAMINE, "ex_kitchen_cup", 0.5f,
            listOf(ScareStep(0f, SfxId.MS_TINKLE, 0.5f), ScareStep(0.5f, SfxId.MS_SCRAPE, 0.6f, traumaOnly = true))),
        MicroScare("pantry_knock", ScareTrigger.ENTER_ROOM, "Pantry", 2.6f, one(SfxId.MS_KNOCK, 0.9f), world = WorldMode.TRAUMA),
        // ---- segundo piso
        MicroScare("hall_steps", ScareTrigger.ENTER_ROOM, "Hall", 2.4f, one(SfxId.FOOTSTEP, 0.22f), requiresFlag = "mirror_fragment_obtained"),
        MicroScare("kid_pencil", ScareTrigger.EXAMINE, "spot_N3", 0.7f, one(SfxId.MS_PENCIL, 0.8f)),
        MicroScare("mom_mattress", ScareTrigger.ENTER_ROOM, "MomRoom", 4.0f,
            listOf(ScareStep(0f, SfxId.MS_RUSTLE, 0.6f), ScareStep(0.6f, SfxId.BREATH, 0.22f)), requiresFlag = "mirror_fragment_obtained"),
        MicroScare("mirror_first", ScareTrigger.MIRROR, "", 0.15f,
            listOf(ScareStep(0f, SfxId.MS_SCRAPE, 0.8f)), world = WorldMode.TRAUMA),
        MicroScare("study_paper", ScareTrigger.DOCUMENT, "d21", 1.4f, one(SfxId.MS_RUSTLE, 0.5f)),
        // ---- sótano
        MicroScare("cellar_creak", ScareTrigger.ENTER_ROOM, "Cellar", 2.6f, one(SfxId.FAR_CREAK, 0.8f), requiresFlag = SURV),
        MicroScare("laundry_drum", ScareTrigger.EXAMINE, "ex_laundry_washer", 0.4f,
            listOf(ScareStep(0f, SfxId.MS_RUSTLE, 0.3f), ScareStep(0.25f, SfxId.MS_KNOCK, 0.4f))),
        MicroScare("electric_hum", ScareTrigger.ENTER_ROOM, "Electric", 1.6f, one(SfxId.MS_HUM_CUT, 0.9f)),
        MicroScare("boiler_pipe", ScareTrigger.EXAMINE, "valve_4", 0.5f, one(SfxId.MS_KNOCK, 0.8f), world = WorldMode.TRAUMA),
        MicroScare("foundation_drip", ScareTrigger.ENTER_ROOM, "Storage", 4.5f, one(SfxId.MS_DRIP, 0.9f), world = WorldMode.NORMAL),
        MicroScare("foundation_drip_t", ScareTrigger.ENTER_ROOM, "Storage", 4.5f, one(SfxId.MS_DRIP_LONG, 0.9f), world = WorldMode.TRAUMA),
        // ---- azotea
        MicroScare("roof_hatch", ScareTrigger.ENTER_ROOM, "Roof", 1.4f, one(SfxId.THUD, 0.45f)),
        MicroScare("roof_tank", ScareTrigger.ENTER_ROOM, "Roof", 6.5f, one(SfxId.MS_HOLLOW, 0.8f)),
        MicroScare("roof_antenna", ScareTrigger.EXAMINE, "ex_roof_antenna", 0.8f, one(SfxId.MS_WHISPER, 0.9f))
    )

    fun get(id: String): MicroScare? = ALL.firstOrNull { it.id == id }
}

/**
 * Cola de micro-sustos: arranca como máximo uno cada [MIN_GAP] segundos, uno detrás de otro, sin apilar capas.
 * Lógica pura (el sonido lo pide a través de [play]); así se puede probar sin Android.
 */
class MicroScareDirector(private val play: (SfxId, Float) -> Unit) {

    private class Running(val scare: MicroScare, var wait: Float, var step: Int)

    private var running: Running? = null
    private val waiting = ArrayList<MicroScare>()
    private var sinceLast = MIN_GAP

    val isBusy: Boolean get() = running != null

    /** Pone en cola [s] (si ya ocurrió o ya espera, se ignora). [done] = ¿tiene ya el hito?; [mark] lo activa al arrancar. */
    fun request(s: MicroScare, done: Boolean) {
        if (done) return
        if (running?.scare === s) return
        if (waiting.contains(s)) return
        waiting.add(s)
    }

    /** Descarta lo que dependía de la habitación (los sonidos de lugar no deben oírse en otra). */
    fun dropRoomBound() {
        waiting.removeAll { it.trigger == ScareTrigger.ENTER_ROOM || it.trigger == ScareTrigger.EXAMINE }
        val r = running
        if (r != null && (r.scare.trigger == ScareTrigger.ENTER_ROOM || r.scare.trigger == ScareTrigger.EXAMINE) && r.step == 0) running = null
    }

    /** Avanza. [canStart] = el mundo está en calma. [mark] se llama con el micro-susto cuando realmente arranca. */
    fun update(dt: Float, trauma: Boolean, canStart: Boolean, mark: (MicroScare) -> Unit) {
        sinceLast += dt
        val r = running
        if (r != null) {
            r.wait -= dt
            while (r.wait <= 0f && running === r) {
                val steps = r.scare.steps
                if (r.step >= steps.size) {
                    running = null
                    sinceLast = 0f
                    break
                }
                val st = steps[r.step]
                if (!st.traumaOnly || trauma) play(st.sfx, st.intensity)
                r.step++
                r.wait = if (r.step < steps.size) steps[r.step].after else 0f
                if (r.step >= steps.size) {
                    running = null
                    sinceLast = 0f
                }
            }
            return
        }
        if (!canStart || waiting.isEmpty() || sinceLast < MIN_GAP) return
        val s = waiting.removeAt(0)
        mark(s)
        running = Running(s, s.delay + (if (s.steps.isNotEmpty()) s.steps[0].after else 0f), 0)
    }

    companion object {
        /** Segundos mínimos entre dos micro-sustos. */
        const val MIN_GAP = 5f
    }
}
