package com.terror2d.chapter

import com.terror2d.core.WorldMode
import com.terror2d.story.DocumentDef
import com.terror2d.story.StoryFlags
import com.terror2d.ui.DialogueLine

/**
 * Los 22 documentos de la casa (Capítulo I). Se leen con el MISMO sistema de documentos de siempre ([DocumentDef]).
 * Los que cambian de aspecto en el otro mundo tienen una variante con sufijo "_t" (TRAUMA): [idFor] elige la correcta.
 * Ninguno explica la muerte: cada uno aporta un fragmento, una rutina o una contradicción.
 */
object ChapterDocuments {

    private const val MAX_CHARS = 32
    const val MAX_LINES = 16

    /** Parte [text] en renglones de [MAX_CHARS] caracteres como máximo, respetando los saltos de línea. */
    fun wrap(text: String): List<String> {
        val out = ArrayList<String>()
        for (para in text.split("\n")) {
            if (para.isEmpty()) {
                out.add("")
                continue
            }
            var line = StringBuilder()
            for (word in para.split(" ")) {
                if (word.isEmpty()) continue
                if (line.isNotEmpty() && line.length + 1 + word.length > MAX_CHARS) {
                    out.add(line.toString())
                    line = StringBuilder()
                }
                if (line.isNotEmpty()) line.append(' ')
                line.append(word)
            }
            if (line.isNotEmpty()) out.add(line.toString())
        }
        return out
    }

    /** El papel solo admite [MAX_LINES] renglones: si sobran, se quitan renglones en blanco (de abajo arriba). */
    fun compact(lines: List<String>): List<String> {
        val out = ArrayList(lines)
        var i = out.size - 1
        while (out.size > MAX_LINES && i >= 0) {
            if (out[i].isEmpty()) out.removeAt(i)
            i--
        }
        return out
    }

    private fun doc(
        id: String, header: String, title: String, text: String, location: String,
        reaction: String, flag: String = "read_$id"
    ) = DocumentDef(
        id = id, header = header, title = title, lines = compact(wrap(text)), handwritten = null,
        reaction = listOf(DialogueLine(null, reaction)), readFlag = flag, location = location
    )

    // ------------------------------------------------------------------ D01
    val d01 = doc(
        "d01", "NOTA", "Junto a la cama",
        "Mi niño:\n\nSi te despiertas antes que yo, quédate en casa. No salgas con la lluvia.\n\nCuida a Ranita.\n\nNo intentes arreglar la ventana.\n\nVolveré pronto.\n\nMamá.",
        "KidRoom: junto a la cama", "Mamá escribe bonito cuando se acuerda.", flag = StoryFlags.MOM_NOTE_READ
    )
    val d01t = doc(
        "d01_t", "NOTA", "Junto a la cama",
        "Las letras están en el mismo sitio, pero parte de la tinta es grafito.\n\nQuédate.\n\nNo salgas.\n\nNo intentes arreglarlo.\n\nNo tienes que encontrarme ahora.",
        "KidRoom (TRAUMA): junto a la cama", "Eso no decía… ¿o sí?", flag = StoryFlags.MOM_NOTE_READ
    )

    val d02 = doc(
        "d02", "DIBUJO", "El mantel dibujado",
        "Mamá decía que la mesa era pequeña para tantas cosas.\n\nLa taza azul iba junto a la pared.\n\nEl plato con la muesca nunca se ponía delante de la silla pequeña.\n\nSi dibujaba la mesa desde arriba, tenía que dejar espacio para que mamá pudiera mover el brazo.\n\nLa última vez olvidé dibujar la silla.",
        "Dining: mantel dibujado (N1)", "Me falta una silla en el dibujo."
    )
    val d03 = doc(
        "d03", "HOJA", "Mi horario",
        "Primero la luz llega a la cortina.\n\nDespués la taza deja de estar caliente.\n\nAl final, el pasillo vuelve a quedarse oscuro.\n\nMamá dice que no tengo que mirar el reloj todo el día.\n\nPero si no lo miro, puedo olvidarme de lo que viene después.",
        "Kitchen / MomRoom: horario (N2)", "Siempre lo miro. Por si acaso."
    )
    val d04 = doc(
        "d04", "DIBUJOS", "Cuatro dibujos de una habitación",
        "Dibujo A: La ventana está abierta.\nDibujo B: La taza está junto a la cama.\nDibujo C: La sombra llega hasta el armario.\nDibujo D: Mamá todavía está aquí.\n\nEn el reverso de la hoja D:\n«No recuerdo si lo dibujé antes o después.»",
        "KidRoom: cuatro dibujos (N3)", "No sé cuál hice primero."
    )
    val d04t = doc(
        "d04_t", "DIBUJOS", "Cuatro dibujos (grafito)",
        "Las mismas hojas, más gastadas. Algunas figuras se han borrado, pero las sombras siguen ahí: una corta, una media, una que llega al armario y una que se come el cuarto.",
        "KidRoom (TRAUMA): cuatro dibujos", "Están más feos. Pero se entienden."
    )
    val d05 = doc(
        "d05", "PAPEL", "Instrucciones para colgar cuadros",
        "Los cuatro cuadros se colgaron con los ganchos que ya estaban en la pared.\n\nNo se deben sustituir los clavos.\n\nSi un marco queda torcido, comprobar primero la longitud de la cuerda.\n\nLa marca pequeña detrás de cada marco indica dónde termina la cuerda, no dónde debe ponerse el clavo.",
        "Hall: reverso de un marco (N4)", "Los clavos no se tocan."
    )
    val d06 = doc(
        "d06", "NOTA", "Nota del electricista",
        "La instalación todavía responde, pero las conexiones no se han identificado.\n\nEl vestíbulo produce un zumbido regular.\n\nLa lámpara de la cocina tarda en estabilizarse.\n\nLa luz del distribuidor cambia después de un intervalo.\n\nNo sustituir ninguna pieza hasta identificar el circuito.",
        "Electric: nota del electricista (N5)", "Primero hay que mirar las luces."
    )
    val d07 = doc(
        "d07", "MARCAS", "Las siete marcas",
        "Siete líneas raspadas con la punta de algo:\n\nAlgunas cosas golpean una vez.\n\nOtras esperan.\n\nNo cuentes lo que escuchas.\n\nEscucha lo que falta.",
        "Pantry (TRAUMA): marcas (T1)", "Eso lo rayó alguien."
    )
    val d08 = doc(
        "d08", "GRABADO", "El retrato sin rostro",
        "En el reverso del retrato:\n\nSi tapas lo que falta, todavía puedes reconocer el borde.\n\nSi miras solamente lo que queda, no sabrás qué has perdido.",
        "MomRoom (TRAUMA): reverso del retrato (T2)", "Faltan trozos."
    )
    val d09 = doc(
        "d09", "NOTA", "Al final del pasillo",
        "La primera puerta no está donde la recuerdas.\n\nLa última puerta tampoco.\n\nPero una grieta sigue siendo la misma grieta, aunque la pared se mueva.\n\nNo sigas las puertas.\n\nSigue la marca que no cambia.",
        "Hall (TRAUMA): distribuidor (T3)", "El pasillo no es el mío."
    )
    val d10 = doc(
        "d10", "PAPEL", "Mantenimiento de la caldera",
        "La presión no es constante.\n\nUna válvula golpea dos veces y espera.\n\nOtra no llega a completar el ciclo.\n\nLa tubería más cercana a la pared deja de sonar antes que las demás.\n\nNo ajustar todas a la vez.",
        "Boiler (TRAUMA): caldera (T4)", "Respira como si estuviera viva."
    )
    val d11 = doc(
        "d11", "NOTA", "Nota de la antena",
        "El brazo más corto no apunta al edificio más cercano.\n\nLa sombra más larga tampoco apunta al horizonte.\n\nBuscar la línea quebrada.\n\nLa antena se orienta por la forma que comparte con el dibujo, no por la distancia.",
        "Roof (TRAUMA): nota de la antena (T5)", "Hay un dibujo con tres figuras."
    )
    val d12 = doc(
        "d12", "NOTA", "Las huellas",
        "Entré cuando la caja todavía estaba en el suelo.\n\nDejé mis zapatos cerca de la puerta.\n\nDespués los encontré al otro lado.\n\nNo recuerdo haberlos movido.",
        "Closet: huellas (C2)", "Mis zapatos no se mueven solos."
    )
    val d12t = doc(
        "d12_t", "NOTA", "Las huellas (grafito)",
        "Las huellas no van hacia donde terminan.\n\nEmpiezan donde nadie quiere mirar.",
        "Closet (TRAUMA): huellas (C2)", "Entran en la pared."
    )
    val d13 = doc(
        "d13", "NOTA", "El vaso",
        "Si el agua está quieta, puedes ver la lámpara.\n\nSi alguien mueve el vaso, la luz se rompe en muchas partes.\n\nMamá me dijo que no jugara con el agua.\n\nYo quería saber por qué el techo también estaba dentro del vaso.",
        "Kitchen: el vaso (C3)", "El techo también está en el vaso."
    )
    val d14a = doc(
        "d14a", "CARTA", "La carta partida (primera mitad)",
        "No quiero que aprendas a mirar el reloj antes que mi cara.\n\nHay días en que no sé cuánto tiempo ha pasado.\n\nCuando me preguntas si todo está bien, a veces digo que sí porque no sé qué otra cosa decirte.",
        "MomRoom: mesita de mamá (C4, fragmento A)", "Parece escrita para mí.", flag = "read_d14a"
    )
    val d14b = doc(
        "d14b", "CARTA", "La carta partida (segunda mitad)",
        "No todo lo que recuerdas ocurrió como lo recuerdas.\n\nPero lo que sentiste también ocurrió.\n\nNo dejes que una cosa borre la otra.",
        "Study (TRAUMA): fragmento B (C4)", "Pesa más que las demás.", flag = "read_d14b"
    )
    val d14c = doc(
        "d14c", "CARTA", "La carta completa",
        "Los trazos del margen forman una secuencia: un zigzag, un rectángulo, una línea alta.\n\nMarca final:\n«Mira desde donde la casa no debería tener ventanas.»",
        "Study: carta reconstruida (C4)", "Hay que mirar desde arriba."
    )
    val d15 = doc(
        "d15", "LISTA", "La lista de compras",
        "Pan.\nLeche.\nJabón.\nPilas para la linterna.\nUna aguja.\nHilo verde.\nAlgo dulce para el niño.\n\nNo olvidar las cosas pequeñas.",
        "Kitchen: lista de compras", "Algo dulce para el niño. Ese soy yo."
    )
    val d15t = doc(
        "d15_t", "LISTA", "La lista de compras (grafito)",
        "Pan.\nLeche.\nJabón.\nPilas para la linterna.\nUna aguja.\n\nLas últimas líneas están cubiertas por trazos oscuros. El texto sigue ahí, debajo.",
        "Kitchen (TRAUMA): lista de compras", "Lo tapó alguien. Debajo sigue."
    )
    val d16 = doc(
        "d16", "ENTRADA", "Entrada de la feria",
        "Entrada infantil.\n\nDos personas.\n\nUna tarde de lluvia.\n\nLa rana de peluche se llevó a casa.\n\n(En el reverso, un dibujo de Ranita con una costura mal hecha en el lado izquierdo.)",
        "KidRoom: caja de juguetes", "Ese día llovió y fue bonito."
    )
    val d17 = doc(
        "d17", "TARJETA", "Tarjeta de cita",
        "Próxima revisión.\n\nLlevar los papeles de la última visita.\n\nConfirmar el transporte.\n\nAvisar si el estado cambia.\n\nNo olvidar la carpeta.",
        "MomRoom: tarjeta de cita", "Mamá tiene que ir a un sitio."
    )
    val d18 = doc(
        "d18", "NOTA", "Nota del vecino",
        "Hoy escuché al pequeño preguntando por su madre.\n\nMe dijo que ya sabía dónde estaban las cosas y que podía encargarse de todo.\n\nLe dije que debía avisar a un adulto si necesitaba ayuda.\n\nPareció sorprendido, como si nunca se le hubiera ocurrido que podía pedirla.",
        "Kitchen: junto a la puerta de servicio", "Yo me encargo. Siempre."
    )
    val d19 = doc(
        "d19", "DIBUJO", "Dibujo de la ventana",
        "Una ventana cerrada, lluvia fuera y una figura pequeña en una habitación iluminada.\n\nDebajo:\n«Cuando mamá está dentro, la casa es grande.\n\nCuando mamá no está, la casa no termina nunca.»",
        "KidRoom: dibujo de la ventana", "La casa no termina nunca."
    )
    val d19t = doc(
        "d19_t", "DIBUJO", "Dibujo de la ventana (grafito)",
        "La ventana ya no tiene marco. La figura pequeña está en un cuarto que no es el de la ventana.",
        "KidRoom (TRAUMA): dibujo de la ventana", "Ese cuarto no existe."
    )
    val d20 = doc(
        "d20", "CARTA", "Nota sin entregar",
        "Mi niño:\n\nHay cosas que no sé explicarte.\n\nNo quiero que tengas miedo de preguntarme.\n\nA veces estoy cansada y digo cosas que no debería decir.\n\nEso no es culpa tuya.\n\nTe quiero.\n\nMamá.",
        "MomRoom: bajo un cajón", "Dice que no es mi culpa."
    )
    val d21 = doc(
        "d21", "HOJA", "Una hoja sin fecha",
        "La casa conserva todo en el mismo lugar.\n\nLa taza.\n\nLa silla.\n\nLa cama.\n\nLa ventana.\n\nPero nadie vuelve a entrar solamente porque las cosas sigan aquí.",
        "Study (TRAUMA): hoja sin fecha", "Todo sigue en su sitio."
    )
    val d22 = doc(
        "d22", "ENVOLTURA", "La envoltura",
        "Una envoltura vacía con la etiqueta casi arrancada. No se lee qué había dentro.\n\nEn una esquina, con letra de niño:\n«La mía sabe peor.»",
        "MomRoom: detrás de la mesita", "No me gusta cómo sabe."
    )

    val ALL: List<DocumentDef> = listOf(
        d01, d01t, d02, d03, d04, d04t, d05, d06, d07, d08, d09, d10, d11, d12, d12t, d13,
        d14a, d14b, d14c, d15, d15t, d16, d17, d18, d19, d19t, d20, d21, d22
    )

    fun get(id: String): DocumentDef? = ALL.firstOrNull { it.id == id }

    /** Id del documento [base] tal como se ve en el mundo [world] (la variante "_t" si existe). */
    fun idFor(base: String, world: WorldMode): String {
        if (world == WorldMode.TRAUMA) {
            val v = base + "_t"
            if (get(v) != null) return v
        }
        return base
    }
}
