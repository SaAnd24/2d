package com.terror2d.chapter

import com.terror2d.audio.AmbienceId
import com.terror2d.audio.MusicId
import com.terror2d.audio.SfxId
import com.terror2d.core.GameState
import com.terror2d.core.WorldMode
import com.terror2d.events.EventType
import com.terror2d.events.GameEvent
import com.terror2d.input.InputAction
import com.terror2d.input.InputController
import com.terror2d.interaction.InteractionContext
import com.terror2d.scene.RoomSegment
import com.terror2d.scene.Scene
import com.terror2d.world.Player

/**
 * Director del Capítulo I (como [com.terror2d.scene.NarrativeDirector]): panel de puzles, espejo NORMAL/TRAUMA,
 * micro-sustos, ambiente de los niveles visuales y final del capítulo. La [Scene] solo le pasa eventos y tiempo.
 * Nada de lo que hace depende del nivel visual: ese nivel solo elige cómo se ve y suena el mundo.
 */
class ChapterDirector(private val scene: Scene) {

    var panel: PuzzlePanel? = null
        private set
    val panelActive: Boolean get() = panel != null

    /** Nivel visual 1..3 del mundo actual (solo presentación). */
    var visualLevel: Int = 1
        private set

    /** Segundos desde que empezó el final (-1 = no ha empezado). */
    var endingTime: Float = -1f
        private set
    val endingActive: Boolean get() = endingTime >= 0f

    val controlLocked: Boolean get() = panel != null || endingActive

    private var solvedHandled = false
    private var lastKnock = 0
    private var lastChanged = 0
    private var lastAttempts = 0
    private var suppressEnter = false
    private var lastSeg = ""
    private var ambT = 6f
    private var musicT = 3f
    private var timeNow = 0f
    private val rng = java.util.Random(77L)
    private val timed = ArrayList<Pair<FloatArray, () -> Unit>>()

    private var audioRef: com.terror2d.audio.AudioPort = com.terror2d.audio.NullAudioPort
    private val scares = MicroScareDirector { sfx, k -> audioRef.playSfx(sfx, k) }

    // ------------------------------------------------------------------ hitos

    private fun setFlag(state: GameState, flag: String) {
        if (state.story.set(flag)) scene.events.post(EventType.ON_STORY_FLAG, flag, scene.currentSegment.id)
    }

    // ------------------------------------------------------------------ panel

    fun openPanel(id: String, ctx: InteractionContext) {
        if (panel != null) return
        val def = PuzzleBook.get(id) ?: return
        if (ctx.hasFlag(def.solvedFlag)) {
            scene.dialogue.showMessage("Ya lo resolví.")
            return
        }
        for (f in def.requires) {
            if (!ctx.hasFlag(f)) {
                scene.dialogue.showMessage(def.lockedText.ifEmpty { "Todavía no puedo." })
                return
            }
        }
        val p = PuzzlePanel(def)
        panel = p
        solvedHandled = false
        lastKnock = p.knockSerial
        lastChanged = p.changedSerial
        lastAttempts = 0
        ctx.setFlag(ChapterFlags.started(id))
        ctx.state.audio.playSfx(SfxId.PAPER, 0.7f)
    }

    private fun closePanel() {
        panel = null
    }

    // ------------------------------------------------------------------ cada frame

    /** Devuelve true si cambió de segmento (la escena corta el frame, como en una transición). */
    fun update(dt: Float, input: InputController, state: GameState): Boolean {
        timeNow += dt
        audioRef = state.audio
        visualLevel = VisualLevels.of(state.captureCount)
        val audio = state.audio
        val trauma = state.worldMode == WorldMode.TRAUMA

        // acciones temporizadas (silencio de antes de C5, restauración del ambiente...)
        var i = 0
        while (i < timed.size) {
            val t = timed[i]
            t.first[0] -= dt
            if (t.first[0] <= 0f) {
                timed.removeAt(i)
                t.second()
            } else i++
        }

        if (endingActive) {
            val before = endingTime
            endingTime += dt
            if (before < 1.5f && endingTime >= 1.5f) audio.setAmbience(AmbienceId.STORM_FAR, 4f)
            input.mirrorEnabled = false
            return false
        }

        val p = panel
        if (p != null) {
            input.mirrorEnabled = false
            if (scene.capture.active) {
                closePanel()
                return false
            }
            if (input.pointerPressed) {
                if (p.solved) {
                    if (p.solvedTime > 0.8f) closePanel()
                } else p.press(input.pointerX, input.pointerY)
            }
            p.update(dt)
            if (p.changedSerial != lastChanged) {
                lastChanged = p.changedSerial
                audio.playSfx(SfxId.CLICK, 0.6f)
            }
            if (p.knockSerial != lastKnock) {
                lastKnock = p.knockSerial
                audio.playSfx(SfxId.MS_KNOCK, 0.9f)
            }
            if (p.attempts != lastAttempts) {
                lastAttempts = p.attempts
                if (!p.solved) audio.playSfx(SfxId.PUZZLE_WRONG, 0.8f)
            }
            if (p.solved && !solvedHandled) {
                solvedHandled = true
                onSolved(p.def, state)
            }
            if (p.wantsClose || (p.solved && p.solvedTime >= PuzzlePanel.SOLVED_HOLD)) closePanel()
            return false
        }

        // ---- espejo
        val has = state.story.has(ChapterFlags.MIRROR_FRAGMENT_OBTAINED)
        val free = scene.isFreeForNarrative && !scene.narrative.controlLocked
        input.mirrorEnabled = has && free
        if (has && free && input.wasPressed(InputAction.MIRROR)) {
            if (toggleWorld(state)) return true
        }

        // ---- ambiente de los niveles visuales (solo suena; nunca cambia reglas)
        val quiet = scene.creature == null && !scene.capture.active
        if (!trauma && visualLevel >= 3 && quiet) {
            musicT -= dt
            if (musicT <= 0f) {
                musicT = 4f
                audio.playMusic(MusicId.SILENCE, 1.5f)
            }
            ambT -= dt
            if (ambT <= 0f) {
                ambT = 5f + rng.nextFloat() * 5f
                audio.playSfx(SfxId.MS_SOB, 0.8f)
            }
        } else if (trauma && visualLevel >= 3 && quiet) {
            ambT -= dt
            if (ambT <= 0f) {
                ambT = 9f + rng.nextFloat() * 8f
                audio.playSfx(if (rng.nextFloat() < 0.7f) SfxId.MS_MURMUR else SfxId.MS_RUSTLE, 0.55f)
            }
        }

        scares.update(dt, trauma, free && quiet) { s -> state.story.set(s.flag) }
        return false
    }

    private fun onSolved(def: PuzzleDef, state: GameState) {
        setFlag(state, def.solvedFlag)
        for (r in def.rewards) setFlag(state, r)
        state.audio.playSfx(SfxId.PUZZLE_SOLVED, 0.9f)
        scene.refreshNarrative(state)
        when (def.id) {
            "T5" -> {
                // el silencio exterior de antes del golpe dentro de la casa
                state.audio.duck(0.12f, 0.4f)
                state.audio.setAmbience(AmbienceId.SILENT, 0.4f)
                later(2.2f) {
                    state.audio.duck(1f, 2.5f)
                    state.audio.setAmbience(AmbienceId.STORM_FAR, 3f)
                    state.audio.playSfx(SfxId.MS_KNOCK, 0.9f)
                }
            }
            "C5" -> later(1.0f) { state.audio.playSfx(SfxId.MS_KNOCK, 1f) }
            "C4" -> setFlag(state, "read_d14c")
        }
    }

    private fun later(seconds: Float, action: () -> Unit) {
        timed.add(Pair(floatArrayOf(seconds), action))
    }

    // ------------------------------------------------------------------ espejo

    private fun toggleWorld(state: GameState): Boolean {
        val target = if (state.worldMode == WorldMode.NORMAL) WorldMode.TRAUMA else WorldMode.NORMAL
        val cur = scene.currentSegment
        if (scene.creature != null) {
            scene.dialogue.showMessage("El espejo no responde. Algo está cerca.")
            state.audio.playSfx(SfxId.PUZZLE_WRONG, 0.6f)
            return false
        }
        if (scene.definition.traumaSegments.none { it.id == cur.id }) {
            scene.dialogue.showMessage("Aquí no cambia nada.")
            return false
        }
        val seg = scene.definition.segmentFor(cur.id, target)
        val keepX = scene.player.centerX
        val facing = scene.player.facing
        val free = findFreeX(seg, keepX)
        if (free == null) {
            scene.dialogue.showMessage("El espejo se nubla. No hay sitio al otro lado.")
            state.audio.playSfx(SfxId.PUZZLE_WRONG, 0.6f)
            return false
        }
        val first = state.story.set(ChapterFlags.MIRROR_USED)
        state.worldMode = target
        suppressEnter = true
        scene.loadSegment(seg.id, seg.spawnPoints.keys.first(), state)
        suppressEnter = false
        scene.player.x = free - Player.WIDTH / 2f
        scene.player.facing = facing
        scene.camera.snapTo(scene.player.centerX)
        state.playerX = scene.player.x
        state.audio.playSfx(SfxId.MIRROR_SWITCH, 0.9f)
        if (first) scares.request(MicroScares.get("mirror_first")!!, false)
        else if (target == WorldMode.TRAUMA) { /* ya aprendido: sin susto */ }
        return true
    }

    private fun findFreeX(seg: RoomSegment, x: Float): Float? {
        val half = Player.WIDTH / 2f
        var d = 0f
        while (d <= 64f) {
            var s = 1f
            while (s >= -1f) {
                val cx = (x + d * s).coerceIn(seg.leftBoundary + half, seg.rightBoundary - half)
                if (!blocked(seg, cx, half)) return cx
                s -= 2f
            }
            d += 4f
        }
        return null
    }

    private fun blocked(seg: RoomSegment, cx: Float, half: Float): Boolean {
        for (o in seg.objects) {
            if (!o.collidable) continue
            if (cx + half > o.x && cx - half < o.right && o.bottom > seg.floorY - Player.HEIGHT && o.y < seg.floorY) return true
        }
        return false
    }

    // ------------------------------------------------------------------ eventos y segmentos

    fun onSegmentLoaded(state: GameState) {
        audioRef = state.audio
        scares.dropRoomBound()
        val id = scene.currentSegment.id
        val a = state.audio
        if (id == "Impossible") {
            a.duck(0.12f, 2.5f)
            a.setAmbience(AmbienceId.SILENT, 3f)
            a.playMusic(MusicId.SILENCE, 2f)
        } else if (lastSeg == "Impossible") {
            a.duck(1f, 4f)
            a.setAmbience(AmbienceId.STORM_FAR, 4f)
        }
        lastSeg = id
        if (suppressEnter) return
        for (s in MicroScares.ALL) {
            if (s.trigger == ScareTrigger.ENTER_ROOM && s.key == id) tryRequest(s, state)
        }
    }

    fun onEvent(e: GameEvent, state: GameState) {
        if (e.type == EventType.ON_STORY_FLAG) {
            scene.refreshNarrative(state)
            if (e.sourceId == "house_exit_used") startEnding(state)
        }
        for (s in MicroScares.ALL) {
            val hit = when (s.trigger) {
                ScareTrigger.EXAMINE -> e.type == EventType.ON_OBJECT_EXAMINED && e.sourceId == s.key
                ScareTrigger.DOCUMENT -> e.type == EventType.ON_DOCUMENT_READ && e.sourceId == s.key
                ScareTrigger.FLAG -> e.type == EventType.ON_STORY_FLAG && e.sourceId == s.key
                ScareTrigger.EVENT -> e.type.name == s.key && (e.type != EventType.ON_ITEM_PICKED || e.sourceId.startsWith("pill_box"))
                else -> false
            }
            if (hit) tryRequest(s, state)
        }
    }

    private fun tryRequest(s: MicroScare, state: GameState) {
        if (s.world != null && s.world != state.worldMode) return
        val rf = s.requiresFlag
        if (rf != null && !state.story.has(rf)) return
        scares.request(s, state.story.has(s.flag))
    }

    // ------------------------------------------------------------------ final

    fun startEnding(state: GameState) {
        if (endingActive) return
        endingTime = 0f
        setFlag(state, ChapterFlags.CHAPTER_COMPLETE)
        state.audio.duck(0.2f, 1.5f)
    }
}
