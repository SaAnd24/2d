package com.terror2d.chapter

/**
 * Geometría del panel de puzle en coordenadas lógicas (320x180). La comparten la lógica (toques) y el dibujo, para que
 * lo que se ve y lo que se toca sean siempre lo mismo.
 */
object PanelLayout {
    const val W = 320f
    const val H = 180f
    const val PAPER_L = 8f
    const val PAPER_T = 6f
    const val PAPER_R = 312f
    const val PAPER_B = 174f

    const val SLOT_AREA_L = 18f
    const val SLOT_AREA_R = 302f
    const val SLOT_TOP = 70f
    const val SLOT_BOTTOM = 118f
    const val GAP = 4f

    const val BTN_Y = 146f
    const val BTN_H = 22f
    const val BTN_W = 78f
    const val CLOSE_X = 20f
    const val LISTEN_X = 121f
    const val TEST_X = 222f

    fun slotWidth(n: Int): Float = (SLOT_AREA_R - SLOT_AREA_L - GAP * (n - 1)) / n
    fun slotLeft(i: Int, n: Int): Float = SLOT_AREA_L + i * (slotWidth(n) + GAP)

    fun inSlot(i: Int, n: Int, x: Float, y: Float): Boolean {
        val l = slotLeft(i, n)
        return x >= l && x <= l + slotWidth(n) && y >= SLOT_TOP && y <= SLOT_BOTTOM
    }

    fun inButton(left: Float, x: Float, y: Float): Boolean = x >= left && x <= left + BTN_W && y >= BTN_Y && y <= BTN_Y + BTN_H
}

/**
 * Estado de un puzle abierto. Lógica pura (sin Android): cada toque cambia una pieza, PROBAR comprueba, y el panel
 * da pistas escalonadas tras los fallos. Un fallo nunca castiga: solo dice cuántas piezas encajan.
 */
class PuzzlePanel(val def: PuzzleDef) {

    val values: IntArray = def.startValues

    var solved: Boolean = false
        private set
    var solvedTime: Float = 0f
        private set
    var attempts: Int = 0
        private set
    var lastMatches: Int = -1
        private set
    var shake: Float = 0f
        private set
    var message: String = def.intro
        private set

    /** El jugador quiere cerrar el panel (la escena lo consulta y lo cierra). */
    var wantsClose: Boolean = false

    /** Ha cambiado el valor de una pieza por última vez (para el sonido de "clic"). */
    var changedSerial: Int = 0
        private set

    // ---- ritmo de golpes (T1): el panel lleva el tiempo, quien lo oye es el director
    private var listenIndex = -1
    private var listenTimer = 0f
    var knockSerial: Int = 0
        private set
    val isListening: Boolean get() = listenIndex >= 0

    fun tapSlot(i: Int) {
        if (solved || i < 0 || i >= def.slots.size) return
        values[i] = (values[i] + 1) % def.slots[i].options.size
        lastMatches = -1
        changedSerial++
    }

    fun matches(): Int {
        var n = 0
        for (i in values.indices) if (values[i] == def.solution[i]) n++
        return n
    }

    /** Comprueba la combinación. true si queda resuelto. */
    fun test(): Boolean {
        if (solved) return true
        attempts++
        val m = matches()
        lastMatches = m
        if (m == values.size) {
            solved = true
            message = def.solvedText
            return true
        }
        shake = 0.45f
        message = if (m == 0) "No encaja nada todavía." else if (m == 1) "Solo una pieza encaja." else m.toString() + " de " + values.size + " piezas encajan."
        if (attempts >= 2) message += " " + def.hints[(attempts - 2) % def.hints.size]
        return false
    }

    /** Empieza a reproducir el ritmo oculto (solo puzles con [PuzzleDef.rhythm]). */
    fun startListen() {
        if (def.rhythm == null || isListening) return
        listenIndex = 0
        listenTimer = 0.2f
    }

    /** Un toque en (x, y). Devuelve true si cambió algo (para el sonido de interacción). */
    fun press(x: Float, y: Float): Boolean {
        if (solved) return false
        val n = def.slots.size
        for (i in 0 until n) {
            if (PanelLayout.inSlot(i, n, x, y)) {
                tapSlot(i)
                return true
            }
        }
        if (PanelLayout.inButton(PanelLayout.CLOSE_X, x, y)) {
            wantsClose = true
            return true
        }
        if (def.rhythm != null && PanelLayout.inButton(PanelLayout.LISTEN_X, x, y)) {
            startListen()
            return true
        }
        if (PanelLayout.inButton(PanelLayout.TEST_X, x, y)) {
            test()
            return true
        }
        return false
    }

    fun update(dt: Float) {
        if (shake > 0f) shake = maxOf(0f, shake - dt)
        if (solved) solvedTime += dt
        val rh = def.rhythm
        if (rh != null && listenIndex >= 0) {
            listenTimer -= dt
            if (listenTimer <= 0f) {
                if (listenIndex >= rh.size) {
                    listenIndex = -1
                } else {
                    if (rh[listenIndex]) knockSerial++
                    listenIndex++
                    listenTimer = STEP
                }
            }
        }
    }

    companion object {
        /** Segundos entre dos posiciones del ritmo de T1. */
        const val STEP = 0.42f
        /** Segundos que se muestra el éxito antes de cerrar solo. */
        const val SOLVED_HOLD = 2.4f
    }
}
