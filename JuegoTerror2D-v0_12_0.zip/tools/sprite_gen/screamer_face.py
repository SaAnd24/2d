"""SCREAMER v0.10.1: rostro canónico del monstruo, reconstruido PROCEDURALMENTE a partir de la imagen de referencia.

La imagen de referencia NO se usa en tiempo de ejecución ni se incluye en el proyecto: aquí solo se codifican, como
números, las medidas que se tomaron de ella (posición y tamaño de ojos, cejas, nariz, línea de la boca, número y
largo de dientes, paleta). El rostro se define UNA vez en un "espacio de cara" (u derecha, v abajo; 1 unidad = medio
ancho de la imagen de referencia) y todos los fotogramas lo vuelven a evaluar bajo una cámara en perspectiva
(distancia, guiñada, cabeceo, alabeo), con la mandíbula, los párpados y la mirada animados. Así cada fotograma es el
MISMO organismo visto de otra manera, no un rediseño.

Técnica: sombreador por píxel en numpy -> color flotante -> cuantización a una paleta fija con tramado ordenado
(Bayer 4x4) y contornos duros. El juego solo recibe índices de paleta (ScreamerArtData).

Dependencias (solo del generador, no del juego): numpy, scipy, Pillow.
"""
import math
import numpy as np
from scipy import ndimage as ndi

W, H = 640, 360
FOCAL = 520.0

# ------------------------------------------------------------------ paleta (RGB). Medida de la referencia + rampas propias
def _ramp(*cols):
    return [tuple(c) for c in cols]

SKIN = _ramp((12, 10, 12), (34, 28, 22), (58, 52, 34), (84, 80, 46), (108, 110, 62), (134, 138, 80), (158, 164, 100), (184, 190, 128))
SKIN_WARM = _ramp((14, 9, 10), (40, 26, 22), (66, 46, 32), (92, 70, 42), (116, 90, 52), (140, 110, 66), (164, 130, 84), (186, 152, 106))
LIP = _ramp((22, 8, 12), (52, 20, 22), (84, 34, 30), (116, 52, 42), (142, 72, 54), (168, 96, 70))
MAW = _ramp((4, 3, 7), (12, 7, 11), (26, 11, 15), (44, 16, 19), (66, 24, 25), (92, 34, 32), (120, 48, 42))
TOOTH = _ramp((38, 30, 24), (74, 62, 42), (112, 98, 62), (150, 138, 92), (186, 176, 126), (214, 206, 158), (238, 230, 184))
EYE = _ramp((18, 8, 12), (58, 20, 24), (96, 34, 36), (130, 50, 46), (160, 74, 62), (190, 108, 90))
TEAR = _ramp((14, 16, 24), (32, 38, 54), (56, 64, 84), (84, 94, 112))
WART = _ramp((70, 34, 20), (128, 70, 30), (186, 118, 46), (222, 168, 82), (246, 206, 130))
SORE = _ramp((60, 16, 16), (110, 30, 26), (156, 52, 38), (190, 82, 54))
EXTRA = [(0, 0, 0), (6, 5, 10), (10, 9, 14), (238, 226, 186), (255, 244, 214), (134, 131, 122), (255, 255, 255), (200, 40, 30)]


def build_palette():
    cols = []
    for r in (SKIN, SKIN_WARM, LIP, MAW, TOOTH, EYE, TEAR, WART, SORE):
        cols.extend(r)
    cols.extend(EXTRA)
    # sin duplicados exactos, orden estable
    out = []
    for c in cols:
        if c not in out:
            out.append(c)
    return out


PALETTE = build_palette()
PAL_ARR = np.array(PALETTE, dtype=np.float32)


# ------------------------------------------------------------------ utilidades matemáticas
def sstep(a, b, x):
    t = np.clip((x - a) / (b - a + 1e-9), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def gauss(x, s):
    return np.exp(-(x / s) ** 2)


def lerp(a, b, t):
    return a + (b - a) * t


def ramp_color(ramp, t):
    """t en [0,1] -> color RGB interpolado en la rampa (arrays)."""
    r = np.array(ramp, dtype=np.float32)
    n = len(r) - 1
    x = np.clip(t, 0.0, 1.0) * n
    i0 = np.clip(np.floor(x).astype(np.int32), 0, n - 1)
    f = (x - i0)[..., None]
    return r[i0] * (1 - f) + r[i0 + 1] * f


def _hash2(ix, iy, seed):
    h = (ix.astype(np.int64) * 374761393 + iy.astype(np.int64) * 668265263 + seed * 2246822519) & 0xFFFFFFFF
    h = ((h ^ (h >> 13)) * 1274126177) & 0xFFFFFFFF
    h = h ^ (h >> 16)
    return (h & 0xFFFF).astype(np.float32) / 65535.0


def vnoise(x, y, seed):
    ix, iy = np.floor(x), np.floor(y)
    fx, fy = x - ix, y - iy
    fx = fx * fx * (3 - 2 * fx)
    fy = fy * fy * (3 - 2 * fy)
    a = _hash2(ix, iy, seed)
    b = _hash2(ix + 1, iy, seed)
    c = _hash2(ix, iy + 1, seed)
    d = _hash2(ix + 1, iy + 1, seed)
    return lerp(lerp(a, b, fx), lerp(c, d, fx), fy)


def fbm(u, v, seed, freq, octaves=4):
    s, amp, tot = 0.0, 1.0, 0.0
    for o in range(octaves):
        s = s + amp * vnoise(u * freq, v * freq, seed + o * 17)
        tot += amp
        amp *= 0.5
        freq *= 2.03
    return s / tot


def seg_dist(u, v, p0, p1):
    dx, dy = p1[0] - p0[0], p1[1] - p0[1]
    L2 = dx * dx + dy * dy
    t = np.clip(((u - p0[0]) * dx + (v - p0[1]) * dy) / L2, 0.0, 1.0)
    return np.hypot(u - (p0[0] + t * dx), v - (p0[1] + t * dy)), t


BAYER = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]], dtype=np.float32) / 16.0 - 0.5


# ------------------------------------------------------------------ medidas de la referencia (espacio de cara)
EYES = [  # (u, v, inclinación rad, lado) lado -1 izq / +1 der
    (-0.397, -0.703, 0.16, -1), (0.373, -0.725, -0.16, 1)]
EYE_RX, EYE_RY = 0.190, 0.098
BROWS = [((-0.15, -1.03), (-0.74, -0.80)), ((0.15, -1.04), (0.74, -0.80))]
BROW_R = 0.185
NOSTRILS = [(-0.075, -0.350, 0.22), (0.105, -0.348, -0.22)]
WARTS = [(-0.76, -1.07, 0.040), (-0.52, -0.90, 0.036), (-0.28, -1.30, 0.034), (0.25, -1.31, 0.034), (0.72, -1.08, 0.042),
         (-0.89, -0.69, 0.034), (-0.62, -1.26, 0.030), (0.60, -1.30, 0.028), (0.86, -0.90, 0.030), (-0.87, -0.46, 0.026),
         (0.35, -1.07, 0.022), (-0.34, -0.99, 0.020), (0.82, -0.55, 0.024)]
SORES = [(0.07, -0.20, 0.05), (0.46, -0.24, 0.045), (-0.34, -0.19, 0.045), (-0.46, -0.30, 0.04), (0.62, -0.38, 0.04),
         (-0.18, -0.22, 0.03), (0.30, -0.18, 0.03)]
HEAD_RX, HEAD_RY, HEAD_CY = 1.13, 1.62, 0.02


def head_halfwidth(v):
    """Semiancho de la cabeza a cada altura: estrecha en la frente, ancha en las mejillas, se cierra en la papada."""
    return (0.80 + 0.34 * sstep(-1.35, -0.55, v) + 0.18 * sstep(-0.35, 0.5, v) - 0.60 * sstep(0.85, 1.65, v))
N_UP, N_LO = 17, 21
UP_L, LO_L = 0.34, 0.23


def lip_up(u):
    """Línea del labio superior (v) — la sonrisa en U de la referencia."""
    return 0.09 - 0.52 * np.abs(u) ** 1.8


def lip_lo(u, jaw):
    """Labio inferior: arco profundo; la mandíbula (jaw) lo baja (más en el centro)."""
    return 1.12 - 1.2 * np.abs(u) ** 2.1 + jaw_drop(u, jaw)


def jaw_drop(u, jaw):
    return jaw * 0.62 * (1.0 - 0.55 * np.minimum(np.abs(u), 1.2) ** 2) * sstep(1.12, 0.70, np.abs(u))


def lip_lo0(u):
    return 1.12 - 1.2 * np.abs(u) ** 2.1


# ------------------------------------------------------------------ cámara en perspectiva
def rot(yaw, pitch, roll):
    cy, sy = math.cos(yaw), math.sin(yaw)
    cp, sp = math.cos(pitch), math.sin(pitch)
    cr, sr = math.cos(roll), math.sin(roll)
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rx = np.array([[1, 0, 0], [0, cp, -sp], [0, sp, cp]])
    Rz = np.array([[cr, -sr, 0], [sr, cr, 0], [0, 0, 1]])
    return Rz @ Rx @ Ry


def face_coords(p):
    """Para cada píxel de pantalla devuelve (u, v) del plano de la cara y la validez."""
    X, Y = np.meshgrid(np.arange(W, dtype=np.float32) + 0.5 - W / 2 - p.get('shx', 0.0),
                       np.arange(H, dtype=np.float32) + 0.5 - H / 2 - p.get('shy', 0.0))
    R = rot(p.get('yaw', 0.0), p.get('pitch', 0.0), p.get('roll', 0.0))
    eu, ev, n = R[:, 0], R[:, 1], R[:, 2]
    D = p['D']
    sx, sy = p.get('sx', 0.0), p.get('sy', 0.0)
    u0, v0 = p.get('u0', 0.0), p.get('v0', 0.0)
    P0 = np.array([sx * D / FOCAL, sy * D / FOCAL, D])
    C = P0 - u0 * eu - v0 * ev
    dx, dy = X / FOCAL, Y / FOCAL
    nd = n[0] * dx + n[1] * dy + n[2]
    t = (n @ C) / np.where(np.abs(nd) < 1e-4, 1e-4, nd)
    Px, Py, Pz = t * dx - C[0], t * dy - C[1], t - C[2]
    u = (Px * eu[0] + Py * eu[1] + Pz * eu[2]).astype(np.float32)
    v = (Px * ev[0] + Py * ev[1] + Pz * ev[2]).astype(np.float32)
    return u, v, (t > 0)



# ------------------------------------------------------------------ MEDIDAS tomadas de la referencia (px de la referencia 896x1200)
# Solo cifras puntuales (posición, tamaño, inclinación) de cada pieza; el dibujo es 100 % de las primitivas de este archivo.
def U(x):
    return (x - 448.0) / 448.0


def V(y):
    return (y - 600.0) / 448.0


# dientes superiores: (centro x, y de la base, y de la punta, ancho)
UP_TEETH = [(140, 572, 646, 30), (190, 612, 706, 38), (234, 628, 752, 54), (285, 656, 764, 48), (342, 664, 782, 54), (416, 672, 782, 48),
            (484, 670, 776, 68), (550, 658, 768, 52), (610, 648, 744, 46), (653, 626, 706, 38), (694, 610, 676, 36), (735, 582, 624, 30)]
# dientes inferiores: (centro x, y de la punta, y de la base, ancho)
LO_TEETH = [(167, 750, 782, 24), (193, 788, 818, 24), (220, 838, 866, 26), (261, 912, 954, 28), (316, 958, 1022, 34), (360, 988, 1046, 34),
            (431, 1002, 1074, 34), (485, 1002, 1076, 36), (539, 988, 1052, 36), (574, 964, 1016, 30), (604, 912, 976, 30), (633, 928, 968, 26),
            (650, 882, 934, 28), (679, 822, 882, 28), (726, 762, 792, 24)]
EYE_M = [  # centro, semiejes, inclinación (la comisura exterior cae), pupila
    dict(c=(270, 292), rx=84, ry=46, tilt=0.46, pupil=(272, 286), side=-1),
    dict(c=(612, 276), rx=80, ry=44, tilt=-0.34, pupil=(618, 272), side=1)]
NOSTRIL_M = [dict(c=(413, 450), rx=27, ry=50, tilt=0.30), dict(c=(490, 446), rx=28, ry=52, tilt=-0.30)]
BROW_M = [dict(a=(392, 150), b=(120, 262), r=54), dict(a=(508, 146), b=(780, 250), r=54)]
WART_M = [(111, 126, 17), (208, 182, 19), (53, 281, 15), (326, 22, 17), (283, 4, 13), (558, 30, 18), (592, 8, 13), (683, 170, 15), (770, 120, 15),
          (165, 70, 12), (640, 62, 11), (380, 18, 10)]
SORE_M = [(309, 516, 14), (660, 502, 16), (265, 472, 12), (304, 451, 10), (572, 442, 11), (500, 520, 12), (390, 540, 9)]
# barras de las lágrimas (escalera oscura): (x centro, y arriba, semiancho arriba, semiancho abajo, nº barras)
TEAR_M = [dict(x=270, y0=322, hw0=90, hw1=62, n=5, side=-1), dict(x=622, y0=306, hw0=82, hw1=64, n=6, side=1)]
HEAD_HW = [(-1.9, 0.72), (-1.34, 0.74), (-1.0, 0.84), (-0.8, 0.96), (-0.6, 1.10), (-0.4, 1.22), (0.9, 1.22), (1.2, 1.04), (1.6, 0.74)]


def head_hw(v):
    xs = [p[0] for p in HEAD_HW]
    ys = [p[1] for p in HEAD_HW]
    return np.interp(v, xs, ys)


def capsule(u, v, a, b, r):
    """Perfil de almohadilla de una cápsula (px ref -> unidades): 1 en el eje, 0 en el borde."""
    d, t = seg_dist(u, v, (U(a[0]), V(a[1])), (U(b[0]), V(b[1])))
    return sstep(1.0, 0.0, d / (r / 448.0)), d, t


def height_field(u, v, eye_w):
    """Relieve: cráneo, losas de las cejas, puente y base de la nariz, cuencas, pómulos, bloques del labio superior, rodillos de las
    mejillas y papada, verrugas."""
    hw = head_hw(v)
    h = 0.55 * np.sqrt(np.clip(1 - (u / hw) ** 2, 0, 1)) * sstep(-1.9, -1.2, v)
    for bm in BROW_M:
        a = (bm['a'][0], bm['a'][1] - 22 * eye_w)
        b = (bm['b'][0], bm['b'][1] - 26 * eye_w)
        c, d, t = capsule(u, v, a, b, bm['r'] * 1.15)
        h += 0.22 * c ** 0.7
    c, d, t = capsule(u, v, (448, 120), (448, 400), 52)
    h += 0.16 * c ** 0.8
    for e in EYE_M:
        ue, ve = (u - U(e['c'][0])), (v - V(e['c'][1]))
        h -= 0.20 * gauss(np.hypot(ue / 0.30, ve / 0.20), 1.0)
    for sgn in (-1, 1):
        h += 0.20 * gauss(np.hypot((u - sgn * 0.58) / 0.36, (v + 0.12) / 0.26), 1.0)           # pómulos
        h += 0.10 * gauss(np.hypot((u - sgn * 0.88) / 0.22, (v - 0.55) / 0.55), 1.0)           # papada lateral
    up = lip_up(u)
    h += 0.14 * gauss(v - (up - 0.07), 0.07) * sstep(1.3, 0.8, np.abs(u))
    h += 0.10 * gauss(v - (lip_lo0(u) + 0.05), 0.07) * sstep(1.3, 0.8, np.abs(u))
    h += 0.12 * gauss(np.hypot(u / 0.6, (v - 1.18) / 0.26), 1.0)                                  # mentón
    # bloques pálidos del labio superior (la hilera de "dientes de calavera"): periodo 0,116
    band = sstep(0.62, 0.55, np.abs(u)) * sstep(up - 0.24, up - 0.19, v) * sstep(up - 0.06, up - 0.10, v)
    h += 0.07 * band * (0.5 + 0.5 * np.cos((u - 0.0) * 2 * math.pi / 0.116)) ** 0.7
    # rodillos horizontales de la frente
    h += 0.028 * (fbm(u, v, 5, 6.0, 3) - 0.5)
    for (wx, wy, r) in WART_M:
        h += 0.10 * gauss(np.hypot(u - U(wx), v - V(wy)), r / 448.0)
    return h


def shade_height(h, s_eff, light=(-0.35, -0.70, 0.62)):
    gy, gx = np.gradient(h)
    k = s_eff * 0.80
    nx, ny, nz = -gx * k, -gy * k, np.ones_like(h)
    inv = 1.0 / np.sqrt(nx * nx + ny * ny + nz * nz)
    nx, ny, nz = nx * inv, ny * inv, nz * inv
    L = np.array(light, dtype=np.float32)
    L = L / np.linalg.norm(L)
    lam = np.clip(nx * L[0] + ny * L[1] + nz * L[2], 0.0, 1.0)
    sig = max(2.0, 0.05 * s_eff)
    ao = np.clip((ndi.gaussian_filter(h, sig) - h) * 3.4, 0.0, 0.55)
    return lam, ao


def paint(img, m, col, outline=None):
    img[m] = col[m] if col.ndim == 3 else col
    if outline is not None:
        edge = m & ~ndi.binary_erosion(m, iterations=1, border_value=1)
        img[edge] = img[edge] * outline


def rot2(du, dv, a):
    c, s = math.cos(a), math.sin(a)
    return du * c + dv * s, -du * s + dv * c


def tooth_shape(u, v, cx, ytop, ytip, wpx, lean_to, base_wide=True):
    """Diente superior: ancho casi uniforme arriba y punta romana (como en la referencia). Devuelve (máscara, x local -1..1, t 0..1)."""
    x0, y0, y1 = U(cx), V(ytop), V(ytip)
    L = y1 - y0
    t = (v - y0) / L
    lean = lean_to * 0.22 * L * np.clip(t, 0, 1) ** 1.3
    xc = x0 + lean
    hw = (wpx / 2.0 / 448.0) * np.clip(1.0 - np.clip(t, 0, 1) ** 2.2, 0, 1) ** 0.6
    m = (t > -0.03) & (t < 1.0) & (np.abs(u - xc) < hw)
    return m, np.clip((u - xc) / np.maximum(hw, 1e-5), -1, 1), np.clip(t, 0, 1)


def render(p):
    """Un fotograma (RGB flotante). Todo se dibuja con primitivas, relieve y luz propios; las cifras vienen de las medidas de arriba."""
    u, v, valid = face_coords(p)
    D = p['D']
    s_eff = FOCAL / D
    jaw = p.get('jaw', 0.0)
    eye_w = p.get('eyew', 0.0)
    lid = p.get('lid', 0.0)
    lookx, looky = p.get('lookx', 0.0), p.get('looky', 0.0)
    seed = p.get('seed', 1)
    lum = p.get('lum', 1.0)

    up = lip_up(u)
    lo0 = lip_lo0(u)
    wj = jaw_drop(u, jaw)
    vm = 0.5 * (up + lo0 + wj)
    vs = np.where(v < vm, v, v - wj)
    vl = v - wj

    # ---------------- piel
    h = height_field(u, vs, eye_w)
    for off, amp in ((0.20, 0.05), (0.42, 0.045), (0.64, 0.035)):
        h -= amp * gauss(vs - (lo0 + off - 0.25 * np.abs(u) ** 2), 0.018) * sstep(0.1, 0.4, vs) * sstep(1.0, 0.7, np.abs(u))
    for off, amp in ((-0.17, 0.10), (-0.33, 0.09), (-0.48, 0.07)):                      # pliegues concéntricos de las mejillas
        h -= amp * gauss(vs - (up + off + 0.12 * np.abs(u)), 0.016) * sstep(0.30, 0.6, np.abs(u)) * sstep(1.1, 0.9, np.abs(u))
    lam, ao = shade_height(h, s_eff)
    tt = np.clip(0.12 + 1.15 * (lam - 0.30) - 0.55 * ao, 0, 1)
    vert = 1.0 - 0.28 * sstep(0.35, 1.3, vs) + 0.10 * sstep(-0.5, -1.2, vs)
    n1 = fbm(u, vs, seed, 7.0, 3)
    pores = (fbm(u, vs, seed + 9, 34.0, 2) > 0.80).astype(np.float32)
    tt = np.clip(tt * vert * (0.92 + 0.14 * n1) - 0.05 * pores, 0, 1)
    warm = np.clip(0.05 + 0.30 * sstep(0.1, 1.25, vs) + 0.25 * sstep(0.9, 1.2, np.abs(u)), 0, 1)[..., None]
    img = ramp_color(SKIN, tt) * (1 - warm) + ramp_color(SKIN_WARM, tt) * warm

    # surcos entre los bloques del labio superior y bajo el borde de las cejas
    band = sstep(0.62, 0.55, np.abs(u)) * sstep(up - 0.24, up - 0.19, vs) * sstep(up - 0.06, up - 0.10, vs)
    groove = np.cos(u * 2 * math.pi / 0.116 + math.pi)
    img[(groove > 0.78) & (band > 0.5)] *= 0.55
    for bm in BROW_M:
        c, d, t = capsule(u, vs, bm['a'], bm['b'], bm['r'] * 1.15)
        edge_lo = (d > bm['r'] / 448.0 * 1.0) & (d < bm['r'] / 448.0 * 1.16) & (vs > (U(bm['a'][0]) * 0 + V(bm['a'][1]) + (V(bm['b'][1]) - V(bm['a'][1])) * t))
        edge_hi = (d > bm['r'] / 448.0 * 1.0) & (d < bm['r'] / 448.0 * 1.12) & (vs < (V(bm['a'][1]) + (V(bm['b'][1]) - V(bm['a'][1])) * t))
        img[edge_lo & (d < bm['r'] / 448.0 * 1.07)] *= 0.55

    # verrugas ocres con volumen
    for (wx, wy, r) in WART_M:
        d = np.hypot(u - U(wx), vs - V(wy)) / (r / 448.0)
        m = d < 1.0
        if not m.any():
            continue
        tw = np.clip(0.30 + 0.35 * (1 - d) + 0.35 * (lam - 0.5), 0, 1)
        paint(img, m, ramp_color(WART, tw * 0.8), outline=0.55)
    # llagas rojizas
    for k, (sx_, sy_, r) in enumerate(SORE_M):
        d = np.hypot((u - U(sx_)) / 1.4, vs - V(sy_)) / (r / 448.0)
        nz = fbm(u, vs, seed + 40 + k, 30.0, 2)
        m = d < (0.7 + 0.7 * nz)
        paint(img, m, ramp_color(SORE, np.clip(0.25 + 0.5 * nz, 0, 1)))

    # ---------------- ojos
    eyes = []
    for e in EYE_M:
        ex, ey = U(e['c'][0]), V(e['c'][1])
        sx_, sy_ = 1.0 + 0.12 * eye_w, 1.0 + 0.75 * eye_w
        ue, ve = rot2(u - ex, vs - ey, e['tilt'])
        rx, ry = e['rx'] / 448.0 * sx_, e['ry'] / 448.0 * sy_
        ell = (ue / rx) ** 2 + (ve / ry) ** 2
        # cuenca oscura y bolsa del párpado inferior
        socket = gauss(np.sqrt(np.maximum(ell, 0)) - 1.0, 0.8)
        img *= (1 - 0.72 * socket * (ell > 1.0))[..., None]
        bag = (ell > 1.0) & (ell < 1.5) & (ve > 0)
        img[bag] *= 0.78
        eye = ell < 1.0
        lid_line = -ry * (0.22 - 0.75 * lid) + 0.16 * ry * (ue / rx) * -e['side']
        lidm = eye & (ve < lid_line)
        ball = eye & ~lidm
        te = np.clip(0.38 - 0.30 * np.minimum(ell, 1.4) ** 1.2 + 0.20 * np.clip(ve / ry, -1, 1) * 0.5 + 0.10 * (fbm(u, vs, seed + 7, 26.0, 3) - 0.5), 0, 1)
        vein = (np.abs(fbm(ue, ve, seed + 5, 24.0, 2) - 0.5) < 0.016) & (ell > 0.3)
        te = np.where(vein, te * 0.6, te)
        paint(img, ball, ramp_color(EYE, te), outline=0.35)
        px_, py_ = U(e['pupil'][0]) + lookx * 0.07, V(e['pupil'][1]) + looky * 0.05
        pr = np.hypot(u - px_, vs - py_)
        iris = ball & (pr < 0.062)
        paint(img, iris, ramp_color(EYE, np.clip(0.12 + 0.35 * (pr / 0.062), 0, 1)))
        img[ball & (pr < 0.036 * (1 + 0.3 * eye_w))] = np.array(EXTRA[1], dtype=np.float32)
        img[ball & (np.hypot(u - px_ - 0.012, vs - py_ + 0.014) < 0.009)] = np.array(EXTRA[3], dtype=np.float32)
        paint(img, lidm, ramp_color(SKIN, np.clip(0.18 + 0.2 * (lam - 0.5), 0, 1)) * 0.75, outline=0.3)
        eyes.append(eye)
    eye_any = eyes[0] | eyes[1]

    # ---------------- lágrimas: escalera oscura con regueros
    for tm_ in TEAR_M:
        cx = U(tm_['x'])
        for i in range(tm_['n']):
            y = V(tm_['y0'] + i * 23)
            hw = (tm_['hw0'] + (tm_['hw1'] - tm_['hw0']) * i / max(tm_['n'] - 1, 1)) / 448.0
            wob = 0.006 * np.sin(u * 40 + i)
            bar = (np.abs(vs - y - wob) < 7.5 / 448.0) & (np.abs(u - cx - 0.012 * tm_['side']) < hw) & ~eye_any
            paint(img, bar, ramp_color(TEAR, np.clip(0.18 + 0.3 * (lam - 0.4), 0, 1)), outline=0.6)
        for dx, ln in ((-1, 0.30), (1, 0.34), (-0.1, 0.20)):
            x0 = cx + dx * (tm_['hw0'] - 8) / 448.0
            dd, _ = seg_dist(u, vs, (x0, V(tm_['y0'])), (x0 + 0.01 * dx, V(tm_['y0']) + ln))
            paint(img, (dd < 0.008) & ~eye_any, ramp_color(TEAR, np.full((H, W), 0.25, dtype=np.float32)))
            paint(img, (np.hypot(u - x0 - 0.01 * dx, vs - V(tm_['y0']) - ln) < 0.014) & ~eye_any, ramp_color(TEAR, np.full((H, W), 0.5, dtype=np.float32)), outline=0.5)

    # ---------------- fosas nasales (ranuras altas, inclinadas "/\")
    for nn in NOSTRIL_M:
        a, b = rot2(u - U(nn['c'][0]), vs - V(nn['c'][1]), nn['tilt'])
        m = (a / (nn['rx'] / 448)) ** 2 + (b / (nn['ry'] / 448)) ** 2 < 1
        rim = (a / (nn['rx'] * 1.45 / 448)) ** 2 + (b / (nn['ry'] * 1.25 / 448)) ** 2 < 1
        img[rim & ~m] *= 0.55
        paint(img, m, np.array(EXTRA[2], dtype=np.float32))

    # ---------------- boca
    interior = (v > up) & (vl < lo0) & (np.abs(u) < 1.13)
    lipw = 0.090
    rim_up = (v > up - lipw * 0.6) & (v <= up + 0.012) & (np.abs(u) < 1.1)
    rim_lo = (vl >= lo0 - 0.012) & (vl < lo0 + lipw) & (np.abs(u) < 1.1)
    dl = np.maximum(v - up, 0)
    dl2 = np.maximum(lo0 - vl, 0)
    glow = 0.20 * np.exp(-dl / 0.07) + 0.20 * np.exp(-dl2 / 0.08) + 0.05 * fbm(u, v, seed + 12, 6.0, 3)
    maw = ramp_color(MAW, np.clip(glow * 1.4, 0, 1))
    te_ = np.hypot(u / 0.46, (vl - 0.74) / 0.25)
    tongue = interior & (te_ < 1)
    ridges = 0.5 + 0.5 * np.sin(te_ * 30.0)
    tcol = ramp_color(MAW, np.clip(0.12 + 0.22 * np.clip(1 - te_, 0, 1) ** 0.8 + 0.04 * ridges - 0.08 * gauss(u, 0.02), 0, 1))
    maw[tongue] = tcol[tongue]
    paint(img, interior, maw)
    paint(img, rim_up, ramp_color(LIP, np.clip(0.48 - (up - v) / lipw * 0.28 + 0.15 * (fbm(u, v, seed + 15, 18.0, 3) - 0.5), 0, 1)), outline=0.5)
    paint(img, rim_lo & ~rim_up, ramp_color(LIP, np.clip(0.50 + (lo0 - vl) / lipw * 0.20 + 0.15 * (fbm(u, vl, seed + 16, 18.0, 3) - 0.5), 0, 1)), outline=0.5)

    # dientes superiores
    for (cx, yt, yp, wpx) in UP_TEETH:
        lean = -1.0 if cx > 450 else 1.0
        lean *= min(abs(cx - 450) / 220.0, 1.0)
        m, xl, t = tooth_shape(u, v, cx, yt, yp, wpx, lean)
        m &= interior | (v > up - 0.02)
        if not m.any():
            continue
        tcl = np.clip(0.66 - 0.26 * xl + 0.10 * t - 0.32 * (t < 0.18) - 0.22 * (np.abs(xl) > 0.80), 0, 1)
        paint(img, m, ramp_color(TOOTH, tcl), outline=0.40)
    # dientes inferiores (suben desde el labio inferior; se mueven con la mandíbula): los medidos y uno intermedio entre cada par
    lo_all = []
    for i_, (cx, yp, yb, wpx) in enumerate(LO_TEETH):
        lo_all.append((cx, yp, yb, wpx * 1.35))
        if i_ + 1 < len(LO_TEETH):
            c2, p2, b2, w2 = LO_TEETH[i_ + 1]
            lo_all.append(((cx + c2) / 2, (yp + p2) / 2 + 14, (yb + b2) / 2 + 4, (wpx + w2) * 0.55))
    for (cx, yp, yb, wpx) in lo_all:
        lean = 1.0 if cx > 450 else -1.0
        lean *= -min(abs(cx - 450) / 220.0, 1.0)
        x0, y_tip, y_base = U(cx), V(yp), V(yb)
        L = y_base - y_tip
        t = (y_base - vl) / L                                     # 0 en la base, 1 en la punta
        xc = x0 + lean * 0.22 * L * np.clip(t, 0, 1) ** 1.3
        hw = (wpx / 2.0 / 448.0) * np.clip(1.0 - np.clip(t, 0, 1) ** 2.2, 0, 1) ** 0.6
        m = (t > -0.03) & (t < 1.0) & (np.abs(u - xc) < hw) & interior
        if not m.any():
            continue
        xl = np.clip((u - xc) / np.maximum(hw, 1e-5), -1, 1)
        tcl = np.clip(0.58 - 0.26 * xl + 0.10 * t - 0.30 * (t < 0.18) - 0.22 * (np.abs(xl) > 0.80), 0, 1)
        paint(img, m, ramp_color(TOOTH, tcl), outline=0.40)

    # baba
    if jaw > 0.5:
        for q in range(7):
            ui = -0.62 + 0.21 * q + 0.04 * math.sin(q * 3.7)
            top = lip_up(ui) + 0.20 * (1.0 - 0.52 * (ui / 0.9) ** 2)
            ln = (0.18 + 0.30 * min(jaw, 1.6)) * (0.6 + 0.4 * math.sin(q * 2.3 + 1.0) ** 2)
            dd, tt2 = seg_dist(u, v, (ui, top), (ui + 0.01 * (q % 3 - 1), top + ln))
            m = (dd < 0.0075) & interior
            img[m] = np.array(EXTRA[3], dtype=np.float32) * (0.55 + 0.45 * np.clip(1 - tt2[m] * 0.5, 0, 1))[..., None]
            drop = (np.hypot(u - (ui + 0.01 * (q % 3 - 1)), v - (top + ln)) < 0.016) & interior
            img[drop] = np.array(EXTRA[4], dtype=np.float32) * 0.85

    # silueta de la cabeza
    hw = head_hw(vs)
    rr = np.abs(u) / hw
    head = (rr < 1.0) & valid & (vs > -1.8)
    img *= (0.30 + 0.70 * sstep(1.0, 0.72, rr))[..., None]
    img[~head] = np.array(EXTRA[1], dtype=np.float32)
    img *= lum
    return img


def quantize(img, amp=13.0):
    h, w, _ = img.shape
    b = np.tile(BAYER, (h // 4 + 1, w // 4 + 1))[:h, :w][..., None] * amp
    x = np.clip(img + b, 0, 255)
    out = np.zeros((h, w), dtype=np.uint8)
    best = np.full((h, w), 1e18, dtype=np.float32)
    for i, c in enumerate(PAL_ARR):
        d = ((x - c) ** 2).sum(axis=2)
        m = d < best
        best[m] = d[m]
        out[m] = i
    return out


def to_rgb(idx):
    return PAL_ARR[idx].astype(np.uint8)
