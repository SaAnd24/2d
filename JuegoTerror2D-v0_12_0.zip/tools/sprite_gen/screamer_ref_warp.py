"""SCREAMER v0.10.1 (método final): la imagen de referencia reproducida 1:1 y animada por deformación.

El primer fotograma ES la imagen de referencia, sin cambios, en su rejilla nativa de píxeles (120x160 bloques) y con la paleta de la imagen.
Los demás fotogramas se obtienen del MISMO primer fotograma deformándolo con una cámara en perspectiva (acercamiento, guiñada, cabeceo,
alabeo), la mandíbula que se abre (la parte baja del rostro desciende y el hueco se rellena con el gaznate oscuro), los ojos que se
abultan y efectos de viñeta, temblor, baba y manos. No se redibuja la cara.

Los píxeles de la referencia quedan en el juego como DATOS de arte con el mismo formato que el resto (ScreamerArtData: índices de paleta
en zlib+base64). La imagen original (JPG) NO se incluye en el proyecto ni se carga en tiempo de ejecución.

Uso: lo invoca screamer_anim.py con la ruta de la imagen (variable de entorno SCREAMER_REF o primer argumento).
"""
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

import screamer_face as F
from screamer_face import W, H, sstep, face_coords, lip_up, jaw_drop

GW, GH = 120, 160                           # rejilla nativa de la referencia
BLOCK_X, BLOCK_Y = 896.0 / GW, 1200.0 / GH


class Ref:
    def __init__(self, path):
        im = Image.open(path).convert('RGB')
        small = im.resize((GW, GH), Image.BOX)                       # cada bloque = un píxel del arte original
        q = small.quantize(colors=205, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
        pal = np.array(q.getpalette()[:205 * 3], dtype=np.uint8).reshape(-1, 3)
        self.idx = np.array(q).astype(np.int32)                       # índices en la paleta de la imagen
        extra = []
        for r in (F.SKIN, F.SKIN_WARM, F.WART, F.TOOTH, F.MAW):
            extra.extend(r)
        extra.extend(F.EXTRA)
        self.palette = [tuple(int(c) for c in p) for p in pal] + [tuple(int(c) for c in e) for e in extra]
        self.pal_arr = np.array(self.palette, dtype=np.float32)
        self.black = int(np.argmin(((self.pal_arr - np.array([6, 5, 10])) ** 2).sum(1)))
        self.maw = int(np.argmin(((self.pal_arr - np.array([18, 9, 13])) ** 2).sum(1)))
        self.rgb = self.pal_arr[self.idx]                              # GHxGWx3 para efectos


def warp_indices(ref, p):
    """Fotograma: índices de paleta tomados del primer fotograma por muestreo en perspectiva. Devuelve (idx HxW, inside HxW)."""
    u, v, valid = face_coords(p)
    jaw = p.get('jaw', 0.0)
    eye_w = p.get('eyew', 0.0)
    up = lip_up(u)
    wj = jaw_drop(u, jaw)
    # mandíbula: por debajo de la punta de los colmillos superiores la cara baja 'wj'; el hueco es gaznate oscuro
    cut = np.minimum(0.45, up + 0.40)
    vs = np.where(v < cut, v, v - wj)
    gap = (v >= cut) & (v < cut + wj)
    # ojos que se abultan: dilatación radial alrededor de cada ojo
    us = u.copy()
    for ex, ey in ((-0.397, -0.688), (0.366, -0.725)):
        k = 0.55 * eye_w
        if k > 0:
            g = np.exp(-(((u - ex) / 0.30) ** 2 + ((vs - ey) / 0.20) ** 2))
            us = ex + (us - ex) / (1.0 + k * g)
            vs = ey + (vs - ey) / (1.0 + 1.3 * k * g)
    x = us * 448.0 + 448.0
    y = vs * 448.0 + 600.0
    gx = np.floor(x / BLOCK_X).astype(np.int32)
    gy = np.floor(y / BLOCK_Y).astype(np.int32)
    inside = (gx >= 0) & (gx < GW) & (gy >= 0) & (gy < GH) & valid
    out = np.full((H, W), ref.black, dtype=np.int32)
    out[inside] = ref.idx[gy[inside], gx[inside]]
    g_ = gap & valid & (np.abs(u) < 1.0)
    out[g_] = ref.maw
    return out, inside | g_


def nearest_index(ref, rgb):
    x = np.clip(rgb, 0, 255)
    best = np.full(x.shape[:2], 1e18, dtype=np.float32)
    out = np.zeros(x.shape[:2], dtype=np.int32)
    for i, c in enumerate(ref.pal_arr):
        d = ((x - c) ** 2).sum(axis=2)
        m = d < best
        best[m] = d[m]
        out[m] = i
    return out
