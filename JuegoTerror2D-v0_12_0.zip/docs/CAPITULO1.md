# MYMom — Capítulo I: la casa de los dos mundos (v0.12.0, arquitectura por plantas)

> **Estado real**: NO se ha compilado ni ejecutado nada (este entorno no tiene Gradle/Android SDK). Ninguna posición en
> pantalla está verificada. Tests escritos pero sin ejecutar. Compila primero y revisa coordenadas en `ChapterHouse.kt`.

## Mapa definitivo (20 zonas, `scene/ChapterHouse.kt`)
Todas las conexiones normales son `Door` reales (la criatura las usa). Solo hay pasos "secretos" (marcados ★) justificados por un puzle.

```
SEGUNDO PISO   Kid ─ Bath ─ Mom ─ [Hall = pasillo] ─ Closet ─★C2─ Study (puerta del pasillo cerrada con llave)
               Hall ──escalera principal──▶ Foyer        Hall ──trampilla──▶ Roof
PLANTA BAJA    Foyer ─ Living ─ Dining ─ Kitchen ─ ServiceCorridor ─ ServiceBath
               Kitchen ─ Pantry        Living ★C1★ Pantry (pared compartida, planta en L)
               ServiceCorridor ──escalera de servicio──▶ Cellar
SÓTANO         Cellar (desembarco) ─ Laundry / Electric / Boiler / Storage
               Storage: hueco bajo los cimientos como extensión baja a su derecha (muro ★T4)
ESPECIAL       Closet ★C5 ▶ Impossible ─▶ Foyer ─▶ puerta principal ─▶ «Fin del capítulo I»
```
Pasillo (x): Kid 70, Bath 200, Mom 330, Closet 460, Study 590 (cerrada), escalera 720, trampilla 900.
Única conexión entre plantas: escalera principal (Hall↔Foyer), de servicio (ServiceCorridor↔Cellar), trampilla (Hall↔Roof).
Se eliminaron las puertas antiguas Hall→Cocina/Comedor/Lavandería/Sótano (la intro existente sigue funcionando, pero ahora
la cocina se alcanza caminando por la planta baja).

## Recorrido físico
A) Kid (despertar, D01) → Bath (fragmento del espejo) → Mom, Hall, Closet (N3, N4, T2, T3, prepara C2).
B) Escalera → Foyer → Living → Dining (N1) → Kitchen (D03, D13, vaso) → Pantry (T1) → C1 en la pared Living|Pantry.
C) **C3**: en la cocina se llena el vaso (queda en las MANOS, inventario `WATER_GLASS`); se sube andando al baño familiar; se deja
   en el lavabo; se observa el reflejo en NORMAL y la figura en TRAUMA (`obs_c3_normal`+`obs_c3_trauma` → `obs_C3`). Persiste al
   cambiar de mundo y al recorrer la casa.
D) Mom: N2 (requiere haber leído D03) → carta A. Study (tras C2): carta B, C4.
E) Cocina → ServiceCorridor → escalera de servicio → Cellar: Electric (N5, luz fija del distribuidor), Boiler (T4 abre el muro del
   hueco), Storage: dentro del hueco, C3 exige T4 + la observación del baño → arandela.
F) Escalera → Hall → trampilla → Roof (T5, C5 con luz del distribuidor vista en NORMAL) → Closet: puerta sin marco → Impossible →
   Foyer → puerta principal.

## Qué cambió (archivos)
`scene/ChapterHouse.kt` (reescrito), `world/ChapterProps.kt` (nuevo: mobiliario y animaciones), `chapter/*` (flags del vaso, N2
requiere D03, C3, textos de C5), `scene/Scene.kt` (NarrativeAware antes de reunir sólidos; frase «Esta pastilla sabe feo» añadida al
mensaje de fin de la medicina), `render/WorldRenderer.kt` (`animTime`), `ChapterDirector` (refresca objetos de historia en cada hito).

## Arte y animación añadidos
Sofá, sillón, mesa de centro, televisor, bañera, toallero, estantes de despensa, escaleras, cubo y fregona, escritorio, ladrillo
de caldera con manómetro, caja de fusibles, tuberías, válvulas, herramientas, tanque, chimenea, antena con tres brazos y base,
parapeto, ventana imposible. Animaciones: cortinas mecidas (`SwayProp`), abrigos, papeles que tiemblan, tuberías que vibran,
goteo por fotogramas (`FramesProp`). Los seis estados visuales siguen siendo capas sobre este mismo mapa.

## Conservado
15 puzles (soluciones y piezas iguales; solo cambian dependencias de N2 y C3), 22 documentos, espejo, micro-sustos, seis estados.

## SIN verificar / pendiente
- Compilación y tests; coordenadas de puertas/objetos (solapes visuales en Hall, Kitchen y Cellar ampliadas).
- Navegación de la criatura por escaleras y pasillos nuevos (reutiliza conectores existentes; no probado).
- Variantes TRAUMA deformadas de los muebles nuevos: hoy solo filtro de grises + grietas + los niveles de `ChapterRenderer`.
- Inspección cercana específica de los objetos nuevos y animación propia de colocar el vaso / manipular antena: NO hechas.
- La intro original (agua para mamá, etc.) ahora exige caminar por Foyer→Living→Dining→Kitchen: revisar su ritmo.
