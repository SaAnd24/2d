# Reestructuración v0.18.0 — Estilo Fran Bow (puesta en escena por capas)

**Versión:** 0.18.0 (versionCode 18) · **Base:** v0.17.4 · **Fecha:** 2026-11-06

## 1. Resumen

v0.18 no es un mapa nuevo ni un sistema de profundidad nuevo: es **puesta en escena**.
Sobre el juego v0.17.4, tal cual, cada habitación se compone ahora en tres capas
—FONDO (muro, ventanas, cuadros), MEDIO (la línea por donde camina el niño, muebles
e interactuables) y PRIMER PLANO (objetos de enmarque que tapan parcialmente al niño
al pasar por detrás)—, con suelo en perspectiva pintada y parallax propio del primer
plano. Encima, dos cambios de jugabilidad que Santiago pidió tras probar la v0.17.4:
**joystick virtual** en lugar de los botones sueltos, y **sprite agachado de verdad**
en lugar del sprite de pie aplastado.

Lo que NO cambia: las mismas habitaciones, puertas, spawns, los 15 puzles con las
mismas soluciones, la historia, el guardado y el estilo pixel art + crayón sobre
papel. Ningún test se debilitó: 341 tests `@Test` (317 de v0.17.4 + 10 nuevos del
agachado + 14 nuevos del joystick).

## 2. Dirección: Fran Bow, no 3D

### El pivote (leer antes de tocar este código)

La v0.18 empezó como un plano 3D estilo **Don't Starve**: banda de suelo más alta,
muebles con rango de profundidad propio, colisión por delante/detrás, interacciones
y patrulla de la criatura en profundidad, orden de pintado por `sortByDepth`.
**Ese plan se canceló por decisión de Santiago** ("deshagamos la idea del 3d, coge
nuestro [juego]") y se revirtió por completo a la base v0.17.4 antes de hacer el
trabajo nuevo. No queda código a medias de ese plan: `FLOOR_BAND_HEIGHT` sigue en
26 px, el span de escala sigue en 0.30 (0.82–1.12), los muebles siguen bloqueando
toda la banda en X y `Scene.render` no ordena por profundidad. La simulación
`front_d_sims/sim_depth.py` se reescribió en la integración para verificar el
contrato nuevo (profundidad sutil de v0.17 mantenida + orden por capas) en lugar
del contrato cancelado.

### Referencias: Don't Starve + Fran Bow

**De Don't Starve se tomó la idea de partida, no el sistema.** Don't Starve es un
mundo 3D-ish con sprites 2D sobre un plano por el que el personaje se mueve en
profundidad de verdad. Esa era la dirección inicial de v0.18 (movimiento en
profundidad con función de juego: pasar por delante/detrás de los muebles,
esconderse en profundidad). Se canceló: el juego es lateral, la banda es de 26 px
y convertirlo en un plano 3D habría exigido rehacer colisiones, interacciones,
patrulla y los 15 puzles. Lo único que sobrevive de esa fase es el diagnóstico
de lo que estaba mal en v0.17.4 (escala 0.82–1.12, cámara ±3 px, muebles sin
profundidad) y la decisión de no exagerar la profundidad.

**De Fran Bow se tomó la puesta en escena.** Fran Bow (Killmonday, 2015) es en
realidad un point-and-click 2D dibujado a mano, no un juego 3D: su "profundidad"
es escenografía, no movimiento. De él se copian cuatro cosas:

1. **Composición por capas en cada habitación**: fondo pintado, línea de juego
   en el medio y marcos de primer plano que enmarcan la escena y ocultan
   parcialmente al personaje (una cortina, un perchero, una planta en la esquina).
2. **Perspectiva pintada en el suelo**: las juntas del suelo convergen hacia un
   punto de fuga; el suelo se oscurece junto al muro y se aclara hacia el
   espectador. Es pintura, no geometría.
3. **Parallax sutil entre capas**: el primer plano se mueve un 2% más rápido que
   el mundo (está más cerca de la cámara); el muro, más despacio.
4. **Doble realidad**: Fran Bow tiene el mundo normal y la Ultrareality. MYMom
   ya la tenía desde antes: el espejo NORMAL/TRAUMA (`ChapterDirector`, espejo
   que alterna `WorldMode.NORMAL` / `WorldMode.TRAUMA`, con puzles y micro-sustos
   propios de cada mundo, como `got_letter_b` en el estudio TRAUMA). v0.18 no la
   crea: la deja como está y la reconoce como el equivalente del doble mundo.

**Lo que NO se copió de Fran Bow:** no es point-and-click (el niño se mueve con
joystick, no se hace clic para andar); la profundidad no es solo visual decorativa
sin más —el primer plano tapa al niño de verdad y eso se puede usar para esconderse
a la vista—; y no se redibujó nada a mano: todo sigue generado en código, pixel art
+ crayón sobre papel, 320x180, 100% offline.

### La profundidad sutil de v0.17 se mantiene

El niño sigue moviéndose en profundidad dentro de la banda de 26 px (teclas o
joystick vertical), con escala 0.82–1.12 y velocidad `DEPTH_SPEED = 0.55`. Es
sutil a propósito: sirve para esquivar un poco y para que el sprite cambie de
tamaño, no para recorrer un plano. El matiz importante está en la sección 3.4.

## 3. Frente A — Escenarios estilo Fran Bow

### 3.1 Orden de pintado por capas (`scene/Scene.kt`, `render/WorldRenderer.kt`)

`Scene.render` pinta en este orden, fijo:

```
fondo (drawBackdropDepth) → backObjects → midObjects → criatura → jugador → frontObjects
```

El bucle de `frontObjects` va dentro de `WorldRenderer.shiftLayer(dx)` con
`dx = -camera.snappedX * 0.02f` (parallax del 2%) y usa margen de visibilidad de
16 px (`camera.isVisible(o, 16f)`) para que el desplazamiento no haga aparecer o
desaparecer un marco de golpe en el borde. La clasificación no cambió:
`layer < OBJECT` → fondo, `layer == OBJECT` → medio, resto → primer plano.
`shiftLayer` solo desplaza el dibujo: zonas de interacción y colisión siguen en
coordenadas del mundo, sin tocar. Ningún interactuable se movió, eliminó ni añadió
(0 movidos; 93 extraídos por regex y comparados con la base v0.17.4).

### 3.2 Marcos de primer plano por habitación

13 habitaciones ganan marcos nuevos en v0.18; la habitación de mamá ya tenía la
lluvia de la ventana en primer plano desde v0.17.4. En total **14 de 19 habitaciones
tienen algún elemento de primer plano**; 5 no tienen (ver abajo).

| Habitación | Marco(s) de primer plano | Nota |
|---|---|---|
| Hall (pasillo) | perchero x20, paragüeros x560 y x904 | enmarcan los extremos y la mitad del pasillo |
| Kid (dormitorio del niño) | — | sin marco; cortinas cortas (papeles d16/d19 en el suelo bajo la ventana) |
| Bathroom (baño) | — | habitación pequeña, composición stark |
| Mom (dormitorio de mamá) | lluvia de la ventana | ya era primer plano en v0.17.4 (`WindowRainOverlay`) |
| Laundry (lavandería) | cesta x290 | movida de x152 al extremo derecho |
| Kitchen (cocina) | silla verde x404; cubo de fregona x430 (variante capítulo) | silla arrimada al extremo de la mesa |
| Dining (comedor) | planta x396 | extremo derecho |
| Cellar (bodega) | barril x68 | movido de x262, junto a la puerta |
| Foyer (vestíbulo) | perchero x110, paragüero x136, cubo x760 | |
| Living (sala) | cortinas largas x320 (menta) | hasta el suelo, ver 3.3 |
| Pantry (despensa) | estantería pequeña x212 | la grande, junto a la puerta, queda en el medio |
| ServiceBath (baño de servicio) | váter x150 | |
| Study (estudio) | cortinas largas x96 (lila) | hasta el suelo, ver 3.3 |
| Closet (armario) | escalera plegable x440 | movida de x70 al extremo derecho |
| Electric (cuarto eléctrico) | — | habitación de servicio, composición stark |
| Boiler (caldera) | — | habitación de servicio, composición stark |
| Storage (almacén) | barril x330 | movido de x250, junto a la entrada del hueco |
| Roof (azotea) | chimenea x366 | |
| Impossible (habitación imposible) | — | habitación especial, composición stark |

Decoración movida sin cambiar de capa (solo composición): dibujo del niño en el
pasillo 650→662 (con su zona de examen `ex_hall_house_drawing`), alfombra del
pasillo 104→130 (centrada bajo la cama), alfombra de la sala 400→380 (centrada).

**Corrección al informe del Frente A:** ese informe decía "16 de 19 habitaciones
con marco, sin marco: Bathroom, Electric, Boiler, Impossible". Verificado en
código en la integración, el dormitorio del niño **tampoco** tiene marco (su
ventana tiene cortinas cortas en DECOR y ningún objeto en FOREGROUND): son
**14 de 19**, y las 5 sin marco son Kid, Bathroom, Electric, Boiler e Impossible.
No es un error grave —el Kid es la habitación inicial, casi vacía, con los papeles
en el suelo— pero queda registrado así para no prometer un marco que no existe.

### 3.3 Cortinas largas (`world/ChapterProps.kt`)

`curtainedWindow(..., long = false)` por defecto, como siempre. Con `long = true`
las cortinas llegan hasta el suelo (`curtainH = F - y - 4`) y van en `Layer.FOREGROUND`:
enmarcan la ventana y tapan al niño cuando pasa por detrás. Solo en **Study y
Living**. El dormitorio del niño sigue con cortinas cortas: tiene los papeles
d16 y d19 en el suelo bajo la ventana y la cortina larga los taparía. En el estudio
el papel d14b solo pierde ~7 px de 22 bajo la cortina (sigue leyéndose, como un
papel medio escondido).

### 3.4 MATIZ: el primer plano es por CAPA, no por profundidad

Esto es lo más fácil de malinterpretar de v0.18, así que va en grande: **el marco
tapa al niño también a depth 1.0** (lo más cerca de la cámara). El primer plano se
dibuja siempre después del jugador, sin mirar su profundidad. Es puesta en escena
(Fran Bow), no el sistema de profundidad cancelado: pasar por detrás de una
cortina o de un mueble te oculta a la vista, pero no es "estar detrás en
profundidad" en el sentido del plan Don't Starve (que habría exigido colisión e
interacción en profundidad). Si algún día se retoma ese plan, este matiz es el
primer párrafo a releer.

### 3.5 Suelo en fuga (`draw/BackdropBuilder.kt`)

- Sombra suave al pie del muro (sobre el rodapié) y suelo oscurecido junto al muro
  que se aclara hacia el espectador: la banda deja de ser plana.
- Juntas de madera: las horizontales ya no son equidistantes (se juntan hacia el
  muro, se separan hacia el espectador); las verticales se inclinan hacia el punto
  de fuga (centro de la habitación, sobre la línea del muro; inclinación máxima
  suave, ~1.5 px en madera y ~3 px en baldosa).
- Baldosas: dos filas de distinta altura (12 px la de atrás, el resto la de
  delante) con el mismo efecto de fuga.

Todo pintado, todo en código, sin assets nuevos.

## 4. Frente B — Joystick virtual

`input/InputController.kt` reescrito; HUD en `render/BaseRenderer.kt`
(`drawJoystick`, `drawSneakButton`, `drawCrouchButton`).

- **Joystick fijo** abajo a la izquierda, centro (46, 140), base r=26, captura
  r=36, zona muerta 0.15. `moveX`/`moveY` continuos en [-1, 1], velocidad lineal
  tras la zona muerta, diagonal real (antes solo había ◀ ▶ y ▲▼ diminutos).
- **Botones derechos:** SIGILO alternar (208, 122), AGACHARSE mantener (208, 160),
  CORRER mantener (250, 158), ACCIÓN grande (296, 158).
- **Eliminado el ciclo de modo de la esquina** (ANDAR→SIGILO→AGACHADO): `cycleModeToggle`
  borrado. La tecla C ahora es **mantener** (antes alternaba); sigilo se alterna con
  el botón, V o `setModeToggle`.
- La zona de ACCIÓN ahora exige `y >= 140` (antes `y >= 100` con `x >= 272`); ningún
  test viejo tocaba esa franja. `setDirection`/`setDepthInput`/`setRunHeld`/
  `setModeToggle` se conservan para los tests y mandos.
- 14 tests nuevos en `JoystickInputTest.kt`; 2 tests actualizados en
  `DepthMovementTest.kt` (sin debilitar).

## 5. Frente C — Sprite agachado de verdad

- 9 poses nuevas en `PixelPose` (al final del enum, sin mover ordinales):
  `CROUCH_IDLE`, `CROUCH_WALK_1/2/3`, `SNEAK_WALK_1/2`, `RUN_1/2/3` — 22 poses
  en total. `SpriteData.kt` regenerado con `emit_kotlin.py`; el generador
  (`tools/sprite_gen/protagonist.py`) dibuja rodillas dobladas y cuerpo bajo.
- `Player.pose` devuelve las poses según el modo: agachado (quieto o andando),
  sigilo (medio agachado, 2 frames) y correr (zancada larga, 3 frames). Quieto en
  sigilo o corriendo no hay pose propia: se está de pie (`IDLE`).
- **El squash x0.72 está eliminado:** `visualHeightScale` es siempre 1
  (`WorldRenderer.drawPlayer` y `drawPaperEffects` ya no lo aplican). La caja de
  colisión sigue en 18x48 en todos los modos. Vista previa en
  `docs/crouch_preview.png` (y generador de la vista previa en
  `tools/sprite_gen/preview_crouch.py`).
- 10 tests nuevos en `CrouchPoseTest.kt`; 1 test actualizado en
  `DepthMovementTest.kt` (`agachadoUsaPoseRealSinAplastar`).
- **Hueco conocido:** no hay variantes `HOLD_CROUCH_*`: agachado con un objeto en
  la mano, la pose agachada manda y el objeto no se dibuja (sigue en el inventario).
  Decisión del Frente C, documentada en el test
  `agachadoConObjetoMantieneLaPoseAgachada`.
- La cadencia de pasos sigue en `STEP_TIME` 0.15 s en todos los modos (sin
  variación por modo; posible ajuste futuro, no hecho en v0.18).

### Decisión de integración: `GameConfig.CROUCH_HEIGHT_SCALE`

La constante (0.72f) **se conserva como legado, documentada**. Ya nada del juego
la usa para dibujar, pero `CrouchPoseTest.visualHeightScaleEsUnoSiempre` la
referencia como el valor antiguo para afirmar que la escala visual ya no es ese
valor; borrarla obligaría a editar ese test para poner el literal 0.72f, sin
ganancia. Su KDoc ahora dice explícitamente que es legado sin uso desde v0.18 y
que no se borre sin actualizar ese test.

## 6. Integración (qué chocaba y qué se hizo)

| Archivo | A (Fran Bow) | B (joystick) | C (agachado) | Resolución |
|---|---|---|---|---|
| `render/WorldRenderer.kt` | solo añadió `shiftLayer` | — | `drawPlayer`/`drawPaperEffects` sin squash | Sin conflicto: ambos cambios presentes y coherentes |
| `scene/Scene.kt` | solo el bucle `frontObjects` con parallax 2% y margen 16 px | — | — | Sin conflicto; `findFocus`/`isFocusAction` (fix v0.17.4) intactos |
| `world/Player.kt` | — | — | `pose` + `visualHeightScale = 1` | Solo C |
| `input/InputController.kt` | — | reescrito | — | Solo B |
| `core/GameConfig.kt` | — | constantes joystick | `CROUCH_HEIGHT_SCALE` legado | Solo el KDoc de legado (integración) |
| `scene/HouseDefinition.kt`, `scene/ChapterHouse.kt` | marcos FRONT + 5 reposiciones | — | — | Solo A |
| `world/ChapterProps.kt` | `curtainedWindow(..., long)` | — | — | Solo A |
| `draw/BackdropBuilder.kt` | suelo en fuga | — | — | Solo A |
| `pixel/PixelCharacter.kt`, `pixel/SpriteData.kt` | — | — | 9 poses nuevas | Solo C |
| `render/BaseRenderer.kt` | — | HUD joystick/botones | — | Solo B |
| `tools/sprite_gen/protagonist.py` | — | — | rodillas dobladas | Solo C |

Verificación de la reversión del plan Don't Starve: `diff -r` de la copia contra
la base v0.17.4 muestra **solo** los archivos de la tabla (más los 2 tests nuevos
y `docs/crouch_preview.png`). `depthBlockedAt`, `DepthAware` y `sortByDepth`
existen con los mismos conteos en la base: son de v0.17, no restos del plan
cancelado. `FLOOR_BAND_HEIGHT` = 26f en ambas.

## 7. Verificación (sin Gradle; la VM no tiene Java/Gradle/Android SDK)

Simulaciones Python, todas en verde tras la integración:

- `front_d_sims/run_all.py` — **TODAS PASAN**:
  - `sim_depth.py` (reescrita en la integración al contrato Fran Bow: escala
    0.82–1.12, banda 26 px, orden de pintado por capas leído de `Scene.render`,
    sin `sortByDepth`, sin rango de profundidad por mueble) — 13 comprobaciones.
  - `sim_focus.py` — 13/13: los 11 escenarios de foco de v0.17.4 (mamá, Ranita,
    documento de finanzas vs ventana de cocina, puerta del baño, cruzar ventanas,
    prioridad, distancia a zona, desempate por centro) siguen igual.
  - `sim_joystick.py` — 64/64: zona muerta, magnitud proporcional, diagonal,
    botones y zonas.
  - `sim_poses.py` — 46/46: poses CROUCH/SNEAK/RUN, sin squash, caja 18x48,
    preview presente.
- `front_a_sims/franbow_sims.py` — **TODO OK** (~70 comprobaciones en 6 grupos):
  orden de pintado por capas, oclusión real de los 20 objetos FRONT (solapan el
  rect 18x48 del niño; oclusión parcial —la cabeza sigue visible— en los bajos),
  interactuables intactos (misma X que v0.17.4), suelo en fuga, parallax máximo
  por habitación < 16 px (peor caso Hall/Foyer: 13.2 px), cortinas largas solo
  en Study y Living, Kid con cortinas cortas.
- Conteos: **341 tests `@Test`** (317 + 10 + 14). Archivos Kotlin: 163.
- Prueba de fuego: `ChapterTest.theWholeChapterIsSolvableFromScratch` (15 puzles
  desde cero) no se tocó y ningún interactuable cambió de X: su verificación real
  es GitHub Actions (abajo).

## 8. Qué queda para GitHub Actions (verificación real, no simulada)

`assembleDebug` + `testDebugUnitTest`, objetivo **341/341**. Riesgos señalados
por el Frente A, a vigilar en los logs:

- `EngineTest.sameSeedSameHouse` y `seedNeverChangesStructure`: `visualFingerprint`
  cambia al añadir operaciones de fondo (suelo en fuga, sombras). Si fallan, es
  por el fingerprint, no por la casa: habrá que actualizar el valor esperado, no
  la casa.
- `ChapterTest.theOriginalHouseIsUntouched`: la casa base ganó marcos y
  reposiciones de decoración; si este test compara la casa original al detalle,
  puede quejarse de los cambios intencionados de v0.18.
- `EngineTest.theHouseLightsReachThePlayer`: luces; no tocadas en v0.18, pero
  vigilar por si el cambio de fondo afecta al cálculo.
- Los 341 tests no se compilaron en local (sin Gradle en la VM): la primera
  compilación real es GitHub Actions.

## 9. Qué queda para la prueba en el celular de Santiago

Recorrido sugerido:

1. Entrar a un cuarto y ver la composición con marco de primer plano (p. ej. el
   pasillo con el perchero, o la sala con las cortinas largas).
2. Pasar por detrás de una cortina larga (Study/Living) o de un mueble con marco
   (barril de la bodega, planta del comedor) y quedar tapado —la cabeza sigue
   visible en los marcos bajos—.
3. Agacharse (mantener el botón AGACHARSE) y ver la animación real: rodillas
   dobladas, cuerpo bajo, 3 frames al andar; sin aplastamiento.
4. Cruzar en diagonal con el joystick (abajo a la izquierda) y comprobar que la
   velocidad es proporcional al empuje y que la zona muerta no hace temblar al niño.
5. Probar sigilo (alternar) y correr (mantener) con sus poses propias.

Huecos conocidos a mirar con ojos críticos: agachado con objeto en la mano no
dibuja el objeto (sección 5); el primer plano tapa al niño también a depth 1.0
(sección 3.4, es intencionado); la cadencia de pasos es la misma en todos los
modos.
