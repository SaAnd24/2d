"""Vista previa del agachado v0.18: niño de pie, agachado quieto, ciclo de caminar
agachado, sigilo y correr, con la cara compuesta (ojos abiertos, boca neutra) como
la dibuja el juego (PixelRasterizer.composeIndices).

Uso:  python3 preview_crouch.py        (desde tools/sprite_gen)
Salida: ../../docs/crouch_preview.png
"""
import os
import numpy as np
from PIL import Image, ImageDraw
import protagonist as pr
import face
from pixlib import PALETTE

OUT = os.path.join(os.path.dirname(__file__), '..', '..', 'docs', 'crouch_preview.png')
NAMES = ['IDLE', 'CROUCH_IDLE', 'CROUCH_WALK_1', 'CROUCH_WALK_2', 'CROUCH_WALK_3',
         'SNEAK_WALK_1', 'RUN_1']
SCALE = 4
BG = (236, 226, 200, 255)
GROUND = (120, 100, 70, 255)


def compose(name):
    """Matriz de índices con base + mano delantera + cara (igual que el juego)."""
    cv, info = pr.build(pr.POSES[name])
    base, fg = pr.split_front_hand(cv, info, pr.POSES[name])
    a = base.copy()
    if fg is not None:
        a = np.where(fg != 0, fg, base)
    hx, hy = info['head']
    for ox, oy, patch in (face.eye_patch('OPEN'), face.mouth_patch('NEUTRAL')):
        h, w = patch.shape
        for j in range(h):
            for i in range(w):
                v = patch[j, i]
                if v:
                    x, y = hx + ox + i, hy + oy + j
                    if 0 <= x < pr.W and 0 <= y < pr.H:
                        a[y, x] = v
    return a


def to_image(a, scale):
    arr = np.zeros((a.shape[0], a.shape[1], 4), dtype=np.uint8)
    for i, c in enumerate(PALETTE):
        arr[a == i] = c
    im = Image.fromarray(arr, 'RGBA')
    base = Image.new('RGBA', im.size, BG)
    base.alpha_composite(im)
    return base.resize((a.shape[1] * scale, a.shape[0] * scale), Image.NEAREST)


def main():
    ims = [to_image(compose(n), SCALE) for n in NAMES]
    pad = 16
    label_h = 22
    w = sum(i.width for i in ims) + pad * (len(ims) + 1)
    h = max(i.height for i in ims) + label_h + pad
    sheet = Image.new('RGBA', (w, h), BG)
    d = ImageDraw.Draw(sheet)
    x = pad
    for name, im in zip(NAMES, ims):
        y = h - label_h - im.height
        sheet.paste(im, (x, y))
        # línea de suelo (los pies quedan en la fila 127 del sprite)
        gy = y + (pr.H - 1) * SCALE
        d.line([(x - 4, gy), (x + im.width + 4, gy)], fill=GROUND, width=2)
        d.text((x, h - label_h + 4), name, fill=(43, 26, 34, 255))
        x += im.width + pad
    sheet.save(OUT)
    print('escrito', os.path.abspath(OUT), sheet.size)


if __name__ == '__main__':
    main()
