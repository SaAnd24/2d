package com.terror2d

import android.view.KeyEvent
import com.terror2d.core.MoveMode
import com.terror2d.input.InputController
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sqrt

/**
 * Joystick virtual + botones de modo (v0.18): el joystick fijo abajo a la izquierda sustituye a
 * los botones discretos ◀ ▶ y ▲ ▼; AGACHARSE es MANTENER y SIGILO alterna con su propio botón.
 * El ciclo de modo de la esquina superior izquierda (ANDAR -> SIGILO -> AGACHADO) se eliminó.
 *
 * Geometría (coordenadas lógicas 320x180): joystick en (46, 140), radio de palanca 26, captura 36,
 * zona muerta 0.15. Velocidad proporcional al empuje: lineal de 0 en el borde de la zona muerta
 * a 1 en el radio máximo.
 */
class JoystickInputTest {

    private val cx = InputController.JOYSTICK_X
    private val cy = InputController.JOYSTICK_Y
    private val r = InputController.JOYSTICK_BASE_RADIUS
    private val dz = InputController.JOYSTICK_DEADZONE

    /** Empuje esperado tras la zona muerta: 0 en el borde, 1 a tope (lineal). */
    private fun empuje(fraccionRadio: Float): Float =
        ((fraccionRadio - dz) / (1f - dz)).coerceIn(0f, 1f)

    @Test fun elJoystickMueveEnDiagonalReal() {
        val input = InputController()
        // diagonal a tope (45°): X y profundidad a la vez, magnitud 1
        val d = r / sqrt(2f)
        input.touchDown(1, cx + d, cy + d)
        assertTrue(input.joystickActive)
        assertEquals(1f / sqrt(2f), input.moveX, 0.001f)
        assertEquals(1f / sqrt(2f), input.moveY, 0.001f)
        // diagonal suave (la mitad del radio, 45°): misma dirección, menos velocidad
        input.touchMove(1, cx + d / 2f, cy + d / 2f)
        val e = empuje(0.5f) / sqrt(2f)
        assertEquals(e, input.moveX, 0.001f)
        assertEquals(e, input.moveY, 0.001f)
        input.touchUp(1)
        assertFalse(input.joystickActive)
        assertEquals(0f, input.moveX, 0.001f)
        assertEquals(0f, input.moveY, 0.001f)
    }

    @Test fun elJoystickDistingueFondoYPrimerPlano() {
        val input = InputController()
        input.touchDown(1, cx, cy - r) // arriba del todo = hacia el fondo (lejos)
        assertEquals(0f, input.moveX, 0.001f)
        assertEquals(-1f, input.moveY, 0.001f)
        input.touchMove(1, cx, cy + r) // abajo del todo = hacia el primer plano (cerca)
        assertEquals(0f, input.moveX, 0.001f)
        assertEquals(1f, input.moveY, 0.001f)
        input.touchMove(1, cx - r, cy) // izquierda a tope, sin profundidad
        assertEquals(-1f, input.moveX, 0.001f)
        assertEquals(0f, input.moveY, 0.001f)
        input.touchUp(1)
    }

    @Test fun laZonaMuertaIgnoraElTemblorDelPulgar() {
        val input = InputController()
        // 3 px de 26 = 0.115 < 0.15: el niño no se mueve
        input.touchDown(1, cx + 3f, cy)
        assertTrue(input.joystickActive) // el pulgar está apoyado, pero no hay movimiento
        assertEquals(0f, input.moveX, 0.001f)
        assertEquals(0f, input.moveY, 0.001f)
        // justo por encima de la zona muerta (5 px = 0.192) ya hay un empuje pequeño, no un salto
        input.touchMove(1, cx + 5f, cy)
        assertEquals(empuje(5f / r), input.moveX, 0.001f)
        assertTrue(input.moveX > 0f && input.moveX < 0.1f)
        input.touchUp(1)
        assertEquals(0f, input.moveX, 0.001f)
    }

    @Test fun laVelocidadEsProporcionalAlEmpuje() {
        val input = InputController()
        input.touchDown(1, cx + r * 0.25f, cy) // empuje al 25% del radio
        assertEquals(empuje(0.25f), input.moveX, 0.001f)
        input.touchMove(1, cx + r * 0.5f, cy) // al 50%
        assertEquals(empuje(0.5f), input.moveX, 0.001f)
        input.touchMove(1, cx + r * 0.75f, cy) // al 75%
        assertEquals(empuje(0.75f), input.moveX, 0.001f)
        input.touchMove(1, cx + r, cy) // a tope
        assertEquals(1f, input.moveX, 0.001f)
        // más allá del radio máximo la velocidad ya no sube (la palanca queda en el borde)
        input.touchMove(1, cx + r * 2f, cy)
        assertEquals(1f, input.moveX, 0.001f)
        assertEquals(0f, input.moveY, 0.001f)
        input.touchUp(1)
    }

    @Test fun elJoystickSoloSeAgarraDentroDeSuZonaDeCaptura() {
        val input = InputController()
        // (150, 150) está lejos del joystick: no se agarra, no hay movimiento
        input.touchDown(1, 150f, 150f)
        assertFalse(input.joystickActive)
        assertEquals(0f, input.moveX, 0.001f)
        assertEquals(0f, input.moveY, 0.001f)
        input.touchUp(1)
        // justo en el borde de captura (36 px del centro) sí se agarra
        input.touchDown(1, cx + InputController.JOYSTICK_CAPTURE_RADIUS, cy)
        assertTrue(input.joystickActive)
        assertEquals(1f, input.moveX, 0.001f)
        input.touchUp(1)
    }

    @Test fun elJoystickSigueAlPulgarAunqueSeDesliceFueraDeLaBase() {
        val input = InputController()
        input.touchDown(1, cx, cy)
        assertEquals(0f, input.moveX, 0.001f)
        // el pulgar se desliza fuera de la base (a 40 px, más allá del radio 26): sigue mandando
        input.touchMove(1, cx + 40f, cy)
        assertEquals(1f, input.moveX, 0.001f)
        assertEquals(0f, input.moveY, 0.001f)
        input.touchUp(1)
        assertEquals(0f, input.moveX, 0.001f)
    }

    @Test fun agacharseSoloMientrasSeMantienePulsado() {
        val input = InputController()
        // botón AGACHARSE (táctil): mantener = agachado, soltar = levantarse
        input.touchDown(1, InputController.CROUCH_X, InputController.CROUCH_Y)
        assertTrue(input.crouchOn)
        assertEquals(MoveMode.CROUCH, input.requestedMode)
        input.touchUp(1)
        assertFalse(input.crouchOn)
        assertEquals(MoveMode.WALK, input.requestedMode)
        // tecla C: igual, MANTENER (v0.18 ya no alterna)
        assertTrue(input.onKey(KeyEvent.KEYCODE_C, true))
        assertEquals(MoveMode.CROUCH, input.requestedMode)
        input.onKey(KeyEvent.KEYCODE_C, false)
        assertEquals(MoveMode.WALK, input.requestedMode)
    }

    @Test fun elSigiloAlternaConSuBotonYConLaTeclaV() {
        val input = InputController()
        input.touchDown(1, InputController.SNEAK_X, InputController.SNEAK_Y)
        assertEquals(MoveMode.SNEAK, input.requestedMode)
        input.touchUp(1)
        assertEquals(MoveMode.SNEAK, input.requestedMode) // alternar: sigue al soltar
        input.touchDown(1, InputController.SNEAK_X, InputController.SNEAK_Y)
        assertEquals(MoveMode.WALK, input.requestedMode)
        input.touchUp(1)
        // la tecla V sigue alternando
        assertTrue(input.onKey(KeyEvent.KEYCODE_V, true))
        assertEquals(MoveMode.SNEAK, input.requestedMode)
        input.onKey(KeyEvent.KEYCODE_V, false)
        assertTrue(input.onKey(KeyEvent.KEYCODE_V, true))
        assertEquals(MoveMode.WALK, input.requestedMode)
        input.onKey(KeyEvent.KEYCODE_V, false)
    }

    @Test fun agachadoMandaSobreSigiloYCorrer() {
        val input = InputController()
        input.touchDown(1, InputController.SNEAK_X, InputController.SNEAK_Y)
        input.touchUp(1)
        assertEquals(MoveMode.SNEAK, input.requestedMode)
        input.touchDown(2, InputController.CROUCH_X, InputController.CROUCH_Y)
        assertEquals(MoveMode.CROUCH, input.requestedMode) // agachado manda sobre sigilo
        input.setRunHeld(true)
        assertEquals(MoveMode.CROUCH, input.requestedMode) // ... y sobre correr
        input.touchUp(2)
        input.setRunHeld(false)
        assertEquals(MoveMode.SNEAK, input.requestedMode) // al levantarse vuelve el sigilo
    }

    @Test fun dosDedosMuevenYCorrenALaVez() {
        val input = InputController()
        // pulgar izquierdo en el joystick (diagonal suave, magnitud 0.5) + pulgar derecho en CORRER
        val d = r * 0.5f / sqrt(2f)
        input.touchDown(1, cx + d, cy + d)
        input.touchDown(2, InputController.RUN_X, InputController.RUN_Y)
        assertTrue(input.runHeld)
        assertEquals(MoveMode.RUN, input.requestedMode)
        assertEquals(empuje(0.5f) / sqrt(2f), input.moveX, 0.001f)
        assertEquals(empuje(0.5f) / sqrt(2f), input.moveY, 0.001f)
        // soltar CORRER no suelta el joystick
        input.touchUp(2)
        assertFalse(input.runHeld)
        assertEquals(MoveMode.WALK, input.requestedMode)
        assertEquals(empuje(0.5f) / sqrt(2f), input.moveX, 0.001f)
        input.touchUp(1)
        assertEquals(0f, input.moveX, 0.001f)
    }

    @Test fun laEsquinaSuperiorIzquierdaYaNoCambiaElModo() {
        val input = InputController()
        // la vieja zona del botón de modo (x < 52, y < 48) hoy es del diario: tocarla no cicla nada
        input.touchDown(1, 24f, 22f)
        assertEquals(MoveMode.WALK, input.requestedMode)
        input.touchUp(1)
        input.touchDown(1, 24f, 22f)
        assertEquals(MoveMode.WALK, input.requestedMode)
        input.touchUp(1)
    }

    @Test fun elTecladoSigueMoviendoEnXyEnProfundidad() {
        val input = InputController()
        input.setDirection(false, true)
        assertEquals(1f, input.moveX, 0.001f)
        input.setDepthInput(true, false)
        assertEquals(-1f, input.moveY, 0.001f)
        input.setDirection(false, false)
        input.setDepthInput(false, false)
        // joystick a tope en diagonal: mismo recorrido que el teclado, pero continuo
        input.setJoystick(1f, 1f)
        assertEquals(1f / sqrt(2f), input.moveX, 0.001f)
        assertEquals(1f / sqrt(2f), input.moveY, 0.001f)
        // teclado + joystick se suman y se limitan a [-1, 1]: derecha (tecla) - izquierda (joystick) = 0
        input.setDirection(false, true)
        input.setJoystick(-1f, 0f)
        assertEquals(0f, input.moveX, 0.001f)
        assertEquals(0f, input.moveY, 0.001f)
        input.setJoystick(0f, 0f)
        input.setDirection(false, false)
        assertEquals(0f, input.moveX, 0.001f)
        assertEquals(0f, input.moveY, 0.001f)
    }

    @Test fun elBotonCorrerSigueSiendoMantener() {
        val input = InputController()
        input.touchDown(1, InputController.RUN_X, InputController.RUN_Y)
        assertTrue(input.runHeld)
        assertEquals(MoveMode.RUN, input.requestedMode)
        input.touchUp(1)
        assertFalse(input.runHeld)
        assertEquals(MoveMode.WALK, input.requestedMode)
    }

    @Test fun elJoystickNoFuncionaEnModoPuzleNiEnElArmario() {
        val input = InputController()
        input.puzzleMode = true
        input.touchDown(1, cx + r, cy)
        assertFalse(input.joystickActive)
        assertEquals(0f, input.moveX, 0.001f)
        input.touchUp(1)
        input.puzzleMode = false
        input.closetMode = true
        input.touchDown(1, cx + r, cy)
        assertFalse(input.joystickActive)
        assertEquals(0f, input.moveX, 0.001f)
        input.touchUp(1)
        input.closetMode = false
        input.touchDown(1, cx + r, cy)
        assertTrue(input.joystickActive)
        assertEquals(1f, input.moveX, 0.001f)
        input.touchUp(1)
    }
}
