package com.terror2d

import com.terror2d.core.GameConfig
import com.terror2d.core.MoveMode
import com.terror2d.pixel.PixelPose
import com.terror2d.pixel.PixelRasterizer
import com.terror2d.pixel.ProtagonistSprite
import com.terror2d.world.Player
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Agachado, sigilo y correr v0.18: son POSES DE VERDAD (dibujadas en el generador), no el sprite
 * de pie aplastado con `canvas.scale(s, s * 0.72)`. `Player.visualHeightScale` es siempre 1 y la
 * altura baja porque el DIBUJO es más bajo (piernas dobladas, cuerpo bajo, cabeza adelantada).
 * La caja de colisión (18x48) no cambia.
 */
class CrouchPoseTest {
    private val dt = 1f / 60f
    private val floorY = 150f

    private fun player(x: Float = 100f): Player = Player(x, floorY - Player.HEIGHT)

    private fun step(p: Player, seconds: Float, dirX: Float = 0f) {
        var t = 0f
        while (t < seconds) {
            p.update(dt, dirX, 0f, emptyList(), floorY, 0f, 1000f)
            t += dt
        }
    }

    /** Muestrea la pose cada 0.05 s mientras se mueve en un modo. */
    private fun posesWhileMoving(p: Player, seconds: Float, dirX: Float = 1f): List<PixelPose> {
        val out = ArrayList<PixelPose>()
        var t = 0f
        var next = 0f
        while (t < seconds) {
            p.update(dt, dirX, 0f, emptyList(), floorY, 0f, 1000f)
            t += dt
            if (t >= next) {
                out.add(p.pose)
                next += 0.05f
            }
        }
        return out
    }

    // ------------------------------------------------------------------ pose según el modo

    @Test fun agachadoQuietoEsCrouchIdleNuncaIdleConSquash() {
        val p = player()
        assertEquals(PixelPose.IDLE, p.pose)
        p.moveMode = MoveMode.CROUCH
        assertEquals(PixelPose.CROUCH_IDLE, p.pose)
        assertEquals(1f, p.visualHeightScale, 0.001f)
    }

    @Test fun agachadoMoviendoseUsaElCicloCrouchWalk() {
        val p = player()
        p.moveMode = MoveMode.CROUCH
        val seen = posesWhileMoving(p, 0.8f).toSet()
        assertTrue("falta CROUCH_WALK_1 en $seen", PixelPose.CROUCH_WALK_1 in seen)
        assertTrue("falta CROUCH_WALK_2 en $seen", PixelPose.CROUCH_WALK_2 in seen)
        assertTrue("falta CROUCH_WALK_3 en $seen", PixelPose.CROUCH_WALK_3 in seen)
        assertTrue("moviéndose agachado no sale IDLE/WALK", seen.none { it == PixelPose.IDLE || it == PixelPose.WALK_1 || it == PixelPose.WALK_2 || it == PixelPose.WALK_3 })
        assertEquals(1f, p.visualHeightScale, 0.001f)
    }

    @Test fun elCicloDeCaminarAgachadoAvanzaConAnimTime() {
        val p = player()
        p.moveMode = MoveMode.CROUCH
        val seq = posesWhileMoving(p, 0.8f)
        // el ciclo 1-2-3-2 tiene que cambiar de fotograma, no quedarse clavado en uno
        assertTrue("el ciclo agachado no avanza: $seq", seq.zipWithNext().any { (a, b) -> a != b })
        assertTrue(seq.size >= 3)
    }

    @Test fun alLevantarseVuelveAIdleYWalk() {
        val p = player()
        p.moveMode = MoveMode.CROUCH
        step(p, 0.4f, dirX = 1f)
        assertTrue(p.pose in setOf(PixelPose.CROUCH_WALK_1, PixelPose.CROUCH_WALK_2, PixelPose.CROUCH_WALK_3))
        p.moveMode = MoveMode.WALK
        step(p, 0.2f, dirX = 0f)
        assertEquals(PixelPose.IDLE, p.pose)
        step(p, 0.4f, dirX = 1f)
        assertTrue(p.pose in setOf(PixelPose.WALK_1, PixelPose.WALK_2, PixelPose.WALK_3))
    }

    @Test fun sigiloYCorrerTienenSusPropiasPoses() {
        val p = player()
        p.moveMode = MoveMode.SNEAK
        val sneak = posesWhileMoving(p, 0.8f).toSet()
        assertTrue("falta SNEAK_WALK_1 en $sneak", PixelPose.SNEAK_WALK_1 in sneak)
        assertTrue("falta SNEAK_WALK_2 en $sneak", PixelPose.SNEAK_WALK_2 in sneak)
        assertTrue(sneak.none { it == PixelPose.WALK_1 || it == PixelPose.WALK_2 || it == PixelPose.WALK_3 })
        p.moveMode = MoveMode.RUN
        val run = posesWhileMoving(p, 0.8f).toSet()
        assertTrue("falta RUN_1 en $run", PixelPose.RUN_1 in run)
        assertTrue("falta RUN_2 en $run", PixelPose.RUN_2 in run)
        assertTrue("falta RUN_3 en $run", PixelPose.RUN_3 in run)
        // quieto en sigilo o corriendo no hay pose propia: se está de pie
        p.moveMode = MoveMode.SNEAK
        step(p, 0.2f, dirX = 0f)
        assertEquals(PixelPose.IDLE, p.pose)
        p.moveMode = MoveMode.RUN
        step(p, 0.2f, dirX = 0f)
        assertEquals(PixelPose.IDLE, p.pose)
    }

    @Test fun visualHeightScaleEsUnoSiempre() {
        val p = player()
        for (mode in MoveMode.values()) {
            p.moveMode = mode
            assertEquals("visualHeightScale en $mode", 1f, p.visualHeightScale, 0.001f)
        }
        assertNotEquals(GameConfig.CROUCH_HEIGHT_SCALE, p.visualHeightScale, 0.001f)
    }

    @Test fun laCajaDeColisionNoCambiaAlAgacharse() {
        val p = player()
        assertEquals(18f, Player.WIDTH, 0.001f)
        assertEquals(48f, Player.HEIGHT, 0.001f)
        p.moveMode = MoveMode.CROUCH
        step(p, 0.4f, dirX = 1f)
        assertEquals(18f, p.width, 0.001f)
        assertEquals(48f, p.height, 0.001f)
    }

    @Test fun agachadoConObjetoMantieneLaPoseAgachada() {
        // No hay variante HOLD agachada: la pose agachada manda y el objeto no se dibuja
        // en la mano (esas poses no tienen punto de agarre); el objeto sigue en el inventario.
        val p = player()
        p.heldItemId = "frog_plush"
        p.moveMode = MoveMode.CROUCH
        assertEquals(PixelPose.CROUCH_IDLE, p.pose)
    }

    // ------------------------------------------------------------------ los datos del sprite

    @Test fun lasPosesNuevasExistenYDibujanDeVerdad() {
        val data = ProtagonistSprite.create()
        val nuevas = listOf(
            PixelPose.CROUCH_IDLE, PixelPose.CROUCH_WALK_1, PixelPose.CROUCH_WALK_2, PixelPose.CROUCH_WALK_3,
            PixelPose.SNEAK_WALK_1, PixelPose.SNEAK_WALK_2,
            PixelPose.RUN_1, PixelPose.RUN_2, PixelPose.RUN_3
        )
        for (pose in nuevas) {
            assertTrue("falta $pose", data.hasPose(pose))
            assertTrue("$pose sin píxeles", data.filledPixels(pose) > 500)
            assertEquals("el enum y los datos no coinciden en $pose",
                pose.name, com.terror2d.pixel.SpriteData.POSE_NAMES[pose.ordinal])
        }
        // todas distintas entre sí y de las viejas (salvo IDLE == FLASHBACK, que solo cambia la paleta)
        val hashes = HashSet<Long>()
        for (pose in PixelPose.values()) {
            if (pose == PixelPose.FLASHBACK) continue
            hashes.add(PixelRasterizer.hash(PixelRasterizer.rasterize(data, pose, false, null)))
        }
        assertEquals(PixelPose.values().size - 1, hashes.size)
    }

    @Test fun elDibujoAgachadoEsMasBajoConLaCabezaMasBajaYLosPiesEnElSuelo() {
        val data = ProtagonistSprite.create()
        val idle = data.visibleRows(PixelPose.IDLE)
        val idleH = idle[1] - idle[0] + 1
        val headIdle = data.face!!.head(PixelPose.IDLE)!!
        for (pose in listOf(PixelPose.CROUCH_IDLE, PixelPose.CROUCH_WALK_1, PixelPose.CROUCH_WALK_2, PixelPose.CROUCH_WALK_3)) {
            val rows = data.visibleRows(pose)
            val h = rows[1] - rows[0] + 1
            assertTrue("$pose no es más bajo que IDLE ($h vs $idleH)", h < idleH * 0.9f)
            assertEquals("$pose no apoya los pies en el suelo", data.height - 1, rows[1])
            val head = data.face!!.head(pose)!!
            assertTrue("la cabeza de $pose no baja (y=${head[1]} vs ${headIdle[1]})", head[1] > headIdle[1] + 10)
            assertTrue("la cabeza de $pose no se adelanta (x=${head[0]} vs ${headIdle[0]})", head[0] > headIdle[0])
        }
        // sigilo: medio camino entre de pie y agachado
        val sneak = data.visibleRows(PixelPose.SNEAK_WALK_1)
        val sneakH = sneak[1] - sneak[0] + 1
        val crouchH = data.visibleRows(PixelPose.CROUCH_IDLE).let { it[1] - it[0] + 1 }
        assertTrue("sigilo no es más bajo que IDLE", sneakH < idleH)
        assertTrue("sigilo no es más alto que agachado", sneakH > crouchH)
    }
}
