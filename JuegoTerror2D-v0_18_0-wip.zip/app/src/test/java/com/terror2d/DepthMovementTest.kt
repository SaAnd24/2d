package com.terror2d

import android.view.KeyEvent
import com.terror2d.core.Camera
import com.terror2d.core.CameraMode
import com.terror2d.core.Depth
import com.terror2d.core.DepthAware
import com.terror2d.core.DepthBand
import com.terror2d.core.DepthLayer
import com.terror2d.core.FloorType
import com.terror2d.core.GameConfig
import com.terror2d.core.MoveMode
import com.terror2d.core.Viewport
import com.terror2d.creature.CreatureBrain
import com.terror2d.creature.CreatureState
import com.terror2d.creature.FootstepNoise
import com.terror2d.creature.Hearing
import com.terror2d.creature.NoiseBus
import com.terror2d.creature.NoiseType
import com.terror2d.creature.Senses
import com.terror2d.input.InputController
import com.terror2d.world.Player
import com.terror2d.world.WorldObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Motor 2.5D + movimiento (v0.17): profundidad, velocidades y stamina por modo,
 * ruido por modo+suelo, movimiento vertical dentro de la banda y percepción de la criatura.
 */
class DepthMovementTest {
    private val dt = 1f / 60f
    private val floorY = 150f
    private val seg = "hall"

    private fun player(x: Float = 100f): Player = Player(x, floorY - Player.HEIGHT)

    private fun step(p: Player, seconds: Float, dirX: Float = 0f, dirDepth: Float = 0f, solids: List<WorldObject> = emptyList()) {
        var t = 0f
        while (t < seconds) {
            p.update(dt, dirX, dirDepth, solids, floorY, 0f, 1000f)
            t += dt
        }
    }

    // ------------------------------------------------------------------ profundidad

    @Test fun depthScaleSigueElContrato() {
        assertEquals(0.82f, Depth.depthScale(0f), 0.001f)
        assertEquals(1.0f, Depth.depthScale(0.6f), 0.001f)
        assertEquals(1.12f, Depth.depthScale(1f), 0.001f)
        assertTrue(Depth.depthScale(0f) < Depth.depthScale(0.5f))
        assertTrue(Depth.depthScale(0.5f) < Depth.depthScale(1f))
        // fuera de rango se limita, no se rompe
        assertEquals(0.82f, Depth.depthScale(-1f), 0.001f)
        assertEquals(1.12f, Depth.depthScale(2f), 0.001f)
    }

    @Test fun depthBandApoyaLosPiesEnFloorYEnElPlanoDeReferencia() {
        val band = DepthBand(floorY)
        assertEquals(floorY, band.footY(0.6f), 0.001f)
        assertTrue(band.footY(0f) < floorY)
        assertTrue(band.footY(1f) > floorY)
        assertEquals(0.6f, band.depthAt(floorY), 0.001f)
        assertEquals(0f, band.depthAt(band.backY), 0.001f)
        assertEquals(1f, band.depthAt(band.frontY), 0.001f)
        // ida y vuelta
        assertEquals(0.25f, band.depthAt(band.footY(0.25f)), 0.001f)
    }

    @Test fun depthLayerYOrdenacion() {
        assertEquals(DepthLayer.BACK, Depth.depthLayerOf(0f))
        assertEquals(DepthLayer.MID, Depth.depthLayerOf(0.6f))
        assertEquals(DepthLayer.FRONT, Depth.depthLayerOf(1f))
        val sorted = Depth.sortByDepth(listOf(0.9f, 0.2f, 0.6f, 0.2f)) { it }
        assertEquals(listOf(0.2f, 0.2f, 0.6f, 0.9f), sorted)
        val near = object : DepthAware { override val depth = 0.9f }
        val far = object : DepthAware { override val depth = 0.1f }
        assertEquals(0.9f, Depth.depthOf(near), 0.001f)
        assertEquals(0.1f, Depth.depthOf(far), 0.001f)
        assertEquals(GameConfig.PLAYER_DEFAULT_DEPTH, Depth.depthOf("sin profundidad"), 0.001f)
        assertTrue(Depth.isInFrontOf(near, 0.6f))
        assertFalse(Depth.isInFrontOf(far, 0.6f))
        assertEquals(DepthLayer.BACK, Depth.layerOf(far))
        assertEquals(DepthLayer.FRONT, Depth.layerOf(near))
    }

    @Test fun floorTypeOfMapeaElPatronDelSegmento() {
        assertEquals(FloorType.WOOD, Depth.floorTypeOf("WOOD"))
        assertEquals(FloorType.CARPET, Depth.floorTypeOf("CARPET"))
        assertEquals(FloorType.TILE, Depth.floorTypeOf("TILES"))
        assertEquals(FloorType.TILE, Depth.floorTypeOf("CONCRETE"))
        assertEquals(FloorType.WOOD, Depth.floorTypeOf("DESCONOCIDO"))
    }

    // ------------------------------------------------------------------ velocidades y stamina

    @Test fun velocidadesPorModo() {
        val cases = listOf(
            MoveMode.WALK to 55f..70f,
            MoveMode.RUN to 90f..112f,
            MoveMode.SNEAK to 27f..34f,
            MoveMode.CROUCH to 18f..24f
        )
        for ((mode, range) in cases) {
            val p = player()
            p.moveMode = mode
            val x0 = p.x
            step(p, 1f, dirX = 1f)
            val moved = p.x - x0
            assertTrue("$mode movió $moved, fuera de $range", moved in range)
        }
    }

    @Test fun correrGastaStaminaYAndarLaRecupera() {
        val p = player()
        p.moveMode = MoveMode.RUN
        step(p, 1f, dirX = 1f)
        assertEquals(100f - GameConfig.STAMINA_DRAIN_RUN, p.stamina, 1f)
        p.moveMode = MoveMode.WALK
        step(p, 1f, dirX = 1f)
        assertEquals(100f - GameConfig.STAMINA_DRAIN_RUN + GameConfig.STAMINA_REGEN_WALK, p.stamina, 1f)
        // parado se recupera más rápido que andando
        val p2 = player()
        p2.stamina = 50f
        step(p2, 1f, dirX = 0f)
        assertEquals(50f + GameConfig.STAMINA_REGEN_IDLE, p2.stamina, 1f)
    }

    @Test fun sinStaminaNoSePuedeCorrer() {
        val p = player()
        p.stamina = 5f
        assertFalse(p.requestMode(MoveMode.RUN))
        assertEquals(MoveMode.WALK, p.moveMode)
        p.stamina = 50f
        assertTrue(p.requestMode(MoveMode.RUN))
        assertEquals(MoveMode.RUN, p.moveMode)
        // corriendo hasta agotar: el modo cae solo a WALK
        p.stamina = 0.1f
        p.moveMode = MoveMode.RUN
        p.update(dt, 1f, emptyList(), floorY, 0f, 1000f)
        assertEquals(MoveMode.WALK, p.moveMode)
        assertEquals(0f, p.stamina, 0.001f)
        // la stamina nunca pasa de 0..100
        p.stamina = 99f
        step(p, 2f, dirX = 0f)
        assertEquals(GameConfig.STAMINA_MAX, p.stamina, 0.001f)
    }

    /**
     * v0.18: agacharse ya NO aplasta el sprite ([GameConfig.CROUCH_HEIGHT_SCALE] queda sin uso):
     * `visualHeightScale` es 1 siempre y la altura baja porque la POSE es CROUCH_IDLE (el dibujo
     * es más bajo de verdad: piernas dobladas, cuerpo bajo). La visibilidad sigue bajando a 0.6.
     */
    @Test fun agachadoUsaPoseRealSinAplastar() {
        val p = player()
        assertEquals(1f, p.visualHeightScale, 0.001f)
        assertEquals(1f, p.visibilityFactor, 0.001f)
        assertEquals(com.terror2d.pixel.PixelPose.IDLE, p.pose)
        p.moveMode = MoveMode.CROUCH
        assertEquals(1f, p.visualHeightScale, 0.001f)
        assertEquals(com.terror2d.pixel.PixelPose.CROUCH_IDLE, p.pose)
        assertEquals(GameConfig.VISIBILITY_CROUCH, p.visibilityFactor, 0.001f)
        p.moveMode = MoveMode.SNEAK
        assertEquals(GameConfig.VISIBILITY_SNEAK, p.visibilityFactor, 0.001f)
        p.moveMode = MoveMode.RUN
        assertEquals(GameConfig.VISIBILITY_RUN, p.visibilityFactor, 0.001f)
    }

    // ------------------------------------------------------------------ movimiento en profundidad

    @Test fun moverseEnProfundidadDentroDeLaBanda() {
        val p = player()
        assertEquals(floorY, p.footY(floorY), 0.001f)
        step(p, 2f, dirDepth = 1f)
        assertEquals(1f, p.depth, 0.001f)
        assertEquals(DepthBand(floorY).frontY, p.bottom, 0.01f)
        step(p, 4f, dirDepth = -1f)
        assertEquals(0f, p.depth, 0.001f)
        assertEquals(DepthBand(floorY).backY, p.bottom, 0.01f)
        // moverse solo en profundidad también anima los pasos
        val p2 = player()
        p2.update(dt, 0f, 1f, emptyList(), floorY, 0f, 1000f)
        assertTrue(p2.moving)
    }

    @Test fun laProfundidadNoAtraviesaLosMuebles() {
        val solid = WorldObject(100f, 100f, 30f, 50f).apply { collidable = true }
        val p = player()
        step(p, 1f, dirDepth = 1f, solids = listOf(solid))
        assertEquals(0.6f, p.depth, 0.001f)
        // sin mueble en X, la profundidad se mueve libre
        val far = WorldObject(500f, 100f, 30f, 50f).apply { collidable = true }
        val p2 = player()
        step(p2, 1f, dirDepth = 1f, solids = listOf(far))
        assertTrue(p2.depth > 0.6f)
        // la firma antigua (sin profundidad) sigue funcionando y no mueve la depth
        val p3 = player()
        p3.update(dt, 1f, emptyList(), floorY, 0f, 1000f)
        assertEquals(0.6f, p3.depth, 0.001f)
        assertEquals(floorY, p3.bottom, 0.001f)
    }

    // ------------------------------------------------------------------ ruido por modo y suelo

    @Test fun ruidoDePasosPorModoYSuelo() {
        // andar sobre madera cruje y se oye; sobre alfombra casi no
        assertEquals(0.161f, FootstepNoise.intensity(MoveMode.WALK, FloorType.WOOD), 0.001f)
        assertEquals(0.028f, FootstepNoise.intensity(MoveMode.WALK, FloorType.CARPET), 0.001f)
        assertTrue(FootstepNoise.intensity(MoveMode.WALK, FloorType.WOOD) > Hearing.THRESHOLD)
        assertTrue(FootstepNoise.intensity(MoveMode.WALK, FloorType.CARPET) < Hearing.THRESHOLD)
        // correr es lo más ruidoso en cualquier suelo
        assertEquals(0.575f, FootstepNoise.intensity(MoveMode.RUN, FloorType.WOOD), 0.001f)
        assertTrue(FootstepNoise.intensity(MoveMode.RUN, FloorType.CARPET) > Hearing.THRESHOLD)
        // sigilo y agachado quedan bajo el umbral incluso en madera y escaleras
        assertTrue(FootstepNoise.intensity(MoveMode.SNEAK, FloorType.WOOD) < Hearing.THRESHOLD)
        assertTrue(FootstepNoise.intensity(MoveMode.SNEAK, FloorType.STAIRS) < Hearing.THRESHOLD)
        assertTrue(FootstepNoise.intensity(MoveMode.CROUCH, FloorType.STAIRS) < Hearing.THRESHOLD)
        // las escaleras crujen más que la madera
        assertTrue(
            FootstepNoise.intensity(MoveMode.WALK, FloorType.STAIRS) >
                FootstepNoise.intensity(MoveMode.WALK, FloorType.WOOD)
        )
        assertEquals(NoiseType.WALK, FootstepNoise.type(MoveMode.WALK))
        assertEquals(NoiseType.RUN, FootstepNoise.type(MoveMode.RUN))
        assertEquals(NoiseType.SNEAK, FootstepNoise.type(MoveMode.SNEAK))
        assertEquals(NoiseType.CROUCH, FootstepNoise.type(MoveMode.CROUCH))
    }

    @Test fun noiseBusEmitePisadasConModoYSuelo() {
        val bus = NoiseBus()
        bus.emitFootstep(100f, seg, MoveMode.RUN, FloorType.WOOD, 0.6f, 0f)
        val n = bus.recent[0]
        assertEquals(NoiseType.RUN, n.type)
        assertEquals(0.575f, n.intensity, 0.001f)
        assertEquals(0.6f, n.depth, 0.001f)
    }

    @Test fun elOidoAtenuaConLaProfundidad() {
        val near = FootstepNoise.event(500f, seg, MoveMode.WALK, FloorType.WOOD, 0.6f, 0f)
        val far = FootstepNoise.event(500f, seg, MoveMode.WALK, FloorType.WOOD, 0.0f, 0f)
        // misma distancia en X, distinta profundidad: el de la otra profundidad se oye más débil
        assertTrue(Hearing.perceivedIntensity(far, 400f, 1.0f) < Hearing.perceivedIntensity(near, 400f, 0.6f))
        // un paso andando a 100 px se oye en la misma profundidad y no en la opuesta
        assertTrue(Hearing.perceivedIntensity(near, 400f, 0.6f) >= Hearing.THRESHOLD)
        assertTrue(Hearing.perceivedIntensity(far, 400f, 1.0f) < Hearing.THRESHOLD)
    }

    // ------------------------------------------------------------------ percepción de la criatura

    private fun brain(x: Float = 400f) = CreatureBrain(x, seg, 100f, 700f, seed = 3)

    private fun runBrain(b: CreatureBrain, s: Senses, seconds: Float, noises: List<com.terror2d.creature.NoiseEvent> = emptyList()) {
        var t = 0f
        while (t < seconds) { b.update(dt, s, noises); t += dt }
    }

    @Test fun agachadoCuestaMasVerlo() {
        // a 250 px, con luz: andando lo ve (alcance 300), agachado no (alcance 300 * 0.6 = 180)
        val walking = brain()
        runBrain(walking, Senses(playerX = 650f, playerSegmentId = seg, playerLight = 1f, playerVisibility = 1f), 0.5f)
        assertEquals(CreatureState.CHASE, walking.state)
        val crouched = brain()
        runBrain(crouched, Senses(playerX = 650f, playerSegmentId = seg, playerLight = 1f, playerVisibility = 0.6f), 0.5f)
        assertEquals(CreatureState.PATROL, crouched.state)
        // ...pero de cerca sí lo ve agachado
        val close = brain()
        runBrain(close, Senses(playerX = 500f, playerSegmentId = seg, playerLight = 1f, playerVisibility = 0.6f), 0.5f)
        assertEquals(CreatureState.CHASE, close.state)
    }

    @Test fun elRuidoEnOtraProfundidadNoLaAtrae() {
        val sameDepth = FootstepNoise.event(500f, seg, MoveMode.WALK, FloorType.WOOD, 0.6f, 0f)
        val otherDepth = FootstepNoise.event(500f, seg, MoveMode.WALK, FloorType.WOOD, 0.0f, 0f)
        val b1 = brain().apply { depth = 0.6f }
        runBrain(b1, Senses(playerX = 5000f, playerSegmentId = seg), 0.3f, listOf(sameDepth))
        assertEquals(CreatureState.INVESTIGATE, b1.state)
        val b2 = brain().apply { depth = 1.0f }
        runBrain(b2, Senses(playerX = 5000f, playerSegmentId = seg), 0.3f, listOf(otherDepth))
        assertEquals(CreatureState.PATROL, b2.state)
    }

    // ------------------------------------------------------------------ cámara y viewport

    @Test fun laCamaraRespiraConLaProfundidad() {
        val cam = Camera(320f, 180f)
        cam.configure(500f, 180f, CameraMode.SIDE_SCROLLING)
        assertEquals(0f, cam.depthShiftY, 0.001f)
        assertEquals(1f, cam.depthZoom, 0.001f)
        cam.updateDepthFocus(1f, 0.1f)
        assertTrue(cam.depthFocus > 0.6f && cam.depthFocus < 1f)
        cam.updateDepthFocus(1f, 5f)
        assertEquals(1f, cam.depthFocus, 0.001f)
        assertEquals(1.2f, cam.depthShiftY, 0.01f)
        assertEquals(1.02f, cam.depthZoom, 0.001f)
        assertTrue(kotlin.math.abs(cam.depthShiftY) <= GameConfig.DEPTH_SHIFT_MAX)
        cam.updateDepthFocus(0f, 5f)
        assertEquals(-1.8f, cam.depthShiftY, 0.01f)
        assertEquals(0.97f, cam.depthZoom, 0.001f)
    }

    @Test fun elViewportZoomNoRompeElEncuadre() {
        val v = Viewport()
        v.update(640, 360)
        assertEquals(2f, v.scale, 0.001f)
        assertEquals(160f, v.toLogicalX(320f), 0.001f)
        v.setZoom(1.05f)
        assertEquals(160f, v.toLogicalX(320f), 0.001f) // el centro no se mueve
        assertEquals(7.62f, v.toLogicalX(0f), 0.05f)
        assertEquals(90f, v.toLogicalY(180f), 0.001f)
        v.setZoom(2f)
        assertEquals(1.05f, v.zoom, 0.001f) // limitado a ±5%
        v.setZoom(1f)
        assertEquals(160f, v.toLogicalX(320f), 0.001f)
    }

    // ------------------------------------------------------------------ controles

    @Test fun controlesDeMovimientoYModo() {
        val input = InputController()
        input.setDirection(false, true)
        assertEquals(1f, input.moveX, 0.001f)
        input.setDepthInput(true, false)
        assertEquals(-1f, input.moveY, 0.001f)
        input.setDepthInput(false, true)
        assertEquals(1f, input.moveY, 0.001f)
        input.setDepthInput(false, false)
        assertEquals(0f, input.moveY, 0.001f)
        assertEquals(MoveMode.WALK, input.requestedMode)

        input.setRunHeld(true)
        assertTrue(input.runHeld)
        assertEquals(MoveMode.RUN, input.requestedMode)
        input.setRunHeld(false)

        input.setModeToggle(MoveMode.SNEAK)
        assertEquals(MoveMode.SNEAK, input.requestedMode)
        input.setModeToggle(MoveMode.CROUCH)
        assertEquals(MoveMode.CROUCH, input.requestedMode)
        // agachado manda sobre correr
        input.setRunHeld(true)
        assertEquals(MoveMode.CROUCH, input.requestedMode)
        input.setRunHeld(false)
        input.setModeToggle(MoveMode.WALK)
        assertEquals(MoveMode.WALK, input.requestedMode)

        // v0.18: el ciclo de modo (ANDAR -> SIGILO -> AGACHADO) ya no existe: el botón de modo
        // de la esquina superior izquierda se eliminó. SIGILO alterna con su propio botón y
        // AGACHARSE es MANTENER: al soltar, el niño se levanta.
        input.touchDown(1, InputController.SNEAK_X, InputController.SNEAK_Y)
        assertEquals(MoveMode.SNEAK, input.requestedMode)
        input.touchUp(1)
        assertEquals(MoveMode.SNEAK, input.requestedMode) // alternar: sigue en sigilo al soltar
        input.touchDown(1, InputController.SNEAK_X, InputController.SNEAK_Y)
        assertEquals(MoveMode.WALK, input.requestedMode)
        input.touchUp(1)

        input.touchDown(2, InputController.CROUCH_X, InputController.CROUCH_Y)
        assertEquals(MoveMode.CROUCH, input.requestedMode)
        input.touchUp(2)
        assertEquals(MoveMode.WALK, input.requestedMode) // mantener: al soltar se levanta
    }

    @Test fun tecladoCorreSigiloYAgachado() {
        val input = InputController()
        assertTrue(input.onKey(KeyEvent.KEYCODE_W, true))
        assertEquals(-1f, input.moveY, 0.001f)
        input.onKey(KeyEvent.KEYCODE_W, false)
        assertTrue(input.onKey(KeyEvent.KEYCODE_S, true))
        assertEquals(1f, input.moveY, 0.001f)
        input.onKey(KeyEvent.KEYCODE_S, false)

        assertTrue(input.onKey(KeyEvent.KEYCODE_SHIFT_LEFT, true))
        assertTrue(input.runHeld)
        assertEquals(MoveMode.RUN, input.requestedMode)
        input.onKey(KeyEvent.KEYCODE_SHIFT_LEFT, false)
        assertFalse(input.runHeld)

        // v0.18: C es MANTENER agachado (antes alternaba): al soltar la tecla, el niño se levanta
        assertTrue(input.onKey(KeyEvent.KEYCODE_C, true))
        assertEquals(MoveMode.CROUCH, input.requestedMode)
        input.onKey(KeyEvent.KEYCODE_C, false)
        assertEquals(MoveMode.WALK, input.requestedMode)
        assertTrue(input.onKey(KeyEvent.KEYCODE_C, true))
        assertEquals(MoveMode.CROUCH, input.requestedMode)
        input.onKey(KeyEvent.KEYCODE_C, false)
        assertEquals(MoveMode.WALK, input.requestedMode)

        assertTrue(input.onKey(KeyEvent.KEYCODE_V, true))
        assertEquals(MoveMode.SNEAK, input.requestedMode)
        input.onKey(KeyEvent.KEYCODE_V, false)
    }
}
