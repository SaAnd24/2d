package com.terror2d.world

import com.terror2d.draw.CrayonBuilder
import com.terror2d.draw.CrayonSprite
import com.terror2d.draw.Cr
import com.terror2d.render.WorldRenderer
import com.terror2d.util.SeededRandom
import kotlin.math.sin

/**
 * Objeto dibujado a crayón que se MECE o vibra: el sprite se construye UNA vez (como [DrawnProp]) y cada frame solo se
 * inclina un poco alrededor de [pivotY] con el tiempo de animación. Determinista y casi gratis.
 * Sirve para cortinas con corriente, abrigos colgados, papeles, tuberías que vibran...
 */
class SwayProp(
    x: Float, y: Float, w: Float, h: Float,
    layerValue: Int,
    private val amplitude: Float,
    private val speed: Float,
    private val phase: Float,
    private val build: (CrayonBuilder, Float, Float) -> Unit
) : WorldObject(x, y, w, h) {

    private var sprite: CrayonSprite = CrayonSprite.EMPTY

    init {
        collidable = false
        layer = layerValue
    }

    override fun prepareVisuals(rng: SeededRandom) {
        val b = CrayonBuilder(rng)
        build(b, x, y)
        sprite = b.finish()
        outline = EMPTY
        hatch = EMPTY
    }

    override fun visualHash(seed: Long): Long = sprite.hash(seed)

    override fun render(r: WorldRenderer) {
        val k = sin(r.animTime * speed + phase) * amplitude
        r.drawSpriteSwayed(sprite, centerX, y, k)
    }
}

/** Animación por fotogramas (gotas que caen, agua que se agita): [frames] sprites precalculados y un cambio de fotograma por reloj. */
class FramesProp(
    x: Float, y: Float, w: Float, h: Float,
    layerValue: Int,
    private val frames: Int,
    private val fps: Float,
    private val build: (CrayonBuilder, Float, Float, Int) -> Unit
) : WorldObject(x, y, w, h) {

    private var sprites: Array<CrayonSprite> = emptyArray()

    init {
        collidable = false
        layer = layerValue
    }

    override fun prepareVisuals(rng: SeededRandom) {
        sprites = Array(frames) { f ->
            val b = CrayonBuilder(rng)
            build(b, x, y, f)
            b.finish()
        }
        outline = EMPTY
        hatch = EMPTY
    }

    override fun visualHash(seed: Long): Long {
        var h = seed
        for (s in sprites) h = 31L * h + s.hash(seed)
        return h
    }

    override fun render(r: WorldRenderer) {
        if (sprites.isEmpty()) return
        r.drawSprite(sprites[((r.animTime * fps).toInt() % frames + frames) % frames])
    }
}

/**
 * Mobiliario y decorado propios de cada estancia del Capítulo I (sofás, tuberías, caldera, antena...). Mismo lenguaje que
 * [HouseProps]: crayón sobre papel, siluetas legibles y escala del niño (~44 px). Ninguno tiene colisión.
 */
object ChapterProps {
    private const val F = 146f

    private fun prop(x: Float, y: Float, w: Float, h: Float, layer: Int = Layer.OBJECT, build: (CrayonBuilder, Float, Float) -> Unit) =
        DrawnProp(x, y, w, h, layer, build)

    // ------------------------------------------------------------------ sala y comedor

    fun sofa(x: Float) = prop(x, F - 40f, 100f, 40f) { b, x0, y0 ->
        b.box(x0, y0 + 12f, 100f, 28f, Cr.CORAL, Cr.RED)
        b.box(x0 - 3f, y0 + 6f, 14f, 34f, Cr.RED, Cr.DBROWN)
        b.box(x0 + 89f, y0 + 6f, 14f, 34f, Cr.RED, Cr.DBROWN)
        b.box(x0 + 10f, y0 + 12f, 36f, 18f, Cr.PINK)
        b.box(x0 + 54f, y0 + 12f, 36f, 18f, Cr.PINK)
        b.box(x0 + 12f, y0 + 2f, 28f, 14f, Cr.YELLOW)          // cojín
        b.line(x0 + 50f, y0 + 14f, x0 + 50f, y0 + 30f, Cr.DBROWN, 1f)
        b.box(x0 + 6f, y0 + 40f, 5f, 4f, Cr.DBROWN)
        b.box(x0 + 89f, y0 + 40f, 5f, 4f, Cr.DBROWN)
    }

    fun armchair(x: Float) = prop(x, F - 40f, 42f, 40f) { b, x0, y0 ->
        b.box(x0 + 4f, y0, 30f, 30f, Cr.TEAL, Cr.DGREEN)
        b.box(x0, y0 + 16f, 42f, 20f, Cr.MINT, Cr.TEAL)
        b.box(x0 + 8f, y0 + 20f, 26f, 10f, Cr.CREAM)
        b.line(x0 + 4f, y0 + 36f, x0 + 4f, y0 + 40f, Cr.DBROWN, 2f)
        b.line(x0 + 38f, y0 + 36f, x0 + 38f, y0 + 40f, Cr.DBROWN, 2f)
        b.box(x0 + 30f, y0 + 8f, 8f, 14f, Cr.YELLOW)            // manta doblada
    }

    fun coffeeTable(x: Float) = prop(x, F - 20f, 44f, 20f) { b, x0, y0 ->
        b.box(x0, y0, 44f, 5f, Cr.WOOD, Cr.BROWN)
        b.box(x0 + 3f, y0 + 5f, 4f, 15f, Cr.BROWN)
        b.box(x0 + 37f, y0 + 5f, 4f, 15f, Cr.BROWN)
        b.box(x0 + 8f, y0 - 6f, 10f, 6f, Cr.BLUE)               // revista
        b.box(x0 + 26f, y0 - 7f, 7f, 7f, Cr.WHITE)              // taza
    }

    fun tvSet(x: Float) = prop(x, F - 52f, 48f, 52f) { b, x0, y0 ->
        b.box(x0, y0 + 36f, 48f, 16f, Cr.BROWN, Cr.DBROWN)
        b.box(x0 + 6f, y0 + 4f, 36f, 30f, Cr.DGRAY, Cr.DARK)
        b.box(x0 + 9f, y0 + 7f, 30f, 24f, Cr.NIGHT)
        b.line(x0 + 14f, y0 + 4f, x0 + 8f, y0 - 6f, Cr.DARK, 1.2f)  // antena de conejo
        b.line(x0 + 30f, y0 + 4f, x0 + 38f, y0 - 6f, Cr.DARK, 1.2f)
        b.dots(x0 + 12f, y0 + 10f, 24f, 18f, 4, Cr.GRAY, 1.2f)
    }

    /**
     * Ventana con cortinas. Cortas por defecto (las de siempre). Con [long] = true las cortinas
     * llegan HASTA EL SUELO y van en PRIMER PLANO (v0.18 Fran Bow): enmarcan la ventana y tapan
     * al niño cuando pasa por detrás —esconderse tras la cortina se ve de verdad—. El dormitorio
     * del niño NO usa cortinas largas: tiene papeles en el suelo bajo la ventana (d16, d19) y la
     * cortina larga los taparía; el estudio y la sala no tienen ese problema (el papel d14b del
     * estudio queda con el borde bajo la cortina, como un papel medio escondido, y sigue leyéndose).
     */
    fun curtainedWindow(x: Float, y: Float, w: Float, h: Float, cloth: Int, amplitude: Float = 0.05f, long: Boolean = false): List<WorldObject> {
        val frame = prop(x - 4f, y - 3f, w + 8f, h + 8f, Layer.DECOR) { b, _, _ ->
            b.box(x, y, w, h, Cr.NIGHT, Cr.DBLUE)
            b.line(x + w / 2f, y, x + w / 2f, y + h, Cr.WHITE, 1.4f)
            b.line(x, y + h / 2f, x + w, y + h / 2f, Cr.WHITE, 1.4f)
            b.box(x - 4f, y + h, w + 8f, 4f, Cr.WOOD, Cr.BROWN)
        }
        if (!long) {
            val left = SwayProp(x - 3f, y - 2f, w * 0.42f, h + 6f, Layer.DECOR, amplitude, 1.1f, x * 0.07f) { b, x0, y0 ->
                b.poly(floatArrayOf(x0, y0, x0 + w * 0.42f, y0, x0 + w * 0.36f, y0 + h + 6f, x0 + 2f, y0 + h + 4f), cloth, Cr.WHITE)
            }
            val right = SwayProp(x + w * 0.6f, y - 2f, w * 0.42f, h + 6f, Layer.DECOR, amplitude, 1.1f, x * 0.07f + 1f) { b, x0, y0 ->
                b.poly(floatArrayOf(x0, y0, x0 + w * 0.42f, y0, x0 + w * 0.40f, y0 + h + 4f, x0 + 6f, y0 + h + 6f), cloth, Cr.WHITE)
            }
            return listOf(frame, left, right)
        }
        val curtainH = F - y - 4f
        val left = SwayProp(x - 3f, y - 2f, w * 0.42f, curtainH, Layer.FOREGROUND, amplitude, 1.1f, x * 0.07f) { b, x0, y0 ->
            b.poly(floatArrayOf(x0, y0, x0 + w * 0.42f, y0, x0 + w * 0.36f, y0 + curtainH + 6f, x0 + 2f, y0 + curtainH + 4f), cloth, Cr.WHITE)
        }
        val right = SwayProp(x + w * 0.6f, y - 2f, w * 0.42f, curtainH, Layer.FOREGROUND, amplitude, 1.1f, x * 0.07f + 1f) { b, x0, y0 ->
            b.poly(floatArrayOf(x0, y0, x0 + w * 0.42f, y0, x0 + w * 0.40f, y0 + curtainH + 4f, x0 + 6f, y0 + curtainH + 6f), cloth, Cr.WHITE)
        }
        return listOf(frame, left, right)
    }

    // ------------------------------------------------------------------ baños

    fun bathtub(x: Float) = prop(x, F - 36f, 84f, 36f) { b, x0, y0 ->
        b.box(x0, y0 + 8f, 84f, 24f, Cr.WHITE, Cr.METAL)
        b.box(x0 + 4f, y0 + 10f, 76f, 8f, Cr.GLASS)
        b.box(x0 + 8f, y0 + 32f, 6f, 4f, Cr.DGRAY)
        b.box(x0 + 70f, y0 + 32f, 6f, 4f, Cr.DGRAY)
        b.line(x0 + 74f, y0, x0 + 74f, y0 + 10f, Cr.METAL, 2f)
        b.line(x0 + 74f, y0, x0 + 66f, y0, Cr.METAL, 2f)
        b.ball(x0 + 20f, y0 + 6f, 6f, 5f, Cr.PINK)               // pato
    }

    fun towelRack(x: Float) = prop(x, 56f, 30f, 36f, Layer.DECOR) { b, x0, y0 ->
        b.line(x0, y0, x0 + 30f, y0, Cr.METAL, 2f)
        b.box(x0 + 3f, y0 + 1f, 11f, 28f, Cr.BLUE, Cr.DBLUE)
        b.box(x0 + 17f, y0 + 1f, 10f, 20f, Cr.YELLOW, Cr.ORANGE)
    }

    // ------------------------------------------------------------------ cocina, despensa, servicio

    fun pantryShelves(x: Float, w: Float) = prop(x, F - 96f, w, 96f) { b, x0, y0 ->
        for (k in 0 until 4) b.box(x0, y0 + 6f + k * 24f, w, 3f, Cr.BROWN, Cr.DBROWN)
        b.box(x0, y0, 3f, 96f, Cr.DBROWN)
        b.box(x0 + w - 3f, y0, 3f, 96f, Cr.DBROWN)
        var i = 0
        while (i * 14f + 8f < w - 6f) {
            val cx = x0 + 6f + i * 14f
            b.box(cx, y0 - 10f + 24f, 9f, 13f, if (i % 2 == 0) Cr.RED else Cr.GREEN)   // botes
            b.box(cx + 1f, y0 + 14f + 24f, 11f, 9f, Cr.CREAM)                         // cajas
            b.box(cx, y0 + 38f + 24f, 8f, 14f, Cr.ORANGE)
            i++
        }
    }

    fun serviceStairsDown(x: Float) = prop(x, F - 70f, 74f, 70f, Layer.DECOR) { b, x0, y0 ->
        b.box(x0, y0, 74f, 70f, Cr.DGRAY, Cr.DARK)               // hueco oscuro
        for (k in 0 until 5) b.box(x0 + 4f + k * 8f, y0 + 16f + k * 10f, 66f - k * 8f, 5f, Cr.GRAY, Cr.DGRAY)
        b.line(x0, y0 + 8f, x0 + 74f, y0 + 8f, Cr.METAL, 2f)    // barandilla
    }

    fun mainStairs(x: Float, up: Boolean) = prop(x, F - 100f, 100f, 100f, Layer.DECOR) { b, x0, y0 ->
        for (k in 0 until 8) {
            val sx = x0 + (if (up) k else 7 - k) * 9f
            b.box(sx, y0 + 28f + k * 9f, 28f + (if (up) 0f else 0f), 9f, Cr.WOOD, Cr.BROWN)
        }
        val ax = if (up) x0 + 2f else x0 + 98f
        b.line(ax, y0 + 20f, if (up) x0 + 98f else x0 + 2f, y0 + 96f, Cr.DBROWN, 2f)
    }

    fun mopBucket(x: Float) = prop(x, F - 36f, 22f, 36f) { b, x0, y0 ->
        b.box(x0 + 2f, y0 + 20f, 18f, 16f, Cr.BLUE, Cr.DBLUE)
        b.line(x0 + 10f, y0, x0 + 12f, y0 + 22f, Cr.WOOD, 2.5f)
        b.box(x0 + 5f, y0 - 2f, 12f, 8f, Cr.CREAM, Cr.GRAY)
    }

    // ------------------------------------------------------------------ segundo piso

    fun deskStudy(x: Float) = prop(x, F - 52f, 90f, 52f) { b, x0, y0 ->
        b.box(x0, y0 + 20f, 90f, 6f, Cr.WOOD, Cr.BROWN)
        b.box(x0 + 4f, y0 + 26f, 6f, 26f, Cr.BROWN)
        b.box(x0 + 80f, y0 + 26f, 6f, 26f, Cr.BROWN)
        b.box(x0 + 60f, y0 + 26f, 20f, 26f, Cr.DBROWN, Cr.BROWN)     // cajones
        b.box(x0 + 8f, y0 + 12f, 22f, 8f, Cr.WHITE)                  // papeles
        b.box(x0 + 14f, y0 + 9f, 18f, 5f, Cr.CREAM)
        b.box(x0 + 46f, y0 + 4f, 5f, 16f, Cr.DGRAY)                  // lámpara de mesa
        b.poly(floatArrayOf(x0 + 40f, y0 + 4f, x0 + 58f, y0 + 4f, x0 + 52f, y0 - 4f, x0 + 46f, y0 - 4f), Cr.YELLOW)
        b.line(x0 + 28f, y0 + 20f, x0 + 40f, y0 + 14f, Cr.RED, 1.2f)  // lápiz
    }

    fun chestOfDrawers(x: Float, w: Float) = prop(x, F - 48f, w, 48f) { b, x0, y0 ->
        b.box(x0, y0, w, 48f, Cr.BROWN, Cr.DBROWN)
        for (k in 0 until 3) {
            b.box(x0 + 3f, y0 + 3f + k * 15f, w - 6f, 12f, Cr.WOOD)
            b.box(x0 + w / 2f - 3f, y0 + 7f + k * 15f, 6f, 2.5f, Cr.METAL)
        }
        b.box(x0 + w - 12f, y0 + 18f, 9f, 3f, Cr.PINK)               // una prenda asoma del cajón mal cerrado
    }

    fun laundryBasket(x: Float) = HouseProps.basket(x)

    fun ladderFold(x: Float) = prop(x, F - 70f, 22f, 70f, Layer.DECOR) { b, x0, y0 ->
        b.line(x0 + 2f, y0, x0 + 4f, y0 + 70f, Cr.METAL, 2f)
        b.line(x0 + 20f, y0, x0 + 18f, y0 + 70f, Cr.METAL, 2f)
        for (k in 0 until 6) b.line(x0 + 3f, y0 + 8f + k * 11f, x0 + 19f, y0 + 8f + k * 11f, Cr.DGRAY, 1.5f)
    }

    fun trapdoorLadder(x: Float) = prop(x, 14f, 34f, F - 14f, Layer.DECOR) { b, x0, y0 ->
        b.box(x0, y0, 34f, 14f, Cr.DBROWN, Cr.BROWN)                 // trampilla
        b.line(x0 + 8f, y0 + 14f, x0 + 8f, y0 + F - 14f, Cr.WOOD, 2f)
        b.line(x0 + 26f, y0 + 14f, x0 + 26f, y0 + F - 14f, Cr.WOOD, 2f)
        for (k in 0 until 8) b.line(x0 + 8f, y0 + 26f + k * 14f, x0 + 26f, y0 + 26f + k * 14f, Cr.BROWN, 1.6f)
    }

    // ------------------------------------------------------------------ sótano

    fun fuseBox(x: Float, y: Float) = prop(x, y, 64f, 66f, Layer.DECOR) { b, x0, y0 ->
        b.box(x0, y0, 64f, 66f, Cr.METAL, Cr.GRAY)
        for (k in 0 until 4) {
            b.box(x0 + 8f + k * 14f, y0 + 12f, 9f, 18f, Cr.DGRAY, Cr.DARK)
            b.box(x0 + 9f + k * 14f, y0 + (if (k % 2 == 0) 14f else 22f), 7f, 7f, Cr.RED)
        }
        b.line(x0 + 10f, y0 + 40f, x0 + 54f, y0 + 40f, Cr.DARK, 1f)
        b.dots(x0 + 8f, y0 + 46f, 48f, 14f, 5, Cr.YELLOW, 1.6f)
        b.line(x0 + 64f, y0 + 20f, x0 + 90f, y0 + 6f, Cr.DARK, 2f)   // cables
        b.line(x0 + 64f, y0 + 34f, x0 + 90f, y0 + 40f, Cr.RED, 1.6f)
    }

    fun boilerTank(x: Float) = prop(x, F - 86f, 84f, 86f) { b, x0, y0 ->
        b.box(x0 + 6f, y0 + 12f, 72f, 74f, Cr.METAL, Cr.GRAY)
        b.ball(x0 + 42f, y0 + 12f, 36f, 10f, Cr.METAL, Cr.GRAY)
        b.ball(x0 + 42f, y0 + 40f, 11f, 11f, Cr.WHITE, Cr.METAL)      // manómetro
        b.line(x0 + 42f, y0 + 40f, x0 + 48f, y0 + 34f, Cr.RED, 1.4f)
        b.box(x0 + 12f, y0 + 62f, 18f, 12f, Cr.DGRAY, Cr.DARK)
        b.box(x0 + 50f, y0 + 62f, 18f, 12f, Cr.ORANGE, Cr.RED)        // ventana de la llama
        b.box(x0 + 14f, y0 + 86f, 8f, 3f, Cr.DARK)
        b.box(x0 + 62f, y0 + 86f, 8f, 3f, Cr.DARK)
    }

    /** Tubería horizontal que vibra (más fuerte cuando [amplitude] es alta). */
    fun pipeRun(x: Float, y: Float, w: Float, amplitude: Float = 0.012f) = SwayProp(x, y, w, 10f, Layer.DECOR, amplitude, 9f, x * 0.1f) { b, x0, y0 ->
        b.box(x0, y0 + 2f, w, 6f, Cr.DGRAY, Cr.GRAY)
        var k = 14f
        while (k < w - 8f) {
            b.box(x0 + k, y0, 4f, 10f, Cr.DARK)
            k += 34f
        }
    }

    fun valve(x: Float, y: Float, tone: Int) = prop(x, y, 20f, 30f, Layer.OBJECT) { b, x0, y0 ->
        b.box(x0 + 8f, y0 + 6f, 4f, 24f, Cr.DGRAY)
        b.ball(x0 + 10f, y0 + 6f, 9f, 4f, tone, Cr.DARK)
        b.line(x0 + 10f, y0 + 2f, x0 + 10f, y0 + 10f, Cr.DARK, 1.2f)
    }

    fun drip(x: Float, y: Float) = FramesProp(x, y, 8f, 40f, Layer.DECOR, 4, 3f) { b, x0, y0, f ->
        b.box(x0 + 1f, y0, 6f, 4f, Cr.DGRAY, Cr.DARK)
        b.ball(x0 + 4f, y0 + 6f + f * 9f, 1.6f, 2.4f, Cr.BLUE)
        if (f == 3) b.line(x0 - 3f, y0 + 38f, x0 + 11f, y0 + 38f, Cr.BLUE, 1f)
    }

    fun shelvesTools(x: Float, w: Float) = prop(x, F - 80f, w, 80f) { b, x0, y0 ->
        for (k in 0 until 3) b.box(x0, y0 + 14f + k * 26f, w, 3f, Cr.DBROWN, Cr.BROWN)
        b.box(x0 + 4f, y0 + 2f, 14f, 12f, Cr.RED, Cr.DBROWN)          // caja de herramientas
        b.box(x0 + 24f, y0 + 4f, 9f, 10f, Cr.YELLOW)
        b.box(x0 + 6f, y0 + 40f, 18f, 12f, Cr.CREAM)
        b.box(x0 + 30f, y0 + 36f, 12f, 16f, Cr.TEAL)
        b.line(x0 + w - 12f, y0 + 58f, x0 + w - 12f, y0 + 80f, Cr.METAL, 2f)
        b.box(x0 + w - 20f, y0 + 62f, 16f, 18f, Cr.DGRAY)
    }

    fun puddle(x: Float, w: Float) = prop(x, F - 5f, w, 5f, Layer.FLOOR) { b, x0, y0 ->
        b.fillOval(x0 + w / 2f, y0 + 2.5f, w / 2f, 2.5f, Cr.BLUE)
    }

    /**
     * v0.17: sombra oscura bajo una cama. Marca el hueco donde cabe el niño (escondite UNDER_BED):
     * solo es decorado del suelo — el escondite en sí es el [Wardrobe] con ese tipo, que no dibuja
     * ningún mueble porque la cama ya está dibujada por la habitación. [x]/[w] son los de la cama.
     */
    fun underBedShadow(x: Float, w: Float) = prop(x, F - 14f, w, 14f, Layer.FLOOR) { b, x0, y0 ->
        b.fillOval(x0 + w / 2f, y0 + 7f, w / 2f, 7f, Cr.DARK)
        b.box(x0 + 4f, y0 + 4f, w - 8f, 3f, Cr.NIGHT)
        b.dots(x0 + 8f, y0 + 8f, w - 16f, 4f, 4, Cr.GRAY, 1.2f)
    }

    // ------------------------------------------------------------------ azotea

    fun waterTank(x: Float) = prop(x, F - 70f, 60f, 70f) { b, x0, y0 ->
        b.box(x0 + 6f, y0 + 14f, 48f, 44f, Cr.METAL, Cr.GRAY)
        b.ball(x0 + 30f, y0 + 14f, 24f, 8f, Cr.GRAY, Cr.DGRAY)
        for (k in 0 until 3) b.line(x0 + 6f, y0 + 24f + k * 12f, x0 + 54f, y0 + 24f + k * 12f, Cr.DGRAY, 1.2f)
        b.line(x0 + 10f, y0 + 58f, x0 + 6f, y0 + 70f, Cr.DBROWN, 2.5f)
        b.line(x0 + 50f, y0 + 58f, x0 + 54f, y0 + 70f, Cr.DBROWN, 2.5f)
        b.line(x0 + 54f, y0 + 40f, x0 + 62f, y0 + 40f, Cr.DGRAY, 2f)
    }

    fun chimney(x: Float) = prop(x, F - 62f, 30f, 62f) { b, x0, y0 ->
        b.box(x0, y0 + 8f, 30f, 54f, Cr.CORAL, Cr.RED)
        b.box(x0 - 3f, y0, 36f, 8f, Cr.DGRAY, Cr.DARK)
        for (k in 0 until 4) b.line(x0, y0 + 16f + k * 12f, x0 + 30f, y0 + 16f + k * 12f, Cr.RED, 1f)
    }

    fun antennaMast(x: Float) = prop(x, F - 112f, 56f, 112f) { b, x0, y0 ->
        b.line(x0 + 28f, y0 + 112f, x0 + 28f, y0, Cr.DGRAY, 3f)
        b.line(x0 + 8f, y0 + 90f, x0 + 28f, y0 + 40f, Cr.METAL, 1.4f)
        b.line(x0 + 48f, y0 + 90f, x0 + 28f, y0 + 40f, Cr.METAL, 1.4f)
        b.line(x0 + 20f, y0 + 14f, x0 + 36f, y0 + 14f, Cr.DGRAY, 2f)   // brazo corto
        b.line(x0 + 14f, y0 + 26f, x0 + 42f, y0 + 26f, Cr.DGRAY, 2f)   // brazo medio
        b.line(x0 + 6f, y0 + 38f, x0 + 50f, y0 + 38f, Cr.DGRAY, 2f)    // brazo largo
        b.box(x0 + 10f, y0 + 100f, 36f, 12f, Cr.DGRAY, Cr.DARK)         // base donde encaja la arandela
    }

    fun roofParapet(x: Float, w: Float) = prop(x, F - 18f, w, 18f, Layer.DECOR) { b, x0, y0 ->
        b.box(x0, y0, w, 18f, Cr.GRAY, Cr.DGRAY)
        var k = 0f
        while (k < w) {
            b.line(x0 + k, y0, x0 + k, y0 + 18f, Cr.DGRAY, 1f)
            k += 22f
        }
    }

    fun flutterPapers(x: Float, y: Float) = SwayProp(x, y, 24f, 18f, Layer.OBJECT, 0.10f, 2.6f, x) { b, x0, y0 ->
        b.box(x0, y0, 14f, 16f, Cr.WHITE, Cr.CREAM)
        b.box(x0 + 8f, y0 + 3f, 14f, 14f, Cr.CREAM, Cr.WHITE)
        b.line(x0 + 3f, y0 + 5f, x0 + 11f, y0 + 5f, Cr.GRAY, 1f)
    }

    /** Un abrigo colgado que se mece con la corriente del pasillo. */
    fun hangingCoat(x: Float) = SwayProp(x, 30f, 30f, 60f, Layer.DECOR, 0.03f, 0.9f, x * 0.1f) { b, x0, y0 ->
        b.poly(floatArrayOf(x0 + 4f, y0, x0 + 26f, y0, x0 + 30f, y0 + 60f, x0, y0 + 60f), Cr.RED, Cr.DBROWN)
        b.box(x0 + 12f, y0 + 18f, 8f, 3f, Cr.YELLOW)
    }

    // ------------------------------------------------------------------ estancia imposible

    fun impossibleWindow(x: Float) = prop(x, 28f, 70f, 64f, Layer.DECOR) { b, x0, y0 ->
        b.box(x0, y0, 70f, 64f, Cr.WHITE, Cr.METAL)
        b.box(x0 + 6f, y0 + 6f, 58f, 52f, Cr.CREAM, Cr.GRAY)           // detrás: una pared de esta misma casa
        b.line(x0 + 6f, y0 + 6f, x0 + 64f, y0 + 58f, Cr.DGRAY, 1f)
        b.line(x0 + 64f, y0 + 6f, x0 + 6f, y0 + 58f, Cr.DGRAY, 1f)
    }
}
