package com.terror2d.scene

import com.terror2d.chapter.ChapterDocuments
import com.terror2d.chapter.ChapterFlags
import com.terror2d.core.CameraMode
import com.terror2d.core.HideSpot
import com.terror2d.core.HideSpotType
import com.terror2d.core.WorldMode
import com.terror2d.draw.Cr
import com.terror2d.draw.CrayonBuilder
import com.terror2d.events.EventType
import com.terror2d.interaction.InteractionContext
import com.terror2d.interaction.InteractionIcon
import com.terror2d.interaction.InteractionResult
import com.terror2d.inventory.ItemRegistry
import com.terror2d.render.Palette
import com.terror2d.story.StoryFlags
import com.terror2d.story.StoryState
import com.terror2d.world.ChapterProps
import com.terror2d.world.DarkZone
import com.terror2d.world.Door
import com.terror2d.world.DrawnProp
import com.terror2d.world.Wardrobe
import com.terror2d.world.WardrobeDeco
import com.terror2d.world.WardrobeStyle
import com.terror2d.world.DoorTarget
import com.terror2d.world.ExamineSpot
import com.terror2d.world.HouseProps
import com.terror2d.world.Lamp
import com.terror2d.world.Layer
import com.terror2d.world.NarrativeAware
import com.terror2d.world.Prop
import com.terror2d.world.ScriptedSpot
import com.terror2d.world.StoryGate
import com.terror2d.world.WindowPassage
import com.terror2d.world.WorldObject

/**
 * CAPÍTULO I — «La casa de los dos mundos», con arquitectura DOMÉSTICA por plantas.
 *
 * v0.17: la casa ya NO es un pasillo lineal: es un GRAFO no lineal (ver [HouseGraph]). El hub es
 * el vestíbulo de la planta baja ([FOYER], 6 salidas); el sótano tiene su propio sub-hub
 * ([HouseDefinition.CELLAR], 5 salidas) y el pasillo del segundo piso ([HouseDefinition.HALL], 6).
 * Cada habitación principal tiene al menos 2 salidas; las vueltas permiten rodear a la criatura
 * en vez de huir siempre por el mismo pasillo.
 *
 *  SEGUNDO PISO   Kid ─ Bath ─ Mom (baño compartido: Kid↔Bath↔Mom, atajo ★S3) + Hall ─ Closet ─ (Study, cerrado)
 *                 Hall ── escalera principal ──▶ Foyer              (única conexión con la planta baja)
 *                 Hall ── trampilla ──▶ Roof                         (única conexión con la azotea)
 *  PLANTA BAJA    Foyer (HUB) ─ Living ─ Dining ─ Kitchen ─ Pantry ─ ServiceBath ─ Foyer  (vuelta ★S1+★S5)
 *                 Kitchen ─ Pantry   (Living|Pantry comparten pared: C1, secreto)
 *                 ServiceCorridor ── escalera de servicio ──▶ Cellar (desembarco)
 *  SÓTANO         Cellar ─ Laundry ↔ Electric (★S2) / Boiler ↔ Storage (★S6)  (vueltas del sótano)
 *  ESPECIAL       Impossible (solo tras C5): ◀ Closet, lleva al Foyer.
 *
 * Atajos nuevos (puertas REALES: las usa también la criatura):
 *  ★S1 Dining↔Kitchen (la vuelta de la planta baja: Foyer→Dining→Kitchen→Foyer),
 *  ★S2 Laundry↔Electric (vuelta del sótano), ★S3 Kid↔Bath↔Mom (baño compartido),
 *  ★S5 Pantry↔ServiceBath (zona de servicio), ★S6 Boiler↔Storage (sala de máquinas).
 * Pasos secretos (solo el niño; la criatura no los usa): C1 (Living↔Pantry), C2 (Closet↔Study),
 * T4 (abre el hueco de Storage, dentro de la sala) y C5 (Impossible).
 *
 * Excepciones documentadas (una sola salida, por diseño): Study (solo se entra por el secreto
 * C2), Roof (azotea sin salida, solo la trampilla) e Impossible (sala final, solo sale al Foyer).
 *
 * Escondites (v0.17): cada habitación tiene su armario (v0.16) y además hay escondites nuevos de
 * los otros dos tipos: debajo de la cama (Kid, Mom) y detrás de las cortinas (Living, Study).
 * 19 zonas: 6 del segundo piso, 6 de la planta baja, 5 del sótano, azotea e imposible.
 *
 * v0.18 (estilo Fran Bow, puesta en escena): cada habitación se compone en 3 capas —FONDO (muro,
 * ventanas, cuadros), MEDIO (la línea por donde camina el niño, muebles e interactuables) y
 * PRIMER PLANO (objetos de enmarque en [Layer.FOREGROUND] que tapan parcialmente al niño al pasar
 * por detrás: cortinas largas hasta el suelo en Study y Living, la cesta y la silla heredadas de
 * la casa base, el barril del almacén, la chimenea de la azotea, la escalera plegable del armario,
 * el váter del baño de servicio, la estantería de la despensa, el perchero y el cubo del
 * vestíbulo)—. No se mueve ningún objeto interactuable. Sin primer plano quedan el baño, el
 * cuarto eléctrico, la caldera y la habitación imposible (habitaciones pequeñas o de servicio
 * cuya composición ya es stark). La lluvia de la ventana de mamá ya era primer plano.
 */
object ChapterHouse {

    const val FOYER = "Foyer"
    const val LIVING = "Living"
    const val PANTRY = "Pantry"
    const val SERVICE_BATH = "ServiceBath"
    const val STUDY = "Study"
    const val CLOSET = "Closet"
    const val ELECTRIC = "Electric"
    const val BOILER = "Boiler"
    const val STORAGE = "Storage"
    const val ROOF = "Roof"
    const val IMPOSSIBLE = "Impossible"

    val NEW_ROOMS = listOf(FOYER, LIVING, PANTRY, SERVICE_BATH, STUDY, CLOSET, ELECTRIC, BOILER, STORAGE, ROOF, IMPOSSIBLE)

    /** Hub del grafo: el vestíbulo de la planta baja (todas las vueltas pasan por él). */
    const val HUB = FOYER

    /**
     * Atajos nuevos de v0.17 (puertas reales, en los dos sentidos). Cada par es una vuelta que
     * permite rodear a la criatura: ★S1 Comedor↔Cocina, ★S2 Lavandería↔Cuarto eléctrico,
     * ★S3 Dormitorio del niño↔Baño y Baño↔Dormitorio de mamá (baño compartido),
     * ★S5 Despensa↔Baño de servicio, ★S6 Caldera↔Almacén.
     */
    val NEW_SHORTCUTS: List<Pair<String, String>> = listOf(
        HouseDefinition.DINING to HouseDefinition.KITCHEN,
        HouseDefinition.LAUNDRY to ELECTRIC,
        HouseDefinition.KID to HouseDefinition.BATH,
        HouseDefinition.BATH to HouseDefinition.MOM,
        PANTRY to SERVICE_BATH,
        BOILER to STORAGE
    )

    /**
     * v0.17: todos los escondites del mapa como datos de contrato ([HideSpot]), con su sala y su
     * tipo. Se construye desde la definición (los [Wardrobe] de cada segmento), así que nunca se
     * desincroniza del mapa. La sospecha es 0 aquí: la actual la pone
     * [com.terror2d.creature.ClosetMemory.withSuspicion].
     */
    fun hideSpots(def: SceneDefinition): List<HideSpot> {
        val out = ArrayList<HideSpot>()
        for (seg in def.segments) {
            for (o in seg.objects) {
                if (o is Wardrobe) out.add(o.toHideSpot(seg.id))
            }
        }
        return out
    }

    /** Todos los escondites del Capítulo I (construye la casa si no se pasa una definición). */
    fun hideSpots(): List<HideSpot> = hideSpots(create())

    /** Planta de cada zona (para el mapa y las pruebas). */
    val FLOORS: Map<String, List<String>> = mapOf(
        "SEGUNDO_PISO" to listOf(HouseDefinition.KID, HouseDefinition.BATH, HouseDefinition.MOM, HouseDefinition.HALL, CLOSET, STUDY),
        "PLANTA_BAJA" to listOf(FOYER, LIVING, HouseDefinition.DINING, HouseDefinition.KITCHEN, PANTRY, SERVICE_BATH),
        "SOTANO" to listOf(HouseDefinition.CELLAR, HouseDefinition.LAUNDRY, ELECTRIC, BOILER, STORAGE),
        "AZOTEA" to listOf(ROOF),
        "ESPECIAL" to listOf(IMPOSSIBLE)
    )

    private const val F = 146f
    private const val WALL = 12f
    private val WARM = Palette.LIGHT_WARM or 0xFF000000.toInt()
    private val COLD = Palette.LIGHT_COLD or 0xFF000000.toInt()
    private val PALE = Palette.LIGHT_PALE or 0xFF000000.toInt()

    // ------------------------------------------------------------------ ayudas de objetos

    private val ready: (InteractionContext) -> Boolean = { it.hasFlag(StoryFlags.SURVIVAL_READY) }

    private fun sp(
        id: String, x: Float, w: Float, prompt: String, icon: InteractionIcon,
        enabled: ((InteractionContext) -> Boolean)? = null,
        action: (InteractionContext) -> InteractionResult
    ): ScriptedSpot = ScriptedSpot(id, x, F - 70f, w, 70f, prompt, icon, 6f, null, null, enabled, 0, action)

    private fun ex(id: String, x: Float, w: Float, text: String) = ExamineSpot(id, x, F - 70f, w, 70f, text, 6f)

    /**
     * v0.15: un documento tiene su propia zona de interacción, separada de su dibujo: como mínimo 44 px de ancho
     * (centrada en la carta) más 14 px de margen, y prioridad alta para que ni un mueble ni un cajón cercano la
     * intercepten. El botón dice la acción y el objetivo: «LEER — Nota de mamá».
     */
    private fun doc(id: String, base: String, x: Float, w: Float, onRead: ((InteractionContext) -> Unit)? = null): com.terror2d.world.DocumentProp {
        // v0.16: documento FÍSICO (papel dibujado + zona táctil que lo rodea). Los que son parte del escenario no se recogen.
        val scenery = base == "d02" || base == "d04" || base == "d05" || base == "d07" || base == "d08" || base == "d12"
        val kind = when (base) {
            "d19", "d04" -> com.terror2d.world.PaperKind.DRAWING
            "d20", "d14b" -> com.terror2d.world.PaperKind.LETTER
            "d16", "d17" -> com.terror2d.world.PaperKind.CARD
            "d15" -> com.terror2d.world.PaperKind.LIST
            "d22" -> com.terror2d.world.PaperKind.WRAPPER
            else -> com.terror2d.world.PaperKind.SHEET
        }
        val pw = maxOf(w, 18f)
        val ph = if (kind == com.terror2d.world.PaperKind.DRAWING) 16f else 14f
        return com.terror2d.world.DocumentProp(id, base, x, F, pw, ph, kind, !scenery, ready, DOC_PRIORITY, onRead)
    }

    private fun docPrompt(docId: String): String {
        val t = com.terror2d.story.Documents.get(docId)?.title ?: return "LEER"
        val s = "LEER — " + t
        return if (s.length <= 24) s else s.substring(0, 23) + "…"
    }

    const val DOC_PRIORITY = 10
    const val PUZZLE_PRIORITY = 8

    private fun puzzle(id: String, pid: String, x: Float, w: Float, prompt: String = "EXAMINAR") =
        ScriptedSpot(id, x, F - 70f, w, 70f, prompt, InteractionIcon.USE, 10f, null, null, ready, PUZZLE_PRIORITY) { InteractionResult.panel(pid) }

    private fun observe(id: String, obsId: String, x: Float, w: Float, text: String, needs: String? = null, missing: String = "") =
        sp(id, x, w, "OBSERVAR", InteractionIcon.EXAMINE, ready) { ctx ->
            if (needs != null && !ctx.hasFlag(needs)) InteractionResult.message(missing)
            else {
                ctx.setFlag(ChapterFlags.observed(obsId))
                InteractionResult.message(text)
            }
        }

    /** Una puerta REAL (la usa también la criatura). El destino es el [spawn] de la estancia [seg]. */
    private fun door(id: String, x: Float, seg: String, spawn: String, color: Int, locked: Boolean = false, text: String = "La puerta está cerrada."): Door =
        Door(id, x, F, target = if (locked) null else DoorTarget(seg, spawn), locked = locked, lockedText = text,
            panelColor = color, panelHatch = CrayonBuilder.darker(color))

    /**
     * Escalera / trampilla: la conexión para la criatura es una [Door] invisible y NO usable por el niño; el niño interactúa con
     * la escalera misma ([stairSpot], que cubre su dibujo) y la escena hace la misma transición que con una puerta.
     */
    private fun stairDoor(id: String, x: Float, seg: String, spawn: String): Door {
        val d = Door(id, x, F, target = DoorTarget(seg, spawn), panelColor = 0xFF14141A.toInt(), panelHatch = 0xFF000000.toInt(), playerUsable = false)
        d.visible = false
        return d
    }

    private fun stairSpot(id: String, door: Door, x: Float, w: Float, label: String): ScriptedSpot =
        ScriptedSpot(id, x, F - 100f, w, 100f, label, InteractionIcon.DOOR, 6f, null, null, null) { ctx ->
            if (!door.activate()) InteractionResult.IGNORED
            else {
                ctx.post(EventType.ON_DOOR_OPEN, door.id)
                InteractionResult.transition(door.target!!, door)
            }
        }

    /** Aparición junto a una puerta del lado IZQUIERDO de una estancia / del lado DERECHO. */
    private fun fromLeft(doorX: Float) = SpawnPoint(doorX + 57f, 1)
    private fun fromRight(doorX: Float) = SpawnPoint(doorX - 30f, -1)

    private fun box(x: Float, w: Float, h: Float, fill: Int, hatch: Int): WorldObject = Prop(x, F - h, w, h, fill, hatch)

    private fun wallPlate(x: Float, y: Float, w: Float, h: Float, fill: Int, hatch: Int): WorldObject =
        Prop(x, y, w, h, fill, hatch).also { it.layer = Layer.DECOR }

    private fun whenFlag(flag: String, o: WorldObject): WorldObject = StoryGate(o) { st -> st.has(flag) }

    private fun lamp(x: Float, cord: Float = 38f, radius: Float = 120f, intensity: Float = 0.9f, color: Int = WARM, flicker: Float = 0f) =
        Lamp(x, cord, radius, intensity, color, flicker)

    /** Muro que se abre cuando se cumple [flag]: antes es sólido (el niño no pasa), después desaparece. */
    private class FlagWall(x: Float, y: Float, w: Float, h: Float, private val flag: String) : WorldObject(x, y, w, h), NarrativeAware {
        init {
            collidable = true
            fillColor = 0xFF4A4038.toInt()
            hatchColor = 0xFF2A2420.toInt()
        }

        override fun onNarrative(story: StoryState) {
            val open = story.has(flag)
            collidable = !open
            visible = !open
        }
    }

    // ------------------------------------------------------------------ colores y estancias

    private fun gray(c: Int): Int {
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        val l = ((r * 0.30f + g * 0.59f + b * 0.11f) * 0.92f).toInt().coerceIn(0, 255)
        return (0xFF shl 24) or (l shl 16) or (l shl 8) or l
    }

    private class Mood(
        val wall: Int, val wallStroke: Int, val floor: Int, val floorStroke: Int,
        val wallPat: WallPattern, val floorPat: FloorPattern, val dark: Float, val darkColor: Int,
        val wallAccent: Int = 0xFFFFFFFF.toInt(), val floorAccent: Int = 0xFF000000.toInt()
    )

    private class Built(val normal: RoomSegment, val trauma: RoomSegment?)

    private fun cracks(width: Float): List<WorldObject> {
        val out = ArrayList<WorldObject>()
        val dark = 0xFF2A2A2A.toInt()
        for (k in 0 until 3) {
            val x = width * (0.22f + 0.30f * k)
            out.add(Prop(x, 6f, 2f, 60f + 14f * k, dark, dark).also { it.layer = Layer.DECOR })
        }
        return out
    }

    private fun seg(
        id: String, width: Float, camera: CameraMode, m: Mood, trauma: Boolean,
        objects: List<WorldObject>, doors: List<Door>, spawns: Map<String, SpawnPoint>, darkZones: List<DarkZone>
    ): RoomSegment {
        val lights = objects.filterIsInstance<Lamp>().map { it.light }
        return RoomSegment(
            id = id, width = width, floorY = F,
            leftBoundary = WALL, rightBoundary = width - WALL, cameraMode = camera,
            objects = objects, doors = doors, spawnPoints = spawns,
            lights = lights, darkZones = darkZones,
            ambientDark = if (trauma) (m.dark + 0.05f).coerceAtMost(0.97f) else m.dark,
            ambientColor = m.darkColor,
            wallColor = if (trauma) gray(m.wall) else m.wall,
            wallStrokeColor = if (trauma) gray(m.wallStroke) else m.wallStroke,
            floorColor = if (trauma) gray(m.floor) else m.floor,
            floorStrokeColor = if (trauma) gray(m.floorStroke) else m.floorStroke,
            wallPattern = m.wallPat, wallAccent = if (trauma) gray(m.wallAccent) else m.wallAccent,
            floorPattern = m.floorPat, floorAccent = if (trauma) gray(m.floorAccent) else m.floorAccent,
            worldMode = if (trauma) WorldMode.TRAUMA else WorldMode.NORMAL
        )
    }

    /** Estancia nueva: objetos y puertas compartidos + los propios de cada mundo. */
    private fun room(
        id: String, width: Float, camera: CameraMode, m: Mood, spawns: Map<String, SpawnPoint>,
        doors: List<Door>, shared: List<WorldObject>,
        onlyNormal: List<WorldObject> = emptyList(), onlyTrauma: List<WorldObject> = emptyList(),
        hasTrauma: Boolean = true
    ): Built {
        val dz = listOf(DarkZone(width - 50f, 0f, 38f, F, 0.3f))
        val n = seg(id, width, camera, m, false, shared + onlyNormal, doors, spawns, dz)
        val t = if (hasTrauma) seg(id, width, camera, m, true, shared + onlyTrauma + cracks(width), doors, spawns, dz) else null
        return Built(n, t)
    }

    /** Copia de una estancia de siempre: quita lo que sobra, cambia sus puertas, añade objetos; y su versión TRAUMA. */
    private fun extend(
        base: RoomSegment, newWidth: Float, removeObj: (WorldObject) -> Boolean,
        keepDoor: (Door) -> Boolean, addDoors: List<Door>, shared: List<WorldObject>,
        onlyNormal: List<WorldObject>, onlyTrauma: List<WorldObject>, addSpawns: Map<String, SpawnPoint>,
        camera: CameraMode? = null
    ): Built {
        // las ventanas-atajo eran provisionales de la casa de pruebas: fuera de TODAS las estancias
        val baseObjs = base.objects.filterNot { it is WindowPassage || removeObj(it) }
        val doors = base.doors.filter(keepDoor) + addDoors
        val spawns = HashMap<String, SpawnPoint>(base.spawnPoints)
        spawns.putAll(addSpawns)
        fun make(trauma: Boolean, extra: List<WorldObject>) = RoomSegment(
            id = base.id, width = newWidth, floorY = base.floorY, height = base.height,
            leftBoundary = base.leftBoundary, rightBoundary = if (newWidth != base.width) newWidth - WALL else base.rightBoundary,
            cameraMode = camera ?: base.cameraMode, objects = baseObjs + shared + extra, doors = doors, spawnPoints = spawns,
            lights = base.lights, darkZones = base.darkZones,
            ambientDark = if (trauma) (base.ambientDark + 0.05f).coerceAtMost(0.97f) else base.ambientDark,
            ambientColor = base.ambientColor,
            wallColor = if (trauma) gray(base.wallColor) else base.wallColor,
            wallStrokeColor = if (trauma) gray(base.wallStrokeColor) else base.wallStrokeColor,
            floorColor = if (trauma) gray(base.floorColor) else base.floorColor,
            floorStrokeColor = if (trauma) gray(base.floorStrokeColor) else base.floorStrokeColor,
            wallPattern = base.wallPattern, wallAccent = if (trauma) gray(base.wallAccent) else base.wallAccent,
            floorPattern = base.floorPattern, floorAccent = if (trauma) gray(base.floorAccent) else base.floorAccent,
            worldMode = if (trauma) WorldMode.TRAUMA else WorldMode.NORMAL
        )
        return Built(make(false, onlyNormal), make(true, onlyTrauma + cracks(newWidth)))
    }

    /**
     * v0.16: un escondite REAL (armario / ropero / gabinete de servicio) para cada habitación. Es el mismo [Wardrobe] de siempre
     * (entrar, ocultarse, esperar, salir), con aspecto distinto según el lugar. [kind]: 0 madera cálida, 1 azul frío,
     * 2 verde, 3 ciruela, 4 gabinete metálico de servicio, 5 blanco (habitación imposible).
     * v0.17: [type] es el tipo de escondite del contrato ([HideSpotType]) y [depth] su profundidad
     * (armario 0.45, cortinas 0.55, debajo de la cama 0.85). Los tipos nuevos no dibujan un mueble:
     * la cama / la cortina ya están en la habitación; el [Wardrobe] solo aporta la zona, el botón
     * («DEBAJO DE LA CAMA» / «TRAS LA CORTINA») y la máquina de esconderse.
     */
    private fun hide(id: String, x: Float, kind: Int, w: Float = 44f, type: HideSpotType = HideSpotType.CLOSET, depth: Float = Wardrobe.DEFAULT_DEPTH): Wardrobe {
        val st = when (kind) {
            0 -> WardrobeStyle(Palette.WARDROBE_WARM_BODY, Palette.WARDROBE_WARM_HATCH, Palette.WARDROBE_WARM_DOOR, Palette.WARDROBE_TRIM, 2, WardrobeDeco.STRIPES)
            1 -> WardrobeStyle(Palette.WARDROBE_COLD_BODY, Palette.WARDROBE_COLD_HATCH, Palette.WARDROBE_COLD_DOOR, Palette.WARDROBE_TRIM, 2, WardrobeDeco.MOON)
            2 -> WardrobeStyle(Palette.WARDROBE_GREEN_BODY, Palette.WARDROBE_GREEN_HATCH, Palette.WARDROBE_GREEN_DOOR, Palette.WARDROBE_TRIM, 1, WardrobeDeco.STAR)
            3 -> WardrobeStyle(Palette.WARDROBE_PLUM_BODY, Palette.WARDROBE_PLUM_HATCH, Palette.WARDROBE_PLUM_DOOR, Palette.WARDROBE_TRIM, 2, WardrobeDeco.NONE)
            4 -> WardrobeStyle(0xFF8A949A.toInt(), 0xCC5E686E.toInt(), 0xFFA3AEB4.toInt(), 0xFF3A4044.toInt(), 1, WardrobeDeco.STRIPES)
            else -> WardrobeStyle(0xFFD8D4CC.toInt(), 0xCCA8A49C.toInt(), 0xFFEAE6DE.toInt(), 0xFF6A665E.toInt(), 1, WardrobeDeco.NONE)
        }
        return Wardrobe(id, x, F, st, w, spotType = type, depth = depth)
    }

    private val none: (WorldObject) -> Boolean = { false }
    private val keepAll: (Door) -> Boolean = { true }
    private val dropHallDoors: (Door) -> Boolean = { it.target?.segmentId != HouseDefinition.HALL }

    // ------------------------------------------------------------------ la casa completa

    fun create(seed: Long = HouseDefinition.DEFAULT_SEED): SceneDefinition {
        val base = HouseDefinition.create(seed)
        val byId = base.segments.associateBy { it.id }
        fun b(id: String) = byId[id] ?: throw IllegalStateException("Falta el segmento $id")

        val built = ArrayList<Built>()
        built.add(hall(b(HouseDefinition.HALL)))
        built.add(kid(b(HouseDefinition.KID)))
        built.add(bath(b(HouseDefinition.BATH)))
        built.add(mom(b(HouseDefinition.MOM)))
        built.add(laundry(b(HouseDefinition.LAUNDRY)))
        built.add(kitchen(b(HouseDefinition.KITCHEN)))
        built.add(dining(b(HouseDefinition.DINING)))
        built.add(cellar(b(HouseDefinition.CELLAR)))
        built.add(foyer()); built.add(living()); built.add(pantry()); built.add(serviceBath())
        built.add(closet()); built.add(study()); built.add(electric()); built.add(boiler()); built.add(storage())
        built.add(roof()); built.add(impossible())

        return SceneDefinition(
            id = base.id, seed = base.seed, segments = built.map { it.normal },
            startSegmentId = base.startSegmentId, startSpawnId = base.startSpawnId,
            triggers = base.triggers, scripts = base.scripts, traumaSegments = built.mapNotNull { it.trauma },
            conversations = base.conversations, creature = base.creature, pointsOfInterest = base.pointsOfInterest
        )
    }

    // ================================================================== SEGUNDO PISO

    private const val HX_CLOSET = 460f
    private const val HX_STUDY = 590f
    private const val HX_STAIRS = 720f
    private const val HX_ROOF = 900f

    private fun hall(s: RoomSegment): Built {
        // fuera las puertas y rótulos de las habitaciones de otras plantas (cocina, comedor, lavandería, sótano)
        val remove: (WorldObject) -> Boolean = { o ->
            (o.y == 48f && (o.x == 465f || o.x == 595f || o.x == 725f || o.x == 865f)) ||
                (o is ExamineSpot && o.id == "ex_hall_frames") || o.x == 776f && o.y == 44f || o.x == 814f && o.y == 40f ||
                (o.x == 904f && o.width == 18f) ||
                (o is DrawnProp && o.x == 20f)   // v0.16: el perchero deja sitio al ropero de los abrigos
        }
        val keep: (Door) -> Boolean = {
            val t = it.target?.segmentId
            t == HouseDefinition.KID || t == HouseDefinition.BATH || t == HouseDefinition.MOM
        }
        val hallStairs = stairDoor("door_hall_stairs", HX_STAIRS, FOYER, "from_hall")
        val hallTrapdoor = stairDoor("door_hall_roof", HX_ROOF, ROOF, "from_hall")
        val doors = listOf(
            door("door_hall_closet", HX_CLOSET, CLOSET, "from_hall", 0xFF7A8A6A.toInt()),
            door("door_hall_study", HX_STUDY, "", "", 0xFF8A6A4A.toInt(), locked = true,
                text = "La puerta del estudio está cerrada con llave. No parece que la cerradura sea de este lado."),
            hallStairs, hallTrapdoor
        )
        val shared = ArrayList<WorldObject>()
        shared.add(ChapterProps.mainStairs(758f, false))
        shared.add(ChapterProps.trapdoorLadder(HX_ROOF - 40f))
        for (k in 0 until 4) shared.add(HouseProps.photoFrame(790f + k * 28f, 40f, 22f, 30f, k % 3))   // los cuatro retratos de N4
        shared.add(stairSpot("stairs_hall_down", hallStairs, HX_STAIRS + 6f, 140f, "BAJAR"))
        shared.add(stairSpot("trapdoor_hall_up", hallTrapdoor, HX_ROOF - 50f, 90f, "SUBIR"))
        shared.add(hide("wardrobe_hall", 14f, 3, 40f))
        shared.add(doc("doc_d05", "d05", 880f, 20f))
        shared.add(ex("ex_hall_light", 640f, 30f, "La luz del pasillo cambia pasado un rato. Esa va después de la cocina."))
        val normal = ArrayList<WorldObject>()
        normal.add(puzzle("spot_N4", "N4", 786f, 112f, "ALINEAR"))
        val trauma = ArrayList<WorldObject>()
        trauma.add(puzzle("spot_T3", "T3", 150f, 70f, "SEGUIR LA GRIETA"))
        trauma.add(observe("obs_T3", "T3", 300f, 40f,
            "Las puertas cambian de sitio, pero una grieta sigue siendo la misma: baja por el medio, se desvía a la izquierda y termina a la derecha."))
        trauma.add(doc("doc_d09", "d09", 240f, 24f))
        val spawns = mapOf(
            "from_closet" to fromLeft(HX_CLOSET), "from_foyer" to fromRight(HX_STAIRS), "from_roof" to SpawnPoint(HX_ROOF - 64f, -1)
        )
        return extend(s, s.width, remove, keep, doors, shared, normal, trauma, spawns)
    }

    private fun kid(s: RoomSegment): Built {
        val shared = ArrayList<WorldObject>()
        shared.addAll(ChapterProps.curtainedWindow(262f, 34f, 44f, 50f, Cr.CORAL, 0.07f).drop(1))   // cortinas movidas por la ventana rota
        shared.add(doc("doc_d01", "d01", 196f, 22f))
        shared.add(doc("doc_d19", "d19", 300f, 18f))
        // v0.17 ★S3: el baño es compartido con el dormitorio del niño (puerta interior junto a la del pasillo).
        // v0.17: escondite UNDER_BED a los pies de la cama (220-256; no tapa el doc d01 ni el d16) + su sombra.
        shared.add(ChapterProps.underBedShadow(148f, 96f))
        shared.add(hide("hide_underbed_kid", 220f, 2, 36f, HideSpotType.UNDER_BED, 0.85f))
        val normal = ArrayList<WorldObject>()
        normal.add(doc("doc_d04", "d04", 100f, 28f))
        normal.add(ex("ex_kid_shadows", 132f, 28f,
            "A: la sombra cruza media alfombra. B: apenas sale de la ventana. C: llega hasta el armario. D: se come todo el cuarto."))
        normal.add(sp("spot_N3", 330f, 40f, "ORDENAR", InteractionIcon.USE, ready) { ctx ->
            if (ctx.hasFlag(ChapterFlags.solved("N3"))) {
                InteractionResult.message("Los bordes de las hojas: inclinado a la izquierda, recto, muy inclinado a la izquierda, inclinado a la derecha.")
            } else InteractionResult.panel("N3")
        })
        normal.add(doc("doc_d16", "d16", 262f, 20f))
        val trauma = ArrayList<WorldObject>()
        trauma.add(doc("doc_d04t", "d04", 100f, 28f))
        return extend(s, s.width, none, keepAll,
            listOf(door("door_kid_bath", 58f, HouseDefinition.BATH, "from_kid", 0xFF7A9AB0.toInt())),
            shared, normal, trauma, mapOf("from_bath" to SpawnPoint(100f, 1)))
    }

    private fun bath(s: RoomSegment): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(ChapterProps.towelRack(250f))
        shared.add(sp("spot_mirror_fragment", 98f, 40f, "EXAMINAR", InteractionIcon.EXAMINE, null) { ctx ->
            if (!ctx.hasFlag(StoryFlags.SURVIVAL_READY)) InteractionResult.message("No me gusta ese espejo.")
            else if (!ctx.hasFlag(ChapterFlags.MIRROR_FRAGMENT_OBTAINED)) {
                ctx.setFlag(ChapterFlags.MIRROR_FRAGMENT_OBTAINED)
                InteractionResult.message("El espejo mostró un pasillo que no es este. Me llevo un trocito. Con él puedo cambiar de mundo (botón del espejo).")
            } else InteractionResult.message("Mi reflejo termina el gesto un poquito tarde.")
        })
        // C3: el vaso con agua se deja en el lavabo y se observa en NORMAL y en TRAUMA
        shared.add(whenFlag(ChapterFlags.GLASS_PLACED, Prop(206f, F - 56f, 9f, 13f, Cr.GLASS, Cr.BLUE)))
        shared.add(sp("spot_glass_bath", 190f, 44f, "VASO", InteractionIcon.USE, null) { ctx ->
            val trauma = ctx.state.worldMode == WorldMode.TRAUMA
            when {
                !ctx.hasFlag(StoryFlags.SURVIVAL_READY) -> InteractionResult.message("El grifo del baño gotea.")
                ctx.hasFlag(ChapterFlags.GLASS_PLACED) -> {
                    ctx.setFlag(if (trauma) ChapterFlags.OBS_C3_T else ChapterFlags.OBS_C3_N)
                    if (ctx.hasFlag(ChapterFlags.OBS_C3_N) && ctx.hasFlag(ChapterFlags.OBS_C3_T)) ctx.setFlag(ChapterFlags.observed("C3"))
                    InteractionResult.message(
                        if (trauma) "El reflejo se rompe en una figura que señala hacia abajo: al fondo del sótano, la pared más baja, el tercer panel contando desde la izquierda."
                        else "El agua está quieta. Veo la lámpara del baño y, dentro del vaso, también el techo."
                    )
                }
                ctx.held == ItemRegistry.WATER_GLASS -> InteractionResult.give(ItemRegistry.WATER_GLASS) { c ->
                    c.setFlag(ChapterFlags.GLASS_PLACED)
                    InteractionResult.message("Dejo el vaso sobre el lavabo, muy quieto. Ahora puedo mirar el agua.")
                }
                else -> InteractionResult.message("Necesito un vaso con agua. En la cocina hay.")
            }
        })
        shared.add(hide("wardrobe_bath", 330f, 1, 40f))
        return extend(s, 400f, { it is ExamineSpot && it.id == "ex_bath_mirror" }, keepAll,
            listOf(
                // v0.17 ★S3: baño compartido — puerta al dormitorio del niño (izquierda) y al de mamá (derecha).
                door("door_bath_kid", 60f, HouseDefinition.KID, "from_bath", 0xFF7A9AB0.toInt()),
                door("door_bath_mom", 290f, HouseDefinition.MOM, "from_bath", 0xFF9A7AA8.toInt())
            ),
            shared, emptyList(), emptyList(),
            mapOf("from_kid" to fromLeft(60f), "from_mom" to fromRight(290f)), CameraMode.SIDE_SCROLLING)
    }

    private fun mom(s: RoomSegment): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(doc("doc_d17", "d17", 322f, 30f))
        shared.add(doc("doc_d20", "d20", 130f, 20f))
        shared.add(doc("doc_d22", "d22", 250f, 18f))
        // v0.17: escondite UNDER_BED a los pies de la cama de mamá (200-240; no tapa el doc d22) + su sombra.
        shared.add(ChapterProps.underBedShadow(140f, 118f))
        shared.add(hide("hide_underbed_mom", 200f, 3, 40f, HideSpotType.UNDER_BED, 0.85f))
        val normal = ArrayList<WorldObject>()
        normal.add(sp("spot_N2", 76f, 50f, "DISCOS", InteractionIcon.USE, ready) { ctx ->
            if (ctx.hasFlag(ChapterFlags.solved("N2"))) InteractionResult.document("d14a") else InteractionResult.panel("N2")
        })
        val trauma = ArrayList<WorldObject>()
        trauma.add(puzzle("spot_T2", "T2", 206f, 48f, "PIEZAS"))
        trauma.add(doc("doc_d08", "d08", 176f, 24f))
        trauma.add(ex("ex_mom_portrait_gaps", 280f, 24f,
            "Los huecos del retrato: uno con una esquina, uno con cuatro brazos, uno de borde curvo y uno largo y delgado."))
        // v0.17: la habitación crece de 440 a 500 para que quepa la puerta del baño compartido (★S3) al fondo, sin mover la cama ni el armario.
        return extend(s, 500f, none, keepAll,
            listOf(door("door_mom_bath", 452f, HouseDefinition.BATH, "from_mom", 0xFF9A7AA8.toInt())),
            shared, normal, trauma, mapOf("from_bath" to SpawnPoint(440f, 1)))
    }

    private val closetMood = Mood(0xFFCDBFAA.toInt(), 0xFFA89880.toInt(), 0xFF8A6E4E.toInt(), 0xFF624A32.toInt(),
        WallPattern.PLAIN, FloorPattern.WOOD, 0.86f, Palette.DARK_DEEP)

    private fun closet(): Built {
        val doors = listOf(door("door_closet_hall", 24f, HouseDefinition.HALL, "from_closet", 0xFF7A8A6A.toInt()))
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(160f, 50f, 100f, 0.7f, WARM))
        // v0.18 Fran Bow: la escalera plegable se mueve al extremo derecho y pasa a primer plano:
        // enmarca el armario y tapa al niño al pasar por detrás.
        shared.add(ChapterProps.ladderFold(440f).also { it.layer = Layer.FOREGROUND })
        shared.add(HouseProps.crateStack(100f))
        shared.add(box(200f, 30f, 60f, 0xFF8A7A66.toInt(), 0xFF5E5040.toInt()))
        shared.add(ChapterProps.hangingCoat(230f))
        shared.add(doc("doc_d12", "d12", 70f, 30f))
        // C2: la pared que comparte con el estudio se abre (conexión secreta)
        shared.add(whenFlag(ChapterFlags.solved("C2"), Prop(326f, F - 76f, 34f, 76f, 0xFF1E1812.toInt(), 0xFF000000.toInt())))
        shared.add(sp("closet_secret_study", 326f, 34f, "AL ESTUDIO", InteractionIcon.DOOR, { it.hasFlag(ChapterFlags.solved("C2")) }) { ctx ->
            ctx.post(EventType.ON_DOOR_OPEN, "closet_secret_study")
            InteractionResult.transition(DoorTarget(STUDY, "from_closet"))
        })
        shared.add(whenFlag(ChapterFlags.HOUSE_EXIT_UNLOCKED, Prop(266f, F - 76f, 34f, 76f, 0xFF101010.toInt(), 0xFF000000.toInt())))
        shared.add(sp("closet_to_impossible", 266f, 34f, "PUERTA SIN MARCO", InteractionIcon.DOOR, { it.hasFlag(ChapterFlags.HOUSE_EXIT_UNLOCKED) }) { ctx ->
            ctx.post(EventType.ON_DOOR_OPEN, "closet_to_impossible")
            InteractionResult.transition(DoorTarget(IMPOSSIBLE, "from_closet"))
        })
        shared.add(sp("spot_C2_box", 140f, 56f, "EXAMINAR CAJA", InteractionIcon.EXAMINE,
            { it.hasFlag(StoryFlags.SURVIVAL_READY) && !it.hasFlag(ChapterFlags.solved("C2")) }) { ctx ->
            if (ctx.state.worldMode == WorldMode.TRAUMA) {
                ctx.setFlag(ChapterFlags.observed("C2"))
                InteractionResult.message("Las huellas entran en la pared por la derecha. El símbolo del retrato está girado, como la marca del estudio.")
            } else InteractionResult.panel("C2")
        })
        shared.add(ex("ex_closet_wall", 330f, 30f, "Del otro lado de esta pared está el estudio. Se oye vacío."))
        val normal = listOf<WorldObject>(ex("ex_closet_prints", 60f, 50f, "Unas huellas terminan frente a la caja. Las mías."))
        val trauma = listOf<WorldObject>(ex("ex_closet_symbol", 200f, 30f, "Una marca de tres líneas y un punto, girada."))
        shared.add(hide("wardrobe_closet", 392f, 3))
        return room(CLOSET, 460f, CameraMode.SIDE_SCROLLING, closetMood, mapOf("from_hall" to fromLeft(24f), "from_study" to fromRight(326f)), doors, shared, normal, trauma)
    }

    private val studyMood = Mood(0xFFD6CCB8.toInt(), 0xFFB0A48C.toInt(), 0xFF7E6446.toInt(), 0xFF584632.toInt(),
        WallPattern.PLAIN, FloorPattern.WOOD, 0.84f, Palette.DARK_WARM)

    private fun study(): Built {
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(170f, 40f, 120f, 0.8f, WARM))
        // v0.18 Fran Bow: cortinas LARGAS hasta el suelo en primer plano (ver ChapterProps).
        shared.addAll(ChapterProps.curtainedWindow(96f, 36f, 34f, 44f, Cr.LILAC, 0.02f, long = true))
        shared.add(ChapterProps.deskStudy(150f))
        shared.add(HouseProps.bookshelf(262f, 44f, 60f))
        shared.add(HouseProps.crateStack(300f))
        shared.add(whenFlag(ChapterFlags.solved("C2"), Prop(20f, F - 76f, 34f, 76f, 0xFF1E1812.toInt(), 0xFF000000.toInt())))
        shared.add(sp("study_secret_closet", 20f, 34f, "AL ARMARIO", InteractionIcon.DOOR, null) { ctx ->
            ctx.post(EventType.ON_DOOR_OPEN, "study_secret_closet")
            InteractionResult.transition(DoorTarget(CLOSET, "from_study"))
        })
        shared.add(sp("spot_C4", 150f, 80f, "CARTA", InteractionIcon.USE, ready) { ctx ->
            if (ctx.hasFlag(ChapterFlags.solved("C4"))) InteractionResult.document("d14c") else InteractionResult.panel("C4")
        })
        // v0.17: escondite CURTAINS tras la cortina de la ventana (94-130; la ventana está en 96-130).
        shared.add(hide("hide_curtains_study", 94f, 1, 36f, HideSpotType.CURTAINS, 0.55f))
        val trauma = listOf<WorldObject>(
            // v0.16: la segunda mitad de la carta es ahora un papel VISIBLE en el suelo; leerla la guarda en las manos del niño (flag)
            doc("doc_d14b", "d14b", 100f, 22f) { ctx -> ctx.setFlag(ChapterFlags.GOT_LETTER_B) },
            doc("doc_d21", "d21", 270f, 30f),
            ex("ex_study_margin", 200f, 30f, "Los trazos del margen de la carta: un zigzag, un rectángulo y una línea alta."),
            ex("ex_study_antenna_drawing", 230f, 30f, "Un dibujo infantil de la antena: brazo corto → ventana iluminada, brazo medio → línea quebrada, brazo largo → torre oscura.")
        )
        shared.add(hide("wardrobe_study", 360f, 0))
        return room(STUDY, 440f, CameraMode.SIDE_SCROLLING, studyMood, mapOf("from_closet" to fromLeft(20f)), emptyList(), shared, emptyList(), trauma)
    }

    private val roofMood = Mood(0xFF8AA0B8.toInt(), 0xFF6A809A.toInt(), 0xFF5A5E66.toInt(), 0xFF3E4248.toInt(),
        WallPattern.PLAIN, FloorPattern.CONCRETE, 0.55f, Palette.DARK_COLD)

    private fun roof(): Built {
        val roofLadder = stairDoor("door_roof_hall", 24f, HouseDefinition.HALL, "from_roof")
        val doors = listOf(roofLadder)
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(300f, 36f, 140f, 0.55f, COLD))
        shared.add(ChapterProps.roofParapet(0f, 500f))
        shared.add(hide("wardrobe_roof", 436f, 4, 40f))
        shared.add(ChapterProps.ladderFold(26f))
        shared.add(stairSpot("trapdoor_roof_down", roofLadder, 10f, 60f, "BAJAR"))
        shared.add(ChapterProps.waterTank(70f))
        // v0.18 Fran Bow: la chimenea pasa a primer plano: enmarca la azotea y tapa al niño al pasar por detrás.
        shared.add(ChapterProps.chimney(366f).also { it.layer = Layer.FOREGROUND })
        shared.add(ChapterProps.antennaMast(186f))
        shared.add(ChapterProps.flutterPapers(300f, F - 20f))
        shared.add(ex("ex_roof_antenna", 190f, 44f, "La antena tiene tres brazos que giran. A lo lejos: una ventana iluminada, una torre oscura y una línea quebrada."))
        shared.add(ex("ex_roof_tank", 72f, 56f, "El tanque de agua. Mamá dice que si lo golpeas suena a hueco."))
        val normal = listOf<WorldObject>(
            observe("obs_C5", "C5", 300f, 50f,
                "Desde aquí veo una luz fija en una ventana del distribuidor, la que dejé estable en el sótano. Su línea cruza la sombra de la antena.",
                needs = ChapterFlags.solved("N5"), missing = "Desde aquí no veo ninguna luz fija. Quizá si la luz del sótano estuviera estable.")
        )
        val trauma = listOf<WorldObject>(
            puzzle("spot_T5", "T5", 150f, 40f, "GIRAR BRAZOS"),
            doc("doc_d11", "d11", 110f, 24f),
            ex("ex_roof_drawing", 250f, 30f, "El dibujo de la antena: brazo corto → ventana iluminada, brazo medio → línea quebrada, brazo largo → torre oscura."),
            puzzle("spot_C5", "C5", 220f, 40f, "ARANDELA")
        )
        return room(ROOF, 500f, CameraMode.SIDE_SCROLLING, roofMood, mapOf("from_hall" to SpawnPoint(90f, 1)), doors, shared, normal, trauma)
    }

    private val impossibleMood = Mood(0xFFE8E4DC.toInt(), 0xFFC8C4BC.toInt(), 0xFFD0CCC4.toInt(), 0xFFB0ACA4.toInt(),
        WallPattern.PLAIN, FloorPattern.CONCRETE, 0.45f, Palette.DARK_COLD)

    private fun impossible(): Built {
        val doors = listOf(door("door_impossible_exit", 240f, FOYER, "from_impossible", 0xFF3A3A44.toInt()))
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(150f, 30f, 150f, 0.95f, PALE))
        shared.add(ChapterProps.impossibleWindow(100f))
        shared.add(hide("wardrobe_impossible", 180f, 5, 40f))
        shared.add(ex("ex_impossible_window", 100f, 70f, "La ventana no da a la calle. Da a una pared de esta misma casa, desde un ángulo que no existe."))
        return room(IMPOSSIBLE, 300f, CameraMode.FIXED, impossibleMood, mapOf("from_closet" to SpawnPoint(70f, 1)), doors, shared, hasTrauma = false)
    }

    // ================================================================== PLANTA BAJA
    // v0.17: el vestíbulo (Foyer) es el HUB, pero ya no es el único camino: comedor↔cocina (★S1) y
    // despensa↔baño de servicio (★S5) cierran una vuelta por la parte trasera, así que se puede
    // rodear la planta sin volver por el pasillo principal. La despensa cuelga de la cocina y
    // comunica en secreto con la sala (C1).

    private const val GX_MAIN = 50f
    private const val GX_STAIRS = 170f
    private const val GX_LIVING = 330f
    private const val GX_DINING = 460f
    private const val GX_KITCHEN = 590f
    private const val GX_BATH = 720f
    private const val GX_BACK = 800f
    private const val GX_SERVICE = 900f

    private val foyerMood = Mood(0xFFE6D6B8.toInt(), 0xFFC4B08C.toInt(), 0xFF9A7A56.toInt(), 0xFF6E5438.toInt(),
        WallPattern.STRIPES, FloorPattern.WOOD, 0.80f, Palette.DARK_WARM, 0xFFB09870.toInt(), 0xFF4A3322.toInt())

    private fun foyer(): Built {
        val dark = 0xFF14141A.toInt()
        val stairsUp = stairDoor("door_gf_stairs_up", GX_STAIRS, HouseDefinition.HALL, "from_foyer")
        val stairsDown = stairDoor("door_gf_service_stairs", GX_SERVICE, HouseDefinition.CELLAR, "from_service")
        val doors = listOf(
            stairsUp,
            door("door_gf_living", GX_LIVING, LIVING, "from_corridor", 0xFF8A6A5A.toInt()),
            door("door_gf_dining", GX_DINING, HouseDefinition.DINING, "from_corridor", 0xFF9A7A5A.toInt()),
            door("door_gf_kitchen", GX_KITCHEN, HouseDefinition.KITCHEN, "from_corridor", 0xFF8A7A5A.toInt()),
            door("door_gf_bath", GX_BATH, SERVICE_BATH, "from_corridor", 0xFF7A8A9A.toInt()),
            door("door_gf_back", GX_BACK, "", "", 0xFF5A4A3A.toInt(), locked = true,
                text = "La puerta trasera tiene la llave echada. Mamá nunca la deja puesta."),
            stairsDown
        )
        val shared = ArrayList<WorldObject>()
        // v0.18: la alfombra queda centrada en la sala (antes corrida a la derecha)
        shared.add(HouseProps.rug(380f, 220f, 0xFFC87050.toInt(), 0xFF8A4A30.toInt()))
        // puerta principal al frente (cerrada hasta el final del capítulo)
        shared.add(Prop(GX_MAIN, F - 82f, 44f, 82f, 0xFF7A3A30.toInt(), 0xFF4A2018.toInt()).also { it.layer = Layer.DECOR })
        // v0.18 Fran Bow: marcos de primer plano en el vestíbulo (perchero, paragüero y cubo)
        shared.add(HouseProps.coatRack(110f).also { it.layer = Layer.FOREGROUND })
        shared.add(HouseProps.umbrellaStand(136f).also { it.layer = Layer.FOREGROUND })
        // escalera principal: sube a la derecha de su puerta; el niño llega al pie desde arriba
        shared.add(ChapterProps.mainStairs(GX_STAIRS + 38f, true))
        shared.add(HouseProps.photoFrame(400f, 34f, 36f, 28f, 1))
        shared.add(HouseProps.photoFrame(530f, 34f, 30f, 26f, 0))
        shared.add(HouseProps.photoFrame(660f, 34f, 34f, 28f, 2))
        shared.add(ChapterProps.serviceStairsDown(GX_SERVICE - 50f))
        shared.add(ChapterProps.mopBucket(760f).also { it.layer = Layer.FOREGROUND })
        shared.add(ChapterProps.hangingCoat(838f))
        shared.add(lamp(120f, 40f, 130f, 0.9f, WARM))
        shared.add(lamp(420f, 40f, 130f, 0.8f, WARM))
        shared.add(lamp(700f, 40f, 120f, 0.75f, WARM, 0.03f))
        shared.add(lamp(870f, 40f, 110f, 0.6f, WARM, 0.05f))
        shared.add(sp("foyer_main_door", GX_MAIN, 44f, "PUERTA", InteractionIcon.DOOR, ready) { ctx ->
            if (ctx.hasFlag(ChapterFlags.HOUSE_EXIT_UNLOCKED)) {
                ctx.post(EventType.ON_DOOR_OPEN, "foyer_main_door")
                ctx.setFlag("house_exit_used")
                InteractionResult.message("La puerta está libre. Salgo.")
            } else InteractionResult.message("La puerta no se abre. La cerradura y el marco no coinciden.")
        })
        shared.add(hide("wardrobe_foyer", 385f, 0))
        shared.add(ex("ex_foyer_light", 100f, 40f, "La lámpara del vestíbulo zumba siempre igual. Esa va primero."))
        shared.add(stairSpot("stairs_foyer_up", stairsUp, GX_STAIRS - 6f, 150f, "SUBIR"))
        shared.add(stairSpot("stairs_service_down", stairsDown, GX_SERVICE - 60f, 100f, "BAJAR"))
        val spawns = mapOf(
            "from_hall" to SpawnPoint(GX_STAIRS - 40f, -1), "from_living" to fromLeft(GX_LIVING), "from_dining" to fromLeft(GX_DINING),
            "from_kitchen" to fromLeft(GX_KITCHEN), "from_bath" to fromLeft(GX_BATH), "from_cellar" to SpawnPoint(GX_SERVICE - 80f, -1),
            "from_impossible" to SpawnPoint(250f, 1)
        )
        return room(FOYER, 980f, CameraMode.SIDE_SCROLLING, foyerMood, spawns, doors, shared)
    }

    private val livingMood = Mood(0xFFD8E0C8.toInt(), 0xFFB0BC98.toInt(), 0xFFA88458.toInt(), 0xFF7A5C38.toInt(),
        WallPattern.PLAIN, FloorPattern.WOOD, 0.80f, Palette.DARK_WARM)

    private fun living(): Built {
        val doors = listOf(door("door_living_corridor", 24f, FOYER, "from_living", 0xFF8A6A5A.toInt()))
        val shared = ArrayList<WorldObject>()
        shared.add(HouseProps.rug(110f, 170f, 0xFF5A7AA0.toInt(), 0xFF38527A.toInt()))
        shared.add(lamp(180f, 38f, 140f, 0.85f, WARM))
        shared.add(ChapterProps.tvSet(76f))
        shared.add(ChapterProps.coffeeTable(146f))
        shared.add(ChapterProps.sofa(200f))
        // v0.18 Fran Bow: cortinas LARGAS hasta el suelo en primer plano (ver ChapterProps):
        // enmarcan la ventana y tapan al niño al pasar por detrás.
        shared.addAll(ChapterProps.curtainedWindow(320f, 34f, 34f, 46f, Cr.MINT, 0.03f, long = true))
        shared.add(HouseProps.photoFrame(130f, 30f, 40f, 30f, 0))
        // v0.17: el armario se mueve al fondo (440) para dejar libre la ventana; la sala crece de 440 a 500.
        shared.add(hide("wardrobe_living", 440f, 3, 42f))
        // v0.17: escondite CURTAINS tras la cortina de la ventana (318-354).
        shared.add(hide("hide_curtains_living", 318f, 1, 36f, HideSpotType.CURTAINS, 0.55f))
        shared.add(ex("ex_living_tv", 76f, 48f, "El televisor está apagado."))
        shared.add(ex("ex_living_sofa", 200f, 100f, "El sofá tiene una manta doblada. Mamá se dormía aquí viendo la tele."))
        // C1: la pared del fondo comparte muro con la despensa
        shared.add(whenFlag(ChapterFlags.solved("C1"), Prop(386f, F - 70f, 36f, 70f, 0xFF2A2018.toInt(), 0xFF000000.toInt())))
        shared.add(sp("living_secret_pantry", 386f, 36f, "PASO ESTRECHO", InteractionIcon.DOOR, { it.hasFlag(ChapterFlags.solved("C1")) }) { ctx ->
            ctx.post(EventType.ON_DOOR_OPEN, "living_secret_pantry")
            InteractionResult.transition(DoorTarget(PANTRY, "from_living"))
        })
        shared.add(sp("spot_C1_wall", 380f, 48f, "EXAMINAR PARED", InteractionIcon.EXAMINE, { it.hasFlag(StoryFlags.SURVIVAL_READY) && !it.hasFlag(ChapterFlags.solved("C1")) }) { ctx ->
            if (ctx.state.worldMode == WorldMode.TRAUMA) {
                ctx.setFlag(ChapterFlags.observed("C1"))
                InteractionResult.message("Las tres grietas son hendiduras de un marco. De izquierda a derecha: una alta, una baja y una a media altura.")
            } else InteractionResult.panel("C1")
        })
        val spawns = mapOf("from_corridor" to fromLeft(24f), "from_pantry" to SpawnPoint(350f, -1))
        return room(LIVING, 500f, CameraMode.SIDE_SCROLLING, livingMood, spawns, doors, shared)
    }

    private fun dining(s: RoomSegment): Built {
        val doors = listOf(
            door("door_dining_corridor", 24f, FOYER, "from_dining", 0xFF9A6A5A.toInt()),
            // v0.17 ★S1: puerta directa a la cocina (la vuelta de la planta baja: Foyer→Dining→Kitchen→Foyer).
            door("door_dining_kitchen", 92f, HouseDefinition.KITCHEN, "from_dining", 0xFF8A7A5A.toInt())
        )
        val shared = ArrayList<WorldObject>()
        shared.add(ex("ex_dining_third_chair", 100f, 22f, "La silla pequeña casi siempre está arrimada a la pared."))
        val normal = ArrayList<WorldObject>()
        normal.add(doc("doc_d02", "d02", 128f, 24f))
        normal.add(puzzle("spot_N1", "N1", 176f, 24f, "ARREGLAR MESA"))
        normal.add(ex("ex_dining_plate", 222f, 24f, "Mi plato es liso. El que tiene una muesca es el de mamá."))
        shared.add(hide("wardrobe_dining", 444f, 0))
        return extend(s, 520f, none, dropHallDoors, doors, shared, normal, emptyList(),
            mapOf("from_corridor" to fromLeft(24f), "from_kitchen" to fromRight(92f)))
    }

    private fun kitchen(s: RoomSegment): Built {
        val doors = listOf(
            door("door_kitchen_corridor", 24f, FOYER, "from_kitchen", 0xFF8A7A5A.toInt()),
            door("door_kitchen_pantry", 452f, PANTRY, "from_kitchen", 0xFF8A7A5A.toInt()),
            // v0.17 ★S1: puerta directa al comedor (la vuelta de la planta baja).
            door("door_kitchen_dining", 486f, HouseDefinition.DINING, "from_kitchen", 0xFF8A7A5A.toInt())
        )
        val shared = ArrayList<WorldObject>()
        // v0.18 Fran Bow: el cubo de la fregona pasa a primer plano (enmarca el lado de la despensa).
        shared.add(ChapterProps.mopBucket(430f).also { it.layer = Layer.FOREGROUND })
        shared.add(ex("ex_kitchen_cup", 312f, 22f, "La taza azul tiene una marca en el borde. Alguien bebió de ahí."))
        // v0.16: tras el apagón el foco de la cocina está reventado: la PISTA (el orden de N5) se conserva intacta
        shared.add(sp("ex_kitchen_lamp", 214f, 30f, "EXAMINAR", InteractionIcon.EXAMINE, null) { ctx ->
            if (ctx.state.blackoutDone) InteractionResult.message("El foco de la cocina reventó. Pero antes tardaba en estabilizarse. Esa va después de la del vestíbulo.")
            else InteractionResult.message("La lámpara de la cocina tarda en estabilizarse. Esa va después de la del vestíbulo.")
        })
        shared.add(doc("doc_d15", "d15", 410f, 22f))
        shared.add(doc("doc_d18", "d18", 62f, 14f))
        shared.add(doc("doc_d03", "d03", 258f, 20f))
        shared.add(glassSink())
        val spawns = mapOf("from_corridor" to fromLeft(24f), "from_pantry" to fromRight(452f), "from_dining" to SpawnPoint(500f, -1))
        shared.add(hide("wardrobe_kitchen", 520f, 2))
        return extend(s, 600f, { it is ScriptedSpot && it.id == HouseDefinition.SPOT_SINK }, dropHallDoors, doors, shared, emptyList(), emptyList(), spawns)
    }

    /** El fregadero de siempre (agua para mamá) y, ya tras la introducción, el agua del vaso de C3. */
    private fun glassSink(): ScriptedSpot = ScriptedSpot(
        HouseDefinition.SPOT_SINK, 160f, F - 60f, 44f, 60f, "USAR", InteractionIcon.USE, 6f,
        promptProvider = { ctx ->
            val intro = ctx.hasFlag(StoryFlags.HEARD_WATER) && !ctx.hasFlag(StoryFlags.GOT_WATER) && !ctx.hasFlag(StoryFlags.WATER_DELIVERED)
            val chapter = ctx.hasFlag(StoryFlags.WATER_DELIVERED) && ctx.hasFlag(StoryFlags.SURVIVAL_READY) &&
                !ctx.hasFlag(ChapterFlags.GOT_GLASS) && !ctx.hasFlag(ChapterFlags.GLASS_PLACED)
            if (intro || chapter) "TOMAR AGUA" else "USAR"
        },
        iconProvider = { ctx ->
            val intro = ctx.hasFlag(StoryFlags.HEARD_WATER) && !ctx.hasFlag(StoryFlags.GOT_WATER) && !ctx.hasFlag(StoryFlags.WATER_DELIVERED)
            val chapter = ctx.hasFlag(StoryFlags.WATER_DELIVERED) && ctx.hasFlag(StoryFlags.SURVIVAL_READY) &&
                !ctx.hasFlag(ChapterFlags.GOT_GLASS) && !ctx.hasFlag(ChapterFlags.GLASS_PLACED)
            if (intro || chapter) InteractionIcon.PICK else InteractionIcon.USE
        }
    ) { ctx ->
        when {
            ctx.hasFlag(StoryFlags.WATER_DELIVERED) -> when {
                !ctx.hasFlag(StoryFlags.SURVIVAL_READY) -> InteractionResult.message("Ya le llevé agua a mamá.")
                ctx.hasFlag(ChapterFlags.GLASS_PLACED) -> InteractionResult.message("Ya dejé el vaso en el baño de arriba. Aquí el grifo gotea.")
                ctx.hasFlag(ChapterFlags.GOT_GLASS) -> InteractionResult.message("Ya tengo el vaso con agua. Tengo que llevarlo arriba, al baño, sin derramarlo.")
                ctx.held != null -> InteractionResult.message("Tengo las manos ocupadas.")
                else -> InteractionResult.pickup(ItemRegistry.WATER_GLASS) { c ->
                    c.setFlag(ChapterFlags.GOT_GLASS)
                    InteractionResult.document("d13")
                }
            }
            ctx.hasFlag(StoryFlags.GOT_WATER) -> InteractionResult.message("Ya tengo el vaso con agua para mamá.")
            !ctx.hasFlag(StoryFlags.HEARD_WATER) -> InteractionResult.message("El grifo gotea. Plic, plic.")
            ctx.held != null -> InteractionResult.message("Tengo las manos ocupadas.")
            else -> InteractionResult.pickup(ItemRegistry.WATER_GLASS) { c ->
                c.setFlag(StoryFlags.GOT_WATER)
                InteractionResult.message("Lleno un vaso con agua. No lo derramo.")
            }
        }
    }

    private val pantryMood = Mood(0xFFD0C4A8.toInt(), 0xFFA89C80.toInt(), 0xFF8A7656.toInt(), 0xFF605038.toInt(),
        WallPattern.PLANKS, FloorPattern.WOOD, 0.86f, Palette.DARK_DEEP)

    private fun pantry(): Built {
        val doors = listOf(
            door("door_pantry_kitchen", 24f, HouseDefinition.KITCHEN, "from_pantry", 0xFF8A7A5A.toInt()),
            // v0.17 ★S5: puerta de servicio al baño de servicio (la zona de servicio tiene su propia vuelta).
            door("door_pantry_svcbath", 160f, SERVICE_BATH, "from_pantry", 0xFF7A8A8A.toInt())
        )
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(150f, 50f, 100f, 0.75f, WARM, 0.06f))
        shared.add(ChapterProps.pantryShelves(60f, 64f))
        // v0.18 Fran Bow: la estantería pequeña pasa a primer plano: enmarca la despensa y tapa
        // al niño al pasar por detrás (la grande, junto a la puerta, queda en el medio).
        shared.add(ChapterProps.pantryShelves(212f, 40f).also { it.layer = Layer.FOREGROUND })
        shared.add(whenFlag(ChapterFlags.solved("C1"), Prop(252f, F - 70f, 36f, 70f, 0xFF2A2018.toInt(), 0xFF000000.toInt())))
        shared.add(sp("pantry_secret_living", 252f, 36f, "PASO ESTRECHO", InteractionIcon.DOOR, { it.hasFlag(ChapterFlags.solved("C1")) }) { ctx ->
            ctx.post(EventType.ON_DOOR_OPEN, "pantry_secret_living")
            InteractionResult.transition(DoorTarget(LIVING, "from_pantry"))
        })
        shared.add(ex("ex_pantry_wall", 252f, 36f, "La pared del fondo es la de la sala. Se oye la tele apagada del otro lado."))
        val normal = listOf<WorldObject>(ex("ex_pantry_cracks", 140f, 70f, "En la pared hay grietas finas. Parecen defectos de la pintura."))
        val trauma = listOf<WorldObject>(doc("doc_d07", "d07", 100f, 30f), puzzle("spot_T1", "T1", 140f, 70f, "PLACAS"))
        val spawns = mapOf("from_kitchen" to fromLeft(24f), "from_living" to SpawnPoint(222f, -1), "from_svcbath" to fromRight(160f))
        shared.add(hide("wardrobe_pantry", 310f, 2, 40f))
        return room(PANTRY, 380f, CameraMode.SIDE_SCROLLING, pantryMood, spawns, doors, shared, normal, trauma)
    }

    private val svcMood = Mood(0xFFDCE6EA.toInt(), 0xFFB4C6CE.toInt(), 0xFFC4D2D6.toInt(), 0xFFA0B2B8.toInt(),
        WallPattern.TILES, FloorPattern.TILES, 0.74f, Palette.DARK_COLD)

    private fun serviceBath(): Built {
        val doors = listOf(
            door("door_svc_corridor", 24f, FOYER, "from_bath", 0xFF7A8A9A.toInt()),
            // v0.17 ★S5: puerta de servicio a la despensa (el baño de servicio deja de ser un callejón sin salida).
            door("door_svc_pantry", 220f, PANTRY, "from_svcbath", 0xFF7A8A8A.toInt())
        )
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(130f, 32f, 110f, 0.95f, PALE))
        shared.add(HouseProps.bathSink(80f))
        // v0.18 Fran Bow: el váter pasa a primer plano: enmarca el baño de servicio.
        shared.add(HouseProps.toilet(150f).also { it.layer = Layer.FOREGROUND })
        shared.add(ChapterProps.towelRack(200f))
        shared.add(ex("ex_svc_note", 80f, 44f, "Una nota: «Limpiar las manchas pequeñas y recoger lo que se cae cuando mamá no puede levantarse». Es mi letra."))
        shared.add(ex("ex_svc_mirror", 110f, 24f, "Este espejo es normal. Solo me refleja a mí."))
        shared.add(hide("wardrobe_svcbath", 268f, 4, 40f))
        return room(SERVICE_BATH, 340f, CameraMode.SIDE_SCROLLING, svcMood, mapOf("from_corridor" to fromLeft(24f), "from_pantry" to fromRight(220f)), doors, shared)
    }

    // ================================================================== SÓTANO

    private val basementMood = Mood(0xFF8A8294.toInt(), 0xFF5E566E.toInt(), 0xFF6A6672.toInt(), 0xFF46424E.toInt(),
        WallPattern.PLANKS, FloorPattern.CONCRETE, 0.88f, Palette.DARK_DEEP)

    private fun laundry(s: RoomSegment): Built {
        val doors = listOf(
            door("door_laundry_cellar", 24f, HouseDefinition.CELLAR, "from_laundry", 0xFF6A8A8A.toInt()),
            // v0.17 ★S2: la lavandería comunica con el cuarto eléctrico (vuelta del sótano).
            door("door_laundry_electric", 58f, ELECTRIC, "from_laundry", 0xFF6A7A8A.toInt())
        )
        val shared = ArrayList<WorldObject>()
        shared.add(ChapterProps.puddle(120f, 40f))
        shared.add(ChapterProps.drip(150f, 20f))
        return extend(s, s.width, none, dropHallDoors, doors, shared, emptyList(), emptyList(),
            mapOf("from_cellar" to fromLeft(24f), "from_electric" to fromLeft(58f)))
    }

    private const val CX_LAUNDRY = 420f
    private const val CX_ELECTRIC = 490f
    private const val CX_BOILER = 560f
    private const val CX_STORAGE = 630f

    private fun cellar(s: RoomSegment): Built {
        val cellarStairs = stairDoor("door_cellar_service", 24f, FOYER, "from_cellar")
        val doors = listOf(
            cellarStairs,
            door("door_cellar_laundry", CX_LAUNDRY, HouseDefinition.LAUNDRY, "from_cellar", 0xFF6A8A8A.toInt()),
            door("door_cellar_electric", CX_ELECTRIC, ELECTRIC, "from_cellar", 0xFF5A5A6A.toInt()),
            door("door_cellar_boiler", CX_BOILER, BOILER, "from_cellar", 0xFF6A5A5A.toInt()),
            door("door_cellar_storage", CX_STORAGE, STORAGE, "from_cellar", 0xFF5A6A5A.toInt())
        )
        val shared = ArrayList<WorldObject>()
        shared.add(ChapterProps.mainStairs(30f, true))
        shared.add(stairSpot("stairs_cellar_up", cellarStairs, 18f, 120f, "SUBIR"))
        shared.add(ChapterProps.pipeRun(150f, 26f, 230f))
        shared.add(ChapterProps.pipeRun(400f, 26f, 280f))
        shared.add(ex("ex_cellar_lamp", 200f, 40f, "La luz del sótano es la última en estabilizarse."))
        val spawns = mapOf(
            "from_service" to SpawnPoint(170f, 1), "from_laundry" to fromRight(CX_LAUNDRY), "from_electric" to fromRight(CX_ELECTRIC),
            "from_boiler" to fromRight(CX_BOILER), "from_storage" to fromRight(CX_STORAGE)
        )
        return extend(s, 700f, none, dropHallDoors, doors, shared, emptyList(), emptyList(), spawns)
    }

    private fun electric(): Built {
        val doors = listOf(
            door("door_electric_cellar", 24f, HouseDefinition.CELLAR, "from_electric", 0xFF5A5A6A.toInt()),
            // v0.17 ★S2: puerta a la lavandería (vuelta del sótano).
            door("door_electric_laundry", 180f, HouseDefinition.LAUNDRY, "from_electric", 0xFF6A7A8A.toInt())
        )
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(130f, 50f, 90f, 0.7f, COLD, 0.08f))
        shared.add(ChapterProps.fuseBox(110f, 40f))
        val normal = listOf<WorldObject>(
            doc("doc_d06", "d06", 60f, 28f),
            sp("spot_N5", 110f, 70f, "INTERRUPTORES", InteractionIcon.USE, ready) { InteractionResult.panel("N5") }
        )
        shared.add(hide("wardrobe_electric", 220f, 4, 40f))
        return room(ELECTRIC, 340f, CameraMode.SIDE_SCROLLING, basementMood, mapOf("from_cellar" to fromLeft(24f), "from_laundry" to fromRight(180f)), doors, shared, normal)
    }

    private fun boiler(): Built {
        val doors = listOf(
            door("door_boiler_cellar", 24f, HouseDefinition.CELLAR, "from_boiler", 0xFF6A5A5A.toInt()),
            // v0.17 ★S6: la caldera comunica con el almacén por la sala de máquinas.
            door("door_boiler_storage", 290f, STORAGE, "from_boiler", 0xFF6A5A5A.toInt())
        )
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(170f, 60f, 100f, 0.65f, WARM, 0.1f))
        shared.add(ChapterProps.pipeRun(20f, 30f, 300f, 0.02f))
        shared.add(ChapterProps.boilerTank(130f))
        shared.add(ChapterProps.valve(80f, F - 40f, Cr.RED))
        shared.add(ChapterProps.valve(104f, F - 40f, Cr.BLUE))
        shared.add(ChapterProps.valve(240f, F - 40f, Cr.GREEN))
        shared.add(ChapterProps.valve(270f, F - 40f, Cr.YELLOW))
        shared.add(ex("ex_boiler_old", 130f, 84f, "La caldera es vieja y ruidosa. Tiene cuatro válvulas."))
        val trauma = listOf<WorldObject>(
            doc("doc_d10", "d10", 56f, 28f),
            ex("valve_1", 80f, 22f, "Válvula 1: golpea dos veces y espera."),
            ex("valve_2", 104f, 22f, "Válvula 2: no llega a completar el ciclo."),
            ex("valve_3", 240f, 22f, "Válvula 3: un silbido continuo."),
            ex("valve_4", 270f, 22f, "Válvula 4, la más cercana a la pared: deja de sonar antes que las demás."),
            puzzle("spot_T4", "T4", 170f, 50f, "AJUSTAR")
        )
        shared.add(hide("wardrobe_boiler", 330f, 4, 40f))
        return room(BOILER, 420f, CameraMode.SIDE_SCROLLING, basementMood, mapOf("from_cellar" to fromLeft(24f), "from_storage" to fromRight(290f)), doors, shared, emptyList(), trauma)
    }

    private const val HUECO_X = 380f

    /** Almacén con el HUECO bajo los cimientos como extensión baja y estrecha a su derecha (cerrada hasta resolver T4). */
    private fun storage(): Built {
        val doors = listOf(
            door("door_storage_cellar", 24f, HouseDefinition.CELLAR, "from_storage", 0xFF5A6A5A.toInt()),
            // v0.17 ★S6: puerta a la caldera por la sala de máquinas.
            door("door_storage_boiler", 136f, BOILER, "from_storage", 0xFF6A5A5A.toInt())
        )
        val shared = ArrayList<WorldObject>()
        shared.add(lamp(170f, 55f, 100f, 0.65f, WARM))
        shared.add(ChapterProps.shelvesTools(70f, 70f))
        shared.add(HouseProps.crateStack(170f))
        // v0.18 Fran Bow: el barril se mueve junto a la entrada del hueco y pasa a primer plano:
        // enmarca el hueco y tapa al niño al pasar por detrás.
        shared.add(HouseProps.barrel(330f).also { it.layer = Layer.FOREGROUND })
        shared.add(hide("wardrobe_storage", 282f, 4, 40f))
        shared.add(ex("ex_storage_gap", 330f, 40f, "Hay un hueco en la pared que no corresponde al almacén. Alguien lo tapó con tablas."))
        // el hueco: techo bajo y muro que se abre al resolver T4
        shared.add(Prop(HUECO_X, 0f, 160f, 66f, 0xFF1E1C24.toInt(), 0xFF000000.toInt()).also { it.layer = Layer.DECOR })
        shared.add(FlagWall(HUECO_X - 6f, 0f, 12f, F, ChapterFlags.solved("T4")))
        shared.add(ChapterProps.pipeRun(HUECO_X + 6f, 70f, 150f, 0.01f))
        val normal = listOf<WorldObject>(
            ChapterProps.puddle(HUECO_X + 20f, 120f),
            ChapterProps.drip(HUECO_X + 70f, 70f),
            sp("spot_C3", 440f, 80f, "PANELES", InteractionIcon.USE, { it.hasFlag(ChapterFlags.solved("T4")) }) { InteractionResult.panel("C3") }
        )
        val trauma = listOf<WorldObject>(
            ex("ex_hueco_trauma", 440f, 80f, "El agua desapareció. Se ve el recorrido de las tuberías hasta el fondo: cuatro paneles de mantenimiento bajo el tubo.")
        )
        return room(STORAGE, 560f, CameraMode.SIDE_SCROLLING, basementMood, mapOf("from_cellar" to fromLeft(24f), "from_boiler" to fromLeft(136f)), doors, shared, normal, trauma)
    }
}
