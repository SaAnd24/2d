package com.terror2d.render

import android.graphics.Paint
import com.terror2d.core.Depth
import com.terror2d.core.DepthLayer
import com.terror2d.core.GameConfig
import com.terror2d.draw.CrayonSprite
import com.terror2d.pixel.ItemSprites
import com.terror2d.pixel.LightingSample
import com.terror2d.pixel.PixelPose
import kotlin.math.round
import com.terror2d.scene.RoomSegment
import com.terror2d.world.DarkZone
import com.terror2d.world.Door
import com.terror2d.world.LightSource
import com.terror2d.world.LightSwitch
import com.terror2d.world.Player
import com.terror2d.world.Wardrobe
import com.terror2d.world.WardrobePhase
import com.terror2d.world.WorldObject

/**
 * Renderizador del MUNDO. Pipeline de un frame (lo orquesta la escena):
 *
 *   fondo -> decoración y muebles -> personaje (pixel art) -> primer plano -> iluminación (máscara de oscuridad)
 *
 * Esta clase aporta las piezas genéricas (puertas, armarios, bombillas, iluminación, personaje) con
 * formas planas; el ESTILO lo ponen sus hijos: [CrayonRenderer] (v0.4) y, en el futuro,
 * Graphite / Scratch / Distortion, que podrán sustituir [drawBackdrop] y [drawSprite] sin tocar el motor.
 * El personaje se dibuja con [PlayerPixelRenderer], independiente del estilo del mundo.
 */
open class WorldRenderer : BaseRenderer() {

    protected val lighting = LightingRenderer()
    protected val playerPixels = PlayerPixelRenderer()
    protected val creaturePixels = CreatureRenderer()
    protected val puzzleRenderer = PuzzleRenderer()
    protected val conversationRenderer = ConversationRenderer()
    protected val closetRenderer = ClosetRenderer(conversationRenderer)
    protected val screamerRenderer = ScreamerRenderer()
    protected val chapterRenderer = ChapterRenderer()

    /** Tiempo de animación (segundos) para animaciones deterministas de objetos. */
    val animTime: Float get() = renderTime

    // ---- Capítulo I: estados visuales (solo presentación)
    /** TRAUMA: lo dibujado hasta [endGraphite] pasa por el filtro de grafito (grises). */
    open fun beginGraphite(on: Boolean) {
        if (on) canvas.saveLayer(null, chapterRenderer.graphitePaint)
    }

    open fun endGraphite(on: Boolean) {
        if (on) canvas.restore()
    }

    open fun drawStateWall(seg: RoomSegment, trauma: Boolean, level: Int, px: Float, py: Float) {
        chapterRenderer.drawWall(canvas, seg, trauma, level, px, py, renderTime)
    }

    open fun drawStateOverlay(seg: RoomSegment, trauma: Boolean, level: Int) {
        chapterRenderer.drawTop(canvas, seg, trauma, level, renderTime)
    }

    open fun drawFabricTexture(x: Float, y: Float, w: Float, h: Float) {
        chapterRenderer.drawFabric(canvas, x, y, w, h)
    }

    open fun drawCeilingMirrored(o: com.terror2d.world.WorldObject, floorY: Float) {
        chapterRenderer.withCeilingFlip(canvas, floorY) { o.render(this) }
    }

    private val mechRenderer = MechRenderer()

    /** v0.15: selector local de objetivos cercanos («‹ 2/3 ›», arriba al centro). Tocarlo cambia de objetivo. */
    open fun drawFocusSelector(count: Int, index: Int) {
        paint.style = android.graphics.Paint.Style.FILL
        paint.color = 0xAA000000.toInt()
        canvas.drawRoundRect(112f, 6f, 208f, 22f, 6f, 6f, paint)
        paint.color = 0xFFFFF2B0.toInt()
        paint.textSize = 7f
        paint.textAlign = android.graphics.Paint.Align.CENTER
        canvas.drawText("‹  " + (index + 1) + "/" + count + "  ›  otro objetivo", 160f, 16f, paint)
        paint.textAlign = android.graphics.Paint.Align.LEFT
    }

    /** v0.15: dibuja el mecanismo propio de un puzle (cada uno tiene su vista, objetos y feedback). */
    open fun drawMechanism(m: com.terror2d.chapter.mech.Mechanism) {
        mechRenderer.draw(canvas, m, renderTime)
    }

    open fun drawChapterPanel(p: com.terror2d.chapter.PuzzlePanel) {
        chapterRenderer.drawPanel(canvas, p, renderTime)
    }

    open fun drawChapterEnding(t: Float) {
        chapterRenderer.drawEnding(canvas, t)
    }

    /** Fondo del segmento (pared y suelo). Versión plana; [CrayonRenderer] la sustituye por trazos de crayón. */
    open fun drawBackdrop(seg: RoomSegment, chunks: Array<CrayonSprite>, camX: Float) {
        val w = seg.width
        val fy = seg.floorY
        paint.style = Paint.Style.FILL
        paint.color = tint(seg.wallColor)
        canvas.drawRect(0f, 0f, w, fy, paint)
        paint.color = tint(seg.floorColor)
        canvas.drawRect(0f, fy, w, seg.height, paint)
        paint.color = tint(Palette.EDGE_WALL)
        if (seg.leftBoundary > 0f) canvas.drawRect(0f, 0f, seg.leftBoundary, seg.height, paint)
        if (seg.rightBoundary < w) canvas.drawRect(seg.rightBoundary, 0f, w, seg.height, paint)
    }

    /** Dibujo de crayón precalculado. Lo implementa el estilo concreto. */
    open fun drawSprite(sprite: CrayonSprite) {}

    /** v0.9: las primeras [count] coordenadas de [lines] (pares x1,y1,x2,y2) como líneas sueltas: lluvia y salpicaduras. */
    open fun drawStrokesN(lines: FloatArray, count: Int, color: Int, strokeWidth: Float) {
        if (count <= 0) return
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = strokeWidth
        paint.color = tint(color)
        canvas.drawLines(lines, 0, count, paint)
    }

    /** v0.9: un dibujo de crayón inclinado en X alrededor de (pivotX, pivotY): una cortina que mueve el viento. */
    open fun drawSpriteSwayed(sprite: CrayonSprite, pivotX: Float, pivotY: Float, skewX: Float) {
        canvas.save()
        canvas.translate(pivotX, pivotY)
        canvas.skew(skewX, 0f)
        canvas.translate(-pivotX, -pivotY)
        drawSprite(sprite)
        canvas.restore()
    }

    /** Dibuja un [CrayonSprite] construido en el origen, desplazado a (dx, dy). */
    open fun drawSpriteAt(sprite: CrayonSprite, dx: Float, dy: Float) {
        canvas.save()
        canvas.translate(dx, dy)
        drawSprite(sprite)
        canvas.restore()
    }

    /**
     * Personaje pixelado: usa los datos de pose del jugador, su cara (parpadeo / expresión), el objeto que lleva
     * en la mano y la iluminación que recibe en su posición (la misma que oscurece el resto del mundo).
     * El objeto se dibuja ENTRE el cuerpo y la mano delantera: los dedos quedan por encima.
     *
     * v0.17 (2.5D): el sprite se escala con [Depth.depthScale] alrededor de los pies
     * (lejos = más pequeño, cerca = más grande; en el plano de referencia la escala es 1.0).
     * v0.18: agacharse ya NO aplasta el sprite en vertical: la pose CROUCH_* se dibuja más
     * baja de verdad (piernas dobladas, cuerpo bajo); `Player.visualHeightScale` es siempre 1.
     */
    open fun drawPlayer(p: Player) {
        val pose = p.pose
        val heldId = p.heldItemId
        val held = if (heldId != null && p.visibilityAlpha > 0.5f) ItemSprites.get(heldId) else null
        val companionId = p.companionItemId
        val companion = if (companionId != null) ItemSprites.get(companionId) else null
        var cdx = 0f
        var cdy = 0f
        if (companion != null) {
            // balanceo de peso del compañero (en píxeles del sprite del niño): sube y baja con los pasos, queda un
            // poco rezagado al arrancar y respira apenas al estar quieto. Sutil: nunca parece animado por sí mismo.
            val moving = kotlin.math.abs(p.velocityX) > Player.MOVING_EPS
            if (moving) {
                val phase = p.animTime / (Player.STEP_TIME * 2f) * 6.2831855f
                cdy = kotlin.math.sin(phase - 0.8f) * 1.3f
                cdx = -(kotlin.math.abs(p.velocityX) / Player.SPEED) * 1.6f
            } else {
                cdy = kotlin.math.sin(renderTime * 1.7f) * 0.7f
            }
        }
        // v0.9: cinemática de la cama: el MISMO sprite y las MISMAS poses, con elevación y giro (90° exactos: píxeles nítidos)
        val by = p.bottom - p.bodyLift
        val turned = p.bodyAngle != 0f
        val s = Depth.depthScale(p.depth)
        canvas.save()
        if (turned) {
            canvas.translate(p.centerX, by)
            canvas.rotate(p.bodyAngle)
            canvas.translate(-p.centerX, -by)
        }
        if (s != 1f) {
            canvas.translate(p.centerX, by)
            canvas.scale(s, s)
            canvas.translate(-p.centerX, -by)
        }
        playerPixels.render(
            canvas, p.sprite, pose, p.eyes, p.mouth, p.facing < 0f,
            p.centerX, by, p.visibilityAlpha, p.light, corruption, held, companion, cdx, cdy
        )
        canvas.restore()
        if (p.paperEffects != 0 && p.visibilityAlpha > 0.5f) drawPaperEffects(p, pose)
    }

    /** v0.8: la criatura, por capas y con la misma iluminación y densidad de píxel que el niño. */
    open fun drawCreature(c: com.terror2d.creature.Creature) {
        creaturePixels.render(canvas, c, c.x, c.floorY, 1f)
    }

    /**
     * v0.17: la criatura a una profundidad dada: se escala con [Depth.depthScale] alrededor
     * de sus pies, igual que el jugador. Sin profundidad se dibuja como siempre (escala 1.0).
     */
    open fun drawCreature(c: com.terror2d.creature.Creature, depth: Float) {
        val s = Depth.depthScale(depth)
        if (s == 1f) {
            drawCreature(c)
            return
        }
        canvas.save()
        canvas.translate(c.x, c.floorY)
        canvas.scale(s, s)
        canvas.translate(-c.x, -c.floorY)
        creaturePixels.render(canvas, c, c.x, c.floorY, 1f)
        canvas.restore()
    }

    // ------------------------------------------------------------------ 2.5D (v0.17)

    /**
     * Orden de pintado por profundidad (lejos -> cerca, estable). La escena pinta
     * BACK -> jugador/criatura intercalados por depth -> FRONT; esta lista es la pieza
     * que ordena cada capa. Los objetos sin profundidad propia usan la de referencia.
     */
    open fun sortByDepth(objects: List<WorldObject>): List<WorldObject> =
        Depth.sortByDepth(objects) { Depth.depthOf(it) }

    /** Capa de render de un objeto según su profundidad ([DepthLayer]). */
    open fun depthLayerOf(o: WorldObject): DepthLayer = Depth.layerOf(o)

    /** true si el objeto está DELANTE del jugador: se dibuja después que él y puede taparlo (oclusión). */
    open fun isInFrontOfPlayer(o: WorldObject, playerDepth: Float): Boolean =
        Depth.isInFrontOf(o, playerDepth)

    /**
     * Dibuja un objeto escalado por su profundidad alrededor de su base, con el mismo
     * estilo de crayón: lejos se ve más pequeño, cerca más grande.
     */
    open fun drawObjectAtDepth(o: WorldObject) {
        val s = Depth.depthScale(Depth.depthOf(o))
        if (s == 1f) {
            o.render(this)
            return
        }
        canvas.save()
        canvas.translate(o.centerX, o.bottom)
        canvas.scale(s, s)
        canvas.translate(-o.centerX, -o.bottom)
        o.render(this)
        canvas.restore()
    }

    /**
     * Fondo con parallax según la profundidad del foco (normalmente el jugador):
     * el muro se desplaza con la cámara al ~60-100% según lo cerca que esté el foco.
     * [CrayonRenderer] hereda este comportamiento a través de [drawBackdrop].
     */
    open fun drawBackdropDepth(seg: RoomSegment, chunks: Array<CrayonSprite>, camX: Float, focusDepth: Float) {
        drawBackdrop(seg, chunks, Depth.parallaxCamX(camX, focusDepth))
    }

    /**
     * v0.18 Fran Bow: dibuja [draw] con un desplazamiento horizontal extra (parallax de capa).
     * La capa de primer plano se mueve un poco MÁS rápido que el mundo (está más cerca de la
     * cámara que el plano medio); el muro, al contrario, se mueve más despacio (ver
     * [drawBackdropDepth]). Solo es un desplazamiento de dibujo: las zonas de interacción y
     * la colisión siguen en coordenadas del mundo, sin tocar.
     */
    open fun shiftLayer(dx: Float, draw: () -> Unit) {
        if (dx == 0f) {
            draw()
            return
        }
        canvas.save()
        canvas.translate(dx, 0f)
        draw()
        canvas.restore()
    }

    /** Efectos de papel pegados (lágrimas, sudor, temblor, dolor, respiración fría) sobre la cabeza. */
    open fun drawPaperEffects(p: Player, pose: PixelPose) {
        val head = p.sprite.face?.head(pose) ?: return
        val dir = if (p.facing < 0f) -1f else 1f
        val hx0 = p.centerX + (head[0] - p.sprite.anchorX) * p.sprite.scale * dir
        val hy0 = p.bottom + (head[1] - p.sprite.height) * p.sprite.scale
        // v0.17: la cabeza sigue la escala de profundidad del sprite.
        // v0.18: ya no hay aplastamiento al agacharse (la pose es más baja de verdad).
        val s = Depth.depthScale(p.depth)
        val hx = p.centerX + (hx0 - p.centerX) * s
        val hy = p.bottom + (hy0 - p.bottom) * s
        val t = renderTime
        for (kind in PaperEffects.ALL_KINDS) {
            if (p.paperEffects and kind == 0) continue
            var ox = 0f
            var oy = 0f
            when (kind) {
                PaperEffects.TREMBLE -> {
                    ox = if (((t * 28f).toInt() and 1) == 0) 0.6f else -0.6f
                    oy = if (((t * 23f).toInt() and 1) == 0) 0.4f else -0.4f
                }
                PaperEffects.TEARS -> oy = (t * 3f) % 3f
                PaperEffects.COLD_BREATH -> oy = -((t * 2f) % 2f)
            }
            canvas.save()
            canvas.translate(round(hx + ox * dir), round(hy + oy))
            if (dir < 0f) canvas.scale(-1f, 1f)
            drawSprite(PaperEffects.sprite(kind))
            canvas.restore()
        }
    }

    /** Primera persona del puzzle de medicamentos (mesa vista desde los ojos del niño). */
    open fun drawPuzzleView(p: com.terror2d.puzzle.MedicinePuzzle, alpha: Float) {
        puzzleRenderer.drawPuzzle(canvas, p, alpha, renderTime, corruption)
    }

    /** Escena de conversación en primera persona (manos del niño + peluche sobre negro). */
    open fun drawConversation(v: com.terror2d.conversation.ConversationView) {
        conversationRenderer.draw(canvas, v)
    }

    /** v0.10: escena del armario en primera persona. */
    open fun drawCloset(v: com.terror2d.closet.ClosetView) {
        closetRenderer.draw(canvas, v)
    }

    /** v0.10.1: libera los bitmaps del interior del armario. */
    open fun releaseCloset() { closetRenderer.release() }

    /** v0.10: screamer de captura (arte dedicado, primerísimo plano). */
    open fun drawScreamer(v: com.terror2d.creature.ScreamerView) {
        screamerRenderer.draw(canvas, v)
    }

    /** v0.10: decodifica el arte del screamer durante la pausa previa (evita un tirón al impactar). */
    open fun prepareScreamer() { screamerRenderer.prepare() }

    open fun releaseScreamer() { screamerRenderer.release() }

    /** Libera el arte de la conversación (al descargar la escena). */
    open fun releaseConversation() {
        conversationRenderer.release()
    }

    /** Documento abierto para leer. */
    open fun drawDocument(d: com.terror2d.story.DocumentDef, t: Float) {
        puzzleRenderer.drawDocument(canvas, d, t)
    }

    /**
     * Objeto del inventario apoyado en el mundo (suelo, mesita, cama): MISMO sprite y MISMA escala que en la mano
     * y en el HUD. (centerX, bottomY) = centro de su base.
     */
    open fun drawItemOnGround(itemId: String, centerX: Float, bottomY: Float) {
        val sprite = ItemSprites.get(itemId) ?: return
        playerPixels.renderStanding(canvas, sprite, centerX, bottomY, 1f, LightingSample.NEUTRAL, corruption)
    }

    /**
     * Capa de iluminación del segmento (coordenadas del mundo), tras dibujar objetos y personaje:
     * la oscuridad se abre solo alrededor de las luces activas. [camX]/[camY] = esquina de la cámara.
     */
    open fun drawLighting(seg: RoomSegment, camX: Float, camY: Float, extra: LightSource?) {
        lighting.drawWorldLighting(
            canvas, camX, camY, seg.ambientDark, seg.ambientColor,
            seg.darkZones, seg.lights, extra, renderTime
        )
    }

    /** Viñeta de pantalla (coordenadas lógicas). */
    open fun drawVignette() {
        lighting.drawVignette(canvas)
    }

    /** Fundido a negro de las transiciones (coordenadas lógicas). */
    open fun drawFade(alpha: Float) {
        if (alpha <= 0.003f) return
        paint.style = Paint.Style.FILL
        paint.color = (alpha.coerceIn(0f, 1f) * 255f).toInt() shl 24
        canvas.drawRect(0f, 0f, GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat(), paint)
    }

    /** Puerta de frente: marco, hueco oscuro y hoja que se abre con [Door.openProgress]. */
    open fun drawDoor(d: Door) {
        val x = d.x
        val y = d.y
        val w = d.width

        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.DOOR_FRAME)
        canvas.drawRect(x - 3f, y - 3f, d.right + 3f, d.bottom, paint)
        paint.color = tint(Palette.DOOR_INSIDE)
        canvas.drawRect(x, y, d.right, d.bottom, paint)

        val pw = w * (1f - 0.8f * d.openProgress)
        if (pw > 0.5f) {
            paint.color = tint(d.panelColor)
            canvas.drawRect(x, y, x + pw, d.bottom, paint)
            canvas.save()
            canvas.clipRect(x, y, x + pw, d.bottom)
            drawStrokes(d.hatch, d.panelHatch, 1.3f)
            canvas.restore()

            // Dos paneles hundidos
            if (pw > 12f) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1f
                paint.color = tint(d.panelHatch)
                val pl = x + pw * 0.16f
                val pr = x + pw * 0.84f
                canvas.drawRect(pl, y + 7f, pr, y + d.height * 0.42f, paint)
                canvas.drawRect(pl, y + d.height * 0.5f, pr, d.bottom - 7f, paint)
            }

            // Pomo (o placa de cerradura si está bloqueada)
            paint.style = Paint.Style.FILL
            val kx = x + pw - 5f
            val ky = y + d.height * 0.55f
            if (d.locked) {
                paint.color = tint(0xFF4A4458.toInt())
                canvas.drawRect(kx - 3f, ky - 5f, kx + 3f, ky + 5f, paint)
                paint.color = tint(Palette.OUTLINE)
                canvas.drawCircle(kx, ky - 1f, 1.1f, paint)
                canvas.drawRect(kx - 0.5f, ky - 1f, kx + 0.5f, ky + 3f, paint)
            } else {
                paint.color = tint(Palette.DOOR_KNOB)
                canvas.drawCircle(kx, ky, 2.4f, paint)
            }
        }
        drawStrokes(d.outline, Palette.OUTLINE, 1.1f)
    }

    /** Armario: cuerpo de crayón, una o dos puertas que se abren, interior oscuro, decoración y ojos si hay alguien. */
    open fun drawWardrobe(w: Wardrobe) {
        val st = w.style
        val x = w.x
        val y = w.y
        val r = w.right
        val b = w.bottom

        // Cuerpo
        paint.style = Paint.Style.FILL
        paint.color = tint(st.bodyFill)
        canvas.drawRect(x, y, r, b - 4f, paint)
        drawStrokes(w.hatch, st.bodyHatch, 1.4f)

        // Cornisa y pies
        paint.style = Paint.Style.FILL
        paint.color = tint(st.trim)
        canvas.drawRect(x - 2f, y - 3f, r + 2f, y + 4f, paint)
        canvas.drawRect(x + 3f, b - 4f, x + 9f, b, paint)
        canvas.drawRect(r - 9f, b - 4f, r - 3f, b, paint)

        // Hueco interior (se ve al abrir)
        val inL = x + 4f
        val inR = r - 4f
        val inT = y + 9f
        val inB = b - 8f
        paint.color = tint(Palette.WARDROBE_INSIDE)
        canvas.drawRect(inL, inT, inR, inB, paint)

        val open = w.visualOpen
        val k = 1f - 0.86f * open

        var gapCenter: Float
        if (st.doorCount >= 2) {
            val half = (inR - inL) / 2f
            val pw = half * k
            drawWardrobeDoor(w, inL, inT, inL + pw, inB)
            drawWardrobeDoor(w, inR - pw, inT, inR, inB)
            if (pw > 4f) {
                paint.style = Paint.Style.FILL
                paint.color = tint(Palette.DOOR_KNOB)
                canvas.drawCircle(inL + pw - 2.5f, inT + (inB - inT) * 0.52f, 1.7f, paint)
                canvas.drawCircle(inR - pw + 2.5f, inT + (inB - inT) * 0.52f, 1.7f, paint)
            }
            gapCenter = (inL + inR) / 2f
        } else {
            val pw = (inR - inL) * k
            drawWardrobeDoor(w, inL, inT, inL + pw, inB)
            if (pw > 5f) {
                paint.style = Paint.Style.FILL
                paint.color = tint(Palette.DOOR_KNOB)
                canvas.drawCircle(inL + pw - 3f, inT + (inB - inT) * 0.52f, 1.8f, paint)
            }
            gapCenter = (inL + pw + inR) / 2f
        }

        // Decoración y arañazos (solo con la puerta casi cerrada)
        if (open < 0.3f) {
            drawStrokes(w.deco, st.decoColor, 1.5f)
            drawStrokes(w.scratches, st.bodyHatch, 1f)
        }

        // Alguien dentro: dos ojos que brillan en la rendija (y parpadean de vez en cuando)
        val inside = w.phase == WardrobePhase.OCCUPIED || w.phase == WardrobePhase.CLOSING_BEHIND
        if (inside && open in 0.05f..0.5f) {
            val ey = inT + (inB - inT) * 0.30f
            val blink = (renderTime % 3.6f) > 3.46f
            paint.style = Paint.Style.FILL
            paint.color = tint(Palette.EYE_WHITE)
            if (blink) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 0.9f
                canvas.drawLine(gapCenter - 2.6f, ey, gapCenter - 0.6f, ey, paint)
                canvas.drawLine(gapCenter + 0.6f, ey, gapCenter + 2.6f, ey, paint)
            } else {
                oval.set(gapCenter - 2.7f, ey - 1.5f, gapCenter - 0.7f, ey + 1.5f)
                canvas.drawOval(oval, paint)
                oval.set(gapCenter + 0.7f, ey - 1.5f, gapCenter + 2.7f, ey + 1.5f)
                canvas.drawOval(oval, paint)
            }
        }

        drawStrokes(w.outline, Palette.OUTLINE, 1.1f)
    }

    /** Hoja de armario entre [l,r] x [t,bt]: relleno, trazos de crayón recortados, panel hundido y contorno. */
    private fun drawWardrobeDoor(w: Wardrobe, l: Float, t: Float, r: Float, bt: Float) {
        if (r - l < 0.8f) return
        paint.style = Paint.Style.FILL
        paint.color = tint(w.style.doorFill)
        canvas.drawRect(l, t, r, bt, paint)
        canvas.save()
        canvas.clipRect(l, t, r, bt)
        drawStrokes(w.hatch, w.style.bodyHatch, 1.2f)
        canvas.restore()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawRect(l, t, r, bt, paint)
        if (r - l > 9f) {
            paint.color = tint(w.style.bodyHatch)
            canvas.drawRect(l + 3f, t + 4f, r - 3f, bt - 4f, paint)
        }
    }

    /** Bombilla de una lámpara: se apaga y enciende según el nivel de la luz (0..1). */
    open fun drawBulb(cx: Float, cy: Float, level: Float) {
        paint.style = Paint.Style.FILL
        paint.color = tint(lerpColor(0xFF5A4A34.toInt(), 0xFFFFF2B0.toInt(), level))
        canvas.drawCircle(cx, cy, 4.4f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawCircle(cx, cy, 4.4f, paint)
    }

    /** v0.16: chispazo breve de un foco que revienta (edad en segundos: 0..0.45). */
    open fun drawSpark(x: Float, y: Float, age: Float) {
        val k = 1f - (age / 0.45f).coerceIn(0f, 1f)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint((((k * 255f).toInt().coerceIn(0, 255)) shl 24) or 0x00FFF2B0)
        val fall = age * 38f
        canvas.drawLine(x, y, x - 5f * age * 6f, y + fall, paint)
        canvas.drawLine(x, y, x + 6f * age * 6f, y + fall * 0.8f, paint)
        canvas.drawLine(x, y, x + 1.5f, y + fall * 1.2f, paint)
    }

    /** v0.16: foco REVENTADO: casquillo con restos de vidrio y una grieta; no brilla (decoración del apagón). */
    open fun drawBrokenBulb(cx: Float, cy: Float) {
        paint.style = Paint.Style.FILL
        paint.color = tint(0xFF3A3028.toInt())
        canvas.drawRect(cx - 2.6f, cy - 4.4f, cx + 2.6f, cy - 1.6f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawLine(cx - 3.6f, cy - 1.4f, cx - 1.6f, cy + 2.4f, paint)
        canvas.drawLine(cx + 3.6f, cy - 1.4f, cx + 1.2f, cy + 1.8f, paint)
        canvas.drawLine(cx - 1.6f, cy + 2.4f, cx + 0.2f, cy - 0.6f, paint)
        paint.style = Paint.Style.FILL
        paint.color = tint(0x88C9D4D8.toInt())
        canvas.drawRect(cx - 1.2f, cy + 3.4f, cx - 0.2f, cy + 4.6f, paint)
        canvas.drawRect(cx + 1.6f, cy + 5.2f, cx + 2.6f, cy + 6.0f, paint)
    }

    /** Interruptor de pared: placa y palanca arriba (encendido) o abajo (apagado). */
    open fun drawSwitch(s: LightSwitch) {
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.SWITCH_PLATE)
        canvas.drawRect(s.x, s.y, s.right, s.bottom, paint)
        drawStrokes(s.outline, Palette.OUTLINE, 1f)
        val on = s.light.active
        val ly = if (on) s.y + 3f else s.y + 9f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawRect(s.x + 3f, ly, s.right - 3f, ly + 4f, paint)
    }
}
