package com.terror2d.core

/** Constantes globales del motor. */
object GameConfig {
    /** Resolución lógica interna (16:9). */
    const val LOGICAL_WIDTH = 320
    const val LOGICAL_HEIGHT = 180

    const val TARGET_FPS = 60

    /** Paso fijo de la simulación (segundos). */
    const val FIXED_STEP = 1f / 60f

    /** Máximo delta aceptado por frame (evita saltos tras pausas). */
    const val MAX_FRAME_TIME = 0.1f

    /** Máximo de pasos de simulación por frame. */
    const val MAX_STEPS_PER_FRAME = 5

    /** true = escala entera (pixel perfect, con más barras negras). */
    const val INTEGER_SCALING = false

    /**
     * Encuadre cercano (v0.3): el cuerpo del personaje debe ocupar al menos esta fracción de la
     * altura lógica de la pantalla. v0.2 estaba en ~0.14 (personaje diminuto); ahora ~0.27.
     */
    const val MIN_PLAYER_FRAME_RATIO = 0.22f

    /** Muestra FPS y datos técnicos (v0.3: apagado para que no parezca un prototipo técnico). */
    const val DEBUG_OVERLAY = false

    // ------------------------------------------------------------------ 2.5D (v0.17)

    /** Profundidad: 0.0 = fondo (lejos), 1.0 = primer plano (cerca). */
    const val DEPTH_MIN = 0f
    const val DEPTH_MAX = 1f

    /**
     * Plano de referencia: la profundidad con escala visual exactamente 1.0 (0.82 + 0.30 * 0.6)
     * y los pies sobre `floorY`. Es la profundidad por defecto del jugador y de todo lo que
     * todavía no tiene profundidad propia: el juego se ve igual que en v0.16 hasta que algo se mueve.
     */
    const val DEPTH_REFERENCE = 0.6f
    const val PLAYER_DEFAULT_DEPTH = 0.6f

    /** Escala visual: `depthScale(depth) = DEPTH_SCALE_FAR + DEPTH_SCALE_SPAN * depth`. */
    const val DEPTH_SCALE_FAR = 0.82f
    const val DEPTH_SCALE_SPAN = 0.30f

    /**
     * Altura vertical (px lógicos) de la banda de suelo: de floorY - 10.4 (fondo) a
     * floorY + 10.4 (primer plano). Suficiente para esquivar por delante/detrás de un mueble
     * sin que el niño se salga del suelo dibujado.
     */
    const val FLOOR_BAND_HEIGHT = 26f

    /** Velocidad en profundidad (unidades de depth/s): cruzar la banda andando ~1.8 s. */
    const val DEPTH_SPEED = 0.55f

    // ------------------------------------------------------------------ Movimiento (v0.17, px/s)

    /** Paseo tranquilo del niño (igual que v0.16). */
    const val WALK_SPEED = 68f
    const val RUN_SPEED = 110f
    const val SNEAK_SPEED = 32f
    const val CROUCH_SPEED = 22f

    /**
     * LEGADO (v0.18): altura visual agachado (fracción de la altura de pie).
     * Ya NO se usa en el juego: desde v0.18 agacharse dibuja una POSE de verdad
     * (piernas dobladas, cuerpo bajo) y `Player.visualHeightScale` es siempre 1.
     * Se conserva solo como referencia histórica del valor antiguo (0.72) y porque
     * `CrouchPoseTest.visualHeightScaleEsUnoSiempre` lo usa para afirmar que la
     * escala visual ya no es ese valor. No borrar sin actualizar ese test.
     */
    const val CROUCH_HEIGHT_SCALE = 0.72f

    /** Visibilidad relativa por modo (1 = normal): agachado cuesta más verlo, corriendo se ve más. */
    const val VISIBILITY_WALK = 1f
    const val VISIBILITY_RUN = 1.15f
    const val VISIBILITY_SNEAK = 0.8f
    const val VISIBILITY_CROUCH = 0.6f

    // ------------------------------------------------------------------ Stamina (v0.17, 0..100)

    const val STAMINA_MAX = 100f
    /** Se agota corriendo: ~4.5 s de carrera continua desde lleno. */
    const val STAMINA_DRAIN_RUN = 22f
    const val STAMINA_REGEN_IDLE = 16f
    const val STAMINA_REGEN_WALK = 10f
    const val STAMINA_REGEN_SNEAK = 12f
    const val STAMINA_REGEN_CROUCH = 12f
    /** Stamina mínima para EMPEZAR a correr; a 0 el modo cae solo a WALK. */
    const val STAMINA_MIN_TO_RUN = 8f

    // ------------------------------------------------------------------ Cámara 2.5D (v0.17)

    /** Desplazamiento vertical máximo de la vista por profundidad (px lógicos, sutil). */
    const val DEPTH_SHIFT_MAX = 3f
    /** Zoom máximo por profundidad (fracción): ±2% alrededor del plano de referencia. */
    const val DEPTH_ZOOM_SPAN = 0.05f
    /** Suavizado con el que la cámara sigue la profundidad del jugador (1/s). */
    const val DEPTH_FOCUS_SMOOTHING = 4f
}
