package com.terror2d.input

import android.view.KeyEvent
import android.view.MotionEvent
import com.terror2d.core.MoveMode
import com.terror2d.core.Viewport
import com.terror2d.interaction.InteractionIcon
import kotlin.math.sqrt

/** Acciones del juego. En v0.3 INTERACT es el botón de acción genérico (puertas, armarios, objetos...). */
enum class InputAction { INTERACT, RUN, HIDE, EXAMINE, CONFIRM, CANCEL, TALK, MIRROR, SNEAK, CROUCH }

/**
 * Traduce eventos táctiles/teclado a un estado de entrada abstracto: movimiento analógico y acciones.
 * La lógica del juego solo lee [moveX]/[moveY] y las acciones; nunca MotionEvent.
 *
 * Controles táctiles (coordenadas lógicas 320x180, zona inferior):
 *  - JOYSTICK VIRTUAL fijo abajo a la izquierda (centro [JOYSTICK_X], [JOYSTICK_Y]): un solo pulgar
 *    mueve en X y en profundidad a la vez (diagonal real). [moveX]/[moveY] son continuos en [-1, 1]:
 *    el empuje suave anda despacio y a tope anda a velocidad completa; correr sigue siendo mantener
 *    CORRER. Fijo y no flotante: en un juego de terror el mando debe estar siempre en el mismo sitio,
 *    sin sorpresas al apoyar el pulgar. Ver [JOYSTICK_DEADZONE] y [JOYSTICK_BASE_RADIUS].
 *  - botón de acción abajo a la derecha, visible solo cuando hay algo con lo que actuar.
 * Las zonas de toque se extienden a las barras negras para que el pulgar nunca falle.
 *
 * Controles 2.5D (v0.17, revisados en v0.18) — el niño ya no solo va a izquierda/derecha:
 *  - PROFUNDIDAD: sale del joystick (empujar arriba = hacia el fondo/lejos, más arriba en pantalla,
 *    más pequeño; empujar abajo = hacia el primer plano/cerca, más abajo, más grande).
 *    Teclado: W / ↑ = fondo, S / ↓ = primer plano.
 *  - CORRER: botón » abajo a la derecha (x 228..272, y >= 140), MANTENER pulsado. Gasta stamina
 *    (barra encima del botón); sin stamina no se corre. Teclado: SHIFT (izq. o der.).
 *  - AGACHARSE: botón abajo a la izquierda de CORRER (x 190..228, y >= 140), MANTENER pulsado:
 *    al soltar, el niño se levanta. Teclado: C (mantener). Agachado es silencioso y cuesta más ver
 *    al niño; agachado manda sobre sigilo y sobre correr.
 *  - SIGILO: botón pequeño encima de AGACHARSE (x 190..228, y 100..140), TOCAR para alternar.
 *    Teclado: V = sigilo (alternar). Correr tiene prioridad sobre el sigilo solo si se mantiene
 *    CORRER. El viejo botón de modo de la esquina superior izquierda (ANDAR -> SIGILO -> AGACHADO)
 *    se eliminó en v0.18: su zona (x < 52, y < 48) se solapaba con el icono del diario y el ciclo
 *    escondía el estado del niño detrás de toques; ahora cada modo tiene su propio botón.
 *  - La escena lee [requestedMode] y lo aplica al jugador con su control de stamina
 *    ([com.terror2d.world.Player.requestMode]); el input solo PIDE el modo.
 *
 * En modo puzle / primera persona / armario los botones de movimiento y de modo se ignoran,
 * como ya hacían los de izquierda/derecha.
 *
 * Costura de pruebas: [touchDown]/[touchMove]/[touchUp] reproducen el mismo camino que
 * [onTouchEvent] con coordenadas lógicas y un id de dedo virtual (los tests unitarios son JUnit
 * puro, sin Robolectric ni MotionEvent). Un id que ya está apoyado y vuelve a bajar se trata
 * como movimiento, no como pulsación nueva (igual que MotionEvent).
 */
class InputController {

    /**
     * v0.18: movimiento horizontal ANALÓGICO en [-1, 1] (joystick o teclado). -1 = izquierda,
     * +1 = derecha. El teclado sigue siendo discreto (-1/0/1); el joystick da valores continuos
     * y su magnitud escala la velocidad del niño ([com.terror2d.world.Player.update] multiplica
     * la velocidad del modo por este valor).
     */
    @Volatile var moveX: Float = 0f
        private set

    /**
     * v0.18: movimiento en profundidad ANALÓGICO en [-1, 1] (joystick o teclado).
     * -1 = hacia el fondo (lejos), +1 = hacia el primer plano (cerca).
     */
    @Volatile var moveY: Float = 0f
        private set

    /** v0.18: vector actual del joystick ([JOYSTICK_X], [JOYSTICK_Y] es el centro). 0,0 = centrado. */
    @Volatile var joystickX: Float = 0f
        private set
    @Volatile var joystickY: Float = 0f
        private set

    /** v0.18: true mientras un pulgar está apoyado en el joystick (el HUD dibuja la palanca activa). */
    @Volatile var joystickActive: Boolean = false
        private set

    /** Teclado: flecha izquierda / A. Los botones táctiles ◀ ▶ ya no existen (los sustituye el joystick). */
    @Volatile var leftHeld: Boolean = false
        private set
    @Volatile var rightHeld: Boolean = false
        private set

    /** v0.17: teclas W/S (fondo / primer plano). Los botones táctiles ▲ ▼ ya no existen (joystick). */
    @Volatile var depthUpHeld: Boolean = false
        private set
    @Volatile var depthDownHeld: Boolean = false
        private set

    /** v0.17: botón CORRER mantenido (o SHIFT en teclado). */
    @Volatile var runHeld: Boolean = false
        private set

    /** v0.18: sigilo (alterna con el botón SIGILO, con V o con [setModeToggle]). */
    @Volatile var sneakOn: Boolean = false
        private set

    /**
     * v0.18: agachado = MANTENER (botón AGACHARSE, tecla C o [setModeToggle]).
     * Al soltar, el niño se levanta. Excluyente con el sigilo: agachado manda.
     */
    @Volatile var crouchOn: Boolean = false
        private set

    /**
     * v0.17: modo de movimiento pedido: agachado > sigilo > correr (mantener) > andar.
     * La escena lo aplica al jugador ([com.terror2d.world.Player.requestMode]) con su
     * control de stamina; si no hay stamina para correr, el jugador cae a ANDAR.
     */
    val requestedMode: MoveMode
        get() = when {
            crouchOn -> MoveMode.CROUCH
            sneakOn -> MoveMode.SNEAK
            runHeld -> MoveMode.RUN
            else -> MoveMode.WALK
        }

    /** Lo escribe la escena: fracción de stamina 0..1 (la barra encima del botón CORRER). */
    @Volatile var staminaFraction: Float = 1f

    /** Lo escribe la escena: etiqueta del modo actual ("ANDAR" / "SIGILO" / "AGACHADO" / "CORRER"). */
    @Volatile var moveModeLabel: String = "ANDAR"

    /** Lo escribe la escena: true cuando el botón de acción debe mostrarse y aceptar toques. */
    @Volatile var actionEnabled: Boolean = false

    /**
     * v0.7: botón contextual HABLAR (compañero a la espalda y manos vacías). Lo escribe la escena. Es un segundo botón
     * encima del de acción para que se pueda hablar con el peluche aunque haya algo con lo que interactuar cerca.
     */
    @Volatile var talkEnabled: Boolean = false
    @Volatile var talkLabel: String = ""

    /** Capítulo I: botón del ESPEJO (alterna NORMAL/TRAUMA). Lo escribe la escena; arriba a la derecha. */
    @Volatile var mirrorEnabled: Boolean = false

    /** Lo escribe la escena (genérico, viene del interactuable enfocado): icono y texto del botón. */
    @Volatile var actionIcon: InteractionIcon = InteractionIcon.DOOR
    @Volatile var actionLabel: String = ""

    /** Lo escribe la escena: objeto que lleva en las manos (el HUD dibuja su icono). */
    @Volatile var heldItemId: String? = null

    /**
     * Lo escribe la escena: true durante la PRIMERA PERSONA (puzzle o conversación). Entonces los botones de la pantalla se
     * ignoran y el dedo se lee como puntero para arrastrar (ver [pointerDown], [pointerX], [pointerY]).
     */
    @Volatile var puzzleMode: Boolean = false

    /** Puntero primario (coordenadas lógicas 320x180): dedo apoyado, su posición y los flancos de pulsar / soltar. */
    @Volatile var pointerDown: Boolean = false
        private set
    @Volatile var pointerX: Float = 0f
        private set
    @Volatile var pointerY: Float = 0f
        private set
    @Volatile var pointerPressed: Boolean = false
        private set
    @Volatile var pointerReleased: Boolean = false
        private set

    /**
     * v0.10.1: true mientras el niño está ESCONDIDO en un armario. El dedo deja de ser un mando: los botones de
     * movimiento y de hablar se ignoran y arrastrar en horizontal desplaza la rendija de la máscara ([consumeClosetDrag]).
     * Un dedo que empezó a arrastrar nunca cuenta como pulsación del botón de acción, aunque pase por encima de él;
     * el botón de acción (salir del armario) sigue funcionando con un dedo distinto que lo pulse.
     */
    @Volatile var closetMode: Boolean = false

    private var dragId = -1
    private var dragLastX = 0f
    private var dragAcc = 0f

    /** Desplazamiento horizontal acumulado del dedo de arrastre desde la última lectura (px lógicos). */
    fun consumeClosetDrag(): Float { val d = dragAcc; dragAcc = 0f; return d }

    /** Simula el dedo de arrastre sin MotionEvent (pruebas, mandos): flancos pulsar / mover / soltar. */
    fun closetDragPoint(down: Boolean, x: Float) {
        if (!closetMode) { dragId = -1; return }
        if (down) {
            if (dragId == -1) { dragId = 0; dragLastX = x } else { dragAcc += x - dragLastX; dragLastX = x }
        } else dragId = -1
    }

    private val actionDown = BooleanArray(InputAction.values().size)
    private val actionPressed = BooleanArray(InputAction.values().size)

    private var touchAction = false
    private var touchTalk = false
    private var touchMirror = false
    private var touchRun = false
    /** v0.18: botón AGACHARSE mantenido (al soltar, el niño se levanta). */
    private var touchCrouch = false
    private var keyMirror = false
    private var keyLeft = false
    private var keyRight = false
    private var keyAction = false
    private var keyTalk = false
    private var keyDepthUp = false
    private var keyDepthDown = false
    private var keyRun = false
    /** v0.18: tecla C mantenida = agachado (antes alternaba; ahora es MANTENER como el botón). */
    private var keyCrouch = false
    private var keySneakDown = false
    /** v0.18: agachado pedido por [setModeToggle] (pruebas y mandos); no es un mantener. */
    private var modeCrouch = false

    /** v0.18: id del dedo que mueve el joystick (-1 = nadie). Lo sigue por id, no por posición. */
    private var joystickPointerId = -1

    fun isDown(action: InputAction): Boolean = actionDown[action.ordinal]

    /** true durante el primer update tras pulsar. */
    fun wasPressed(action: InputAction): Boolean = actionPressed[action.ordinal]

    fun setAction(action: InputAction, down: Boolean) {
        val i = action.ordinal
        if (down && !actionDown[i]) actionPressed[i] = true
        actionDown[i] = down
    }

    /** Se llama al final de cada update para limpiar las pulsaciones puntuales. */
    fun endFrame() {
        for (i in actionPressed.indices) actionPressed[i] = false
        pointerPressed = false
        pointerReleased = false
    }

    /**
     * Fija el puntero directamente (tests y mandos). Detecta los flancos: pulsar (down tras up) y soltar.
     * El dedo se mantiene en la última posición al soltar para que [pointerReleased] sepa dónde se soltó.
     */
    fun setPointer(down: Boolean, x: Float, y: Float) {
        pointerX = x
        pointerY = y
        if (down && !pointerDown) pointerPressed = true
        if (!down && pointerDown) pointerReleased = true
        pointerDown = down
    }

    /** Fija la dirección directamente (útil para tests y mandos). */
    fun setDirection(left: Boolean, right: Boolean) {
        keyLeft = left
        keyRight = right
        publish()
    }

    /** Fija la dirección en profundidad directamente (tests y mandos): up = hacia el fondo, down = primer plano. */
    fun setDepthInput(up: Boolean, down: Boolean) {
        keyDepthUp = up
        keyDepthDown = down
        publish()
    }

    /** Fija CORRER directamente (tests y mandos): mantener. */
    fun setRunHeld(held: Boolean) {
        keyRun = held
        publish()
    }

    /**
     * Fija el vector del joystick directamente (tests y mandos): valores continuos en [-1, 1].
     * Pasa por la zona muerta igual que el pulgar ([JOYSTICK_DEADZONE]); (0, 0) lo centra.
     */
    fun setJoystick(x: Float, y: Float) {
        updateJoystickVector(x * JOYSTICK_BASE_RADIUS, y * JOYSTICK_BASE_RADIUS)
        joystickActive = joystickX != 0f || joystickY != 0f
        if (!joystickActive) joystickPointerId = -1
        publish()
    }

    /** Fija el modo de sigilo directamente (tests y mandos): WALK quita sigilo y agachado. */
    fun setModeToggle(mode: MoveMode) {
        sneakOn = mode == MoveMode.SNEAK
        modeCrouch = mode == MoveMode.CROUCH
        publish()
    }

    /** Alterna agacharse (compatibilidad; el juego usa MANTENER: botón AGACHARSE o tecla C). Si se agacha, se quita el sigilo. */
    fun toggleCrouch() {
        modeCrouch = !modeCrouch
        if (modeCrouch) sneakOn = false
        publish()
    }

    /** Alterna el sigilo (tecla V o botón SIGILO). Si entra en sigilo, se quita agacharse. */
    fun toggleSneak() {
        sneakOn = !sneakOn
        if (sneakOn) modeCrouch = false
        publish()
    }

    // ------------------------------------------------------------------ toque

    /** Un dedo activo en coordenadas lógicas. El camino de MotionEvent y el de pruebas usan el mismo. */
    private data class TouchPointer(val id: Int, val x: Float, val y: Float)

    /** Dedos virtuales de la costura de pruebas ([touchDown]/[touchMove]/[touchUp]), en orden de apoyo. */
    private val virtualPointers = LinkedHashMap<Int, TouchPointer>()

    /**
     * Costura de pruebas y mandos: un dedo virtual apoya en coordenadas lógicas (320x180).
     * Reproduce [onTouchEvent] sin MotionEvent. Si [id] ya estaba apoyado, se trata como
     * movimiento, no como pulsación nueva (igual que un ACTION_MOVE).
     */
    fun touchDown(id: Int, x: Float, y: Float) {
        val isNew = !virtualPointers.containsKey(id)
        val p = TouchPointer(id, x, y)
        virtualPointers[id] = p
        handleTouch(virtualPointers.values.toList(), if (isNew) p else null, -1)
    }

    /** Costura de pruebas y mandos: el dedo virtual [id] se desliza hasta (x, y). */
    fun touchMove(id: Int, x: Float, y: Float) {
        if (!virtualPointers.containsKey(id)) return
        virtualPointers[id] = TouchPointer(id, x, y)
        handleTouch(virtualPointers.values.toList(), null, -1)
    }

    /** Costura de pruebas y mandos: el dedo virtual [id] se levanta. */
    fun touchUp(id: Int) {
        if (virtualPointers.remove(id) == null) return
        handleTouch(virtualPointers.values.toList(), null, id)
    }

    /** Costura de pruebas: todos los dedos virtuales se cancelan (como un ACTION_CANCEL). */
    fun touchCancel() {
        virtualPointers.clear()
        resetTouchState()
    }

    /**
     * Recalcula el estado táctil con TODOS los dedos activos, de modo que deslizar el dedo
     * de un botón a otro cambia de dirección y varios dedos conviven (mover + actuar).
     * El joystick se sigue por id de dedo: el pulgar que lo agarró lo conserva aunque se
     * deslice fuera de su base (el vector se limita al radio máximo).
     */
    fun onTouchEvent(e: MotionEvent, viewport: Viewport): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_CANCEL) {
            resetTouchState()
            return true
        }
        val lifting = e.actionMasked == MotionEvent.ACTION_UP ||
            e.actionMasked == MotionEvent.ACTION_POINTER_UP
        val skip = if (lifting) e.actionIndex else -1
        val pointers = ArrayList<TouchPointer>(e.pointerCount)
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            pointers.add(TouchPointer(e.getPointerId(i), viewport.toLogicalX(e.getX(i)), viewport.toLogicalY(e.getY(i))))
        }
        val down: TouchPointer? = when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val di = e.actionIndex
                TouchPointer(e.getPointerId(di), viewport.toLogicalX(e.getX(di)), viewport.toLogicalY(e.getY(di)))
            }
            else -> null
        }
        val upId = if (lifting) e.getPointerId(e.actionIndex) else -1
        handleTouch(pointers, down, upId)
        return true
    }

    /** Limpia todo el estado táctil (cancelación, cambio de modo): botones, joystick y arrastre. */
    private fun resetTouchState() {
        touchAction = false
        touchTalk = false
        touchMirror = false
        touchRun = false
        touchCrouch = false
        dragId = -1
        releaseJoystick()
        if (pointerDown) setPointer(false, pointerX, pointerY)
        publish()
    }

    /** Suelta el joystick y centra su vector. */
    private fun releaseJoystick() {
        joystickPointerId = -1
        joystickX = 0f
        joystickY = 0f
        joystickActive = false
    }

    /**
     * Vector del joystick desde un desplazamiento en px lógicos respecto a su centro.
     * Zona muerta [JOYSTICK_DEADZONE] (el tembleque del pulgar no mueve al niño) y después
     * velocidad PROPORCIONAL al empuje: lineal de 0 en el borde de la zona muerta a 1 en el
     * radio máximo [JOYSTICK_BASE_RADIUS]. Fuera del radio, la dirección se conserva y la
     * magnitud se limita a 1 (la palanca queda en el borde).
     */
    private fun updateJoystickVector(dx: Float, dy: Float) {
        val rx = dx / JOYSTICK_BASE_RADIUS
        val ry = dy / JOYSTICK_BASE_RADIUS
        val m = sqrt(rx * rx + ry * ry)
        if (m <= JOYSTICK_DEADZONE) {
            joystickX = 0f
            joystickY = 0f
            return
        }
        val t = ((m - JOYSTICK_DEADZONE) / (1f - JOYSTICK_DEADZONE)).coerceIn(0f, 1f)
        joystickX = (rx / m) * t
        joystickY = (ry / m) * t
    }

    private fun handleTouch(pointers: List<TouchPointer>, down: TouchPointer?, upId: Int) {
        // puntero primario: el primer dedo que sigue apoyado (para arrastrar las cajas del puzzle)
        val primary = pointers.firstOrNull()
        if (primary != null) setPointer(true, primary.x, primary.y)
        else setPointer(false, pointerX, pointerY)

        if (closetMode) {
            touchAction = false
            touchTalk = false
            touchMirror = false
            touchRun = false
            touchCrouch = false
            releaseJoystick()
            if (down != null) {
                val inAction = down.x >= ACTION_ZONE_START && down.y >= HUD_TOP
                if (!inAction && dragId == -1) { dragId = down.id; dragLastX = down.x }
            }
            if (upId == dragId) dragId = -1
            val dragPointer = pointers.firstOrNull { it.id == dragId }
            if (dragPointer != null) {
                dragAcc += dragPointer.x - dragLastX
                dragLastX = dragPointer.x
            }
            var a = false
            for (p in pointers) {
                if (p.id == dragId) continue
                if (p.y >= HUD_TOP && p.x >= ACTION_ZONE_START && actionEnabled) a = true
            }
            touchAction = a
            publish()
            return
        }
        if (puzzleMode) {
            touchAction = false
            touchTalk = false
            touchMirror = false
            touchRun = false
            touchCrouch = false
            releaseJoystick()
            publish()
            return
        }

        // --- joystick: el dedo que baja dentro de su zona de captura lo agarra; al levantarse se suelta ---
        if (upId == joystickPointerId) releaseJoystick()
        if (down != null && joystickPointerId == -1 &&
            dist(down.x, down.y, JOYSTICK_X, JOYSTICK_Y) <= JOYSTICK_CAPTURE_RADIUS
        ) {
            joystickPointerId = down.id
            joystickActive = true
            updateJoystickVector(down.x - JOYSTICK_X, down.y - JOYSTICK_Y)
        }
        val joyPointer = pointers.firstOrNull { it.id == joystickPointerId }
        if (joyPointer != null) updateJoystickVector(joyPointer.x - JOYSTICK_X, joyPointer.y - JOYSTICK_Y)

        var a = false
        var tk = false
        var mr = false
        var rn = false
        var cr = false
        // SIGILO alterna solo en el flanco (al apoyar el dedo, no mientras se mantiene)
        if (down != null && down.x in SIDE_BTN_ZONE_X0..SIDE_BTN_ZONE_X1 &&
            down.y >= HUD_TOP && down.y < SIDE_ROW_SPLIT_Y
        ) toggleSneak()
        for (p in pointers) {
            if (p.id == joystickPointerId) continue
            val lx = p.x
            val ly = p.y
            if (mirrorEnabled && lx >= MIRROR_ZONE_X && ly < MIRROR_ZONE_END_Y) { mr = true; continue }
            if (ly < HUD_TOP) continue
            if (lx in SIDE_BTN_ZONE_X0..SIDE_BTN_ZONE_X1) {
                if (ly < SIDE_ROW_SPLIT_Y) { /* SIGILO: alterna en el flanco, no se mantiene */ }
                else cr = true
            } else if (lx in RUN_ZONE_X0..RUN_ZONE_X1) {
                if (ly >= SIDE_ROW_SPLIT_Y) rn = true
            } else if (lx >= ACTION_ZONE_START) {
                // con HABLAR visible, la zona superior del lado derecho es HABLAR y la inferior la acción
                if (talkEnabled && ly < TALK_ZONE_END_Y) tk = true
                else if (ly >= TALK_ZONE_END_Y && actionEnabled) a = true
            }
        }
        touchAction = a
        touchTalk = tk
        touchMirror = mr
        touchRun = rn
        touchCrouch = cr
        publish()
    }

    private fun dist(x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x1 - x2
        val dy = y1 - y2
        return sqrt(dx * dx + dy * dy)
    }

    /**
     * Teclado (emulador / mando): flechas o A/D; ESPACIO, ENTER o E = acción.
     * v0.17: W/S o ↑/↓ = profundidad, SHIFT = correr (mantener), V = sigilo (alternar), T/Q = hablar, M = espejo.
     * v0.18: C = agacharse MANTENER (antes alternaba; ahora igual que el botón: al soltar, el niño se levanta).
     */
    fun onKey(keyCode: Int, down: Boolean): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_A -> keyLeft = down
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_D -> keyRight = down
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_W -> keyDepthUp = down
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_S -> keyDepthDown = down
            KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_SHIFT_RIGHT -> keyRun = down
            KeyEvent.KEYCODE_C -> keyCrouch = down
            KeyEvent.KEYCODE_V -> {
                if (down && !keySneakDown) toggleSneak()
                keySneakDown = down
            }
            KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_E -> keyAction = down
            KeyEvent.KEYCODE_T, KeyEvent.KEYCODE_Q -> keyTalk = down
            KeyEvent.KEYCODE_M -> keyMirror = down
            else -> return false
        }
        publish()
        return true
    }

    private fun publish() {
        leftHeld = keyLeft
        rightHeld = keyRight
        var mx = joystickX
        if (leftHeld) mx -= 1f
        if (rightHeld) mx += 1f
        moveX = mx.coerceIn(-1f, 1f)
        depthUpHeld = keyDepthUp
        depthDownHeld = keyDepthDown
        var my = joystickY
        if (depthUpHeld) my -= 1f
        if (depthDownHeld) my += 1f
        moveY = my.coerceIn(-1f, 1f)
        runHeld = touchRun || keyRun
        crouchOn = touchCrouch || keyCrouch || modeCrouch
        setAction(InputAction.INTERACT, touchAction || keyAction)
        setAction(InputAction.TALK, touchTalk || keyTalk)
        setAction(InputAction.MIRROR, touchMirror || keyMirror)
        setAction(InputAction.RUN, runHeld)
        setAction(InputAction.SNEAK, sneakOn)
        setAction(InputAction.CROUCH, crouchOn)
    }

    companion object {
        // ------------------------------------------------------------------ joystick virtual (v0.18)
        // Fijo abajo a la izquierda, coordenadas lógicas. La palanca viaja hasta JOYSTICK_BASE_RADIUS
        // px desde el centro (a tope = velocidad completa); la zona de captura es algo mayor que la
        // base para que el pulgar no tenga que acertar al milímetro.
        const val JOYSTICK_X = 46f
        const val JOYSTICK_Y = 140f
        const val JOYSTICK_BASE_RADIUS = 26f
        const val JOYSTICK_KNOB_RADIUS = 10f
        const val JOYSTICK_CAPTURE_RADIUS = 36f
        /** Empuje mínimo que mueve al niño (fracción del radio máximo): por debajo, el pulgar tiembla en vano. */
        const val JOYSTICK_DEADZONE = 0.15f

        // ------------------------------------------------------------------ botones derechos (v0.18)
        // Dos columnas: SIGILO (alternar) y AGACHARSE (mantener) en x 190..228; CORRER (mantener)
        // en x 228..272; ACCIÓN (grande) en x >= 272. Fila superior y 100..140, inferior y >= 140.
        const val SNEAK_X = 208f
        const val SNEAK_Y = 122f
        const val SNEAK_BTN_RADIUS = 10f
        const val CROUCH_X = 208f
        const val CROUCH_Y = 160f
        const val CROUCH_BTN_RADIUS = 11f
        const val RUN_X = 250f
        const val RUN_Y = 158f
        const val RUN_BTN_RADIUS = 12f
        const val ACTION_X = 296f
        const val BTN_Y = 158f
        const val TALK_Y = 126f
        const val TALK_ZONE_END_Y = 140f
        const val BTN_RADIUS = 12f
        const val MIRROR_X = 296f
        const val MIRROR_Y = 22f
        const val MIRROR_ZONE_X = 262f
        const val MIRROR_ZONE_END_Y = 46f

        // Zonas de toque (generosas, incluyen las barras negras laterales).
        const val HUD_TOP = 100f
        /** v0.18: la zona de acción empieza en 272 (antes 240): el hueco 228..272 es CORRER. */
        const val ACTION_ZONE_START = 272f
        const val RUN_ZONE_X0 = 228f
        const val RUN_ZONE_X1 = 272f
        /** Columna SIGILO / AGACHARSE (x 190..228); la fila la parte SIDE_ROW_SPLIT_Y. */
        const val SIDE_BTN_ZONE_X0 = 190f
        const val SIDE_BTN_ZONE_X1 = 228f
        const val SIDE_ROW_SPLIT_Y = 140f
    }
}
