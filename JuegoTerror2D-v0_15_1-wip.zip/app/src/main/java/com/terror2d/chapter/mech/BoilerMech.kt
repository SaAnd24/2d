package com.terror2d.chapter.mech

import com.terror2d.audio.SfxId

/**
 * T4 — La caldera que respira. Cuatro válvulas sobre cuatro tuberías, con 12 posiciones (detentes de 30°) cada una.
 * Se giran con un gesto circular sobre la válvula o con los botones ◀ ▶ de debajo. Cada posición cambia el RITMO de
 * golpes de su tubería (se oye y se ve pulsar) y mueve el manómetro. Junto a cada válvula hay una figura de referencia.
 *
 *   posiciones 0-2 = callada · 3-5 = continua · 6-8 = dos golpes y espera · 9-11 = ciclo incompleto (se apaga)
 *   De izquierda a derecha: la tubería más cercana a la pared es la CALLADA (D10), después dos golpes, continua e incompleta.
 *
 * Una válvula que alcanza su banda correcta se TRABA y conserva su ajuste mientras se trabaja en las demás.
 */
class BoilerMech : Mechanism("T4") {

    val count = 4
    val valveX = floatArrayOf(50f, 130f, 210f, 290f)
    val valveY = 100f

    /** Banda objetivo de cada válvula (0 callada, 1 continua, 2 dos golpes, 3 incompleta). */
    val targetBand = intArrayOf(0, 2, 1, 3)
    val detent = intArrayOf(7, 10, 1, 4)
    val locked = BooleanArray(4)
    private val dwell = FloatArray(4)
    private var active = -1
    private val lastTouch = FloatArray(4) { -99f }
    /** Fase del ritmo de cada tubería (segundos dentro de su ciclo) y pulso visual 0..1. */
    private val phase = FloatArray(4)
    val pulse = FloatArray(4)
    var gauge = 0.5f
        private set

    fun band(d: Int): Int = d / 3

    /** 1 = en su banda, 0.5 = en la banda vecina (el patrón coincide solo en parte), 0 = lejos. */
    fun closeness(v: Int): Float {
        val b = band(detent[v])
        return when {
            b == targetBand[v] -> 1f
            kotlin.math.abs(b - targetBand[v]) == 1 -> 0.5f
            else -> 0f
        }
    }

    val allLocked: Boolean get() = locked.all { it }
    val lockedCount: Int get() = locked.count { it }

    /** 0..1 de cuánto ha bajado el agua del pasadizo tras resolver. */
    val waterDrop: Float get() = if (!solved) 0f else (solvedTime / 3.0f).coerceIn(0f, 1f)

    private fun valveAt(x: Float, y: Float): Int {
        for (v in 0 until count) if (dist(x, y, valveX[v], valveY) <= 28f) return v
        return -1
    }

    private fun buttonAt(x: Float, y: Float): Int {
        // 2*v = girar atrás, 2*v+1 = girar adelante
        for (v in 0 until count) {
            if (y in 140f..166f) {
                if (kotlin.math.abs(x - (valveX[v] - 16f)) <= 13f) return 2 * v
                if (kotlin.math.abs(x - (valveX[v] + 16f)) <= 13f) return 2 * v + 1
            }
        }
        return -1
    }

    override fun onDown(x: Float, y: Float) {
        active = -1
        val b = buttonAt(x, y)
        if (b >= 0) {
            step(b / 2, if (b % 2 == 0) -1 else 1)
            return
        }
        val v = valveAt(x, y)
        if (v >= 0) {
            if (locked[v]) { say("Esa válvula ya está ajustada. Se queda así.", 1.8f); return }
            active = v
        }
    }

    override fun onMove(x: Float, y: Float, dx: Float, dy: Float) {
        val v = active
        if (v < 0) return
        val a = angleOf(valveX[v], valveY, x, y)
        var f = (a + 90f) / 30f
        if (f < 0f) f += 12f
        val target = (Math.round(f) % 12 + 12) % 12
        if (target != detent[v]) {
            // sigue la mano por el camino más corto: nunca salta de golpe media vuelta
            var d = target - detent[v]
            if (d > 6) d -= 12
            if (d < -6) d += 12
            step(v, if (d > 0) 1 else -1)
        }
    }

    override fun onUp(x: Float, y: Float) { active = -1 }

    private fun step(v: Int, dir: Int) {
        if (locked[v]) return
        detent[v] = ((detent[v] + dir) % 12 + 12) % 12
        lastTouch[v] = time
        phase[v] = 0f
        play(SfxId.MECH_METAL_CLINK, 0.35f) // el mando gira con un clic metálico
    }

    /** Instantes (0..cycle) y fuerza de los golpes de cada banda. Ciclo de 1.4 s. */
    private fun knocks(band: Int): Array<FloatArray> = when (band) {
        0 -> emptyArray()
        1 -> arrayOf(floatArrayOf(0f, 1f), floatArrayOf(0.35f, 1f), floatArrayOf(0.7f, 1f), floatArrayOf(1.05f, 1f))
        2 -> arrayOf(floatArrayOf(0f, 1f), floatArrayOf(0.28f, 1f))
        else -> arrayOf(floatArrayOf(0f, 0.9f), floatArrayOf(0.30f, 0.55f), floatArrayOf(0.58f, 0.25f))
    }

    override fun update(dt: Float) {
        var sum = 0f
        for (v in 0 until count) {
            val b = band(detent[v])
            sum += b
            val loud = locked[v] || time - lastTouch[v] < 3f
            val before = phase[v]
            phase[v] += dt
            if (phase[v] >= CYCLE) phase[v] -= CYCLE
            val ks = knocks(b)
            for (k in ks) {
                val crossed = if (phase[v] >= before) k[0] > before && k[0] <= phase[v] else (k[0] > before || k[0] <= phase[v])
                if (crossed) {
                    pulse[v] = k[1]
                    if (loud) play(SfxId.MECH_PIPE, 0.28f + 0.1f * v + (if (locked[v]) -0.1f else 0f))
                }
            }
            if (pulse[v] > 0f) pulse[v] = (pulse[v] - dt * 3.5f).coerceAtLeast(0f)
            // ajuste correcto sostenido => la válvula se traba
            if (!locked[v]) {
                if (closeness(v) >= 1f && active != v) {
                    dwell[v] += dt
                    if (dwell[v] > 0.9f) {
                        locked[v] = true
                        play(SfxId.MECH_METAL_CLINK, 0.8f)
                        play(SfxId.MECH_PIPE, 0.6f)
                        say("La tubería encuentra su ritmo y se queda así.", 2.4f)
                    }
                } else dwell[v] = 0f
            }
        }
        // el manómetro sigue la posición de las válvulas (más ritmo = más aguja) y se estabiliza al fijarlas
        val goal = if (solved) 0.5f else 0.2f + (sum / 12f) * 0.6f + (if (active >= 0) 0.04f else 0f)
        gauge += (goal - gauge) * (1f - kotlin.math.exp(-3f * dt))
        if (!solved && allLocked) {
            markSolved()
            // golpe final, silencio y una cola grave que se apaga
            later(0.3f, SfxId.MECH_PIPE, 1f)
            later(1.2f, SfxId.MECH_DEEP_THUMP, 1f)
            later(2.6f, SfxId.MECH_RESONANCE, 0.5f)
            later(3.2f, SfxId.PUZZLE_SOLVED, 0.45f)
        }
    }

    override fun solvedHold(): Float = 4.2f

    companion object {
        const val CYCLE = 1.4f
    }
}
