package com.terror2d.chapter.mech

import com.terror2d.audio.SfxId

/**
 * N5 — El cuadro eléctrico. Cuatro ramas de cobre salen de la izquierda; cuatro terminales de cerámica (con la
 * silueta del lugar al que alimentan) están a la derecha. El jugador ARRASTRA el extremo de cada cable y lo guía con
 * el dedo hasta un terminal. La rama que recibe corriente emite su pulso (zumbido): el que se oye y se ve parpadear en
 * la lámpara del terminal debe ser el que se observó en la casa:
 *   vestíbulo = zumbido regular · cocina = tarda en estabilizarse · pasillo = cambia pasado un rato · sótano = la última.
 * Una conexión incompatible chisporrotea, el cable cae flojo y vuelve; la correcta se queda conectada.
 */
class FuseBoxMech : Mechanism("N5") {

    /** Firma de cada rama (0 regular, 1 se estabiliza despacio, 2 cambia tras un intervalo, 3 la última). */
    val branchSig = intArrayOf(3, 0, 2, 1)
    /** Circuito que alimenta cada terminal, de arriba abajo: pasillo, vestíbulo, sótano, cocina. */
    val terminalCircuit = intArrayOf(2, 0, 3, 1)

    val endX = FloatArray(4) { SRC_X + 14f }
    val endY = FloatArray(4) { SRC_Y[it] }
    /** Terminal al que está unido cada cable (-1 = suelto). */
    val connected = IntArray(4) { -1 }
    private val locked = BooleanArray(4)
    private var active = -1
    /** Cable en prueba (conectado de forma tentativa a un terminal incompatible). */
    private val testing = IntArray(4) { -1 }
    private val testTime = FloatArray(4)
    /** Posición 0..1 del pulso que viaja por cada cable. */
    val pulse = FloatArray(4) { -1f }
    var lampFlash = FloatArray(4)
        private set

    val lockedCount: Int get() = locked.count { it }
    fun isLocked(b: Int) = locked[b]
    fun isTesting(b: Int) = testing[b] >= 0
    fun testingTerminal(b: Int) = testing[b]

    private fun terminalAt(x: Float, y: Float): Int {
        for (t in 0 until 4) if (dist(x, y, TERM_X, TERM_Y[t]) <= 20f) return t
        return -1
    }

    private fun terminalTaken(t: Int): Boolean {
        for (b in 0 until 4) if (locked[b] && connected[b] == t) return true
        return false
    }

    override fun onDown(x: Float, y: Float) {
        active = -1
        for (b in 0 until 4) {
            if (locked[b]) continue
            if (dist(x, y, endX[b], endY[b]) <= 18f) {
                active = b
                testing[b] = -1
                connected[b] = -1
                // al tocar la punta de cobre sale su pulso de prueba (se oye su firma)
                pulse[b] = 0f
                play(SfxId.MECH_METAL_CLINK, 0.4f)
                return
            }
        }
    }

    override fun onMove(x: Float, y: Float, dx: Float, dy: Float) {
        val b = active
        if (b < 0) return
        endX[b] = x.coerceIn(SRC_X + 8f, 296f)
        endY[b] = y.coerceIn(30f, 166f)
    }

    override fun onUp(x: Float, y: Float) {
        val b = active
        active = -1
        if (b < 0) return
        val t = terminalAt(endX[b], endY[b])
        if (t < 0 || terminalTaken(t)) {
            if (t >= 0) say("Ese terminal ya tiene su rama.", 1.8f)
            return // el cable queda suelto y recupera su reposo en update()
        }
        endX[b] = TERM_X - 12f
        endY[b] = TERM_Y[t]
        play(SfxId.MECH_METAL_CLINK, 0.7f)
        pulse[b] = 0f
        if (branchSig[b] == terminalCircuit[t]) {
            locked[b] = true
            connected[b] = t
            lampFlash[t] = 1f
            later(0.35f, SfxId.MECH_ZAP, 0.35f)
        } else {
            testing[b] = t
            testTime[b] = 0f
            connected[b] = t
            lampFlash[t] = 0.6f
            play(SfxId.MECH_ZAP, 0.7f)
            mistake("El zumbido no es el que oí en la casa.")
        }
    }

    override fun update(dt: Float) {
        for (b in 0 until 4) {
            if (pulse[b] >= 0f) {
                pulse[b] += dt * 1.1f
                if (pulse[b] > 1.2f) pulse[b] = -1f
            }
            if (lampFlash[b] > 0f) lampFlash[b] = (lampFlash[b] - dt * 0.8f).coerceAtLeast(0f)
            if (testing[b] >= 0) {
                testTime[b] += dt
                if (testTime[b] > 1.4f) {
                    // la conexión incompatible se apaga y el cable vuelve; el progreso del resto no se toca
                    testing[b] = -1
                    connected[b] = -1
                    endX[b] = SRC_X + 14f
                    endY[b] = SRC_Y[b]
                    play(SfxId.MECH_MUFFLED, 0.3f)
                }
            } else if (!locked[b] && active != b && connected[b] < 0) {
                // un cable suelto vuelve despacio a su reposo (se curva al moverse)
                endX[b] += (SRC_X + 14f - endX[b]) * (1f - kotlin.math.exp(-5f * dt))
                endY[b] += (SRC_Y[b] - endY[b]) * (1f - kotlin.math.exp(-5f * dt))
            }
        }
        if (!solved && lockedCount == 4) {
            markSolved()
            later(0.3f, SfxId.MS_HUM_CUT, 0.5f)
            later(1.2f, SfxId.PUZZLE_SOLVED, 0.6f)
        }
    }

    /** Estabilización de la luz del distribuidor tras resolver (0..1), visible en los indicadores del panel. */
    val steady: Float get() = if (!solved) 0f else (solvedTime / 2.2f).coerceIn(0f, 1f)

    override fun solvedHold(): Float = 3.0f

    companion object {
        const val SRC_X = 28f
        val SRC_Y = floatArrayOf(48f, 84f, 120f, 156f)
        const val TERM_X = 276f
        val TERM_Y = floatArrayOf(48f, 84f, 120f, 156f)
    }
}
