package com.terror2d.chapter.mech

import com.terror2d.audio.SfxId
import kotlin.math.abs

/**
 * T2 — El retrato sin rostro. El retrato está cubierto de grafito y tiene cuatro huecos blancos de contorno.
 * En la cómoda hay cuatro piezas de madera; cada una comparte borde con un hueco. Se ARRASTRAN sobre la imagen y se
 * giran con un toque (cuartos de vuelta). Una pieza encaja solo en el hueco cuyo borde coincide con su silueta y en
 * su orientación. Los contornos blancos se afinan al acercar la pieza correcta; una pieza equivocada TAPA el borde
 * que debería verse. Nada es definitivo: las piezas se pueden volver a coger. Al completar, las líneas blancas se
 * unen en el símbolo de tres líneas y un punto.
 * Hueco 0 (esquina) = pieza en L · hueco 1 (cuatro brazos) = cruz · hueco 2 (borde curvo) = redonda · hueco 3 (largo) = alargada.
 */
class PortraitMech : Mechanism("T2") {

    enum class Shape { L, CROSS, ROUND, LONG }

    val pieces = arrayOf(Draggable(236f, 56f, 22f), Draggable(286f, 56f, 22f), Draggable(236f, 112f, 22f), Draggable(280f, 128f, 22f))
    val shapes = arrayOf(Shape.L, Shape.CROSS, Shape.ROUND, Shape.LONG)
    val rot = intArrayOf(1, 0, 0, 0)

    /** Centro y forma de cada hueco; `holeRot` = giro con el que encaja la pieza (0..3). */
    val holeX = floatArrayOf(62f, 150f, 66f, 146f)
    val holeY = floatArrayOf(60f, 56f, 120f, 122f)
    val holeShape = arrayOf(Shape.L, Shape.CROSS, Shape.ROUND, Shape.LONG)
    val holeRot = intArrayOf(0, 0, 0, 1)

    private var active = -1
    private var moved = 0f
    private var slideCool = 0f
    private val placed = BooleanArray(4)
    private val dust = ArrayList<FloatArray>()

    val dustTrail: List<FloatArray> get() = dust

    fun isPlaced(p: Int) = placed[p]

    /** Hueco al que encaja la pieza [p] si está bien orientada. */
    private fun holeOf(p: Int): Int = holeShape.indexOf(shapes[p])

    private fun orientationOk(p: Int): Boolean {
        val h = holeOf(p)
        return when (shapes[p]) {
            Shape.CROSS, Shape.ROUND -> true
            Shape.LONG -> rot[p] % 2 == holeRot[h] % 2
            Shape.L -> rot[p] % 4 == holeRot[h]
        }
    }

    /** 0..1: cuánto se acerca el borde de la pieza a su contorno (afina la línea blanca). */
    fun edgeSharpness(h: Int): Float {
        var best = 0f
        for (p in 0 until 4) {
            if (holeOf(p) != h) continue
            val d = dist(pieces[p].x, pieces[p].y, holeX[h], holeY[h])
            val ok = if (orientationOk(p)) 1f else 0.55f
            val c = if (d >= 40f) 0f else (1f - d / 40f) * ok
            if (c > best) best = c
        }
        return if (placed[h2p(h)]) 1f else best
    }

    private fun h2p(h: Int): Int = shapes.indexOf(holeShape[h])

    /** true si el hueco [h] está cubierto por una pieza que no es la suya (oculta su borde). */
    fun coveredWrong(h: Int): Boolean {
        for (p in 0 until 4) {
            if (holeOf(p) == h) continue
            if (dist(pieces[p].x, pieces[p].y, holeX[h], holeY[h]) < 20f) return true
        }
        return false
    }

    override fun onDown(x: Float, y: Float) {
        active = -1
        var best = -1
        var bd = 1e9f
        for (p in 0 until 4) {
            val d = dist(x, y, pieces[p].x, pieces[p].y)
            if (d <= pieces[p].grab + 4f && d < bd) { bd = d; best = p }
        }
        if (best < 0) return
        active = best
        moved = 0f
        pieces[best].begin(x, y)
        placed[best] = false
        play(SfxId.MECH_WOOD_CLICK, 0.3f)
    }

    override fun onMove(x: Float, y: Float, dx: Float, dy: Float) {
        val p = active
        if (p < 0) return
        moved += abs(dx) + abs(dy)
        pieces[p].dragTo(x, y, 14f, 22f, 306f, 166f)
        // polvo de grafito en el rastro
        if (dust.size < 60 && (abs(dx) + abs(dy)) > 1.5f) dust.add(floatArrayOf(pieces[p].x, pieces[p].y + 8f, 1f))
        if (slideCool <= 0f) {
            slideCool = 0.18f
            play(SfxId.MS_PENCIL, 0.18f)
        }
    }

    override fun onUp(x: Float, y: Float) {
        val p = active
        active = -1
        if (p < 0) return
        pieces[p].end()
        if (moved < 5f) {
            rot[p] = (rot[p] + 1) % 4
            play(SfxId.MECH_WOOD_CLICK, 0.4f)
            return
        }
        val h = holeOf(p)
        val d = dist(pieces[p].x, pieces[p].y, holeX[h], holeY[h])
        if (d <= SNAP && orientationOk(p)) {
            pieces[p].x = holeX[h]
            pieces[p].y = holeY[h]
            placed[p] = true
            play(SfxId.MECH_WOOD_CLICK, 0.8f)
        } else {
            // si la dejas sobre un hueco que no es el suyo, tapa su borde: solo se nota que falta la línea
            for (hh in 0 until 4) {
                if (hh != h && dist(pieces[p].x, pieces[p].y, holeX[hh], holeY[hh]) < 20f) {
                    mistake("Esta pieza tapa el borde. Ese contorno no era suyo.")
                    break
                }
            }
            if (d < 24f && !orientationOk(p)) say("El borde casi coincide, pero la pieza está girada.", 2.2f)
        }
    }

    override fun update(dt: Float) {
        if (slideCool > 0f) slideCool -= dt
        for (i in dust.indices.reversed()) {
            dust[i][2] -= dt * 0.5f
            if (dust[i][2] <= 0f) dust.removeAt(i)
        }
        if (!solved && placed.all { it }) {
            markSolved()
            later(0.3f, SfxId.MS_PENCIL, 0.5f)
            later(1.0f, SfxId.MECH_RESONANCE, 0.5f)
            later(1.8f, SfxId.PUZZLE_SOLVED, 0.5f)
        }
    }

    /** 0..1 de cuánto se ha formado el símbolo de tres líneas y un punto. */
    val symbol: Float get() = if (!solved) 0f else ((solvedTime - 0.3f) / 1.8f).coerceIn(0f, 1f)

    override fun solvedHold(): Float = 5.5f

    companion object {
        const val SNAP = 10f
    }
}
