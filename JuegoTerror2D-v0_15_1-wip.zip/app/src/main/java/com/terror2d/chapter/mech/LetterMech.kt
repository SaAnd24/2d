package com.terror2d.chapter.mech

import com.terror2d.audio.SfxId
import kotlin.math.abs

/**
 * C4 — La carta partida. Dos hojas rotas (fragmentos A y B de D14) sobre el escritorio. Se DESLIZAN con el dedo y se
 * giran con un toque (mitad izquierda = -6°, mitad derecha = +6°) hasta que la línea de rasgado coincide: las fibras
 * del borde forman una línea continua. Con una superposición incorrecta, las palabras de la unión se ven
 * desplazadas. Con los bordes alineados aparecen marcas en el margen; para leerlas hay que cambiar de mundo con el
 * espejo (icono de la esquina) sin que las hojas se muevan: en NORMAL se ven las líneas escritas y el zigzag y el
 * rectángulo; en TRAUMA aparecen los huecos de grafito y la línea alta. Cuando se han visto las tres marcas en
 * ambos mundos, la carta queda reconstruida: «Mira desde donde la casa no debería tener ventanas».
 */
class LetterMech : Mechanism("C4") {

    val a = Draggable(100f, 96f, 34f)
    val b = Draggable(228f, 110f, 34f)
    var rotA = 21f
    var rotB = -27f

    /** Perfil de rasgado: el borde derecho de A y el izquierdo de B son complementarios (9 puntos). */
    val tear = floatArrayOf(0f, 4f, -3f, 5f, -2f, 3f, -4f, 2f, 0f)

    /** Vista local del mundo (el espejo de la esquina cambia lo que se ve; las hojas no se mueven). */
    var viewTrauma: Boolean? = null
        private set
    val seeingTrauma: Boolean get() = viewTrauma ?: trauma

    private var active = 0 // 1 = A, 2 = B
    private var moved = 0f
    private var downX = 0f
    private var seenNormal = 0f
    private var seenTrauma = 0f
    private var revealGlow = 0f

    /** Marcas del margen visibles ahora, 0..3 (zigzag, rectángulo en NORMAL; línea alta solo en TRAUMA). */
    var marksShown = 0
        private set
    var worldsSeen = 0
        private set

    /** Error de alineación en píxeles (0 = bordes exactos). Solo cuenta si las dos hojas están derechas. */
    fun gapError(): Float {
        val dx = abs((b.x - a.x) - FRAG_W)
        val dy = abs(b.y - a.y)
        return maxOf(dx, dy)
    }

    fun uprightBoth(): Boolean = abs(rotA) <= ROT_TOL && abs(rotB) <= ROT_TOL

    val aligned: Boolean get() = uprightBoth() && gapError() <= TOL

    /** 0..1 de cuánto se parecen los bordes (las fibras se unen a medida que te acercas). */
    val fiberJoin: Float get() {
        val e = gapError() + (abs(rotA) + abs(rotB)) * 0.4f
        return if (e >= 24f) 0f else 1f - e / 24f
    }

    fun mirrorHit(x: Float, y: Float): Boolean = canToggleWorld && dist(x, y, 296f, 22f) <= 18f

    override fun onDown(x: Float, y: Float) {
        active = 0
        if (mirrorHit(x, y)) {
            viewTrauma = !seeingTrauma
            play(SfxId.MS_PENCIL, 0.5f) // las marcas aparecen con un breve trazo animado
            revealGlow = 1f
            return
        }
        val ha = abs(x - a.x) <= FRAG_W / 2f + 4f && abs(y - a.y) <= FRAG_H / 2f + 4f
        val hb = abs(x - b.x) <= FRAG_W / 2f + 4f && abs(y - b.y) <= FRAG_H / 2f + 4f
        if (hb && (!ha || lastTouchedB)) {
            active = 2; b.begin(x, y)
        } else if (ha) {
            active = 1; a.begin(x, y)
        } else if (hb) {
            active = 2; b.begin(x, y)
        }
        if (active != 0) {
            lastTouchedB = active == 2
            moved = 0f
            downX = x
            play(SfxId.MECH_PAPER_FLEX, 0.35f)
        }
    }

    private var lastTouchedB = false

    override fun onMove(x: Float, y: Float, dx: Float, dy: Float) {
        moved += abs(dx) + abs(dy)
        when (active) {
            1 -> a.dragTo(x, y, 50f, 56f, 270f, 150f)
            2 -> b.dragTo(x, y, 50f, 56f, 270f, 150f)
        }
        flex = (flex + dx * 0.1f).coerceIn(-4f, 4f)
    }

    var flex = 0f
        private set

    override fun onUp(x: Float, y: Float) {
        if (active == 0) return
        val f = if (active == 1) a else b
        f.end()
        if (moved < 5f) {
            // un toque gira la hoja un poco (mitad izquierda -6°, derecha +6°)
            val d = if (downX < f.x) -6f else 6f
            if (active == 1) rotA += d else rotB += d
            play(SfxId.MECH_PAPER_FLEX, 0.4f)
        } else if (gapError() < 24f && !aligned) {
            say("Los bordes casi encajan, pero las palabras de la unión no coinciden.", 2.4f)
            mistake()
        }
        active = 0
    }

    override fun update(dt: Float) {
        flex *= (1f - 8f * dt).coerceAtLeast(0f)
        if (revealGlow > 0f) revealGlow = (revealGlow - dt * 1.5f).coerceAtLeast(0f)
        if (aligned) {
            if (seeingTrauma) seenTrauma += dt else seenNormal += dt
        }
        marksShown = if (!aligned) 0 else if (seeingTrauma) 3 else 2
        worldsSeen = (if (seenNormal > 1.0f) 1 else 0) + (if (seenTrauma > 1.0f) 1 else 0)
        if (!solved && aligned && seenNormal > 1.0f && seenTrauma > 1.0f && active == 0) {
            markSolved()
            say("«Mira desde donde la casa no debería tener ventanas».", 6f)
            later(0.3f, SfxId.MECH_PAPER_FLEX, 0.6f)
            later(0.8f, SfxId.MS_PENCIL, 0.6f)
            later(1.6f, SfxId.PUZZLE_SOLVED, 0.5f)
        }
    }

    val phraseReveal: Float get() = if (!solved) 0f else (solvedTime / 2.0f).coerceIn(0f, 1f)

    override fun solvedHold(): Float = 4.5f

    companion object {
        const val FRAG_W = 92f
        const val FRAG_H = 104f
        const val TOL = 4f
        const val ROT_TOL = 4f
    }
}
