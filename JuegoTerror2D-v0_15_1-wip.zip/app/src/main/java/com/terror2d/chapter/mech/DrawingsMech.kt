package com.terror2d.chapter.mech

import com.terror2d.audio.SfxId
import kotlin.math.abs

/**
 * N3 — Los cuatro dibujos. Cuatro hojas físicas sobre la mesa auxiliar. Se ARRASTRAN libremente y se giran con un
 * toque (cuartos de vuelta). No hay ranuras ni etiquetas: la solución es una composición visual.
 * Cada hoja tiene un trazo en su borde izquierdo y otro en el derecho (altura = fracción del lado). Las hojas forman
 * la secuencia cuando, EN FILA y derechas, el borde derecho de cada una continúa exactamente el trazo del izquierdo
 * de la siguiente. Los dibujos (D04) llevan las sombras: B (la taza junto a la cama, corta), A (ventana abierta,
 * media), C (llega al armario) y D (se come el cuarto): el orden de las sombras también lo confirma.
 */
class DrawingsMech : Mechanism("N3") {

    /** Índices: 0 = A, 1 = B, 2 = C, 3 = D. */
    val sheets = arrayOf(Draggable(70f, 64f, 30f), Draggable(240f, 70f, 30f), Draggable(120f, 130f, 30f), Draggable(236f, 134f, 30f))
    val rot = intArrayOf(1, 2, 0, 3)
    private var active = -1
    private var downX = 0f
    private var downY = 0f
    private var moved = 0f
    var jointGlow = FloatArray(3)
        private set
    private val seq = intArrayOf(1, 0, 2, 3) // B, A, C, D (solución)

    private fun w(i: Int) = if (rot[i] % 2 == 0) SW else SH
    private fun h(i: Int) = if (rot[i] % 2 == 0) SH else SW

    /** Orden izquierda -> derecha de las hojas colocadas en fila, o null si no hay una fila. */
    fun rowOrder(): IntArray? {
        val idx = (0 until 4).sortedBy { sheets[it].x }
        val minY = idx.minOf { sheets[it].y }
        val maxY = idx.maxOf { sheets[it].y }
        if (maxY - minY > ROW_BAND) return null
        return idx.toIntArray()
    }

    private fun jointError(a: Int, b: Int): Float {
        // fracción del lado derecho de a y del izquierdo de b, medidas en pantalla (hojas derechas)
        val ay = sheets[a].y - SH / 2f + RIGHT_FRAC[a] * SH
        val by = sheets[b].y - SH / 2f + LEFT_FRAC[b] * SH
        val gap = (sheets[b].x - SW / 2f) - (sheets[a].x + SW / 2f)
        return maxOf(abs(ay - by), abs(gap))
    }

    fun upright(): Boolean = rot.all { it == 0 }

    override fun onDown(x: Float, y: Float) {
        active = -1
        // la hoja de encima (la última tocada) manda: se recorre al revés el orden de apilado
        for (k in order.indices.reversed()) {
            val i = order[k]
            val s = sheets[i]
            if (abs(x - s.x) <= w(i) / 2f + 6f && abs(y - s.y) <= h(i) / 2f + 6f) {
                active = i
                s.begin(x, y)
                downX = x; downY = y; moved = 0f
                order.remove(i); order.add(i)
                play(SfxId.MECH_PAPER_FLEX, 0.4f)
                return
            }
        }
    }

    val order = ArrayList<Int>().apply { addAll(listOf(0, 1, 2, 3)) }

    override fun onMove(x: Float, y: Float, dx: Float, dy: Float) {
        val i = active
        if (i < 0) return
        moved += abs(dx) + abs(dy)
        sheets[i].dragTo(x, y, 30f, 34f, 290f, 156f)
        // la hoja se flexiona un poco al moverse (el dibujo lo usa)
        flex[i] = (flex[i] + sheets[i].vx * 0.12f).coerceIn(-5f, 5f)
    }

    val flex = FloatArray(4)

    override fun onUp(x: Float, y: Float) {
        val i = active
        active = -1
        if (i < 0) return
        sheets[i].end()
        if (moved < 5f) {
            // un toque sin arrastre = girar un cuarto de vuelta; la hoja no se mueve
            rot[i] = (rot[i] + 1) % 4
            play(SfxId.MECH_PAPER_FLEX, 0.5f)
        } else {
            play(SfxId.MECH_PAPER_FLEX, 0.3f)
        }
    }

    override fun update(dt: Float) {
        for (i in 0 until 4) flex[i] *= (1f - 8f * dt).coerceAtLeast(0f)
        // trazo compartido: más oscuro cuando dos bordes casi coinciden (sin bloquear nada)
        val row = rowOrder()
        for (j in 0 until 3) jointGlow[j] = 0f
        var chainOk = 0
        if (row != null && upright()) {
            for (j in 0 until 3) {
                val e = jointError(row[j], row[j + 1])
                jointGlow[j] = if (e >= 18f) 0f else 1f - e / 18f
                if (e <= TOL) chainOk++
            }
        }
        if (!solved && active < 0 && row != null && upright() && chainOk == 3) {
            if (row.contentEquals(seq)) {
                markSolved()
                play(SfxId.PUZZLE_SOLVED, 0.5f)
                later(0.6f, SfxId.MECH_PAPER_FLEX, 0.6f)
            }
        }
    }

    override fun solvedHold(): Float = 3.4f

    companion object {
        const val SW = 64f
        const val SH = 48f
        const val TOL = 5f
        const val ROW_BAND = 22f
        /** A, B, C, D */
        val LEFT_FRAC = floatArrayOf(0.80f, 0.40f, 0.20f, 0.55f)
        val RIGHT_FRAC = floatArrayOf(0.20f, 0.80f, 0.55f, 0.95f)
    }
}
