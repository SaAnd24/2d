package com.terror2d.chapter.mech

import com.terror2d.audio.SfxId

/**
 * C1 — La puerta detrás de la pared. Primer plano de la pared compartida entre la sala y la despensa.
 * Se arrastra la LÁMINA DE LATÓN por el papel pintado. Sobre una junta falsa se desliza sin resistencia; sobre una
 * junta verdadera queda atrapada un poco (se frena y suelta polvo). Para accionar un punto se mantiene la lámina
 * quieta sobre la junta y se mantiene pulsado: cede con un clic de madera detrás de la pared.
 * Orden (de izquierda a derecha): ALTA, BAJA y a MEDIA altura. Un punto fuera de turno no cede, pero no se pierde nada:
 * los puntos activados quedan registrados. El último punto libera el mecanismo y el revestimiento se desplaza hacia dentro.
 * En TRAUMA la pared muestra el contorno de siete marcas (mismas posiciones lógicas; solo cambia cómo se ve).
 */
class WallJointMech : Mechanism("C1") {

    val strip = Draggable(160f, 158f, 26f)
    /** Juntas verdaderas en orden de activación: alta, baja, media. */
    val jointX = floatArrayOf(84f, 160f, 236f)
    val jointY = floatArrayOf(56f, 128f, 92f)
    /** Juntas falsas (señuelos): la esquina y dos grietas que se pierden. */
    val fakeX = floatArrayOf(24f, 118f, 292f)
    val fakeY = floatArrayOf(150f, 92f, 40f)

    val activated = BooleanArray(3)
    val nextIndex: Int get() = activated.count { it }

    private var holdT = 0f
    private var holdJ = -1
    private var dragging = false
    private var scrapeCool = 0f
    val dust = ArrayList<FloatArray>()
    var open = 0f
        private set

    /** Junta verdadera bajo la lámina (la más cercana a menos de 16 px) o -1. */
    fun jointUnder(): Int {
        for (j in 0 until 3) if (dist(strip.x, strip.y, jointX[j], jointY[j]) <= CATCH) return j
        return -1
    }

    fun fakeUnder(): Boolean {
        for (j in fakeX.indices) if (dist(strip.x, strip.y, fakeX[j], fakeY[j]) <= CATCH) return true
        return false
    }

    /** 0..1: cuánto se acerca la lámina a la siguiente junta (la grieta "respira" un poco más a medida que te acercas). */
    fun nearness(j: Int): Float {
        val d = dist(strip.x, strip.y, jointX[j], jointY[j])
        return if (d >= 44f) 0f else 1f - d / 44f
    }

    override fun onDown(x: Float, y: Float) {
        if (strip.hit(x, y)) {
            strip.begin(x, y)
            dragging = true
            holdT = 0f
            play(SfxId.MECH_WOOD_SLIDE, 0.3f)
        }
    }

    override fun onMove(x: Float, y: Float, dx: Float, dy: Float) {
        if (!dragging) return
        var mx = dx
        var my = dy
        // junta verdadera: la lámina queda atrapada, se frena (la mano avanza y ella no)
        if (jointUnder() >= 0) { mx *= 0.25f; my *= 0.25f }
        strip.x = (strip.x + mx).coerceIn(14f, 306f)
        strip.y = (strip.y + my).coerceIn(24f, 168f)
        if (scrapeCool <= 0f) {
            scrapeCool = 0.2f
            play(if (jointUnder() >= 0) SfxId.MECH_STONE_DRAG else SfxId.MECH_WOOD_SLIDE, if (jointUnder() >= 0) 0.35f else 0.22f)
            if (jointUnder() >= 0 && dust.size < 40) dust.add(floatArrayOf(strip.x, strip.y, 1f))
        }
    }

    override fun onUp(x: Float, y: Float) {
        dragging = false
        strip.end()
        holdT = 0f
        holdJ = -1
    }

    override fun update(dt: Float) {
        if (scrapeCool > 0f) scrapeCool -= dt
        for (i in dust.indices.reversed()) {
            dust[i][2] -= dt * 0.9f
            if (dust[i][2] <= 0f) dust.removeAt(i)
        }
        // accionar: lámina quieta sobre una junta verdadera + dedo mantenido
        if (dragging && pointerDown && !solved) {
            val j = jointUnder()
            val still = kotlin.math.abs(strip.vx) + kotlin.math.abs(strip.vy) < 0.01f
            if (j >= 0 && !activated[j]) {
                if (holdJ != j) { holdJ = j; holdT = 0f }
                holdT += dt
                if (holdT >= 0.55f) {
                    holdT = 0f
                    if (j == nextIndex) {
                        activated[j] = true
                        play(SfxId.MECH_WOOD_CLICK, 0.9f)
                        later(0.15f, SfxId.MECH_STONE_DRAG, 0.3f)
                        say(STEP_TEXT[j], 2.8f)
                    } else {
                        // fuera de turno: empuja, pero no cede
                        play(SfxId.MECH_MUFFLED, 0.6f)
                        mistake("Esta junta no cede todavía. Algo la sujeta desde dentro.")
                    }
                }
            } else {
                holdT = 0f
                holdJ = -1
            }
            if (still && j < 0) { /* nada */ }
        }
        if (!solved && activated.all { it }) {
            markSolved()
            later(0.3f, SfxId.MECH_STONE_DRAG, 0.8f)
            later(1.3f, SfxId.MECH_DEEP_THUMP, 0.6f)
        }
        if (solved) open = (solvedTime / 2.4f).coerceIn(0f, 1f)
    }

    override fun solvedHold(): Float = 3.2f

    companion object {
        const val CATCH = 16f
        val STEP_TEXT = arrayOf(
            "El primer punto cede.",
            "El segundo suena detrás del papel.",
            "El tercero suelta el mecanismo."
        )
    }
}
