package com.terror2d.chapter.mech

import com.terror2d.audio.SfxId
import kotlin.math.abs

/**
 * T1 — Las siete marcas. Siete marcas raspadas en una pared de grafito. Detrás se oye un ritmo irregular.
 * Las marcas LARGAS son golpes y las CORTAS son esperas (D07: "no cuentes lo que escuchas, escucha lo que falta").
 * El jugador reproduce el ritmo golpeando las marcas directamente: un toque seco o una pulsación mantenida
 * (resonancia distinta). Cada golpe se valida contra el intervalo del patrón con una tolerancia razonable.
 * Un fallo suena como un eco amortiguado, NO reinicia el puzle: los aciertos alcanzados quedan marcados (destello de
 * grafito) y tras cada fallo se reproduce el patrón de referencia. Se resuelve con UNA repetición limpia completa.
 */
class MarksMech : Mechanism("T1") {

    val steps = 7
    val isKnock = booleanArrayOf(true, false, true, false, true, true, false)
    /** Posiciones (índice de marca) de los golpes, en orden. */
    val knocks = intArrayOf(0, 2, 4, 5)

    /** Longitud dibujada de cada marca (1 corta, 3 larga): la misma información que `def.marks`. */
    val markLen: IntArray = def.marks ?: intArrayOf(3, 1, 3, 1, 3, 3, 1)

    /** Cuántos golpes seguidos se han reproducido bien alguna vez (destello permanente de aciertos parciales). */
    var best = 0
        private set

    private var runStart = -1f
    private var runK = -1          // índice (en [knocks]) del último golpe correcto de la repetición en curso
    private var runBeginK = 0
    private var runBeginT = 0f
    private var pressedMark = -1
    private var pressT = 0f
    private var resonated = false

    /** Vibración visual 0..1 de cada marca y destello de grafito 0..1. */
    val vibe = FloatArray(7)
    val flash = FloatArray(7)
    val muffled = FloatArray(7)
    private var refPos = -1
    private var refT = 0f
    var crack = 0f
        private set

    val isPlayingRef: Boolean get() = refPos >= 0

    private fun markAt(x: Float, y: Float): Int {
        if (y < 36f || y > 150f) return -1
        var best = -1
        var bd = 1e9f
        for (i in 0 until steps) {
            val d = abs(x - markX(i))
            if (d < bd) { bd = d; best = i }
        }
        return if (bd <= 19f) best else -1
    }

    fun markX(i: Int): Float = 34f + i * 42f

    override fun onDown(x: Float, y: Float) {
        // oreja de la esquina: volver a escuchar el patrón de referencia
        if (dist(x, y, EAR_X, EAR_Y) <= 18f) { playReference(); return }
        val m = markAt(x, y)
        pressedMark = m
        pressT = time
        resonated = false
        if (m < 0 || refPos >= 0) return
        vibe[m] = 1f
        if (!isKnock[m]) {
            // una marca corta es una espera: golpearla rompe el ritmo
            play(SfxId.MECH_MUFFLED, 0.6f)
            muffled[m] = 1f
            breakRun("Eso era una espera.")
            return
        }
        play(SfxId.MECH_WOOD_CLICK, 0.55f)
        val k = knocks.indexOf(m)
        if (runK < 0) {
            // primer golpe de una repetición: puede empezar en cualquier golpe ya alcanzado
            if (k <= best) {
                runStart = time
                runK = k
                runBeginK = k
                runBeginT = time
                markHit(m, k)
            } else {
                muffled[m] = 1f
                play(SfxId.MECH_MUFFLED, 0.5f)
                say("Todavía no. Antes viene otro golpe.", 1.8f)
            }
            return
        }
        val nextK = runK + 1
        if (nextK >= knocks.size) { breakRun(null); return }
        val gapSteps = knocks[nextK] - knocks[runK]
        val expected = gapSteps * STEP
        val tol = 0.20f + 0.06f * gapSteps
        val actual = time - lastTapT
        if (k == nextK && abs(actual - expected) <= tol) {
            runK = nextK
            markHit(m, nextK)
        } else {
            muffled[m] = 1f
            play(SfxId.MECH_MUFFLED, 0.7f)
            breakRun(if (k == nextK) "Fuera de tiempo. El muro pierde el ritmo." else "Ese no era el siguiente golpe.")
        }
    }

    private var lastTapT = 0f

    private fun markHit(m: Int, k: Int) {
        lastTapT = time
        flash[m] = 1f
        if (k + 1 > best) best = k + 1
        if (runBeginK == 0 && k == knocks.size - 1) {
            // repetición limpia desde el primer golpe hasta el último
            markSolved()
            later(0.5f, SfxId.MECH_DEEP_THUMP, 0.95f)
            later(1.0f, SfxId.MECH_RESONANCE, 0.6f)
        }
    }

    private fun breakRun(text: String?) {
        runK = -1
        if (text != null) say(text, 1.8f)
        mistake()
        // tras un intento fallido se reproduce el patrón de referencia sin reiniciar nada
        if (!solved) playReference()
    }

    override fun onUp(x: Float, y: Float) {
        pressedMark = -1
    }

    fun playReference() {
        if (refPos >= 0 || solved) return
        refPos = 0
        refT = 0.35f
    }

    override fun update(dt: Float) {
        for (i in 0 until steps) {
            if (vibe[i] > 0f) vibe[i] = (vibe[i] - dt * 3f).coerceAtLeast(0f)
            if (muffled[i] > 0f) muffled[i] = (muffled[i] - dt * 1.6f).coerceAtLeast(0f)
            if (flash[i] > 0f && !solved) flash[i] = (flash[i] - dt * 0.5f).coerceAtLeast(0.0f)
        }
        // los aciertos parciales conservan un destello tenue
        for (k in 0 until best.coerceAtMost(knocks.size)) {
            if (flash[knocks[k]] < 0.25f) flash[knocks[k]] = 0.25f
        }
        // pulsación mantenida: resonancia distinta
        if (pressedMark >= 0 && pointerDown && !resonated && isKnock[pressedMark] && time - pressT > 0.4f && refPos < 0) {
            resonated = true
            vibe[pressedMark] = 1f
            play(SfxId.MECH_RESONANCE, 0.6f)
        }
        // si la repetición se queda sin seguir, se abandona (sin castigo)
        if (runK >= 0 && time - lastTapT > 2.2f) runK = -1
        // referencia
        if (refPos >= 0) {
            refT -= dt
            if (refT <= 0f) {
                if (refPos >= steps) refPos = -1
                else {
                    if (isKnock[refPos]) {
                        play(SfxId.MECH_MUFFLED, 0.9f)
                        vibe[refPos] = 1f
                    }
                    refPos++
                    refT = STEP
                }
            }
        }
        if (solved) crack = (solvedTime / 1.6f).coerceIn(0f, 1f)
    }

    override fun solvedHold(): Float = 3.2f

    companion object {
        const val STEP = 0.42f
        const val EAR_X = 296f
        const val EAR_Y = 20f
    }
}
