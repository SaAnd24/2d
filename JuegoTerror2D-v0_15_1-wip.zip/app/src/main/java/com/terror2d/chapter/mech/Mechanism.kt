package com.terror2d.chapter.mech

import com.terror2d.audio.SfxId
import com.terror2d.chapter.PuzzleBook
import com.terror2d.chapter.PuzzleDef
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.min

/** Un sonido que el mecanismo pide al director (el director lo pasa al audio; el mecanismo no conoce el audio). */
class MechSound(val sfx: SfxId, val intensity: Float)

/**
 * v0.15: un puzle con mecánica PROPIA. Sustituye al panel de cuatro ranuras + PROBAR. Lógica pura (sin Android):
 * recibe el dedo en coordenadas lógicas (320x180) y el tiempo, y expone su estado para dibujarlo y para las pruebas.
 *
 *  - No hay botón de comprobar: [solved] se activa solo cuando se cumplen las condiciones físicas del mecanismo.
 *  - Un error nunca reinicia: cada mecanismo conserva sus aciertos y solo cuenta [failures] para las pistas.
 *  - La instancia VIVE en el [com.terror2d.chapter.ChapterDirector] aunque se cierre la vista, cambie el mundo o
 *    capture la criatura, así que el estado se conserva (persistencia de la sesión, igual que los hitos).
 *  - Pistas progresivas ([assist] 0..3): 1 = relación visual ya existente más clara, 2 = el sonido / la sombra /
 *    la reacción del mecanismo se vuelve más evidente, 3 = observación breve del niño. Nunca la solución completa.
 */
abstract class Mechanism(val id: String) {

    val def: PuzzleDef = PuzzleBook.get(id) ?: throw IllegalArgumentException("puzle desconocido: $id")

    var solved: Boolean = false
        protected set
    var solvedTime: Float = 0f
        private set
    var time: Float = 0f
        private set
    var wantsClose: Boolean = false

    /** Equivocaciones razonables acumuladas (solo alimentan las pistas; nunca castigan). */
    var failures: Int = 0
        protected set

    /** Frase breve del niño (pistas, observaciones). */
    var message: String = ""
        private set
    var messageLeft: Float = 0f
        private set

    /** Mundo que se está viendo (lo escribe el director cada frame). Solo cambia la textura, nunca la lógica. */
    var trauma: Boolean = false

    /** El jugador tiene el fragmento del espejo: algunos mecanismos (C4) ofrecen ver el otro mundo. Lo escribe el director. */
    var canToggleWorld: Boolean = false

    /** Nivel de pista 0..3. */
    val assist: Int get() = min(3, failures / 3)

    var pointerDown: Boolean = false
        private set
    var px: Float = 0f
        private set
    var py: Float = 0f
        private set

    private val soundQ = ArrayList<MechSound>()
    private val delayed = ArrayList<FloatArray>()
    private val delayedSfx = ArrayList<MechSound>()

    // ------------------------------------------------------------------ entrada

    /** Un fotograma de dedo. [pressed]/[released] son los flancos del [com.terror2d.input.InputController]. */
    fun feed(down: Boolean, pressed: Boolean, released: Boolean, x: Float, y: Float) {
        if (pressed) {
            pointerDown = true
            px = x; py = y
            if (!solved && x < CLOSE_W && y < CLOSE_H) {
                wantsClose = true
                return
            }
            if (solved) {
                if (solvedTime > solvedHold()) wantsClose = true
                return
            }
            onDown(x, y)
        } else if (down && pointerDown) {
            if (abs(x - px) > 0.01f || abs(y - py) > 0.01f) {
                val ox = px; val oy = py
                px = x; py = y
                if (!solved) onMove(x, y, x - ox, y - oy)
            }
        }
        if (released && pointerDown) {
            pointerDown = false
            if (!solved) onUp(x, y)
        }
    }

    protected open fun onDown(x: Float, y: Float) {}
    protected open fun onMove(x: Float, y: Float, dx: Float, dy: Float) {}
    protected open fun onUp(x: Float, y: Float) {}

    /** Segundos tras resolver antes de que un toque cierre la vista (cada mecanismo puede alargarlo). */
    protected open fun solvedHold(): Float = 1.2f

    /** Segundos de resolución que se muestran antes de que un toque cierre la vista. */
    fun holdSeconds(): Float = solvedHold()

    // ------------------------------------------------------------------ tiempo

    fun tick(dt: Float) {
        time += dt
        if (messageLeft > 0f) messageLeft -= dt
        if (solved) solvedTime += dt
        var i = 0
        while (i < delayed.size) {
            delayed[i][0] -= dt
            if (delayed[i][0] <= 0f) {
                play(delayedSfx[i].sfx, delayedSfx[i].intensity)
                delayed.removeAt(i)
                delayedSfx.removeAt(i)
            } else i++
        }
        update(dt)
    }

    protected open fun update(dt: Float) {}

    // ------------------------------------------------------------------ audio y mensajes

    protected fun play(sfx: SfxId, intensity: Float = 0.6f) {
        if (soundQ.size < 10) soundQ.add(MechSound(sfx, intensity))
    }

    protected fun later(seconds: Float, sfx: SfxId, intensity: Float = 0.6f) {
        delayed.add(floatArrayOf(seconds))
        delayedSfx.add(MechSound(sfx, intensity))
    }

    /** El director vacía los sonidos pendientes cada frame. */
    fun drainSounds(out: (MechSound) -> Unit) {
        for (i in 0 until soundQ.size) out(soundQ[i])
        soundQ.clear()
    }

    protected fun say(text: String, seconds: Float = 3.2f) {
        message = text
        messageLeft = seconds
    }

    /**
     * Registra una equivocación razonable. Tras varias, el mecanismo se vuelve más legible ([assist]) y, al llegar
     * al nivel 3, el niño dice una observación breve (nunca la solución completa).
     */
    protected fun mistake(contextual: String? = null) {
        failures++
        if (assist >= 3 && def.hints.isNotEmpty()) {
            say(def.hints[(failures / 3 - 3).coerceAtLeast(0) % def.hints.size], 4f)
        } else if (contextual != null) say(contextual, 2.2f)
    }

    protected fun markSolved() {
        if (solved) return
        solved = true
        say(def.solvedText, 6f)
    }

    // ------------------------------------------------------------------ geometría compartida

    protected fun dist(ax: Float, ay: Float, bx: Float, by: Float): Float = hypot(ax - bx, ay - by)

    protected fun angleOf(cx: Float, cy: Float, x: Float, y: Float): Float =
        Math.toDegrees(atan2((y - cy).toDouble(), (x - cx).toDouble())).toFloat()

    /** Diferencia angular con signo en (-180, 180]. */
    protected fun angDiff(a: Float, b: Float): Float {
        var d = (a - b) % 360f
        if (d > 180f) d -= 360f
        if (d <= -180f) d += 360f
        return d
    }

    companion object {
        const val W = 320f
        const val H = 180f
        const val CLOSE_W = 34f
        const val CLOSE_H = 24f
    }
}

/** Un objeto arrastrable con radio de agarre generoso (táctil). */
class Draggable(var x: Float, var y: Float, val grab: Float) {
    var held = false
    var offX = 0f
    var offY = 0f
    var vx = 0f
    var vy = 0f

    fun hit(tx: Float, ty: Float): Boolean = hypot(tx - x, ty - y) <= grab

    fun begin(tx: Float, ty: Float) {
        held = true
        offX = x - tx
        offY = y - ty
    }

    fun dragTo(tx: Float, ty: Float, minX: Float, minY: Float, maxX: Float, maxY: Float) {
        val nx = (tx + offX).coerceIn(minX, maxX)
        val ny = (ty + offY).coerceIn(minY, maxY)
        vx = nx - x; vy = ny - y
        x = nx; y = ny
    }

    fun end() { held = false; vx = 0f; vy = 0f }
}

/** Fábrica: qué puzles ya tienen mecanismo propio. El resto cae al panel clásico hasta migrarlos (ver CAPITULO1.md). */
object MechRegistry {
    fun create(id: String): Mechanism? = when (id) {
        "N1" -> TableMech()
        "N2" -> RoutineMech()
        "N3" -> DrawingsMech()
        "N4" -> FramesMech()
        "N5" -> FuseBoxMech()
        "T1" -> MarksMech()
        "T2" -> PortraitMech()
        "T4" -> BoilerMech()
        "T5" -> AntennaMech()
        "C1" -> WallJointMech()
        "C4" -> LetterMech()
        else -> null
    }

    val MIGRATED: List<String> = listOf("N1", "N2", "N3", "N4", "N5", "T1", "T2", "T4", "T5", "C1", "C4")
}
