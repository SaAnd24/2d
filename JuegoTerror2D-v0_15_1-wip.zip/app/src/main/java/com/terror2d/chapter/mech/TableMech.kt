package com.terror2d.chapter.mech

import com.terror2d.audio.SfxId

/**
 * N1 — La mesa para dos. Vista cenital de la mesa del comedor (la misma mesa, dibujada de cerca).
 * El jugador ARRASTRA la taza azul, el plato con muesca y la silla pequeña. No hay posiciones prefabricadas:
 * las marcas viejas del tablero (anillos de polvo) y las muescas del borde dicen dónde iba cada cosa (D02):
 *  - la taza azul iba junto a la pared  -> anillo del borde de atrás;
 *  - el plato con muesca ante la silla de mamá (nunca ante la pequeña) -> anillo del lado izquierdo;
 *  - la silla pequeña arrimada a la pared, dejando sitio para el brazo de mamá.
 * Solución única: cada objeto tiene UNA marca con tolerancia propia y las manchas redondas son señuelos sin muesca.
 */
class TableMech : Mechanism("N1") {

    val cup = Draggable(150f, 104f, 16f)
    val plate = Draggable(170f, 90f, 18f)
    val chair = Draggable(276f, 118f, 18f)

    /** Anillos de polvo que SÍ cuentan (el dibujo marca además la muesca del borde en esas x). */
    val cupMark = floatArrayOf(CUP_X, CUP_Y)
    val plateMark = floatArrayOf(PLATE_X, PLATE_Y)
    val chairMark = floatArrayOf(CHAIR_X, CHAIR_Y)

    /** Señuelos: manchas circulares que no tienen muesca en el borde. */
    val decoys: Array<FloatArray> = arrayOf(floatArrayOf(150f, 100f, 9f), floatArrayOf(232f, 120f, 8f), floatArrayOf(118f, 78f, 7f))

    private var active: Draggable? = null
    private var misses = 0
    private var clinkCool = 0f
    private var slideCool = 0f

    /** 0..1: cuánto se acerca cada objeto a su marca (para el polvo). */
    fun closeness(o: Draggable): Float {
        val (mx, my, r) = target(o)
        val d = dist(o.x, o.y, mx, my)
        val reach = r * (if (assist >= 2) 4.2f else 3.0f)
        return if (d >= reach) 0f else 1f - d / reach
    }

    private data class T(val x: Float, val y: Float, val r: Float)

    private fun target(o: Draggable): T = when {
        o === cup -> T(CUP_X, CUP_Y, CUP_TOL)
        o === plate -> T(PLATE_X, PLATE_Y, PLATE_TOL)
        else -> T(CHAIR_X, CHAIR_Y, CHAIR_TOL)
    }

    private fun inPlace(o: Draggable): Boolean {
        val t = target(o)
        return dist(o.x, o.y, t.x, t.y) <= t.r
    }

    val cupOk: Boolean get() = inPlace(cup)
    val plateOk: Boolean get() = inPlace(plate)
    val chairOk: Boolean get() = inPlace(chair)

    /** Sombra de un objeto: más larga y desplazada cuanto más alto (taza), siempre hacia el lado contrario de la luz. */
    fun shadowDx(): Float = 3.5f

    override fun onDown(x: Float, y: Float) {
        // la taza queda encima del plato si se solapan: se prueba primero lo más pequeño
        val pick = when {
            cup.hit(x, y) -> cup
            plate.hit(x, y) -> plate
            chair.hit(x, y) -> chair
            else -> null
        }
        if (pick != null) {
            pick.begin(x, y)
            active = pick
            play(if (pick === chair) SfxId.MECH_WOOD_SLIDE else SfxId.MECH_CERAMIC, 0.35f)
        }
    }

    override fun onMove(x: Float, y: Float, dx: Float, dy: Float) {
        val o = active ?: return
        if (o === chair) {
            o.dragTo(x, y, 20f, 18f, 300f, 168f)
            // la silla no entra en el tablero: se queda en el borde (se puede comprobar el espacio libre)
            if (o.x > TABLE_L - 8f && o.x < TABLE_R + 8f && o.y > TABLE_T + 2f && o.y < TABLE_B + 8f) {
                val toTop = o.y - (TABLE_T + 2f)
                val toBottom = (TABLE_B + 8f) - o.y
                val toLeft = o.x - (TABLE_L - 8f)
                val toRight = (TABLE_R + 8f) - o.x
                val m = minOf(minOf(toTop, toBottom), minOf(toLeft, toRight))
                when (m) {
                    toTop -> o.y = TABLE_T + 2f
                    toBottom -> o.y = TABLE_B + 8f
                    toLeft -> o.x = TABLE_L - 8f
                    else -> o.x = TABLE_R + 8f
                }
            }
        } else {
            o.dragTo(x, y, TABLE_L + 8f, TABLE_T + 8f, TABLE_R - 8f, TABLE_B - 8f)
        }
        if (slideCool <= 0f && (dx * dx + dy * dy) > 2f) {
            slideCool = 0.16f
            play(SfxId.MECH_WOOD_SLIDE, if (o === chair) 0.45f else 0.25f)
        }
    }

    override fun onUp(x: Float, y: Float) {
        val o = active ?: return
        o.end()
        active = null
        val t = target(o)
        val d = dist(o.x, o.y, t.x, t.y)
        if (d <= t.r) {
            play(if (o === chair) SfxId.MECH_WOOD_CLICK else SfxId.MECH_CERAMIC, 0.5f)
        } else {
            // simplemente se aprecia que las marcas no coinciden: el objeto NO vuelve a su sitio
            misses++
            if (d < t.r * 3.2f) say("Casi. El anillo de polvo no queda del todo cubierto.", 2.2f)
            if (misses % 4 == 0) mistake()
        }
    }

    override fun update(dt: Float) {
        if (clinkCool > 0f) clinkCool -= dt
        if (slideCool > 0f) slideCool -= dt
        // la taza y el plato no se atraviesan: chocan y se separan un poco
        val d = dist(cup.x, cup.y, plate.x, plate.y)
        val min = 22f
        if (d < min && d > 0.01f) {
            val mover = if (cup.held) plate else cup
            val nx = (mover.x - (if (mover === cup) plate.x else cup.x)) / d
            val ny = (mover.y - (if (mover === cup) plate.y else cup.y)) / d
            if (!(plate.held && cup.held)) {
                mover.x = (mover.x + nx * (min - d) * 0.6f).coerceIn(TABLE_L + 8f, TABLE_R - 8f)
                mover.y = (mover.y + ny * (min - d) * 0.6f).coerceIn(TABLE_T + 8f, TABLE_B - 8f)
            }
            if (clinkCool <= 0f) {
                clinkCool = 0.35f
                play(SfxId.MECH_CERAMIC, 0.5f)
            }
        }
        if (!solved && active == null && cupOk && plateOk && chairOk) {
            markSolved()
            // clic de madera, el borde de la mesa coincide y se abre la hendidura
            later(0.5f, SfxId.MECH_WOOD_CLICK, 0.8f)
            later(1.1f, SfxId.MECH_WOOD_SLIDE, 0.7f)
            later(1.7f, SfxId.PUZZLE_SOLVED, 0.6f)
        }
    }

    /** 0..1 de apertura del compartimento (el dibujo lo usa; la cámara se detiene en la hendidura). */
    val drawerOpen: Float get() = if (!solved) 0f else ((solvedTime - 1.0f) / 1.2f).coerceIn(0f, 1f)

    override fun solvedHold(): Float = 3.2f

    companion object {
        const val TABLE_L = 70f
        const val TABLE_R = 250f
        const val TABLE_T = 66f
        const val TABLE_B = 142f

        const val CUP_X = 204f
        const val CUP_Y = 80f
        const val CUP_TOL = 10f
        const val PLATE_X = 104f
        const val PLATE_Y = 116f
        const val PLATE_TOL = 12f
        const val CHAIR_X = 150f
        const val CHAIR_Y = 52f
        const val CHAIR_TOL = 15f
    }
}
