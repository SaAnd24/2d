package com.terror2d.chapter.mech

import com.terror2d.audio.SfxId
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * N4 — Los retratos torcidos. Cuatro marcos colgados del papel pintado. Se arrastra un marco en horizontal para
 * inclinarlo (o se usan los pequeños botones ◀ ▶ bajo cada uno). La cuerda se tensa, el marco oscila y su SOMBRA
 * cae sobre el papel pintado: la posición correcta no es solo la inclinación sino dónde cae la sombra.
 * Detrás de cada marco hay una marca de lápiz (la sombra que debe coincidir). Los ángulos objetivo siguen el patrón
 * que dejó N3 en los bordes de las hojas, de izquierda a derecha: inclinado a la izquierda, recto, muy inclinado a
 * la izquierda, inclinado a la derecha. Un marco asentado queda fijo; los otros tres siguen pidiendo manipulación.
 */
class FramesMech : Mechanism("N4") {

    val count = 4
    val centerX = floatArrayOf(58f, 126f, 194f, 262f)
    val centerY = 78f

    /** Ángulo actual (grados; negativo = inclinado a la izquierda) y velocidad de oscilación. */
    val angle = floatArrayOf(14f, -11f, 9f, -17f)
    val swingVel = FloatArray(4)
    val settled = BooleanArray(4)
    private val dwell = FloatArray(4)
    private var active = -1
    private var tickAcc = 0f

    /** Longitud de la cuerda (solo dibujo; D05: la marca indica dónde termina la cuerda). */
    val ropeLen = floatArrayOf(22f, 17f, 26f, 20f)

    /** Dónde cae el extremo de la sombra respecto al centro del marco para un ángulo dado. */
    fun shadowTipX(i: Int, a: Float): Float = centerX[i] + 15f + sin(Math.toRadians(a.toDouble())).toFloat() * 36f
    fun shadowTipY(i: Int, a: Float): Float = centerY + 28f + cos(Math.toRadians(a.toDouble())).toFloat() * 8f
    fun markTipX(i: Int): Float = shadowTipX(i, TARGET[i])
    fun markTipY(i: Int): Float = shadowTipY(i, TARGET[i])

    /** 0..1 de cuánto coincide la sombra con la marca (feedback de aproximación). */
    fun match(i: Int): Float {
        val d = abs(angle[i] - TARGET[i])
        return if (d >= 10f) 0f else 1f - d / 10f
    }

    val allSettled: Boolean get() = settled.all { it }
    val revealed: Float get() = if (!solved) 0f else ((solvedTime - 0.4f) / 1.6f).coerceIn(0f, 1f)

    private fun frameAt(x: Float, y: Float): Int {
        for (i in 0 until count) {
            if (abs(x - centerX[i]) <= 28f && y >= centerY - 36f && y <= centerY + 40f) return i
        }
        return -1
    }

    private fun arrowAt(x: Float, y: Float): Int {
        // devuelve 2*i (izquierda) o 2*i+1 (derecha); -1 = ninguno
        for (i in 0 until count) {
            if (y in (ARROW_Y - 12f)..(ARROW_Y + 12f)) {
                if (abs(x - (centerX[i] - 17f)) <= 12f) return 2 * i
                if (abs(x - (centerX[i] + 17f)) <= 12f) return 2 * i + 1
            }
        }
        return -1
    }

    override fun onDown(x: Float, y: Float) {
        val ar = arrowAt(x, y)
        if (ar >= 0) {
            val i = ar / 2
            if (!settled[i]) nudge(i, if (ar % 2 == 0) -2f else 2f)
            active = -1
            return
        }
        val i = frameAt(x, y)
        active = if (i >= 0 && !settled[i]) i else -1
        if (i >= 0 && settled[i]) say("Ese marco ya está bien asentado en su gancho.", 1.8f)
    }

    override fun onMove(x: Float, y: Float, dx: Float, dy: Float) {
        val i = active
        if (i < 0) return
        nudge(i, dx * 0.32f)
    }

    private fun nudge(i: Int, d: Float) {
        val before = angle[i]
        angle[i] = (angle[i] + d).coerceIn(-32f, 32f)
        swingVel[i] += d * 0.9f
        tickAcc += abs(angle[i] - before)
        if (tickAcc > 4f) {
            tickAcc = 0f
            play(SfxId.MECH_WOOD_SLIDE, 0.22f) // roce de la cuerda al tensarse
        }
    }

    override fun onUp(x: Float, y: Float) {
        active = -1
    }

    override fun update(dt: Float) {
        for (i in 0 until count) {
            if (settled[i]) { swingVel[i] = 0f; continue }
            // oscilación amortiguada alrededor del ángulo fijado por el jugador
            swingVel[i] *= (1f - 3.2f * dt).coerceAtLeast(0f)
            val within = abs(angle[i] - TARGET[i]) <= TOL
            if (within && active != i) {
                dwell[i] += dt
                if (dwell[i] > 0.55f) {
                    settled[i] = true
                    angle[i] = TARGET[i]
                    play(SfxId.MECH_HOOK, 0.7f)
                    say("Clic. El gancho se asienta.", 1.6f)
                }
            } else {
                if (dwell[i] > 0.2f && !within) {
                    // casi estuvo: el marco se pasó un poco (error sin castigo)
                    mistake()
                }
                dwell[i] = 0f
            }
        }
        if (!solved && allSettled) {
            markSolved()
            later(0.4f, SfxId.MECH_WOOD_CLICK, 0.8f)
            later(0.9f, SfxId.MECH_STONE_DRAG, 0.7f)
            later(2.1f, SfxId.PUZZLE_SOLVED, 0.6f)
        }
    }

    override fun solvedHold(): Float = 3.0f

    companion object {
        /** Ángulos exactos: A la izquierda, Recto, Muy a la izquierda, A la derecha (patrón de N3). */
        val TARGET = floatArrayOf(-8f, 0f, -18f, 8f)
        const val TOL = 2.8f
        const val ARROW_Y = 138f
    }
}
