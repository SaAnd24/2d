package com.terror2d.chapter.mech

import com.terror2d.audio.SfxId
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * T5 — La antena de la azotea. Tres brazos ARTICULADOS en cadena (corto, medio, largo): girar el primero arrastra
 * a los otros dos. Se gira cada brazo directamente con el dedo (arrastrando alrededor de su articulación) o con los
 * botones ◀ ▶. La SOMBRA de cada brazo se proyecta sobre la azotea en tiempo real. En el horizonte hay tres figuras:
 * una ventana iluminada, una torre oscura y una línea quebrada. D11: el brazo se orienta por la FORMA que comparte con
 * el dibujo, no por la distancia: la cabeza cuadrada del brazo corto es la ventana, el codo en zigzag del medio es la
 * línea quebrada y la barra alta del largo es la torre. El jugador debe llevar la punta de cada sombra a su silueta.
 */
class AntennaMech : Mechanism("T5") {

    /** Longitud de cada brazo en el plano de sombras. */
    val len = floatArrayOf(34f, 44f, 56f)
    /** Ángulo ABSOLUTO (grados, 0 = derecha, -90 = arriba) de cada brazo. Empieza lejos de la solución. */
    val theta = floatArrayOf(-20f, 20f, -30f)
    private var active = -1
    private var tickAcc = 0f
    private val dwell = FloatArray(3)
    val aligned = BooleanArray(3)
    private var allHold = 0f

    fun baseX() = BASE_X
    fun baseY() = BASE_Y

    /** Punta de la sombra del brazo [i] (cadena desde la base). */
    fun tipX(i: Int): Float {
        var x = BASE_X
        for (k in 0..i) x += len[k] * cos(Math.toRadians(theta[k].toDouble())).toFloat()
        return x
    }

    fun tipY(i: Int): Float {
        var y = BASE_Y
        for (k in 0..i) y += len[k] * sin(Math.toRadians(theta[k].toDouble())).toFloat()
        return y
    }

    fun pivotX(i: Int): Float = if (i == 0) BASE_X else tipX(i - 1)
    fun pivotY(i: Int): Float = if (i == 0) BASE_Y else tipY(i - 1)

    /** Siluetas objetivo: ventana (brazo 0), línea quebrada (brazo 1), torre (brazo 2). Calculadas de la cadena resuelta. */
    fun targetX(i: Int): Float {
        var x = BASE_X
        for (k in 0..i) x += len[k] * cos(Math.toRadians(SOLUTION[k].toDouble())).toFloat()
        return x
    }

    fun targetY(i: Int): Float {
        var y = BASE_Y
        for (k in 0..i) y += len[k] * sin(Math.toRadians(SOLUTION[k].toDouble())).toFloat()
        return y
    }

    /** 0..1 de cuánto se acerca la punta a su silueta (la línea de la sombra se vuelve más nítida). */
    fun nearness(i: Int): Float {
        val d = dist(tipX(i), tipY(i), targetX(i), targetY(i))
        return if (d >= 34f) 0f else 1f - d / 34f
    }

    private fun armAt(x: Float, y: Float): Int {
        // el brazo cuyo tramo queda más cerca del dedo (con preferencia por los de la punta)
        var best = -1
        var bd = 16f
        for (i in 2 downTo 0) {
            val d = segDist(x, y, pivotX(i), pivotY(i), tipX(i), tipY(i))
            if (d < bd) { bd = d; best = i }
        }
        return best
    }

    private fun segDist(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
        val abx = bx - ax; val aby = by - ay
        val l2 = abx * abx + aby * aby
        var t = if (l2 <= 0.0001f) 0f else ((px - ax) * abx + (py - ay) * aby) / l2
        t = t.coerceIn(0f, 1f)
        return dist(px, py, ax + abx * t, ay + aby * t)
    }

    override fun onDown(x: Float, y: Float) {
        active = -1
        // botones ◀ ▶ de cada brazo
        for (i in 0 until 3) {
            if (dist(x, y, BTN_X[i] - 14f, BTN_Y) <= 13f) { turn(i, -3f); return }
            if (dist(x, y, BTN_X[i] + 14f, BTN_Y) <= 13f) { turn(i, 3f); return }
        }
        active = armAt(x, y)
    }

    override fun onMove(x: Float, y: Float, dx: Float, dy: Float) {
        val i = active
        if (i < 0) return
        val a = angleOf(pivotX(i), pivotY(i), x, y)
        // resistencia: el brazo sigue al dedo con retraso, como una articulación dura
        val d = angDiff(a, theta[i]) * 0.38f
        turn(i, d.coerceIn(-9f, 9f))
    }

    override fun onUp(x: Float, y: Float) { active = -1 }

    private fun turn(i: Int, d: Float) {
        theta[i] = ((theta[i] + d + 180f) % 360f + 360f) % 360f - 180f
        tickAcc += abs(d)
        if (tickAcc > 6f) {
            tickAcc = 0f
            play(SfxId.MECH_METAL_CLINK, 0.3f) // roce metálico de la articulación
        }
    }

    override fun update(dt: Float) {
        var all = true
        for (i in 0 until 3) {
            val d = dist(tipX(i), tipY(i), targetX(i), targetY(i))
            val ok = d <= TOL
            if (ok) {
                dwell[i] += dt
                if (!aligned[i] && dwell[i] > 0.35f) {
                    aligned[i] = true
                    play(SfxId.MECH_HOOK, 0.6f) // clic de la articulación
                }
            } else {
                if (aligned[i]) say("Al mover un brazo, las sombras de los demás se desplazan.", 2.4f)
                if (dwell[i] > 0.3f) mistake()
                aligned[i] = false
                dwell[i] = 0f
                all = false
            }
            if (!aligned[i]) all = false
        }
        if (all && active < 0 && !solved) {
            allHold += dt
            if (allHold > 0.9f) {
                markSolved()
                later(0.2f, SfxId.MECH_HOOK, 0.8f)
                later(1.0f, SfxId.MECH_RESONANCE, 0.5f)
                later(2.0f, SfxId.PUZZLE_SOLVED, 0.45f)
            }
        } else if (!all) allHold = 0f
    }

    /** 0..1 de cuánto se alarga la sombra final que apunta a la ventana imposible. */
    val longShadow: Float get() = if (!solved) 0f else (solvedTime / 2.4f).coerceIn(0f, 1f)

    override fun solvedHold(): Float = 4.0f

    companion object {
        const val BASE_X = 160f
        const val BASE_Y = 150f
        const val TOL = 8f
        val SOLUTION = floatArrayOf(-62f, -20f, -110f)
        val BTN_X = floatArrayOf(40f, 108f, 232f)
        const val BTN_Y = 166f
    }
}
