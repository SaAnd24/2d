package com.terror2d.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.terror2d.chapter.mech.AntennaMech
import com.terror2d.chapter.mech.BoilerMech
import com.terror2d.chapter.mech.DrawingsMech
import com.terror2d.chapter.mech.FramesMech
import com.terror2d.chapter.mech.FuseBoxMech
import com.terror2d.chapter.mech.LetterMech
import com.terror2d.chapter.mech.MarksMech
import com.terror2d.chapter.mech.Mechanism
import com.terror2d.chapter.mech.PortraitMech
import com.terror2d.chapter.mech.RoutineMech
import com.terror2d.chapter.mech.TableMech
import com.terror2d.chapter.mech.WallJointMech
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * v0.15 — Vistas de los mecanismos de los puzles (cada uno con su propio dibujo, objetos y feedback). Coordenadas
 * lógicas 320x180. Todo procedural: sin Paint ni Path nuevos por fotograma. NORMAL se dibuja en crayón cálido; TRAUMA
 * en grafito gris: la lógica es la misma, solo cambia la paleta (los seis estados de deterioro no tocan nada de esto).
 */
class MechRenderer {

    private val fill = Paint().apply { style = Paint.Style.FILL; isAntiAlias = true }
    private val line = Paint().apply { style = Paint.Style.STROKE; isAntiAlias = true; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val text = Paint().apply {
        isAntiAlias = true
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.LEFT
    }
    private val rf = RectF()
    private val path = Path()

    // paleta del mundo activo
    private var tr = false
    private var wall = 0
    private var wood = 0
    private var woodDark = 0
    private var ink = 0
    private var paper = 0
    private var accent = 0

    private fun palette(trauma: Boolean) {
        tr = trauma
        wall = if (trauma) 0xFFB9B9B5.toInt() else 0xFFE8D8B6.toInt()
        wood = if (trauma) 0xFF8D8D89.toInt() else 0xFFB98A5A.toInt()
        woodDark = if (trauma) 0xFF5E5E5B.toInt() else 0xFF7A5230.toInt()
        ink = if (trauma) 0xFF1E1E1E.toInt() else 0xFF3A2A20.toInt()
        paper = if (trauma) 0xFFD4D4D0.toInt() else 0xFFFFF6DC.toInt()
        accent = if (trauma) 0xFFEDEDED.toInt() else 0xFFFFE9A0.toInt()
    }

    fun draw(canvas: Canvas, m: Mechanism, time: Float) {
        val trauma = if (m is LetterMech) m.seeingTrauma else m.trauma
        palette(trauma)
        canvas.save()
        when (m) {
            is TableMech -> drawTable(canvas, m, time)
            is RoutineMech -> drawRoutine(canvas, m, time)
            is DrawingsMech -> drawDrawings(canvas, m, time)
            is FramesMech -> drawFrames(canvas, m, time)
            is FuseBoxMech -> drawFuse(canvas, m, time)
            is MarksMech -> drawMarks(canvas, m, time)
            is PortraitMech -> drawPortrait(canvas, m, time)
            is BoilerMech -> drawBoiler(canvas, m, time)
            is AntennaMech -> drawAntenna(canvas, m, time)
            is WallJointMech -> drawWall(canvas, m, time)
            is LetterMech -> drawLetter(canvas, m, time)
        }
        canvas.restore()
        chrome(canvas, m)
    }

    // ------------------------------------------------------------------ utilidades

    private fun rect(c: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int) {
        fill.color = color
        c.drawRect(l, t, r, b, fill)
    }

    private fun frame(c: Canvas, l: Float, t: Float, r: Float, b: Float, w: Float = 1.2f, color: Int = ink) {
        line.strokeWidth = w
        line.color = color
        c.drawRect(l, t, r, b, line)
    }

    private fun ln(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, color: Int) {
        line.strokeWidth = w
        line.color = color
        c.drawLine(x1, y1, x2, y2, line)
    }

    private fun circ(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        fill.color = color
        c.drawCircle(x, y, r, fill)
    }

    private fun ring(c: Canvas, x: Float, y: Float, r: Float, w: Float, color: Int) {
        line.strokeWidth = w
        line.color = color
        c.drawCircle(x, y, r, line)
    }

    private fun alpha(color: Int, a: Float): Int {
        val na = ((color ushr 24) * a.coerceIn(0f, 1f)).toInt()
        return (na shl 24) or (color and 0xFFFFFF)
    }

    private fun label(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, center: Boolean = true) {
        text.textSize = size
        text.color = color
        text.textAlign = if (center) Paint.Align.CENTER else Paint.Align.LEFT
        c.drawText(s, x, y, text)
    }

    private fun hatchBg(c: Canvas, base: Int) {
        rect(c, 0f, 0f, 320f, 180f, base)
        var y = 6f
        while (y < 180f) {
            ln(c, 0f, y, 320f, y + 1.5f, 0.5f, alpha(ink, 0.06f))
            y += 9f
        }
    }

    private fun arrowBtn(c: Canvas, x: Float, y: Float, dir: Int, color: Int = ink) {
        circ(c, x, y, 9f, alpha(paper, 0.9f))
        ring(c, x, y, 9f, 1f, alpha(color, 0.8f))
        path.reset()
        path.moveTo(x + dir * 3f, y - 4f)
        path.lineTo(x - dir * 3f, y)
        path.lineTo(x + dir * 3f, y + 4f)
        path.close()
        fill.color = alpha(color, 0.85f)
        c.drawPath(path, fill)
    }

    private fun wrapLines(s: String, maxChars: Int): List<String> {
        val out = ArrayList<String>()
        var cur = StringBuilder()
        for (w in s.split(" ")) {
            if (w.isEmpty()) continue
            if (cur.isNotEmpty() && cur.length + 1 + w.length > maxChars) { out.add(cur.toString()); cur = StringBuilder() }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(w)
        }
        if (cur.isNotEmpty()) out.add(cur.toString())
        return out
    }

    /** Cierre, mensaje contextual del niño y aviso de salida. Común a todos pero discreto. */
    private fun chrome(c: Canvas, m: Mechanism) {
        // botón de cerrar (arriba a la izquierda): una pequeña X de lápiz
        circ(c, 14f, 13f, 8f, alpha(paper, 0.85f))
        ln(c, 10.5f, 9.5f, 17.5f, 16.5f, 1.4f, ink)
        ln(c, 17.5f, 9.5f, 10.5f, 16.5f, 1.4f, ink)
        if (m.messageLeft > 0f && m.message.isNotEmpty()) {
            val lines = wrapLines(m.message, 52)
            val h = lines.size * 7.4f + 6f
            fill.color = alpha(0xFF000000.toInt(), 0.62f * (m.messageLeft / 0.6f).coerceIn(0f, 1f))
            rf.set(26f, 4f, 294f, 4f + h)
            c.drawRoundRect(rf, 3f, 3f, fill)
            for (k in lines.indices) label(c, lines[k], 160f, 12.5f + k * 7.4f, 5.6f, 0xFFFFF6DC.toInt())
        }
        if (m.solved && m.solvedTime > m.holdSeconds()) {
            label(c, "toca para seguir", 160f, 176f, 5f, alpha(ink, 0.7f))
        }
    }

    // ------------------------------------------------------------------ N1 — la mesa para dos

    private fun drawTable(c: Canvas, m: TableMech, time: Float) {
        hatchBg(c, wall)
        rect(c, 0f, 150f, 320f, 180f, alpha(woodDark, 0.5f)) // suelo
        // la luz entra por la ventana de la izquierda: las sombras caen hacia la derecha y abajo
        rect(c, TableMech.TABLE_L - 3f, TableMech.TABLE_T - 3f, TableMech.TABLE_R + 3f, TableMech.TABLE_B + 8f, alpha(0xFF000000.toInt(), 0.18f))
        rect(c, TableMech.TABLE_L, TableMech.TABLE_T, TableMech.TABLE_R, TableMech.TABLE_B, wood)
        var x = TableMech.TABLE_L + 22f
        while (x < TableMech.TABLE_R) { ln(c, x, TableMech.TABLE_T, x, TableMech.TABLE_B, 0.6f, alpha(woodDark, 0.5f)); x += 22f }
        rect(c, TableMech.TABLE_L, TableMech.TABLE_B, TableMech.TABLE_R, TableMech.TABLE_B + 8f, woodDark)
        frame(c, TableMech.TABLE_L, TableMech.TABLE_T, TableMech.TABLE_R, TableMech.TABLE_B, 1.3f)

        // muescas del borde: el borde coincide con la taza y con el plato cuando todo está bien
        val glow = if (m.solved) 1f else 0.55f + 0.1f * m.assist
        ln(c, TableMech.CUP_X, TableMech.TABLE_T - 2f, TableMech.CUP_X, TableMech.TABLE_T + 4f, 1.6f, alpha(ink, glow))
        ln(c, TableMech.PLATE_X, TableMech.TABLE_B + 2f, TableMech.PLATE_X, TableMech.TABLE_B + 8f, 1.6f, alpha(ink, glow))

        // manchas señuelo (rellenas, sin muesca) y anillos de polvo verdaderos
        for (d in m.decoys) circ(c, d[0], d[1], d[2], alpha(woodDark, 0.35f))
        val ringA = 0.35f + 0.18f * m.assist
        dashedRing(c, TableMech.CUP_X, TableMech.CUP_Y, 8.5f, alpha(ink, ringA))
        dashedRing(c, TableMech.PLATE_X, TableMech.PLATE_Y, 12.5f, alpha(ink, ringA))
        // marcas de la silla pequeña contra la pared: cuatro rozaduras
        val cx = TableMech.CHAIR_X; val cy = TableMech.CHAIR_Y
        for (dx in intArrayOf(-9, 9)) for (dy in intArrayOf(-6, 6)) circ(c, cx + dx, cy + dy, 1.4f, alpha(ink, ringA))

        // silla de mamá (izquierda, con el brazo libre) y silla del niño (derecha): fijas
        chairTop(c, 52f, 118f, 22f, 26f, true, 0f, false)
        chairTop(c, 268f, 100f, 20f, 24f, false, 0f, false)

        // polvo fino bajo el objeto que se acerca a su marca
        for (o in arrayOf(m.cup, m.plate, m.chair)) {
            val k = m.closeness(o)
            if (k > 0f) {
                val tx = if (o === m.cup) TableMech.CUP_X else if (o === m.plate) TableMech.PLATE_X else TableMech.CHAIR_X
                val ty = if (o === m.cup) TableMech.CUP_Y else if (o === m.plate) TableMech.PLATE_Y else TableMech.CHAIR_Y
                for (i in 0 until 7) {
                    val a = i * 0.9f + time * 0.6f
                    circ(c, tx + cos(a) * (6f + i), ty + sin(a) * (5f + i * 0.6f), 0.9f, alpha(0xFFFFFFFF.toInt(), 0.5f * k))
                }
            }
        }

        // la silla pequeña (arrastrable)
        chairTop(c, m.chair.x, m.chair.y, 24f, 17f, false, 3.5f, true)
        // plato con muesca
        circ(c, m.plate.x + 3f, m.plate.y + 3.5f, 11f, alpha(0xFF000000.toInt(), 0.22f))
        circ(c, m.plate.x, m.plate.y, 11f, if (tr) 0xFFE8E8E4.toInt() else 0xFFFFFDF2.toInt())
        ring(c, m.plate.x, m.plate.y, 11f, 1f, ink)
        ring(c, m.plate.x, m.plate.y, 7.5f, 0.6f, alpha(ink, 0.5f))
        circ(c, m.plate.x - 8f, m.plate.y - 7.5f, 2.6f, if (tr) 0xFF8D8D89.toInt() else wood) // la muesca
        // taza azul
        circ(c, m.cup.x + 3f, m.cup.y + 3.5f, 7f, alpha(0xFF000000.toInt(), 0.25f))
        circ(c, m.cup.x, m.cup.y, 7f, if (tr) 0xFF9A9A9A.toInt() else 0xFF4F7FC8.toInt())
        ring(c, m.cup.x, m.cup.y, 7f, 1f, ink)
        circ(c, m.cup.x, m.cup.y, 4.4f, if (tr) 0xFF5A5A5A.toInt() else 0xFF2D4F8A.toInt())
        ring(c, m.cup.x + 8.5f, m.cup.y, 2.6f, 1.2f, ink)

        // hendidura bajo el borde que se abre al resolver (la cámara se queda en ella)
        if (m.solved) {
            val o = m.drawerOpen
            rect(c, 112f, TableMech.TABLE_B + 8f, 196f, TableMech.TABLE_B + 8f + 12f * o, 0xFF2A1A10.toInt())
            if (o > 0.6f) {
                rf.set(130f, TableMech.TABLE_B + 12f, 178f, TableMech.TABLE_B + 18f)
                fill.color = if (tr) 0xFFC8C8C0.toInt() else 0xFFD9B34A.toInt()
                c.drawRoundRect(rf, 1.5f, 1.5f, fill)
                ln(c, 134f, TableMech.TABLE_B + 13f, 172f, TableMech.TABLE_B + 13f, 0.8f, 0xFFFFFFFF.toInt())
            }
            frame(c, 112f, TableMech.TABLE_B + 8f, 196f, TableMech.TABLE_B + 8f + 12f * o, 1f)
        }
    }

    private fun dashedRing(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        line.strokeWidth = 1.1f
        line.color = color
        for (i in 0 until 12) {
            val a0 = i * 0.5236f
            c.drawLine(x + cos(a0) * r, y + sin(a0) * r, x + cos(a0 + 0.30f) * r, y + sin(a0 + 0.30f) * r, line)
        }
    }

    private fun chairTop(c: Canvas, x: Float, y: Float, w: Float, h: Float, mom: Boolean, shadow: Float, grab: Boolean) {
        if (shadow > 0f) rect(c, x - w / 2f + shadow, y - h / 2f + shadow, x + w / 2f + shadow, y + h / 2f + shadow, alpha(0xFF000000.toInt(), 0.22f))
        rect(c, x - w / 2f, y - h / 2f, x + w / 2f, y + h / 2f, if (grab) wood else alpha(woodDark, 0.85f))
        frame(c, x - w / 2f, y - h / 2f, x + w / 2f, y + h / 2f, 1f)
        rect(c, x - w / 2f, y - h / 2f, x + w / 2f, y - h / 2f + 3f, woodDark)
        if (mom) { /* respaldo ancho: es la silla de mamá */ ln(c, x - w / 2f - 2f, y - h / 2f, x - w / 2f - 2f, y + h / 2f, 2f, woodDark) }
    }

    // ------------------------------------------------------------------ N2 — el horario

    private fun drawRoutine(c: Canvas, m: RoutineMech, time: Float) {
        hatchBg(c, if (tr) 0xFFB2B2AE.toInt() else 0xFFE4D2B0.toInt())
        rect(c, 0f, 150f, 320f, 180f, alpha(woodDark, 0.45f))
        // pasillo (puerta oscura a la izquierda): se queda a oscuras en la tercera fase
        rect(c, 4f, 40f, 24f, 120f, if (m.done[2]) 0xFF0A0A0C.toInt() else alpha(0xFFFFE9A0.toInt(), 0.5f))
        frame(c, 4f, 40f, 24f, 120f, 1f)
        // ventana
        val sky = if (tr) 0xFFD8D8D6.toInt() else 0xFFBFE0F0.toInt()
        rect(c, 196f, 22f, 276f, 96f, sky)
        frame(c, 196f, 22f, 276f, 96f, 1.6f)
        // lamas: seis tiras, más abiertas o más cerradas según la inclinación
        val slatShift = m.tilt * 5f
        for (i in 0 until 6) {
            val y = 26f + i * 11.5f
            ln(c, 198f, y + slatShift, 274f, y - slatShift, 2.2f, alpha(woodDark, 0.9f))
        }
        // cortina (panel que se desliza hacia la derecha al abrirse)
        val cw = 80f * (1f - m.curtain)
        if (cw > 1f) {
            rect(c, 196f, 20f, 196f + cw, 98f, if (tr) 0xFF8A8A88.toInt() else 0xFFC96B6B.toInt())
            var fx = 198f
            while (fx < 196f + cw) { ln(c, fx, 20f, fx + 1f + sin(time * 1.3f + fx) * 0.8f, 98f, 0.7f, alpha(ink, 0.25f)); fx += 6f }
        }
        // cordón de la cortina y varilla de las lamas
        ln(c, 196f + 80f * m.curtain, 96f, 196f + 80f * m.curtain, 112f, 1f, ink)
        circ(c, 196f + 80f * m.curtain, 114f, 3.5f, ink)
        ln(c, 284f, 24f, 284f, 100f, 1.2f, alpha(ink, 0.7f))
        circ(c, 284f, 63f - m.tilt * 37f, 4f, woodDark)
        // mesita con taza (marca B)
        rect(c, 214f, 118f, 268f, 126f, wood)
        rect(c, 218f, 126f, 222f, 146f, woodDark); rect(c, 260f, 126f, 264f, 146f, woodDark)
        val cold = m.done[1]
        circ(c, 240f, 112f, 6.5f, if (tr) 0xFF9A9A9A.toInt() else 0xFF4F7FC8.toInt())
        ring(c, 240f, 112f, 6.5f, 1f, ink)
        if (!cold) for (i in 0 until 3) ln(c, 236f + i * 4f, 104f, 236f + i * 4f + sin(time * 2f + i) * 2f, 96f - i, 0.9f, alpha(0xFFFFFFFF.toInt(), 0.7f))
        // cómoda con cajón (marca C)
        rect(c, 30f, 96f, 112f, 144f, wood)
        frame(c, 30f, 96f, 112f, 144f, 1.2f)
        val dOpen = m.drawerOpen
        rect(c, 38f, 118f, 104f, 134f + 6f * dOpen, if (dOpen > 0f) 0xFF2A1A10.toInt() else woodDark)
        frame(c, 38f, 118f, 104f, 134f + 6f * dOpen, 1f)
        if (dOpen > 0.7f) {
            rf.set(52f, 128f, 88f, 136f)
            fill.color = paper
            c.drawRoundRect(rf, 1f, 1f, fill)
            ln(c, 56f, 131f, 84f, 131f, 0.6f, alpha(ink, 0.6f))
        }
        // marcas de lápiz de las tres fases
        for (k in 0 until 3) {
            val a = if (m.done[k]) 1f else 0.35f + 0.18f * m.assist
            ring(c, RoutineMech.MARK_X[k], RoutineMech.MARK_Y[k], 5f, 1.1f, alpha(ink, a))
            if (m.done[k]) {
                ln(c, RoutineMech.MARK_X[k] - 3f, RoutineMech.MARK_Y[k], RoutineMech.MARK_X[k] - 1f, RoutineMech.MARK_Y[k] + 2.5f, 1.4f, ink)
                ln(c, RoutineMech.MARK_X[k] - 1f, RoutineMech.MARK_Y[k] + 2.5f, RoutineMech.MARK_X[k] + 3.5f, RoutineMech.MARK_Y[k] - 3f, 1.4f, ink)
            }
        }
        // rayo de sol
        if (m.beamOn) {
            path.reset()
            path.moveTo(204f, 70f); path.lineTo(268f, 74f)
            path.lineTo(m.beamX + 9f, m.beamY + 5f); path.lineTo(m.beamX - 9f, m.beamY - 5f)
            path.close()
            fill.color = alpha(if (tr) 0xFFFFFFFF.toInt() else 0xFFFFE9A0.toInt(), 0.18f + 0.1f * m.curtain)
            c.drawPath(path, fill)
            val near = maxOf(m.nearness(0), maxOf(m.nearness(1), m.nearness(2)))
            circ(c, m.beamX, m.beamY, 6f + 4f * near, alpha(if (tr) 0xFFFFFFFF.toInt() else 0xFFFFE070.toInt(), 0.55f + 0.3f * near))
        }
        // reloj de mesita con manecillas
        val cx = RoutineMech.CLOCK_X; val cy = RoutineMech.CLOCK_Y
        circ(c, cx, cy, 25f, alpha(0xFF000000.toInt(), 0.2f))
        circ(c, cx, cy, 24f, paper)
        ring(c, cx, cy, 24f, 1.6f, ink)
        for (h in 0 until 12) {
            val a = Math.toRadians((h * 30f - 90f).toDouble())
            ln(c, cx + cos(a).toFloat() * 20f, cy + sin(a).toFloat() * 20f, cx + cos(a).toFloat() * 23f, cy + sin(a).toFloat() * 23f, 1f, ink)
        }
        for (t in RoutineMech.CLOCK_TICKS) {
            val a = Math.toRadians((t * 30f - 90f).toDouble())
            circ(c, cx + cos(a).toFloat() * 16.5f, cy + sin(a).toFloat() * 16.5f, 1.6f, alpha(ink, 0.55f + 0.15f * m.assist))
        }
        val ha = Math.toRadians((m.hour * 30f - 90f).toDouble())
        val ma = Math.toRadians(((m.hour * 360f) % 360f - 90f).toDouble())
        ln(c, cx, cy, cx + cos(ha).toFloat() * 13f, cy + sin(ha).toFloat() * 13f, 2.4f, ink)
        ln(c, cx, cy, cx + cos(ma).toFloat() * 19f, cy + sin(ma).toFloat() * 19f, 1.1f, ink)
        circ(c, cx, cy, 2f, ink)
        arrowBtn(c, 116f, 164f, -1); arrowBtn(c, 184f, 164f, 1)
        arrowBtn(c, 214f, 150f, -1); arrowBtn(c, 258f, 150f, 1)
        arrowBtn(c, 300f, 122f, 1); arrowBtn(c, 300f, 146f, -1)
    }

    // ------------------------------------------------------------------ N3 — los cuatro dibujos

    private fun drawDrawings(c: Canvas, m: DrawingsMech, time: Float) {
        hatchBg(c, if (tr) 0xFF9E9E9A.toInt() else 0xFFC9A877.toInt())
        rect(c, 14f, 26f, 306f, 164f, if (tr) 0xFF8A8A86.toInt() else 0xFFB98A5A.toInt())
        frame(c, 14f, 26f, 306f, 164f, 1.4f)
        // luz de la habitación: una banda continua cae sobre las hojas cuando la composición es correcta
        for (k in m.order.indices) {
            val i = m.order[k]
            val s = m.sheets[i]
            c.save()
            c.translate(s.x, s.y)
            c.rotate(m.rot[i] * 90f)
            c.skew(m.flex[i] * 0.02f, 0f)
            val hw = DrawingsMech.SW / 2f; val hh = DrawingsMech.SH / 2f
            rect(c, -hw + 2.5f, -hh + 2.5f, hw + 2.5f, hh + 2.5f, alpha(0xFF000000.toInt(), 0.25f))
            rect(c, -hw, -hh, hw, hh, paper)
            frame(c, -hw, -hh, hw, hh, 0.9f, alpha(ink, 0.7f))
            sheetArt(c, i, hw, hh)
            // trazo del borde izquierdo y derecho (altura = fracción del lado)
            val ly = -hh + DrawingsMech.LEFT_FRAC[i] * DrawingsMech.SH
            val ry = -hh + DrawingsMech.RIGHT_FRAC[i] * DrawingsMech.SH
            ln(c, -hw, ly, -hw + 8f, ly, 2f, ink)
            ln(c, hw - 8f, ry, hw, ry, 2f, ink)
            c.restore()
        }
        // trazo compartido más oscuro cuando dos bordes casi coinciden
        val row = m.rowOrder()
        if (row != null) {
            for (j in 0 until 3) {
                val g = m.jointGlow[j]
                if (g > 0f) {
                    val a = m.sheets[row[j]]; val b = m.sheets[row[j + 1]]
                    val y = a.y - DrawingsMech.SH / 2f + DrawingsMech.RIGHT_FRAC[row[j]] * DrawingsMech.SH
                    ln(c, a.x + DrawingsMech.SW / 2f - 3f, y, b.x - DrawingsMech.SW / 2f + 3f, y, 1.5f + 2.5f * g, alpha(ink, 0.4f + 0.6f * g))
                }
            }
            if (m.solved) {
                val k = (m.solvedTime / 1.4f).coerceIn(0f, 1f)
                val first = m.sheets[row[0]]; val last = m.sheets[row[3]]
                rect(c, first.x - 32f, first.y - 6f, first.x - 32f + (last.x + 32f - (first.x - 32f)) * k, first.y + 8f, alpha(0xFF000000.toInt(), 0.2f))
                // el símbolo del borde: pendientes inclinada-recta-muy inclinada-contraria
                if (m.solvedTime > 1.2f) {
                    val sy = 24f
                    val t = ((m.solvedTime - 1.2f) / 1.4f).coerceIn(0f, 1f)
                    val sx = 80f
                    val dxs = floatArrayOf(-8f, 0f, -16f, 8f)
                    for (n in 0 until 4) {
                        if (n / 4f <= t) ln(c, sx + n * 40f + dxs[n] * 0.5f, sy + 6f, sx + n * 40f - dxs[n] * 0.5f, sy + 26f, 2.4f, ink)
                    }
                }
            }
        }
    }

    private fun sheetArt(c: Canvas, i: Int, hw: Float, hh: Float) {
        // ventana (abierta solo en A), taza junto a la cama, armario y sombra cada vez más larga: B corta, A media, C hasta el armario, D todo el cuarto
        rect(c, -hw + 8f, -hh + 7f, -hw + 20f, -hh + 19f, if (i == 0) alpha(0xFFBFE0F0.toInt(), 0.9f) else alpha(0xFF8A8A8A.toInt(), 0.5f))
        frame(c, -hw + 8f, -hh + 7f, -hw + 20f, -hh + 19f, 0.7f)
        rect(c, hw - 18f, -hh + 8f, hw - 8f, hh - 10f, alpha(woodDark, 0.6f)) // armario
        circ(c, -hw + 26f, hh - 10f, 2.6f, if (tr) 0xFF8A8A8A.toInt() else 0xFF4F7FC8.toInt()) // taza
        val len = when (i) { 1 -> 14f; 0 -> 30f; 2 -> 56f; else -> 120f }
        path.reset()
        path.moveTo(-hw + 10f, hh - 6f)
        path.lineTo(-hw + 10f + len, hh - 6f)
        path.lineTo(-hw + 10f + len - 4f, hh - 12f)
        path.lineTo(-hw + 14f, hh - 12f)
        path.close()
        fill.color = alpha(0xFF000000.toInt(), if (i == 3) 0.5f else 0.28f)
        c.save()
        c.clipRect(-hw + 1f, -hh + 1f, hw - 1f, hh - 1f)
        c.drawPath(path, fill)
        c.restore()
        if (i == 3) { // D: mamá todavía está aquí
            circ(c, -hw + 40f, hh - 22f, 3f, ink)
            ln(c, -hw + 40f, hh - 19f, -hw + 40f, hh - 10f, 1.2f, ink)
        }
    }

    // ------------------------------------------------------------------ N4 — los retratos torcidos

    private fun drawFrames(c: Canvas, m: FramesMech, time: Float) {
        rect(c, 0f, 0f, 320f, 180f, if (tr) 0xFFA8A8A4.toInt() else 0xFFD9C79D.toInt())
        var sx = 6f
        while (sx < 320f) { ln(c, sx, 0f, sx, 180f, 1.2f, alpha(ink, 0.10f)); sx += 14f }
        rect(c, 0f, 150f, 320f, 180f, alpha(woodDark, 0.5f))
        // panel del revestimiento que se desplaza al resolver (a la derecha)
        val r = m.revealed
        rect(c, 286f, 40f, 316f, 140f, woodDark)
        if (r > 0f) {
            rect(c, 288f, 42f, 314f, 138f, 0xFF1A120C.toInt())
            rect(c, 286f + 28f * r, 40f, 316f + 28f * r, 140f, wood)
            if (r > 0.6f) { // la llave
                circ(c, 298f, 90f, 3.5f, if (tr) 0xFFDDDDDD.toInt() else 0xFFD9B34A.toInt())
                ln(c, 298f, 93f, 298f, 108f, 1.8f, if (tr) 0xFFDDDDDD.toInt() else 0xFFD9B34A.toInt())
            }
        }
        frame(c, 286f, 40f, 316f, 140f, 1f)
        for (i in 0 until m.count) {
            val cx = m.centerX[i]
            val cy = m.centerY
            val a = m.angle[i] + sin(time * 4.2f + i) * m.swingVel[i] * 0.15f
            val near = m.match(i)
            // marca de lápiz: dónde debe caer la sombra
            val mx0 = cx + 15f; val my0 = cy + 28f
            ln(c, mx0, my0, m.markTipX(i), m.markTipY(i), 1.1f, alpha(ink, 0.35f + 0.2f * m.assist + 0.3f * near))
            // sombra del marco sobre el papel pintado
            val sxTip = m.shadowTipX(i, m.angle[i]); val syTip = m.shadowTipY(i, m.angle[i])
            ln(c, mx0, my0, sxTip, syTip, 3f + 1.5f * near, alpha(0xFF000000.toInt(), 0.18f + 0.3f * near))
            if (m.settled[i]) circ(c, sxTip, syTip, 2f, alpha(ink, 0.7f))
            // gancho, cuerda y marco
            val hookY = cy - 34f - m.ropeLen[i] * 0.2f
            circ(c, cx, hookY, 1.8f, ink)
            c.save()
            c.translate(cx, hookY)
            c.rotate(a)
            val ly = cy - hookY
            ln(c, 0f, 0f, -17f, ly - 26f, 0.8f, alpha(ink, 0.8f))
            ln(c, 0f, 0f, 17f, ly - 26f, 0.8f, alpha(ink, 0.8f))
            c.translate(0f, ly)
            rect(c, -20f, -26f, 20f, 26f, woodDark)
            rect(c, -16f, -22f, 16f, 22f, if (tr) 0xFFC8C8C4.toInt() else 0xFFEFE2C0.toInt())
            frame(c, -20f, -26f, 20f, 26f, 1.4f)
            // retrato (una cabeza y unos hombros dibujados con tiza)
            circ(c, 0f, -4f, 7f, alpha(ink, 0.5f + 0.1f * i))
            rect(c, -10f, 6f, 10f, 20f, alpha(ink, 0.4f))
            c.restore()
            arrowBtn(c, cx - 17f, FramesMech.ARROW_Y, -1, if (m.settled[i]) alpha(ink, 0.25f) else ink)
            arrowBtn(c, cx + 17f, FramesMech.ARROW_Y, 1, if (m.settled[i]) alpha(ink, 0.25f) else ink)
        }
        // línea continua formada por las cuatro sombras al resolver
        if (m.solved) {
            val k = m.revealed
            for (i in 0 until 3) {
                ln(c, m.markTipX(i), m.markTipY(i), m.markTipX(i + 1) + (m.markTipX(i) - m.markTipX(i + 1)) * (1f - k), m.markTipY(i + 1) + (m.markTipY(i) - m.markTipY(i + 1)) * (1f - k), 2f, alpha(ink, 0.8f))
            }
        }
    }

    // ------------------------------------------------------------------ N5 — el cuadro eléctrico

    private fun drawFuse(c: Canvas, m: FuseBoxMech, time: Float) {
        rect(c, 0f, 0f, 320f, 180f, if (tr) 0xFF3C3C3C.toInt() else 0xFF4A4036.toInt())
        rect(c, 14f, 22f, 306f, 172f, if (tr) 0xFF5A5A58.toInt() else 0xFF6E6254.toInt())
        frame(c, 14f, 22f, 306f, 172f, 2f, 0xFF15110D.toInt())
        for (p in 0 until 4) circ(c, if (p % 2 == 0) 20f else 300f, if (p < 2) 28f else 166f, 2f, 0xFF15110D.toInt())
        // diagrama de mantenimiento desgastado: cuatro cajitas y líneas casi borradas
        for (i in 0 until 4) {
            val y = 48f + i * 36f
            ln(c, 70f, y, 240f, y, 0.7f, alpha(0xFFFFFFFF.toInt(), 0.10f))
            rect(c, 140f + (i % 2) * 20f, y - 4f, 154f + (i % 2) * 20f, y + 4f, alpha(0xFFFFFFFF.toInt(), 0.07f))
        }
        val stable = m.steady
        // terminales y lámparas (de arriba abajo: pasillo, vestíbulo, sótano, cocina)
        for (t in 0 until 4) {
            val ty = FuseBoxMech.TERM_Y[t]
            circ(c, FuseBoxMech.TERM_X, ty, 11f, if (tr) 0xFFC8C8C4.toInt() else 0xFFE8E0D0.toInt())
            ring(c, FuseBoxMech.TERM_X, ty, 11f, 1.2f, 0xFF15110D.toInt())
            circ(c, FuseBoxMech.TERM_X, ty, 4f, 0xFFA8793A.toInt())
            pictogram(c, t, 300f, ty)
            val lampOn = m.lampFlash[t] * (0.5f + 0.5f * sin(time * 40f).let { if (m.solved) 1f else it })
            val lamp = if (m.solved) stable else lampOn.coerceIn(0f, 1f)
            circ(c, 300f - 22f, ty - 11f, 3.5f, alpha(if (tr) 0xFFFFFFFF.toInt() else 0xFFFFE070.toInt(), 0.15f + 0.85f * lamp))
        }
        // cables
        for (b in 0 until 4) {
            val sy = FuseBoxMech.SRC_Y[b]
            circ(c, FuseBoxMech.SRC_X, sy, 8f, 0xFF2A241E.toInt())
            ring(c, FuseBoxMech.SRC_X, sy, 8f, 1f, 0xFF15110D.toInt())
            val ex = m.endX[b]; val ey = m.endY[b]
            val wob = if (m.isTesting(b)) sin(time * 70f) * 1.8f else 0f
            path.reset()
            path.moveTo(FuseBoxMech.SRC_X + 6f, sy)
            val sag = 10f + abs(ex - FuseBoxMech.SRC_X) * 0.06f
            path.cubicTo(FuseBoxMech.SRC_X + 50f, sy + sag, ex - 50f, ey + sag + wob, ex, ey + wob)
            line.strokeWidth = 3.4f
            line.color = 0xFF1A130C.toInt()
            c.drawPath(path, line)
            line.strokeWidth = 2.2f
            line.color = if (m.isLocked(b)) 0xFFE09A4A.toInt() else if (tr) 0xFFB89870.toInt() else 0xFFC9783A.toInt()
            c.drawPath(path, line)
            // pulso que viaja por el cable
            val pu = m.pulse[b]
            if (pu in 0f..1f) {
                val px = FuseBoxMech.SRC_X + (ex - FuseBoxMech.SRC_X) * pu
                val py = sy + (ey - sy) * pu + sin(pu * 3.14f) * sag * 0.75f
                circ(c, px, py, 3.2f, alpha(0xFFFFFFFF.toInt(), 0.9f))
            }
            circ(c, ex, ey, 4.4f, 0xFFD8B46A.toInt())
            ring(c, ex, ey, 4.4f, 0.8f, 0xFF15110D.toInt())
            if (m.isTesting(b)) { // chisporroteo
                for (k in 0 until 4) ln(c, ex, ey, ex + sin(time * 55f + k * 2f) * 9f, ey + cos(time * 63f + k) * 9f, 0.9f, 0xFFFFF0A0.toInt())
            }
        }
        // manómetro / indicadores: responden al resolver
        ring(c, 160f, 36f, 11f, 1.4f, 0xFF15110D.toInt())
        val na = Math.toRadians((-150f + 120f * (if (m.solved) 0.5f else 0.25f + 0.5f * (m.lockedCount / 4f) + sin(time * 9f) * 0.03f * (4 - m.lockedCount))).toDouble())
        ln(c, 160f, 36f, 160f + cos(na).toFloat() * 9f, 36f + sin(na).toFloat() * 9f, 1.4f, if (m.solved) 0xFF7ADB7A.toInt() else 0xFFFFE070.toInt())
    }

    private fun pictogram(c: Canvas, t: Int, x: Float, y: Float) {
        val col = alpha(0xFFFFFFFF.toInt(), 0.75f)
        when (t) {
            0 -> { // pasillo: dos líneas que se alejan
                ln(c, x - 6f, y + 5f, x - 2f, y - 5f, 1.2f, col); ln(c, x + 6f, y + 5f, x + 2f, y - 5f, 1.2f, col)
            }
            1 -> { // vestíbulo: puerta
                frame(c, x - 4f, y - 6f, x + 4f, y + 6f, 1.2f, col); circ(c, x + 2f, y, 0.9f, col)
            }
            2 -> { // sótano: escalones hacia abajo
                ln(c, x - 6f, y - 4f, x - 2f, y - 4f, 1.2f, col); ln(c, x - 2f, y - 4f, x - 2f, y, 1.2f, col)
                ln(c, x - 2f, y, x + 2f, y, 1.2f, col); ln(c, x + 2f, y, x + 2f, y + 4f, 1.2f, col); ln(c, x + 2f, y + 4f, x + 6f, y + 4f, 1.2f, col)
            }
            else -> { // cocina: olla
                frame(c, x - 5f, y - 2f, x + 5f, y + 5f, 1.2f, col); ln(c, x - 7f, y - 2f, x + 7f, y - 2f, 1.2f, col)
            }
        }
    }

    // ------------------------------------------------------------------ T1 — las siete marcas

    private fun drawMarks(c: Canvas, m: MarksMech, time: Float) {
        rect(c, 0f, 0f, 320f, 180f, if (tr) 0xFF5E5E5C.toInt() else 0xFF5A5148.toInt())
        for (k in 0 until 60) {
            val x = (k * 37 % 320).toFloat(); val y = (k * 53 % 180).toFloat()
            ln(c, x, y, x + 9f, y + 1f, 0.6f, alpha(0xFF000000.toInt(), 0.13f))
        }
        // grietas que se abren al resolver
        if (m.crack > 0f) {
            for (i in 0 until 7) {
                val x = m.markX(i)
                ln(c, x, 40f, x + sin(i * 2.3f) * 14f * m.crack, 40f + 60f * m.crack, 1.4f, alpha(0xFF0A0A0A.toInt(), 0.8f))
                ln(c, x, 100f, x + cos(i * 1.7f) * 12f * m.crack, 100f + 40f * m.crack, 1.2f, alpha(0xFF0A0A0A.toInt(), 0.7f))
            }
        }
        for (i in 0 until 7) {
            val x0 = m.markX(i)
            val len = m.markLen[i] * 17f
            val jx = sin(time * 80f) * 1.6f * m.vibe[i]
            val top = 90f - len / 2f
            // profundidad: placa hundida tras la marca
            rect(c, x0 - 9f + jx, top - 4f, x0 + 9f + jx, top + len + 4f, alpha(0xFF000000.toInt(), 0.25f))
            val f = m.flash[i]
            val col = if (f > 0f) 0xFFDADAD8.toInt() else 0xFFA9A9A6.toInt()
            ln(c, x0 + jx, top, x0 + jx, top + len, 2.6f + 1.6f * m.vibe[i], alpha(col, 0.5f + 0.5f * f.coerceAtLeast(0.35f)))
            ln(c, x0 - 2f + jx, top + 2f, x0 - 2f + jx, top + len - 2f, 0.8f, alpha(0xFF000000.toInt(), 0.5f))
            if (m.muffled[i] > 0f) rect(c, x0 - 12f, top - 6f, x0 + 12f, top + len + 6f, alpha(0xFF000000.toInt(), 0.35f * m.muffled[i]))
            if (f > 0.3f) circ(c, x0, top + len + 10f, 2f, alpha(0xFFFFFFFF.toInt(), f))
            // pista visual con ayuda: las marcas largas se marcan con un puntito grave encima
            if (m.assist >= 1 && m.markLen[i] >= 3) circ(c, x0, top - 9f, 1.6f, alpha(0xFFFFFFFF.toInt(), 0.45f))
        }
        // la oreja: reproducir de nuevo el patrón
        ring(c, MarksMech.EAR_X, MarksMech.EAR_Y, 9f, 1.2f, alpha(0xFFFFFFFF.toInt(), if (m.isPlayingRef) 1f else 0.6f))
        ln(c, MarksMech.EAR_X - 3f, MarksMech.EAR_Y - 4f, MarksMech.EAR_X + 2f, MarksMech.EAR_Y - 2f, 1.2f, alpha(0xFFFFFFFF.toInt(), 0.7f))
        ln(c, MarksMech.EAR_X + 2f, MarksMech.EAR_Y - 2f, MarksMech.EAR_X, MarksMech.EAR_Y + 4f, 1.2f, alpha(0xFFFFFFFF.toInt(), 0.7f))
        // progreso: puntos de grafito de los golpes ya alcanzados
        for (k in 0 until 4) circ(c, 120f + k * 26f, 158f, 3f, if (k < m.best) 0xFFE8E8E4.toInt() else alpha(0xFFFFFFFF.toInt(), 0.18f))
    }

    // ------------------------------------------------------------------ T2 — el retrato sin rostro

    private fun drawPortrait(c: Canvas, m: PortraitMech, time: Float) {
        rect(c, 0f, 0f, 320f, 180f, if (tr) 0xFF6E6E6C.toInt() else 0xFF6A5B4A.toInt())
        // el retrato cubierto de grafito
        rect(c, 18f, 18f, 198f, 164f, 0xFF2A2A2A.toInt())
        frame(c, 18f, 18f, 198f, 164f, 2.4f, 0xFF8A8A88.toInt())
        for (k in 0 until 50) {
            val x = 22f + (k * 29 % 172); val y = 22f + (k * 47 % 138)
            ln(c, x.toFloat(), y.toFloat(), x + 14f, y + 3f, 0.8f, alpha(0xFF555555.toInt(), 0.5f))
        }
        // silueta sin rostro (cabeza y hombros): el contorno que "falta"
        ring(c, 110f, 66f, 30f, 0.8f, alpha(0xFFFFFFFF.toInt(), 0.12f))
        // cómoda
        rect(c, 210f, 18f, 312f, 164f, if (tr) 0xFF7A7A78.toInt() else 0xFF8A6A48.toInt())
        frame(c, 210f, 18f, 312f, 164f, 1.4f)
        // huecos con contorno blanco
        for (h in 0 until 4) {
            val sharp = m.edgeSharpness(h)
            val a = if (m.solved) 1f else (0.45f + 0.12f * m.assist + 0.5f * sharp).coerceAtMost(1f)
            if (m.coveredWrong(h)) continue // una pieza equivocada tapa el borde que debería verse
            drawShape(c, m.holeShape[h], m.holeX[h], m.holeY[h], if (h == 3) 1 else 0, false, 0xFFFFFFFF.toInt(), a, true)
        }
        // rastro de polvo de grafito
        for (d in m.dustTrail) circ(c, d[0], d[1], 1.1f, alpha(0xFF9A9A9A.toInt(), 0.5f * d[2]))
        // piezas de madera
        for (p in 0 until 4) {
            val pc = m.pieces[p]
            drawShape(c, m.shapes[p], pc.x + 2.5f, pc.y + 2.5f, m.rot[p], true, 0xFF000000.toInt(), 0.3f, false)
            drawShape(c, m.shapes[p], pc.x, pc.y, m.rot[p], true, if (tr) 0xFFA0A0A0.toInt() else 0xFFB98A5A.toInt(), 1f, false)
            drawShape(c, m.shapes[p], pc.x, pc.y, m.rot[p], false, ink, 1f, false)
        }
        // símbolo final: tres líneas y un punto
        val s = m.symbol
        if (s > 0f) {
            rect(c, 18f, 18f, 198f, 164f, alpha(0xFF000000.toInt(), 0.35f * s))
            for (k in 0 until 3) {
                val k0 = (s * 3f - k).coerceIn(0f, 1f)
                ln(c, 70f + k * 28f, 56f, 70f + k * 28f, 56f + 66f * k0, 3.2f, alpha(0xFFFFFFFF.toInt(), 0.95f))
            }
            if (s > 0.9f) circ(c, 154f, 134f, 4f, 0xFFFFFFFF.toInt())
        }
    }

    private fun drawShape(c: Canvas, shape: PortraitMech.Shape, x: Float, y: Float, rot: Int, solidFill: Boolean, color: Int, a: Float, outline: Boolean) {
        c.save()
        c.translate(x, y)
        c.rotate(rot * 90f)
        val col = alpha(color, a)
        fill.color = col
        line.color = col
        line.strokeWidth = if (outline) 1.4f else 1.1f
        val st = solidFill && !outline
        when (shape) {
            PortraitMech.Shape.L -> {
                path.reset()
                path.moveTo(-10f, -14f); path.lineTo(0f, -14f); path.lineTo(0f, 4f); path.lineTo(14f, 4f)
                path.lineTo(14f, 14f); path.lineTo(-10f, 14f); path.close()
                c.drawPath(path, if (st) fill else line)
            }
            PortraitMech.Shape.CROSS -> {
                path.reset()
                path.moveTo(-4f, -14f); path.lineTo(4f, -14f); path.lineTo(4f, -4f); path.lineTo(14f, -4f); path.lineTo(14f, 4f)
                path.lineTo(4f, 4f); path.lineTo(4f, 14f); path.lineTo(-4f, 14f); path.lineTo(-4f, 4f); path.lineTo(-14f, 4f)
                path.lineTo(-14f, -4f); path.lineTo(-4f, -4f); path.close()
                c.drawPath(path, if (st) fill else line)
            }
            PortraitMech.Shape.ROUND -> if (st) c.drawCircle(0f, 0f, 13f, fill) else c.drawCircle(0f, 0f, 13f, line)
            PortraitMech.Shape.LONG -> {
                // base horizontal; el hueco la pide vertical
                if (st) c.drawRect(-20f, -4f, 20f, 4f, fill) else c.drawRect(-20f, -4f, 20f, 4f, line)
            }
        }
        c.restore()
    }

    // ------------------------------------------------------------------ T4 — la caldera

    private fun drawBoiler(c: Canvas, m: BoilerMech, time: Float) {
        rect(c, 0f, 0f, 320f, 180f, if (tr) 0xFF444443.toInt() else 0xFF4E4640.toInt())
        // el agua del pasadizo, abajo, que baja al resolver
        val wy = 168f + 10f * m.waterDrop
        rect(c, 0f, wy, 320f, 180f, alpha(if (tr) 0xFF5A6A70.toInt() else 0xFF3F6A8A.toInt(), 0.6f))
        // tubo colector arriba y manómetro
        rect(c, 10f, 40f, 310f, 50f, if (tr) 0xFF6E6E6C.toInt() else 0xFF7A6A5C.toInt())
        frame(c, 10f, 40f, 310f, 50f, 1.2f)
        circ(c, 160f, 24f, 15f, paper)
        ring(c, 160f, 24f, 15f, 1.6f, ink)
        for (k in 0 until 7) {
            val a = Math.toRadians((-210f + k * 40f).toDouble())
            ln(c, 160f + cos(a).toFloat() * 11f, 24f + sin(a).toFloat() * 11f, 160f + cos(a).toFloat() * 14f, 24f + sin(a).toFloat() * 14f, 0.9f, ink)
        }
        val ga = Math.toRadians((-210f + 240f * m.gauge).toDouble())
        ln(c, 160f, 24f, 160f + cos(ga).toFloat() * 11f, 24f + sin(ga).toFloat() * 11f, 1.8f, if (m.solved) 0xFF7ADB7A.toInt() else 0xFFB02A2A.toInt())
        circ(c, 160f, 24f, 2f, ink)
        for (v in 0 until m.count) {
            val vx = m.valveX[v]
            val pu = m.pulse[v]
            // tubería vertical que late con su ritmo
            val pw = 9f + 3f * pu
            rect(c, vx - pw / 2f, 50f, vx + pw / 2f, 74f, if (tr) 0xFF77777A.toInt() else 0xFF8A7A6C.toInt())
            rect(c, vx - pw / 2f, 120f, vx + pw / 2f, 140f, if (tr) 0xFF77777A.toInt() else 0xFF8A7A6C.toInt())
            frame(c, vx - pw / 2f, 50f, vx + pw / 2f, 74f, 0.9f)
            if (pu > 0.1f) ring(c, vx, 62f, 7f + 9f * (1f - pu), 1f, alpha(0xFFFFFFFF.toInt(), pu * 0.7f))
            // válvula: volante con rayos girando a su posición
            val ang = m.detent[v] * 30f
            circ(c, vx, m.valveY, 26f, alpha(0xFF000000.toInt(), 0.25f))
            circ(c, vx, m.valveY, 24f, if (m.locked[v]) (if (tr) 0xFF9AA09A.toInt() else 0xFF6F8F5F.toInt()) else (if (tr) 0xFF888888.toInt() else 0xFFA05A3A.toInt()))
            ring(c, vx, m.valveY, 24f, 2f, ink)
            c.save()
            c.translate(vx, m.valveY)
            c.rotate(ang)
            for (s in 0 until 4) { c.rotate(90f); ln(c, 0f, 0f, 0f, -20f, 3f, ink) }
            circ(c, 0f, -19f, 3f, 0xFFF2F2E0.toInt()) // marca de posición
            c.restore()
            circ(c, vx, m.valveY, 5f, ink)
            // detentes alrededor
            for (d in 0 until 12) {
                val a = Math.toRadians((d * 30f - 90f).toDouble())
                val sel = d == m.detent[v]
                circ(c, vx + cos(a).toFloat() * 30f, m.valveY + sin(a).toFloat() * 30f, if (sel) 1.8f else 0.9f, alpha(0xFFFFFFFF.toInt(), if (sel) 0.9f else 0.35f))
            }
            // figura de referencia junto a la válvula (el ritmo que debe tener su tubería)
            refFigure(c, m.targetBand[v], vx - 20f, 156f - 18f, time)
            arrowBtn(c, vx - 16f, 153f, -1, if (m.locked[v]) alpha(ink, 0.25f) else ink)
            arrowBtn(c, vx + 16f, 153f, 1, if (m.locked[v]) alpha(ink, 0.25f) else ink)
            // si el patrón coincide en parte, su figura de referencia destella
            if (m.closeness(v) == 0.5f) ring(c, vx, m.valveY, 28f, 1f, alpha(0xFFFFFFFF.toInt(), 0.35f + 0.25f * sin(time * 6f)))
        }
    }

    /** Figura de referencia: banda 0 callada (línea plana), 1 continua (onda), 2 dos golpes y espera, 3 ciclo incompleto (se apaga). */
    private fun refFigure(c: Canvas, band: Int, x: Float, y: Float, time: Float) {
        rect(c, x - 2f, y - 8f, x + 42f, y + 10f, alpha(paper, 0.9f))
        frame(c, x - 2f, y - 8f, x + 42f, y + 10f, 0.8f)
        when (band) {
            0 -> ln(c, x + 2f, y + 3f, x + 38f, y + 3f, 1.4f, ink)
            1 -> for (k in 0 until 6) rect(c, x + 3f + k * 6f, y - 4f, x + 6.5f + k * 6f, y + 6f, ink)
            2 -> { rect(c, x + 4f, y - 5f, x + 9f, y + 6f, ink); rect(c, x + 13f, y - 5f, x + 18f, y + 6f, ink); ln(c, x + 22f, y + 3f, x + 38f, y + 3f, 1.2f, alpha(ink, 0.6f)) }
            else -> { rect(c, x + 4f, y - 5f, x + 9f, y + 6f, ink); rect(c, x + 13f, y - 2f, x + 18f, y + 6f, alpha(ink, 0.7f)); rect(c, x + 22f, y + 1f, x + 27f, y + 6f, alpha(ink, 0.4f)) }
        }
    }

    // ------------------------------------------------------------------ T5 — la antena

    private fun drawAntenna(c: Canvas, m: AntennaMech, time: Float) {
        // cielo / horizonte
        rect(c, 0f, 0f, 320f, 62f, if (tr) 0xFF8E8E8C.toInt() else 0xFF7C7A92.toInt())
        rect(c, 0f, 62f, 320f, 180f, if (tr) 0xFF3E3E3D.toInt() else 0xFF55524A.toInt())
        ln(c, 0f, 62f, 320f, 62f, 1.2f, ink)
        // horizonte: ventana iluminada, torre oscura y línea quebrada
        rect(c, 236f, 36f, 250f, 50f, 0xFFFFE9A0.toInt())
        frame(c, 236f, 36f, 250f, 50f, 1f)
        rect(c, 60f, 14f, 72f, 62f, 0xFF1A1A22.toInt())
        path.reset()
        path.moveTo(130f, 56f); path.lineTo(142f, 40f); path.lineTo(152f, 54f); path.lineTo(164f, 36f); path.lineTo(176f, 56f)
        line.strokeWidth = 1.6f; line.color = ink
        c.drawPath(path, line)
        // suelo de la azotea con juntas
        for (k in 0 until 8) ln(c, 0f, 70f + k * 14f, 320f, 70f + k * 14f + 2f, 0.6f, alpha(0xFF000000.toInt(), 0.18f))
        // siluetas objetivo (en el plano de sombras); se afinan al acercar la punta
        for (i in 0 until 3) {
            val nr = m.nearness(i)
            val tx = m.targetX(i); val ty = m.targetY(i)
            val a = if (m.solved) 1f else 0.3f + 0.12f * m.assist + 0.6f * nr
            targetShape(c, i, tx, ty, alpha(0xFFFFFFFF.toInt(), a), alpha(0xFF000000.toInt(), a * 0.3f))
        }
        // sombra de la antena sobre la azotea (cadena desplazada y aplastada)
        var px = m.baseX(); var py = m.baseY()
        for (i in 0 until 3) {
            val tx = m.tipX(i); val ty = m.tipY(i)
            ln(c, px + 7f, py + 5f, tx + 7f, ty + 5f, 3f + 3f * m.nearness(i), alpha(0xFF000000.toInt(), 0.30f + 0.3f * m.nearness(i)))
            px = tx; py = ty
        }
        // brazos con articulaciones
        px = m.baseX(); py = m.baseY()
        rect(c, m.baseX() - 9f, m.baseY() - 2f, m.baseX() + 9f, m.baseY() + 8f, if (tr) 0xFF666666.toInt() else 0xFF7A6A5C.toInt())
        for (i in 0 until 3) {
            val tx = m.tipX(i); val ty = m.tipY(i)
            val w = 3.6f - i * 0.5f
            ln(c, px, py, tx, ty, w + 1.4f, ink)
            ln(c, px, py, tx, ty, w, if (m.aligned[i]) (if (tr) 0xFFF0F0F0.toInt() else 0xFFE8D89A.toInt()) else (if (tr) 0xFFAAAAAA.toInt() else 0xFF9A9AA6.toInt()))
            circ(c, tx, ty, 3.4f, ink)
            circ(c, tx, ty, 2f, if (m.aligned[i]) 0xFFFFFFFF.toInt() else 0xFFB0B0B0.toInt())
            px = tx; py = ty
        }
        circ(c, m.baseX(), m.baseY(), 4f, ink)
        // sombra larga final hacia la ventana imposible
        if (m.longShadow > 0f) {
            val l = m.longShadow
            ln(c, m.baseX(), m.baseY(), m.baseX() + 150f * l, m.baseY() - 100f * l, 2.4f, alpha(0xFF000000.toInt(), 0.5f))
        }
        for (i in 0 until 3) {
            arrowBtn(c, AntennaMech.BTN_X[i] - 14f, AntennaMech.BTN_Y, -1)
            arrowBtn(c, AntennaMech.BTN_X[i] + 14f, AntennaMech.BTN_Y, 1)
            // barritas de longitud: la misma jerarquía que los brazos (corto, medio, largo)
            ln(c, AntennaMech.BTN_X[i] - 8f, AntennaMech.BTN_Y - 13f, AntennaMech.BTN_X[i] - 8f + m.len[i] * 0.3f, AntennaMech.BTN_Y - 13f, 2f, alpha(ink, 0.7f))
        }
    }

    private fun targetShape(c: Canvas, arm: Int, x: Float, y: Float, col: Int, shadowCol: Int) {
        line.strokeWidth = 1.3f
        line.color = col
        when (arm) {
            0 -> { c.drawRect(x - 5f, y - 5f, x + 5f, y + 5f, line) } // ventana
            1 -> { // línea quebrada
                path.reset()
                path.moveTo(x - 9f, y + 4f); path.lineTo(x - 3f, y - 4f); path.lineTo(x + 2f, y + 3f); path.lineTo(x + 9f, y - 5f)
                c.drawPath(path, line)
            }
            else -> { c.drawRect(x - 3f, y - 14f, x + 3f, y + 3f, line) } // torre
        }
    }

    // ------------------------------------------------------------------ C1 — la pared

    private fun drawWall(c: Canvas, m: WallJointMech, time: Float) {
        rect(c, 0f, 0f, 320f, 180f, wall)
        var x = 8f
        while (x < 320f) { ln(c, x, 0f, x, 180f, 1f, alpha(ink, 0.10f)); x += 16f }
        rect(c, 0f, 168f, 320f, 180f, woodDark) // rodapié
        // el tramo del revestimiento que se desplaza hacia dentro
        val o = m.open
        rect(c, 190f, 60f, 270f, 168f, alpha(0xFF000000.toInt(), 0.12f))
        if (o > 0f) rect(c, 190f + 6f * o, 60f, 270f - 6f * o, 168f, 0xFF140E0A.toInt())
        rect(c, 196f - 4f * o, 66f, 264f - 4f * o - 40f * o, 168f, alpha(wall, 1f))
        // juntas falsas
        for (j in m.fakeX.indices) crack(c, m.fakeX[j], m.fakeY[j], 0.35f, j)
        // juntas verdaderas (grietas que "respiran" un poco al acercarse la lámina)
        for (j in 0 until 3) {
            val near = m.nearness(j)
            crack(c, m.jointX[j], m.jointY[j], 0.7f + 0.3f * near + 0.1f * m.assist, j + 5)
            if (m.activated[j]) {
                circ(c, m.jointX[j], m.jointY[j], 4f, alpha(accent, 0.8f))
                ring(c, m.jointX[j], m.jointY[j], 7f, 1f, alpha(ink, 0.8f))
            }
        }
        // TRAUMA: contorno de siete marcas de la puerta oculta
        if (tr) {
            for (k in 0 until 7) {
                val a = k * 0.9f
                ln(c, 196f + k * 11f, 62f + (k % 3) * 3f, 196f + k * 11f, 70f + (k % 3) * 3f, 1.4f, alpha(0xFFFFFFFF.toInt(), 0.7f))
            }
        }
        // polvo
        for (d in m.dust) circ(c, d[0] + sin(d[2] * 9f) * 2f, d[1] + (1f - d[2]) * 6f, 1.1f, alpha(0xFFFFFFFF.toInt(), 0.7f * d[2]))
        // lámina de latón
        c.save()
        c.translate(m.strip.x, m.strip.y)
        rect(c, -28f + 2f, -4f + 2.5f, 28f + 2f, 4f + 2.5f, alpha(0xFF000000.toInt(), 0.28f))
        rf.set(-28f, -4f, 28f, 4f)
        fill.color = if (tr) 0xFFC8C8C0.toInt() else 0xFFD9B34A.toInt()
        c.drawRoundRect(rf, 1.5f, 1.5f, fill)
        ln(c, -24f, -1.5f, 24f, -1.5f, 0.8f, 0xFFFFFFFF.toInt())
        frame(c, -28f, -4f, 28f, 4f, 0.8f)
        c.restore()
        if (m.jointUnder() >= 0) ring(c, m.strip.x, m.strip.y, 12f, 1f, alpha(0xFFFFFFFF.toInt(), 0.5f + 0.3f * sin(time * 8f)))
    }

    private fun crack(c: Canvas, x: Float, y: Float, a: Float, seed: Int) {
        path.reset()
        path.moveTo(x - 7f, y - 9f + (seed % 3))
        path.lineTo(x - 2f, y - 3f)
        path.lineTo(x + 2f, y + 1f)
        path.lineTo(x - 1f, y + 6f)
        path.lineTo(x + 4f, y + 11f)
        line.strokeWidth = 1.1f
        line.color = alpha(ink, a)
        c.drawPath(path, line)
    }

    // ------------------------------------------------------------------ C4 — la carta partida

    private fun drawLetter(c: Canvas, m: LetterMech, time: Float) {
        hatchBg(c, if (tr) 0xFF7A7A78.toInt() else 0xFF8A6A48.toInt())
        rect(c, 24f, 30f, 296f, 160f, if (tr) 0xFF6A6A68.toInt() else 0xFF9C7A52.toInt())
        frame(c, 24f, 30f, 296f, 160f, 1.4f)
        val err = m.gapError()
        for (which in 0 until 2) {
            val f = if (which == 0) m.a else m.b
            val rot = if (which == 0) m.rotA else m.rotB
            c.save()
            c.translate(f.x, f.y)
            c.rotate(rot)
            c.skew(m.flex * 0.015f, 0f)
            val hw = LetterMech.FRAG_W / 2f; val hh = LetterMech.FRAG_H / 2f
            path.reset()
            if (which == 0) {
                path.moveTo(-hw, -hh); path.lineTo(hw, -hh)
                for (k in 0 until 9) path.lineTo(hw + m.tear[k], -hh + k * (LetterMech.FRAG_H / 8f))
                path.lineTo(-hw, hh); path.close()
            } else {
                path.moveTo(-hw, -hh)
                for (k in 0 until 9) path.lineTo(-hw + m.tear[k], -hh + k * (LetterMech.FRAG_H / 8f))
                path.lineTo(-hw, hh); path.lineTo(hw, hh); path.lineTo(hw, -hh); path.close()
            }
            fill.color = alpha(0xFF000000.toInt(), 0.25f)
            c.save(); c.translate(2.5f, 3f); c.drawPath(path, fill); c.restore()
            fill.color = paper
            c.drawPath(path, fill)
            line.strokeWidth = 0.9f; line.color = alpha(ink, 0.7f)
            c.drawPath(path, line)
            // renglones; las palabras de la unión se desplazan si los bordes no coinciden
            val shiftY = if (which == 1) (m.b.y - m.a.y) * 0.35f * (if (m.aligned) 0f else 1f) else 0f
            for (k in 0 until 9) {
                val ly = -hh + 12f + k * 10f + shiftY
                val x0 = if (which == 0) -hw + 8f else -hw + 6f
                val x1 = if (which == 0) hw - 6f else hw - 14f
                ln(c, x0, ly, x1 - (k % 3) * 6f, ly, 1f, alpha(ink, 0.5f))
            }
            c.restore()
        }
        // fibras del borde: se unen en una línea continua a medida que coinciden
        val j = m.fiberJoin
        if (j > 0.25f) {
            for (k in 0 until 9) {
                val yy = m.a.y - LetterMech.FRAG_H / 2f + k * (LetterMech.FRAG_H / 8f)
                ln(c, m.a.x + LetterMech.FRAG_W / 2f - 2f, yy, m.b.x - LetterMech.FRAG_W / 2f + 2f, yy, 0.8f + 1.4f * j, alpha(0xFFFFFFFF.toInt(), 0.35f * j))
            }
        }
        // marcas del margen: zigzag y rectángulo en NORMAL; la línea alta solo se distingue en TRAUMA
        if (m.marksShown > 0) {
            val mx = m.b.x + LetterMech.FRAG_W / 2f - 10f
            val my = m.b.y - 30f
            path.reset(); path.moveTo(mx - 4f, my + 10f); path.lineTo(mx, my); path.lineTo(mx + 3f, my + 9f); path.lineTo(mx + 7f, my - 1f)
            line.strokeWidth = 1.5f; line.color = ink
            c.drawPath(path, line)
            c.drawRect(mx - 5f, my + 18f, mx + 6f, my + 28f, line)
            if (m.marksShown >= 3) {
                ln(c, mx, my + 36f, mx, my + 62f, 2.2f, 0xFF2A2A2A.toInt())
                circ(c, mx - 6f, my + 50f, 1.4f, alpha(0xFFFFFFFF.toInt(), 0.6f))
            } else {
                // un hueco en el papel donde estará la tercera marca (grafito en el otro mundo)
                ring(c, mx, my + 49f, 6f, 0.8f, alpha(ink, 0.25f))
            }
        }
        // espejo: cambiar de mundo manteniendo las hojas donde están
        if (m.canToggleWorld) {
            circ(c, 296f, 22f, 12f, alpha(paper, 0.9f))
            ring(c, 296f, 22f, 12f, 1.4f, ink)
            ln(c, 290f, 28f, 302f, 16f, 1f, alpha(ink, 0.5f))
            label(c, if (m.seeingTrauma) "T" else "N", 296f, 25f, 7f, ink)
        }
        // frase reconstruida
        if (m.solved) {
            val k = m.phraseReveal
            rect(c, 30f, 118f, 290f, 154f, alpha(0xFF000000.toInt(), 0.55f * k))
            label(c, "Mira desde donde la casa", 160f, 132f, 7f, alpha(0xFFFFF6DC.toInt(), k))
            label(c, "no debería tener ventanas", 160f, 144f, 7f, alpha(0xFFFFF6DC.toInt(), k))
        } else if (m.worldsSeen > 0 && m.aligned) {
            label(c, "mundos vistos: " + m.worldsSeen + "/2", 160f, 172f, 5f, alpha(ink, 0.8f))
        }
        if (err > 60f) label(c, "desliza las hojas · toca para girarlas", 160f, 172f, 5f, alpha(ink, 0.6f))
    }
}
