package com.terror2d.audio

import com.terror2d.core.WorldMode

/**
 * API de audio de ALTO NIVEL de MYMom (v0.7). La lógica de juego pide EVENTOS de audio ("suena la voz de la rana con esta
 * emoción", "pasos sobre madera") y no sabe nada de síntesis. Quien implementa el puerto es [AudioEngine] (síntesis
 * procedural en tiempo real) o [NullAudioPort] (silencio: tests, equipos sin audio).
 *
 * Todas las llamadas son baratas y NO bloquean: solo dejan una orden en una cola que consume el hilo de audio.
 */

/** Quién habla. DOCTOR, NEIGHBOR y MONSTER están preparados (perfil registrado) pero todavía no se usan en 0.7. */
enum class VoiceId { CHILD, MOTHER, FROG, DOCTOR, NEIGHBOR, MONSTER }

/** Emoción de una voz: modula tono, ritmo, respiración y vibrato. */
enum class Emotion { NEUTRAL, SOFT, WARM, HAPPY, WORRIED, SAD, TENSE, TIRED, CALM }

/** Forma del sonido vocal: balbuceo de sílabas no lingüísticas, un "mmm" largo o un "hm" corto. */
enum class VoiceKind { BABBLE, HUM, HM }

/** Efectos de sonido procedurales. */
enum class SfxId {
    FOOTSTEP, PICKUP, DROP, INTERACT, DOCUMENT_OPEN, PAPER, GLASS, WATER, MEDICINE,
    DOOR_OPEN, DOOR_CLOSE, BREATH, THUD, CLICK, HEARTBEAT, CLOTH, PLUSH_TAP, TEXT_TICK, CHIME,
    // v0.8: la criatura (todo procedural; el AudioDirector/CreatureAudio deciden cuándo suena cada cosa)
    CREATURE_BREATH, CREATURE_STEP, CREATURE_ARM, CREATURE_WET, CREATURE_MOUTH, CREATURE_GROWL,
    CREATURE_ALERT, CREATURE_CHASE, CREATURE_LOST, CREATURE_CAPTURE,
    // v0.9: la noche en que mamá desaparece
    MOM_SCREAM, WINDOW_CRASH, BED_CLIMB, BED_SETTLE, CREATURE_REVEAL,
    // v0.10: survival. Respiración por estado, pasos lejanos (a través de paredes), ventana, armario, foco, screamer, casa
    CREATURE_BREATH_SEARCH, CREATURE_BREATH_CHASE, CREATURE_SNIFF, CREATURE_STEP_FAR, CREATURE_BREATH_FAR,
    WINDOW_CLIMB, CLOSET_CREAK, CLOSET_DOOR, LIGHT_BREAK, LIGHT_FLICKER,
    SCREAM_IMPACT, SCREAM_ROAR, SCREAM_GRAB, SCREAM_FINAL, FAR_CREAK, FAR_THUD,
    // Capítulo I: micro-sustos (sonidos pequeños y dudosos, nunca la señal de ataque de la criatura) y ambiente de deterioro
    MS_KNOCK, MS_SCRAPE, MS_PENCIL, MS_TINKLE, MS_DRIP, MS_DRIP_LONG, MS_WHISPER, MS_VOICE_CLICK, MS_SOB, MS_MURMUR,
    MS_HOLLOW, MS_HUM_CUT, MS_RUSTLE, PUZZLE_SOLVED, PUZZLE_WRONG, MIRROR_SWITCH,
    // v0.15: sonidos propios de los mecanismos de los puzles (siempre más suaves y secos que un micro-susto)
    MECH_CERAMIC, MECH_WOOD_SLIDE, MECH_WOOD_CLICK, MECH_METAL_CLINK, MECH_ZAP, MECH_PIPE, MECH_RESONANCE,
    MECH_MUFFLED, MECH_HOOK, MECH_CLOCK_TICK, MECH_PAPER_FLEX, MECH_STONE_DRAG, MECH_DEEP_THUMP
}

/** Superficie sobre la que suenan los pasos. HOSPITAL está preparada aunque no se use todavía. */
enum class Surface { WOOD, TILE, GROUND, HOSPITAL }

/** Piezas / estados de música. SILENCE = silencio dinámico (solo queda el murmullo de la casa). */
enum class MusicId { SILENCE, HOME, CHILD_THEME, FROG_SCENE, TENSION }

/** Perfiles de ambiente (qué canales de la casa están presentes). */
enum class AmbienceId {
    SILENT, HOUSE, CONVERSATION,

    /** v0.9: la casa con la tormenta oída a lo lejos, a través de las paredes. */
    STORM_FAR,

    /** v0.9: en la habitación con la ventana rota: lluvia, viento, goteo y cortina. */
    STORM
}

interface AudioPort {
    /** Una frase vocal. [units] = sílabas (BABBLE) o décimas de segundo x2.5 (HUM); [seed] varía el balbuceo. */
    fun playVoice(voice: VoiceId, emotion: Emotion, intensity: Float, kind: VoiceKind = VoiceKind.BABBLE, units: Int = 3, seed: Int = 0)

    fun playSfx(sfx: SfxId, intensity: Float = 1f, surface: Surface = Surface.WOOD)

    fun playMusic(music: MusicId, fadeSeconds: Float = 2f)

    fun setAmbience(ambience: AmbienceId, fadeSeconds: Float = 2f)

    /** NORMAL y TRAUMA comparten los mismos eventos con parámetros distintos (tono, reverb, distorsión, resonancia). */
    fun setWorld(mode: WorldMode)

    /** Baja temporalmente música y ambiente (escenas de conversación). 1 = sin bajar. */
    fun duck(level: Float, seconds: Float)

    fun stopAll()
}

/** Puerto vacío: no suena nada. */
object NullAudioPort : AudioPort {
    override fun playVoice(voice: VoiceId, emotion: Emotion, intensity: Float, kind: VoiceKind, units: Int, seed: Int) {}
    override fun playSfx(sfx: SfxId, intensity: Float, surface: Surface) {}
    override fun playMusic(music: MusicId, fadeSeconds: Float) {}
    override fun setAmbience(ambience: AmbienceId, fadeSeconds: Float) {}
    override fun setWorld(mode: WorldMode) {}
    override fun duck(level: Float, seconds: Float) {}
    override fun stopAll() {}
}
