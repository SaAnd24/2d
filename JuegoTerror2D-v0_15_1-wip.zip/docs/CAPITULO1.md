# MYMom — Capítulo I: la casa de los dos mundos (v0.14.0 + rediseño artesanal EN CURSO, 11 de 15 puzles)

> **Estado real**: NO se ha compilado ni ejecutado nada (este entorno no tiene Gradle/Android SDK). Ninguna posición en
> pantalla está verificada. Tests escritos pero sin ejecutar. Compila primero y revisa coordenadas en `ChapterHouse.kt`.

## Mapa definitivo (19 segmentos, 20 zonas lógicas; `scene/ChapterHouse.kt`)
**Cada planta es UN solo pasillo** con las habitaciones colgando de él. Puertas reales (la criatura las usa); ★ = paso secreto de un puzle.
**Se eliminaron TODAS las ventanas-atajo** (`WindowPassage`) de la casa de pruebas.

```
SEGUNDO PISO  Pasillo (Hall): Kid 70 · Bath 200 · Mom 330 · Closet 460 · Study 590 (cerrada) · ESCALERA 720 · TRAMPILLA 900
              Closet ★C2★ Study (pared compartida)
PLANTA BAJA   Pasillo único (segmento Foyer, 980 px): puerta principal 50 · ESCALERA ARRIBA 170 · Living 330 · Dining 460 ·
              Kitchen 590 · Baño de servicio 720 · puerta trasera (cerrada) 800 · ESCALERA DE SERVICIO ABAJO 900
              (izquierda = vestíbulo, derecha = pasillo de servicio). Kitchen ─ Pantry. Living ★C1★ Pantry.
SÓTANO        Desembarco (Cellar): escalera arriba 24 · Laundry 420 · Electric 490 · Boiler 560 · Storage 630
              Storage: hueco bajo los cimientos al fondo (muro ★T4)
AZOTEA        Roof (por la trampilla del pasillo)
ESPECIAL      Closet ★C5 ▶ Impossible ─▶ pasillo de planta baja ─▶ puerta principal ─▶ «Fin del capítulo I»
```
**Escaleras y trampillas**: el niño interactúa con LA ESCALERA (BAJAR / SUBIR) tocando su dibujo, no con una puerta
al lado. Por debajo hay una `Door` invisible y no usable por el niño (`playerUsable=false`) que solo existe como conector de la
criatura; el niño usa `stairSpot`, que activa esa puerta y hace la misma transición. Pasillo 2º piso (720) ⇄ planta baja (170);
planta baja (900) ⇄ sótano (24); trampilla del pasillo (900) ⇄ azotea (escalera de mano).

## Lógica de puzles (revisada)
Cadena: N1 lámina · N2 (necesita leer D03 en la cocina) carta A · N3→N4→llave→N5 (pistas de luces: vestíbulo, cocina, pasillo,
sótano; cada una tiene su punto de examen) · T1..T5 · C1 (N1+T1+observar en TRAUMA) · C2 (T2+T3+observar) · C3 (ver abajo) ·
C4 (carta A+B) · C5 (N5,T5,C1,arandela,C4 + luz del distribuidor vista en NORMAL desde la azotea).
**C3**: llenar vaso en cocina (queda en las manos) → subir andando → dejarlo en el lavabo del baño familiar → observar en NORMAL y
en TRAUMA (`obs_c3_*`) → T4 abre el hueco → panel correcto en el hueco del almacén → arandela.

## Qué cambió (archivos)
`scene/ChapterHouse.kt` (reescrito), `world/ChapterProps.kt` (nuevo: mobiliario y animaciones), `chapter/*` (flags del vaso, N2
requiere D03, C3, textos de C5), `scene/Scene.kt` (NarrativeAware antes de reunir sólidos; frase «Esta pastilla sabe feo» añadida al
mensaje de fin de la medicina), `render/WorldRenderer.kt` (`animTime`), `ChapterDirector` (refresca objetos de historia en cada hito).

## Arte y animación añadidos
Sofá, sillón, mesa de centro, televisor, bañera, toallero, estantes de despensa, escaleras, cubo y fregona, escritorio, ladrillo
de caldera con manómetro, caja de fusibles, tuberías, válvulas, herramientas, tanque, chimenea, antena con tres brazos y base,
parapeto, ventana imposible. Animaciones: cortinas mecidas (`SwayProp`), abrigos, papeles que tiemblan, tuberías que vibran,
goteo por fotogramas (`FramesProp`). Los seis estados visuales siguen siendo capas sobre este mismo mapa.

## Conservado
15 puzles (soluciones y piezas iguales; solo cambian dependencias de N2 y C3), 22 documentos, espejo, micro-sustos, seis estados.

## SIN verificar / pendiente
- Compilación y tests; coordenadas de puertas/objetos (solapes visuales en Hall, Kitchen y Cellar ampliadas).
- Navegación de la criatura por escaleras y pasillos nuevos (reutiliza conectores existentes; no probado).
- Variantes TRAUMA deformadas de los muebles nuevos: hoy solo filtro de grises + grietas + los niveles de `ChapterRenderer`.
- Inspección cercana específica de los objetos nuevos y animación propia de colocar el vaso / manipular antena: NO hechas.
- La intro original (agua para mamá, etc.) ahora exige caminar por Foyer→Living→Dining→Kitchen: revisar su ritmo.


---

## v0.15 (en curso) — puzles artesanales y selección de documentos

> **Estado real**: escrito SIN compilar ni ejecutar nada (no hay Kotlin/Gradle en el entorno de trabajo). Los tests de
> `MechanismTest.kt` están escritos pero NO ejecutados. Compila primero y corrige lo que salga.

### Arquitectura nueva (`chapter/mech/`)
`Mechanism` (lógica pura: dedo en coordenadas 320x180, `tick`, `solved`, pistas `assist` 0..3, sonidos propios) +
`MechRegistry` (qué puzle usa qué mecanismo) + `render/MechRenderer.kt` (una vista distinta por mecanismo).
`ChapterDirector` conserva las instancias en un mapa: el estado sobrevive a cerrar la vista, cambiar de mundo o ser
capturado. Los puzles aún no migrados siguen usando el panel clásico (`PuzzlePanel`) hasta que se rehagan.
Sin botón PROBAR: el éxito ocurre cuando se cumplen las condiciones físicas. Sonidos nuevos `SfxId.MECH_*` (sintetizados).

### Identidad jugable de los puzles hechos (11)
- **N1** arrastrar taza, plato y silla pequeña sobre la mesa; anillos de polvo y muescas del borde; manchas señuelo; se abre la hendidura.
- **N2** cordón de cortina, varilla de lamas y reloj (gesto circular o ◀ ▶); el rayo cae en (hora, lamas); tres marcas = tres fases de D03 en orden, sostenidas 0,8 s.
- **N3** cuatro hojas arrastrables y girables; los trazos de los bordes deben continuarse en fila; sombras B<A<C<D.
- **N4** inclinar marcos arrastrando (o ◀ ▶); la sombra debe caer sobre la marca de lápiz; cada gancho se asienta; el revestimiento se desplaza.
- **N5** cables de cobre arrastrables hasta terminales con pictograma; pulso viajero, chisporroteo si es incompatible, lo correcto se queda.
- **T1** golpear marcas largas (golpe) y evitar las cortas (espera) con intervalos del patrón; mantener = resonancia; eco amortiguado y reproducción de referencia al fallar (oreja arriba a la derecha).
- **T2** piezas de madera sobre el retrato (arrastrar, tocar para girar); contornos blancos que se afinan; la pieza equivocada tapa el borde; símbolo de tres líneas y un punto.
- **T4** cuatro válvulas con 12 detentes (gesto circular o ◀ ▶); ritmos callada/continua/dos golpes/incompleta con figuras de referencia, manómetro; válvula acertada se traba.
- **T5** antena de tres brazos articulados en cadena; la sombra de cada punta debe llegar a su silueta (ventana, línea quebrada, torre); cambiar un brazo mueve los siguientes.
- **C1** lámina de latón sobre la pared: se atasca en juntas verdaderas, mantener pulsado acciona; orden alta → baja → media; el revestimiento se abre.
- **C4** dos fragmentos deslizables/girables; fibras y palabras de la unión; marcas del margen según mundo visto (espejo de la esquina); frase final.

### Documentos (parte II)
Zona de interacción propia (≥44 px + 14 px de margen), prioridad 10 (puzles 8, decoración 0), botón «LEER — título».
Si hay varios objetivos al alcance, selector arriba al centro («‹ n/m › otro objetivo»); tocarlo cambia de objetivo.

### PENDIENTE (honesto)
- **T3, C2, C3, C5** NO están rehechos: siguen con el panel clásico. Son espaciales y piden cambios de mapa y de escena
  (pasillo con grietas continuas, caja empujable, vaso con reflejos entre plantas, antena + espejo en la azotea).
- C4 cambia de mundo SOLO de forma visual dentro de la inspección (no recarga el segmento).
- No se auditó la colocación de cada documento (parte II, 9 y 10): solo se agrandaron zonas y prioridades.
- Los micro-sustos no se han tocado: no se verificó que no tapen sonidos de mecanismos.
- Tests existentes que miren anchos de zonas de documentos o `PuzzlePanel` podrían necesitar ajuste.
