# MYMom — Capítulo I: la casa de los dos mundos (v0.14.0, escaleras interactuables)

> **Estado real**: NO se ha compilado ni ejecutado nada (este entorno no tiene Gradle/Android SDK). Ninguna posición en
> pantalla está verificada. Tests escritos pero sin ejecutar. Compila primero y revisa coordenadas en `ChapterHouse.kt`.

## Mapa definitivo (19 segmentos, 20 zonas lógicas; `scene/ChapterHouse.kt`)
**Cada planta es UN solo pasillo** con las habitaciones colgando de él. Puertas reales (la criatura las usa); ★ = paso secreto de un puzle.
**Se eliminaron TODAS las ventanas-atajo** (`WindowPassage`) de la casa de pruebas.

```
SEGUNDO PISO  Pasillo (Hall): Kid 70 · Bath 200 · Mom 330 · Closet 460 · Study 590 (cerrada) · ESCALERA 720 · TRAMPILLA 900
              Closet ★C2★ Study (pared compartida)
PLANTA BAJA   Pasillo único (segmento Foyer, 980 px): puerta principal 50 · ESCALERA ARRIBA 170 · Living 330 · Dining 460 ·
              Kitchen 590 · Baño de servicio 720 · puerta trasera (cerrada) 800 · ESCALERA DE SERVICIO ABAJO 900
              (izquierda = vestíbulo, derecha = pasillo de servicio). Kitchen ─ Pantry. Living ★C1★ Pantry.
SÓTANO        Desembarco (Cellar): escalera arriba 24 · Laundry 420 · Electric 490 · Boiler 560 · Storage 630
              Storage: hueco bajo los cimientos al fondo (muro ★T4)
AZOTEA        Roof (por la trampilla del pasillo)
ESPECIAL      Closet ★C5 ▶ Impossible ─▶ pasillo de planta baja ─▶ puerta principal ─▶ «Fin del capítulo I»
```
**Escaleras y trampillas**: el niño interactúa con LA ESCALERA (BAJAR / SUBIR) tocando su dibujo, no con una puerta
al lado. Por debajo hay una `Door` invisible y no usable por el niño (`playerUsable=false`) que solo existe como conector de la
criatura; el niño usa `stairSpot`, que activa esa puerta y hace la misma transición. Pasillo 2º piso (720) ⇄ planta baja (170);
planta baja (900) ⇄ sótano (24); trampilla del pasillo (900) ⇄ azotea (escalera de mano).

## Lógica de puzles (revisada)
Cadena: N1 lámina · N2 (necesita leer D03 en la cocina) carta A · N3→N4→llave→N5 (pistas de luces: vestíbulo, cocina, pasillo,
sótano; cada una tiene su punto de examen) · T1..T5 · C1 (N1+T1+observar en TRAUMA) · C2 (T2+T3+observar) · C3 (ver abajo) ·
C4 (carta A+B) · C5 (N5,T5,C1,arandela,C4 + luz del distribuidor vista en NORMAL desde la azotea).
**C3**: llenar vaso en cocina (queda en las manos) → subir andando → dejarlo en el lavabo del baño familiar → observar en NORMAL y
en TRAUMA (`obs_c3_*`) → T4 abre el hueco → panel correcto en el hueco del almacén → arandela.

## Qué cambió (archivos)
`scene/ChapterHouse.kt` (reescrito), `world/ChapterProps.kt` (nuevo: mobiliario y animaciones), `chapter/*` (flags del vaso, N2
requiere D03, C3, textos de C5), `scene/Scene.kt` (NarrativeAware antes de reunir sólidos; frase «Esta pastilla sabe feo» añadida al
mensaje de fin de la medicina), `render/WorldRenderer.kt` (`animTime`), `ChapterDirector` (refresca objetos de historia en cada hito).

## Arte y animación añadidos
Sofá, sillón, mesa de centro, televisor, bañera, toallero, estantes de despensa, escaleras, cubo y fregona, escritorio, ladrillo
de caldera con manómetro, caja de fusibles, tuberías, válvulas, herramientas, tanque, chimenea, antena con tres brazos y base,
parapeto, ventana imposible. Animaciones: cortinas mecidas (`SwayProp`), abrigos, papeles que tiemblan, tuberías que vibran,
goteo por fotogramas (`FramesProp`). Los seis estados visuales siguen siendo capas sobre este mismo mapa.

## Conservado
15 puzles (soluciones y piezas iguales; solo cambian dependencias de N2 y C3), 22 documentos, espejo, micro-sustos, seis estados.

## SIN verificar / pendiente
- Compilación y tests; coordenadas de puertas/objetos (solapes visuales en Hall, Kitchen y Cellar ampliadas).
- Navegación de la criatura por escaleras y pasillos nuevos (reutiliza conectores existentes; no probado).
- Variantes TRAUMA deformadas de los muebles nuevos: hoy solo filtro de grises + grietas + los niveles de `ChapterRenderer`.
- Inspección cercana específica de los objetos nuevos y animación propia de colocar el vaso / manipular antena: NO hechas.
- La intro original (agua para mamá, etc.) ahora exige caminar por Foyer→Living→Dining→Kitchen: revisar su ritmo.
