package com.terror2d.scene

import com.terror2d.core.CameraMode
import com.terror2d.events.EventTrigger
import com.terror2d.events.EventType
import com.terror2d.render.Palette
import com.terror2d.world.Chair
import com.terror2d.world.DarkZone
import com.terror2d.world.Doodle
import com.terror2d.world.Door
import com.terror2d.world.DoorTarget
import com.terror2d.world.ExamineSpot
import com.terror2d.world.Lamp
import com.terror2d.world.LightSource
import com.terror2d.world.LightSwitch
import com.terror2d.world.LightType
import com.terror2d.world.PictureFrame
import com.terror2d.world.Prop
import com.terror2d.world.Rug
import com.terror2d.world.Shelf
import com.terror2d.world.ToyBox
import com.terror2d.world.Wardrobe
import com.terror2d.world.WardrobeDeco
import com.terror2d.world.WardrobeStyle
import com.terror2d.world.WorldObject

/**
 * Casa de prueba de v0.3: CUATRO habitaciones técnicas (RoomA..RoomD), conectadas A <-> B <-> C <-> D.
 * NO son las habitaciones de la historia: sirven para probar cámara, oscuridad, puertas,
 * interacción y escondites.
 *
 *   RoomA (320, FIXED)          cálida y acogedora
 *   RoomB (320, FIXED)          fría, más zonas oscuras
 *   RoomC (560, SIDE_SCROLLING) más grande, varias luces e interruptor
 *   RoomD (420, SIDE_SCROLLING) la más oscura: una lámpara aislada y una puerta bloqueada
 *
 * Todas las posiciones son literales: ninguna usa aleatoriedad (la semilla solo afecta al trazo
 * y a pequeños detalles de decoración).
 *
 * Composición de cada habitación: lámpara -> zona iluminada -> objetos -> jugador -> zona oscura -> puerta.
 */
object TestRoomDefinition {
    const val ID = "test_room"

    const val ROOM_A = "RoomA"
    const val ROOM_B = "RoomB"
    const val ROOM_C = "RoomC"
    const val ROOM_D = "RoomD"

    // Compatibilidad con v0.2 (los dos primeros segmentos conservan su nombre de constante).
    const val SEGMENT_A = ROOM_A
    const val SEGMENT_B = ROOM_B

    const val DOOR_A_TO_B = "door_a_to_b"
    const val DOOR_B_TO_A = "door_b_to_a"
    const val DOOR_B_TO_C = "door_b_to_c"
    const val DOOR_C_TO_B = "door_c_to_b"
    const val DOOR_C_TO_D = "door_c_to_d"
    const val DOOR_D_TO_C = "door_d_to_c"
    const val DOOR_D_LOCKED = "door_d_locked"

    const val WARDROBE_A = "wardrobe_a"
    const val WARDROBE_B = "wardrobe_b"
    const val WARDROBE_C = "wardrobe_c"
    const val WARDROBE_D = "wardrobe_d"

    const val SWITCH_C = "switch_c"

    const val DEFAULT_SEED = 20260101L

    /** Suelo común: el personaje (48 px) y las puertas (76 px) se leen bien en 180 px de alto. */
    const val FLOOR_Y = 146f
    const val WIDTH_A = 320f
    const val WIDTH_B = 320f
    const val WIDTH_C = 560f
    const val WIDTH_D = 420f
    private const val WALL = 12f // grosor de los muros laterales

    private val WARM = Palette.LIGHT_WARM or 0xFF000000.toInt()
    private val COLD = Palette.LIGHT_COLD or 0xFF000000.toInt()
    private val PALE = Palette.LIGHT_PALE or 0xFF000000.toInt()

    /** Crea objetos NUEVOS en cada llamada (cada carga de escena parte limpia). */
    fun create(seed: Long = DEFAULT_SEED): SceneDefinition =
        SceneDefinition(
            id = ID,
            seed = seed,
            segments = listOf(roomA(), roomB(), roomC(), roomD()),
            startSegmentId = ROOM_A,
            startSpawnId = "start",
            triggers = listOf(
                // Prueba del sistema de eventos: la primera vez que se entra en RoomD aparece un texto.
                EventTrigger(EventType.ON_ENTER_ROOM, ROOM_D, once = true) { ctx ->
                    ctx.dialogue.showMessage("Aquí dentro está muy oscuro.")
                }
            )
        )

    // ------------------------------------------------------------------------------------------
    // RoomA — cálida, acogedora, cámara fija (cabe entera en pantalla)
    // ------------------------------------------------------------------------------------------
    private fun roomA(): RoomSegment {
        val objects = ArrayList<WorldObject>()
        val lamp = Lamp(132f, 34f, radius = 128f, intensity = 1f, color = WARM)
        objects.add(Rug(88f, FLOOR_Y - 6f, 112f, 6f))
        objects.add(Doodle(210f, 36f, 36f))                               // dibujo infantil en la pared
        objects.add(PictureFrame(150f, 40f, 40f, 32f))
        objects.add(lamp)
        objects.add(Wardrobe(
            WARDROBE_A, 28f, FLOOR_Y,
            WardrobeStyle(
                Palette.WARDROBE_WARM_BODY, Palette.WARDROBE_WARM_HATCH, Palette.WARDROBE_WARM_DOOR,
                Palette.WARDROBE_TRIM, doorCount = 2, deco = WardrobeDeco.STAR
            )
        ))
        objects.add(Chair(104f, FLOOR_Y))
        objects.add(ToyBox(168f, FLOOR_Y))
        objects.add(ExamineSpot("examine_a_chair", 104f, FLOOR_Y - 34f, 24f, 34f, "Una silla de madera."))
        objects.add(ExamineSpot("examine_a_toybox", 168f, FLOOR_Y - 32f, 34f, 32f, "Una caja de juguetes."))

        val door = Door(DOOR_A_TO_B, 264f, FLOOR_Y, target = DoorTarget(ROOM_B, "from_a"))
        val sconce = LightSource(281f, 70f, 56f, WARM, 0.5f, LightType.LAMP)   // luz tenue junto a la puerta

        return RoomSegment(
            id = ROOM_A,
            width = WIDTH_A,
            floorY = FLOOR_Y,
            leftBoundary = WALL,
            rightBoundary = WIDTH_A - WALL,
            cameraMode = CameraMode.FIXED,
            objects = objects,
            doors = listOf(door),
            spawnPoints = mapOf(
                "start" to SpawnPoint(146f, 1),
                "from_b" to SpawnPoint(236f, -1)
            ),
            lights = listOf(lamp.light, sconce),
            darkZones = emptyList(),
            ambientDark = 0.80f,
            ambientColor = Palette.DARK_WARM,
            wallColor = Palette.WALL_A,
            wallStrokeColor = Palette.WALL_A_STROKE
        )
    }

    // ------------------------------------------------------------------------------------------
    // RoomB — fría, más zonas oscuras, composición inquietante, cámara fija
    // ------------------------------------------------------------------------------------------
    private fun roomB(): RoomSegment {
        val objects = ArrayList<WorldObject>()
        val lamp = Lamp(214f, 44f, radius = 104f, intensity = 0.95f, color = COLD, flicker = 0.05f)
        objects.add(Doodle(78f, 30f, 44f))
        objects.add(PictureFrame(112f, 34f, 34f, 42f))
        objects.add(Shelf(250f, 64f, 30f))
        objects.add(lamp)
        objects.add(Wardrobe(
            WARDROBE_B, 156f, FLOOR_Y,
            WardrobeStyle(
                Palette.WARDROBE_COLD_BODY, Palette.WARDROBE_COLD_HATCH, Palette.WARDROBE_COLD_DOOR,
                Palette.WARDROBE_TRIM, doorCount = 1, deco = WardrobeDeco.STRIPES
            )
        ))
        objects.add(Chair(96f, FLOOR_Y))
        objects.add(ExamineSpot("examine_b_picture", 112f, 34f, 34f, 42f, "Un dibujo torcido.", margin = 0f))

        val doorBack = Door(DOOR_B_TO_A, 22f, FLOOR_Y, target = DoorTarget(ROOM_A, "from_b"))
        val doorNext = Door(DOOR_B_TO_C, 264f, FLOOR_Y, target = DoorTarget(ROOM_C, "from_b"))

        return RoomSegment(
            id = ROOM_B,
            width = WIDTH_B,
            floorY = FLOOR_Y,
            leftBoundary = WALL,
            rightBoundary = WIDTH_B - WALL,
            cameraMode = CameraMode.FIXED,
            objects = objects,
            doors = listOf(doorBack, doorNext),
            spawnPoints = mapOf(
                "from_a" to SpawnPoint(78f, 1),
                "from_c" to SpawnPoint(236f, -1)
            ),
            lights = listOf(lamp.light),
            darkZones = listOf(
                DarkZone(WALL, 0f, 74f, FLOOR_Y, 0.45f),
                DarkZone(254f, 0f, 54f, FLOOR_Y, 0.45f)
            ),
            ambientDark = 0.88f,
            ambientColor = Palette.DARK_COLD,
            wallColor = Palette.WALL_B,
            wallStrokeColor = Palette.WALL_B_STROKE
        )
    }

    // ------------------------------------------------------------------------------------------
    // RoomC — más grande, SIDE_SCROLLING, varias fuentes de luz e interruptor
    // ------------------------------------------------------------------------------------------
    private fun roomC(): RoomSegment {
        val objects = ArrayList<WorldObject>()
        val lamp1 = Lamp(116f, 36f, radius = 104f, intensity = 0.95f, color = WARM)
        val lamp2 = Lamp(300f, 40f, radius = 118f, intensity = 1f, color = PALE)
        val lamp3 = Lamp(472f, 34f, radius = 96f, intensity = 0.9f, color = WARM)
        objects.add(Rug(246f, FLOOR_Y - 6f, 130f, 6f))
        objects.add(Doodle(176f, 34f, 38f))
        objects.add(PictureFrame(380f, 44f, 40f, 30f))
        objects.add(Shelf(430f, 66f, 30f))
        objects.add(lamp1)
        objects.add(lamp2)
        objects.add(lamp3)
        objects.add(Chair(148f, FLOOR_Y))
        objects.add(ToyBox(206f, FLOOR_Y))
        objects.add(Prop(420f, FLOOR_Y - 18f, 26f, 18f, Palette.GREEN_FILL, Palette.GREEN_HATCH))
        objects.add(Wardrobe(
            WARDROBE_C, 322f, FLOOR_Y,
            WardrobeStyle(
                Palette.WARDROBE_GREEN_BODY, Palette.WARDROBE_GREEN_HATCH, Palette.WARDROBE_GREEN_DOOR,
                Palette.WARDROBE_TRIM, doorCount = 2, deco = WardrobeDeco.NONE
            )
        ))
        objects.add(LightSwitch(SWITCH_C, 262f, 62f, lamp2.light))
        objects.add(ExamineSpot("examine_c_chair", 148f, FLOOR_Y - 34f, 24f, 34f, "Otra silla de madera."))

        val doorBack = Door(DOOR_C_TO_B, 22f, FLOOR_Y, target = DoorTarget(ROOM_B, "from_c"))
        val doorNext = Door(DOOR_C_TO_D, 508f, FLOOR_Y, target = DoorTarget(ROOM_D, "from_c"))

        return RoomSegment(
            id = ROOM_C,
            width = WIDTH_C,
            floorY = FLOOR_Y,
            leftBoundary = WALL,
            rightBoundary = WIDTH_C - WALL,
            cameraMode = CameraMode.SIDE_SCROLLING,
            objects = objects,
            doors = listOf(doorBack, doorNext),
            spawnPoints = mapOf(
                "from_b" to SpawnPoint(78f, 1),
                "from_d" to SpawnPoint(480f, -1)
            ),
            lights = listOf(lamp1.light, lamp2.light, lamp3.light),
            darkZones = listOf(DarkZone(WALL, 0f, 64f, FLOOR_Y, 0.4f)),
            ambientDark = 0.88f,
            ambientColor = Palette.DARK_ZONE,
            wallColor = Palette.WALL_A,
            wallStrokeColor = Palette.WALL_A_STROKE
        )
    }

    // ------------------------------------------------------------------------------------------
    // RoomD — la más oscura: lámpara aislada, gran zona de sombra, puerta bloqueada
    // ------------------------------------------------------------------------------------------
    private fun roomD(): RoomSegment {
        val objects = ArrayList<WorldObject>()
        val lamp = Lamp(202f, 50f, radius = 88f, intensity = 0.95f, color = WARM, flicker = 0.06f)
        objects.add(Doodle(96f, 40f, 40f))
        objects.add(PictureFrame(142f, 44f, 34f, 28f))
        objects.add(lamp)
        objects.add(Wardrobe(
            WARDROBE_D, 240f, FLOOR_Y,
            WardrobeStyle(
                Palette.WARDROBE_PLUM_BODY, Palette.WARDROBE_PLUM_HATCH, Palette.WARDROBE_PLUM_DOOR,
                Palette.WARDROBE_TRIM, doorCount = 1, deco = WardrobeDeco.MOON
            )
        ))
        objects.add(Chair(158f, FLOOR_Y))

        val doorBack = Door(DOOR_D_TO_C, 22f, FLOOR_Y, target = DoorTarget(ROOM_C, "from_d"))
        val doorLocked = Door(DOOR_D_LOCKED, 366f, FLOOR_Y, locked = true)

        return RoomSegment(
            id = ROOM_D,
            width = WIDTH_D,
            floorY = FLOOR_Y,
            leftBoundary = WALL,
            rightBoundary = WIDTH_D - WALL,
            cameraMode = CameraMode.SIDE_SCROLLING,
            objects = objects,
            doors = listOf(doorBack, doorLocked),
            spawnPoints = mapOf("from_c" to SpawnPoint(78f, 1)),
            lights = listOf(lamp.light),
            darkZones = listOf(DarkZone(WALL, 0f, 110f, FLOOR_Y, 0.35f), DarkZone(300f, 0f, 108f, FLOOR_Y, 0.4f)),
            ambientDark = 0.94f,
            ambientColor = Palette.DARK_DEEP,
            wallColor = Palette.WALL_B,
            wallStrokeColor = Palette.WALL_B_STROKE
        )
    }
}
