package com.terror2d.scene

import com.terror2d.core.Camera
import com.terror2d.core.GameConfig
import com.terror2d.core.GameState
import com.terror2d.events.EventBus
import com.terror2d.events.EventListener
import com.terror2d.events.EventType
import com.terror2d.events.GameEvent
import com.terror2d.events.TriggerContext
import com.terror2d.input.InputAction
import com.terror2d.input.InputController
import com.terror2d.interaction.Interactable
import com.terror2d.interaction.InteractionContext
import com.terror2d.interaction.InteractionIcon
import com.terror2d.interaction.InteractionResult
import com.terror2d.render.BaseRenderer
import com.terror2d.render.Palette
import com.terror2d.ui.DialogueManager
import com.terror2d.util.SeededRandom
import com.terror2d.world.Layer
import com.terror2d.world.LightSource
import com.terror2d.world.LightType
import com.terror2d.world.Player
import com.terror2d.world.SketchBuilder
import com.terror2d.world.Wardrobe
import com.terror2d.world.WorldObject

/**
 * Escena base (vista LATERAL): contiene el segmento activo, jugador, cámara, colisiones y el
 * sistema de interacción. Una escena (p. ej. la casa) se compone de varios [RoomSegment]
 * conectados por puertas; solo uno está cargado a la vez.
 *
 * Interacción (v0.3): cada frame la escena busca el [Interactable] más cercano al jugador, publica su
 * acción en el botón (genérico) y, al pulsar, llama a executeInteraction() e interpreta el
 * [InteractionResult] (texto, transición...). No hay lógica por tipo de objeto.
 */
abstract class Scene(val definition: SceneDefinition) {

    val id: String get() = definition.id

    lateinit var currentSegment: RoomSegment
        private set
    val width: Float get() = currentSegment.width
    val height: Float get() = currentSegment.height

    val camera = Camera(GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat())
    lateinit var player: Player
        private set

    /** Bus de eventos de esta escena. */
    val events = EventBus()

    /** Texto del juego: mensajes breves y base de diálogos. */
    val dialogue = DialogueManager()

    /** Transición entre segmentos (puerta -> fundido -> carga -> fundido). */
    val transition = SceneTransition()

    /** Resplandor tenue alrededor del jugador (nunca se pierde del todo de vista en la oscuridad). */
    val playerGlow = LightSource(
        x = 0f, y = 0f,
        radius = PLAYER_GLOW_RADIUS,
        color = Palette.LIGHT_GLOW or 0xFF000000.toInt(),
        intensity = PLAYER_GLOW_INTENSITY,
        type = LightType.GLOW,
        tintStrength = 0f
    )

    /** Interactuable enfocado ahora mismo (el que mostraría el botón de acción). */
    var focused: Interactable? = null
        private set

    val transitionAlpha: Float get() = transition.fadeAlpha

    private var stateRef: GameState? = null
    private var interactionContext: InteractionContext? = null

    private val objects = ArrayList<WorldObject>()
    private val solids = ArrayList<WorldObject>()
    private val backObjects = ArrayList<WorldObject>()   // FLOOR / DECOR (detrás de todo)
    private val midObjects = ArrayList<WorldObject>()    // OBJECT (muebles, puertas)
    private val frontObjects = ArrayList<WorldObject>()  // FOREGROUND (delante del jugador)
    private val interactables = ArrayList<Interactable>()

    private var wallStrokes: FloatArray = WorldObject.EMPTY
    private var floorStrokes: FloatArray = WorldObject.EMPTY
    private var speckles: FloatArray = WorldObject.EMPTY

    init {
        events.subscribeAll(EventListener { e -> dispatch(e) })
    }

    fun load(state: GameState) {
        stateRef = state
        loadSegment(definition.startSegmentId, definition.startSpawnId, state)
    }

    /**
     * Carga un segmento y coloca al jugador en el spawn indicado (la transición con fundido la
     * gestiona [SceneTransition]; este método es la carga en sí).
     */
    fun loadSegment(segmentId: String, spawnId: String, state: GameState) {
        stateRef = state
        val ctx: InteractionContext = interactionContext?.takeIf { it.state === state }
            ?: InteractionContext(events, state).also { interactionContext = it }

        val seg = definition.segment(segmentId)
        currentSegment = seg
        focused = null
        dialogue.clear()

        objects.clear()
        solids.clear()
        backObjects.clear()
        midObjects.clear()
        frontObjects.clear()
        interactables.clear()

        // Todas las puertas y armarios vuelven a su estado inicial al cambiar de segmento.
        for (si in 0 until definition.segments.size) {
            val other = definition.segments[si]
            for (di in 0 until other.doors.size) other.doors[di].reset()
            for (oi in 0 until other.objects.size) {
                val o = other.objects[oi]
                if (o is Wardrobe) o.reset()
            }
        }
        objects.addAll(seg.objects)
        objects.addAll(seg.doors)

        // Imperfecciones visuales deterministas: dependen de la semilla de la escena, del índice
        // del segmento y del índice del objeto (nunca del orden de ejecución).
        val segIndex = definition.segments.indexOf(seg)
        val segSeed = SeededRandom.derive(definition.seed, SEGMENT_SALT + segIndex)
        for (i in 0 until objects.size) {
            objects[i].prepareVisuals(SeededRandom(SeededRandom.derive(segSeed, i + 1)))
        }
        val bgRng = SeededRandom(SeededRandom.derive(segSeed, BACKDROP_SALT))
        wallStrokes = SketchBuilder.buildVerticalHatch(0f, 0f, seg.width, seg.floorY, 7f, bgRng)
        floorStrokes = SketchBuilder.buildHatch(0f, seg.floorY, seg.width, seg.height - seg.floorY, 5f, bgRng)
        speckles = SketchBuilder.buildSpeckles(seg.width, seg.height, (seg.width * seg.height / 450f).toInt(), bgRng)

        for (i in 0 until objects.size) {
            val o = objects[i]
            if (o.collidable) solids.add(o)
            if (o is Interactable) interactables.add(o)
            when {
                o.layer < Layer.OBJECT -> backObjects.add(o)
                o.layer == Layer.OBJECT -> midObjects.add(o)
                else -> frontObjects.add(o)
            }
        }
        // Las luces de la habitación empiezan en su estado real (sin fundido desde apagado).
        for (i in 0 until seg.lights.size) seg.lights[i].update(10f)

        val sp = seg.spawn(spawnId)
        player = Player(sp.x - Player.WIDTH / 2f, seg.floorY - Player.HEIGHT)
        player.facing = if (sp.facing < 0) -1f else 1f
        camera.configure(seg.width, seg.height, seg.cameraMode)
        camera.snapTo(player.centerX)
        syncGlow()
        playerGlow.update(10f)

        ctx.player = player
        ctx.segment = seg

        state.currentSceneId = id
        state.currentSegmentId = seg.id
        state.playerX = player.x
        state.playerY = player.y
        state.playerHidden = false
        onLoad(state)

        events.post(EventType.ON_ENTER_ROOM, seg.id, seg.id)
    }

    open fun onLoad(state: GameState) {}

    open fun unload(state: GameState) {}

    /**
     * Orden: texto -> transición -> jugador -> objetos/luces -> enfoque -> acción -> cámara.
     * Con una transición o un diálogo en curso el jugador no se mueve.
     */
    open fun update(dt: Float, input: InputController, state: GameState) {
        dialogue.update(dt)

        if (transition.update(dt)) {
            val t = transition.target
            if (t != null) {
                loadSegment(t.segmentId, t.spawnId, state)
                input.actionEnabled = false
                return
            }
        }

        val seg = currentSegment
        val ctx = interactionContext ?: return
        ctx.time = state.elapsedTime
        val locked = transition.isActive || dialogue.blocksInput

        player.update(dt, if (locked) 0f else input.moveX, solids, seg.floorY, seg.leftBoundary, seg.rightBoundary)
        for (i in 0 until objects.size) objects[i].update(dt)
        for (i in 0 until seg.lights.size) seg.lights[i].update(dt)
        syncGlow()
        playerGlow.update(dt)

        // --- Enfoque: el interactuable más cercano al alcance ---
        focused = if (locked) null else findFocus(ctx)

        // --- Botón de acción (genérico: icono y texto vienen del interactuable) ---
        val f = focused
        if (dialogue.blocksInput) {
            input.actionEnabled = true
            input.actionIcon = InteractionIcon.NEXT
            input.actionLabel = "SEGUIR"
        } else if (f != null) {
            input.actionEnabled = true
            input.actionIcon = f.promptIcon
            input.actionLabel = f.promptText
        } else {
            input.actionEnabled = false
        }

        // --- Pulsación ---
        if (input.wasPressed(InputAction.INTERACT)) {
            if (dialogue.blocksInput) {
                dialogue.advance()
            } else if (f != null && !transition.isActive) {
                interact(f, ctx)
            }
        }

        camera.follow(player.centerX, dt)
        state.playerX = player.x
        state.playerY = player.y
        state.playerHidden = player.isHidden
    }

    /** Ejecuta un interactuable e interpreta el resultado. Público para poder probarlo. */
    fun interact(target: Interactable, ctx: InteractionContext) {
        val res = target.executeInteraction(ctx)
        applyResult(target, res, ctx)
    }

    private fun applyResult(target: Interactable, res: InteractionResult, ctx: InteractionContext) {
        if (!res.handled) return
        events.post(EventType.ON_INTERACT, target.interactionId, currentSegment.id)
        val msg = res.message
        if (msg != null) dialogue.showMessage(msg, res.speaker)
        val t = res.transition
        if (t != null) transition.start(t, res.transitionDoor)
    }

    /** Interactuable más cercano al que el jugador puede llegar y usar ahora. */
    private fun findFocus(ctx: InteractionContext): Interactable? {
        var best: Interactable? = null
        var bestDist = Float.MAX_VALUE
        val px = player.centerX
        val usable = player.state == com.terror2d.world.PlayerState.NORMAL
        for (i in 0 until interactables.size) {
            val cand = interactables[i]
            if (!usable && !cand.worksWhileHidden) continue
            if (!cand.isInRange(player)) continue
            if (!cand.canInteract(ctx)) continue
            val d = kotlin.math.abs((cand.zoneLeft + cand.zoneRight) * 0.5f - px)
            if (d < bestDist) {
                bestDist = d
                best = cand
            }
        }
        return best
    }

    private fun syncGlow() {
        playerGlow.x = player.centerX
        playerGlow.y = player.bottom - Player.HEIGHT * 0.55f
        playerGlow.active = player.visibilityAlpha > 0.5f
    }

    private fun dispatch(e: GameEvent) {
        val st = stateRef ?: return
        st.lastEvent = e.toString()
        val ts = definition.triggers
        for (i in 0 until ts.size) {
            val t = ts[i]
            if (t.matches(e)) t.fire(TriggerContext(e, dialogue, st))
        }
    }

    /**
     * Dibuja en coordenadas del mundo (la transformación de cámara ya está aplicada). Pipeline:
     * fondo -> decoración -> objetos -> jugador -> primer plano -> ILUMINACIÓN (máscara de oscuridad
     * abierta por las luces) -> marca de interacción (encima de la oscuridad, para poder encontrarla).
     */
    open fun render(r: BaseRenderer) {
        val seg = currentSegment
        r.drawBackdrop(seg, wallStrokes, floorStrokes, speckles)

        for (i in 0 until backObjects.size) {
            val o = backObjects[i]
            if (o.visible && camera.isVisible(o)) o.render(r)
        }
        for (i in 0 until midObjects.size) {
            val o = midObjects[i]
            if (o.visible && camera.isVisible(o)) o.render(r)
        }
        player.render(r)
        for (i in 0 until frontObjects.size) {
            val o = frontObjects[i]
            if (o.visible && camera.isVisible(o)) o.render(r)
        }

        r.drawLighting(seg, camera.snappedX, camera.snappedY, playerGlow)

        val f = focused
        if (f != null && !transition.isActive && !dialogue.blocksInput) r.drawInteractMarker(f.markerX, f.markerY)
    }

    /** Huella de todo el aspecto generado del segmento cargado: misma semilla => mismo valor (tests). */
    fun visualFingerprint(): Long {
        var h = 1125899906842597L
        h = WorldObject.hashFloats(h, wallStrokes)
        h = WorldObject.hashFloats(h, floorStrokes)
        h = WorldObject.hashFloats(h, speckles)
        for (i in 0 until objects.size) h = objects[i].visualHash(h)
        return h
    }

    companion object {
        private const val SEGMENT_SALT = 0x5E60
        private const val BACKDROP_SALT = 0x7F10

        const val PLAYER_GLOW_RADIUS = 36f
        const val PLAYER_GLOW_INTENSITY = 0.42f
    }
}
