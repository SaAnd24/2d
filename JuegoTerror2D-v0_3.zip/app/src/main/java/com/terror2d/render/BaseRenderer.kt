package com.terror2d.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.terror2d.core.GameConfig
import com.terror2d.input.InputAction
import com.terror2d.input.InputController
import com.terror2d.interaction.InteractionIcon
import com.terror2d.scene.RoomSegment
import com.terror2d.ui.DialogueManager
import com.terror2d.world.Door
import com.terror2d.world.LightSource
import com.terror2d.world.LightSwitch
import com.terror2d.world.Player
import com.terror2d.world.Wardrobe
import com.terror2d.world.WardrobePhase
import com.terror2d.world.WorldObject
import kotlin.math.min
import kotlin.math.round
import kotlin.math.sin

/**
 * Renderizador base (etapa crayón). Todo el dibujo del mundo pasa por aquí.
 * Futuro: CrayonRenderer, GraphiteRenderer, ShadowRenderer, DistortionRenderer y
 * ScratchRenderer pueden heredar o componerse sobre esta clase. La iluminación tiene su
 * propia pieza ([LightingRenderer]), integrada en el pipeline: mundo -> personaje -> luz/oscuridad.
 * No crea objetos en el bucle de dibujo (Paint/Path/RectF reutilizados).
 */
open class BaseRenderer {

    protected lateinit var canvas: Canvas
    protected var corruption: Float = 0f

    /** Segundos de juego (para animaciones puramente visuales: parpadeos, rebote de la marca). */
    protected var renderTime: Float = 0f

    protected val paint = Paint().apply {
        isAntiAlias = false
        isFilterBitmap = false
        isDither = false
        strokeCap = Paint.Cap.SQUARE
        strokeJoin = Paint.Join.MITER
    }

    private val textPaint = Paint().apply {
        isAntiAlias = true
        textSize = 7f
        typeface = Typeface.MONOSPACE
        color = Palette.OUTLINE
    }

    private val labelPaint = Paint().apply {
        isAntiAlias = true
        textSize = 6.5f
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        color = Palette.TEXT_INK
    }

    private val dialoguePaint = Paint().apply {
        isAntiAlias = true
        textSize = 8f
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        color = Palette.TEXT_INK
    }

    private val path = Path()
    private val oval = RectF()
    private val pill = RectF()
    protected val lighting = LightingRenderer()

    // Ajuste de texto en líneas (se recalcula solo cuando cambia la línea; sin allocations por frame)
    private val wrapStart = IntArray(MAX_WRAP_LINES)
    private val wrapEnd = IntArray(MAX_WRAP_LINES)
    private var wrapCount = 0
    private var wrapSerial = -1

    open fun beginFrame(canvas: Canvas, visualCorruption: Float, time: Float = 0f) {
        this.canvas = canvas
        this.corruption = visualCorruption
        this.renderTime = time
    }

    /**
     * Gancho de corrupción visual: 0.0 devuelve el color intacto.
     * Futuro: más saturación perdida, tintes, grafito...
     */
    protected open fun tint(c: Int): Int {
        val k = corruption
        if (k <= 0.001f) return c
        val a = (c ushr 24) and 0xFF
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        val gray = r * 0.30f + g * 0.59f + b * 0.11f
        val t = k * 0.85f
        val nr = (r + (gray - r) * t).toInt()
        val ng = (g + (gray - g) * t).toInt()
        val nb = (b + (gray - b) * t).toInt()
        return (a shl 24) or (nr shl 16) or (ng shl 8) or nb
    }

    private fun lerpColor(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        val ar = (a shr 16) and 0xFF
        val ag = (a shr 8) and 0xFF
        val ab = a and 0xFF
        val br = (b shr 16) and 0xFF
        val bg = (b shr 8) and 0xFF
        val bb = b and 0xFF
        val r = (ar + (br - ar) * k).toInt()
        val g = (ag + (bg - ag) * k).toInt()
        val bl = (ab + (bb - ab) * k).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
    }

    /** Fondo de papel (zona lógica completa, coordenadas de pantalla lógica). */
    open fun drawBackground() {
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.PAPER)
        canvas.drawRect(0f, 0f, GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat(), paint)
    }

    /**
     * Fondo del segmento lateral (coordenadas del mundo): pared de papel pintado a crayón,
     * sombra en el techo, rodapié, suelo de madera y muros laterales oscuros en los límites.
     */
    open fun drawBackdrop(seg: RoomSegment, wall: FloatArray, floor: FloatArray, speckles: FloatArray) {
        val w = seg.width
        val h = seg.height
        val fy = seg.floorY

        // Pared
        paint.style = Paint.Style.FILL
        paint.color = tint(seg.wallColor)
        canvas.drawRect(0f, 0f, w, fy, paint)
        drawStrokes(wall, seg.wallStrokeColor, 1.4f)

        // Sombra del techo (contraste): cuatro bandas translúcidas
        paint.style = Paint.Style.FILL
        paint.color = 0x22000000
        canvas.drawRect(0f, 0f, w, 8f, paint)
        canvas.drawRect(0f, 0f, w, 18f, paint)
        canvas.drawRect(0f, 0f, w, 32f, paint)
        canvas.drawRect(0f, 0f, w, 48f, paint)

        // Suelo
        paint.color = tint(seg.floorColor)
        canvas.drawRect(0f, fy, w, h, paint)
        drawStrokes(floor, seg.floorStrokeColor, 1.5f)

        // Rodapié y línea de suelo
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.SKIRTING)
        canvas.drawRect(0f, fy - 8f, w, fy, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.2f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawLine(0f, fy - 8f, w, fy - 8f, paint)
        canvas.drawLine(0f, fy, w, fy, paint)

        // Motas de papel
        if (speckles.isNotEmpty()) {
            paint.strokeWidth = 1f
            paint.color = tint(Palette.SPECKLE)
            canvas.drawPoints(speckles, paint)
        }

        // Muros laterales (límites del segmento)
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.EDGE_WALL)
        if (seg.leftBoundary > 0f) canvas.drawRect(0f, 0f, seg.leftBoundary, h, paint)
        if (seg.rightBoundary < w) canvas.drawRect(seg.rightBoundary, 0f, w, h, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint(Palette.WALL_LINE)
        if (seg.leftBoundary > 0f) canvas.drawLine(seg.leftBoundary, 0f, seg.leftBoundary, h, paint)
        if (seg.rightBoundary < w) canvas.drawLine(seg.rightBoundary, 0f, seg.rightBoundary, h, paint)
    }

    /**
     * Capa de iluminación del segmento (coordenadas del mundo), tras dibujar objetos y personaje:
     * la oscuridad se abre solo alrededor de las luces activas. [camX]/[camY] = esquina de la cámara.
     */
    open fun drawLighting(seg: RoomSegment, camX: Float, camY: Float, extra: LightSource?) {
        lighting.drawWorldLighting(
            canvas, camX, camY, seg.ambientDark, seg.ambientColor,
            seg.darkZones, seg.lights, extra, renderTime
        )
    }

    /** Viñeta de pantalla (coordenadas lógicas). */
    open fun drawVignette() {
        lighting.drawVignette(canvas)
    }

    /** Fundido a negro de las transiciones (coordenadas lógicas). */
    open fun drawFade(alpha: Float) {
        if (alpha <= 0.003f) return
        paint.style = Paint.Style.FILL
        paint.color = (alpha.coerceIn(0f, 1f) * 255f).toInt() shl 24
        canvas.drawRect(0f, 0f, GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat(), paint)
    }

    /** Puerta de frente: marco, hueco oscuro y hoja que se abre con [Door.openProgress]. */
    open fun drawDoor(d: Door) {
        val x = d.x
        val y = d.y
        val w = d.width

        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.DOOR_FRAME)
        canvas.drawRect(x - 3f, y - 3f, d.right + 3f, d.bottom, paint)
        paint.color = tint(Palette.DOOR_INSIDE)
        canvas.drawRect(x, y, d.right, d.bottom, paint)

        val pw = w * (1f - 0.8f * d.openProgress)
        if (pw > 0.5f) {
            paint.color = tint(Palette.DOOR_PANEL)
            canvas.drawRect(x, y, x + pw, d.bottom, paint)
            canvas.save()
            canvas.clipRect(x, y, x + pw, d.bottom)
            drawStrokes(d.hatch, Palette.DOOR_HATCH, 1.3f)
            canvas.restore()

            // Dos paneles hundidos
            if (pw > 12f) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1f
                paint.color = tint(Palette.DOOR_HATCH)
                val pl = x + pw * 0.16f
                val pr = x + pw * 0.84f
                canvas.drawRect(pl, y + 7f, pr, y + d.height * 0.42f, paint)
                canvas.drawRect(pl, y + d.height * 0.5f, pr, d.bottom - 7f, paint)
            }

            // Pomo (o placa de cerradura si está bloqueada)
            paint.style = Paint.Style.FILL
            val kx = x + pw - 5f
            val ky = y + d.height * 0.55f
            if (d.locked) {
                paint.color = tint(0xFF4A4458.toInt())
                canvas.drawRect(kx - 3f, ky - 5f, kx + 3f, ky + 5f, paint)
                paint.color = tint(Palette.OUTLINE)
                canvas.drawCircle(kx, ky - 1f, 1.1f, paint)
                canvas.drawRect(kx - 0.5f, ky - 1f, kx + 0.5f, ky + 3f, paint)
            } else {
                paint.color = tint(Palette.DOOR_KNOB)
                canvas.drawCircle(kx, ky, 2.4f, paint)
            }
        }
        drawStrokes(d.outline, Palette.OUTLINE, 1.1f)
    }

    /** Armario: cuerpo de crayón, una o dos puertas que se abren, interior oscuro, decoración y ojos si hay alguien. */
    open fun drawWardrobe(w: Wardrobe) {
        val st = w.style
        val x = w.x
        val y = w.y
        val r = w.right
        val b = w.bottom

        // Cuerpo
        paint.style = Paint.Style.FILL
        paint.color = tint(st.bodyFill)
        canvas.drawRect(x, y, r, b - 4f, paint)
        drawStrokes(w.hatch, st.bodyHatch, 1.4f)

        // Cornisa y pies
        paint.style = Paint.Style.FILL
        paint.color = tint(st.trim)
        canvas.drawRect(x - 2f, y - 3f, r + 2f, y + 4f, paint)
        canvas.drawRect(x + 3f, b - 4f, x + 9f, b, paint)
        canvas.drawRect(r - 9f, b - 4f, r - 3f, b, paint)

        // Hueco interior (se ve al abrir)
        val inL = x + 4f
        val inR = r - 4f
        val inT = y + 9f
        val inB = b - 8f
        paint.color = tint(Palette.WARDROBE_INSIDE)
        canvas.drawRect(inL, inT, inR, inB, paint)

        val open = w.visualOpen
        val k = 1f - 0.86f * open

        var gapCenter: Float
        if (st.doorCount >= 2) {
            val half = (inR - inL) / 2f
            val pw = half * k
            drawWardrobeDoor(w, inL, inT, inL + pw, inB)
            drawWardrobeDoor(w, inR - pw, inT, inR, inB)
            if (pw > 4f) {
                paint.style = Paint.Style.FILL
                paint.color = tint(Palette.DOOR_KNOB)
                canvas.drawCircle(inL + pw - 2.5f, inT + (inB - inT) * 0.52f, 1.7f, paint)
                canvas.drawCircle(inR - pw + 2.5f, inT + (inB - inT) * 0.52f, 1.7f, paint)
            }
            gapCenter = (inL + inR) / 2f
        } else {
            val pw = (inR - inL) * k
            drawWardrobeDoor(w, inL, inT, inL + pw, inB)
            if (pw > 5f) {
                paint.style = Paint.Style.FILL
                paint.color = tint(Palette.DOOR_KNOB)
                canvas.drawCircle(inL + pw - 3f, inT + (inB - inT) * 0.52f, 1.8f, paint)
            }
            gapCenter = (inL + pw + inR) / 2f
        }

        // Decoración y arañazos (solo con la puerta casi cerrada)
        if (open < 0.3f) {
            drawStrokes(w.deco, st.decoColor, 1.5f)
            drawStrokes(w.scratches, st.bodyHatch, 1f)
        }

        // Alguien dentro: dos ojos que brillan en la rendija (y parpadean de vez en cuando)
        val inside = w.phase == WardrobePhase.OCCUPIED || w.phase == WardrobePhase.CLOSING_BEHIND
        if (inside && open in 0.05f..0.5f) {
            val ey = inT + (inB - inT) * 0.30f
            val blink = (renderTime % 3.6f) > 3.46f
            paint.style = Paint.Style.FILL
            paint.color = tint(Palette.EYE_WHITE)
            if (blink) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 0.9f
                canvas.drawLine(gapCenter - 2.6f, ey, gapCenter - 0.6f, ey, paint)
                canvas.drawLine(gapCenter + 0.6f, ey, gapCenter + 2.6f, ey, paint)
            } else {
                oval.set(gapCenter - 2.7f, ey - 1.5f, gapCenter - 0.7f, ey + 1.5f)
                canvas.drawOval(oval, paint)
                oval.set(gapCenter + 0.7f, ey - 1.5f, gapCenter + 2.7f, ey + 1.5f)
                canvas.drawOval(oval, paint)
            }
        }

        drawStrokes(w.outline, Palette.OUTLINE, 1.1f)
    }

    /** Hoja de armario entre [l,r] x [t,bt]: relleno, trazos de crayón recortados, panel hundido y contorno. */
    private fun drawWardrobeDoor(w: Wardrobe, l: Float, t: Float, r: Float, bt: Float) {
        if (r - l < 0.8f) return
        paint.style = Paint.Style.FILL
        paint.color = tint(w.style.doorFill)
        canvas.drawRect(l, t, r, bt, paint)
        canvas.save()
        canvas.clipRect(l, t, r, bt)
        drawStrokes(w.hatch, w.style.bodyHatch, 1.2f)
        canvas.restore()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawRect(l, t, r, bt, paint)
        if (r - l > 9f) {
            paint.color = tint(w.style.bodyHatch)
            canvas.drawRect(l + 3f, t + 4f, r - 3f, bt - 4f, paint)
        }
    }

    /** Bombilla de una lámpara: se apaga y enciende según el nivel de la luz (0..1). */
    open fun drawBulb(cx: Float, cy: Float, level: Float) {
        paint.style = Paint.Style.FILL
        paint.color = tint(lerpColor(0xFF5A4A34.toInt(), 0xFFFFF2B0.toInt(), level))
        canvas.drawCircle(cx, cy, 4.4f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawCircle(cx, cy, 4.4f, paint)
    }

    /** Interruptor de pared: placa y palanca arriba (encendido) o abajo (apagado). */
    open fun drawSwitch(s: LightSwitch) {
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.SWITCH_PLATE)
        canvas.drawRect(s.x, s.y, s.right, s.bottom, paint)
        drawStrokes(s.outline, Palette.OUTLINE, 1f)
        val on = s.light.active
        val ly = if (on) s.y + 3f else s.y + 9f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawRect(s.x + 3f, ly, s.right - 3f, ly + 4f, paint)
    }

    /** Marca de interacción: un triángulo que rebota sobre el objeto enfocado (se ve incluso en la oscuridad). */
    open fun drawInteractMarker(x: Float, y: Float) {
        val bob = sin(renderTime * 5f) * 1.6f
        val ty = y + bob
        path.reset()
        path.moveTo(x - 4.5f, ty - 7f)
        path.lineTo(x + 4.5f, ty - 7f)
        path.lineTo(x, ty)
        path.close()
        paint.style = Paint.Style.FILL
        paint.color = tint(0xFFFFF2B0.toInt())
        canvas.drawPath(path, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.1f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawPath(path, paint)
    }

    /** Líneas sueltas (pares x1,y1,x2,y2). */
    open fun drawStrokes(lines: FloatArray, color: Int, strokeWidth: Float) {
        if (lines.isEmpty()) return
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = strokeWidth
        paint.color = tint(color)
        canvas.drawLines(lines, paint)
    }

    /** Caja con relleno de crayón, trazos de sombreado y contorno doble imperfecto. */
    open fun drawSketchBox(o: WorldObject) {
        paint.style = Paint.Style.FILL
        paint.color = tint(o.fillColor)
        canvas.drawRect(o.x, o.y, o.right, o.bottom, paint)
        drawStrokes(o.hatch, o.hatchColor, 1.4f)
        drawStrokes(o.outline, o.lineColor, 1f)
    }

    /**
     * Personaje de PERFIL con aire de dibujo infantil. Se diseña en una cuadrícula de 26 unidades
     * de alto y se escala a [Player.HEIGHT] (encuadre cercano), con los pies en el origen.
     * Fotogramas: idle (0), walk_1 (1), walk_2 (2). Se desvanece al entrar en un armario.
     */
    @Suppress("DEPRECATION")
    open fun drawPlayer(p: Player) {
        val alpha = p.visibilityAlpha
        if (alpha <= 0.01f) return
        val layered = alpha < 0.99f
        if (layered) {
            canvas.saveLayerAlpha(p.x - 14f, p.y - 10f, p.right + 14f, p.bottom + 6f, (alpha * 255f).toInt())
        }

        val f = if (p.facing < 0f) -1f else 1f
        val k = p.height / 26f
        val frame = p.walkFrame
        val bob = if (frame == 1) -1f else 0f
        val stride = when (frame) {
            1 -> 2.5f
            2 -> -2.5f
            else -> 0f
        }

        canvas.save()
        canvas.translate(round(p.x + p.width * 0.5f), round(p.bottom))
        canvas.scale(k, k)

        // Sombra en el suelo
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.SHADOW)
        oval.set(-6.5f, -1.5f, 6.5f, 1.5f)
        canvas.drawOval(oval, paint)

        // Piernas (perfil: una adelante y otra atrás) y zapatos
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.6f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawLine(-0.5f, -8f, -0.5f + f * stride, 0f, paint)
        canvas.drawLine(0.5f, -8f, 0.5f - f * stride, 0f, paint)
        paint.strokeWidth = 1.9f
        paint.color = tint(Palette.PLAYER_SHOE)
        canvas.drawLine(-0.5f + f * stride, -0.9f, -0.5f + f * stride + f * 2.8f, -0.9f, paint)
        canvas.drawLine(0.5f - f * stride, -0.9f, 0.5f - f * stride + f * 2.8f, -0.9f, paint)

        // Vestido
        path.reset()
        path.moveTo(-3.5f, -17f + bob)
        path.lineTo(3.5f, -17f + bob)
        path.lineTo(5.5f, -8f)
        path.lineTo(-5.5f, -8f)
        path.close()
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.PLAYER_DRESS)
        canvas.drawPath(path, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawPath(path, paint)
        // Cinturón y dobladillo
        paint.color = tint(Palette.PLAYER_DRESS_TRIM)
        canvas.drawLine(-3.1f, -13.6f + bob * 0.5f, 3.1f, -13.6f + bob * 0.5f, paint)
        canvas.drawLine(-5.2f, -9.2f, 5.2f, -9.2f, paint)

        // Brazo (se balancea al caminar)
        paint.color = tint(Palette.OUTLINE)
        paint.strokeWidth = 1.2f
        canvas.drawLine(0f, -15f + bob, -f * stride * 0.7f + f * 0.5f, -9f + bob, paint)

        // Cabeza
        val hy = -21.5f + bob
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.PLAYER_SKIN)
        canvas.drawCircle(0f, hy, 4.5f, paint)

        // Pelo: casquete superior y un moño en la parte de atrás
        paint.color = tint(Palette.PLAYER_HAIR)
        oval.set(-4.5f, hy - 4.5f, 4.5f, hy + 4.5f)
        canvas.drawArc(oval, 180f, 180f, true, paint)
        canvas.drawCircle(-f * 4f, hy - 1.5f, 2.4f, paint)

        // Contorno doble (trazo duplicado sutil)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawCircle(0f, hy, 4.5f, paint)
        canvas.drawCircle(0.5f, hy + 0.4f, 4.3f, paint)

        // Ojo (mira hacia donde camina), mejilla y boquita
        paint.style = Paint.Style.FILL
        canvas.drawRect(f * 2f - 0.5f, hy, f * 2f + 0.5f, hy + 1.6f, paint)
        paint.color = tint(Palette.PLAYER_BLUSH)
        canvas.drawCircle(f * 2.2f, hy + 2.6f, 0.9f, paint)

        canvas.restore()
        if (layered) canvas.restore()
    }

    /** HUD discreto (coordenadas lógicas): ← → abajo a la izquierda y acción abajo a la derecha. */
    open fun drawHud(input: InputController) {
        drawArrowButton(InputController.LEFT_X, -1f, input.leftHeld)
        drawArrowButton(InputController.RIGHT_X, 1f, input.rightHeld)
        if (input.actionEnabled) drawActionButton(input.isDown(InputAction.INTERACT), input.actionIcon, input.actionLabel)
    }

    private fun drawArrowButton(cx: Float, dir: Float, pressed: Boolean) {
        val cy = InputController.BTN_Y
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f
        paint.color = if (pressed) 0xAA402A1E.toInt() else 0x55402A1E
        canvas.drawCircle(cx, cy, InputController.BTN_RADIUS, paint)
        path.reset()
        path.moveTo(cx + dir * 4f, cy)
        path.lineTo(cx - dir * 3f, cy - 5f)
        path.lineTo(cx - dir * 3f, cy + 5f)
        path.close()
        paint.style = Paint.Style.FILL
        canvas.drawPath(path, paint)
    }

    /** Botón de acción genérico: el icono y el texto los decide el interactuable enfocado. */
    private fun drawActionButton(pressed: Boolean, icon: InteractionIcon, label: String) {
        val cx = InputController.ACTION_X
        val cy = InputController.BTN_Y
        val ink = if (pressed) 0xEE402A1E.toInt() else 0xAA402A1E.toInt()

        // Etiqueta "[ ABRIR ]" a la izquierda del botón, sobre una pastilla de papel
        if (label.isNotEmpty()) {
            val tw = labelPaint.measureText(label)
            val right = cx - InputController.BTN_RADIUS - 5f
            pill.set(right - tw - 8f, cy - 7f, right, cy + 7f)
            paint.style = Paint.Style.FILL
            paint.color = 0xD8F4ECD8.toInt()
            canvas.drawRoundRect(pill, 4f, 4f, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1f
            paint.color = ink
            canvas.drawRoundRect(pill, 4f, 4f, paint)
            canvas.drawText(label, right - tw - 4f, cy + 2.4f, labelPaint)
        }

        paint.style = Paint.Style.FILL
        paint.color = if (pressed) 0x66F4ECD8 else 0x33F4ECD8
        canvas.drawCircle(cx, cy, InputController.BTN_RADIUS + 2f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f
        paint.color = ink
        canvas.drawCircle(cx, cy, InputController.BTN_RADIUS + 2f, paint)
        drawActionIcon(cx, cy, icon)
    }

    private fun drawActionIcon(cx: Float, cy: Float, icon: InteractionIcon) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.3f
        when (icon) {
            InteractionIcon.DOOR -> {
                canvas.drawRect(cx - 4f, cy - 7f, cx + 4f, cy + 7f, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx + 2f, cy + 1f, 1f, paint)
            }
            InteractionIcon.HIDE -> {
                canvas.drawRect(cx - 5f, cy - 7f, cx + 5f, cy + 7f, paint)
                canvas.drawLine(cx, cy - 7f, cx, cy + 7f, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx - 1.8f, cy + 1f, 0.9f, paint)
                canvas.drawCircle(cx + 1.8f, cy + 1f, 0.9f, paint)
            }
            InteractionIcon.EXIT -> {
                canvas.drawLine(cx - 6f, cy - 6f, cx - 6f, cy + 6f, paint)
                canvas.drawLine(cx - 4f, cy, cx + 6f, cy, paint)
                canvas.drawLine(cx + 6f, cy, cx + 2f, cy - 4f, paint)
                canvas.drawLine(cx + 6f, cy, cx + 2f, cy + 4f, paint)
            }
            InteractionIcon.EXAMINE -> {
                canvas.drawCircle(cx - 1.5f, cy - 1.5f, 4f, paint)
                canvas.drawLine(cx + 1.5f, cy + 1.5f, cx + 6f, cy + 6f, paint)
            }
            InteractionIcon.USE -> {
                canvas.drawRect(cx - 5f, cy - 3f, cx + 5f, cy + 3f, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx + 2f, cy, 2f, paint)
            }
            InteractionIcon.NEXT -> {
                path.reset()
                path.moveTo(cx - 3f, cy - 5f)
                path.lineTo(cx + 5f, cy)
                path.lineTo(cx - 3f, cy + 5f)
                path.close()
                paint.style = Paint.Style.FILL
                canvas.drawPath(path, paint)
            }
            InteractionIcon.TALK -> {
                canvas.drawRect(cx - 6f, cy - 5f, cx + 6f, cy + 3f, paint)
                canvas.drawLine(cx - 2f, cy + 3f, cx - 4f, cy + 7f, paint)
            }
        }
    }

    /**
     * Caja de texto del juego (coordenadas lógicas), arriba y centrada: papel con borde de crayón
     * doble e irregular, texto monoespaciado que se "escribe" letra a letra. Hereda la estética
     * del juego (no es una interfaz genérica de Android).
     */
    open fun drawTextBox(d: DialogueManager) {
        val line = d.current ?: return
        val text = line.text
        val left = 28f
        val right = GameConfig.LOGICAL_WIDTH - 28f
        val top = 8f
        val padX = 8f
        ensureWrapped(text, d.lineSerial, right - left - padX * 2f)

        val speaker = line.speaker
        val lineH = 10f
        val h = 9f + wrapCount * lineH + (if (speaker != null) 9f else 0f)

        // Papel + borde doble de crayón
        pill.set(left, top, right, top + h)
        paint.style = Paint.Style.FILL
        paint.color = Palette.TEXT_BOX_FILL
        canvas.drawRoundRect(pill, 3f, 3f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.3f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawRoundRect(pill, 3f, 3f, paint)
        paint.strokeWidth = 0.8f
        pill.set(left + 1.2f, top - 0.8f, right - 0.9f, top + h + 1f)
        canvas.drawRoundRect(pill, 3f, 3f, paint)

        var y = top + 9.5f
        if (speaker != null) {
            canvas.drawText(speaker, left + padX, y, labelPaint)
            y += 9f
        }
        val visible = d.visibleChars
        for (i in 0 until wrapCount) {
            val s = wrapStart[i]
            val e = min(wrapEnd[i], visible)
            if (e > s) canvas.drawText(text, s, e, left + padX, y, dialoguePaint)
            y += lineH
        }

        // Indicador "sigue" en los diálogos que esperan a la acción
        if (d.blocksInput && d.isFullyRevealed) {
            val bx = right - 9f
            val by = top + h - 6f + sin(renderTime * 6f) * 1f
            path.reset()
            path.moveTo(bx - 3f, by - 2.5f)
            path.lineTo(bx + 3f, by - 2.5f)
            path.lineTo(bx, by + 1.5f)
            path.close()
            paint.style = Paint.Style.FILL
            paint.color = tint(Palette.OUTLINE)
            canvas.drawPath(path, paint)
        }
    }

    /** Divide [text] en líneas que caben en [maxWidth] (cortando por espacios). Solo si cambió la línea. */
    private fun ensureWrapped(text: String, serial: Int, maxWidth: Float) {
        if (serial == wrapSerial) return
        wrapSerial = serial
        wrapCount = 0
        val n = text.length
        var start = 0
        while (start < n && wrapCount < MAX_WRAP_LINES) {
            var fit = dialoguePaint.breakText(text, start, n, true, maxWidth, null)
            if (fit < 1) fit = 1
            var end = start + fit
            if (end < n) {
                var sp = end
                while (sp > start && text[sp] != ' ') sp--
                if (sp > start) end = sp
            }
            wrapStart[wrapCount] = start
            wrapEnd[wrapCount] = end
            wrapCount++
            start = end
            while (start < n && text[start] == ' ') start++
        }
        if (wrapCount == 0) {
            wrapStart[0] = 0
            wrapEnd[0] = 0
            wrapCount = 1
        }
    }

    open fun drawDebug(text: CharSequence) {
        canvas.drawText(text, 0, text.length, 3f, 9f, textPaint)
    }

    companion object {
        private const val MAX_WRAP_LINES = 4
    }
}
