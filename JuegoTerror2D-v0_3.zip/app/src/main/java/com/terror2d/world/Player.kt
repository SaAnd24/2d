package com.terror2d.world

import com.terror2d.render.BaseRenderer
import kotlin.math.abs

/** Estado del jugador respecto a esconderse. NORMAL y HIDDEN son los estados estables. */
enum class PlayerState { NORMAL, ENTERING_HIDE, HIDDEN, LEAVING_HIDE }

/**
 * Jugador en vista LATERAL. La caja de colisión es el cuerpo completo (WIDTH x HEIGHT) y siempre
 * está apoyada en el suelo del segmento: la Y no la controla ningún input.
 *
 * v0.3: el personaje es mucho más grande en la escala lógica (encuadre cercano) y puede esconderse
 * ([state], [isHidden]); mientras se esconde o está escondido no se mueve.
 */
class Player(x: Float, y: Float) : WorldObject(x, y, WIDTH, HEIGHT) {

    var velocityX: Float = 0f

    /** +1 mira a la derecha, -1 a la izquierda. */
    var facing: Float = 1f
    var moving: Boolean = false
    var animTime: Float = 0f

    /** 0 = idle, 1 = walk_1, 2 = walk_2. */
    var walkFrame: Int = 0
        private set

    /** Futuro: correr, ralentizar, etc. */
    var speedMultiplier: Float = 1f

    /** NORMAL / ENTERING_HIDE / HIDDEN / LEAVING_HIDE. */
    var state: PlayerState = PlayerState.NORMAL
        private set

    /** true solo cuando está completamente dentro de un escondite. */
    val isHidden: Boolean get() = state == PlayerState.HIDDEN

    /** El jugador puede caminar solo en estado NORMAL. */
    val canMove: Boolean get() = state == PlayerState.NORMAL

    /** Opacidad con la que se dibuja (1 = visible, 0 = invisible dentro del armario). */
    var visibilityAlpha: Float = 1f

    init {
        collidable = false // el jugador no está en la lista de sólidos
    }

    /** Empieza a esconderse (el escondite controla la animación y llama a [finishHide]). */
    fun beginHide() {
        state = PlayerState.ENTERING_HIDE
        velocityX = 0f
        moving = false
        walkFrame = 0
    }

    fun finishHide() {
        state = PlayerState.HIDDEN
        visibilityAlpha = 0f
    }

    /** Empieza a salir del escondite (sigue invisible hasta [finishLeave]). */
    fun beginLeave() {
        state = PlayerState.LEAVING_HIDE
    }

    fun finishLeave() {
        state = PlayerState.NORMAL
        visibilityAlpha = 1f
    }

    /**
     * Un paso de simulación. [dirX] en [-1, 1]. Movimiento deliberado y suave:
     * aceleración corta, sin deslizamiento largo. Si no puede moverse, solo se frena.
     */
    fun update(
        dt: Float,
        dirX: Float,
        solids: List<WorldObject>,
        floorY: Float,
        leftBoundary: Float,
        rightBoundary: Float
    ) {
        val dir = if (canMove) dirX.coerceIn(-1f, 1f) else 0f
        val target = dir * SPEED * speedMultiplier
        val rate = (if (dir == 0f) DECEL else ACCEL) * dt
        velocityX = when {
            velocityX < target - rate -> velocityX + rate
            velocityX > target + rate -> velocityX - rate
            else -> target
        }

        CollisionSystem.snapToFloor(this, floorY)
        if (canMove) {
            val blocked = CollisionSystem.moveHorizontal(this, velocityX * dt, solids, leftBoundary, rightBoundary)
            if (blocked) velocityX = 0f
        } else {
            velocityX = 0f
        }
        CollisionSystem.snapToFloor(this, floorY)

        if (dir != 0f) facing = if (dir < 0f) -1f else 1f
        moving = abs(velocityX) > MOVING_EPS
        if (moving) {
            animTime += dt
            walkFrame = 1 + ((animTime / STEP_TIME).toInt() and 1)
        } else {
            animTime = 0f
            walkFrame = 0
        }
    }

    override fun prepareVisuals(rng: com.terror2d.util.SeededRandom) {
        // El personaje se dibuja proceduralmente; no necesita trazos precalculados.
    }

    override fun render(r: BaseRenderer) {
        r.drawPlayer(this)
    }

    companion object {
        /** Escala lógica del personaje (v0.3: ~27 % de la altura de pantalla; v0.2 era ~14 %). */
        const val WIDTH = 18f
        const val HEIGHT = 48f

        /** Velocidad máxima en píxeles lógicos por segundo (paseo tranquilo, acorde a la nueva escala). */
        const val SPEED = 68f
        const val ACCEL = 520f
        const val DECEL = 640f
        const val MOVING_EPS = 2f

        /** Segundos por fotograma de la animación de caminar. */
        const val STEP_TIME = 0.17f
    }
}
