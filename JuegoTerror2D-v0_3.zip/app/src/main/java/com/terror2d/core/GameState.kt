package com.terror2d.core

/**
 * Estado global del juego. Sigue siendo mínimo.
 * Futuro: progreso, inventario, flags, estado narrativo, guardado.
 */
class GameState {
    var currentSceneId: String = ""

    /** Segmento lateral activo dentro de la escena actual. */
    var currentSegmentId: String = ""

    var playerX: Float = 0f
    var playerY: Float = 0f

    /** v0.3: el jugador está escondido dentro de un armario. */
    var playerHidden: Boolean = false

    /** v0.3: descripción del último evento del juego (depuración). */
    var lastEvent: String = ""

    /** Tiempo de juego acumulado (segundos). */
    var elapsedTime: Float = 0f

    /**
     * 0.0 = visualmente normal, 1.0 = completamente deteriorado.
     * En v0.3 permanece en 0.0. Futuras versiones lo usarán para saturación,
     * textura, grafito, rasguños, distorsión y sombras.
     */
    var visualCorruption: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
        }
}
