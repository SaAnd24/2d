package com.terror2d.input

import android.view.KeyEvent
import android.view.MotionEvent
import com.terror2d.core.Viewport
import com.terror2d.interaction.InteractionIcon

/** Acciones del juego. En v0.3 INTERACT es el botón de acción genérico (puertas, armarios, objetos...). */
enum class InputAction { INTERACT, RUN, HIDE, EXAMINE, CONFIRM, CANCEL }

/**
 * Traduce eventos táctiles/teclado a un estado de entrada abstracto: izquierda, derecha y acción.
 * La lógica del juego solo lee [moveX] y las acciones; nunca MotionEvent.
 *
 * Controles táctiles (coordenadas lógicas 320x180, zona inferior):
 *  - botón izquierdo y derecho abajo a la izquierda (discretos);
 *  - botón de acción abajo a la derecha, visible solo cuando hay algo con lo que actuar.
 * Las zonas de toque se extienden a las barras negras para que el pulgar nunca falle.
 */
class InputController {

    /** Dirección horizontal: -1 (izquierda), 0 o 1 (derecha). No existe eje vertical. */
    @Volatile var moveX: Float = 0f
        private set

    @Volatile var leftHeld: Boolean = false
        private set
    @Volatile var rightHeld: Boolean = false
        private set

    /** Lo escribe la escena: true cuando el botón de acción debe mostrarse y aceptar toques. */
    @Volatile var actionEnabled: Boolean = false

    /** Lo escribe la escena (genérico, viene del interactuable enfocado): icono y texto del botón. */
    @Volatile var actionIcon: InteractionIcon = InteractionIcon.DOOR
    @Volatile var actionLabel: String = ""

    private val actionDown = BooleanArray(InputAction.values().size)
    private val actionPressed = BooleanArray(InputAction.values().size)

    private var touchLeft = false
    private var touchRight = false
    private var touchAction = false
    private var keyLeft = false
    private var keyRight = false
    private var keyAction = false

    fun isDown(action: InputAction): Boolean = actionDown[action.ordinal]

    /** true durante el primer update tras pulsar. */
    fun wasPressed(action: InputAction): Boolean = actionPressed[action.ordinal]

    fun setAction(action: InputAction, down: Boolean) {
        val i = action.ordinal
        if (down && !actionDown[i]) actionPressed[i] = true
        actionDown[i] = down
    }

    /** Se llama al final de cada update para limpiar las pulsaciones puntuales. */
    fun endFrame() {
        for (i in actionPressed.indices) actionPressed[i] = false
    }

    /** Fija la dirección directamente (útil para tests y mandos). */
    fun setDirection(left: Boolean, right: Boolean) {
        keyLeft = left
        keyRight = right
        publish()
    }

    /**
     * Recalcula el estado táctil con TODOS los dedos activos, de modo que deslizar el dedo
     * de un botón a otro cambia de dirección y varios dedos conviven (mover + actuar).
     */
    fun onTouchEvent(e: MotionEvent, viewport: Viewport): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_CANCEL) {
            touchLeft = false
            touchRight = false
            touchAction = false
            publish()
            return true
        }
        val lifting = e.actionMasked == MotionEvent.ACTION_UP ||
            e.actionMasked == MotionEvent.ACTION_POINTER_UP
        val skip = if (lifting) e.actionIndex else -1
        var l = false
        var r = false
        var a = false
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            val lx = viewport.toLogicalX(e.getX(i))
            val ly = viewport.toLogicalY(e.getY(i))
            if (ly < HUD_TOP) continue
            if (lx < LEFT_ZONE_END) l = true
            else if (lx < RIGHT_ZONE_END) r = true
            else if (actionEnabled && lx >= ACTION_ZONE_START) a = true
        }
        touchLeft = l
        touchRight = r
        touchAction = a
        publish()
        return true
    }

    /** Teclado (emulador / mando): flechas o A/D; ESPACIO, ENTER o E = acción. */
    fun onKey(keyCode: Int, down: Boolean): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_A -> keyLeft = down
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_D -> keyRight = down
            KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_E -> keyAction = down
            else -> return false
        }
        publish()
        return true
    }

    private fun publish() {
        leftHeld = touchLeft || keyLeft
        rightHeld = touchRight || keyRight
        var mx = 0f
        if (leftHeld) mx -= 1f
        if (rightHeld) mx += 1f
        moveX = mx
        setAction(InputAction.INTERACT, touchAction || keyAction)
    }

    companion object {
        // Posición de los botones en coordenadas lógicas (para el HUD).
        const val BTN_Y = 158f
        const val LEFT_X = 20f
        const val RIGHT_X = 58f
        const val ACTION_X = 296f
        const val BTN_RADIUS = 12f

        // Zonas de toque (generosas, incluyen las barras negras laterales).
        const val HUD_TOP = 100f
        const val LEFT_ZONE_END = 39f
        const val RIGHT_ZONE_END = 80f
        const val ACTION_ZONE_START = 240f
    }
}
