package com.terror2d

import com.terror2d.core.CameraMode
import com.terror2d.core.GameConfig
import com.terror2d.core.GameState
import com.terror2d.core.Viewport
import com.terror2d.events.EventBus
import com.terror2d.events.EventType
import com.terror2d.input.InputAction
import com.terror2d.input.InputController
import com.terror2d.interaction.InteractionIcon
import com.terror2d.render.LightingRenderer
import com.terror2d.render.Palette
import com.terror2d.scene.RoomSegment
import com.terror2d.scene.Scene
import com.terror2d.scene.SceneDefinition
import com.terror2d.scene.SceneTransition
import com.terror2d.scene.SpawnPoint
import com.terror2d.scene.TestRoomDefinition
import com.terror2d.scene.TestRoomDefinition.ROOM_A
import com.terror2d.scene.TestRoomDefinition.ROOM_B
import com.terror2d.scene.TestRoomDefinition.ROOM_C
import com.terror2d.scene.TestRoomDefinition.ROOM_D
import com.terror2d.scene.TestScene
import com.terror2d.ui.DialogueLine
import com.terror2d.ui.DialogueManager
import com.terror2d.util.SeededRandom
import com.terror2d.world.Block
import com.terror2d.world.Door
import com.terror2d.world.DoorTarget
import com.terror2d.world.LightSource
import com.terror2d.world.LightSwitch
import com.terror2d.world.Player
import com.terror2d.world.PlayerState
import com.terror2d.world.Wardrobe
import com.terror2d.world.WardrobePhase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineTest {

    private val dt = 1f / 60f

    private class World(seed: Long = TestRoomDefinition.DEFAULT_SEED, room: String? = null, spawn: String = "start") {
        val state = GameState()
        val input = InputController()
        val scene = TestScene(seed).also { it.load(state) }

        init {
            if (room != null) scene.loadSegment(room, spawn, state)
        }

        fun step(n: Int = 1) {
            repeat(n) {
                scene.update(1f / 60f, input, state)
                input.endFrame()
            }
        }

        fun walk(left: Boolean, right: Boolean, steps: Int) {
            input.setDirection(left, right)
            step(steps)
            input.setDirection(false, false)
        }

        fun pressAction() {
            input.setAction(InputAction.INTERACT, true)
            step(1)
            input.setAction(InputAction.INTERACT, false)
        }

        fun door(id: String): Door = scene.currentSegment.doors.first { it.id == id }

        fun wardrobe(): Wardrobe = scene.currentSegment.objects.filterIsInstance<Wardrobe>().first()

        /** Coloca al jugador junto a la puerta y la usa; espera a que acabe la transición. */
        fun useDoor(id: String) {
            val d = door(id)
            scene.player.x = d.x + 2f
            step()
            pressAction()
            step(70)
        }

        fun standAt(x: Float) {
            scene.player.x = x
            step()
        }
    }

    /** Escena mínima con un bloque sólido, para probar colisiones (las habitaciones de v0.3 no tienen sólidos). */
    private class SolidWorld {
        val block = Block(150f, 146f - 20f, 20f, 20f, Palette.CRATE_FILL, Palette.CRATE_HATCH)
        val state = GameState()
        val input = InputController()
        val scene: Scene = object : Scene(
            SceneDefinition(
                id = "solid", seed = 1L,
                segments = listOf(
                    RoomSegment(
                        id = "s", width = 320f, floorY = 146f, leftBoundary = 12f, rightBoundary = 308f,
                        objects = listOf(block),
                        spawnPoints = mapOf("a" to SpawnPoint(60f, 1), "b" to SpawnPoint(250f, -1))
                    )
                ),
                startSegmentId = "s", startSpawnId = "a"
            )
        ) {}.also { it.load(state) }

        fun walk(left: Boolean, right: Boolean, steps: Int) {
            input.setDirection(left, right)
            repeat(steps) { scene.update(dt0, input, state); input.endFrame() }
            input.setDirection(false, false)
        }

        companion object {
            const val dt0 = 1f / 60f
        }
    }

    // ---------- SeededRandom (intacto) ----------

    @Test
    fun sameSeedProducesSameSequence() {
        val a = SeededRandom(42L)
        val b = SeededRandom(42L)
        for (i in 0 until 1000) assertEquals(a.nextLong(), b.nextLong())
    }

    @Test
    fun differentSeedsProduceDifferentSequences() {
        assertNotEquals(SeededRandom(1L).nextLong(), SeededRandom(2L).nextLong())
    }

    @Test
    fun floatsStayInRange() {
        val r = SeededRandom(7L)
        for (i in 0 until 1000) {
            val f = r.nextFloat()
            assertTrue(f >= 0f && f < 1f)
        }
    }

    // ---------- Seed visual ----------

    @Test
    fun sameSeedProducesSameVisuals() {
        val a = TestScene(123L).also { it.load(GameState()) }
        val b = TestScene(123L).also { it.load(GameState()) }
        assertEquals(a.visualFingerprint(), b.visualFingerprint())
    }

    @Test
    fun differentSeedProducesDifferentVisuals() {
        val a = TestScene(123L).also { it.load(GameState()) }
        val b = TestScene(124L).also { it.load(GameState()) }
        assertNotEquals(a.visualFingerprint(), b.visualFingerprint())
    }

    @Test
    fun sameSeedSameVisualsInEveryRoomAfterTransitions() {
        val state = GameState()
        val scene = TestScene(55L).also { it.load(state) }
        for (room in listOf(ROOM_A, ROOM_B, ROOM_C, ROOM_D)) {
            scene.loadSegment(room, scene.definition.segment(room).spawnPoints.keys.first(), state)
            val first = scene.visualFingerprint()
            scene.loadSegment(ROOM_A, "start", state)
            scene.loadSegment(room, scene.definition.segment(room).spawnPoints.keys.first(), state)
            assertEquals("el aspecto de $room cambió al volver", first, scene.visualFingerprint())
        }
    }

    @Test
    fun seedNeverChangesCriticalPositions() {
        val a = TestRoomDefinition.create(1L)
        val b = TestRoomDefinition.create(999999L)
        for (i in a.segments.indices) {
            val sa = a.segments[i]
            val sb = b.segments[i]
            assertEquals(sa.width, sb.width, 0f)
            assertEquals(sa.floorY, sb.floorY, 0f)
            for (j in sa.doors.indices) assertEquals(sa.doors[j].x, sb.doors[j].x, 0f)
            val wa = sa.objects.filterIsInstance<Wardrobe>().first()
            val wb = sb.objects.filterIsInstance<Wardrobe>().first()
            assertEquals(wa.x, wb.x, 0f)
            for (k in sa.spawnPoints.keys) assertEquals(sa.spawnPoints[k]!!.x, sb.spawnPoints[k]!!.x, 0f)
        }
    }

    @Test
    fun wardrobesAreVisuallyDistinct() {
        val def = TestRoomDefinition.create()
        val styles = def.segments.map { it.objects.filterIsInstance<Wardrobe>().first().style }
        for (i in styles.indices) for (j in i + 1 until styles.size) {
            val a = styles[i]
            val b = styles[j]
            assertTrue(
                "armarios $i y $j demasiado parecidos",
                a.bodyFill != b.bodyFill || a.doorCount != b.doorCount || a.deco != b.deco
            )
        }
        assertEquals(4, styles.map { it.bodyFill }.toSet().size)
    }

    // ---------- Movimiento lateral ----------

    @Test
    fun walksRight() {
        val w = World()
        val x0 = w.scene.player.x
        w.walk(left = false, right = true, steps = 30)
        assertTrue("no avanzó a la derecha", w.scene.player.x > x0 + 5f)
        assertEquals(1f, w.scene.player.facing, 0f)
    }

    @Test
    fun walksLeft() {
        val w = World()
        val x0 = w.scene.player.x
        w.walk(left = true, right = false, steps = 30)
        assertTrue("no avanzó a la izquierda", w.scene.player.x < x0 - 5f)
        assertEquals(-1f, w.scene.player.facing, 0f)
    }

    @Test
    fun noFreeVerticalMovement() {
        val w = World(room = ROOM_C, spawn = "from_b")
        val y0 = w.scene.player.y
        w.walk(left = false, right = true, steps = 120)
        w.walk(left = true, right = false, steps = 60)
        assertEquals(y0, w.scene.player.y, 0f)
        assertEquals(y0, w.state.playerY, 0f)
    }

    @Test
    fun movementIsDeterministic() {
        val a = World(room = ROOM_C, spawn = "from_b")
        val b = World(room = ROOM_C, spawn = "from_b")
        a.walk(false, true, 200)
        b.walk(false, true, 200)
        assertEquals(a.scene.player.x, b.scene.player.x, 0f)
    }

    @Test
    fun speedIsGentleAndStopsWhenReleased() {
        val w = World(room = ROOM_C, spawn = "from_b")
        w.walk(false, true, 120)
        assertTrue(w.scene.player.velocityX <= Player.SPEED + 0.001f)
        w.step(30)
        assertEquals(0f, w.scene.player.velocityX, 0.001f)
    }

    @Test
    fun playerStaysOnFloor() {
        val w = World(room = ROOM_C, spawn = "from_b")
        val floor = w.scene.currentSegment.floorY
        for (i in 0 until 300) {
            w.input.setDirection(left = i % 120 >= 60, right = i % 120 < 60)
            w.step()
            assertEquals(floor, w.scene.player.bottom, 0.0001f)
        }
    }

    // ---------- Límites y colisiones ----------

    @Test
    fun rightBoundaryStopsPlayer() {
        val w = World(room = ROOM_C, spawn = "from_b")
        w.walk(false, true, 1500)
        assertEquals(w.scene.currentSegment.rightBoundary - Player.WIDTH, w.scene.player.x, 0.01f)
    }

    @Test
    fun leftBoundaryStopsPlayer() {
        val w = World(room = ROOM_B, spawn = "from_a")
        w.walk(true, false, 600)
        assertEquals(w.scene.currentSegment.leftBoundary, w.scene.player.x, 0.01f)
    }

    @Test
    fun solidObjectBlocksPlayerFromBothSides() {
        val a = SolidWorld()
        a.walk(false, true, 600)
        assertEquals(a.block.x - Player.WIDTH, a.scene.player.x, 0.01f)
        val b = SolidWorld()
        b.scene.loadSegment("s", "b", b.state)
        b.walk(true, false, 600)
        assertEquals(b.block.right, b.scene.player.x, 0.01f)
    }

    @Test
    fun furnitureNeverBlocksTheWayToTheDoors() {
        val w = World()
        w.walk(false, true, 900)
        val door = w.scene.currentSegment.doors[0]
        assertTrue(w.scene.player.x + Player.WIDTH > door.x)
    }

    // ---------- Cámara cercana ----------

    @Test
    fun closeFramingMakesThePlayerClearlyVisible() {
        val ratio = Player.HEIGHT / GameConfig.LOGICAL_HEIGHT
        assertTrue("el personaje ocupa solo ${ratio * 100}% de la pantalla", ratio >= GameConfig.MIN_PLAYER_FRAME_RATIO)
        assertTrue("el personaje debe ser mayor que el de v0.2 (26 px)", Player.HEIGHT >= 44f)
        val door = Door("t", 0f, 146f)
        assertTrue("la puerta debe verse bien más alta que el jugador", door.height > Player.HEIGHT)
        assertTrue(door.height < GameConfig.LOGICAL_HEIGHT * 0.5f)
    }

    @Test
    fun smallRoomsUseFixedCameraAndShowTheWholeRoom() {
        for (room in listOf(ROOM_A, ROOM_B)) {
            val w = World(room = room, spawn = w0(room))
            val cam = w.scene.camera
            assertEquals(CameraMode.FIXED, cam.mode)
            assertTrue(w.scene.width <= cam.viewWidth)
            val x0 = cam.x
            val y0 = cam.y
            w.walk(false, true, 120)
            w.walk(true, false, 120)
            assertEquals(x0, cam.x, 0f)
            assertEquals(y0, cam.y, 0f)
        }
    }

    private fun w0(room: String): String = if (room == ROOM_A) "start" else "from_a"

    @Test
    fun largeRoomsUseSideScrollingFollowingHorizontally() {
        for (room in listOf(ROOM_C, ROOM_D)) {
            val spawn = if (room == ROOM_C) "from_b" else "from_c"
            val w = World(room = room, spawn = spawn)
            val cam = w.scene.camera
            val y0 = cam.y
            assertEquals(CameraMode.SIDE_SCROLLING, cam.mode)
            w.walk(false, true, 25)
            assertEquals("no debe moverse dentro de la zona muerta", 0f, cam.x, 0.001f)
            w.walk(false, true, 400)
            assertTrue("la cámara debe seguir al jugador", cam.x > 20f)
            assertTrue(cam.x <= w.scene.width - cam.viewWidth + 0.001f)
            assertTrue(w.scene.player.centerX >= cam.x && w.scene.player.centerX <= cam.x + cam.viewWidth)
            w.walk(true, false, 900)
            assertTrue(cam.x >= 0f)
            assertEquals("la cámara nunca se mueve en vertical", y0, cam.y, 0f)
        }
    }

    @Test
    fun cameraNeverLeavesRoomOnEitherEnd() {
        val w = World(room = ROOM_C, spawn = "from_b")
        w.walk(false, true, 1500)
        assertEquals(w.scene.width - w.scene.camera.viewWidth, w.scene.camera.x, 0.5f)
        w.walk(true, false, 1500)
        assertEquals(0f, w.scene.camera.x, 0.5f)
    }

    @Test
    fun roomsAreCompact() {
        for (seg in TestRoomDefinition.create().segments) {
            assertTrue("${seg.id} demasiado grande", seg.width <= GameConfig.LOGICAL_WIDTH * 2f)
            assertEquals(TestRoomDefinition.FLOOR_Y, seg.floorY, 0f)
        }
    }

    // ---------- Puertas ----------

    @Test
    fun doorChangesState() {
        val d = Door("d", 10f, 140f, target = DoorTarget("x", "y"))
        assertFalse(d.isOpen)
        assertTrue(d.activate())
        assertTrue(d.isOpen)
        assertFalse("activar una puerta ya abierta no cambia nada", d.activate())
        repeat(30) { d.update(dt) }
        assertEquals(1f, d.openProgress, 0f)
        assertTrue(d.close())
        repeat(30) { d.update(dt) }
        assertEquals(0f, d.openProgress, 0f)
        d.activate()
        d.reset()
        assertFalse(d.isOpen)
        assertEquals(0f, d.openProgress, 0f)
    }

    @Test
    fun lockedDoorDoesNotOpenAndShowsText() {
        val w = World(room = ROOM_D, spawn = "from_c")
        val locked = w.door(TestRoomDefinition.DOOR_D_LOCKED)
        assertTrue(locked.locked)
        assertFalse(locked.activate())
        w.standAt(locked.x + 2f)
        w.pressAction()
        assertFalse(locked.isOpen)
        assertEquals(ROOM_D, w.scene.currentSegment.id)
        assertEquals("La puerta está cerrada.", w.scene.dialogue.current?.text)
        assertFalse(w.scene.transition.isActive)
    }

    @Test
    fun actionIsOnlyAvailableNearSomethingInteractable() {
        val w = World()
        w.step()
        assertFalse(w.input.actionEnabled)
        assertNull(w.scene.focused)
        val door = w.scene.currentSegment.doors[0]
        w.standAt(door.x + 2f)
        assertTrue(w.input.actionEnabled)
        assertEquals(door, w.scene.focused)
        assertEquals("ABRIR", w.input.actionLabel)
        assertEquals(InteractionIcon.DOOR, w.input.actionIcon)
    }

    @Test
    fun actionFarFromAnythingDoesNothing() {
        val w = World()
        val door = w.scene.currentSegment.doors[0]
        w.pressAction()
        assertFalse(door.isOpen)
        assertEquals(ROOM_A, w.scene.currentSegment.id)
    }

    @Test
    fun doorTransitionHasPhasesAndLoadsTargetAtSpawn() {
        val w = World()
        val doorA = w.scene.currentSegment.doors[0]
        w.standAt(doorA.x + 2f)
        w.pressAction()
        assertTrue(doorA.isOpen)
        assertTrue(w.scene.transition.isActive)
        assertEquals("aún debe estar abriéndose", ROOM_A, w.scene.currentSegment.id)
        // El jugador no se mueve durante la transición
        val x = w.scene.player.x
        w.walk(true, false, 5)
        assertEquals(x, w.scene.player.x, 0.5f)
        w.step(60)
        assertEquals(ROOM_B, w.scene.currentSegment.id)
        assertEquals(ROOM_B, w.state.currentSegmentId)
        assertEquals(78f, w.scene.player.centerX, 0.01f)
        assertEquals(w.scene.currentSegment.floorY, w.scene.player.bottom, 0f)
        assertEquals(1f, w.scene.player.facing, 0f)
        assertFalse(w.scene.transition.isActive)
    }

    @Test
    fun sceneTransitionStateMachine() {
        val t = SceneTransition()
        assertFalse(t.isActive)
        t.start(DoorTarget("x", "y"), null)
        assertEquals(SceneTransition.Phase.FADE_OUT, t.phase)
        var loads = 0
        var maxAlpha = 0f
        repeat(120) {
            if (t.update(dt)) loads++
            if (t.fadeAlpha > maxAlpha) maxAlpha = t.fadeAlpha
        }
        assertEquals("la carga debe ocurrir una sola vez", 1, loads)
        assertTrue(maxAlpha > 0.95f)
        assertFalse(t.isActive)
    }

    @Test
    fun spawnArrivalDoesNotImmediatelyPromptTheArrivalDoor() {
        val w = World()
        w.useDoor(TestRoomDefinition.DOOR_A_TO_B)
        assertEquals(ROOM_B, w.scene.currentSegment.id)
        w.step()
        assertNull(w.scene.focused)
    }

    // ---------- Cuatro habitaciones y conexiones ----------

    @Test
    fun fourRoomsWithDoorWardrobeLampAndDecoration() {
        val def = TestRoomDefinition.create()
        assertEquals(listOf(ROOM_A, ROOM_B, ROOM_C, ROOM_D), def.segments.map { it.id })
        for (seg in def.segments) {
            assertTrue("${seg.id}: sin puerta", seg.doors.isNotEmpty())
            assertTrue("${seg.id}: sin armario", seg.objects.any { it is Wardrobe })
            assertTrue("${seg.id}: sin luz", seg.lights.isNotEmpty())
            assertTrue("${seg.id}: sin decoración", seg.objects.size >= 5)
        }
    }

    @Test
    fun everyDoorTargetAndSpawnExists() {
        val def = TestRoomDefinition.create()
        for (seg in def.segments) for (d in seg.doors) {
            val t = d.target
            if (t == null) {
                assertTrue("${d.id}: puerta sin destino que no está bloqueada", d.locked)
            } else {
                val dest = def.segment(t.segmentId)
                assertNotNull(dest.spawn(t.spawnId))
            }
        }
    }

    @Test
    fun connectionsAreABCDAndBack() {
        val def = TestRoomDefinition.create()
        fun targets(id: String) = def.segment(id).doors.mapNotNull { it.target?.segmentId }.toSet()
        assertEquals(setOf(ROOM_B), targets(ROOM_A))
        assertEquals(setOf(ROOM_A, ROOM_C), targets(ROOM_B))
        assertEquals(setOf(ROOM_B, ROOM_D), targets(ROOM_C))
        assertEquals(setOf(ROOM_C), targets(ROOM_D))
    }

    @Test
    fun canWalkThroughAllFourRoomsAndBack() {
        val w = World()
        val path = listOf(
            TestRoomDefinition.DOOR_A_TO_B to ROOM_B,
            TestRoomDefinition.DOOR_B_TO_C to ROOM_C,
            TestRoomDefinition.DOOR_C_TO_D to ROOM_D,
            TestRoomDefinition.DOOR_D_TO_C to ROOM_C,
            TestRoomDefinition.DOOR_C_TO_B to ROOM_B,
            TestRoomDefinition.DOOR_B_TO_A to ROOM_A
        )
        for ((doorId, expected) in path) {
            w.useDoor(doorId)
            assertEquals("tras $doorId", expected, w.scene.currentSegment.id)
            assertEquals(w.scene.currentSegment.floorY, w.scene.player.bottom, 0f)
        }
        // Todas las puertas vuelven cerradas
        for (seg in w.scene.definition.segments) for (d in seg.doors) assertFalse(d.isOpen)
    }

    @Test
    fun roomLayoutsAreTestedAcrossDifferentCameraModes() {
        val def = TestRoomDefinition.create()
        assertEquals(CameraMode.FIXED, def.segment(ROOM_A).cameraMode)
        assertEquals(CameraMode.FIXED, def.segment(ROOM_B).cameraMode)
        assertEquals(CameraMode.SIDE_SCROLLING, def.segment(ROOM_C).cameraMode)
        assertEquals(CameraMode.SIDE_SCROLLING, def.segment(ROOM_D).cameraMode)
        assertTrue(def.segment(ROOM_C).width > def.segment(ROOM_A).width)
    }

    // ---------- Interacción genérica ----------

    @Test
    fun examinableObjectIsDetectedAndShowsText() {
        val w = World()
        w.standAt(108f)
        assertEquals("examine_a_chair", w.scene.focused?.interactionId)
        assertEquals("EXAMINAR", w.input.actionLabel)
        assertEquals(InteractionIcon.EXAMINE, w.input.actionIcon)
        w.pressAction()
        assertEquals("Una silla de madera.", w.scene.dialogue.current?.text)
        assertTrue(w.scene.events.wasPosted(EventType.ON_OBJECT_EXAMINED, "examine_a_chair"))
        assertTrue(w.scene.events.wasPosted(EventType.ON_INTERACT, "examine_a_chair"))
    }

    @Test
    fun lightSwitchTogglesItsLampThroughTheGenericButton() {
        val w = World(room = ROOM_C, spawn = "from_b")
        val sw = w.scene.currentSegment.objects.filterIsInstance<LightSwitch>().first()
        val light = sw.light
        assertTrue(light.active)
        w.standAt(sw.x - 6f)
        assertEquals(sw, w.scene.focused)
        assertEquals("APAGAR", w.input.actionLabel)
        w.pressAction()
        assertFalse(light.active)
        w.step(40)
        assertEquals(0f, light.level, 0.001f)
        assertEquals("ENCENDER", w.input.actionLabel)
        w.pressAction()
        assertTrue(light.active)
    }

    // ---------- Armarios / esconderse ----------

    @Test
    fun wardrobeIsDetectedWhenNearAndShowsHideAction() {
        val w = World()
        val wd = w.wardrobe()
        w.step()
        assertNull(w.scene.focused)
        w.standAt(wd.x + 10f)
        assertEquals(wd, w.scene.focused)
        assertTrue(w.input.actionEnabled)
        assertEquals("ESCONDERSE", w.input.actionLabel)
        assertEquals(InteractionIcon.HIDE, w.input.actionIcon)
        assertEquals(PlayerState.NORMAL, w.scene.player.state)
        assertFalse(w.state.playerHidden)
    }

    @Test
    fun enteringAndLeavingTheWardrobe() {
        val w = World()
        val wd = w.wardrobe()
        w.standAt(wd.x + 10f)
        w.pressAction()
        assertEquals(PlayerState.ENTERING_HIDE, w.scene.player.state)
        assertFalse(w.scene.player.canMove)
        w.step(60)
        val p = w.scene.player
        assertEquals(WardrobePhase.OCCUPIED, wd.phase)
        assertTrue(p.isHidden)
        assertEquals(PlayerState.HIDDEN, p.state)
        assertTrue(w.state.playerHidden)
        assertEquals(0f, p.visibilityAlpha, 0f)
        assertTrue(w.scene.events.wasPosted(EventType.ON_HIDE, wd.id))
        assertEquals("El armario está vacío.", w.scene.dialogue.current?.text)

        // Escondido no se camina
        val x = p.x
        w.walk(false, true, 40)
        assertEquals(x, p.x, 0.001f)

        // Aparece el botón de salir y se sale
        w.step()
        assertEquals(wd, w.scene.focused)
        assertEquals("SALIR", w.input.actionLabel)
        assertEquals(InteractionIcon.EXIT, w.input.actionIcon)
        w.pressAction()
        assertEquals(PlayerState.LEAVING_HIDE, p.state)
        w.step(60)
        assertEquals(PlayerState.NORMAL, p.state)
        assertFalse(p.isHidden)
        assertFalse(w.state.playerHidden)
        assertEquals(1f, p.visibilityAlpha, 0f)
        assertEquals(WardrobePhase.CLOSED, wd.phase)
        assertTrue(w.scene.events.wasPosted(EventType.ON_EXIT_HIDE, wd.id))

        // Reaparece delante del armario, dentro de los límites, apoyado en el suelo
        val seg = w.scene.currentSegment
        assertEquals(wd.centerX, p.centerX, 0.6f)
        assertTrue(p.x >= seg.leftBoundary && p.right <= seg.rightBoundary)
        assertEquals(seg.floorY, p.bottom, 0f)

        // Y vuelve a caminar
        val x1 = p.x
        w.walk(false, true, 30)
        assertTrue(p.x > x1 + 5f)
    }

    @Test
    fun everyRoomWardrobeWorks() {
        for (room in listOf(ROOM_A, ROOM_B, ROOM_C, ROOM_D)) {
            val spawn = when (room) {
                ROOM_A -> "start"
                ROOM_B -> "from_a"
                ROOM_C -> "from_b"
                else -> "from_c"
            }
            val w = World(room = room, spawn = spawn)
            val wd = w.wardrobe()
            w.standAt(wd.x + 10f)
            assertEquals("$room: no detecta el armario", wd, w.scene.focused)
            w.pressAction()
            w.step(60)
            assertTrue("$room: no se escondió", w.scene.player.isHidden)
            w.pressAction()
            w.step(60)
            assertEquals("$room: no salió", PlayerState.NORMAL, w.scene.player.state)
            val seg = w.scene.currentSegment
            assertTrue(w.scene.player.x >= seg.leftBoundary && w.scene.player.right <= seg.rightBoundary)
        }
    }

    @Test
    fun wardrobeSecondVisitDoesNotRepeatTheEmptyMessage() {
        val w = World()
        val wd = w.wardrobe()
        w.standAt(wd.x + 10f)
        w.pressAction()
        w.step(60)
        w.pressAction()
        w.step(60)
        w.scene.dialogue.clear()
        w.pressAction()
        w.step(60)
        assertTrue(w.scene.player.isHidden)
        assertNull(w.scene.dialogue.current)
    }

    @Test
    fun changingRoomResetsHiddenState() {
        val w = World()
        w.scene.loadSegment(ROOM_B, "from_a", w.state)
        assertEquals(PlayerState.NORMAL, w.scene.player.state)
        assertFalse(w.state.playerHidden)
    }

    // ---------- Texto, diálogos y eventos ----------

    @Test
    fun messagesRevealAndAutoClose() {
        val d = DialogueManager()
        d.showMessage("Hola")
        assertTrue(d.isActive)
        assertFalse(d.blocksInput)
        repeat(30) { d.update(dt) }
        assertTrue(d.isFullyRevealed)
        repeat(300) { d.update(dt) }
        assertFalse(d.isActive)
    }

    @Test
    fun dialogueAdvancesLineByLineAndBlocksInput() {
        val d = DialogueManager()
        var finished = false
        d.startDialogue(listOf(DialogueLine("Niño", "Uno"), DialogueLine(null, "Dos")), { finished = true })
        assertTrue(d.blocksInput)
        assertEquals("Niño", d.current?.speaker)
        assertTrue(d.advance())             // completa la escritura
        assertTrue(d.isFullyRevealed)
        assertTrue(d.advance())             // siguiente línea
        assertEquals("Dos", d.current?.text)
        d.advance()
        d.advance()
        assertFalse(d.isActive)
        assertTrue(finished)
    }

    @Test
    fun dialogueFreezesTheSceneUntilAdvanced() {
        val w = World()
        w.scene.dialogue.startDialogue(listOf(DialogueLine("Niño", "Hola")))
        val x = w.scene.player.x
        w.walk(false, true, 40)
        assertEquals(x, w.scene.player.x, 0.001f)
        assertEquals("SEGUIR", w.input.actionLabel)
        w.pressAction()
        w.pressAction()
        assertFalse(w.scene.dialogue.isActive)
        w.walk(false, true, 30)
        assertTrue(w.scene.player.x > x)
    }

    @Test
    fun eventBusDeliversEvents() {
        val bus = EventBus()
        var count = 0
        bus.subscribe(EventType.ON_HIDE) { count++ }
        bus.post(EventType.ON_HIDE, "a")
        bus.post(EventType.ON_EXIT_HIDE, "a")
        assertEquals(1, count)
        assertTrue(bus.wasPosted(EventType.ON_EXIT_HIDE))
        assertFalse(bus.wasPosted(EventType.ON_ENTER_ROOM))
    }

    @Test
    fun enteringRoomsAndOpeningDoorsPostEvents() {
        val w = World()
        assertTrue(w.scene.events.wasPosted(EventType.ON_ENTER_ROOM, ROOM_A))
        w.useDoor(TestRoomDefinition.DOOR_A_TO_B)
        assertTrue(w.scene.events.wasPosted(EventType.ON_DOOR_OPEN, TestRoomDefinition.DOOR_A_TO_B))
        assertTrue(w.scene.events.wasPosted(EventType.ON_INTERACT, TestRoomDefinition.DOOR_A_TO_B))
        assertTrue(w.scene.events.wasPosted(EventType.ON_ENTER_ROOM, ROOM_B))
    }

    @Test
    fun eventTriggerFiresOnceOnFirstEntryToRoomD() {
        val w = World()
        w.scene.loadSegment(ROOM_D, "from_c", w.state)
        assertEquals("Aquí dentro está muy oscuro.", w.scene.dialogue.current?.text)
        w.scene.dialogue.clear()
        w.scene.loadSegment(ROOM_D, "from_c", w.state)
        assertNull(w.scene.dialogue.current)
    }

    // ---------- Iluminación ----------

    @Test
    fun lightSourceModelsPositionRadiusIntensityTintAndState() {
        val l = LightSource(100f, 50f, 80f, Palette.LIGHT_WARM or 0xFF000000.toInt(), 0.8f)
        assertTrue(l.active)
        assertTrue(l.reaches(100f, 100f))
        assertFalse(l.reaches(100f, 200f))
        assertEquals(0.8f, l.effectiveIntensity(0f), 0.001f)
        l.active = false
        repeat(60) { l.update(dt) }
        assertEquals(0f, l.effectiveIntensity(0f), 0f)
        l.active = true
        repeat(60) { l.update(dt) }
        assertEquals(0.8f, l.effectiveIntensity(0f), 0.001f)
    }

    @Test
    fun flickerNeverBrightensBeyondBaseOrBelowZero() {
        val l = LightSource(0f, 0f, 50f, 0xFFFFFFFF.toInt(), 1f, flicker = 0.3f)
        var t = 0f
        repeat(500) {
            val k = l.effectiveIntensity(t)
            assertTrue(k in 0f..1f)
            t += 0.05f
        }
    }

    @Test
    fun roomsAreGenuinelyDarkAndLampsAreTheLightSource() {
        val def = TestRoomDefinition.create()
        for (seg in def.segments) {
            assertTrue("${seg.id}: no es lo bastante oscura", seg.ambientDark >= 0.75f)
            assertTrue(seg.lights.all { it.radius > 0f && it.intensity > 0f })
        }
        val a = def.segment(ROOM_A)
        val b = def.segment(ROOM_B)
        val c = def.segment(ROOM_C)
        val d = def.segment(ROOM_D)
        assertEquals("RoomD es la más oscura", d.ambientDark, def.segments.maxOf { it.ambientDark }, 0f)
        assertTrue(d.ambientDark > a.ambientDark)
        assertEquals("RoomD: lámpara aislada", 1, d.lights.size)
        assertTrue("RoomC: varias fuentes de luz", c.lights.size >= 3)
        assertEquals("RoomB: oscuridad fría", Palette.DARK_COLD, b.ambientColor)
        assertTrue("RoomB: más zonas oscuras que RoomA", b.darkZones.size > a.darkZones.size)
        assertEquals("RoomA: ambiente cálido", Palette.DARK_WARM, a.ambientColor)
    }

    @Test
    fun lampLightSourcesCoverTheirFurnitureButNotTheWholeRoom() {
        val d = TestRoomDefinition.create().segment(ROOM_D)
        val lamp = d.lights.first()
        val wd = d.objects.filterIsInstance<Wardrobe>().first()
        assertTrue("el armario de RoomD debe quedar a la luz de la lámpara", lamp.reaches(wd.centerX, wd.centerY))
        val farDoor = d.doors.first { it.locked }
        assertFalse("la puerta lejana de RoomD debe quedar a oscuras", lamp.reaches(farDoor.centerX, farDoor.centerY))
    }

    @Test
    fun playerGlowFollowsThePlayerAndHidesWhenHidden() {
        val w = World()
        w.walk(false, true, 20)
        assertEquals(w.scene.player.centerX, w.scene.playerGlow.x, 0.01f)
        val wd = w.wardrobe()
        w.standAt(wd.x + 10f)
        w.pressAction()
        w.step(60)
        assertFalse(w.scene.playerGlow.active)
    }

    // ---------- Render / configuración ----------

    @Test
    fun logicalResolutionIs320x180() {
        assertEquals(320, GameConfig.LOGICAL_WIDTH)
        assertEquals(180, GameConfig.LOGICAL_HEIGHT)
        val w = World()
        assertEquals(320f, w.scene.camera.viewWidth, 0f)
        assertEquals(180f, w.scene.camera.viewHeight, 0f)
    }

    @Test
    fun lightMaskIsHalfLogicalResolution() {
        assertEquals(GameConfig.LOGICAL_WIDTH / 2, LightingRenderer.MASK_W)
        assertEquals(GameConfig.LOGICAL_HEIGHT / 2, LightingRenderer.MASK_H)
    }

    @Test
    fun viewportScalesWithoutDistortion() {
        val v = Viewport()
        v.update(1920, 1080)
        assertEquals(6f, v.scale, 0.001f)
        assertEquals(0f, v.offsetX, 0.001f)
        assertEquals(0f, v.offsetY, 0.001f)
        v.update(2400, 1080)
        assertEquals(6f, v.scale, 0.001f)
        assertEquals(240f, v.offsetX, 0.001f)
    }

    @Test
    fun visualCorruptionStaysAtZero() {
        val w = World()
        w.walk(false, true, 100)
        assertEquals(0f, w.state.visualCorruption, 0f)
    }

    @Test
    fun noEnemiesOrFearSystemsExistYet() {
        // v0.3 solo prueba la mecánica de esconderse: nada reacciona a que el jugador esté oculto.
        val w = World()
        val wd = w.wardrobe()
        w.standAt(wd.x + 10f)
        w.pressAction()
        w.step(600)
        assertTrue(w.scene.player.isHidden)
        assertEquals(0f, w.state.visualCorruption, 0f)
    }
}
