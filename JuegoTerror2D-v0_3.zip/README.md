# Juego de Terror 2D — v0.3 (Interacción, cámara cercana, oscuridad y primera casa de prueba)

## Proyecto
Juego de terror psicológico 2D para Android con estética de dibujo infantil sobre papel que irá
degenerándose (crayón → crayón + grafito → grafito, rasguños, papel deteriorado).
100 % nativo (Kotlin + Android Canvas), sin motores externos, sin internet, sin backend.

## Versión actual
**v0.3.0** — La base técnica de v0.2 se convierte en una **pequeña casa explorable de cuatro
habitaciones**, con cámara cercana, oscuridad real iluminada por lámparas, un sistema genérico de
interacción y armarios donde esconderse. **No hay historia, enemigos ni puzzles**: es un prototipo
de gameplay y atmósfera.

## Cambios en v0.3

### 1. Corrección del encuadre (cámara cercana)
No se amplió la imagen: se cambió la **escala lógica del mundo** manteniendo 320×180.
- Personaje: 10×26 → **18×48** (≈ 27 % de la altura de pantalla; antes ≈ 14 %).
- Puertas 76 px, armarios 76×46, muebles y habitaciones rediseñados a esa escala.
- Habitaciones compactas (320–560 px de ancho). Zona muerta de cámara 14 px, seguimiento más ágil.
- Modos conservados: `FIXED` (habitación pequeña entera en pantalla) y `SIDE_SCROLLING`
  (sigue solo en horizontal, respeta límites, nunca se mueve en vertical).

### 2. Iluminación: el mundo es oscuro, las lámparas permiten ver
`LightingRenderer` ya no es una viñeta con círculos encima. Cada frame construye una **máscara de
oscuridad** (bitmap de 160×90 reutilizado):
1. se rellena con el color de la oscuridad de la habitación (`ambientDark` 0.80–0.94);
2. cada luz activa **abre un agujero suave** en la oscuridad (`PorterDuff.DST_OUT`);
3. las `DarkZone` añaden sombra incluso dentro de la luz;
4. la máscara se dibuja sobre el mundo ya renderizado → suelo, paredes, muebles, puertas y personaje
   solo se ven donde llega la luz;
5. cada luz tiñe su zona (cálida/fría).

Pipeline: `fondo → objetos → personaje → luz/máscara de oscuridad → viñeta → texto → HUD → fundido`.
El color se conserva dentro de la luz; la oscuridad es azul-violeta, no gris. Un resplandor tenue
alrededor del jugador evita perderlo del todo. Sin allocations por frame.

**`LightSource`** (`Light` es un alias): posición, radio, intensidad, tipo (`LAMP`, `GLOW`,
`FLASHLIGHT`, `AMBIENT_SPOT`), color/tinte, activa/inactiva (con fundido) y parpadeo opcional.
`Lamp` es la fuente fija de v0.3 y se dibuja con bombilla que se apaga y enciende.

### 3. Cuatro habitaciones (A ↔ B ↔ C ↔ D)
Nombres técnicos neutros; todas tienen puerta, armario distinto, lámpara y decoración:

| Sala | Ancho | Cámara | Prueba |
|---|---|---|---|
| `RoomA` | 320 | FIXED | Luz cálida, acogedora; armario con estrella |
| `RoomB` | 320 | FIXED | Luz fría parpadeante, más zonas oscuras; armario rayado |
| `RoomC` | 560 | SIDE_SCROLLING | Tres luces, interruptor que apaga una; armario verde |
| `RoomD` | 420 | SIDE_SCROLLING | La más oscura: una lámpara aislada, puerta bloqueada; armario con luna |

Todas las posiciones son literales. `SeededRandom` solo varía trazos, arañazos del armario y
detalles de decoración — nunca posiciones críticas, puertas, armarios, colisiones, spawns ni lógica.

### 4. Sistema de interacción genérico (`interaction/`)
`Interactable` (id, texto/icono del botón, zona, `canInteract`, `executeInteraction`),
`InteractionContext` (bus de eventos, estado, jugador, segmento) e `InteractionResult`
(mensaje, transición, ignorado). La escena busca el interactuable más cercano, **el botón de acción
muestra su icono y texto (`ABRIR`, `ESCONDERSE`, `SALIR`, `EXAMINAR`, `ENCENDER`…)** y al pulsar
llama a `executeInteraction()`. No hay lógica por tipo dentro del botón.
Implementan `Interactable`: `Door`, `Wardrobe`, `ExamineSpot`, `LightSwitch`.

### 5. Puertas
`Door` usa el sistema genérico: abre, cierra, define destino (`DoorTarget`) y spawn de llegada, y
puede estar **bloqueada** ("La puerta está cerrada."). Transición con fases (`SceneTransition`):
puerta abriéndose → fundido a negro → carga → fundido de entrada.

### 6. Armarios y esconderse
`Wardrobe`: `CLOSED → abriendo → cerrándose → OCCUPIED → abriendo → cerrándose → CLOSED`.
`Player.state` = `NORMAL / ENTERING_HIDE / HIDDEN / LEAVING_HIDE` (+ `isHidden`, `GameState.playerHidden`).
Escondido el personaje no se dibuja, no se mueve y deja una rendija con dos ojos que brillan.
Al salir reaparece delante del armario (`exitX`), dentro de los límites y apoyado en el suelo.
**No hay enemigos, IA, detección ni miedo** (llegarán en v0.8).

### 7. Texto, diálogos y eventos
- `DialogueManager`: mensajes breves que se cierran solos y diálogos de varias líneas
  (`DialogueLine(personaje, texto)`, avanzar con la acción, callback al terminar). Cuadro de texto
  con papel y borde de crayón que se escribe letra a letra (no es UI de Android).
- `EventBus` + `EventType` (`ON_ENTER_ROOM`, `ON_INTERACT`, `ON_DOOR_OPEN`, `ON_OBJECT_EXAMINED`,
  `ON_HIDE`, `ON_EXIT_HIDE`) y `EventTrigger` declarativo en `SceneDefinition`
  (ejemplo: al entrar por primera vez en RoomD aparece un texto).

### 8. Se conserva
Canvas, Game Loop, `SceneManager`, `RoomSegment`, `Door`, `Camera`, `InputController`,
`CollisionSystem`, `SeededRandom`, `BaseRenderer`, `LightingRenderer`, `visualCorruption = 0.0`,
resolución 320×180 y `.github/workflows/build.yml` (sin cambios). El overlay de depuración
(`GameConfig.DEBUG_OVERLAY`) queda apagado.

## Arquitectura (paquete `com.terror2d`)
| Pieza | Archivo |
|---|---|
| Canvas / Game / Loop / Estado / Viewport / Cámara | `core/` |
| Input (izquierda, derecha, acción genérica) | `input/InputController.kt` |
| Interacción | `interaction/Interaction.kt` |
| Eventos | `events/GameEvents.kt` |
| Texto y diálogos | `ui/Dialogue.kt` |
| Escena, segmentos, transición, casa de prueba | `scene/` |
| Objetos, jugador, puertas, armarios, luces | `world/` |
| Render (crayón, máscara de oscuridad, HUD, texto) | `render/` |
| SeededRandom | `util/SeededRandom.kt` |

## Tests
`./gradlew testDebugUnitTest` — movimiento (izquierda/derecha, sin Y libre), suelo, límites,
colisiones, **encuadre cercano**, cámara FIXED/SIDE_SCROLLING, puertas (estado, bloqueo, transición,
destino y spawn), **cuatro habitaciones y conexiones**, recorrido A→B→C→D→C→B→A, interacción
(botón, examinar, interruptor), **armarios** (detectar, entrar, `isHidden`, salir, posición),
texto/diálogos, eventos, iluminación (`LightSource`, habitaciones oscuras, cobertura de lámparas),
seed determinista, resolución 320×180 y máscara de luz.

## Build (GitHub Actions)
`.github/workflows/build.yml` (sin cambios): JDK 17, Gradle 8.7, regenera `gradle-wrapper.jar` si
falta, `./gradlew assembleDebug`, artifact **`JuegoTerror2D-debug-apk`** y después tests unitarios.
APK: pestaña **Actions** → última ejecución → **Artifacts**.

```
Claude → ZIP → Descomprimir → Subir a GitHub → Actions → build.yml → APK
```
La raíz del ZIP es la raíz del repositorio.

## Controles
Táctil: `←` `→` abajo a la izquierda; botón de acción abajo a la derecha (solo aparece con algo
al alcance, con su etiqueta). Teclado: flechas o A/D; Espacio, Enter o E = acción.

## Próximo paso
**v0.4 — Primera habitación real de la historia**, sobre este modelo de cámara, iluminación,
navegación e interacción.
