"""Objetos pixelados con ESCALA CANÓNICA ÚNICA (cada píxel = 0.5 px lógicos, igual que el protagonista).

Un solo dibujo por objeto: suelo, cama, mano, inventario, HOLD_ITEM y PLACED usan EXACTAMENTE este sprite.
  - Ranita de peluche: 32x32 px  = 16x16 lógicos
  - Caja de medicinas: 16x22 px  = 8x11 lógicos (la huella de las cajas de v0.5)
  - Vaso de agua:      14x22 px  = 7x11 lógicos
"""
import numpy as np
from pixlib import Cv, P

# colores propios de los objetos (se añaden al final de su paleta)
FROG = ['T', 'OUT', 'G', 'G_L', 'G_S', 'G_D', 'BELLY', 'BELLY_S', 'WHITE', 'EYEW', 'PUPIL', 'HI', 'CROSS', 'CROSS_D', 'STITCH',
        'BLUSH', 'MOUTH', 'CAP', 'CAP_S']
FROG_PAL = [
    (0, 0, 0, 0), (0x2B, 0x1A, 0x22, 255),
    (0x7C, 0xC9, 0x6B, 255), (0xA8, 0xE6, 0x8E, 255), (0x55, 0xA4, 0x48, 255), (0x3C, 0x7C, 0x36, 255),
    (0xE4, 0xF4, 0xC4, 255), (0xBF, 0xD9, 0x9C, 255), (0xFA, 0xF6, 0xEC, 255), (0xFF, 0xFF, 0xFF, 255),
    (0x1C, 0x14, 0x24, 255), (0xFF, 0xF6, 0xD8, 255), (0x3C, 0x9A, 0x4C, 255), (0x2A, 0x70, 0x38, 255),
    (0x5A, 0x4A, 0x3A, 255), (0xF2, 0x9A, 0x8C, 255), (0x6A, 0x24, 0x2E, 255), (0xF4, 0xEE, 0xDC, 255), (0xC9, 0xC2, 0xB0, 255),
]
FI = {n: i for i, n in enumerate(FROG)}


def frog():
    """Ranita pequeña y tierna: cabeza enorme, ojos saltones, cuerpo pequeño, brazos y patas visibles, costuras, gorrito con cruz."""
    cv = Cv(32, 32)
    g = FI

    def sh(m, base='G', light='G_L', shadow='G_S', deep='G_D'):
        cv.shaded(m, g[base], g[light], g[shadow], g[deep], hb=1, sb=1, db=1)

    # patas traseras (sentada) y cuerpo pequeño
    sh(cv.ellipse(8, 27, 5, 3))
    sh(cv.ellipse(24, 27, 5, 3))
    # patas con pies
    for fx in (3, 6, 9):
        cv.put(fx, 29, g['G_S'])
    for fx in (22, 25, 28):
        cv.put(fx, 29, g['G_S'])
    body = cv.ellipse(16, 22, 8, 7)
    sh(body)
    belly = cv.ellipse(16, 24, 5, 4)
    cv.shaded(belly, g['BELLY'], g['HI'], g['BELLY_S'], None, hb=1, sb=1)
    # cruz verde de la farmacia en la barriga
    for (x, y) in [(16, 21), (16, 22), (16, 23), (16, 24), (14, 22), (15, 22), (17, 22), (18, 22)]:
        cv.put(x, y, g['CROSS'])
    cv.put(16, 24, g['CROSS_D']); cv.put(18, 22, g['CROSS_D'])
    # bracitos
    sh(cv.capsule((9, 17), (5, 23), 1.7, 1.4))
    sh(cv.capsule((23, 17), (27, 23), 1.7, 1.4))
    cv.put(4, 24, g['G_S']); cv.put(5, 24, g['G_S']); cv.put(28, 24, g['G_S']); cv.put(27, 24, g['G_S'])
    # cabeza grande y ancha
    head = cv.ellipse(16, 12, 12, 7)
    sh(head)
    # ojos saltones
    for cx in (9, 23):
        bump = cv.ellipse(cx, 6, 4, 4)
        sh(bump)
        cv.a[cv.ellipse(cx, 6, 3, 3)] = g['EYEW']
        cv.a[cv.ellipse(cx + (1 if cx < 16 else -1), 7, 1, 1)] = g['PUPIL']
        cv.put(cx - 1, 5, g['HI']); cv.put(cx - 2, 6, g['HI'])
        cv.put(cx - 3, 6, g['STITCH']) if False else None
    # mejillas y sonrisa
    cv.a[cv.ellipse(7, 14, 2, 1)] = g['BLUSH']
    cv.a[cv.ellipse(25, 14, 2, 1)] = g['BLUSH']
    for (x, y) in [(10, 13), (11, 14), (12, 15), (13, 15), (14, 15), (15, 15), (16, 15), (17, 15), (18, 15), (19, 15), (20, 14), (21, 13)]:
        cv.put(x, y, g['MOUTH'])
    # gorrito blanco con cruz
    cap = cv.poly([(12, 5), (20, 5), (21, 3), (20, 1), (12, 1), (11, 3)])
    cv.shaded(cap, g['CAP'], g['HI'], g['CAP_S'], None, hb=1, sb=1)
    for (x, y) in [(16, 1), (16, 2), (16, 3), (15, 2), (17, 2)]:
        cv.put(x, y, g['CROSS'])
    # costuras (puntadas) en cuerpo y cabeza
    for x in range(11, 22, 2):
        cv.put(x, 18, g['STITCH'])
    for y in range(26, 29, 2):
        cv.put(16, y, g['STITCH'])
    cv.put(12, 25, g['STITCH']); cv.put(20, 25, g['STITCH'])
    cv.outline(g['OUT'])
    return cv, FROG_PAL, (16, 26)       # agarre: la barriguita / patitas


# ---- caja de medicinas 16x22 ----
def pill_box(body, light, shadow, accent, name_color):
    pal = [(0, 0, 0, 0), (0x2B, 0x1A, 0x22, 255), body, light, shadow, accent, (0xF8, 0xF2, 0xE0, 255), name_color,
           (0x6A, 0x5A, 0x4A, 255)]
    cv = Cv(16, 22)
    m = cv.rect(1, 1, 14, 20)
    cv.shaded(m, 2, 3, 4, None, hb=1, sb=1)
    # solapa superior
    cv.a[cv.rect(1, 1, 14, 3)] = 3
    cv.a[cv.rect(1, 3, 14, 3)] = 4
    # etiqueta blanca y cruz
    cv.a[cv.rect(3, 6, 12, 15)] = 6
    for (x, y) in [(7, 7), (8, 7), (7, 8), (8, 8), (6, 9), (7, 9), (8, 9), (9, 9), (6, 10), (7, 10), (8, 10), (9, 10), (7, 11), (8, 11), (7, 12), (8, 12)]:
        pass
    cv.a[cv.rect(7, 7, 8, 12)] = 5
    cv.a[cv.rect(5, 9, 10, 10)] = 5
    # líneas de texto
    cv.a[cv.rect(4, 13, 11, 13)] = 8
    cv.a[cv.rect(4, 15, 9, 15)] = 8
    cv.a[cv.rect(3, 18, 12, 18)] = 7       # franja con el color de la marca
    cv.outline(1)
    return cv, pal, (8, 13)


def glass():
    """Vaso transparente con agua (14x22)."""
    pal = [(0, 0, 0, 0), (0x2B, 0x1A, 0x22, 255), (0xDD, 0xEE, 0xF8, 255), (0xBF, 0xE4, 0xFF, 255), (0x5A, 0xA6, 0xE8, 255),
           (0x3C, 0x84, 0xC8, 255), (0xFF, 0xFF, 0xFF, 255), (0x9A, 0xC8, 0xE0, 255)]
    cv = Cv(14, 22)
    body = cv.poly([(1, 1), (12, 1), (11, 20), (2, 20)])
    cv.a[body] = 2
    water = cv.poly([(2, 8), (11, 8), (10, 19), (3, 19)])
    cv.shaded(water, 4, 3, 5, None, hb=1, sb=1)
    cv.a[cv.rect(2, 8, 11, 8) & body] = 3
    cv.a[cv.rect(3, 3, 3, 15) & body] = 6        # brillo del cristal
    cv.a[cv.rect(10, 4, 10, 17) & body] = 7
    cv.a[cv.rect(2, 19, 11, 20) & body] = 7
    cv.outline(1)
    return cv, pal, (7, 14)


def all_items():
    out = {}
    cv, pal, grip = frog()
    out['frog_plush'] = (cv, pal, grip)
    out['pill_box_blue'] = pill_box((0x5A, 0x8F, 0xE0, 255), (0x86, 0xB4, 0xF2, 255), (0x3A, 0x68, 0xB4, 255), (0x3C, 0x84, 0xC8, 255), (0x2F, 0x5F, 0xA8, 255))
    out['pill_box_orange'] = pill_box((0xE8, 0x94, 0x4A, 255), (0xF8, 0xB8, 0x78, 255), (0xB8, 0x68, 0x28, 255), (0xD9, 0x4F, 0x3D, 255), (0xB8, 0x4A, 0x1A, 255))
    out['pill_box_white'] = pill_box((0xF2, 0xEE, 0xE0, 255), (0xFF, 0xFF, 0xF4, 255), (0xC9, 0xC4, 0xB4, 255), (0x4F, 0x9A, 0x3E, 255), (0x3C, 0x84, 0x36, 255))
    cv, pal, grip = glass()
    out['water_glass'] = (cv, pal, grip)
    return out
