package com.terror2d.events

import com.terror2d.core.GameState
import com.terror2d.ui.DialogueManager

/**
 * Tipos de evento del juego. Lista corta a propósito: la estructura es ampliable
 * (añadir un valor aquí y publicarlo con [EventBus.post]).
 */
enum class EventType {
    /** Se ha cargado una habitación (segmento). sourceId = id del segmento. */
    ON_ENTER_ROOM,

    /** Se ha interactuado con algo. sourceId = id del interactuable. */
    ON_INTERACT,

    /** Se ha abierto una puerta. sourceId = id de la puerta. */
    ON_DOOR_OPEN,

    /** Se ha examinado un objeto (texto). sourceId = id del objeto. */
    ON_OBJECT_EXAMINED,

    /** El jugador ha terminado de esconderse. sourceId = id del escondite. */
    ON_HIDE,

    /** El jugador ha terminado de salir del escondite. sourceId = id del escondite. */
    ON_EXIT_HIDE,

    /** Se ha activado un hito narrativo por primera vez. sourceId = nombre del hito. */
    ON_STORY_FLAG,

    /** El jugador ha terminado de recoger un objeto. sourceId = id del objeto. */
    ON_ITEM_PICKED,

    /** El jugador ha entregado un objeto. sourceId = id del objeto. */
    ON_ITEM_GIVEN,

    /** El jugador ha dejado un objeto en su sitio. sourceId = id del objeto. */
    ON_ITEM_PLACED,

    /** El jugador ha abierto un documento para leerlo. sourceId = id del documento. */
    ON_DOCUMENT_READ,

    /** Empieza el puzzle de medicamentos (cambio a primera persona). sourceId = id del puzzle. */
    ON_PUZZLE_STARTED,

    /** Las tres cajas están en su orden correcto. sourceId = id del puzzle. */
    MEDICINE_PUZZLE_COMPLETED,

    /** Termina el puzzle y se vuelve a tercera persona. sourceId = id del puzzle. */
    ON_PUZZLE_ENDED
}

/** Un evento ya ocurrido. */
class GameEvent(val type: EventType, val sourceId: String, val segmentId: String) {
    override fun toString(): String = "$type:$sourceId"
}

fun interface EventListener {
    fun onEvent(event: GameEvent)
}

/**
 * Bus de eventos sencillo. Los emisores publican, los oyentes reaccionan; ninguno se conoce.
 * Pensado para eventos puntuales (no se publican por frame).
 */
class EventBus {
    private val byType = HashMap<EventType, ArrayList<EventListener>>()
    private val all = ArrayList<EventListener>()

    /** Últimos eventos publicados (para depuración y tests). */
    private val history = ArrayList<GameEvent>()

    val postedCount: Int get() = history.size

    val last: GameEvent? get() = if (history.isEmpty()) null else history[history.size - 1]

    fun subscribe(type: EventType, listener: EventListener) {
        byType.getOrPut(type) { ArrayList() }.add(listener)
    }

    fun subscribeAll(listener: EventListener) {
        all.add(listener)
    }

    fun post(type: EventType, sourceId: String, segmentId: String = "") {
        val e = GameEvent(type, sourceId, segmentId)
        history.add(e)
        if (history.size > MAX_HISTORY) history.removeAt(0)
        val specific = byType[type]
        if (specific != null) {
            for (i in 0 until specific.size) specific[i].onEvent(e)
        }
        for (i in 0 until all.size) all[i].onEvent(e)
    }

    /** ¿Se ha publicado alguna vez un evento de este tipo (y, opcionalmente, de esta fuente)? */
    fun wasPosted(type: EventType, sourceId: String? = null): Boolean {
        for (i in 0 until history.size) {
            val e = history[i]
            if (e.type == type && (sourceId == null || e.sourceId == sourceId)) return true
        }
        return false
    }

    fun clearHistory() {
        history.clear()
    }

    companion object {
        private const val MAX_HISTORY = 64
    }
}

/** Lo que una regla de evento puede usar al dispararse: el evento, el texto y el estado global. */
class TriggerContext(val event: GameEvent, val dialogue: DialogueManager, val state: GameState)

/**
 * Regla de evento declarativa: "cuando ocurra X (opcionalmente de la fuente Y), haz Z".
 * Vive en la [com.terror2d.scene.SceneDefinition]; la escena la conecta al bus.
 */
class EventTrigger(
    val type: EventType,
    val sourceId: String? = null,
    val once: Boolean = true,
    val action: (TriggerContext) -> Unit
) {
    var fired: Boolean = false
        private set

    fun matches(e: GameEvent): Boolean =
        e.type == type && (sourceId == null || sourceId == e.sourceId) && !(once && fired)

    fun fire(ctx: TriggerContext) {
        fired = true
        action(ctx)
    }
}
