package com.terror2d.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import com.terror2d.pixel.EyeState
import com.terror2d.pixel.LightingSample
import com.terror2d.pixel.MouthState
import com.terror2d.pixel.PixelCharacterData
import com.terror2d.pixel.PixelPose
import com.terror2d.pixel.PixelRasterizer
import kotlin.math.round

/**
 * Dibuja personajes y objetos pixelados. Recibe datos ([PixelCharacterData]), pose, cara, orientación,
 * posición, iluminación y opacidad: no sabe quién es el personaje.
 *
 * Cada capa se convierte en ARGB con [PixelRasterizer] (iluminación y cara incluidas) y se vuelca a un Bitmap
 * que se CACHEA por (personaje, capa, pose, ojos, boca, nivel de luz quantizado): normalmente solo se crean unos
 * pocos bitmaps y el frame se reduce a drawBitmap sin filtrado (nearest-neighbor, píxeles nítidos, sin blur).
 *
 * Orden de un personaje que sostiene algo: base -> OBJETO -> mano delantera (primer plano). Así los dedos quedan
 * por encima del objeto y se ve realmente sujeto.
 */
class PlayerPixelRenderer {

    private val paint = Paint().apply {
        isAntiAlias = false
        isFilterBitmap = false
        isDither = false
    }

    private val cache = HashMap<Long, Bitmap>()
    private val quantized = LightingSample()
    private var lastCorruption = 0f
    private var buffer = IntArray(0)

    /**
     * Dibuja un personaje (con cara, objeto en la mano y mano delantera).
     * @param centerX / bottomY punto del suelo bajo el centro del cuerpo (coordenadas del mundo).
     * @param held objeto sostenido (null = manos libres); se alinea con el punto de agarre de la pose.
     */
    fun render(
        canvas: Canvas,
        data: PixelCharacterData,
        pose: PixelPose,
        eyes: EyeState,
        mouth: MouthState,
        flip: Boolean,
        centerX: Float,
        bottomY: Float,
        alpha: Float,
        light: LightingSample,
        corruption: Float,
        held: PixelCharacterData? = null
    ) {
        if (alpha <= 0.01f) return
        syncCorruption(corruption)
        light.quantizeInto(quantized)
        val lightKey = light.key()
        val base = bitmap(data, pose, PixelRasterizer.PART_BASE, eyes, mouth, lightKey, corruption)
        val frontFrame = data.frontFrame(pose)
        val front = if (frontFrame != null) bitmap(data, pose, PixelRasterizer.PART_FRONT, eyes, mouth, lightKey, corruption) else null
        val heldBmp = if (held != null) bitmap(held, PixelPose.IDLE, PixelRasterizer.PART_ALL, EyeState.OPEN, MouthState.NEUTRAL, lightKey, corruption) else null

        paint.alpha = (alpha.coerceIn(0f, 1f) * 255f).toInt()
        canvas.save()
        canvas.translate(round(centerX), round(bottomY))
        if (flip) canvas.scale(-1f, 1f)
        canvas.scale(data.scale, data.scale)
        canvas.drawBitmap(base, -data.anchorX.toFloat(), -data.height.toFloat(), paint)
        val hand = data.hand(pose)
        if (held != null && heldBmp != null && hand != null) {
            val k = held.scale / data.scale
            canvas.save()
            canvas.translate(hand[0].toFloat(), hand[1].toFloat())
            canvas.scale(k, k)
            canvas.drawBitmap(heldBmp, -held.gripX.toFloat(), -held.gripY.toFloat(), paint)
            canvas.restore()
        }
        if (front != null) canvas.drawBitmap(front, -data.anchorX.toFloat(), -data.height.toFloat(), paint)
        canvas.restore()
    }

    /** Dibuja un objeto apoyado en el suelo / en un mueble: centro de la base en (centerX, bottomY). */
    fun renderStanding(
        canvas: Canvas,
        item: PixelCharacterData,
        centerX: Float,
        bottomY: Float,
        alpha: Float,
        light: LightingSample,
        corruption: Float,
        flip: Boolean = false
    ) {
        if (alpha <= 0.01f) return
        syncCorruption(corruption)
        light.quantizeInto(quantized)
        val bmp = bitmap(item, PixelPose.IDLE, PixelRasterizer.PART_ALL, EyeState.OPEN, MouthState.NEUTRAL, light.key(), corruption)
        paint.alpha = (alpha.coerceIn(0f, 1f) * 255f).toInt()
        canvas.save()
        canvas.translate(round(centerX), round(bottomY))
        if (flip) canvas.scale(-1f, 1f)
        canvas.scale(item.scale, item.scale)
        canvas.drawBitmap(bmp, -item.anchorX.toFloat(), -item.height.toFloat(), paint)
        canvas.restore()
    }

    /** Dibuja un sprite (objeto o mano) centrado en (cx, cy) con un factor extra de escala (HUD). */
    fun renderCentered(
        canvas: Canvas,
        item: PixelCharacterData,
        cx: Float,
        cy: Float,
        extraScale: Float,
        light: LightingSample,
        corruption: Float
    ) {
        syncCorruption(corruption)
        light.quantizeInto(quantized)
        val bmp = bitmap(item, PixelPose.IDLE, PixelRasterizer.PART_ALL, EyeState.OPEN, MouthState.NEUTRAL, light.key(), corruption)
        paint.alpha = 255
        canvas.save()
        canvas.translate(cx, cy)
        val k = item.scale * extraScale
        canvas.scale(k, k)
        canvas.drawBitmap(bmp, -item.width / 2f, -item.height / 2f, paint)
        canvas.restore()
    }

    private fun syncCorruption(corruption: Float) {
        if (kotlin.math.abs(corruption - lastCorruption) > 0.02f) {
            clear()
            lastCorruption = corruption
        }
    }

    private fun bitmap(
        data: PixelCharacterData,
        pose: PixelPose,
        part: Int,
        eyes: EyeState,
        mouth: MouthState,
        lightKey: Int,
        corruption: Float
    ): Bitmap {
        val faceKey = if (part == PixelRasterizer.PART_FRONT) 0 else (eyes.ordinal shl 3) or mouth.ordinal
        val key = (System.identityHashCode(data).toLong() shl 32) or
            (part.toLong() shl 30) or (pose.ordinal.toLong() shl 22) or (faceKey.toLong() shl 12) or lightKey.toLong()
        var bmp = cache[key]
        if (bmp == null) {
            // al desbordar se vacía SIN reciclar: otro bitmap del mismo frame podría seguir en uso
            if (cache.size >= MAX_CACHED) cache.clear()
            val n = data.width * data.height
            if (buffer.size < n) buffer = IntArray(n)
            val e = if (part == PixelRasterizer.PART_FRONT) null else eyes
            val m = if (part == PixelRasterizer.PART_FRONT) null else mouth
            PixelRasterizer.rasterize(data, pose, false, quantized, corruption, buffer, e, m, part)
            bmp = Bitmap.createBitmap(data.width, data.height, Bitmap.Config.ARGB_8888)
            bmp.setPixels(buffer, 0, data.width, 0, 0, data.width, data.height)
            cache[key] = bmp
        }
        return bmp
    }

    fun clear() {
        for (b in cache.values) b.recycle()
        cache.clear()
    }

    companion object {
        private const val MAX_CACHED = 192
    }
}
