package com.terror2d.inventory

import com.terror2d.core.WorldMode

/**
 * Definición de un objeto del juego: dato puro y reutilizable.
 * [icon] es el nombre del dibujo (lo interpreta el renderer); [usable] marca los que se pueden entregar/usar;
 * [world] es el mundo en el que el objeto existe de forma natural (preparado para NORMAL/TRAUMA).
 */
class ItemDef(
    val id: String,
    val name: String,
    val icon: String,
    val description: String = "",
    val stackable: Boolean = false,
    val maxStack: Int = 1,
    val usable: Boolean = true,
    val world: WorldMode = WorldMode.NORMAL
)

/** Catálogo de objetos. Los nuevos objetos (v0.6 puzzle, v0.7 peluche...) se registran aquí. */
object ItemRegistry {
    const val WATER_GLASS = "water_glass"
    const val FROG_PLUSH = "frog_plush"
    const val PILL_BOX_BLUE = "pill_box_blue"
    const val PILL_BOX_ORANGE = "pill_box_orange"
    const val PILL_BOX_WHITE = "pill_box_white"

    private val defs = HashMap<String, ItemDef>()

    init {
        register(ItemDef(WATER_GLASS, "Vaso de agua", "water_glass", "Un vaso con agua para mamá."))
        register(ItemDef(FROG_PLUSH, "Ranita", "frog_plush", "El peluche de rana."))
        register(ItemDef(PILL_BOX_BLUE, "Caja azul", "pill_box_blue", "Una cajita de las pastillas de mamá."))
        register(ItemDef(PILL_BOX_ORANGE, "Caja naranja", "pill_box_orange", "Una cajita de las pastillas de mamá."))
        register(ItemDef(PILL_BOX_WHITE, "Caja blanca", "pill_box_white", "Una cajita de las pastillas de mamá."))
    }

    fun register(def: ItemDef) {
        defs[def.id] = def
    }

    fun get(id: String): ItemDef? = defs[id]

    fun require(id: String): ItemDef = defs[id] ?: throw IllegalArgumentException("Objeto no registrado: $id")

    fun contains(id: String): Boolean = defs.containsKey(id)

    val all: Collection<ItemDef> get() = defs.values
}

/** Una casilla del inventario. */
class ItemStack(val id: String, var quantity: Int)

/**
 * Inventario reutilizable: ID, nombre, icono (vía [ItemRegistry]), cantidad y objeto en la mano.
 * Lógica pura (sin Android). Capacidad limitada; los objetos apilables suman cantidad hasta su máximo.
 *
 * El niño sostiene UN objeto a la vez ([held]); el resto de objetos puede estar en las casillas.
 */
class Inventory(val capacity: Int = 8) {

    private val stacks = ArrayList<ItemStack>()

    /** Objeto que lleva en las manos (null = manos libres). */
    var held: String? = null
        private set

    val size: Int get() = stacks.size

    val isEmpty: Boolean get() = stacks.isEmpty()

    fun stack(index: Int): ItemStack = stacks[index]

    fun count(id: String): Int {
        for (i in 0 until stacks.size) if (stacks[i].id == id) return stacks[i].quantity
        return 0
    }

    fun has(id: String): Boolean = count(id) > 0

    /** Añade objetos. Devuelve false (sin cambios) si no caben o el objeto no está registrado. */
    fun add(id: String, quantity: Int = 1): Boolean {
        val def = ItemRegistry.get(id) ?: return false
        if (quantity <= 0) return false
        for (i in 0 until stacks.size) {
            val s = stacks[i]
            if (s.id == id) {
                if (!def.stackable || s.quantity + quantity > def.maxStack) return false
                s.quantity += quantity
                return true
            }
        }
        if (stacks.size >= capacity || quantity > def.maxStack) return false
        stacks.add(ItemStack(id, quantity))
        return true
    }

    /** Quita objetos. Devuelve false (sin cambios) si no hay suficientes. Si era el objeto en mano, la libera. */
    fun remove(id: String, quantity: Int = 1): Boolean {
        for (i in 0 until stacks.size) {
            val s = stacks[i]
            if (s.id != id) continue
            if (s.quantity < quantity) return false
            s.quantity -= quantity
            if (s.quantity == 0) {
                stacks.removeAt(i)
                if (held == id) held = null
            }
            return true
        }
        return false
    }

    /** Pone un objeto del inventario en las manos. Devuelve false si no lo tiene. */
    fun hold(id: String): Boolean {
        if (!has(id)) return false
        held = id
        return true
    }

    /** Libera las manos (el objeto sigue en el inventario). */
    fun release() {
        held = null
    }

    fun isHolding(id: String): Boolean = held == id

    fun clear() {
        stacks.clear()
        held = null
    }
}
