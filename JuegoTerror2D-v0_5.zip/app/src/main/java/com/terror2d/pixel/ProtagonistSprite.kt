package com.terror2d.pixel

/** Lienzo de índices de paleta con primitivas mínimas (solo para construir los datos del personaje). */
class PixelCanvas(val w: Int, val h: Int) {
    val px = IntArray(w * h)

    fun set(x: Int, y: Int, c: Int) {
        if (x in 0 until w && y in 0 until h) px[y * w + x] = c
    }

    fun get(x: Int, y: Int): Int = if (x in 0 until w && y in 0 until h) px[y * w + x] else 0

    fun rect(x0: Int, y0: Int, x1: Int, y1: Int, c: Int) {
        for (y in y0..y1) for (x in x0..x1) set(x, y, c)
    }

    fun ellipse(cx: Int, cy: Int, rx: Int, ry: Int, c: Int) {
        for (y in cy - ry..cy + ry) for (x in cx - rx..cx + rx) {
            val dx = (x - cx).toFloat() / (rx + 0.5f)
            val dy = (y - cy).toFloat() / (ry + 0.5f)
            if (dx * dx + dy * dy <= 1f) set(x, y, c)
        }
    }

    /** Línea de 2 px de grosor (Bresenham). */
    fun thickLine(x0: Int, y0: Int, x1: Int, y1: Int, c: Int) {
        var x = x0
        var y = y0
        val dx = kotlin.math.abs(x1 - x0)
        val dy = -kotlin.math.abs(y1 - y0)
        val sx = if (x0 < x1) 1 else -1
        val sy = if (y0 < y1) 1 else -1
        var err = dx + dy
        while (true) {
            set(x, y, c)
            set(x + 1, y, c)
            set(x, y + 1, c)
            if (x == x1 && y == y1) break
            val e2 = 2 * err
            if (e2 >= dy) {
                err += dy
                x += sx
            }
            if (e2 <= dx) {
                err += dx
                y += sy
            }
        }
    }

    /** Contorno de 1 píxel alrededor de todo lo dibujado (4 vecinos). */
    fun outline(c: Int) {
        val snap = px.copyOf()
        for (y in 0 until h) for (x in 0 until w) {
            if (snap[y * w + x] != 0) continue
            val n = (y > 0 && snap[(y - 1) * w + x] != 0) ||
                (y < h - 1 && snap[(y + 1) * w + x] != 0) ||
                (x > 0 && snap[y * w + x - 1] != 0) ||
                (x < w - 1 && snap[y * w + x + 1] != 0)
            if (n) px[y * w + x] = c
        }
    }
}

/**
 * EL PROTAGONISTA (definitivo): un niño de 8 años, pixel art de 48x64 (50 px visibles), de perfil
 * mirando a la derecha (el renderer lo voltea). Pelo castaño despeinado, suéter de lana naranja con una
 * línea roja, pantalón caqui, zapatos blancos, bufanda corta rojo oscuro y una pequeña marca en la mejilla.
 *
 * Se genera una vez con primitivas y queda como matriz de índices (17 colores): el renderer no sabe quién es.
 * Cada pose es solo un conjunto de parámetros ([PoseParams]); los brazos tienen varios modos
 * (colgando, sosteniendo, entregando, recogiendo).
 */
object ProtagonistSprite {

    const val W = 48
    const val H = 64
    const val CX = 23

    val PALETTE: IntArray = intArrayOf(
        0x00000000,
        0xFF2B1A22.toInt(), // 1 contorno
        0xFF7A4A2A.toInt(), // 2 cabello castaño
        0xFFFFD2A8.toInt(), // 3 piel
        0xFFE5A57F.toInt(), // 4 sombra de piel
        0xFFF08A2E.toInt(), // 5 suéter naranja
        0xFFC96A1A.toInt(), // 6 sombra del suéter
        0xFFB89968.toInt(), // 7 pantalón caqui
        0xFF8E7448.toInt(), // 8 sombra del pantalón
        0xFFF4F0E6.toInt(), // 9 zapatos blancos
        0xFF1C1424.toInt(), // 10 ojo
        0xFFD03A2E.toInt(), // 11 línea roja
        0xFFFFF6D8.toInt(), // 12 brillo
        0xFF8E1F2E.toInt(), // 13 bufanda
        0xFF5E1220.toInt(), // 14 sombra de la bufanda
        0xFFB5543F.toInt(), // 15 marca del rostro
        0xFFB8B4C8.toInt()  // 16 sombra de los zapatos
    )

    /** Paleta alternativa (recuerdos): mismos datos, otros colores. */
    val PALETTE_FLASHBACK: IntArray = intArrayOf(
        0x00000000,
        0xFF3A2A20.toInt(), 0xFF7A6A52.toInt(), 0xFFE8D8B8.toInt(), 0xFFC8B590.toInt(),
        0xFFB8A888.toInt(), 0xFF8E7F63.toInt(), 0xFF9A8E78.toInt(), 0xFF6F644F.toInt(),
        0xFFEFE6D0.toInt(), 0xFF2A2018.toInt(), 0xFFA89870.toInt(), 0xFFFFF8E8.toInt(),
        0xFF7A6C54.toInt(), 0xFF5A4E3C.toInt(), 0xFF9A8868.toInt(), 0xFFCFC6B0.toInt()
    )

    private const val ARM_HANG = 0
    private const val ARM_HOLD = 1
    private const val ARM_GIVE = 2
    private const val ARM_PICKUP = 3

    private class PoseParams(
        val bob: Int = 0,
        val frontLeg: Int = 0,
        val backLeg: Int = 0,
        val headDx: Int = 0,
        val crouch: Int = 0,
        val eyesClosed: Boolean = false,
        val arms: Int = ARM_HANG
    )

    fun create(): PixelCharacterData {
        val n = PixelPose.values().size
        val frames = arrayOfNulls<IntArray>(n)
        val hands = arrayOfNulls<IntArray>(n)
        fun put(pose: PixelPose, p: PoseParams) {
            frames[pose.ordinal] = paint(p)
            val top = p.bob + p.crouch
            when (p.arms) {
                ARM_HOLD -> hands[pose.ordinal] = intArrayOf(9, 41 + top - H)
                ARM_GIVE -> hands[pose.ordinal] = intArrayOf(15, 38 + top - H)
            }
        }
        put(PixelPose.IDLE, PoseParams())
        put(PixelPose.WALK_1, PoseParams(frontLeg = 4, backLeg = -4))
        put(PixelPose.WALK_2, PoseParams(bob = -1, frontLeg = 1, backLeg = -1))
        put(PixelPose.WALK_3, PoseParams(frontLeg = -4, backLeg = 4))
        put(PixelPose.PICKUP, PoseParams(crouch = 4, headDx = 2, arms = ARM_PICKUP))
        put(PixelPose.HOLD_ITEM, PoseParams(arms = ARM_HOLD))
        put(PixelPose.GIVE_ITEM, PoseParams(headDx = 1, arms = ARM_GIVE))
        put(PixelPose.HIDE, PoseParams(crouch = 5, headDx = -1))
        put(PixelPose.HURT, PoseParams(bob = 1, headDx = 1, eyesClosed = true))
        put(PixelPose.FLASHBACK, PoseParams())
        put(PixelPose.HOLD_WALK_1, PoseParams(frontLeg = 4, backLeg = -4, arms = ARM_HOLD))
        put(PixelPose.HOLD_WALK_2, PoseParams(bob = -1, frontLeg = 1, backLeg = -1, arms = ARM_HOLD))
        put(PixelPose.HOLD_WALK_3, PoseParams(frontLeg = -4, backLeg = 4, arms = ARM_HOLD))
        return PixelCharacterData("protagonista", W, H, PALETTE, frames, CX, hands)
    }

    private fun paint(p: PoseParams): IntArray {
        val c = PixelCanvas(W, H)
        val cx = CX
        val top = p.bob + p.crouch

        // brazo trasero (más oscuro, queda detrás del cuerpo)
        arm(c, p, cx - 1, 35 + top, true)

        // pierna trasera
        leg(c, cx - 3 + p.backLeg, PixelIndex.PANTS_SHADOW)

        // suéter de lana: cuerpo, dobladillo, línea roja y puntitos de lana
        c.rect(cx - 5, 33 + top, cx + 4, 47 + top, PixelIndex.SHIRT)
        c.rect(cx - 5, 33 + top, cx - 4, 47 + top, PixelIndex.SHIRT_SHADOW)
        c.rect(cx - 5, 46 + top, cx + 4, 47 + top, PixelIndex.SHIRT_SHADOW)
        c.rect(cx - 5, 39 + top, cx + 4, 40 + top, PixelIndex.DETAIL)
        var wy = 35 + top
        while (wy <= 44 + top) {
            if (wy != 39 + top && wy != 40 + top) {
                var wx = cx - 3 + (wy % 2)
                while (wx <= cx + 3) {
                    c.set(wx, wy, PixelIndex.SHIRT_SHADOW)
                    wx += 3
                }
            }
            wy += 1
        }

        // pantalón largo
        c.rect(cx - 5, 48 + top, cx + 4, 55 + top, PixelIndex.PANTS)
        c.rect(cx - 5, 48 + top, cx - 4, 55 + top, PixelIndex.PANTS_SHADOW)
        c.rect(cx - 5, 54 + top, cx + 4, 55 + top, PixelIndex.PANTS_SHADOW)

        // pierna delantera
        leg(c, cx + 1 + p.frontLeg, PixelIndex.PANTS)

        // bufanda corta: vuelta al cuello y una cola que cuelga por la espalda
        c.rect(cx - 4, 31 + top, cx + 3, 33 + top, PixelIndex.SCARF)
        c.rect(cx - 4, 33 + top, cx - 3, 33 + top, PixelIndex.SCARF_SHADOW)
        c.rect(cx - 6, 33 + top, cx - 4, 39 + top, PixelIndex.SCARF)
        c.rect(cx - 6, 38 + top, cx - 4, 39 + top, PixelIndex.SCARF_SHADOW)

        // cabeza grande (es un niño)
        val hx = cx + 1 + p.headDx
        val hy = 24 + top
        c.rect(cx - 1, 29 + top, cx + 2, 31 + top, PixelIndex.SKIN_SHADOW) // cuello
        c.ellipse(hx, hy, 8, 8, PixelIndex.SKIN)

        // pelo castaño despeinado: casquete, nuca, flequillo irregular y mechones
        for (y in hy - 8..hy + 8) for (x in hx - 9..hx + 9) {
            if (c.get(x, y) != PixelIndex.SKIN) continue
            val back = x <= hx - 3 && y <= hy + 4
            val capTop = y <= hy - 4
            val fringe = y <= hy - 1 && x >= hx + 1 && ((x * 2 + y) % 3 != 0)
            if (back || capTop || fringe) c.set(x, y, PixelIndex.HAIR)
        }
        c.set(hx - 3, hy - 9, PixelIndex.HAIR)
        c.set(hx - 2, hy - 9, PixelIndex.HAIR)
        c.set(hx + 1, hy - 9, PixelIndex.HAIR)
        c.set(hx + 4, hy - 8, PixelIndex.HAIR)
        c.set(hx - 8, hy - 3, PixelIndex.HAIR)
        c.set(hx - 8, hy, PixelIndex.HAIR)
        c.set(hx - 1, hy - 6, PixelIndex.HIGHLIGHT)
        c.set(hx, hy - 6, PixelIndex.HIGHLIGHT)

        // cara: oreja, nariz, ceja, ojo, mejilla con su marca, boca
        c.rect(hx - 2, hy + 1, hx - 1, hy + 3, PixelIndex.SKIN_SHADOW)
        c.set(hx + 8, hy + 2, PixelIndex.SKIN_SHADOW)
        c.rect(hx + 4, hy - 2, hx + 6, hy - 2, PixelIndex.HAIR)
        if (p.eyesClosed) {
            c.rect(hx + 4, hy + 1, hx + 6, hy + 1, PixelIndex.EYE)
        } else {
            c.rect(hx + 5, hy, hx + 6, hy + 3, PixelIndex.EYE)
            c.set(hx + 6, hy, PixelIndex.HIGHLIGHT)
        }
        c.rect(hx + 3, hy + 4, hx + 4, hy + 5, PixelIndex.FACE_MARK)
        c.rect(hx + 6, hy + 6, hx + 7, hy + 6, PixelIndex.OUTLINE)

        // brazo delantero
        arm(c, p, cx + 1, 35 + top, false)

        c.outline(PixelIndex.OUTLINE)
        return c.px
    }

    /** Brazo según el modo de la pose. [back] = el brazo de atrás (más oscuro y más corto). */
    private fun arm(c: PixelCanvas, p: PoseParams, sx: Int, sy: Int, back: Boolean) {
        val sleeve = if (back) PixelIndex.SHIRT_SHADOW else PixelIndex.SHIRT
        val hand = if (back) PixelIndex.SKIN_SHADOW else PixelIndex.SKIN
        val cx = CX
        val top = p.bob + p.crouch
        when (p.arms) {
            ARM_HANG -> {
                val swing = if (back) -p.frontLeg / 2 else -p.backLeg / 2
                for (i in 0..10) {
                    val xx = sx + swing * i / 10
                    val col = if (i <= 7) sleeve else hand
                    c.set(xx, sy + i, col)
                    c.set(xx + 1, sy + i, col)
                }
            }
            ARM_HOLD -> {
                val hx = if (back) cx + 7 else cx + 9
                val hy = if (back) 42 + top else 41 + top
                c.thickLine(sx, sy, sx + 1, sy + 6, sleeve)
                c.thickLine(sx + 1, sy + 6, hx - 2, hy, sleeve)
                c.rect(hx - 1, hy, hx, hy + 1, hand)
            }
            ARM_GIVE -> {
                val hx = if (back) cx + 12 else cx + 15
                val hy = if (back) 39 + top else 38 + top
                c.thickLine(sx, sy, hx - 2, hy, sleeve)
                c.rect(hx - 1, hy, hx, hy + 1, hand)
            }
            else -> { // PICKUP: estirado hacia abajo y adelante
                val hx = if (back) cx + 8 else cx + 11
                val hy = if (back) 50 else 52
                c.thickLine(sx, sy, hx - 2, hy - 2, sleeve)
                c.rect(hx - 1, hy - 1, hx, hy, hand)
            }
        }
    }

    /** Pierna de 3 px (filas 56..60) con pantalón y zapato blanco (filas 61..63) que apunta hacia delante. */
    private fun leg(c: PixelCanvas, x: Int, pants: Int) {
        c.rect(x, 56, x + 2, 60, pants)
        c.rect(x - 1, 61, x + 4, 63, PixelIndex.SHOES)
        c.rect(x - 1, 63, x + 4, 63, PixelIndex.SHOE_SHADOW)
        c.set(x + 4, 61, PixelIndex.TRANSPARENT)
    }
}
