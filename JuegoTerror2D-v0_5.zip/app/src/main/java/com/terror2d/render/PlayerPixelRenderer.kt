package com.terror2d.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import com.terror2d.pixel.LightingSample
import com.terror2d.pixel.PixelCharacterData
import com.terror2d.pixel.PixelPose
import com.terror2d.pixel.PixelRasterizer
import kotlin.math.round

/**
 * Dibuja personajes pixelados. Recibe datos ([PixelCharacterData]), pose, orientación, posición,
 * iluminación y opacidad: no sabe quién es el personaje.
 *
 * La matriz se convierte en ARGB con [PixelRasterizer] (iluminación incluida) y se vuelca a un
 * Bitmap que se CACHEA por (personaje, pose, nivel de luz quantizado): normalmente solo se crean
 * unos pocos bitmaps y el frame se reduce a un drawBitmap sin filtrado (píxeles nítidos).
 */
class PlayerPixelRenderer {

    private val paint = Paint().apply {
        isAntiAlias = false
        isFilterBitmap = false
        isDither = false
    }

    private val cache = HashMap<Long, Bitmap>()
    private val quantized = LightingSample()
    private var lastCorruption = 0f
    private var buffer = IntArray(0)

    /** @param centerX / bottomY punto del suelo bajo el centro del cuerpo (coordenadas del mundo). */
    fun render(
        canvas: Canvas,
        data: PixelCharacterData,
        pose: PixelPose,
        flip: Boolean,
        centerX: Float,
        bottomY: Float,
        alpha: Float,
        light: LightingSample,
        corruption: Float
    ) {
        if (alpha <= 0.01f) return
        if (kotlin.math.abs(corruption - lastCorruption) > 0.02f) {
            clear()
            lastCorruption = corruption
        }
        light.quantizeInto(quantized)
        val key = (System.identityHashCode(data).toLong() shl 32) or
            (pose.ordinal.toLong() shl 16) or light.key().toLong()
        var bmp = cache[key]
        if (bmp == null) {
            if (cache.size >= MAX_CACHED) clear()
            val n = data.width * data.height
            if (buffer.size < n) buffer = IntArray(n)
            PixelRasterizer.rasterize(data, pose, false, quantized, corruption, buffer)
            bmp = Bitmap.createBitmap(data.width, data.height, Bitmap.Config.ARGB_8888)
            bmp.setPixels(buffer, 0, data.width, 0, 0, data.width, data.height)
            cache[key] = bmp
        }
        paint.alpha = (alpha.coerceIn(0f, 1f) * 255f).toInt()
        canvas.save()
        canvas.translate(round(centerX), round(bottomY))
        if (flip) canvas.scale(-1f, 1f)
        canvas.drawBitmap(bmp, -data.anchorX.toFloat(), -data.height.toFloat(), paint)
        canvas.restore()
    }

    fun clear() {
        for (b in cache.values) b.recycle()
        cache.clear()
    }

    companion object {
        private const val MAX_CACHED = 96
    }
}
