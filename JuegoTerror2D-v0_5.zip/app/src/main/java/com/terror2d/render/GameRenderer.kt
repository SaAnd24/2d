package com.terror2d.render

import android.graphics.Canvas
import android.graphics.Color
import com.terror2d.core.GameConfig
import com.terror2d.core.GameState
import com.terror2d.core.Viewport
import com.terror2d.input.InputController
import com.terror2d.scene.SceneManager

/**
 * Orquesta un frame: barras negras, escala a resolución lógica 320x180, cámara lateral, mundo
 * (fondo -> objetos -> personaje -> iluminación, vía SceneManager), viñeta, texto, HUD y fundido
 * de transición. El estilo visual lo decide [renderer].
 */
class GameRenderer(private val viewport: Viewport) {

    /** Intercambiable en el futuro (CrayonRenderer, GraphiteRenderer...). */
    var renderer: WorldRenderer = CrayonRenderer()

    fun render(
        canvas: Canvas,
        sceneManager: SceneManager,
        state: GameState,
        input: InputController,
        debugText: CharSequence?
    ) {
        canvas.drawColor(Color.BLACK)
        val scene = sceneManager.current ?: return

        canvas.save()
        canvas.translate(viewport.offsetX, viewport.offsetY)
        canvas.scale(viewport.scale, viewport.scale)
        canvas.clipRect(0f, 0f, GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat())

        renderer.beginFrame(canvas, state.visualCorruption, state.elapsedTime)
        renderer.drawBackground()

        // Mundo: coordenadas del mundo -> cámara -> pantalla lógica
        canvas.save()
        canvas.translate(-scene.camera.snappedX, -scene.camera.snappedY)
        sceneManager.render(renderer)
        canvas.restore()

        // Viñeta, texto, HUD y fundido (coordenadas lógicas de pantalla)
        renderer.drawVignette()
        renderer.drawTextBox(scene.dialogue)
        renderer.drawHud(input)
        renderer.drawFade(scene.transitionAlpha)
        if (debugText != null) renderer.drawDebug(debugText)

        canvas.restore()
    }
}
