package com.terror2d.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.terror2d.core.GameConfig
import com.terror2d.input.InputAction
import com.terror2d.input.InputController
import com.terror2d.interaction.InteractionIcon
import com.terror2d.ui.DialogueManager
import com.terror2d.world.WorldObject
import kotlin.math.min
import kotlin.math.round
import kotlin.math.sin

/**
 * Base del renderizado: lienzo, Paint reutilizado, gancho de corrupción visual ([tint]), HUD, caja de
 * texto y marcas de interacción. NO sabe nada del mundo: eso es de [WorldRenderer] y sus hijos
 * ([CrayonRenderer], y en el futuro Graphite/Scratch/Distortion).
 * No crea objetos en el bucle de dibujo (Paint/Path/RectF reutilizados).
 */
open class BaseRenderer {

    protected lateinit var canvas: Canvas
    protected var corruption: Float = 0f

    /** Segundos de juego (para animaciones puramente visuales: parpadeos, rebote de la marca). */
    protected var renderTime: Float = 0f

    protected val paint = Paint().apply {
        isAntiAlias = false
        isFilterBitmap = false
        isDither = false
        strokeCap = Paint.Cap.SQUARE
        strokeJoin = Paint.Join.MITER
    }

    private val textPaint = Paint().apply {
        isAntiAlias = true
        textSize = 7f
        typeface = Typeface.MONOSPACE
        color = Palette.OUTLINE
    }

    private val labelPaint = Paint().apply {
        isAntiAlias = true
        textSize = 6.5f
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        color = Palette.TEXT_INK
    }

    private val dialoguePaint = Paint().apply {
        isAntiAlias = true
        textSize = 8f
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        color = Palette.TEXT_INK
    }

    protected val path = Path()
    protected val oval = RectF()
    private val pill = RectF()

    // Ajuste de texto en líneas (se recalcula solo cuando cambia la línea; sin allocations por frame)
    private val wrapStart = IntArray(MAX_WRAP_LINES)
    private val wrapEnd = IntArray(MAX_WRAP_LINES)
    private var wrapCount = 0
    private var wrapSerial = -1

    open fun beginFrame(canvas: Canvas, visualCorruption: Float, time: Float = 0f) {
        this.canvas = canvas
        this.corruption = visualCorruption
        this.renderTime = time
    }

    /**
     * Gancho de corrupción visual: 0.0 devuelve el color intacto.
     * Futuro: más saturación perdida, tintes, grafito...
     */
    protected open fun tint(c: Int): Int {
        val k = corruption
        if (k <= 0.001f) return c
        val a = (c ushr 24) and 0xFF
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        val gray = r * 0.30f + g * 0.59f + b * 0.11f
        val t = k * 0.85f
        val nr = (r + (gray - r) * t).toInt()
        val ng = (g + (gray - g) * t).toInt()
        val nb = (b + (gray - b) * t).toInt()
        return (a shl 24) or (nr shl 16) or (ng shl 8) or nb
    }

    protected fun lerpColor(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        val ar = (a shr 16) and 0xFF
        val ag = (a shr 8) and 0xFF
        val ab = a and 0xFF
        val br = (b shr 16) and 0xFF
        val bg = (b shr 8) and 0xFF
        val bb = b and 0xFF
        val r = (ar + (br - ar) * k).toInt()
        val g = (ag + (bg - ag) * k).toInt()
        val bl = (ab + (bb - ab) * k).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
    }

    /** Fondo de papel (zona lógica completa, coordenadas de pantalla lógica). */
    open fun drawBackground() {
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.PAPER)
        canvas.drawRect(0f, 0f, GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat(), paint)
    }

    /** Marca de interacción: un triángulo que rebota sobre el objeto enfocado (se ve incluso en la oscuridad). */
    open fun drawInteractMarker(x: Float, y: Float) {
        val bob = sin(renderTime * 5f) * 1.6f
        val ty = y + bob
        path.reset()
        path.moveTo(x - 4.5f, ty - 7f)
        path.lineTo(x + 4.5f, ty - 7f)
        path.lineTo(x, ty)
        path.close()
        paint.style = Paint.Style.FILL
        paint.color = tint(0xFFFFF2B0.toInt())
        canvas.drawPath(path, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.1f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawPath(path, paint)
    }

    /** Líneas sueltas (pares x1,y1,x2,y2). */
    open fun drawStrokes(lines: FloatArray, color: Int, strokeWidth: Float) {
        if (lines.isEmpty()) return
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = strokeWidth
        paint.color = tint(color)
        canvas.drawLines(lines, paint)
    }

    /** Caja con relleno de crayón, trazos de sombreado y contorno doble imperfecto. */
    open fun drawSketchBox(o: WorldObject) {
        paint.style = Paint.Style.FILL
        paint.color = tint(o.fillColor)
        canvas.drawRect(o.x, o.y, o.right, o.bottom, paint)
        drawStrokes(o.hatch, o.hatchColor, 1.4f)
        drawStrokes(o.outline, o.lineColor, 1f)
    }

    /**
     * Dibujo pequeño de un objeto del inventario, centrado en (cx, cy) y escalado por [scale]. Se usa en la
     * mano del niño y en el HUD. Formas planas con un contorno: el estilo de crayón del mundo lo pone la luz.
     */
    open fun drawItemArt(itemId: String, cx: Float, cy: Float, scale: Float) {
        canvas.save()
        canvas.translate(cx, cy)
        canvas.scale(scale, scale)
        when (itemId) {
            "water_glass" -> {
                // vaso transparente con agua, borde y brillo
                paint.style = Paint.Style.FILL
                paint.color = tint(0x66DDEEF8)
                canvas.drawRect(-4f, -6f, 4f, 6f, paint)
                paint.color = tint(0xFF5AA6E8.toInt())
                canvas.drawRect(-3.4f, -2f, 3.4f, 5.4f, paint)
                paint.color = tint(0xFFBFE4FF.toInt())
                canvas.drawRect(-3.4f, -2f, 3.4f, -0.6f, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1f
                paint.color = tint(Palette.OUTLINE)
                canvas.drawRect(-4f, -6f, 4f, 6f, paint)
                paint.color = tint(0xAAFFFFFF.toInt())
                canvas.drawLine(-2.2f, -4.6f, -2.2f, 2f, paint)
            }
            "frog_plush" -> {
                paint.style = Paint.Style.FILL
                paint.color = tint(0xFF7CC96B.toInt())
                oval.set(-6f, -2f, 6f, 7f)
                canvas.drawOval(oval, paint)
                oval.set(-6.5f, -7f, 6.5f, 1f)
                canvas.drawOval(oval, paint)
                paint.color = tint(0xFFF8F2E0.toInt())
                canvas.drawCircle(-3.6f, -7f, 2.4f, paint)
                canvas.drawCircle(3.6f, -7f, 2.4f, paint)
                paint.color = tint(Palette.OUTLINE)
                canvas.drawCircle(-3.3f, -6.8f, 1f, paint)
                canvas.drawCircle(3.3f, -6.8f, 1f, paint)
                paint.color = tint(0xFF4F9A3E.toInt())
                canvas.drawRect(-0.8f, 1.5f, 0.8f, 5.5f, paint)
                canvas.drawRect(-2.4f, 3f, 2.4f, 4.2f, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1f
                paint.color = tint(Palette.OUTLINE)
                canvas.drawLine(-3f, -2.6f, 3f, -2.6f, paint)
            }
            else -> {
                // caja de medicinas: color según el objeto y una cruz blanca
                val body = when (itemId) {
                    "pill_box_blue" -> 0xFF5A8FE0.toInt()
                    "pill_box_orange" -> 0xFFE8944A.toInt()
                    else -> 0xFFF2EEE0.toInt()
                }
                paint.style = Paint.Style.FILL
                paint.color = tint(body)
                canvas.drawRect(-5f, -6f, 5f, 6f, paint)
                paint.color = tint(if (itemId == "pill_box_white") 0xFF4F9A3E.toInt() else 0xFFFFFFFF.toInt())
                canvas.drawRect(-0.8f, -4f, 0.8f, 0.5f, paint)
                canvas.drawRect(-2.6f, -2.2f, 2.6f, -0.8f, paint)
                paint.color = tint(0x55000000)
                canvas.drawRect(-4f, 2.4f, 4f, 3.2f, paint)
                canvas.drawRect(-4f, 4.2f, 2f, 4.8f, paint)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1f
                paint.color = tint(Palette.OUTLINE)
                canvas.drawRect(-5f, -6f, 5f, 6f, paint)
            }
        }
        canvas.restore()
    }

    /** Casilla discreta (arriba a la derecha) con el objeto que lleva el niño. */
    open fun drawHeldSlot(itemId: String?) {
        if (itemId == null) return
        val cx = GameConfig.LOGICAL_WIDTH - 17f
        val cy = 17f
        pill.set(cx - 13f, cy - 13f, cx + 13f, cy + 13f)
        paint.style = Paint.Style.FILL
        paint.color = 0xD8F4ECD8.toInt()
        canvas.drawRoundRect(pill, 4f, 4f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.2f
        paint.color = 0xAA402A1E.toInt()
        canvas.drawRoundRect(pill, 4f, 4f, paint)
        drawItemArt(itemId, cx, cy, 1.15f)
    }

    /** HUD discreto (coordenadas lógicas): ← → abajo a la izquierda y acción abajo a la derecha. */
    open fun drawHud(input: InputController) {
        drawHeldSlot(input.heldItemId)
        drawArrowButton(InputController.LEFT_X, -1f, input.leftHeld)
        drawArrowButton(InputController.RIGHT_X, 1f, input.rightHeld)
        if (input.actionEnabled) drawActionButton(input.isDown(InputAction.INTERACT), input.actionIcon, input.actionLabel)
    }

    private fun drawArrowButton(cx: Float, dir: Float, pressed: Boolean) {
        val cy = InputController.BTN_Y
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f
        paint.color = if (pressed) 0xAA402A1E.toInt() else 0x55402A1E
        canvas.drawCircle(cx, cy, InputController.BTN_RADIUS, paint)
        path.reset()
        path.moveTo(cx + dir * 4f, cy)
        path.lineTo(cx - dir * 3f, cy - 5f)
        path.lineTo(cx - dir * 3f, cy + 5f)
        path.close()
        paint.style = Paint.Style.FILL
        canvas.drawPath(path, paint)
    }

    /** Botón de acción genérico: el icono y el texto los decide el interactuable enfocado. */
    private fun drawActionButton(pressed: Boolean, icon: InteractionIcon, label: String) {
        val cx = InputController.ACTION_X
        val cy = InputController.BTN_Y
        val ink = if (pressed) 0xEE402A1E.toInt() else 0xAA402A1E.toInt()

        // Etiqueta "[ ABRIR ]" a la izquierda del botón, sobre una pastilla de papel
        if (label.isNotEmpty()) {
            val tw = labelPaint.measureText(label)
            val right = cx - InputController.BTN_RADIUS - 5f
            pill.set(right - tw - 8f, cy - 7f, right, cy + 7f)
            paint.style = Paint.Style.FILL
            paint.color = 0xD8F4ECD8.toInt()
            canvas.drawRoundRect(pill, 4f, 4f, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1f
            paint.color = ink
            canvas.drawRoundRect(pill, 4f, 4f, paint)
            canvas.drawText(label, right - tw - 4f, cy + 2.4f, labelPaint)
        }

        paint.style = Paint.Style.FILL
        paint.color = if (pressed) 0x66F4ECD8 else 0x33F4ECD8
        canvas.drawCircle(cx, cy, InputController.BTN_RADIUS + 2f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f
        paint.color = ink
        canvas.drawCircle(cx, cy, InputController.BTN_RADIUS + 2f, paint)
        drawActionIcon(cx, cy, icon)
    }

    private fun drawActionIcon(cx: Float, cy: Float, icon: InteractionIcon) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.3f
        when (icon) {
            InteractionIcon.DOOR -> {
                canvas.drawRect(cx - 4f, cy - 7f, cx + 4f, cy + 7f, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx + 2f, cy + 1f, 1f, paint)
            }
            InteractionIcon.HIDE -> {
                canvas.drawRect(cx - 5f, cy - 7f, cx + 5f, cy + 7f, paint)
                canvas.drawLine(cx, cy - 7f, cx, cy + 7f, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx - 1.8f, cy + 1f, 0.9f, paint)
                canvas.drawCircle(cx + 1.8f, cy + 1f, 0.9f, paint)
            }
            InteractionIcon.EXIT -> {
                canvas.drawLine(cx - 6f, cy - 6f, cx - 6f, cy + 6f, paint)
                canvas.drawLine(cx - 4f, cy, cx + 6f, cy, paint)
                canvas.drawLine(cx + 6f, cy, cx + 2f, cy - 4f, paint)
                canvas.drawLine(cx + 6f, cy, cx + 2f, cy + 4f, paint)
            }
            InteractionIcon.EXAMINE -> {
                canvas.drawCircle(cx - 1.5f, cy - 1.5f, 4f, paint)
                canvas.drawLine(cx + 1.5f, cy + 1.5f, cx + 6f, cy + 6f, paint)
            }
            InteractionIcon.USE -> {
                canvas.drawRect(cx - 5f, cy - 3f, cx + 5f, cy + 3f, paint)
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx + 2f, cy, 2f, paint)
            }
            InteractionIcon.NEXT -> {
                path.reset()
                path.moveTo(cx - 3f, cy - 5f)
                path.lineTo(cx + 5f, cy)
                path.lineTo(cx - 3f, cy + 5f)
                path.close()
                paint.style = Paint.Style.FILL
                canvas.drawPath(path, paint)
            }
            InteractionIcon.PICK -> {
                canvas.drawLine(cx - 5f, cy + 6f, cx - 5f, cy - 1f, paint)
                canvas.drawLine(cx + 5f, cy + 6f, cx + 5f, cy - 1f, paint)
                canvas.drawLine(cx - 5f, cy + 6f, cx + 5f, cy + 6f, paint)
                canvas.drawLine(cx, cy - 6f, cx, cy + 1f, paint)
                canvas.drawLine(cx, cy + 1f, cx - 3f, cy - 2f, paint)
                canvas.drawLine(cx, cy + 1f, cx + 3f, cy - 2f, paint)
            }
            InteractionIcon.GIVE -> {
                canvas.drawRect(cx - 6f, cy + 1f, cx + 1f, cy + 6f, paint)
                canvas.drawLine(cx + 1f, cy - 2f, cx + 7f, cy - 2f, paint)
                canvas.drawLine(cx + 7f, cy - 2f, cx + 4f, cy - 5f, paint)
                canvas.drawLine(cx + 7f, cy - 2f, cx + 4f, cy + 1f, paint)
            }
            InteractionIcon.TALK -> {
                canvas.drawRect(cx - 6f, cy - 5f, cx + 6f, cy + 3f, paint)
                canvas.drawLine(cx - 2f, cy + 3f, cx - 4f, cy + 7f, paint)
            }
        }
    }

    /**
     * Caja de texto del juego (coordenadas lógicas), arriba y centrada: papel con borde de crayón
     * doble e irregular, texto monoespaciado que se "escribe" letra a letra. Hereda la estética
     * del juego (no es una interfaz genérica de Android).
     */
    open fun drawTextBox(d: DialogueManager) {
        val line = d.current ?: return
        val text = line.text
        val left = 28f
        val right = GameConfig.LOGICAL_WIDTH - 28f
        val top = 8f
        val padX = 8f
        ensureWrapped(text, d.lineSerial, right - left - padX * 2f)

        val speaker = line.speaker
        val lineH = 10f
        val h = 9f + wrapCount * lineH + (if (speaker != null) 9f else 0f)

        // Papel + borde doble de crayón
        pill.set(left, top, right, top + h)
        paint.style = Paint.Style.FILL
        paint.color = Palette.TEXT_BOX_FILL
        canvas.drawRoundRect(pill, 3f, 3f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.3f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawRoundRect(pill, 3f, 3f, paint)
        paint.strokeWidth = 0.8f
        pill.set(left + 1.2f, top - 0.8f, right - 0.9f, top + h + 1f)
        canvas.drawRoundRect(pill, 3f, 3f, paint)

        var y = top + 9.5f
        if (speaker != null) {
            canvas.drawText(speaker, left + padX, y, labelPaint)
            y += 9f
        }
        val visible = d.visibleChars
        for (i in 0 until wrapCount) {
            val s = wrapStart[i]
            val e = min(wrapEnd[i], visible)
            if (e > s) canvas.drawText(text, s, e, left + padX, y, dialoguePaint)
            y += lineH
        }

        // Indicador "sigue" en los diálogos que esperan a la acción
        if (d.blocksInput && d.isFullyRevealed) {
            val bx = right - 9f
            val by = top + h - 6f + sin(renderTime * 6f) * 1f
            path.reset()
            path.moveTo(bx - 3f, by - 2.5f)
            path.lineTo(bx + 3f, by - 2.5f)
            path.lineTo(bx, by + 1.5f)
            path.close()
            paint.style = Paint.Style.FILL
            paint.color = tint(Palette.OUTLINE)
            canvas.drawPath(path, paint)
        }
    }

    /** Divide [text] en líneas que caben en [maxWidth] (cortando por espacios). Solo si cambió la línea. */
    private fun ensureWrapped(text: String, serial: Int, maxWidth: Float) {
        if (serial == wrapSerial) return
        wrapSerial = serial
        wrapCount = 0
        val n = text.length
        var start = 0
        while (start < n && wrapCount < MAX_WRAP_LINES) {
            var fit = dialoguePaint.breakText(text, start, n, true, maxWidth, null)
            if (fit < 1) fit = 1
            var end = start + fit
            if (end < n) {
                var sp = end
                while (sp > start && text[sp] != ' ') sp--
                if (sp > start) end = sp
            }
            wrapStart[wrapCount] = start
            wrapEnd[wrapCount] = end
            wrapCount++
            start = end
            while (start < n && text[start] == ' ') start++
        }
        if (wrapCount == 0) {
            wrapStart[0] = 0
            wrapEnd[0] = 0
            wrapCount = 1
        }
    }

    open fun drawDebug(text: CharSequence) {
        canvas.drawText(text, 0, text.length, 3f, 9f, textPaint)
    }

    companion object {
        private const val MAX_WRAP_LINES = 4
    }
}
