package com.terror2d.world

import com.terror2d.pixel.LightingSample
import com.terror2d.pixel.PixelCharacterData
import com.terror2d.pixel.PixelPose
import com.terror2d.pixel.ProtagonistSprite
import com.terror2d.render.WorldRenderer
import kotlin.math.abs

/** Estado del jugador respecto a esconderse. NORMAL y HIDDEN son los estados estables. */
enum class PlayerState { NORMAL, ENTERING_HIDE, HIDDEN, LEAVING_HIDE, PICKING_UP, GIVING }

/**
 * Jugador en vista LATERAL. La caja de colisión es el cuerpo completo (WIDTH x HEIGHT) y siempre
 * está apoyada en el suelo del segmento: la Y no la controla ningún input.
 *
 * v0.3: el personaje es mucho más grande en la escala lógica (encuadre cercano) y puede esconderse
 * ([state], [isHidden]); mientras se esconde o está escondido no se mueve.
 */
class Player(x: Float, y: Float) : WorldObject(x, y, WIDTH, HEIGHT) {

    var velocityX: Float = 0f

    /** +1 mira a la derecha, -1 a la izquierda. */
    var facing: Float = 1f
    var moving: Boolean = false
    var animTime: Float = 0f

    /** 0 = idle, 1 = walk_1, 2 = walk_2, 3 = walk_3 (ciclo 1-2-3-2). */
    var walkFrame: Int = 0
        private set

    /** Datos de pixel art del personaje (el renderer no depende de quién sea). */
    var sprite: PixelCharacterData = defaultSprite
        private set

    /** Iluminación que recibe en su posición (la calcula la escena con las luces de la habitación). */
    val light = LightingSample()

    /** Futuro: correr, ralentizar, etc. */
    var speedMultiplier: Float = 1f

    /** NORMAL / ENTERING_HIDE / HIDDEN / LEAVING_HIDE. */
    var state: PlayerState = PlayerState.NORMAL
        private set

    /** true solo cuando está completamente dentro de un escondite. */
    val isHidden: Boolean get() = state == PlayerState.HIDDEN

    /** El jugador puede caminar solo en estado NORMAL. */
    val canMove: Boolean get() = state == PlayerState.NORMAL

    /** Objeto que lleva en las manos (lo escribe la escena desde el inventario). */
    var heldItemId: String? = null

    /** Pose forzada (HURT, FLASHBACK... para eventos futuros). null = la pose sale del estado. */
    var poseOverride: PixelPose? = null

    /** Pose que se dibuja ahora: depende del estado, de si lleva algo y del ciclo de caminar. */
    val pose: PixelPose
        get() {
            val o = poseOverride
            if (o != null) return o
            val holding = heldItemId != null
            return when (state) {
                PlayerState.ENTERING_HIDE, PlayerState.LEAVING_HIDE, PlayerState.HIDDEN -> PixelPose.HIDE
                PlayerState.PICKING_UP -> PixelPose.PICKUP
                PlayerState.GIVING -> PixelPose.GIVE_ITEM
                PlayerState.NORMAL -> when (walkFrame) {
                    1 -> if (holding) PixelPose.HOLD_WALK_1 else PixelPose.WALK_1
                    2 -> if (holding) PixelPose.HOLD_WALK_2 else PixelPose.WALK_2
                    3 -> if (holding) PixelPose.HOLD_WALK_3 else PixelPose.WALK_3
                    else -> if (holding) PixelPose.HOLD_ITEM else PixelPose.IDLE
                }
            }
        }

    private var actionTimer = 0f
    private var onActionDone: (() -> Unit)? = null

    /** Opacidad con la que se dibuja (1 = visible, 0 = invisible dentro del armario). */
    var visibilityAlpha: Float = 1f

    init {
        collidable = false // el jugador no está en la lista de sólidos
    }

    /**
     * Empieza una acción con animación (recoger / entregar). El niño no se mueve; al acabar el tiempo
     * vuelve a NORMAL y se llama a [done].
     */
    fun beginAction(newState: PlayerState, seconds: Float, done: (() -> Unit)?) {
        state = newState
        velocityX = 0f
        moving = false
        walkFrame = 0
        actionTimer = seconds
        onActionDone = done
    }

    /** Empieza a esconderse (el escondite controla la animación y llama a [finishHide]). */
    fun beginHide() {
        state = PlayerState.ENTERING_HIDE
        velocityX = 0f
        moving = false
        walkFrame = 0
    }

    fun finishHide() {
        state = PlayerState.HIDDEN
        visibilityAlpha = 0f
    }

    /** Empieza a salir del escondite (sigue invisible hasta [finishLeave]). */
    fun beginLeave() {
        state = PlayerState.LEAVING_HIDE
    }

    fun finishLeave() {
        state = PlayerState.NORMAL
        visibilityAlpha = 1f
    }

    /**
     * Un paso de simulación. [dirX] en [-1, 1]. Movimiento deliberado y suave:
     * aceleración corta, sin deslizamiento largo. Si no puede moverse, solo se frena.
     */
    fun update(
        dt: Float,
        dirX: Float,
        solids: List<WorldObject>,
        floorY: Float,
        leftBoundary: Float,
        rightBoundary: Float
    ) {
        if (state == PlayerState.PICKING_UP || state == PlayerState.GIVING) {
            actionTimer -= dt
            if (actionTimer <= 0f) {
                state = PlayerState.NORMAL
                val cb = onActionDone
                onActionDone = null
                cb?.invoke()
            }
        }
        val dir = if (canMove) dirX.coerceIn(-1f, 1f) else 0f
        val target = dir * SPEED * speedMultiplier
        val rate = (if (dir == 0f) DECEL else ACCEL) * dt
        velocityX = when {
            velocityX < target - rate -> velocityX + rate
            velocityX > target + rate -> velocityX - rate
            else -> target
        }

        CollisionSystem.snapToFloor(this, floorY)
        if (canMove) {
            val blocked = CollisionSystem.moveHorizontal(this, velocityX * dt, solids, leftBoundary, rightBoundary)
            if (blocked) velocityX = 0f
        } else {
            velocityX = 0f
        }
        CollisionSystem.snapToFloor(this, floorY)

        if (dir != 0f) facing = if (dir < 0f) -1f else 1f
        moving = abs(velocityX) > MOVING_EPS
        if (moving) {
            animTime += dt
            walkFrame = WALK_CYCLE[(animTime / STEP_TIME).toInt() and 3]
        } else {
            animTime = 0f
            walkFrame = 0
        }
    }

    override fun prepareVisuals(rng: com.terror2d.util.SeededRandom) {
        // El personaje es pixel art (datos fijos); no necesita trazos precalculados.
    }

    override fun render(r: WorldRenderer) {
        r.drawPlayer(this)
    }

    companion object {
        /** Caja de colisión; el sprite (48x64, ~50 px visibles) se alinea con sus pies. */
        const val WIDTH = 18f
        const val HEIGHT = 48f

        /** Velocidad máxima en píxeles lógicos por segundo (paseo tranquilo, acorde a la nueva escala). */
        const val SPEED = 68f
        const val ACCEL = 520f
        const val DECEL = 640f
        const val MOVING_EPS = 2f

        /** Segundos por fotograma de la animación de caminar (pasos de un niño de 8 años: tranquilos). */
        const val STEP_TIME = 0.15f

        /** Secuencia de poses al caminar: WALK_1, WALK_2, WALK_3, WALK_2. */
        private val WALK_CYCLE = intArrayOf(1, 2, 3, 2)

        /** Un solo juego de datos compartido por todos los jugadores (se genera una vez). */
        val defaultSprite: PixelCharacterData by lazy { ProtagonistSprite.create() }
    }
}
