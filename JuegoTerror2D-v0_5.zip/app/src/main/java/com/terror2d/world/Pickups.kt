package com.terror2d.world

import com.terror2d.draw.CrayonBuilder
import com.terror2d.draw.CrayonSprite
import com.terror2d.events.EventType
import com.terror2d.inventory.ItemRegistry
import com.terror2d.interaction.Interactable
import com.terror2d.interaction.InteractionContext
import com.terror2d.interaction.InteractionIcon
import com.terror2d.interaction.InteractionResult
import com.terror2d.render.WorldRenderer
import com.terror2d.util.SeededRandom

/**
 * Objeto del mundo que se puede recoger y volver a dejar en su sitio (cajas de medicinas, etc.).
 * - En su sitio ([isAtHome]): "RECOGER" (animación + va al inventario y a las manos).
 * - Si el niño lo lleva y está cerca: "DEJAR" (animación de entrega + vuelve a su sitio).
 * - Con las manos ocupadas por otra cosa: "Tengo las manos ocupadas."
 * El dibujo se genera una vez con la semilla (misma semilla = mismo dibujo).
 */
class WorldPickup(
    val id: String,
    val itemId: String,
    x: Float,
    y: Float,
    w: Float,
    h: Float,
    private val pickupText: String,
    private val margin: Float = 6f,
    private val onPicked: ((InteractionContext) -> Unit)? = null,
    private val art: (CrayonBuilder, Float, Float) -> Unit
) : WorldObject(x, y, w, h), Interactable {

    var isAtHome: Boolean = true
        private set

    var sprite: CrayonSprite = CrayonSprite.EMPTY
        private set

    init {
        collidable = false
        layer = Layer.OBJECT
    }

    override fun prepareVisuals(rng: SeededRandom) {
        val b = CrayonBuilder(rng)
        art(b, x, y)
        sprite = b.finish()
        outline = EMPTY
        hatch = EMPTY
    }

    override fun visualHash(seed: Long): Long = sprite.hash(seed)

    override fun render(r: WorldRenderer) {
        if (isAtHome) r.drawSprite(sprite)
    }

    // ---------- Interactable ----------

    override val interactionId: String get() = id
    override val promptText: String get() = if (isAtHome) "RECOGER" else "DEJAR"
    override val promptIcon: InteractionIcon get() = if (isAtHome) InteractionIcon.PICK else InteractionIcon.GIVE
    override val zoneLeft: Float get() = x - margin
    override val zoneRight: Float get() = right + margin
    override val markerX: Float get() = centerX
    override val markerY: Float get() = y - 3f

    override fun canInteract(ctx: InteractionContext): Boolean =
        isAtHome || ctx.inventory.isHolding(itemId)

    override fun executeInteraction(ctx: InteractionContext): InteractionResult {
        if (isAtHome) {
            if (ctx.held != null) return InteractionResult.message("Tengo las manos ocupadas.")
            return InteractionResult.pickup(itemId) { c ->
                isAtHome = false
                onPicked?.invoke(c)
                InteractionResult.message(pickupText)
            }
        }
        return InteractionResult.give(itemId) { c ->
            isAtHome = true
            c.post(EventType.ON_ITEM_PLACED, itemId)
            InteractionResult.message("La dejo donde estaba.")
        }
    }

    /** Vuelve a su sitio (al recargar el segmento). */
    fun reset() {
        isAtHome = true
    }
}

/** Estados del peluche de rana. Todavía NO habla ni tiene personalidad (eso llega en v0.7). */
enum class PlushState { ON_FLOOR, HELD, PLACED }

/**
 * La ranita de peluche (cuerpo completo): en el suelo, en las manos del niño o dejada en un sitio.
 * Es el peluche de la farmacia (cruz verde en la barriga y gorrito). Solo objeto: sin voz ni autonomía.
 */
class PlushFrog(
    val id: String,
    x: Float,
    floorY: Float
) : WorldObject(x, floorY - HEIGHT, WIDTH, HEIGHT), Interactable {

    var state: PlushState = PlushState.ON_FLOOR
        private set

    private val homeX = x
    private val homeY = floorY - HEIGHT

    /** Esquina donde está dibujado ahora (suelo o lugar donde se dejó). */
    private var drawX = x
    private var drawY = floorY - HEIGHT

    private var sprite: CrayonSprite = CrayonSprite.EMPTY

    init {
        collidable = false
        layer = Layer.OBJECT
    }

    /** Deja el peluche en un sitio (esquina superior izquierda del dibujo). */
    fun placeAt(px: Float, py: Float) {
        state = PlushState.PLACED
        drawX = px
        drawY = py
        x = px
        y = py
    }

    fun reset() {
        state = PlushState.ON_FLOOR
        drawX = homeX
        drawY = homeY
        x = homeX
        y = homeY
    }

    override fun prepareVisuals(rng: SeededRandom) {
        val b = CrayonBuilder(rng)
        drawFrog(b, 0f, 0f)
        sprite = b.finish()
        outline = EMPTY
        hatch = EMPTY
    }

    override fun visualHash(seed: Long): Long = sprite.hash(seed)

    override fun render(r: WorldRenderer) {
        if (state != PlushState.HELD) r.drawSpriteAt(sprite, drawX, drawY)
    }

    // ---------- Interactable ----------

    override val interactionId: String get() = id
    override val promptText: String get() = "RECOGER"
    override val promptIcon: InteractionIcon get() = InteractionIcon.PICK
    override val zoneLeft: Float get() = x - 8f
    override val zoneRight: Float get() = right + 8f
    override val markerX: Float get() = centerX
    override val markerY: Float get() = y - 3f

    override fun canInteract(ctx: InteractionContext): Boolean = state != PlushState.HELD

    override fun executeInteraction(ctx: InteractionContext): InteractionResult {
        if (state == PlushState.HELD) return InteractionResult.IGNORED
        if (ctx.held != null) return InteractionResult.message("Tengo las manos ocupadas.")
        return InteractionResult.pickup(ItemRegistry.FROG_PLUSH) { _ ->
            state = PlushState.HELD
            InteractionResult.message("Ranita. Me la dieron en la farmacia. Siempre sonríe.")
        }
    }

    companion object {
        const val WIDTH = 28f
        const val HEIGHT = 34f

        /** Peluche de rana de cuerpo completo, sentado: cabeza, ojos saltones, brazos, piernas y la cruz verde. */
        fun drawFrog(b: CrayonBuilder, x0: Float, y0: Float) {
            val green = 0xFF7CC96B.toInt()
            val dgreen = 0xFF4F9A3E.toInt()
            val white = 0xFFF8F2E0.toInt()
            val ink = CrayonBuilder.INK
            // patas traseras y cuerpo
            b.ball(x0 + 6f, y0 + 29f, 6f, 4f, green)
            b.ball(x0 + 22f, y0 + 29f, 6f, 4f, green)
            b.ball(x0 + 14f, y0 + 23f, 10f, 9f, green)
            b.ball(x0 + 14f, y0 + 26f, 6.5f, 5.5f, 0xFFD9EFB8.toInt())     // barriguita
            b.cross(x0 + 14f, y0 + 26f, 3f, dgreen, 2f)                      // cruz verde de la farmacia
            // bracitos
            b.line(x0 + 5f, y0 + 20f, x0 + 2f, y0 + 27f, dgreen, 3f, 0.3f)
            b.line(x0 + 23f, y0 + 20f, x0 + 26f, y0 + 27f, dgreen, 3f, 0.3f)
            // cabeza ancha con ojos saltones
            b.ball(x0 + 14f, y0 + 11f, 11f, 7.5f, green)
            b.ball(x0 + 7f, y0 + 5f, 4.6f, 4.6f, green)
            b.ball(x0 + 21f, y0 + 5f, 4.6f, 4.6f, green)
            b.fillOval(x0 + 7f, y0 + 5f, 3.1f, 3.1f, white)
            b.fillOval(x0 + 21f, y0 + 5f, 3.1f, 3.1f, white)
            b.fillOval(x0 + 7.6f, y0 + 5.4f, 1.4f, 1.6f, ink)
            b.fillOval(x0 + 20.4f, y0 + 5.4f, 1.4f, 1.6f, ink)
            // sonrisa de siempre (un poco ancha)
            b.smile(x0 + 14f, y0 + 11f, 7f, 2.8f, ink, false)
            // gorrito blanco con cruz
            b.box(x0 + 9f, y0 - 2f, 10f, 5f, white)
            b.cross(x0 + 14f, y0 + 0.5f, 1.6f, dgreen, 1.3f)
        }
    }
}
