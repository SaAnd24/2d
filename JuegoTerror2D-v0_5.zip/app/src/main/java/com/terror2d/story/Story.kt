package com.terror2d.story

import com.terror2d.core.GameState
import com.terror2d.events.EventBus
import com.terror2d.events.EventType
import com.terror2d.events.GameEvent
import com.terror2d.ui.DialogueManager

/**
 * Estado narrativo: simples hitos (flags) con nombre. Es deliberadamente genérico: la introducción
 * de v0.4 lo usa y v0.5/v0.6 (medicamentos, puzzle) pueden añadir sus propios hitos sin cambiar nada.
 */
class StoryState {
    private val flags = HashSet<String>()

    fun has(flag: String): Boolean = flags.contains(flag)

    /** Activa el hito. Devuelve true solo la primera vez. */
    fun set(flag: String): Boolean = flags.add(flag)

    val count: Int get() = flags.size
}

/** Nombres de los hitos de la introducción. */
object StoryFlags {
    const val INTRO_STARTED = "intro_started"
    const val HEARD_CALL = "heard_call"
    const val HEARD_PILLS = "heard_pills"
    const val HEARD_WATER = "heard_water"
    const val INTRO_CALLS_DONE = "intro_calls_done"
    const val SAW_PILLS = "saw_pills"
    const val GOT_WATER = "got_water"
    const val TALKED_TO_MOM = "talked_to_mom"
    const val INTRO_DONE = "intro_done"
    const val WATER_DELIVERED = "water_delivered"
    const val PILLS_REQUESTED = "pills_requested"
    const val GOT_PILLS = "got_pills"
    const val PILLS_DELIVERED = "pills_delivered"
}

/** Lo que un guion de escena puede usar. */
class ScriptContext(val dialogue: DialogueManager, val state: GameState, val events: EventBus) {
    /** Segmento activo. */
    var segmentId: String = ""

    /** Activa un hito y publica ON_STORY_FLAG la primera vez. */
    fun setFlag(flag: String): Boolean {
        val isNew = state.story.set(flag)
        if (isNew) events.post(EventType.ON_STORY_FLAG, flag, segmentId)
        return isNew
    }
}

/** Guion de escena: reacciona a eventos y/o al paso del tiempo. */
interface SceneScript {
    fun onEvent(e: GameEvent, ctx: ScriptContext) {}
    fun update(dt: Float, ctx: ScriptContext) {}
}
