package com.terror2d.core

import android.content.Context
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView

/** Superficie de dibujo. Solo conecta Android (superficie, touch, teclas) con Game. */
class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {

    val game = Game()
    private var loop: GameLoop? = null

    init {
        holder.addCallback(this)
        isFocusable = true
        isFocusableInTouchMode = true
        keepScreenOn = true
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        val frame = holder.surfaceFrame
        game.viewport.update(frame.width(), frame.height())
        loop?.stopLoop()
        loop = GameLoop(holder, game).also { it.startLoop() }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        game.viewport.update(width, height)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        loop?.stopLoop()
        loop = null
    }

    override fun onTouchEvent(event: MotionEvent): Boolean =
        game.input.onTouchEvent(event, game.viewport)

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean =
        game.input.onKey(keyCode, true) || super.onKeyDown(keyCode, event)

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean =
        game.input.onKey(keyCode, false) || super.onKeyUp(keyCode, event)
}
