# Design Bible — Horror 2D

Documento de dirección narrativa, visual y mecánica. **Es canon**: ninguna versión futura debe contradecirlo.
Las partes marcadas *(futuro)* NO están implementadas; sirven de guía para que cada decisión de hoy encaje con mañana.

## 1. Premisa
Un niño de ~8 años vive con su madre enferma. El juego es la reconstrucción subjetiva, hecha por el niño, de una
experiencia traumática: no se debe tratar el mundo como una representación literal de la realidad. El niño
interpreta lo que no comprende; el jugador debe poder entender más que él. Se cuenta con escenarios, objetos,
cambios visuales, conversaciones, recuerdos, símbolos, acciones, contradicciones y pequeños detalles.
Sin exposición directa excesiva: el niño no explica lo que todo significa.

## 2. Madre e hijo
La madre **no es una villana**. Era cariñosa, protectora y muy cercana; lo crió prácticamente sola. Con el deterioro
de su salud, el dolor y el desgaste la volvieron frustrada, agresiva e hiriente; descargó su sufrimiento en el niño,
lo culpó injustamente (incluso del abandono del padre y de su propia enfermedad). Es una tragedia: una madre que ama
a su hijo y cuyo sufrimiento acaba haciéndole daño. El niño no comprende la contradicción; el jugador la va percibiendo.

## 3. La rana (peluche) y el monstruo
- **Peluche de rana**: memoria afectuosa de la madre antes de la enfermedad (cariñosa, protectora, optimista, divertida).
  La madre trabajó como mascota de una farmacia. Frase recurrente *(futuro, v0.7+)*: «Sabía que eres un niño especial.»
  Al principio reconfortante; con el tiempo repetitiva, sospechosa, dolorosa.
- **Monstruo** *(futuro)*: rana deformada con elementos farmacéuticos originales (bata, varios ojos, sonrisa grotesca,
  dientes/sangre, ojos tristes). Representa enfermedad, dolor, frustración, miedo y daño emocional. Contradicción clave:
  en cierto momento **ayuda** al niño (le venda el pie): la madre no se reduce a una figura malvada.
- Ambos son representaciones distintas de la misma figura materna y ambos pueden mostrar contradicciones.
- **Todo original**: nada de mascotas, nombres, logos, eslóganes, uniformes, paletas ni rostros de empresas reales.

## 4. Dos mundos
- **Mundo Normal** (hoy): terror infantil colorido. Crayón, dibujos infantiles, detalles extraños, iluminación oscura,
  sombras, anomalías pequeñas. Colorido e inquietante a la vez; *no* es «bonito = seguro».
- **Mundo Trauma** *(futuro)*: gris/negro, casi sin color, líneas negras fuertes, perspectiva incorrecta, paredes
  deformadas, muebles mal proporcionados, dibujos «corregidos violentamente»: los mismos lugares, mal reconstruidos.
  Más agresivo. No es «mundo malo» frente a «mundo bueno»: son dos manifestaciones del horror.
- **Mecánica** *(futuro)*: un objeto o acción de un mundo resuelve un problema del otro
  (NORMAL → TRAUMA → NORMAL …). Los puzzles deben dar información, una contradicción o una pista sobre madre/niño.
- **Primer acceso** *(futuro)*: tras la desaparición de mamá, el espejo del baño muestra un símbolo original relacionado
  con la rana; la realidad que el niño conocía deja de ser estable.

### Estado de la arquitectura (v0.5)
`WorldMode { NORMAL, TRAUMA }`, `GameState.worldMode`, `RoomSegment.worldMode`,
`SceneDefinition.traumaSegments` + `segmentFor(id, mode)` (si no hay variante TRAUMA se usa la NORMAL),
`ItemDef.world`. Nadie usa TRAUMA todavía: ni mapas, ni transición, ni estilo gris. El renderer
(`BaseRenderer → WorldRenderer → CrayonRenderer`) admitirá `GraphiteRenderer`, `ScratchRenderer`, `DistortionRenderer`.

## 5. Arco completo
1. **Prólogo – la casa** *(v0.4–v0.5)*: empieza en su cuarto; mamá lo llama («¿puedes ayudarme?», «ya es hora de mis
   pastillas», «¿me traes un poco de agua?»); agua a mamá; la cajita azul. Todo parece cotidiano, con anomalías: reloj con
   una marca de más, flores con demasiados pétalos, patito de sonrisa enorme, silueta borrosa en el espejo, tres platos
   para dos, la rana que sonríe demasiado.
2. **Medicinas** *(v0.5–v0.6)*: rutina para el niño («estas cosas saben feo», «no sé por qué mamá toma tantas»). Puzzle de
   cajas: las letras forman una contraseña; detrás, recetas y dolor crónico. Nunca decir «mi mamá tiene una enfermedad
   degenerativa»: se descubre poco a poco.
3. **Peluche** *(v0.7)*: empieza a hablar; amistoso y reconfortante.
4. **Desaparición**: un grito, ventana rota, aire frío, cama vacía, nota deformada («Me fui al hospital, deberías
   alcanzarme!»). El niño la acepta; el jugador desconfía.
5. **La criatura**: la casa se vuelve peligrosa; esconderse, observar, escapar. Terror psicológico, no acción.
6. **Mundo Trauma**: espejo del baño; puzzles cruzados entre ambos mundos.
7. **La calle**: vecinos que conocen la situación («¿tu mamá sigue en el hospital?», «pobrecito…»).
8. **La farmacia**: rana → farmacia → madre → enfermedad (mascota 100 % original).
9. **Parque de diversiones**: los recuerdos más felices; el lugar más luminoso. No es descanso: hace que la tragedia duela más.
10. **Deterioro**: recuerdos que contradicen los felices; la rana se impacienta si el jugador tarda.
11. **Cementerio**: un niño llorando ante una tumba; la rana: «Un lugar tenebroso para un niño, ¿no? Qué feo es quedarse solo.»
12. **Hospital**: deformado; la criatura, más agresiva. **Flashbacks**: una visita médica; enfermedad degenerativa
    (puede quedar poco específica).
13. **Peluche roto**: ojos rojos, sonrisa rota, costuras rasgadas; ya no habla. Ruptura de la imagen idealizada.
14. **El monstruo ayuda**: reja que la criatura no puede cruzar; el niño se lastima un pie; ella lo venda y su
    expresión pasa de tristeza a una especie de felicidad.
15. **Recuerdos dolorosos**: gritos, insultos, culpas, el abandono del padre; la marca en la cara del protagonista
    cobra sentido. Las piezas se acumulan; nada explícito de golpe.
16. **Pasillo final**: «Perdón, ¿todavía eres mi niño especial?»
17. **Habitación de mamá**: cama de hospital, monitores, luz fría; la criatura desaparece; ella es solo una mujer enferma.
    Foto: madre e hijo, ella con el disfraz de la rana, contexto de farmacia; ambos felices.
18. **Último momento**: lo reconoce, lo besa: «Sigues siendo mi niño especial, lo siento por tanto.» *beeeep*. Sale solo.
19. **Cementerio final**: llora ante su tumba; el peluche ya no está; ve a otro niño con un peluche de rana que camina
    hacia el hospital. **Final cíclico**: significado abierto; sin explicar el ciclo.

## 6. Reglas narrativas (CANON)
1. El protagonista es un niño de 8 años. 2. No habla como adulto. 3. No comprende del todo la enfermedad.
4. El jugador puede comprender antes que él. 5. La madre NO es una villana simple. 6. Peluche y monstruo son
representaciones distintas de la misma figura materna. 7. La rana = memoria afectuosa. 8. El monstruo = enfermedad,
dolor, frustración, miedo y daño emocional. 9. Ambas pueden mostrar contradicciones. 10. Sugerir más de lo que se explica.
11. Objetos y escenarios contienen información. 12. No revelar prematuramente las interpretaciones simbólicas.

## 7. Estilo visual y de voz
- Mundo: crayón sobre papel, trazos imperfectos, color vivo + oscuridad real; lo extraño parece **accidental** al principio.
- Protagonista: pixel art 48×64 (~50 px visibles), suéter de lana naranja con línea roja, pelo castaño despeinado,
  pantalón caqui, zapatos blancos, bufanda corta rojo oscuro, pequeña marca en la mejilla. Mezcla pixel art + crayón = identidad.
- Voz del niño: frases breves, simples, curiosas y emocionales. Sin términos médicos ni reflexiones adultas.

## 8. Mapa de versiones
| Versión | Contenido |
|---|---|
| v0.3 | Cámara cercana, oscuridad, interacción, armarios |
| v0.4 | La casa (pasillo + 7 espacios), crayón detallado, protagonista pixel art, intro |
| **v0.5** | **Protagonista definitivo, inventario, objetos en mano, agua y medicinas como objetos, peluche recogible, base NORMAL/TRAUMA** |
| v0.6 | Puzzle de medicamentos (letras → contraseña) |
| v0.7 | Peluche que habla |
| v0.8+ | Criatura, desaparición, Mundo Trauma, calle, farmacia, parque, hospital, final |
