"""SCREAMER de captura (v0.10). Arte DEDICADO de primerísimo plano de la criatura, a 640x360 (1 px = 0,5 px lógicos).

NO es un zoom de un sprite: la cabeza, los ojos, la boca de dientes finos, las verrugas, las llagas y los brazos largos
se DIBUJAN de nuevo aquí con las MISMAS funciones, paleta y proporciones de creature.py (cada coordenada de la cabeza
canónica se multiplica por un factor k), pero con composiciones y poses nuevas hechas para el momento de captura:
la cabeza llena la pantalla, la boca se abre más allá de su gesto canon, los brazos enmarcan y una mano cae encima.
Ninguna imagen de referencia se usa ni se incluye: todo sale de matrices de índices de paleta.

Salida: app/.../pixel/ScreamerArtData.kt (RLE, cadenas < 64 KB) y una vista previa PNG (solo para revisar).
Uso: python3 screamer.py
"""
import math, os, sys
import numpy as np
from PIL import Image
import creature as C
from creature import (PAL, OUT, SK, SKL, SKS, SKD, SKH, SKHH, FOLD, BEL, BELS, WART, SORE, LIP, LIPD, MIN, MINR, TON, TEE, TEES,
                      NAIL, VEIN, RAMP_SK, RAMP_BEL, vshade, wart, sore, crease, mottle, pores, paste, poly_curve, mouth_patch,
                      eye_patch, belly_mouth, BELLY_MOUTHS, MOUTH_STATES, HEAD_C)
from pixlib import Cv

W, H = 640, 360
FRAMES = 6


def hp(cx, cy, k, x, y):
    """Punto de la cabeza canónica (x, y) -> lienzo del screamer."""
    return (cx + (x - HEAD_C[0]) * k, cy + (y - HEAD_C[1]) * k)


def tcurve(cv, pts, color, m, th, only=None):
    for t in range(th):
        poly_curve(cv, [(int(round(x)), int(round(y)) + t) for x, y in pts], color, m, only=only if only else C.SKINS)


def build_head(cv, cx, cy, k, eye='WIDE', mouth=1.5, tilt=0.0, seed=1, eyes_dir=(0, 0)):
    """La cabeza frontal canónica (variante 0) a escala k. Devuelve (máscara, centros de ojos, centro de boca)."""
    def E(x, y, rx, ry):
        px, py = hp(cx, cy, k, x, y)
        return cv.ellipse(px, py, rx * k, ry * k)
    cxh, cyh = HEAD_C
    m = (E(cxh, cyh - 8, 19, 21) | E(cxh, cyh + 4, 23, 15) | E(cxh + 8, cyh - 18, 11, 9) |
         E(cxh - 17, cyh + 8, 8, 10) | E(cxh + 18, cyh + 8, 8, 10) | E(cxh + 2, cyh + 17, 18, 8))
    vshade(cv, m, RAMP_SK, cap=int(9 * k), strength=0.85)
    mottle(cv, m, seed + 11, 0.9)
    # entrecejo, cejas caídas, nariz de calavera, pómulos (todo del diseño canon)
    def P(x, y): return hp(cx, cy, k, x, y)
    brow = cv.capsule(P(cxh - 3, cyh - 12), P(cxh - 16, cyh - 7), 2.6 * k, 3.0 * k) | cv.capsule(P(cxh + 3, cyh - 13), P(cxh + 16, cyh - 8), 2.6 * k, 3.0 * k)
    cv.a[brow & m] = SKL
    cv.a[brow & m & ~Cv.shift(brow, 0, -int(k * 0.7))] = SKH
    th = max(2, int(k * 0.5))
    tcurve(cv, [P(cxh - 18, cyh - 5), P(cxh - 9, cyh - 9), P(cxh - 2, cyh - 10)], FOLD, m, th, only=C.SKINS + (SKL, SKH))
    tcurve(cv, [P(cxh + 18, cyh - 6), P(cxh + 9, cyh - 10), P(cxh + 2, cyh - 11)], FOLD, m, th, only=C.SKINS + (SKL, SKH))
    nose = cv.capsule(P(cxh, cyh - 6), P(cxh, cyh + 6), 2.4 * k, 3.2 * k)
    cv.a[nose & m] = SKL
    cv.a[nose & m & ~Cv.shift(nose, int(k * 0.5), 0)] = SKH
    cv.a[nose & m & ~Cv.shift(nose, -int(k * 0.5), 0)] = SKS
    for sx_ in (-2.0, 2.0):
        x0, y0 = P(cxh + sx_, cyh + 7)
        cv.a[cv.capsule((x0, y0), (x0, y0 + k * 2.2), k * 0.55) & m] = FOLD
    tcurve(cv, [P(cxh - 22, cyh + 6), P(cxh - 18, cyh + 11), P(cxh - 12, cyh + 14)], FOLD, m, th)
    tcurve(cv, [P(cxh + 22, cyh + 6), P(cxh + 18, cyh + 11), P(cxh + 12, cyh + 14)], FOLD, m, th)
    for i, (x, y, ln) in enumerate([(cxh - 14, cyh - 15, 12), (cxh - 4, cyh - 17, 16), (cxh - 18, cyh + 18, 14), (cxh - 4, cyh + 21, 18)]):
        px, py = P(x, y)
        for t in range(max(2, int(k * 0.4))):
            crease(cv, m, int(px), int(py) + t * 1, int(ln * k), 500 + i + seed, droop=0.8)
    pores(cv, m, seed + 3, int(60 * k))
    for (x, y, r) in [(cxh + 9, cyh - 24, 3), (cxh + 15, cyh - 19, 2), (cxh - 8, cyh - 22, 1), (cxh - 15, cyh - 14, 1), (cxh + 17, cyh - 10, 1),
                      (cxh - 21, cyh + 2, 1), (cxh + 22, cyh + 12, 1), (cxh - 13, cyh + 20, 1), (cxh + 4, cyh + 22, 2), (cxh - 6, cyh + 14, 1)]:
        px, py = P(x, y)
        wart(cv, px, py, max(2, int(r * k * 0.6)), m)
    for (x, y, rx, ry) in [(cxh + 12, cyh - 15, 1, 2), (cxh - 20, cyh - 6, 1, 1), (cxh + 20, cyh + 4, 1, 1)]:
        px, py = P(x, y)
        sore(cv, px, py, max(2, int(rx * k * 0.7)), max(2, int(ry * k * 0.7)), m, drip=False)
    cv.outline(OUT)
    cv.outline(OUT, m=None)
    # ojos tristes (los mismos del diseño; el párpado cae hacia fuera)
    centers = []
    for (ex, ey, outer, rr) in ((cxh - 10, cyh - 3, -1, 6.2), (cxh + 10, cyh - 4, 1, 5.8)):
        px, py = P(ex, ey)
        px += eyes_dir[0] * k * 0.8
        py += eyes_dir[1] * k * 0.8
        patch = eye_patch(rr * k, eye, outer)
        paste(cv, patch, int(px) - patch.w // 2, int(py) - patch.h // 2)
        centers.append((px, py, rr * k))
    # boca principal: la sonrisa de dientes finos, abierta MÁS allá del gesto canon
    L, hm, _, curve, tt, tb, per = C.MAIN_MOUTH_SPECS[0]
    patch, pcx, pcy = mouth_patch(L * k, hm * k, tilt, curve * k, mouth, tt * k, tb * k, per * k, lip=max(2.0, 0.8 * k), seed=7, closed_slit=1.0)
    mx, my = P(*C.MOUTH_AT[0])
    paste(cv, patch, int(mx) - pcx, int(my) - pcy + int(k * 0.5))
    return m, centers, (mx, my)


def hand(cv, x, y, size, ang, spread=1.0, curl=0.55, seed=3, palm_to_cam=True):
    """Mano larguísima de dedos finos (los del diseño canon), con uñas y verrugas. ang en grados (0 = dedos hacia arriba)."""
    a0 = math.radians(ang - 90)
    ux, uy = math.cos(a0), math.sin(a0)
    px, py = -uy, ux
    palm = cv.ellipse(x, y, size * 0.55, size * 0.62)
    mask = palm.copy()
    tips = []
    for i, off in enumerate((-1.5, -0.5, 0.5, 1.5)):
        base = (x + px * off * size * 0.26, y + py * off * size * 0.26)
        ln = size * (1.15 - 0.12 * abs(off)) * (1.1 if i in (1, 2) else 1.0)
        bend = curl * (0.35 + 0.15 * off)
        mid = (base[0] + ux * ln * 0.5 + px * off * size * 0.12 * spread, base[1] + uy * ln * 0.5 + py * off * size * 0.12 * spread)
        tip = (mid[0] + ux * ln * 0.5 * (1 - bend) + px * off * size * 0.1 * spread, mid[1] + uy * ln * 0.5 * (1 - bend) + py * off * size * 0.1 * spread + bend * ln * 0.2)
        mask |= cv.capsule(base, mid, size * 0.17, size * 0.13) | cv.capsule(mid, tip, size * 0.13, size * 0.09)
        tips.append((tip, off))
    # pulgar
    tb = (x + px * size * 0.5, y + py * size * 0.1)
    tt = (tb[0] + px * size * 0.55 + ux * size * 0.35, tb[1] + py * size * 0.55 + uy * size * 0.35)
    mask |= cv.capsule(tb, tt, size * 0.14, size * 0.09)
    tips.append((tt, 2.0))
    vshade(cv, mask, RAMP_SK, cap=max(6, int(size * 0.14)), strength=0.9)
    mottle(cv, mask, seed + 5, 0.9)
    for (tp, off) in tips:
        n = cv.ellipse(tp[0], tp[1], size * 0.075, size * 0.1)
        cv.a[n] = NAIL
        cv.a[n & ~Cv.shift(n, 1, 1)] = SKHH
        cv.a[n & ~Cv.shift(n, -1, -1)] = FOLD
    # nudillos, pliegues y verrugas
    for j in range(4):
        wx, wy = x + px * (j - 1.5) * size * 0.26 + ux * size * 0.15, y + py * (j - 1.5) * size * 0.26 + uy * size * 0.15
        wart(cv, wx, wy, max(2, int(size * 0.045)), mask)
    for t in range(max(2, int(size * 0.02))):
        poly_curve(cv, [(x - size * 0.4 + t * 0, y + size * 0.12 + t), (x, y + size * 0.2 + t), (x + size * 0.4, y + size * 0.1 + t)], FOLD, mask)
    pores(cv, mask, seed + 9, int(size * 1.6))
    cv.outline(OUT)
    cv.outline(OUT)
    return mask


def arm(cv, p0, p1, p2, r0, r1, r2, seed=4):
    mask = cv.capsule(p0, p1, r0, r1) | cv.capsule(p1, p2, r1, r2)
    vshade(cv, mask, RAMP_SK, cap=int(r1), strength=0.9)
    mottle(cv, mask, seed, 0.9)
    for (t, rad) in ((0.25, 0.16), (0.6, 0.12), (0.85, 0.1)):
        x = p0[0] + (p2[0] - p0[0]) * t
        y = p0[1] + (p2[1] - p0[1]) * t
        wart(cv, x + r1 * 0.3, y, max(2, int(r1 * rad)), mask)
    pores(cv, mask, seed + 2, int(r1 * 6))
    cv.outline(OUT)
    cv.outline(OUT)
    return mask


def keep_only(cv, keeps):
    k = cv.blank()
    for m in keeps:
        k |= m
    cv.a[~k] = 0


def make_frames():
    frames = []
    # ---- 0: emerge de la oscuridad: solo ojos tristes y el brillo de los dientes
    cv = Cv(W, H)
    m, eyes, mouth = build_head(cv, 320, 200, 3.4, eye='OPEN', mouth=1.1, seed=2)
    keeps = [cv.ellipse(ex, ey, r * 1.9, r * 1.6) for ex, ey, r in eyes] + [np.isin(cv.a, [TEE, TEES]) & cv.ellipse(mouth[0], mouth[1], 90, 40)]
    keep_only(cv, keeps)
    frames.append(cv.a.copy())

    # ---- 1: EMBESTIDA: la cabeza llena la pantalla, la sonrisa se abre
    cv = Cv(W, H)
    build_head(cv, 320, 238, 11.0, eye='WIDE', mouth=1.55, seed=3)
    frames.append(cv.a.copy())

    # ---- 2: RUGIDO: boca abierta del todo; los brazos largos enmarcan la pantalla
    cv = Cv(W, H)
    arm(cv, (-60, 420), (40, 230), (92, 66), 52, 40, 30, seed=21)
    arm(cv, (700, 420), (600, 230), (548, 66), 52, 40, 30, seed=22)
    hand(cv, 92, 54, 86, -12, spread=1.4, curl=0.7, seed=5)
    hand(cv, 548, 54, 86, 12, spread=1.4, curl=0.7, seed=6)
    build_head(cv, 320, 252, 12.0, eye='WIDE', mouth=2.7, seed=4)
    frames.append(cv.a.copy())

    # ---- 3: SACUDIDA: cabeza ladeada y desorbitada, las bocas del vientre asoman por debajo
    cv = Cv(W, H)
    chest = cv.ellipse(330, 470, 360, 190)
    vshade(cv, chest, C.RAMP_BEL, cap=70, strength=0.9)
    mottle(cv, chest, 31, 0.9)
    for i, (dx, dy, sc) in enumerate(((120, 300, 4), (330, 318, 5), (520, 306, 3))):
        patch, pcx, pcy = belly_mouth((0, 2, 3)[i], 3)
        a2 = np.kron(patch.a, np.ones((sc, sc), dtype=np.int32))
        tmp = Cv(a2.shape[1], a2.shape[0]); tmp.a = a2
        paste(cv, tmp, int(dx) - a2.shape[1] // 2, int(dy) - a2.shape[0] // 2)
    cv.outline(OUT)
    build_head(cv, 270, 150, 9.2, eye='WIDE', mouth=2.2, tilt=13.0, seed=5, eyes_dir=(-1, 1))
    frames.append(cv.a.copy())

    # ---- 4: AGARRE: una mano enorme cae sobre la pantalla (palma hacia la cámara)
    cv = Cv(W, H)
    build_head(cv, 230, 226, 12.0, eye='WIDE', mouth=2.0, tilt=-6.0, seed=6, eyes_dir=(1, 0))
    arm(cv, (800, 420), (720, 330), (540, 250), 80, 66, 56, seed=41)
    hand(cv, 470, 215, 250, -62, spread=1.6, curl=0.3, seed=8)
    frames.append(cv.a.copy())

    # ---- 5: casi todo negro: un ojo y los dientes
    cv = Cv(W, H)
    m, eyes, mouth = build_head(cv, 330, 244, 14.0, eye='HALF', mouth=1.25, tilt=4.0, seed=7)
    keeps = [cv.ellipse(eyes[0][0], eyes[0][1], eyes[0][2] * 1.3, eyes[0][2] * 1.15), np.isin(cv.a, [TEE, TEES]) & cv.ellipse(mouth[0] - 40, mouth[1], 160, 60)]
    keep_only(cv, keeps)
    frames.append(cv.a.copy())
    return frames


def rle(a):
    flat = a.flatten()
    out, i, n = [], 0, len(flat)
    while i < n:
        v, j = int(flat[i]), i
        while j < n and flat[j] == v and j - i < 70:
            j += 1
        out.append(chr(48 + v) + chr(48 + (j - i)))
        i = j
    return out


def esc(s):
    return s.replace('\\', '\\\\').replace('$', '\\$').replace('"', '\\"')


def emit(frames, path):
    L = []
    w = L.append
    w('package com.terror2d.pixel')
    w('')
    w('/**')
    w(' * DATOS GENERADOS por tools/sprite_gen/screamer.py. NO editar a mano: edita el generador.')
    w(' * Arte del SCREAMER de captura (v0.10): %d fotogramas de %dx%d (1 px = 0,5 px lógicos), índices de la paleta de la criatura' % (len(frames), W, H))
    w(' * (0 = transparente) en tramos RLE de 2 caracteres: 48+índice y 48+longitud. Cadenas de <= 12000 tramos (límite de la JVM).')
    w(' */')
    w('object ScreamerArtData {')
    w(f'    const val WIDTH = {W}')
    w(f'    const val HEIGHT = {H}')
    w(f'    const val FRAME_COUNT = {len(frames)}')
    w('    val PALETTE: IntArray = intArrayOf(' + ', '.join('0x%02X%02X%02X%02X.toInt()' % (a, r, g, b) for r, g, b, a in PAL) + ')')
    w('    val FRAME_DATA: Array<Array<String>> = arrayOf(')
    blocks = []
    for f in frames:
        runs = rle(f)
        chunks = [''.join(runs[i:i + 12000]) for i in range(0, len(runs), 12000)]
        blocks.append('        arrayOf(\n' + ',\n'.join('            "%s"' % esc(c) for c in chunks) + '\n        )')
    w(',\n'.join(blocks))
    w('    )')
    w('}')
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, 'w', encoding='utf-8').write('\n'.join(L) + '\n')


def preview(frames, path):
    tiles = []
    for f in frames:
        arr = np.zeros((H, W, 4), dtype=np.uint8)
        arr[..., 3] = 255
        for i, c in enumerate(PAL):
            if i:
                arr[f == i] = c
        tiles.append(Image.fromarray(arr, 'RGBA'))
    sheet = Image.new('RGBA', (W * 3, H * 2), (0, 0, 0, 255))
    for i, t in enumerate(tiles):
        sheet.paste(t, ((i % 3) * W, (i // 3) * H))
    sheet.save(path)


if __name__ == '__main__':
    fr = make_frames()
    out = os.path.join(os.path.dirname(__file__), '..', '..', 'app', 'src', 'main', 'java', 'com', 'terror2d', 'pixel', 'ScreamerArtData.kt')
    emit(fr, out)
    prev = '/home/claude/screamer_preview.png' if len(sys.argv) < 2 else sys.argv[1]
    preview(fr, prev)
    print('ok', os.path.getsize(out), 'bytes')
