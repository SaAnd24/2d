package com.terror2d.conversation

import com.terror2d.audio.Emotion
import com.terror2d.audio.VoiceKind
import com.terror2d.companion.CompanionState
import com.terror2d.companion.HandState
import com.terror2d.core.GameState
import com.terror2d.events.EventType

/**
 * Conversaciones del compañero. v0.7 solo incluye lo imprescindible para DEMOSTRAR el sistema:
 *
 *  - frog_after_water      TRIGGER TEMPORAL A: tras entregar el agua a mamá (WATER_DELIVERED).
 *  - frog_after_medicine   TRIGGER TEMPORAL B: tras MEDICINE_PUZZLE_COMPLETED ("Sabía que eres un niño especial.").
 *  - frog_idle             HABLAR manual (siempre disponible, sin información nueva).
 *
 * Los dos primeros son PRUEBAS del sistema: la narrativa definitiva los sustituirá cambiando estas definiciones
 * (otro trigger, otra condición, otro texto) sin rehacer nada. NO añadir aquí cientos de diálogos todavía.
 *
 * Reglas para escribir conversaciones futuras:
 *  1. El peluche NO se mueve, no parpadea, no respira: toda la inquietud sale del niño (manos) y del sonido.
 *  2. La voz es feedback emocional (VoiceCue), nunca la frase pronunciada.
 *  3. Nada de explicar quién es el peluche ni de asustar con golpes de sonido.
 */
object Conversations {

    /** El compañero a la espalda y las manos vacías: lo mínimo para poder hablar con él. */
    val canTalk: (GameState) -> Boolean = { s ->
        s.inventory.companion.state == CompanionState.ON_BACK && s.inventory.handState == HandState.EMPTY
    }

    fun defaults(): List<ConversationDef> = listOf(
        // A — después del agua: una frase corta, sin pausas dramáticas
        ConversationDef(
            id = "frog_after_water",
            triggerType = EventType.CINEMATIC_REQUESTED,
            triggerSource = "frog_after_water",
            condition = canTalk,
            delay = 1.8f,
            priority = 10,
            lines = listOf(
                ConversationLine(
                    speaker = Speaker.COMPANION,
                    text = "¿Ya terminaste?",
                    cues = listOf(
                        VoiceCue(VoiceKind.HUM, 2, Emotion.SOFT, 0.45f, 0.18f),
                        VoiceCue(VoiceKind.HM, 1, Emotion.SOFT, 0.5f, 0.1f)
                    ),
                    leadSilence = 0.7f,
                    gapAfterSound = 0.55f
                ),
                ConversationLine(
                    speaker = Speaker.CHILD,
                    text = "Sí… ya le llevé su agua.",
                    cues = listOf(VoiceCue(VoiceKind.BABBLE, 5, Emotion.SOFT, 0.5f)),
                    leadSilence = 0.5f
                )
            )
        ),
        // B — después del puzzle: sonido suave -> silencio -> respiración/temblor -> frase
        ConversationDef(
            id = "frog_after_medicine",
            triggerType = EventType.CINEMATIC_REQUESTED,
            triggerSource = "frog_after_medicine",
            condition = canTalk,
            delay = 1.6f,
            priority = 10,
            lines = listOf(
                ConversationLine(
                    speaker = Speaker.COMPANION,
                    text = "Sabía que eres un niño especial.",
                    cues = listOf(VoiceCue(VoiceKind.HUM, 3, Emotion.CALM, 0.4f, 0.1f)),
                    leadSilence = 0.8f,
                    gapAfterSound = 2.0f,
                    tremor = 0.75f,
                    breathing = 0.65f,
                    breathSfx = true
                )
            )
        ),
        // HABLAR a mano: no aporta información (la personalidad completa del peluche NO existe en 0.7)
        ConversationDef(
            id = "frog_idle",
            manual = true,
            repeatable = true,
            cooldown = 2f,
            priority = 0,
            condition = canTalk,
            lines = listOf(
                ConversationLine(
                    speaker = Speaker.CHILD,
                    text = "Hola, Ranita.",
                    cues = listOf(VoiceCue(VoiceKind.BABBLE, 3, Emotion.SOFT, 0.45f)),
                    leadSilence = 0.5f
                ),
                ConversationLine(
                    speaker = Speaker.COMPANION,
                    text = "…",
                    cues = listOf(VoiceCue(VoiceKind.HUM, 2, Emotion.SOFT, 0.35f)),
                    leadSilence = 0.9f,
                    gapAfterSound = 0.6f,
                    autoAdvance = 1.2f
                )
            )
        )
    )
}
