package com.terror2d.events

import com.terror2d.core.GameState
import com.terror2d.ui.DialogueManager

/**
 * Tipos de evento del juego. Lista corta a propósito: la estructura es ampliable
 * (añadir un valor aquí y publicarlo con [EventBus.post]).
 */
enum class EventType {
    /** Se ha cargado una habitación (segmento). sourceId = id del segmento. */
    ON_ENTER_ROOM,

    /** Se ha interactuado con algo. sourceId = id del interactuable. */
    ON_INTERACT,

    /** Se ha abierto una puerta. sourceId = id de la puerta. */
    ON_DOOR_OPEN,

    /** Se ha examinado un objeto (texto). sourceId = id del objeto. */
    ON_OBJECT_EXAMINED,

    /** El jugador ha terminado de esconderse. sourceId = id del escondite. */
    ON_HIDE,

    /** El jugador ha terminado de salir del escondite. sourceId = id del escondite. */
    ON_EXIT_HIDE,

    /** Se ha activado un hito narrativo por primera vez. sourceId = nombre del hito. */
    ON_STORY_FLAG,

    /** El jugador ha terminado de recoger un objeto. sourceId = id del objeto. */
    ON_ITEM_PICKED,

    /** El jugador ha entregado un objeto. sourceId = id del objeto. */
    ON_ITEM_GIVEN,

    /** El jugador ha dejado un objeto en su sitio. sourceId = id del objeto. */
    ON_ITEM_PLACED,

    /** El jugador ha abierto un documento para leerlo. sourceId = id del documento. */
    ON_DOCUMENT_READ,

    /** Empieza el puzzle de medicamentos (cambio a primera persona). sourceId = id del puzzle. */
    ON_PUZZLE_STARTED,

    /** Las tres cajas están en su orden correcto. sourceId = id del puzzle. */
    MEDICINE_PUZZLE_COMPLETED,

    /** Termina el puzzle y se vuelve a tercera persona. sourceId = id del puzzle. */
    ON_PUZZLE_ENDED,

    // ---- v0.7: compañero, conversación y audio. Son eventos de ALTO NIVEL: la lógica no sabe cómo suenan. ----

    /** Un paso del niño (foot-down). sourceId = "player". Transitorio: no queda en el historial. */
    FOOTSTEP,

    /** Empieza una línea de texto del juego. sourceId = "KID" o el nombre del personaje; value = nº de caracteres. */
    DIALOGUE_LINE,

    /** Se entregó correctamente el vaso de agua a mamá (ON_STORY_FLAG water_delivered, con nombre propio). */
    WATER_DELIVERED,

    /** El niño ha recogido al peluche: pasa al COMPANION SLOT (sin ocupar las manos). sourceId = id del objeto. */
    COMPANION_PICKED_UP,

    /** El niño elige HABLAR con el compañero (botón contextual). sourceId = id del compañero. */
    FROG_TALK,

    /** Empieza la escena de conversación. sourceId = id de la conversación. */
    CONVERSATION_STARTED,

    /** Termina la escena de conversación (ya de vuelta en el gameplay). sourceId = id de la conversación. */
    CONVERSATION_ENDED,

    // ---- v0.8: la criatura (el audio decide cómo suena cada evento) ----

    /** Paso de la criatura. sourceId = "creature"; value = 1 si va en persecución. Transitorio. */
    CREATURE_STEP,

    /** La criatura cambió de estado de IA. sourceId = nombre del estado nuevo (PATROL, INVESTIGATE, CHASE...). */
    CREATURE_STATE,

    /** La criatura alcanzó al niño: empieza la secuencia de captura (sin Game Over). */
    CREATURE_CAPTURE,

    // ---- v0.9: la noche en que mamá desaparece. Eventos de ALTO NIVEL: el AudioDirector decide cómo suenan.

    /** La fase narrativa avanzó. sourceId = nombre de la fase. */
    NARRATIVE_PHASE_CHANGED,

    /** El niño dice que se va a dormir y pierde el control. sourceId = punto de interés de la cama. */
    BEDTIME_STARTED,

    /** El niño sube a la cama. */
    CHILD_CLIMBS_BED,

    /** El niño se acuesta. */
    CHILD_LIES_DOWN,

    /** Empieza el fundido a negro de dormir (tensión, audio que baja). */
    SLEEP_FADE_STARTED,

    /** El grito de mamá (ocurre UNA sola vez). */
    MOM_SCREAM,

    /** Cristales rompiéndose en otra habitación, ya con la pantalla en negro. */
    WINDOW_CRASH,

    /** El niño despierta en la casa y recupera el control. */
    CHILD_WAKES,

    /** Cambia el tiempo oído en la habitación. sourceId = CALM | STORM_FAR | STORM_INSIDE. */
    WEATHER_CHANGED,

    /** Empieza la primera aparición de la criatura. */
    CREATURE_INTRO_STARTED,

    /** Termina la primera aparición (la criatura ya no está a la vista). */
    CREATURE_INTRO_ENDED,

    /** v0.10: el survival se activa (CREATURE_ACTIVE). */
    CREATURE_ACTIVATED,

    /** v0.10: el niño atravesó una ventana. sourceId = id de la ventana. */
    WINDOW_CROSSED,

    /** v0.10: la ventana rompió la persecución: la criatura pierde el foco (pasa a LOST_TARGET). */
    CREATURE_FOCUS_LOST,

    /** v0.10: la criatura abre un poco la puerta de un armario sospechoso. sourceId = id del armario. */
    CREATURE_CLOSET_PEEK,

    /** v0.10: un foco se ha roto. sourceId = id del foco. */
    LIGHT_BROKEN,

    /** v0.10: un foco empieza a fallar. sourceId = id del foco. value = estado (BulbState.ordinal). */
    LIGHT_DEGRADED,

    /**
     * v0.10: un evento NARRATIVO pide explícitamente una escena cinematográfica (sourceId = id de la conversación).
     * Las dos escenas de prueba de Ranita (0.7/0.8) ya no se disparan al recoger a Ranita ni por eventos de gameplay.
     */
    CINEMATIC_REQUESTED
}

/** Un evento ya ocurrido. */
class GameEvent(val type: EventType, val sourceId: String, val segmentId: String, val value: Int = 0) {
    override fun toString(): String = "$type:$sourceId"
}

fun interface EventListener {
    fun onEvent(event: GameEvent)
}

/**
 * Bus de eventos sencillo. Los emisores publican, los oyentes reaccionan; ninguno se conoce.
 * Pensado para eventos puntuales (no se publican por frame).
 */
class EventBus {
    private val byType = HashMap<EventType, ArrayList<EventListener>>()
    private val all = ArrayList<EventListener>()

    /** Últimos eventos publicados (para depuración y tests). */
    private val history = ArrayList<GameEvent>()

    val postedCount: Int get() = history.size

    val last: GameEvent? get() = if (history.isEmpty()) null else history[history.size - 1]

    fun subscribe(type: EventType, listener: EventListener) {
        byType.getOrPut(type) { ArrayList() }.add(listener)
    }

    fun subscribeAll(listener: EventListener) {
        all.add(listener)
    }

    fun post(type: EventType, sourceId: String, segmentId: String = "", value: Int = 0) {
        val e = GameEvent(type, sourceId, segmentId, value)
        history.add(e)
        if (history.size > MAX_HISTORY) history.removeAt(0)
        deliver(e)
    }

    /**
     * Evento frecuente (pasos, líneas de texto): se entrega a los oyentes pero NO se guarda en el historial, para
     * no desplazar de él los eventos narrativos que consultan [wasPosted] y los tests.
     */
    fun postTransient(type: EventType, sourceId: String, segmentId: String = "", value: Int = 0) {
        deliver(GameEvent(type, sourceId, segmentId, value))
    }

    private fun deliver(e: GameEvent) {
        val type = e.type
        val specific = byType[type]
        if (specific != null) {
            for (i in 0 until specific.size) specific[i].onEvent(e)
        }
        for (i in 0 until all.size) all[i].onEvent(e)
    }

    /** ¿Se ha publicado alguna vez un evento de este tipo (y, opcionalmente, de esta fuente)? */
    fun wasPosted(type: EventType, sourceId: String? = null): Boolean {
        for (i in 0 until history.size) {
            val e = history[i]
            if (e.type == type && (sourceId == null || e.sourceId == sourceId)) return true
        }
        return false
    }

    fun clearHistory() {
        history.clear()
    }

    companion object {
        private const val MAX_HISTORY = 64
    }
}

/** Lo que una regla de evento puede usar al dispararse: el evento, el texto y el estado global. */
class TriggerContext(val event: GameEvent, val dialogue: DialogueManager, val state: GameState)

/**
 * Regla de evento declarativa: "cuando ocurra X (opcionalmente de la fuente Y), haz Z".
 * Vive en la [com.terror2d.scene.SceneDefinition]; la escena la conecta al bus.
 */
class EventTrigger(
    val type: EventType,
    val sourceId: String? = null,
    val once: Boolean = true,
    val action: (TriggerContext) -> Unit
) {
    var fired: Boolean = false
        private set

    fun matches(e: GameEvent): Boolean =
        e.type == type && (sourceId == null || sourceId == e.sourceId) && !(once && fired)

    fun fire(ctx: TriggerContext) {
        fired = true
        action(ctx)
    }
}
