package com.terror2d.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import com.terror2d.core.GameConfig
import com.terror2d.creature.ScreamerView
import com.terror2d.pixel.ScreamerArtData
import kotlin.math.cos
import kotlin.math.sin

/**
 * Dibuja el SCREAMER de captura: los fotogramas dedicados de [ScreamerArtData] (arte 640x360 generado con la paleta y
 * los rasgos de la criatura canon), con sacudida, zoom de embestida, destello de impacto y viñeta. El arte solo ocupa
 * memoria durante la captura ([prepare] al empezar, [release] al terminar).
 */
class ScreamerRenderer {
    private val frames = arrayOfNulls<Bitmap>(ScreamerArtData.FRAME_COUNT)
    private val paint = Paint().apply { isAntiAlias = false; isFilterBitmap = false; isDither = false }

    fun prepare() {
        for (i in frames.indices) if (frames[i] == null) frames[i] = decode(i)
    }

    fun release() {
        for (i in frames.indices) { frames[i]?.recycle(); frames[i] = null }
    }

    private fun decode(index: Int): Bitmap {
        val w = ScreamerArtData.WIDTH
        val h = ScreamerArtData.HEIGHT
        val px = IntArray(w * h)
        val pal = ScreamerArtData.PALETTE
        var pos = 0
        val chunks = ScreamerArtData.FRAME_DATA[index]
        for (c in chunks.indices) {
            val s = chunks[c]
            var i = 0
            while (i + 1 < s.length && pos < px.size) {
                val color = pal[s[i].code - 48]
                val run = s[i + 1].code - 48
                var k = 0
                while (k < run && pos < px.size) { px[pos++] = color; k++ }
                i += 2
            }
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(px, 0, w, 0, 0, w, h)
        return bmp
    }

    fun draw(canvas: Canvas, v: ScreamerView) {
        if (!v.active) return
        prepare()
        val bmp = frames[v.frame.coerceIn(0, frames.size - 1)] ?: return
        val w = GameConfig.LOGICAL_WIDTH.toFloat()
        val h = GameConfig.LOGICAL_HEIGHT.toFloat()
        paint.style = Paint.Style.FILL
        paint.color = 0xFF020102.toInt()
        canvas.drawRect(0f, 0f, w, h, paint)
        val shake = v.shake
        val dx = sin(v.time * 131f) * 5f * shake
        val dy = cos(v.time * 97f) * 4f * shake
        canvas.save()
        canvas.translate(w / 2f + dx, h / 2f + dy)
        canvas.scale(v.zoom, v.zoom)
        canvas.translate(-w / 2f, -h / 2f)
        canvas.scale(0.5f, 0.5f)                // 640x360 de arte -> 320x180 lógicos
        paint.alpha = 255
        canvas.drawBitmap(bmp, 0f, 0f, paint)
        canvas.restore()
        // viñeta de bordes oscuros (ocupa la pantalla y deja el centro cargado)
        for (i in 0 until 5) {
            paint.color = ((26 + i * 7) shl 24) or 0x020102
            val e = 3f + i * 5f
            canvas.drawRect(0f, 0f, e, h, paint); canvas.drawRect(w - e, 0f, w, h, paint)
            canvas.drawRect(0f, 0f, w, e * 0.6f, paint); canvas.drawRect(0f, h - e * 0.6f, w, h, paint)
        }
        val f = v.flash
        if (f > 0.01f) {
            paint.color = ((f * 150f).toInt() shl 24) or 0xE8D4C0
            canvas.drawRect(0f, 0f, w, h, paint)
        }
    }
}
