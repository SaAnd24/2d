package com.terror2d.render

import android.graphics.Canvas
import android.graphics.Paint
import com.terror2d.closet.ClosetView
import com.terror2d.core.GameConfig
import kotlin.math.sin

/**
 * Dibuja la escena del armario: negro casi total, una rendija vertical de luz entre las hojas y, si Ranita acompaña,
 * las manos del niño abrazándola (arte de [ConversationRenderer], oscurecido). Cuando la criatura se asoma, la rendija
 * se abre y aparece un ojo triste y el borde de una sonrisa con dientes (los mismos rasgos del diseño canon).
 */
class ClosetRenderer(private val conversation: ConversationRenderer) {
    private val paint = Paint().apply { isAntiAlias = false; isFilterBitmap = false; isDither = false }

    fun draw(canvas: Canvas, v: ClosetView) {
        val b = v.blend
        if (b <= 0.002f) return
        val w = GameConfig.LOGICAL_WIDTH.toFloat()
        val h = GameConfig.LOGICAL_HEIGHT.toFloat()
        paint.style = Paint.Style.FILL
        paint.color = ((b.coerceIn(0f, 1f) * 250f).toInt() shl 24) or 0x030304
        canvas.drawRect(0f, 0f, w, h, paint)

        val a = ((b - 0.4f) / 0.6f).coerceIn(0f, 1f)
        if (v.withFrog && a > 0.01f) {
            // el niño abraza a Ranita (mismo arte que la conversación; sin texto)
            conversation.drawHandsAndPlush(canvas, v.time, v.breathingIntensity, v.tremorIntensity, a)
            paint.color = ((a * 0.62f * 255f).toInt() shl 24) or 0x020203
            canvas.drawRect(0f, 0f, w, h, paint)       // más oscuro: dentro del armario casi no se ve
        }
        if (a <= 0.01f) return

        // rendija de luz entre las hojas (se estrecha y se enfría con el peligro)
        val sway = sin(v.time * 1.7f) * 0.35f * v.breathingIntensity
        val open = 1.4f + v.peek * 9f
        val cx = w * 0.5f + sway
        val warm = (1f - v.danger * 0.65f).coerceIn(0.25f, 1f)
        val r = (0x5A * warm).toInt()
        val g = (0x4A * warm).toInt()
        val bl = (0x36 * warm).toInt() + (v.danger * 14f).toInt()
        paint.color = ((a * 200f).toInt() shl 24) or (r shl 16) or (g shl 8) or bl
        canvas.drawRect(cx - open * 0.5f, h * 0.12f, cx + open * 0.5f, h * 0.88f, paint)

        if (v.peek > 0.35f) drawPeek(canvas, v, cx, h * 0.46f, a)
    }

    private fun drawPeek(canvas: Canvas, v: ClosetView, cx: Float, cy: Float, a: Float) {
        val k = ((v.peek - 0.35f) / 0.65f).coerceIn(0f, 1f) * a
        // ojo pálido y triste, mirando hacia dentro
        paint.color = ((k * 255f).toInt() shl 24) or 0xD9D2B8
        canvas.drawRect(cx - 3.2f, cy - 3f, cx + 3.2f, cy + 3f, paint)
        paint.color = ((k * 255f).toInt() shl 24) or 0x1C1424
        val look = sin(v.time * 0.9f) * 1.1f
        canvas.drawRect(cx - 1.2f + look, cy - 1.6f, cx + 1.2f + look, cy + 1.6f, paint)
        // párpado caído (tristeza)
        paint.color = ((k * 255f).toInt() shl 24) or 0x4A3A33
        canvas.drawRect(cx - 3.6f, cy - 3.6f, cx + 3.6f, cy - 1.6f, paint)
        // borde de la sonrisa con dientes
        paint.color = ((k * 220f).toInt() shl 24) or 0xE9E2C4
        var i = -3
        while (i <= 3) {
            canvas.drawRect(cx + i * 1.7f - 0.6f, cy + 9f, cx + i * 1.7f + 0.6f, cy + 11.5f, paint)
            i++
        }
        paint.color = ((k * 160f).toInt() shl 24) or 0x2A141C
        canvas.drawRect(cx - 6f, cy + 8.2f, cx + 6f, cy + 9f, paint)
    }
}
