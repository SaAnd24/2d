package com.terror2d.closet

import kotlin.math.max
import kotlin.math.min

/**
 * v0.10: estado de la ESCENA DEL ARMARIO en primera persona. Mientras el niño está escondido el mundo se funde a casi
 * negro: solo una rendija de luz, su respiración y, si lleva a Ranita, sus manos abrazándola (el mismo arte
 * cinematográfico de la conversación, más oscuro). Si NO lleva a Ranita no se muestra nada de ella.
 *
 * No tiene lógica de IA: la escena le dice si hay peligro cerca ([danger], 0..1) y si la criatura se asoma ([peeking]).
 */
class ClosetView {
    var active = false
        private set
    /** 0..1: fundido hacia/desde la escena. */
    var blend = 0f
        private set
    var time = 0f
        private set
    /** true = Ranita acompaña al niño (la escena la muestra abrazada). */
    var withFrog = false
        private set
    /** 0..1: cercanía de la criatura (la rendija se oscurece, el niño respira más y tiembla). */
    var danger = 0f
        private set
    /** 0..1: la criatura abre la puerta un poco y se asoma (ojo y sonrisa en la rendija). */
    var peek = 0f
        private set
    private var wantPeek = false
    private var wantActive = false

    val breathingIntensity: Float get() = 0.25f + 0.75f * danger
    val tremorIntensity: Float get() = 0.1f + 0.9f * danger

    fun begin(frogAccompanies: Boolean) {
        withFrog = frogAccompanies
        wantActive = true
        active = true
        time = 0f
        peek = 0f
    }

    fun end() { wantActive = false }

    /** Corta de golpe (descarga de la escena / captura). */
    fun abort() { wantActive = false; active = false; blend = 0f; peek = 0f; danger = 0f; wantPeek = false }

    fun setPeeking(v: Boolean) { wantPeek = v }

    fun update(dt: Float, dangerNow: Float) {
        if (!active) return
        time += dt
        val target = if (wantActive) 1f else 0f
        blend = if (blend < target) min(target, blend + dt / FADE_IN) else max(target, blend - dt / FADE_OUT)
        if (!wantActive && blend <= 0f) { active = false; peek = 0f; danger = 0f; return }
        danger += (dangerNow.coerceIn(0f, 1f) - danger) * min(1f, 3f * dt)
        val pt = if (wantPeek) 1f else 0f
        peek += (pt - peek) * min(1f, 2.4f * dt)
    }

    companion object {
        const val FADE_IN = 0.45f
        const val FADE_OUT = 0.3f
    }
}
