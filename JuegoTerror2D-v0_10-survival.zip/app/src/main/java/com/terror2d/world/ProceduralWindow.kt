package com.terror2d.world

import com.terror2d.draw.Cr
import com.terror2d.draw.CrayonBuilder
import com.terror2d.draw.CrayonSprite
import com.terror2d.render.WorldRenderer
import com.terror2d.story.StoryState
import com.terror2d.util.SeededRandom

/**
 * Ventana procedural reutilizable (v0.9), construida SOLO con las herramientas gráficas del motor (crayón + trazos), sin
 * imágenes. Tiene dos estados que decide [brokenWhen] según el progreso narrativo:
 *
 *  - entera: marco, noche en el cristal, cruz de madera, cortina quieta;
 *  - rota: cristal quebrado con grietas, hueco por el que entra el exterior, fragmentos sueltos en el alféizar y en el
 *    suelo, cortina movida por el viento, lluvia del exterior vista por el hueco, lluvia que entra a la habitación
 *    (objeto [WindowRainOverlay]) y una luz fría coherente ([coldLight]).
 *
 * Se crea con [build], que devuelve la ventana y su capa de lluvia; la casa solo decide dónde.
 */
class ProceduralWindow private constructor(
    val id: String,
    private val wx: Float,
    private val wy: Float,
    private val ww: Float,
    private val wh: Float,
    private val floorY: Float,
    private val curtainColor: Int,
    val coldLight: LightSource,
    private val brokenWhen: (StoryState) -> Boolean
) : WorldObject(wx - 8f, wy - 6f, ww + 16f, wh + 14f), NarrativeAware, RainSource {

    var broken: Boolean = false
        private set

    override val isRaining: Boolean get() = broken

    /** Hueco por el que entra la lluvia (mitad derecha-baja del cristal). */
    val holeLeft: Float get() = wx + ww * 0.42f
    val holeRight: Float get() = wx + ww - 4f
    val holeTop: Float get() = wy + wh * 0.38f
    val holeBottom: Float get() = wy + wh - 3f

    private var intactSprite = CrayonSprite.EMPTY
    private var backSprite = CrayonSprite.EMPTY
    private var frontSprite = CrayonSprite.EMPTY
    private var curtainStill = CrayonSprite.EMPTY
    private var curtainTorn = CrayonSprite.EMPTY
    private var floorShards = CrayonSprite.EMPTY

    private val outside = RainField(18, wx + 3f, wx + ww - 3f, wy + 3f, wy + wh - 3f, 22f, 150f, false, id.hashCode() xor 0x5A17)
    private val buf = FloatArray(18 * 4)
    private var clock = 0f
    private var sway = 0f

    init {
        collidable = false
        layer = Layer.DECOR
    }

    override fun onNarrative(story: StoryState) {
        broken = brokenWhen(story)
        coldLight.active = broken
    }

    override fun update(dt: Float) {
        if (!broken) return
        clock += dt
        outside.update(dt)
        val gust = Math.max(0f, kotlin.math.sin(clock * 0.45f))
        sway = 0.10f + 0.06f * kotlin.math.sin(clock * 1.7f) + 0.04f * kotlin.math.sin(clock * 4.3f + 1f) + 0.14f * gust * gust * gust
    }

    /** Inclinación actual de la cortina (para tests). */
    val curtainSway: Float get() = sway

    override fun prepareVisuals(rng: SeededRandom) {
        val night = 0xFF141A3C.toInt()
        // ---- ventana entera
        val a = CrayonBuilder(rng)
        a.box(wx, wy, ww, wh, Cr.CREAM)
        a.fillRect(wx + 3f, wy + 3f, ww - 6f, wh - 6f, Cr.NIGHT)
        a.dots(wx + 3f, wy + 3f, ww - 6f, wh - 6f, 5, 0xFFB8C0E8.toInt(), 1.4f)
        a.line(wx + ww / 2f, wy + 3f, wx + ww / 2f, wy + wh - 3f, Cr.CREAM, 2.5f)
        a.line(wx + 3f, wy + wh / 2f, wx + ww - 3f, wy + wh / 2f, Cr.CREAM, 2.5f)
        a.box(wx - 3f, wy + wh, ww + 6f, 4f, Cr.WOOD)
        intactSprite = a.finish()

        // ---- ventana rota: marco + noche + hueco
        val b = CrayonBuilder(rng)
        b.box(wx, wy, ww, wh, Cr.CREAM)
        b.fillRect(wx + 3f, wy + 3f, ww - 6f, wh - 6f, night)
        b.line(wx + 3f, wy + wh / 2f, wx + ww * 0.42f, wy + wh / 2f, Cr.CREAM, 2.5f)
        b.box(wx - 3f, wy + wh, ww + 6f, 4f, Cr.WOOD)
        backSprite = b.finish()

        // ---- cristal que queda: esquirlas de bordes dentados, grietas y fragmentos
        val f = CrayonBuilder(rng)
        val glass = 0x66CFE3EE
        f.fillPoly(floatArrayOf(wx + 3f, wy + 3f, wx + ww * 0.46f, wy + 3f, wx + ww * 0.40f, wy + wh * 0.22f, wx + ww * 0.28f, wy + wh * 0.40f, wx + 3f, wy + wh * 0.36f), glass)
        f.fillPoly(floatArrayOf(wx + ww * 0.50f, wy + 3f, wx + ww - 3f, wy + 3f, wx + ww - 3f, wy + wh * 0.30f, wx + ww * 0.80f, wy + wh * 0.24f, wx + ww * 0.62f, wy + wh * 0.34f), glass)
        f.fillPoly(floatArrayOf(wx + 3f, wy + wh * 0.62f, wx + ww * 0.30f, wy + wh * 0.56f, wx + ww * 0.40f, wy + wh - 3f, wx + 3f, wy + wh - 3f), glass)
        val ink = 0xCCF4F8FF.toInt()
        f.line(wx + ww * 0.40f, wy + wh * 0.38f, wx + ww * 0.12f, wy + wh * 0.06f, ink, 1f, 0.2f)
        f.line(wx + ww * 0.40f, wy + wh * 0.38f, wx + ww * 0.62f, wy + wh * 0.02f, ink, 1f, 0.2f)
        f.line(wx + ww * 0.40f, wy + wh * 0.38f, wx + ww * 0.02f, wy + wh * 0.60f, ink, 1f, 0.2f)
        f.line(wx + ww * 0.40f, wy + wh * 0.38f, wx + ww * 0.36f, wy + wh * 0.96f, ink, 1f, 0.2f)
        f.line(wx + ww * 0.20f, wy + wh * 0.22f, wx + ww * 0.30f, wy + wh * 0.18f, ink, 0.8f, 0.2f)
        // dientes de cristal en el borde del hueco
        f.poly(floatArrayOf(wx + ww * 0.42f, wy + wh * 0.50f, wx + ww * 0.50f, wy + wh * 0.56f, wx + ww * 0.44f, wy + wh * 0.64f), 0xAACFE3EE.toInt(), 0, CrayonBuilder.INK, 4f)
        f.poly(floatArrayOf(wx + ww * 0.58f, wy + wh * 0.30f, wx + ww * 0.66f, wy + wh * 0.40f, wx + ww * 0.56f, wy + wh * 0.38f), 0xAACFE3EE.toInt(), 0, CrayonBuilder.INK, 4f)
        // fragmentos sueltos en el alféizar
        f.poly(floatArrayOf(wx + ww * 0.55f, wy + wh + 0.5f, wx + ww * 0.62f, wy + wh - 3.5f, wx + ww * 0.68f, wy + wh + 0.5f), 0xCCCFE3EE.toInt(), 0, CrayonBuilder.INK, 4f)
        f.poly(floatArrayOf(wx + ww * 0.80f, wy + wh + 0.5f, wx + ww * 0.84f, wy + wh - 2.5f, wx + ww * 0.90f, wy + wh + 0.5f), 0xCCCFE3EE.toInt(), 0, CrayonBuilder.INK, 4f)
        frontSprite = f.finish()

        // ---- cortinas
        val c = CrayonBuilder(rng)
        c.poly(floatArrayOf(wx - 4f, wy - 3f, wx + ww * 0.30f, wy - 3f, wx + ww * 0.20f, wy + wh + 2f, wx - 4f, wy + wh + 2f), curtainColor)
        c.poly(floatArrayOf(wx + ww + 4f, wy - 3f, wx + ww * 0.70f, wy - 3f, wx + ww * 0.80f, wy + wh + 2f, wx + ww + 4f, wy + wh + 2f), curtainColor)
        curtainStill = c.finish()
        // en la ventana rota la cortina izquierda se hincha hacia la habitación; la derecha, rasgada, queda más corta
        val t = CrayonBuilder(rng)
        t.poly(floatArrayOf(wx - 4f, wy - 3f, wx + ww * 0.34f, wy - 3f, wx + ww * 0.26f, wy + wh * 0.55f, wx + ww * 0.12f, wy + wh + 4f, wx - 4f, wy + wh + 2f), curtainColor)
        t.poly(floatArrayOf(wx + ww + 4f, wy - 3f, wx + ww * 0.72f, wy - 3f, wx + ww * 0.86f, wy + wh * 0.40f, wx + ww * 0.78f, wy + wh * 0.70f, wx + ww + 4f, wy + wh * 0.58f), curtainColor)
        curtainTorn = t.finish()

        // ---- cristales en el suelo bajo la ventana
        val s = CrayonBuilder(rng)
        val gx = wx + ww * 0.45f
        s.poly(floatArrayOf(gx, floorY - 1f, gx + 4f, floorY - 5f, gx + 7f, floorY - 1f), 0xBBCFE3EE.toInt(), 0, CrayonBuilder.INK, 4f)
        s.poly(floatArrayOf(gx + 14f, floorY - 1f, gx + 16f, floorY - 4f, gx + 20f, floorY - 1f), 0xBBCFE3EE.toInt(), 0, CrayonBuilder.INK, 4f)
        s.poly(floatArrayOf(gx + 27f, floorY - 1f, gx + 30f, floorY - 6f, gx + 32f, floorY - 1f), 0xBBCFE3EE.toInt(), 0, CrayonBuilder.INK, 4f)
        floorShards = s.finish()
    }

    override fun visualHash(seed: Long): Long {
        var h = intactSprite.hash(seed)
        h = backSprite.hash(h)
        h = frontSprite.hash(h)
        h = curtainStill.hash(h)
        h = curtainTorn.hash(h)
        return floorShards.hash(h)
    }

    override fun render(r: WorldRenderer) {
        if (!broken) {
            r.drawSprite(intactSprite)
            r.drawSprite(curtainStill)
            return
        }
        r.drawSprite(backSprite)
        val n = outside.lines(buf)
        r.drawStrokesN(buf, n, 0xCCBFD8F0.toInt(), 0.9f)
        r.drawSprite(frontSprite)
        r.drawSprite(floorShards)
        r.drawSpriteSwayed(curtainTorn, wx + ww * 0.15f, wy - 3f, sway)
    }

    companion object {
        /**
         * Construye la ventana y su capa de lluvia (la lluvia de dentro se dibuja DELANTE de los muebles). [coldLight] es
         * la luz fría que entra por el hueco: la casa la añade a las luces del segmento.
         */
        fun build(
            id: String, x: Float, y: Float, w: Float, h: Float, floorY: Float, curtain: Int,
            coldLight: LightSource, brokenWhen: (StoryState) -> Boolean
        ): List<WorldObject> {
            val win = ProceduralWindow(id, x, y, w, h, floorY, curtain, coldLight, brokenWhen)
            return listOf(win, WindowRainOverlay(win, floorY))
        }
    }
}

/** Lluvia que entra por el hueco y cae hasta el suelo, con salpicaduras. Primer plano (delante de muebles y niño). */
class WindowRainOverlay(private val window: ProceduralWindow, floorY: Float) :
    WorldObject(window.holeLeft - 6f, window.holeTop, (window.holeRight - window.holeLeft) + 40f, floorY - window.holeTop) {

    val rain = RainField(
        22, window.holeLeft, window.holeRight, window.holeTop, floorY - 1f, 14f, 170f, true,
        window.id.hashCode() xor 0x7A11
    )
    private val drops = FloatArray(22 * 4)
    private val splash = FloatArray(RainField.MAX_SPLASH * 8)

    init {
        collidable = false
        layer = Layer.FOREGROUND
    }

    override fun prepareVisuals(rng: SeededRandom) {
        outline = EMPTY
        hatch = EMPTY
    }

    override fun visualHash(seed: Long): Long = seed + 31L * rain.count

    override fun update(dt: Float) {
        if (window.broken) rain.update(dt)
    }

    override fun render(r: WorldRenderer) {
        if (!window.broken) return
        val n = rain.lines(drops)
        r.drawStrokesN(drops, n, 0xDDBFD8F0.toInt(), 1f)
        val m = rain.splashLines(splash)
        r.drawStrokesN(splash, m, 0xCCDCEAF8.toInt(), 0.9f)
    }
}
