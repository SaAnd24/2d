package com.terror2d.world

import com.terror2d.draw.Cr
import com.terror2d.draw.CrayonBuilder
import com.terror2d.draw.CrayonSprite
import com.terror2d.interaction.Interactable
import com.terror2d.interaction.InteractionContext
import com.terror2d.interaction.InteractionIcon
import com.terror2d.interaction.InteractionResult
import com.terror2d.render.WorldRenderer
import com.terror2d.util.SeededRandom

/**
 * v0.10: VENTANA conector del laboratorio. Es una conexión espacial real: se ve en la pared (hoja entreabierta, cajón
 * para trepar), se atraviesa con una transición corta y tiene un destino concreto. Jugador y criatura pueden usarla.
 *
 * Regla de diseño: cruzar una ventana ROMPE la persecución (la criatura pierde el foco), pero no da invulnerabilidad ni
 * teletransporta a un lugar seguro. Es un conector provisional; en 0.11 se sustituye por rutas reales de la casa.
 */
class WindowPassage(
    val id: String,
    x: Float,
    floorY: Float,
    val target: WindowTarget,
    width: Float = WIDTH
) : WorldObject(x, floorY - HEIGHT, width, HEIGHT), Interactable {

    private var sprite: CrayonSprite = CrayonSprite.EMPTY

    init {
        collidable = false
        layer = Layer.DECOR
    }

    override val interactionId: String get() = id
    override val promptText: String get() = "TREPAR"
    override val promptIcon: InteractionIcon get() = InteractionIcon.EXIT
    override val zoneLeft: Float get() = x - MARGIN
    override val zoneRight: Float get() = right + MARGIN
    override val markerX: Float get() = centerX
    override val markerY: Float get() = y + 6f

    override fun executeInteraction(ctx: InteractionContext): InteractionResult =
        InteractionResult.transition(target, null)

    override fun prepareVisuals(rng: SeededRandom) {
        val b = CrayonBuilder(rng)
        val wx = x + 3f
        val wy = y
        val ww = width - 6f
        val wh = 46f
        // marco y noche del otro lado (se ve que da a OTRA habitación)
        b.box(wx, wy, ww, wh, Cr.CREAM)
        b.fillRect(wx + 3f, wy + 3f, ww - 6f, wh - 6f, Cr.NIGHT)
        // hoja entreabierta, hacia dentro
        b.poly(floatArrayOf(wx + 3f, wy + 3f, wx + ww * 0.42f, wy + 7f, wx + ww * 0.42f, wy + wh - 7f, wx + 3f, wy + wh - 3f), Cr.GLASS)
        b.line(wx + ww * 0.42f, wy + 7f, wx + ww * 0.42f, wy + wh - 7f, Cr.CREAM, 2.2f)
        b.box(wx - 3f, wy + wh, ww + 6f, 4f, Cr.WOOD)
        // cajón/taburete bajo la ventana para trepar
        b.box(wx + 4f, y + HEIGHT - 24f, ww - 8f, 24f, Cr.WOOD)
        b.line(wx + 8f, y + HEIGHT - 14f, wx + ww - 8f, y + HEIGHT - 14f, CrayonBuilder.darker(Cr.WOOD), 1.6f)
        sprite = b.finish()
        outline = EMPTY
        hatch = EMPTY
    }

    override fun visualHash(seed: Long): Long = sprite.hash(seed)

    override fun render(r: WorldRenderer) { r.drawSprite(sprite) }

    companion object {
        const val WIDTH = 44f
        const val HEIGHT = 94f
        const val MARGIN = 12f
    }
}
