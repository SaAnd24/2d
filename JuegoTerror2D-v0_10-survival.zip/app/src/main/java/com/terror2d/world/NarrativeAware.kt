package com.terror2d.world

import com.terror2d.story.StoryState
import com.terror2d.util.SeededRandom

/**
 * Objeto cuyo aspecto o presencia depende del progreso narrativo (v0.9). La escena le avisa al cargar el segmento y cada
 * vez que cambia la fase. Así la habitación de mamá pasa de "mamá durmiendo" a "habitación vacía y alterada" sin que el
 * objeto conozca coordenadas ni habitaciones.
 */
interface NarrativeAware {
    fun onNarrative(story: StoryState)
}

/** Fuente de lluvia: la escena la usa para decidir el ambiente sonoro de la habitación. */
interface RainSource {
    val isRaining: Boolean
}

/** Envuelve un objeto y solo lo muestra mientras [show] devuelva true para el estado narrativo. */
class StoryGate(
    private val inner: WorldObject,
    private val show: (StoryState) -> Boolean
) : WorldObject(inner.x, inner.y, inner.width, inner.height), NarrativeAware {

    init {
        collidable = false
        layer = inner.layer
        visible = false
    }

    override fun onNarrative(story: StoryState) {
        visible = show(story)
    }

    override fun prepareVisuals(rng: SeededRandom) {
        inner.prepareVisuals(rng)
    }

    override fun visualHash(seed: Long): Long = inner.visualHash(seed)

    override fun update(dt: Float) {
        inner.update(dt)
    }

    override fun render(r: com.terror2d.render.WorldRenderer) {
        if (visible) inner.render(r)
    }
}
