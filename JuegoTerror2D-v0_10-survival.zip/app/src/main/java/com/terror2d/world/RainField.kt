package com.terror2d.world

/**
 * Lluvia generada por el motor (v0.9): gotas que caen, y salpicaduras al llegar al suelo. Determinista (misma semilla =
 * misma lluvia), sin allocations por frame (arrays fijos) y sin imágenes. Lógica pura: [update] mueve, [lines] y
 * [splashLines] rellenan trazos (x1,y1,x2,y2) para dibujarlos de una vez.
 */
class RainField(
    val count: Int,
    private val left: Float,
    private val right: Float,
    private val top: Float,
    private val bottom: Float,
    private val windX: Float,
    private val speed: Float,
    private val splashes: Boolean,
    private val seed: Int
) {
    private val x = FloatArray(count)
    private val y = FloatArray(count)
    private val v = FloatArray(count)
    private val len = FloatArray(count)
    private val round = IntArray(count)

    private val sx = FloatArray(MAX_SPLASH)
    private val sy = FloatArray(MAX_SPLASH)
    private val sa = FloatArray(MAX_SPLASH)
    private var nextSplash = 0

    var splashCount = 0
        private set

    init {
        for (i in 0 until count) {
            spawn(i)
            y[i] = top + h01(seed + i, 977) * (bottom - top)   // reparto inicial: ya está lloviendo
        }
        for (i in 0 until MAX_SPLASH) sa[i] = -1f
    }

    private fun h01(a: Int, b: Int): Float {
        var h = a * 374761393 + b * 668265263
        h = (h xor (h ushr 13)) * 1274126177.toInt()
        h = h xor (h ushr 16)
        return (h and 0xFFFFFF) / 16777216f
    }

    private fun spawn(i: Int) {
        round[i]++
        x[i] = left + h01(seed + i * 31, round[i]) * (right - left)
        y[i] = top
        v[i] = speed * (0.75f + 0.5f * h01(seed + i * 17, round[i] + 5))
        len[i] = 2.5f + 3f * h01(seed + i * 13, round[i] + 9)
    }

    fun update(dt: Float) {
        for (i in 0 until count) {
            y[i] += v[i] * dt
            x[i] += windX * dt
            if (y[i] >= bottom) {
                if (splashes) addSplash(x[i], bottom - h01(seed + i, round[i] + 3) * 4f)
                spawn(i)
            }
        }
        var alive = 0
        for (i in 0 until MAX_SPLASH) {
            if (sa[i] >= 0f) {
                sa[i] += dt
                if (sa[i] > SPLASH_LIFE) sa[i] = -1f else alive++
            }
        }
        splashCount = alive
    }

    private fun addSplash(px: Float, py: Float) {
        sx[nextSplash] = px
        sy[nextSplash] = py
        sa[nextSplash] = 0f
        nextSplash = (nextSplash + 1) % MAX_SPLASH
    }

    /** Escribe las gotas como trazos inclinados por el viento. Devuelve cuántos floats escribió. */
    fun lines(out: FloatArray): Int {
        var n = 0
        val k = if (speed > 0f) windX / speed else 0f
        for (i in 0 until count) {
            if (n + 4 > out.size) break
            out[n++] = x[i]
            out[n++] = y[i]
            out[n++] = x[i] + len[i] * k
            out[n++] = y[i] + len[i]
        }
        return n
    }

    /** Salpicaduras: dos pequeños trazos en "V" que se abren y se apagan. Devuelve cuántos floats escribió. */
    fun splashLines(out: FloatArray): Int {
        var n = 0
        for (i in 0 until MAX_SPLASH) {
            val a = sa[i]
            if (a < 0f) continue
            if (n + 8 > out.size) break
            val r = 1f + 3.5f * (a / SPLASH_LIFE)
            val up = 1.2f + 1.8f * (1f - a / SPLASH_LIFE)
            out[n++] = sx[i]; out[n++] = sy[i]; out[n++] = sx[i] - r; out[n++] = sy[i] - up
            out[n++] = sx[i]; out[n++] = sy[i]; out[n++] = sx[i] + r; out[n++] = sy[i] - up
        }
        return n
    }

    /** Todas las gotas están dentro de la zona de lluvia (con el desvío del viento). Para tests. */
    fun allInside(margin: Float = 40f): Boolean {
        for (i in 0 until count) {
            if (y[i] < top - 0.01f || y[i] > bottom + 0.01f) return false
            if (x[i] < left - margin || x[i] > right + margin) return false
        }
        return true
    }

    companion object {
        const val MAX_SPLASH = 24
        const val SPLASH_LIFE = 0.35f
    }
}
