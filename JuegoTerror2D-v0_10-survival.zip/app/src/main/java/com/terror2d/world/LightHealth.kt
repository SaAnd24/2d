package com.terror2d.world

enum class BulbState { OK, FLICKERING, DAMAGED, BROKEN }

/**
 * v0.10: salud independiente de CADA foco de refugio. Cada vez que la luz detiene a la criatura (o el niño la usa de
 * refugio) el foco sube su contador de usos: uso normal -> parpadea -> se daña (falla a ratos) -> se rompe.
 * Los umbrales son datos del constructor: la casa definitiva fijará los reales. Cada foco tiene SU estado; nunca
 * se rompen todos a la vez.
 *
 * El foco solo protege cuando [protects]: funciona, está encendido (un interruptor lo puede apagar) y no está en una
 * fase de apagón del parpadeo. Se apoya en [LightSource.active]/[LightSource.level] sin cambiar su contrato.
 */
class LightHealth(
    val source: LightSource,
    val id: String,
    private val flickerAt: Int = 3,
    private val damageAt: Int = 5,
    private val breakAt: Int = 7
) {
    var uses = 0
        private set
    var state = BulbState.OK
        private set
    private var clock = 0f
    private var inBlink = false
    private var userActive = true

    val isBroken: Boolean get() = state == BulbState.BROKEN

    /** Registra un uso. Devuelve el estado resultante (la escena emite el ruido/sonido al romperse). */
    fun use(): BulbState {
        uses++
        state = when {
            uses >= breakAt -> BulbState.BROKEN
            uses >= damageAt -> BulbState.DAMAGED
            uses >= flickerAt -> BulbState.FLICKERING
            else -> BulbState.OK
        }
        return state
    }

    /** Apagón momentáneo del parpadeo según el estado (determinista, depende del tiempo del foco). */
    fun blinkingOff(): Boolean = when (state) {
        BulbState.OK, BulbState.BROKEN -> false
        BulbState.FLICKERING -> (clock % 4.2f) < 0.22f
        BulbState.DAMAGED -> (clock * 2.7f) % 1f < 0.38f
    }

    fun protects(): Boolean = state != BulbState.BROKEN && source.active && source.level > 0.7f && !blinkingOff()

    fun update(dt: Float) {
        clock += dt
        if (state == BulbState.BROKEN) { source.active = false; return }
        if (state == BulbState.OK) return
        val off = blinkingOff()
        if (off && !inBlink) { userActive = source.active; inBlink = true; source.active = false }
        else if (!off && inBlink) { source.active = userActive; inBlink = false }
    }

    companion object {
        /** Solo las lámparas fuertes funcionan como refugio. */
        fun isRefugeCandidate(l: LightSource): Boolean = l.type == LightType.LAMP && l.intensity >= 0.8f
        /** Mitad del ancho de la zona segura bajo el foco. */
        fun refugeHalfWidth(l: LightSource): Float = l.radius * 0.5f
    }
}
