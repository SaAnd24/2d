package com.terror2d.scene

import com.terror2d.creature.Connector
import com.terror2d.creature.ConnectorKind
import com.terror2d.world.WindowPassage

/**
 * v0.10: deriva de la definición de la casa TODAS las conexiones físicas (puertas y ventanas). La IA no sabe de
 * habitaciones concretas: solo de esta lista de conexiones. La casa definitiva podrá aportar las suyas
 * (escaleras, huecos, atajos...) sin tocar la IA.
 */
fun SceneDefinition.buildConnectors(): List<Connector> {
    val out = ArrayList<Connector>()
    for (seg in segments) {
        for (d in seg.doors) {
            val t = d.target ?: continue
            val dest = segments.firstOrNull { it.id == t.segmentId } ?: continue
            val sp = dest.spawnPoints[t.spawnId] ?: continue
            out.add(Connector(d.id, ConnectorKind.DOOR, seg.id, d.centerX, dest.id, sp.x))
        }
        for (o in seg.objects) {
            if (o !is WindowPassage) continue
            val dest = segments.firstOrNull { it.id == o.target.segmentId } ?: continue
            val sp = dest.spawnPoints[o.target.spawnId] ?: continue
            out.add(Connector(o.id, ConnectorKind.WINDOW, seg.id, o.centerX, dest.id, sp.x))
        }
    }
    return out
}
