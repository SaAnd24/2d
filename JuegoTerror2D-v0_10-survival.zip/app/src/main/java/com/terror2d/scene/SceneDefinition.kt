package com.terror2d.scene

import com.terror2d.conversation.ConversationDef
import com.terror2d.core.WorldMode
import com.terror2d.events.EventTrigger
import com.terror2d.story.SceneScript

/** Punto de aparición: X del CENTRO de los pies y hacia dónde mira. La Y la da el suelo del segmento. */
class SpawnPoint(val x: Float, val facing: Int = 1)

/**
 * Descripción de una escena (p. ej. una casa): una semilla y una lista de segmentos laterales
 * conectados por puertas, más reglas de eventos opcionales. Futuras escenas solo necesitan crear
 * una definición, sin tocar el motor.
 */
class SceneDefinition(
    val id: String,
    val seed: Long,
    val segments: List<RoomSegment>,
    val startSegmentId: String,
    val startSpawnId: String = "start",
    val triggers: List<EventTrigger> = emptyList(),
    val scripts: List<SceneScript> = emptyList(),
    /**
     * Versiones TRAUMA de los segmentos (mismo id que el segmento NORMAL). Vacío en v0.5: la arquitectura
     * ya contempla el segundo mundo, pero no existe ningún mapa del Mundo Trauma todavía.
     */
    val traumaSegments: List<RoomSegment> = emptyList(),
    /** v0.7: conversaciones del compañero de esta escena (datos puros; ver [com.terror2d.conversation.Conversations]). */
    val conversations: List<ConversationDef> = emptyList(),
    /** v0.8: criatura que patrulla un segmento (null = ninguna). */
    val creature: CreatureSpawn? = null,
    /** v0.9: puntos de interés semánticos (CHILD_BED, MOTHER_WINDOW...). La narrativa solo habla con ellos. */
    val pointsOfInterest: com.terror2d.story.PointsOfInterest = com.terror2d.story.PointsOfInterest.EMPTY
) {
    /** Segmento [id] en el mundo [mode]; si ese mundo no define una variante, se usa el NORMAL. */
    fun segmentFor(id: String, mode: WorldMode): RoomSegment {
        if (mode == WorldMode.TRAUMA) {
            val v = traumaSegments.firstOrNull { it.id == id }
            if (v != null) return v
        }
        return segment(id)
    }

    /**
     * v0.9: puerta del segmento [from] que acerca al niño al segmento [to] (búsqueda en anchura por las puertas).
     * null si ya está en [to] o no hay ruta. Así una secuencia automática no sabe qué habitaciones hay en medio.
     */
    fun routeDoor(from: String, to: String): com.terror2d.world.Door? {
        if (from == to) return null
        val first = HashMap<String, com.terror2d.world.Door>()
        val queue = ArrayList<String>()
        val seen = HashSet<String>()
        queue.add(from)
        seen.add(from)
        var head = 0
        while (head < queue.size) {
            val cur = queue[head++]
            val seg = segments.firstOrNull { it.id == cur } ?: continue
            for (d in seg.doors) {
                val t = d.target ?: continue
                if (!seen.add(t.segmentId)) continue
                val via = if (cur == from) d else first[cur] ?: continue
                first[t.segmentId] = via
                if (t.segmentId == to) return via
                queue.add(t.segmentId)
            }
        }
        return null
    }

    fun segment(id: String): RoomSegment =
        segments.firstOrNull { it.id == id }
            ?: throw IllegalArgumentException("Segmento no definido en $id: $id")
}

/**
 * Dónde y cuándo aparece la criatura. [requiredFlag]: hito de historia que debe estar activo (null = siempre);
 * en 0.8 es una condición técnica controlada, no narrativa.
 */
class CreatureSpawn(
    val segmentId: String,
    val x: Float,
    val minX: Float,
    val maxX: Float,
    val seed: Int = 8,
    val requiredFlag: String? = null
)
