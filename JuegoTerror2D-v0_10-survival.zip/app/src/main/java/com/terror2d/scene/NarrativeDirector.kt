package com.terror2d.scene

import com.terror2d.core.GameState
import com.terror2d.events.EventType
import com.terror2d.events.GameEvent
import com.terror2d.story.BedGeometry
import com.terror2d.story.BedtimeSequence
import com.terror2d.story.CreatureIntro
import com.terror2d.story.NarrativePhase
import com.terror2d.story.Poi
import com.terror2d.story.PointOfInterest
import com.terror2d.story.StoryFlags
import com.terror2d.world.DoorTarget
import com.terror2d.world.Player
import kotlin.math.abs

/**
 * Director narrativo de v0.9: el puente entre la rutina inicial y la primera aparición de la criatura.
 *
 *   puzzle terminado -> el niño se va a dormir -> negro + grito de mamá -> despierta (Ranita disponible)
 *   -> habitación de mamá vacía, ventana rota, nota -> la criatura se muestra en el pasillo -> SURVIVAL_READY
 *
 * REGLA DE ORO: nada aquí conoce coordenadas ni nombres de habitaciones. Todo se resuelve por PUNTOS DE INTERÉS
 * ([Poi]) de [SceneDefinition.pointsOfInterest]. Al construir la casa definitiva basta con recolocar esos puntos.
 *
 * Reutiliza lo existente: el sistema de documentos para la nota, el texto del juego, las transiciones de puerta, la
 * criatura de 0.8 (solo movida por guion) y el AudioDirector (la lógica solo publica eventos). Las fases son hitos
 * persistentes y monótonos: la secuencia no se puede saltar ni repetir.
 */
class NarrativeDirector(private val scene: Scene) {

    val bedtime = BedtimeSequence()
    val creatureIntro = CreatureIntro()

    /** El niño avanza solo por orden de la secuencia (-1, 0, +1). */
    var walkDir = 0f
        private set

    val autoWalking: Boolean get() = walkDir != 0f

    /** Mientras dura la secuencia de dormir el jugador no manda. */
    val controlLocked: Boolean get() = bedtime.controlLocked

    /** Negro de la secuencia (se suma al de las transiciones y la captura). */
    val blackAlpha: Float get() = bedtime.blackAlpha

    private var pending = false
    private var pendingTimer = 0f
    private var noteTimer = -1f
    private var walkTimer = 0f
    private var lastDx = 0f
    private var bodyApplied = false

    private val pois get() = scene.definition.pointsOfInterest

    // ------------------------------------------------------------------ eventos

    fun onEvent(e: GameEvent, state: GameState) {
        val story = state.story
        when (e.type) {
            EventType.ON_STORY_FLAG -> when (e.sourceId) {
                StoryFlags.MEDICINE_PUZZLE_COMPLETED -> if (story.advanceTo(NarrativePhase.MEDICINE_COMPLETED)) {
                    pending = true
                    pendingTimer = 0f
                    announce(NarrativePhase.MEDICINE_COMPLETED, state)
                }
                StoryFlags.MOM_NOTE_READ -> if (story.advanceTo(NarrativePhase.MOM_NOTE_READ)) {
                    noteTimer = 0f
                    announce(NarrativePhase.MOM_NOTE_READ, state)
                }
                else -> {}
            }
            EventType.ON_ENTER_ROOM -> {
                val room = pois[Poi.MOTHER_BEDROOM]
                if (room != null && e.sourceId == room.segmentId && story.isAtLeast(NarrativePhase.PLUSH_UNLOCKED) &&
                    story.advanceTo(NarrativePhase.MOTHER_ROOM_DISCOVERED)
                ) {
                    story.set(StoryFlags.MOTHER_ROOM_DISCOVERED)
                    announce(NarrativePhase.MOTHER_ROOM_DISCOVERED, state)
                    scene.dialogue.showMessage(DISCOVER_LINE)
                }
            }
            else -> {}
        }
    }

    /** Al cargar un segmento: sincroniza el director con los hitos (persistencia) y corta lo que dependía del segmento. */
    fun onSegmentLoaded(state: GameState) {
        lastDx = 0f
        val st = state.story
        if (st.has(StoryFlags.CREATURE_INTRO_DONE)) creatureIntro.markDone()
        else if (st.isAtLeast(NarrativePhase.CREATURE_INTRO_UNLOCKED)) creatureIntro.unlock()
        if (creatureIntro.active) creatureIntro.abort()
        if (!bedtime.active && bedtime.phase == BedtimeSequence.Phase.IDLE) {
            val ph = st.phase
            if (ph == NarrativePhase.MEDICINE_COMPLETED) pending = true
            // seguridad: si se retomara una partida a mitad de la noche, no se queda bloqueada Ranita ni la historia
            if (ph.ordinal >= NarrativePhase.CHILD_GOES_TO_BED.ordinal && ph.ordinal <= NarrativePhase.MOM_SCREAM.ordinal) {
                st.set(StoryFlags.MOM_SCREAM_HEARD)
                st.set(StoryFlags.PLUSH_AVAILABLE)
                st.advanceTo(NarrativePhase.PLUSH_UNLOCKED)
            }
        }
        if (st.isAtLeast(NarrativePhase.MOM_NOTE_READ) && !st.isAtLeast(NarrativePhase.CREATURE_INTRO_UNLOCKED) && noteTimer < 0f) noteTimer = 0f
    }

    private fun announce(phase: NarrativePhase, state: GameState) {
        scene.events.post(EventType.NARRATIVE_PHASE_CHANGED, phase.name, scene.currentSegment.id)
        scene.refreshNarrative(state)
    }

    // ------------------------------------------------------------------ cada frame

    fun update(dt: Float, state: GameState) {
        walkDir = 0f
        if (pending && bedtime.phase == BedtimeSequence.Phase.IDLE) {
            if (scene.isFreeForNarrative) {
                pendingTimer += dt
                if (pendingTimer >= START_DELAY) startBedtime(state)
            } else {
                pendingTimer = 0f
            }
        }
        if (bedtime.active) runBedtime(dt, state)
        runNote(dt, state)
        runIntro(dt, state)
    }

    // ------------------------------------------------------------------ dormir

    private fun startBedtime(state: GameState) {
        pending = false
        val bed = pois[Poi.CHILD_BED] ?: return
        if (!state.story.advanceTo(NarrativePhase.CHILD_GOES_TO_BED)) return
        announce(NarrativePhase.CHILD_GOES_TO_BED, state)
        scene.events.post(EventType.BEDTIME_STARTED, bed.id, scene.currentSegment.id)
        scene.dialogue.showMessage(BEDTIME_LINE)
        bedtime.start()
    }

    private fun runBedtime(dt: Float, state: GameState) {
        val bed = pois.require(Poi.CHILD_BED)
        val seq = bedtime
        val before = seq.phase
        var arrived = false
        if (seq.phase == BedtimeSequence.Phase.WALK) arrived = walk(bed, dt)
        seq.update(dt, !scene.dialogue.isActive, arrived)
        if (seq.phase != before) onBedPhase(seq.phase, bed, state)
        if (seq.takeScream()) fireScream(state)
        if (seq.takeCrash()) scene.events.post(EventType.WINDOW_CRASH, Poi.MOTHER_WINDOW, scene.currentSegment.id)
        applyBody(bed)
    }

    private fun onBedPhase(p: BedtimeSequence.Phase, bed: PointOfInterest, state: GameState) {
        val seg = scene.currentSegment.id
        when (p) {
            BedtimeSequence.Phase.WALK -> {
                walkTimer = 0f
                lastDx = 0f
            }
            BedtimeSequence.Phase.CLIMB -> scene.events.post(EventType.CHILD_CLIMBS_BED, bed.id, seg)
            BedtimeSequence.Phase.LIE -> scene.events.post(EventType.CHILD_LIES_DOWN, bed.id, seg)
            BedtimeSequence.Phase.FADE_OUT -> {
                state.story.advanceTo(NarrativePhase.SLEEP_SEQUENCE)
                announce(NarrativePhase.SLEEP_SEQUENCE, state)
                scene.events.post(EventType.SLEEP_FADE_STARTED, bed.id, seg)
            }
            BedtimeSequence.Phase.WAKE -> {
                fireScream(state)   // red de seguridad: si un frame enorme se saltó el grito, suena ahora (nunca dos veces)
                releaseBody()
                val pl = scene.player
                pl.x = BedGeometry.approachX(bed) - Player.WIDTH / 2f
                pl.facing = -1f
                scene.events.post(EventType.CHILD_WAKES, bed.id, seg)
                scene.dialogue.showMessage(WAKE_LINE)
            }
            BedtimeSequence.Phase.DONE -> {
                // el control vuelve: la noche cambió la casa
                state.story.advanceTo(NarrativePhase.PLUSH_UNLOCKED)
                announce(NarrativePhase.PLUSH_UNLOCKED, state)
            }
            else -> {}
        }
    }

    /** El grito: UNA sola vez, pase lo que pase. Desbloquea a Ranita y avanza la fase. */
    private fun fireScream(state: GameState) {
        if (!state.story.set(StoryFlags.MOM_SCREAM_HEARD)) return
        val seg = scene.currentSegment.id
        state.story.advanceTo(NarrativePhase.MOM_SCREAM)
        scene.events.post(EventType.MOM_SCREAM, Poi.MOTHER_BEDROOM, seg)
        if (state.story.set(StoryFlags.PLUSH_AVAILABLE)) scene.events.post(EventType.ON_STORY_FLAG, StoryFlags.PLUSH_AVAILABLE, seg)
        announce(NarrativePhase.MOM_SCREAM, state)
    }

    /** Camina hacia la cama: por las puertas que haga falta, sin saber qué habitaciones hay en medio. */
    private fun walk(bed: PointOfInterest, dt: Float): Boolean {
        if (scene.transition.isActive) return false
        walkTimer += dt
        val seg = scene.currentSegment
        if (walkTimer > WALK_FAILSAFE) return failsafe(bed)
        if (seg.id != bed.segmentId) {
            val door = scene.definition.routeDoor(seg.id, bed.segmentId) ?: return failsafe(bed)
            if (stepTo(door.centerX)) {
                if (door.activate()) scene.events.post(EventType.ON_DOOR_OPEN, door.id, seg.id)
                val t = door.target
                if (t != null) scene.transition.start(t, door)
            }
            return false
        }
        return stepTo(BedGeometry.approachX(bed))
    }

    /** Nunca se queda colgada: si no hay ruta o tarda demasiado, salta a la cama con un fundido. */
    private fun failsafe(bed: PointOfInterest): Boolean {
        walkTimer = 0f
        if (scene.currentSegment.id == bed.segmentId) {
            scene.player.x = BedGeometry.approachX(bed) - Player.WIDTH / 2f
            return true
        }
        val room = pois[Poi.CHILD_BEDROOM]
        if (room != null && room.spawnId.isNotEmpty()) scene.transition.start(DoorTarget(room.segmentId, room.spawnId), null)
        return false
    }

    private fun stepTo(targetX: Float): Boolean {
        val p = scene.player
        val dx = targetX - p.centerX
        val crossed = lastDx != 0f && lastDx * dx < 0f
        if (abs(dx) <= ARRIVE_TOL || crossed) {
            walkDir = 0f
            lastDx = 0f
            p.x = targetX - Player.WIDTH / 2f
            return true
        }
        lastDx = dx
        walkDir = if (dx > 0f) 1f else -1f
        return false
    }

    /** Subir -> acomodarse -> acostarse con las poses del niño más elevación y giro. */
    private fun applyBody(bed: PointOfInterest) {
        val seq = bedtime
        if (!seq.bodyControlled) {
            if (bodyApplied) releaseBody()
            return
        }
        val a = BedGeometry.approachX(bed)
        val c = BedGeometry.climbX(bed)
        val l = BedGeometry.lieFeetX(bed)
        val path = seq.bodyPath
        val x = if (path < 1f) a + (c - a) * path else c + (l - c) * (path - 1f)
        val p = scene.player
        p.x = x - Player.WIDTH / 2f
        p.bodyLift = bed.rise * seq.liftFraction + BedGeometry.HOP * seq.hop + BedGeometry.BACK_THICKNESS * seq.lyingFraction
        p.bodyAngle = seq.angle
        p.poseOverride = seq.pose
        p.eyesOverride = if (seq.eyesClosed) com.terror2d.pixel.EyeState.CLOSED else null
        p.facing = if (seq.facingRight) 1f else -1f
        bodyApplied = true
    }

    private fun releaseBody() {
        val p = scene.player
        p.bodyLift = 0f
        p.bodyAngle = 0f
        p.poseOverride = null
        p.eyesOverride = null
        bodyApplied = false
    }

    // ------------------------------------------------------------------ nota -> criatura

    private fun runNote(dt: Float, state: GameState) {
        if (noteTimer < 0f) return
        if (scene.isFreeForNarrative) noteTimer += dt
        if (noteTimer >= INTRO_DELAY) {
            noteTimer = -1f
            if (state.story.advanceTo(NarrativePhase.CREATURE_INTRO_UNLOCKED)) {
                state.story.set(StoryFlags.CREATURE_INTRO_UNLOCKED)
                creatureIntro.unlock()
                announce(NarrativePhase.CREATURE_INTRO_UNLOCKED, state)
            }
        }
    }

    private fun runIntro(dt: Float, state: GameState) {
        val ci = creatureIntro
        val trig = pois[Poi.HALLWAY_CREATURE_TRIGGER] ?: return
        val stage = pois[Poi.HALLWAY_CREATURE_STAGE] ?: return
        val seg = scene.currentSegment
        when (ci.phase) {
            CreatureIntro.Phase.WAITING -> {
                if (seg.id == trig.segmentId && scene.isFreeForNarrative && trig.contains(scene.player.centerX)) {
                    ci.begin(stage.right, stage.left, stage.right + EXIT_BEYOND)
                    if (ci.active) {
                        scene.spawnScriptedCreature(stage.right)
                        scene.events.post(EventType.CREATURE_INTRO_STARTED, "creature", seg.id)
                    }
                }
            }
            CreatureIntro.Phase.APPEAR, CreatureIntro.Phase.LOOK, CreatureIntro.Phase.LEAVE -> {
                val c = scene.creature
                if (c == null || seg.id != stage.segmentId) {
                    ci.abort()
                    scene.clearCreature()
                    return
                }
                ci.update(dt, c.x, scene.player.centerX)
                if (ci.phase == CreatureIntro.Phase.DONE) finishIntro(state, seg.id)
            }
            else -> {}
        }
    }

    private fun finishIntro(state: GameState, segId: String) {
        scene.clearCreature()
        state.story.set(StoryFlags.CREATURE_INTRO_DONE)
        state.story.set(StoryFlags.SURVIVAL_READY)
        state.story.advanceTo(NarrativePhase.SURVIVAL_READY)
        scene.events.post(EventType.CREATURE_INTRO_ENDED, "creature", segId)
        announce(NarrativePhase.SURVIVAL_READY, state)
        scene.dialogue.showMessage(INTRO_LINE)
    }

    companion object {
        /** La frase pedida, tal cual: corta, de niño de 8 años. */
        const val BEDTIME_LINE = "Bueno... debería irme a mi habitación ya. Es tarde."
        const val WAKE_LINE = "¿Mamá…? ¿Qué fue ese ruido?"
        const val DISCOVER_LINE = "¿Mamá? Su cama está vacía. Y hace mucho frío."
        const val INTRO_LINE = "¿Qué… era eso?"

        /** Calma tras terminar el puzzle antes de decir que se va a dormir. */
        const val START_DELAY = 1.5f

        /** Intervalo narrativo entre leer la nota y desbloquear la primera aparición. */
        const val INTRO_DELAY = 2.5f

        const val ARRIVE_TOL = 2.5f
        const val WALK_FAILSAFE = 40f
        const val EXIT_BEYOND = 40f
    }
}
