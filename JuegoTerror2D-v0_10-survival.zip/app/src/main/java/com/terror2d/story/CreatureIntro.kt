package com.terror2d.story

import kotlin.math.abs

/**
 * Primera aparición de la criatura (v0.9): una revelación, NO una persecución. Lógica pura y guionizada:
 *
 *   LOCKED -> WAITING (desbloqueada, esperando al niño) -> APPEAR (entra despacio) -> LOOK (se queda quieta mirando al
 *   niño) -> LEAVE (se va de la vista) -> DONE
 *
 * Mientras está activa, la IA normal de la criatura NO corre (no ve, no oye, no persigue, no captura): la escena la mueve
 * con [goalX]/[speed]/[facing] y el gesto de mirar con [gaze].
 */
class CreatureIntro {
    enum class Phase { LOCKED, WAITING, APPEAR, LOOK, LEAVE, DONE }

    var phase = Phase.LOCKED
        private set
    var goalX = 0f
        private set
    var speed = 0f
        private set
    var facing = -1f
        private set
    var gaze = false
        private set

    private var lookX = 0f
    private var exitX = 0f
    private var t = 0f

    val unlocked: Boolean get() = phase != Phase.LOCKED
    val active: Boolean get() = phase == Phase.APPEAR || phase == Phase.LOOK || phase == Phase.LEAVE

    fun unlock() {
        if (phase == Phase.LOCKED) phase = Phase.WAITING
    }

    fun markDone() {
        phase = Phase.DONE
        speed = 0f
        gaze = false
    }

    /** Empieza la aparición: entra desde [startX], se detiene en [lookX] y se marcha hacia [exitX]. */
    fun begin(startX: Float, lookX: Float, exitX: Float) {
        if (phase != Phase.WAITING) return
        this.lookX = lookX
        this.exitX = exitX
        goalX = lookX
        speed = APPEAR_SPEED
        facing = if (lookX < startX) -1f else 1f
        gaze = false
        t = 0f
        phase = Phase.APPEAR
    }

    /** El niño se fue a otra habitación a mitad: vuelve a esperar (se repetirá entera). */
    fun abort() {
        if (active) {
            phase = Phase.WAITING
            speed = 0f
            gaze = false
        }
    }

    fun update(dt: Float, creatureX: Float, playerX: Float) {
        when (phase) {
            Phase.APPEAR -> if (abs(creatureX - lookX) < 2f) {
                phase = Phase.LOOK
                t = 0f
                speed = 0f
                gaze = true
            }
            Phase.LOOK -> {
                t += dt
                speed = 0f
                facing = if (playerX < creatureX) -1f else 1f
                if (t >= LOOK_TIME) {
                    phase = Phase.LEAVE
                    gaze = false
                    goalX = exitX
                    speed = LEAVE_SPEED
                    facing = if (exitX > creatureX) 1f else -1f
                }
            }
            Phase.LEAVE -> if (abs(creatureX - exitX) < 2f) {
                phase = Phase.DONE
                speed = 0f
            }
            else -> {}
        }
    }

    companion object {
        const val APPEAR_SPEED = 22f
        const val LEAVE_SPEED = 26f
        const val LOOK_TIME = 3.2f
    }
}
