package com.terror2d.story

import com.terror2d.pixel.PixelPose

/**
 * Geometría de la cama derivada de su punto de interés: todo es relativo a [PointOfInterest.x]/[PointOfInterest.width],
 * así que mover la cama (otra casa) mueve la secuencia sin tocar nada más. Se sube por el pie de la cama (derecha) y se
 * acuesta con la cabeza hacia la izquierda.
 */
object BedGeometry {
    /** Dónde se detiene el niño, en el suelo, antes de subir. */
    fun approachX(bed: PointOfInterest): Float = bed.right + 8f

    /** Dónde apoya los pies al subir al colchón. */
    fun climbX(bed: PointOfInterest): Float = bed.right - 20f

    /** Dónde quedan sus pies al acostarse (la cabeza cae hacia la almohada). */
    fun lieFeetX(bed: PointOfInterest): Float = bed.x + bed.width * 0.2f

    /** Grosor de la espalda del niño: al tumbarse, el pivote sube esto sobre la superficie. */
    const val BACK_THICKNESS = 9f

    /** Salto extra (px) al subir. */
    const val HOP = 6f
}

/**
 * Secuencia de irse a dormir (v0.9): lógica pura de tiempos, sin Android (como la captura de 0.8). La escena le dice si
 * el niño ya terminó de hablar ([update] speechDone) y si ya llegó a la cama (arrived); ella devuelve la animación
 * (pose, giro, altura), el negro, el momento del grito y cuándo termina.
 *
 *   SAY -> WALK -> CLIMB -> SETTLE -> LIE -> REST -> FADE_OUT -> BLACK (grito) -> WAKE -> DONE
 *
 * Caminar -> subir -> acomodarse -> acostarse usa las poses actuales del niño (WALK_*, PICKUP, HIDE, IDLE) más un giro
 * y una elevación del sprite; no hay animaciones nuevas del protagonista.
 */
class BedtimeSequence {
    enum class Phase { IDLE, SAY, WALK, CLIMB, SETTLE, LIE, REST, FADE_OUT, BLACK, WAKE, DONE }

    var phase = Phase.IDLE
        private set
    private var t = 0f
    private var screamFired = false
    private var crashFired = false

    val active: Boolean get() = phase != Phase.IDLE && phase != Phase.DONE
    val isDone: Boolean get() = phase == Phase.DONE
    val timeInPhase: Float get() = t

    fun start() {
        if (phase != Phase.IDLE) return
        phase = Phase.SAY
        t = 0f
    }

    private fun go(p: Phase) {
        phase = p
        t = 0f
    }

    fun update(dt: Float, speechDone: Boolean, arrived: Boolean) {
        t += dt
        when (phase) {
            Phase.SAY -> if (speechDone && t >= MIN_SAY) go(Phase.WALK)
            Phase.WALK -> if (arrived) go(Phase.CLIMB)
            Phase.CLIMB -> if (t >= CLIMB_TIME) go(Phase.SETTLE)
            Phase.SETTLE -> if (t >= SETTLE_TIME) go(Phase.LIE)
            Phase.LIE -> if (t >= LIE_TIME) go(Phase.REST)
            Phase.REST -> if (t >= REST_TIME) go(Phase.FADE_OUT)
            Phase.FADE_OUT -> if (t >= FADE_TIME) go(Phase.BLACK)
            Phase.BLACK -> if (t >= BLACK_TIME) go(Phase.WAKE)
            Phase.WAKE -> if (t >= WAKE_TIME) go(Phase.DONE)
            else -> {}
        }
    }

    /** true UNA sola vez, cuando toca el grito (ya en negro). */
    fun takeScream(): Boolean {
        if (phase != Phase.BLACK || screamFired || t < SCREAM_AT) return false
        screamFired = true
        return true
    }

    /** true UNA sola vez: los cristales, un poco después del grito. */
    fun takeCrash(): Boolean {
        if (phase != Phase.BLACK || crashFired || t < CRASH_AT) return false
        crashFired = true
        return true
    }

    private val progress: Float get() = (t / lengthOf(phase)).coerceIn(0f, 1f)

    private fun lengthOf(p: Phase): Float = when (p) {
        Phase.CLIMB -> CLIMB_TIME
        Phase.SETTLE -> SETTLE_TIME
        Phase.LIE -> LIE_TIME
        Phase.REST -> REST_TIME
        Phase.FADE_OUT -> FADE_TIME
        Phase.BLACK -> BLACK_TIME
        Phase.WAKE -> WAKE_TIME
        else -> 1f
    }

    private fun smooth(x: Float): Float = x * x * (3f - 2f * x)

    /** El niño está en la cama (o subiendo): el cuerpo lo controla la secuencia, no el caminar normal. */
    val bodyControlled: Boolean get() = phase.ordinal >= Phase.CLIMB.ordinal && phase.ordinal <= Phase.BLACK.ordinal

    /** Recorrido horizontal: 0 = aproximación, 1 = sobre el colchón, 2 = posición de acostado. */
    val bodyPath: Float
        get() = when (phase) {
            Phase.CLIMB -> smooth(progress)
            Phase.SETTLE -> 1f + smooth(progress)
            Phase.LIE, Phase.REST, Phase.FADE_OUT, Phase.BLACK -> 2f
            else -> 0f
        }

    /** Fracción (0..1) de la altura de la cama a la que están los pies. */
    val liftFraction: Float
        get() = when (phase) {
            Phase.CLIMB -> smooth(progress)
            Phase.SETTLE, Phase.LIE, Phase.REST, Phase.FADE_OUT, Phase.BLACK -> 1f
            else -> 0f
        }

    /** Impulso del salto (0..1..0) mientras sube. */
    val hop: Float
        get() = if (phase == Phase.CLIMB) kotlin.math.sin(Math.PI.toFloat() * progress) else 0f

    /** 0..1: cuánto se ha tumbado (sube el pivote por el grosor de la espalda). */
    val lyingFraction: Float
        get() = when (phase) {
            Phase.LIE -> smooth(progress)
            Phase.REST, Phase.FADE_OUT, Phase.BLACK -> 1f
            else -> 0f
        }

    /** Giro del sprite en grados: 0 de pie, -90 tumbado de espaldas con la cabeza a la izquierda. */
    val angle: Float get() = -90f * lyingFraction

    val pose: PixelPose
        get() = when (phase) {
            Phase.CLIMB -> if (progress < 0.5f) PixelPose.PICKUP else PixelPose.WALK_2
            Phase.SETTLE -> PixelPose.HIDE
            Phase.LIE -> if (progress < 0.3f) PixelPose.HIDE else PixelPose.IDLE
            else -> PixelPose.IDLE
        }

    /** Mira hacia la derecha. Sube mirando a la cama (izquierda), se da la vuelta para sentarse y se recuesta. */
    val facingRight: Boolean
        get() = when (phase) {
            Phase.CLIMB -> false
            Phase.SETTLE -> progress >= 0.4f
            else -> true
        }

    val eyesClosed: Boolean
        get() = when (phase) {
            Phase.LIE -> progress > 0.6f
            Phase.REST, Phase.FADE_OUT, Phase.BLACK -> true
            else -> false
        }

    /** Opacidad del negro (0..1). Durante WAKE el negro se disipa. */
    val blackAlpha: Float
        get() = when (phase) {
            Phase.FADE_OUT -> smooth(progress)
            Phase.BLACK -> 1f
            Phase.WAKE -> 1f - smooth(progress)
            else -> 0f
        }

    /** La escena está bajo control de la secuencia (el jugador no manda). */
    val controlLocked: Boolean get() = active

    companion object {
        const val MIN_SAY = 0.8f
        const val CLIMB_TIME = 1.0f
        const val SETTLE_TIME = 1.2f
        const val LIE_TIME = 1.3f
        const val REST_TIME = 0.9f
        const val FADE_TIME = 2.4f

        /** Pantalla negra: silencio, grito, cristales y de nuevo silencio. */
        const val SCREAM_AT = 1.7f
        const val CRASH_AT = 3.0f
        const val BLACK_TIME = 5.4f
        const val WAKE_TIME = 1.8f
    }
}
