package com.terror2d.story

/**
 * Fases narrativas del arco de v0.9 (rutina inicial -> desaparición de mamá -> primera aparición de la criatura),
 * en ORDEN. La fase actual es siempre la más alta alcanzada: nunca retrocede, así que la secuencia no se puede
 * saltar ni repetir por accidente. Cada fase vive como un hito de [StoryState] (persistente con el resto de hitos).
 */
enum class NarrativePhase(val flag: String) {
    INITIAL_ROUTINE("phase_initial_routine"),
    MEDICINE_COMPLETED("phase_medicine_completed"),
    CHILD_GOES_TO_BED("phase_child_goes_to_bed"),
    SLEEP_SEQUENCE("phase_sleep_sequence"),
    MOM_SCREAM("phase_mom_scream"),
    PLUSH_UNLOCKED("phase_plush_unlocked"),
    MOTHER_ROOM_DISCOVERED("phase_mother_room_discovered"),
    MOM_NOTE_READ("phase_mom_note_read"),
    CREATURE_INTRO_UNLOCKED("phase_creature_intro_unlocked"),

    /** La criatura ya se ha mostrado: queda preparado el terreno de los sistemas survival de v0.10. */
    SURVIVAL_READY("phase_survival_ready");

    companion object {
        /** Copia única de los valores (sin allocations al consultar la fase cada frame). */
        val ALL: Array<NarrativePhase> = values()
    }
}

/**
 * Punto de interés semántico: un identificador con un lugar en el mundo. La narrativa habla de "CHILD_BED" o
 * "MOTHER_WINDOW", nunca de coordenadas: cuando la casa definitiva cambie de sitio las habitaciones y los objetos,
 * solo hay que recolocar estos puntos en la definición de la casa.
 *
 * @param x centro horizontal del punto (coordenadas del segmento).
 * @param width extensión horizontal (la cama mide lo que mide; una zona de disparo, lo que abarca).
 * @param rise altura sobre el suelo de la superficie útil (p. ej. la cama), en px lógicos.
 * @param spawnId punto de aparición del segmento al entrar por su puerta (vacío = ninguno).
 */
class PointOfInterest(
    val id: String,
    val segmentId: String,
    val x: Float,
    val width: Float = 0f,
    val rise: Float = 0f,
    val spawnId: String = ""
) {
    val left: Float get() = x - width / 2f
    val right: Float get() = x + width / 2f

    fun contains(px: Float): Boolean = px >= left && px <= right
}

/** Identificadores semánticos de los puntos de interés de la secuencia de 0.9. */
object Poi {
    const val CHILD_BEDROOM = "CHILD_BEDROOM"
    const val CHILD_BED = "CHILD_BED"
    const val MOTHER_BEDROOM = "MOTHER_BEDROOM"
    const val MOTHER_BED = "MOTHER_BED"
    const val MOTHER_WINDOW = "MOTHER_WINDOW"
    const val MOTHER_NOTE = "MOTHER_NOTE"
    const val HALLWAY_CREATURE_TRIGGER = "HALLWAY_CREATURE_TRIGGER"

    /** Escenario de la primera aparición: x = centro, width = recorrido (entra por la derecha, mira, vuelve a irse). */
    const val HALLWAY_CREATURE_STAGE = "HALLWAY_CREATURE_STAGE"
}

/** Registro de puntos de interés de una escena. */
class PointsOfInterest(list: List<PointOfInterest> = emptyList()) {
    private val byId = HashMap<String, PointOfInterest>()

    init {
        for (p in list) byId[p.id] = p
    }

    operator fun get(id: String): PointOfInterest? = byId[id]

    fun has(id: String): Boolean = byId.containsKey(id)

    fun require(id: String): PointOfInterest =
        byId[id] ?: throw IllegalArgumentException("Punto de interés no definido: $id")

    val ids: Set<String> get() = byId.keys

    companion object {
        val EMPTY = PointsOfInterest()
    }
}
