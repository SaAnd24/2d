package com.terror2d.story

import com.terror2d.core.GameState
import com.terror2d.events.EventBus
import com.terror2d.events.EventType
import com.terror2d.events.GameEvent
import com.terror2d.ui.DialogueManager

/**
 * Estado narrativo: simples hitos (flags) con nombre. Es deliberadamente genérico: la introducción
 * de v0.4 lo usa y v0.5/v0.6 (medicamentos, puzzle) pueden añadir sus propios hitos sin cambiar nada.
 */
class StoryState {
    private val flags = HashSet<String>()

    fun has(flag: String): Boolean = flags.contains(flag)

    /** Activa el hito. Devuelve true solo la primera vez. */
    fun set(flag: String): Boolean = flags.add(flag)

    val count: Int get() = flags.size

    /** v0.9: fase narrativa actual = la más alta alcanzada (vive en los mismos hitos, así que es persistente). */
    val phase: NarrativePhase
        get() {
            var best = NarrativePhase.INITIAL_ROUTINE
            val all = NarrativePhase.ALL
            for (i in all.indices) {
                val p = all[i]
                if (p.ordinal > best.ordinal && flags.contains(p.flag)) best = p
            }
            return best
        }

    fun isAtLeast(p: NarrativePhase): Boolean = phase.ordinal >= p.ordinal

    /** Avanza a la fase [p]. NUNCA retrocede. Devuelve true solo si realmente avanzó. */
    fun advanceTo(p: NarrativePhase): Boolean {
        if (isAtLeast(p)) return false
        flags.add(p.flag)
        return true
    }
}

/** Nombres de los hitos de la introducción. */
object StoryFlags {
    const val INTRO_STARTED = "intro_started"
    const val HEARD_CALL = "heard_call"
    const val HEARD_PILLS = "heard_pills"
    const val HEARD_WATER = "heard_water"
    const val INTRO_CALLS_DONE = "intro_calls_done"
    const val SAW_PILLS = "saw_pills"
    const val GOT_WATER = "got_water"
    const val TALKED_TO_MOM = "talked_to_mom"
    const val INTRO_DONE = "intro_done"
    const val WATER_DELIVERED = "water_delivered"
    const val PILLS_REQUESTED = "pills_requested"
    const val GOT_PILLS = "got_pills"
    const val PILLS_DELIVERED = "pills_delivered"

    // --- v0.6: documentos y puzzle de medicamentos
    const val READ_DOC_MEDICAL = "read_doc_medical"
    const val READ_DOC_FINANCE = "read_doc_finance"
    const val READ_DOC_PHARMACY = "read_doc_pharmacy"
    const val PUZZLE_STARTED = "medicine_puzzle_started"
    const val MEDICINE_PUZZLE_DONE = "medicine_puzzle_done"
    const val MEDICINE_CODE_KNOWN = "medicine_code_known"

    // --- v0.8: primera criatura (condición técnica de prueba; la narrativa real llega en 0.9)
    /** Tras completar el puzzle de medicinas, la criatura patrulla el pasillo (condición controlada de 0.8). */
    const val CREATURE_ACTIVE = "creature_active"
    const val CREATURE_FIRST_CAPTURE = "creature_first_capture"

    // --- v0.9: la desaparición de mamá y la primera aparición de la criatura
    /** El puzzle de medicamentos terminó bien. Es el MISMO hito que [MEDICINE_PUZZLE_DONE]; con este nombre arranca la noche. */
    const val MEDICINE_PUZZLE_COMPLETED = MEDICINE_PUZZLE_DONE

    /** Ranita ya se puede recoger (estado narrativo, no una coordenada). Mientras no esté, PLUSH_LOCKED. */
    const val PLUSH_AVAILABLE = "plush_available"
    const val MOM_SCREAM_HEARD = "mom_scream_heard"
    const val MOTHER_ROOM_DISCOVERED = "mother_room_discovered"
    const val MOM_NOTE_READ = "mom_note_read"
    const val CREATURE_INTRO_UNLOCKED = "creature_intro_unlocked"
    const val CREATURE_INTRO_DONE = "creature_intro_done"

    /** Preparado para 0.10: tras la aparición ya se pueden activar los sistemas survival (luces, rutas, armarios...). */
    const val SURVIVAL_READY = "survival_ready"
}

/** Lo que un guion de escena puede usar. */
class ScriptContext(val dialogue: DialogueManager, val state: GameState, val events: EventBus) {
    /** Segmento activo. */
    var segmentId: String = ""

    /** Activa un hito y publica ON_STORY_FLAG la primera vez. */
    fun setFlag(flag: String): Boolean {
        val isNew = state.story.set(flag)
        if (isNew) events.post(EventType.ON_STORY_FLAG, flag, segmentId)
        return isNew
    }
}

/** Guion de escena: reacciona a eventos y/o al paso del tiempo. */
interface SceneScript {
    fun onEvent(e: GameEvent, ctx: ScriptContext) {}
    fun update(dt: Float, ctx: ScriptContext) {}
}
