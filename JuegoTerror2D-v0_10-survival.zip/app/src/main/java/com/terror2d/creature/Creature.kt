package com.terror2d.creature

import com.terror2d.pixel.LightingSample
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.sin

/** Animaciones pedidas para la criatura (las poses de cuerpo base se reutilizan; ver [Creature.bodyPose]). */
enum class CreatureAnim {
    IDLE, PATROL, WALK, RUN, WALK_1, WALK_2, WALK_3, INVESTIGATE, ALERT, CHASE_1, CHASE_2, LOST_TARGET, RETURN_TO_PATROL, HURT_LIGHT, CAPTURE
}

/** Estados de los ojos (índice = orden de CreatureSpriteData.EYE_STATES). */
object CreatureEye { const val OPEN = 0; const val HALF = 1; const val CLOSED = 2; const val LOOK_DOWN = 3; const val WIDE = 4 }

/** Estados de la boca principal (índice = orden de CreatureSpriteData.MAIN_MOUTH_STATES). */
object CreatureMouth { const val CLOSED = 0; const val TENSE = 1; const val OPEN = 2; const val WIDE = 3 }

/**
 * La criatura en el mundo: cerebro de IA + animación (pasos, brazos con inercia, ojos, bocas) + iluminación.
 * Todo es determinista y dependiente del tiempo; no hay objetos nuevos por frame.
 */
class Creature(
    x: Float,
    val segmentId: String,
    minX: Float,
    maxX: Float,
    seed: Int = 7,
    moveMin: Float = minX,
    moveMax: Float = maxX
) {
    val brain = CreatureBrain(x, segmentId, minX, maxX, seed, moveMin, moveMax)
    val mouths = MouthAnimator(SECONDARY, seed * 31 + 5)
    private val seedI = seed

    val x: Float get() = brain.x
    /** Sentido en que mira: +1 derecha, -1 izquierda. */
    val facing: Float get() = brain.facing
    val state: CreatureState get() = brain.state
    val arousal: Float get() = brain.arousal

    /** Iluminación recibida (la calcula la escena con LightField, igual que el niño). */
    val light = LightingSample()
    var time = 0f
        private set

    /** Fase del ciclo de paso (0..1 = dos pasos); avanza con la DISTANCIA recorrida, así los pies no patinan. */
    var gaitPhase = 0f
        private set
    /** Frame (0..7) del ciclo: 0 y 4 son los apoyos de cada pie. */
    var gaitFrame = 0
        private set
    /** Caminando o terminando el paso (se detiene en un apoyo, sin saltos de pose). */
    var gaitActive = false
        private set
    /** 0 = quieto, 1..8 = frame del ciclo + 1 (compatibilidad). */
    val walkFrame: Int get() = if (gaitActive) gaitFrame + 1 else 0
    var anim = CreatureAnim.IDLE
        private set
    /** Brazos como péndulos pesados (delantero y trasero). */
    val leadArm = ArmPendulum()
    val trailArm = ArmPendulum(stiffness = 12f, damping = 2.2f)
    private var lastShoulder = FloatArray(4)
    private var lastPose = -1
    /** Brazo con inercia (0..1) según la velocidad (compatibilidad / audio). */
    var armLag = 0f
        private set
    var eyeState = CreatureEye.HALF
        private set
    var mainMouth = CreatureMouth.CLOSED
        private set
    private var blinkClock = 0f
    var hurtTimer = 0f
    var capturing = false
    /** Y del suelo del segmento (la escena la fija al colocar a la criatura). */
    var floorY = 0f

    /** Aviso de paso (para el audio): se llama con (intensidad 0..1, esChase). */
    var onStep: ((Float, Boolean) -> Unit)? = null
    /** Aviso de sonido de boca/alarma por cambio de estado (para el audio). */
    var onStateChanged: ((CreatureState, CreatureState) -> Unit)? = null
    private var lastState = CreatureState.PATROL

    /** v0.9: true = mira fija al niño con los ojos abiertos (primera aparición). */
    var gaze = false

    fun update(dt: Float, senses: Senses, noises: List<NoiseEvent>) {
        time += dt
        brain.update(dt, senses, noises)
        advance(dt)
    }

    /** v0.9: un paso guionizado (la IA no corre). Misma animación, pasos, brazos, ojos y bocas que siempre. */
    fun updateScripted(dt: Float, goalX: Float, speed: Float, face: Float) {
        time += dt
        brain.scripted(dt, goalX, speed, face)
        advance(dt)
    }

    private fun advance(dt: Float) {
        val st = brain.state
        if (st != lastState) { onStateChanged?.invoke(lastState, st); lastState = st }
        val sp = brain.speed
        val moving = sp > 1f
        val chasing = st == CreatureState.CHASE
        // ciclo de paso por distancia: paso corto al caminar (15 px lógicos), largo al perseguir (30)
        val stepLen = if (chasing) RUN_STEP else WALK_STEP
        if (moving) {
            gaitActive = true
            gaitPhase = (gaitPhase + sp * dt / (2f * stepLen)) % 1f
        } else if (gaitActive) {
            // terminar el paso hasta el siguiente apoyo (frame 0 o 4) para no teletransportar los pies
            val f = (gaitPhase * 8f).toInt() and 7
            if (f == 0 || f == 4) { gaitActive = false; gaitPhase = f / 8f } else gaitPhase = (gaitPhase + dt * 0.9f) % 1f
        }
        val prevFrame = gaitFrame
        gaitFrame = (gaitPhase * 8f).toInt() and 7
        if (gaitActive && gaitFrame != prevFrame && (gaitFrame == 0 || gaitFrame == 4)) onStep?.invoke(if (chasing) 1f else 0.55f, chasing)
        val target = min(1f, sp / CreatureBrain.CHASE_SPEED * 1.1f)
        armLag += (target - armLag) * min(1f, (if (target > armLag) 2.2f else 1.1f) * dt)
        updateAnim(st, moving)
        updateArms(dt, chasing)
        updateFace(dt, st)
        anim = pickAnim(st, moving)
        if (hurtTimer > 0f) hurtTimer -= dt
        if (brain.blockedByLight && !wasLightBlocked) hurtTimer = 0.7f   // la luz la frena: retrocede doliéndose
        wasLightBlocked = brain.blockedByLight
    }
    private var wasLightBlocked = false

    private fun updateAnim(st: CreatureState, moving: Boolean) {
        anim = pickAnim(st, moving)
    }

    private fun pickAnim(st: CreatureState, moving: Boolean): CreatureAnim {
        if (capturing) return CreatureAnim.CAPTURE
        if (hurtTimer > 0f) return CreatureAnim.HURT_LIGHT
        val walking = moving || gaitActive
        return when (st) {
            CreatureState.CHASE -> if (walking) CreatureAnim.RUN else CreatureAnim.ALERT
            CreatureState.INVESTIGATE -> if (walking) CreatureAnim.WALK else CreatureAnim.ALERT
            CreatureState.LOST_TARGET -> if (walking) CreatureAnim.WALK else CreatureAnim.LOST_TARGET
            CreatureState.RETURN_TO_PATROL -> if (walking) CreatureAnim.WALK else CreatureAnim.RETURN_TO_PATROL
            CreatureState.PATROL -> if (walking) CreatureAnim.WALK else CreatureAnim.IDLE
        }
    }

    /** Pose de cuerpo (orden de CreatureSpriteData.BODY_POSES): el frame del ciclo de paso o una pose estática. */
    fun bodyPose(): Int = when (anim) {
        CreatureAnim.WALK, CreatureAnim.WALK_1, CreatureAnim.WALK_2, CreatureAnim.WALK_3 -> CreaturePose.WALK0 + gaitFrame
        CreatureAnim.RUN -> CreaturePose.RUN0 + gaitFrame
        CreatureAnim.CHASE_1, CreatureAnim.CHASE_2 -> CreaturePose.RUN0 + gaitFrame
        CreatureAnim.INVESTIGATE, CreatureAnim.LOST_TARGET -> CreaturePose.INVESTIGATE
        CreatureAnim.ALERT -> CreaturePose.ALERT
        CreatureAnim.CAPTURE -> CreaturePose.CAPTURE
        CreatureAnim.HURT_LIGHT -> CreaturePose.HURT
        else -> CreaturePose.IDLE
    }

    /**
     * Los brazos cuelgan del hombro de la pose actual. Objetivo: contrabalanceo suave de la pierna contraria (más amplio
     * y echado atrás al correr; hacia delante al capturar) + empujón de inercia cuando el hombro se mueve con el cuerpo.
     */
    private fun updateArms(dt: Float, chasing: Boolean) {
        val pose = bodyPose()
        val anchors = com.terror2d.pixel.CreatureSpriteData.BODY_ANCHORS[pose]
        if (lastPose >= 0 && pose != lastPose) {
            val prev = com.terror2d.pixel.CreatureSpriteData.BODY_ANCHORS[lastPose]
            val dLx = (anchors[4] - prev[4]).toFloat(); val dLy = (anchors[5] - prev[5]).toFloat()
            val dTx = (anchors[6] - prev[6]).toFloat(); val dTy = (anchors[7] - prev[7]).toFloat()
            // el cuerpo avanza/cae: el brazo (pesado) se queda atrás y el antebrazo cuelga
            if (abs(dLx) < 14f) { leadArm.kick(-dLx * KICK); leadArm.kickElbow(-dLy * 9f) }
            if (abs(dTx) < 14f) { trailArm.kick(-dTx * KICK); trailArm.kickElbow(-dTy * 9f) }
        }
        lastPose = pose
        val amp = if (chasing) 20f else 9f
        val base = if (chasing) -16f else -3f
        val ph = gaitPhase * 6.2831855f
        val swing = if (gaitActive) kotlin.math.cos(ph) * amp else 0f
        val breathe = sin(time * 1.1f) * 2.5f
        var tl = base - swing + breathe
        var tt = base + swing - breathe
        if (capturing) { tl = 58f; tt = 52f }                    // los brazos se echan hacia delante
        else if (hurtTimer > 0f) { tl = -26f; tt = -22f }
        leadArm.update(dt, tl)
        trailArm.update(dt, tt)
    }

    /** Índice (balanceo * 3 + codo) del sprite del brazo delantero / trasero. */
    fun leadArmIndex(): Int = leadArm.index
    fun trailArmIndex(): Int = trailArm.index

    /** Respiración visual (0..1 de amplitud): lenta en PATROL, fuerte en CHASE. */
    fun breath(): Float = sin(time * (1.4f + 5.5f * arousal)) * (0.4f + 1.4f * arousal)

    private fun updateFace(dt: Float, st: CreatureState) {
        blinkClock += dt
        val blinkEvery = 3.2f + 2.4f * Det.hash01(seedI, floor(time / 3f).toInt())
        val blink = (blinkClock % blinkEvery) < 0.16f
        eyeState = when {
            blink -> CreatureEye.CLOSED
            st == CreatureState.CHASE -> CreatureEye.WIDE                 // miran al niño, siguen siendo tristes
            st == CreatureState.INVESTIGATE || st == CreatureState.LOST_TARGET -> CreatureEye.OPEN
            else -> if ((time * 0.35f).toInt() % 3 == 2) CreatureEye.LOOK_DOWN else CreatureEye.HALF   // mirada perdida
        }
        if (gaze && !blink) eyeState = CreatureEye.OPEN
        mainMouth = when (st) {
            CreatureState.CHASE -> if (sin(time * 9f) > 0f) CreatureMouth.WIDE else CreatureMouth.OPEN
            CreatureState.LOST_TARGET -> if (sin(time * 2.2f) > 0.2f) CreatureMouth.OPEN else CreatureMouth.TENSE
            CreatureState.INVESTIGATE -> CreatureMouth.TENSE
            else -> if (sin(time * 0.6f + seedI) > 0.85f) CreatureMouth.TENSE else CreatureMouth.CLOSED
        }
    }

    /** Distancia al niño (para el audio de proximidad). */
    fun distanceTo(px: Float) = abs(px - x)

    companion object {
        /** Nº de bocas secundarias: sale de los datos del sprite (cabeza + torso). */
        val SECONDARY: Int = com.terror2d.pixel.CreatureSpriteData.HEAD_MOUTHS.size + com.terror2d.pixel.CreatureSpriteData.TORSO_MOUTHS.size
        /** Alto lógico aproximado (176 px de sprite × 0,5). */
        const val HEIGHT = 94f
        /** Ancho lógico del cuerpo (para huecos que no puede cruzar). */
        const val BODY_WIDTH = 52f
        /** Pasos en px lógicos (la mitad del recorrido de un pie en el sprite): caminar y correr. */
        const val WALK_STEP = 15f
        const val RUN_STEP = 30f
        private const val KICK = 7f
    }
}
