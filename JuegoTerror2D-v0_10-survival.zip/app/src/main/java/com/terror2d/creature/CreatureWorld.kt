package com.terror2d.creature

import kotlin.math.abs

enum class ConnectorKind { DOOR, WINDOW }

/**
 * v0.10: una conexión física entre dos segmentos (puerta o ventana). Es DATO: la escena la deriva de la definición de
 * la casa, así la casa de prueba es reemplazable (en 0.11 serán escaleras, huecos, atajos...) sin tocar la IA.
 */
class Connector(
    val id: String,
    val kind: ConnectorKind,
    val fromSeg: String,
    val fromX: Float,
    val toSeg: String,
    val toX: Float
)

/** La criatura aparece en [segmentId] porque llegó por una conexión. */
class Arrival(
    val segmentId: String,
    val x: Float,
    val state: CreatureState,
    val lastKnownX: Float,
    val facing: Float,
    val via: ConnectorKind
)

/**
 * Presencia PERSISTENTE de la criatura en la casa. La escena solo simula (con [Creature]/[CreatureBrain]) el segmento
 * donde está el niño; este rastreador mantiene a la criatura viva fuera de pantalla: dónde está, qué estado tenía y
 * qué conexión va a usar. Reglas de 0.10:
 *
 *  - PUERTA: si la criatura PERSEGUÍA al niño, va hasta la puerta y lo sigue en CHASE.
 *  - VENTANA: rompe la persecución. Pierde el foco (LOST_TARGET), conserva la última posición conocida (la ventana),
 *    la investiga y puede cruzarla (más despacio que el niño) para seguir buscando en la otra habitación.
 */
class CreatureTracker(
    private val connectors: List<Connector>,
    startSeg: String,
    startX: Float
) {
    var segId: String = startSeg
        private set
    var x: Float = startX
        private set
    var state: CreatureState = CreatureState.PATROL
        private set
    var lastKnownX: Float = startX
        private set
    var facing: Float = 1f
        private set
    var arousal: Float = 0f
        private set
    /** true = la criatura está materializada en la escena actual (la simula el [Creature]). */
    var live: Boolean = false
        private set

    private var plan: Connector? = null
    private var climbing = false
    private var timer = 0f
    private var idleLost = 0f

    val isCrossing: Boolean get() = plan != null
    val plannedConnector: Connector? get() = plan

    fun connectorById(id: String): Connector? = connectors.firstOrNull { it.id == id }

    /** Vuelve a patrulla en su sitio de origen (tras una captura el niño despierta a salvo). */
    fun resetTo(seg: String, cx: Float) {
        segId = seg; x = cx; lastKnownX = cx; state = CreatureState.PATROL
        plan = null; climbing = false; idleLost = 0f; live = false
    }

    /** La escena marca si la criatura está (o no) materializada. */
    fun setLive(v: Boolean) { live = v }

    /** Copia el estado real de la criatura simulada. */
    fun syncLive(seg: String, cx: Float, st: CreatureState, known: Float, face: Float, arousalNow: Float) {
        segId = seg; x = cx; state = st; lastKnownX = known; facing = face; arousal = arousalNow
        plan = null; climbing = false; idleLost = 0f
    }

    /**
     * El niño acaba de cruzar [c]. Si la criatura estaba en el segmento de origen decide qué hace.
     * Devuelve true si la criatura pasa a tener un plan de cruce.
     */
    fun onPlayerLeft(c: Connector): Boolean {
        if (segId != c.fromSeg) return false
        when (c.kind) {
            ConnectorKind.WINDOW -> {
                // LA VENTANA ROMPE LA PERSECUCIÓN: pierde el foco directo, sin teletransporte ni invulnerabilidad.
                if (state == CreatureState.CHASE || state == CreatureState.INVESTIGATE || state == CreatureState.LOST_TARGET) {
                    state = CreatureState.LOST_TARGET
                    lastKnownX = c.fromX
                    plan = c; climbing = false; timer = 0f
                    return true
                }
            }
            ConnectorKind.DOOR -> {
                if (state == CreatureState.CHASE) {
                    lastKnownX = c.fromX
                    plan = c; climbing = false; timer = 0f
                    return true
                }
            }
        }
        return false
    }

    /** Avanza la criatura fuera de pantalla. Devuelve una [Arrival] cuando entra en el segmento del jugador. */
    fun update(dt: Float, playerSeg: String): Arrival? {
        if (live) return null
        val p = plan
        if (p != null) {
            if (!climbing) {
                val sp = if (state == CreatureState.CHASE) CreatureBrain.CHASE_SPEED else CreatureBrain.LOST_SPEED
                val dx = p.fromX - x
                facing = if (dx >= 0f) 1f else -1f
                val step = sp * dt
                if (abs(dx) <= step) { x = p.fromX; climbing = true; timer = if (p.kind == ConnectorKind.WINDOW) WINDOW_CLIMB_TIME else DOOR_DELAY }
                else x += facing * step
            } else {
                timer -= dt
                if (timer <= 0f) return cross(p, playerSeg)
            }
            return null
        }
        // sin plan: la búsqueda fuera de pantalla se enfría sola
        if (state == CreatureState.LOST_TARGET || state == CreatureState.INVESTIGATE) {
            idleLost += dt
            if (idleLost > OFFSCREEN_SEARCH_TIME) { state = CreatureState.PATROL; idleLost = 0f }
        }
        return null
    }

    private fun cross(c: Connector, playerSeg: String): Arrival? {
        plan = null; climbing = false
        segId = c.toSeg
        x = c.toX
        val intoFacing = 1f   // las llegadas se colocan junto al lado de entrada: mira hacia el interior
        facing = intoFacing
        val newState: CreatureState
        val known: Float
        if (c.kind == ConnectorKind.WINDOW) {
            newState = CreatureState.LOST_TARGET          // sigue SIN ver al niño: busca, no persigue
            known = c.toX + 60f
        } else {
            newState = if (playerSeg == c.toSeg) CreatureState.CHASE else CreatureState.LOST_TARGET
            known = c.toX + 120f
        }
        state = newState
        lastKnownX = known
        idleLost = 0f
        return if (playerSeg == c.toSeg) Arrival(c.toSeg, c.toX, newState, known, intoFacing, c.kind) else null
    }

    companion object {
        const val WINDOW_CLIMB_TIME = 1.9f
        const val DOOR_DELAY = 0.8f
        const val OFFSCREEN_SEARCH_TIME = 9f
    }
}
