package com.terror2d.creature

/**
 * v0.10: reacción de la criatura ante un armario según el abuso. Base de la regla futura de escalada:
 * PASS (uso normal) -> SUSPICION (se detiene y se asoma: advertencia) -> WARNING -> CAPTURE (ya no se deja engañar).
 * Cada armario tiene su propio contador; en 0.10 solo SUSPICION y CAPTURE tienen efecto de juego, pero la estructura
 * ya existe para no rehacer nada en 0.11.
 */
enum class ClosetReaction { PASS, SUSPICION, WARNING, CAPTURE }

class ClosetMemory(
    /** Usos a partir de los cuales aparece cada reacción (usos totales del MISMO armario). */
    private val suspicionAt: Int = 3,
    private val warningAt: Int = 4,
    private val captureAt: Int = 6
) {
    private val uses = HashMap<String, Int>()

    fun usesOf(closetId: String): Int = uses[closetId] ?: 0

    /** El niño entra en [closetId]. Devuelve la reacción que corresponde a ESTE uso. */
    fun register(closetId: String): ClosetReaction {
        val n = usesOf(closetId) + 1
        uses[closetId] = n
        return reactionFor(n)
    }

    fun reactionFor(n: Int): ClosetReaction = when {
        n >= captureAt -> ClosetReaction.CAPTURE
        n >= warningAt -> ClosetReaction.WARNING
        n >= suspicionAt -> ClosetReaction.SUSPICION
        else -> ClosetReaction.PASS
    }

    /** Reacción actual sin contar un uso nuevo. */
    fun current(closetId: String): ClosetReaction = reactionFor(usesOf(closetId))

    /** Tras una captura el armario "se olvida": el niño vuelve a su refugio. */
    fun forgive(closetId: String) { uses.remove(closetId) }

    fun reset() { uses.clear() }
}
