package com.terror2d.creature

import kotlin.math.sin

/**
 * v0.10: estado del SCREAMER de captura. El arte (varios fotogramas dedicados, generados por
 * tools/sprite_gen/screamer.py con la misma paleta y rasgos de la criatura canon) lo dibuja
 * [com.terror2d.render.ScreamerRenderer]; aquí solo viven los TIEMPOS: qué fotograma toca, cuánto tiembla la pantalla,
 * el destello del impacto y las marcas de audio sincronizadas con los cambios de fotograma.
 *
 *  fotograma 0  la cara emerge de la oscuridad: solo ojos tristes y el brillo de los dientes
 *  fotograma 1  EMBESTIDA: la cabeza llena la pantalla, sonrisa abierta                (IMPACTO + sonido)
 *  fotograma 2  la boca se abre del todo; los brazos largos enmarcan la pantalla       (RUGIDO)
 *  fotograma 3  sacudida: cabeza ladeada, ojos desorbitados, bocas del vientre asomando
 *  fotograma 4  la mano larga cae sobre la pantalla (agarre)                           (AGARRE)
 *  fotograma 5  casi todo negro: solo los dientes y un ojo
 */
class ScreamerView {
    var active = false
        private set
    var time = 0f
        private set
    private var cueIndex = 0

    /** Fotograma de arte (0 until [FRAME_COUNT]) que toca ahora. */
    val frame: Int
        get() {
            var f = 0
            for (i in FRAME_START.indices) if (time >= FRAME_START[i]) f = i
            return f
        }

    /** 0..1 sacudida de pantalla (mayor en los impactos). */
    val shake: Float
        get() {
            var s = 0f
            for (c in CUE_TIMES) {
                val d = time - c
                if (d in 0f..0.28f) s = maxOf(s, 1f - d / 0.28f)
            }
            return s * (0.75f + 0.25f * sin(time * 90f))
        }

    /** 0..1 destello rojo/blanco del impacto (solo ~0.12 s tras la embestida y el agarre). */
    val flash: Float
        get() {
            var f = 0f
            for (c in CUE_TIMES) { val d = time - c; if (d in 0f..0.12f) f = maxOf(f, 1f - d / 0.12f) }
            return f
        }

    /** Zoom del primerísimo plano: crece durante la embestida. */
    val zoom: Float get() = 1f + 0.22f * (time / DURATION).coerceIn(0f, 1f) + 0.12f * shake

    val done: Boolean get() = active && time >= DURATION

    fun begin() { active = true; time = 0f; cueIndex = 0 }
    fun end() { active = false }

    fun update(dt: Float) {
        if (!active) return
        time += dt
    }

    /** Devuelve (una vez) el siguiente cue de audio cuyo instante ya pasó, o -1. Los cues coinciden con cambios de fotograma. */
    fun consumeCue(): Int {
        if (!active || cueIndex >= CUE_TIMES.size) return -1
        if (time >= CUE_TIMES[cueIndex]) return cueIndex++
        return -1
    }

    companion object {
        const val FRAME_COUNT = 6
        const val DURATION = 2.0f
        /** Instante de inicio de cada fotograma. */
        val FRAME_START = floatArrayOf(0f, 0.22f, 0.46f, 0.80f, 1.16f, 1.62f)
        /** Cues de audio: 0 = impacto/embestida, 1 = rugido, 2 = agarre. Sincronizados con FRAME_START[1], [2] y [4]. */
        val CUE_TIMES = floatArrayOf(FRAME_START[1], FRAME_START[2], FRAME_START[4])
        const val CUE_IMPACT = 0
        const val CUE_ROAR = 1
        const val CUE_GRAB = 2
    }
}
