package com.terror2d.creature

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class CreatureState { PATROL, INVESTIGATE, CHASE, LOST_TARGET, RETURN_TO_PATROL }

/** Intervalo X que la criatura no puede cruzar (hueco pequeño, ventilación). [blocksSight] = false: se ve a través. */
class Blocker(val x0: Float, val x1: Float, val blocksSight: Boolean, val isLight: Boolean = false)

/** Lo que la criatura puede saber en cada paso: nada de «posición mágica» del niño salvo lo que ve. */
class Senses(
    var playerX: Float = 0f,
    var playerSegmentId: String = "",
    var playerHidden: Boolean = false,
    /** Brillo de la luz sobre el niño (0 = oscuridad, 1 = iluminado). */
    var playerLight: Float = 1f,
    var blockers: List<Blocker> = emptyList(),
    var now: Float = 0f,
    /** v0.10: el niño está entrando en un escondite o ya dentro (la criatura puede haberlo VISTO entrar). */
    var playerHiding: Boolean = false,
    /** v0.10: el niño está dentro de una zona de refugio de luz (foco que funciona). */
    var playerInRefuge: Boolean = false,
    /** v0.10: reacción acumulada de este armario ([ClosetReaction.ordinal]); 0 = uso normal. */
    var closetReaction: Int = 0
)

/**
 * Cerebro de la criatura en vista lateral (1 eje). Máquina de estados PATROL → INVESTIGATE → CHASE →
 * LOST_TARGET → RETURN_TO_PATROL. Determinista (sin azar por frame) y barato: la IA corre a [AI_STEP].
 */
class CreatureBrain(
    var x: Float,
    val segmentId: String,
    private val patrolMin: Float,
    private val patrolMax: Float,
    private val seed: Int = 1,
    /** v0.10: rango REAL de movimiento (toda la habitación). La patrulla usa [patrolMin]..[patrolMax]. */
    private val moveMin: Float = patrolMin,
    private val moveMax: Float = patrolMax
) {
    var state = CreatureState.PATROL
        private set
    var facing = 1f
        private set
    var speed = 0f
        private set
    /** 0..1: intensidad (respiración, bocas, música). Sube rápido al ver al niño y baja despacio. */
    var arousal = 0.15f
        private set
    var lastKnownX = x
        private set
    var targetX = x
        private set
    var captured = false
        private set
    /** v0.10: capturado sacándolo del armario (la criatura lo VIO entrar). */
    var closetCapture = false
        private set
    /** v0.10: recuerda que el niño entró en un armario (conocimiento > estado de escondido). */
    var witnessedHide = false
        private set
    var hideX = 0f
        private set
    /** v0.10: parada a escuchar junto a un armario ocupado que NO vio ocupar. */
    val listening: Boolean get() = listenTimer > 0f
    /** v0.10: frenada por una zona de luz (fotofobia). */
    var blockedByLight = false
        private set
    /** v0.10: contador de cada vez que la luz la frena (para desgastar el foco). */
    var lightHits = 0
        private set
    /** v0.10: pidió asomarse al armario sospechoso (la escena lo consume). */
    private var peekPending = false
    /** 0..1: aceleración de la persecución (arranca lento, el niño gana unos metros). */
    var chaseRamp = 0f
        private set
    val reacting: Boolean get() = state == CreatureState.CHASE && reactTimer > 0f

    private var timer = 0f
    private var reactTimer = 0f
    private var listenTimer = 0f
    private var listenLatch = false
    private var sinceSeen = 99f
    private var blockedTimer = 0f
    private var refugeGiveUp = 0f
    private var lostTimer = 0f
    private var patrolIdx = 0
    private var aiAcc = 0f
    private var lookDir = 1f

    fun update(dt: Float, s: Senses, noises: List<NoiseEvent>) {
        if (captured) { speed = 0f; return }
        sinceSeen += dt
        if (refugeGiveUp > 0f) refugeGiveUp -= dt
        if (state == CreatureState.CHASE && reactTimer <= 0f) chaseRamp = min(1f, chaseRamp + dt / RAMP_TIME)
        else if (state != CreatureState.CHASE) chaseRamp = 0f
        aiAcc += dt
        if (aiAcc >= AI_STEP) { think(aiAcc, s, noises); aiAcc = 0f }
        move(dt, s)
        val goal = when (state) {
            CreatureState.CHASE -> 1f
            CreatureState.LOST_TARGET -> 0.7f
            CreatureState.INVESTIGATE -> 0.45f
            else -> 0.15f
        }
        val rate = if (goal > arousal) 2.5f else 0.25f   // sube de golpe, baja gradualmente
        arousal += (goal - arousal) * min(1f, rate * dt)
    }

    private fun think(dt: Float, s: Senses, noises: List<NoiseEvent>) {
        val sees = canSee(s) && !(s.playerInRefuge && refugeGiveUp > 0f)
        if (sees) sinceSeen = 0f
        if (!s.playerHiding) { witnessedHide = false; listenLatch = false }
        // v0.10: el conocimiento manda. Si lo vio entrar en el armario, no se deja engañar por el estado "escondido".
        if (s.playerHiding) {
            val knew = canSeePosition(s) && sinceSeen <= WITNESS_WINDOW
            if (!witnessedHide && (knew || s.closetReaction >= ClosetReaction.CAPTURE.ordinal) && s.playerSegmentId == segmentId) {
                witnessedHide = true
                hideX = s.playerX
                lastKnownX = s.playerX
            }
        }
        if (witnessedHide) {
            if (state != CreatureState.CHASE) { state = CreatureState.CHASE; timer = 0f; chaseRamp = 0.5f; reactTimer = 0f }
            targetX = hideX
            lostTimer = 0f
            if (s.playerHidden && abs(hideX - x) < CLOSET_REACH) { captured = true; closetCapture = true }
            return
        }
        if (sees) {
            lastKnownX = s.playerX
            lostTimer = 0f
            if (state != CreatureState.CHASE) {
                state = CreatureState.CHASE; timer = 0f
                reactTimer = REACTION_TIME            // se queda un instante mirando: ventana real de supervivencia
                chaseRamp = 0f
                facing = if (s.playerX >= x) 1f else -1f
            }
            targetX = s.playerX
            if (s.playerSegmentId == segmentId && abs(s.playerX - x) < CAPTURE_RANGE && !s.playerHidden && reactTimer <= 0f) captured = true
            return
        }
        // v0.10: armario ocupado sin haber visto entrar: se detiene a escuchar (y, si ya sospecha, se asoma)
        if (s.playerHidden && s.playerSegmentId == segmentId && abs(s.playerX - x) < LISTEN_RANGE && state != CreatureState.CHASE) {
            if (!listenLatch) {
                listenLatch = true
                listenTimer = LISTEN_TIME + (if (s.closetReaction >= ClosetReaction.SUSPICION.ordinal) 1.6f else 0f)
                if (s.closetReaction >= ClosetReaction.SUSPICION.ordinal) peekPending = true
                facing = if (s.playerX >= x) 1f else -1f
            }
        }
        if (state == CreatureState.CHASE) {
            lostTimer += dt
            targetX = lastKnownX
            if (lostTimer > LOSE_DELAY || stuckBehindBlocker(s)) { state = CreatureState.LOST_TARGET; timer = 0f }
            return
        }
        // oído: solo cambia de PATROL / RETURN / INVESTIGATE; durante la búsqueda cercana reacciona al ruido más fuerte
        var best: NoiseEvent? = null
        var bestI = 0f
        for (n in noises) {
            if (n.segmentId != segmentId) continue
            val i = Hearing.perceivedIntensity(n, x)
            if (i >= Hearing.THRESHOLD && i > bestI) { best = n; bestI = i }
        }
        if (best != null && (state != CreatureState.INVESTIGATE || bestI > 0.3f)) {
            targetX = Hearing.perceivedX(best, x, seed).coerceIn(moveMin, moveMax)
            state = CreatureState.INVESTIGATE
            timer = 0f
        }
        timer += dt
        when (state) {
            CreatureState.INVESTIGATE -> if (arrived()) {
                lookAround(dt)
                if (timer > INVESTIGATE_TIME) { state = CreatureState.LOST_TARGET; timer = 0f; targetX = x }
            }
            CreatureState.LOST_TARGET -> {
                if (arrived()) lookAround(dt)
                if (timer > LOST_TIME) { state = CreatureState.RETURN_TO_PATROL; timer = 0f; targetX = nearestPatrolPoint() }
            }
            CreatureState.RETURN_TO_PATROL -> if (arrived()) { state = CreatureState.PATROL; timer = 0f; patrolIdx = nearestIdx() }
            CreatureState.PATROL -> {
                if (arrived()) {
                    // pausa para mirar alrededor y siguiente punto
                    lookAround(dt)
                    if (timer > 1.5f + 2f * Det.hash01(seed, patrolIdx)) {
                        patrolIdx = (patrolIdx + 1) % PATROL_POINTS
                        targetX = patrolPoint(patrolIdx)
                        timer = 0f
                    }
                } else timer = 0f
            }
            else -> {}
        }
    }

    private fun lookAround(dt: Float) {
        lookTimer += dt
        if (lookTimer > 1.1f) { lookTimer = 0f; lookDir = -lookDir; facing = lookDir }
    }
    private var lookTimer = 0f

    private fun move(dt: Float, s: Senses) {
        blockedByLight = false
        if (listenTimer > 0f) { listenTimer -= dt; speed = 0f; return }
        if (state == CreatureState.CHASE && reactTimer > 0f) { reactTimer -= dt; speed = 0f; return }
        val sp = currentSpeed()
        val dx = targetX - x
        if (abs(dx) < ARRIVE) { speed = 0f; blockedTimer = 0f; return }
        val dir = if (dx > 0) 1f else -1f
        facing = dir
        var step = min(sp * dt, abs(dx))
        var nx = x + dir * step
        var lightHit = false
        for (b in s.blockers) {
            // el cuerpo grande no cabe: se detiene en el borde del hueco (o de la luz)
            if (dir > 0 && x + HALF_BODY <= b.x0 && nx + HALF_BODY > b.x0) { nx = b.x0 - HALF_BODY; if (b.isLight) lightHit = true }
            if (dir < 0 && x - HALF_BODY >= b.x1 && nx - HALF_BODY < b.x1) { nx = b.x1 + HALF_BODY; if (b.isLight) lightHit = true }
        }
        nx = nx.coerceIn(moveMin, moveMax)
        step = abs(nx - x)
        speed = if (dt > 0f) step / dt else 0f
        x = nx
        if (lightHit || (step < 0.01f && lightNear(s))) {
            if (!blockedByLight && blockedTimer == 0f) lightHits++
            blockedByLight = true
            blockedTimer += dt
            if (blockedTimer > LIGHT_PATIENCE && state == CreatureState.CHASE) {
                // se rinde ante la luz: retrocede y pierde interés durante un rato
                refugeGiveUp = LIGHT_GIVEUP
                blockedTimer = 0f
                state = CreatureState.LOST_TARGET
                timer = 0f
                targetX = (x - dir * 80f).coerceIn(moveMin, moveMax)
            }
        } else blockedTimer = 0f
    }

    private fun lightNear(s: Senses): Boolean {
        for (b in s.blockers) if (b.isLight && (abs(x + HALF_BODY - b.x0) < 1.5f || abs(x - HALF_BODY - b.x1) < 1.5f)) return true
        return false
    }

    /** Velocidad actual (px/s): la persecución arranca despacio y acelera ([chaseRamp]). */
    fun currentSpeed(): Float = when (state) {
        CreatureState.CHASE -> CHASE_START_SPEED + (CHASE_SPEED - CHASE_START_SPEED) * chaseRamp
        CreatureState.INVESTIGATE -> INVESTIGATE_SPEED
        CreatureState.LOST_TARGET -> LOST_SPEED
        CreatureState.RETURN_TO_PATROL -> PATROL_SPEED * 1.2f
        CreatureState.PATROL -> PATROL_SPEED
    }

    /** true UNA vez cuando la criatura quiere asomarse al armario sospechoso. */
    fun consumePeek(): Boolean { val p = peekPending; peekPending = false; return p }

    /**
     * v0.10: una VENTANA rompe la persecución. Pierde el foco directo (sale de CHASE hacia LOST_TARGET), conserva la
     * última posición conocida ([atX]) y la investigará. No olvida que el niño existe: el ruido y la vista lo reactivan.
     */
    fun loseFocus(atX: Float) {
        lastKnownX = atX
        targetX = atX.coerceIn(moveMin, moveMax)
        state = CreatureState.LOST_TARGET
        timer = 0f; lostTimer = 0f; reactTimer = 0f; chaseRamp = 0f
        witnessedHide = false
    }

    /** v0.10: la criatura aparece en una habitación (llegó por una puerta o ventana) con un estado ya decidido. */
    fun restore(newState: CreatureState, lastKnown: Float, face: Float, arousalNow: Float) {
        state = newState
        lastKnownX = lastKnown
        targetX = lastKnown.coerceIn(moveMin, moveMax)
        facing = if (face < 0f) -1f else 1f
        arousal = arousalNow
        timer = 0f; lostTimer = 0f; chaseRamp = if (newState == CreatureState.CHASE) 0.6f else 0f
        reactTimer = 0f
    }

    private fun stuckBehindBlocker(s: Senses): Boolean {
        for (b in s.blockers) {
            val edge = if (facing > 0) b.x0 - HALF_BODY else b.x1 + HALF_BODY
            if (abs(x - edge) < 1f && ((facing > 0 && s.playerX > b.x0) || (facing < 0 && s.playerX < b.x1))) return true
        }
        return false
    }

    /** Visión: mismo segmento, distancia (reducida por oscuridad), campo de visión, sin obstáculos opacos, sin armario. */
    fun canSee(s: Senses): Boolean {
        if (s.playerHidden) return false
        return canSeePosition(s)
    }

    /** Igual que [canSee] pero ignorando que el niño esté escondido: ¿ve el LUGAR donde está? (testigo de que entra). */
    fun canSeePosition(s: Senses): Boolean {
        if (s.playerSegmentId != segmentId) return false
        val dx = s.playerX - x
        val d = abs(dx)
        val range = VISION_RANGE * (0.35f + 0.65f * s.playerLight.coerceIn(0f, 1f))
        if (d > range) return false
        val inFront = dx * facing > 0f
        if (!inFront && d > REAR_AWARENESS) return false
        val lo = min(x, s.playerX)
        val hi = max(x, s.playerX)
        for (b in s.blockers) if (b.blocksSight && b.x0 < hi && b.x1 > lo) return false
        return true
    }

    private fun arrived() = abs(targetX - x) < ARRIVE
    private fun patrolPoint(i: Int) = patrolMin + (patrolMax - patrolMin) * (i / (PATROL_POINTS - 1f))
    private fun nearestIdx(): Int {
        var bi = 0
        for (i in 0 until PATROL_POINTS) if (abs(patrolPoint(i) - x) < abs(patrolPoint(bi) - x)) bi = i
        return bi
    }
    private fun nearestPatrolPoint() = patrolPoint(nearestIdx())

    /**
     * v0.9: movimiento guionizado (primera aparición). Ignora sentidos y estados: no ve, no oye, no persigue ni captura.
     * Va hacia [goalX] a [sp] px/s y mira hacia [face] (0 = hacia donde camina).
     */
    fun scripted(dt: Float, goalX: Float, sp: Float, face: Float) {
        val dx = goalX - x
        if (sp <= 0f || abs(dx) < 0.5f) {
            speed = 0f
        } else {
            val dir = if (dx > 0f) 1f else -1f
            val step = min(sp * dt, abs(dx))
            x += dir * step
            speed = if (dt > 0f) step / dt else 0f
            if (face == 0f) facing = dir
        }
        if (face != 0f) facing = face
        arousal += (0.3f - arousal) * min(1f, dt)
    }

    /** Para la captura/escena: la devuelve a patrulla tras despertar al niño. */
    fun reset(newX: Float) {
        x = newX; captured = false; closetCapture = false; witnessedHide = false; listenTimer = 0f; chaseRamp = 0f; state = CreatureState.PATROL; arousal = 0.15f
        targetX = newX; timer = 0f; lostTimer = 0f; patrolIdx = nearestIdx()
    }

    companion object {
        const val AI_STEP = 1f / 15f
        const val PATROL_POINTS = 4
        const val PATROL_SPEED = 18f
        const val INVESTIGATE_SPEED = 34f
        const val LOST_SPEED = 40f
        /** Siempre mayor que Player.SPEED (68): la criatura gana en línea recta. */
        const val CHASE_SPEED = 84f
        /** v0.10: velocidad al empezar a perseguir (acelera hasta [CHASE_SPEED] en [RAMP_TIME]). Carrera de desgaste. */
        const val CHASE_START_SPEED = 50f
        const val RAMP_TIME = 1.6f
        /** Pausa de sorpresa al ver al niño: tiempo real para reaccionar. */
        const val REACTION_TIME = 0.45f
        const val WITNESS_WINDOW = 0.7f
        const val CLOSET_REACH = 34f
        const val LISTEN_RANGE = 70f
        const val LISTEN_TIME = 2.2f
        const val LIGHT_PATIENCE = 3.2f
        const val LIGHT_GIVEUP = 5f
        const val HALF_BODY = 26f
        const val ARRIVE = 3f
        const val VISION_RANGE = 190f
        const val REAR_AWARENESS = 14f
        const val CAPTURE_RANGE = 17f
        const val LOSE_DELAY = 0.8f
        const val INVESTIGATE_TIME = 4f
        const val LOST_TIME = 5f
    }
}
