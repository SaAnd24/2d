package com.terror2d

import com.terror2d.companion.CompanionState
import com.terror2d.core.CameraMode
import com.terror2d.core.GameConfig
import com.terror2d.core.GameState
import com.terror2d.core.WorldMode
import com.terror2d.core.Viewport
import com.terror2d.draw.BackdropBuilder
import com.terror2d.draw.CrayonBuilder
import com.terror2d.events.EventBus
import com.terror2d.events.EventType
import com.terror2d.input.InputAction
import com.terror2d.input.InputController
import com.terror2d.interaction.InteractionIcon
import com.terror2d.inventory.Inventory
import com.terror2d.inventory.ItemRegistry
import com.terror2d.pixel.LightingSample
import com.terror2d.pixel.PixelCharacterData
import com.terror2d.pixel.PixelPose
import com.terror2d.pixel.PixelRasterizer
import com.terror2d.pixel.EyeState
import com.terror2d.pixel.ItemSprites
import com.terror2d.pixel.MouthState
import com.terror2d.pixel.ProtagonistSprite
import com.terror2d.render.PaperEffects
import com.terror2d.render.LightingRenderer
import com.terror2d.render.Palette
import com.terror2d.scene.HouseDefinition
import com.terror2d.scene.HouseDefinition.BATH
import com.terror2d.scene.HouseDefinition.CELLAR
import com.terror2d.scene.HouseDefinition.DINING
import com.terror2d.scene.HouseDefinition.HALL
import com.terror2d.scene.HouseDefinition.KID
import com.terror2d.scene.HouseDefinition.KITCHEN
import com.terror2d.scene.HouseDefinition.LAUNDRY
import com.terror2d.scene.HouseDefinition.MOM
import com.terror2d.scene.HouseScene
import com.terror2d.scene.RoomSegment
import com.terror2d.scene.Scene
import com.terror2d.scene.SceneDefinition
import com.terror2d.scene.SceneTransition
import com.terror2d.scene.SpawnPoint
import com.terror2d.story.StoryFlags
import com.terror2d.ui.DialogueLine
import com.terror2d.ui.DialogueManager
import com.terror2d.util.SeededRandom
import com.terror2d.world.Block
import com.terror2d.world.Door
import com.terror2d.world.DoorTarget
import com.terror2d.world.ExamineSpot
import com.terror2d.world.LightField
import com.terror2d.world.LightSource
import com.terror2d.world.Player
import com.terror2d.world.PlayerState
import com.terror2d.world.PlushFrog
import com.terror2d.world.PlushState
import com.terror2d.world.WorldPickup
import com.terror2d.world.ScriptedSpot
import com.terror2d.world.Wardrobe
import com.terror2d.world.WardrobePhase
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import com.terror2d.puzzle.MedicinePuzzle
import com.terror2d.puzzle.PuzzleLayout
import com.terror2d.scene.FirstPersonView
import com.terror2d.story.Documents
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineTest {

    private val dt = 1f / 60f

    private class World(seed: Long = HouseDefinition.DEFAULT_SEED, room: String? = null, spawn: String = "from_hall") {
        val state = GameState()
        val input = InputController()
        val scene = HouseScene(seed).also { it.load(state) }

        init {
            if (room != null) scene.loadSegment(room, spawn, state)
        }

        fun step(n: Int = 1) {
            repeat(n) {
                scene.update(1f / 60f, input, state)
                input.endFrame()
            }
        }

        fun walk(left: Boolean, right: Boolean, steps: Int) {
            input.setDirection(left, right)
            step(steps)
            input.setDirection(false, false)
        }

        fun pressAction() {
            input.setAction(InputAction.INTERACT, true)
            step(1)
            input.setAction(InputAction.INTERACT, false)
        }

        fun door(id: String): Door = scene.currentSegment.doors.first { it.id == id }

        fun wardrobe(): Wardrobe = scene.currentSegment.objects.filterIsInstance<Wardrobe>().first()

        fun standAt(x: Float) {
            scene.player.x = x
            step()
        }

        /** Coloca al jugador junto a la puerta y la usa; espera a que acabe la transición. */
        fun useDoor(id: String) {
            standAt(door(id).x + 2f)
            pressAction()
            step(70)
        }

        /** Pasa por los diálogos pulsando la acción. */
        fun finishDialogue() {
            var n = 0
            while (scene.dialogue.blocksInput && n < 30) {
                pressAction()
                n++
            }
        }
    }

    /** Escena mínima con un bloque sólido, para probar colisiones. */
    private class SolidWorld {
        val block = Block(150f, 146f - 20f, 20f, 20f, Palette.CRATE_FILL, Palette.CRATE_HATCH)
        val state = GameState()
        val input = InputController()
        val scene: Scene = object : Scene(
            SceneDefinition(
                id = "solid", seed = 1L,
                segments = listOf(
                    RoomSegment(
                        id = "s", width = 320f, floorY = 146f, leftBoundary = 12f, rightBoundary = 308f,
                        objects = listOf(block),
                        spawnPoints = mapOf("a" to SpawnPoint(60f, 1), "b" to SpawnPoint(250f, -1))
                    )
                ),
                startSegmentId = "s", startSpawnId = "a"
            )
        ) {}.also { it.load(state) }

        fun walk(left: Boolean, right: Boolean, steps: Int) {
            input.setDirection(left, right)
            repeat(steps) { scene.update(1f / 60f, input, state); input.endFrame() }
            input.setDirection(false, false)
        }
    }

    private val allRooms = listOf(HALL, KID, BATH, MOM, LAUNDRY, KITCHEN, DINING, CELLAR)

    private fun spawnFor(room: String) = if (room == HALL) HouseDefinition.fromSpawn(KID) else "from_hall"

    // ================================================================== SeededRandom

    @Test
    fun sameSeedProducesSameSequence() {
        val a = SeededRandom(42L)
        val b = SeededRandom(42L)
        for (i in 0 until 1000) assertEquals(a.nextLong(), b.nextLong())
    }

    @Test
    fun differentSeedsProduceDifferentSequences() {
        assertNotEquals(SeededRandom(1L).nextLong(), SeededRandom(2L).nextLong())
    }

    // ================================================================== La casa: 7 habitaciones + pasillo

    @Test
    fun sevenRoomsAndTheHallExist() {
        val def = HouseDefinition.create()
        assertEquals(8, def.segments.size)
        assertEquals(allRooms.toSet(), def.segments.map { it.id }.toSet())
        assertEquals(7, HouseDefinition.ROOMS.size)
        assertEquals(KID, def.startSegmentId)
    }

    @Test
    fun hallIsLongAndHasOneDoorPerRoom() {
        val hall = HouseDefinition.create().segment(HALL)
        assertTrue("el pasillo debe ser largo", hall.width >= 900f)
        assertEquals(CameraMode.SIDE_SCROLLING, hall.cameraMode)
        assertEquals(7, hall.doors.size)
        assertEquals(HouseDefinition.ROOMS.toSet(), hall.doors.mapNotNull { it.target?.segmentId }.toSet())
        assertTrue("el pasillo tiene decoración y cosas que examinar", hall.objects.size >= 25)
    }

    @Test
    fun everyRoomConnectsToTheHallBothWays() {
        val def = HouseDefinition.create()
        val hall = def.segment(HALL)
        for (room in HouseDefinition.ROOMS) {
            val seg = def.segment(room)
            // la habitación tiene una puerta al pasillo, con un spawn válido
            val back = seg.doors.single { it.target?.segmentId == HALL }
            assertEquals(HouseDefinition.roomDoorId(room), back.id)
            assertNotNull(hall.spawn(back.target!!.spawnId))
            // el pasillo tiene la puerta a la habitación, con un spawn válido
            val front = hall.doors.single { it.id == HouseDefinition.hallDoorId(room) }
            assertEquals(room, front.target!!.segmentId)
            assertNotNull(seg.spawn(front.target!!.spawnId))
        }
    }

    @Test
    fun doorsLeadToTheCorrectDestinationAndSpawn() {
        for (room in HouseDefinition.ROOMS) {
            val w = World(room = HALL, spawn = HouseDefinition.fromSpawn(KID))
            w.useDoor(HouseDefinition.hallDoorId(room))
            assertEquals("la puerta del pasillo debe llevar a $room", room, w.scene.currentSegment.id)
            assertEquals(81f, w.scene.player.centerX, 0.01f)
            assertEquals(w.scene.currentSegment.floorY, w.scene.player.bottom, 0f)
            w.useDoor(HouseDefinition.roomDoorId(room))
            assertEquals("la puerta de $room debe volver al pasillo", HALL, w.scene.currentSegment.id)
            val expectedX = (HouseDefinition.HALL_DOOR_X[room] ?: 0f) + 57f
            assertEquals(expectedX, w.scene.player.centerX, 0.01f)
        }
    }

    @Test
    fun transitionsKeepTheGameStateConsistent() {
        val w = World(room = KID, spawn = "start")
        w.state.story.set("marcador")
        w.useDoor(HouseDefinition.roomDoorId(KID))
        assertEquals(HALL, w.state.currentSegmentId)
        assertTrue(w.state.story.has("marcador"))
        assertFalse(w.state.playerHidden)
        assertEquals(PlayerState.NORMAL, w.scene.player.state)
        assertFalse(w.scene.transition.isActive)
        for (seg in w.scene.definition.segments) for (d in seg.doors) assertFalse(d.isOpen)
        assertEquals(0f, w.state.visualCorruption, 0f)
    }

    @Test
    fun canWalkAllTheWayAroundTheHouse() {
        val w = World()
        w.useDoor(HouseDefinition.roomDoorId(KID))
        for (room in listOf(BATH, MOM, LAUNDRY, KITCHEN, DINING, CELLAR)) {
            w.useDoor(HouseDefinition.hallDoorId(room))
            assertEquals(room, w.scene.currentSegment.id)
            w.useDoor(HouseDefinition.roomDoorId(room))
            assertEquals(HALL, w.scene.currentSegment.id)
        }
    }

    // ================================================================== Movimiento, límites y colisiones

    @Test
    fun walksLeftAndRightWithoutVerticalMovement() {
        val w = World(room = HALL, spawn = HouseDefinition.fromSpawn(BATH))
        val x0 = w.scene.player.x
        val y0 = w.scene.player.y
        w.walk(false, true, 40)
        assertTrue(w.scene.player.x > x0 + 5f)
        assertEquals(1f, w.scene.player.facing, 0f)
        val x1 = w.scene.player.x
        w.walk(true, false, 40)
        assertTrue(w.scene.player.x < x1 - 5f)
        assertEquals(-1f, w.scene.player.facing, 0f)
        assertEquals(y0, w.scene.player.y, 0f)
    }

    @Test
    fun everyRoomHasWorkingBoundaries() {
        for (room in allRooms) {
            val w = World(room = room, spawn = spawnFor(room))
            val seg = w.scene.currentSegment
            w.walk(false, true, 1700)
            assertEquals("$room: límite derecho", seg.rightBoundary - Player.WIDTH, w.scene.player.x, 0.01f)
            w.walk(true, false, 1700)
            assertEquals("$room: límite izquierdo", seg.leftBoundary, w.scene.player.x, 0.01f)
            assertEquals(seg.floorY, w.scene.player.bottom, 0f)
        }
    }

    @Test
    fun solidObjectsStillBlockThePlayer() {
        val a = SolidWorld()
        a.walk(false, true, 600)
        assertEquals(a.block.x - Player.WIDTH, a.scene.player.x, 0.01f)
        val b = SolidWorld()
        b.scene.loadSegment("s", "b", b.state)
        b.walk(true, false, 600)
        assertEquals(b.block.right, b.scene.player.x, 0.01f)
    }

    @Test
    fun furnitureDoesNotBlockTheWayThroughTheHouse() {
        val w = World(room = HALL, spawn = HouseDefinition.fromSpawn(KID))
        w.walk(false, true, 1700)
        assertEquals(w.scene.currentSegment.rightBoundary - Player.WIDTH, w.scene.player.x, 0.01f)
    }

    // ================================================================== Cámara cercana

    @Test
    fun cameraStaysCloseAndTheProtagonistKeepsHisScale() {
        assertEquals(48f, Player.HEIGHT, 0f)
        assertTrue(Player.HEIGHT / GameConfig.LOGICAL_HEIGHT >= GameConfig.MIN_PLAYER_FRAME_RATIO)
        val w = World(room = KID, spawn = "start")
        assertEquals(320f, w.scene.camera.viewWidth, 0f)
        assertEquals(180f, w.scene.camera.viewHeight, 0f)
    }

    @Test
    fun smallRoomsAreFixedAndLargeOnesScrollHorizontally() {
        val def = HouseDefinition.create()
        assertEquals(CameraMode.FIXED, def.segment(BATH).cameraMode)
        assertEquals(CameraMode.FIXED, def.segment(LAUNDRY).cameraMode)
        for (room in listOf(HALL, KID, MOM, KITCHEN, DINING, CELLAR)) {
            val w = World(room = room, spawn = spawnFor(room))
            val cam = w.scene.camera
            assertEquals(CameraMode.SIDE_SCROLLING, cam.mode)
            val y0 = cam.y
            w.walk(false, true, 1700)
            assertEquals("$room: la cámara no se mueve en vertical", y0, cam.y, 0f)
            assertEquals("$room: la cámara termina en el extremo derecho", w.scene.width - cam.viewWidth, cam.x, 0.5f)
            w.walk(true, false, 1700)
            assertEquals("$room: vuelve al extremo izquierdo", 0f, cam.x, 0.5f)
        }
        for (room in listOf(BATH, LAUNDRY)) {
            val w = World(room = room, spawn = "from_hall")
            val x0 = w.scene.camera.x
            w.walk(false, true, 300)
            assertEquals(x0, w.scene.camera.x, 0f)
        }
    }

    // ================================================================== Interacción contextual

    @Test
    fun doorPromptAndGenericActionButton() {
        val w = World(room = HALL, spawn = HouseDefinition.fromSpawn(KID))
        w.step()
        val door = w.door(HouseDefinition.hallDoorId(BATH))
        w.standAt(door.x + 2f)
        assertEquals(door, w.scene.focused)
        assertTrue(w.input.actionEnabled)
        assertEquals("ABRIR", w.input.actionLabel)
        assertEquals(InteractionIcon.DOOR, w.input.actionIcon)
    }

    @Test
    fun examineSpotShowsTheChildsVoice() {
        val w = World(room = KID, spawn = "start")
        w.standAt(256f)
        assertEquals("ex_kid_chest", w.scene.focused?.interactionId)
        assertEquals("EXAMINAR", w.input.actionLabel)
        w.pressAction()
        assertEquals("Mi caja de juguetes. Ese osito ya está viejo.", w.scene.dialogue.current?.text)
        assertTrue(w.scene.events.wasPosted(EventType.ON_OBJECT_EXAMINED, "ex_kid_chest"))
    }

    @Test
    fun everySpaceHasSeveralExaminePoints() {
        val def = HouseDefinition.create()
        for (seg in def.segments) {
            val n = seg.objects.count { it is ExamineSpot || it is ScriptedSpot }
            assertTrue("${seg.id} solo tiene $n puntos examinables", n >= 3)
        }
        assertTrue(def.segment(HALL).objects.count { it is ExamineSpot } >= 8)
    }

    @Test
    fun childVoiceIsShortAndSimple() {
        val def = HouseDefinition.create()
        for (seg in def.segments) for (o in seg.objects) {
            if (o is ExamineSpot) assertTrue("texto largo en ${o.id}", o.text.length <= 75)
        }
    }

    // ================================================================== Armarios

    @Test
    fun wardrobesAreInTheLogicalRooms() {
        val def = HouseDefinition.create()
        val with = def.segments.filter { seg -> seg.objects.any { it is Wardrobe } }.map { it.id }.toSet()
        assertEquals(setOf(KID, MOM, LAUNDRY, CELLAR), with)
    }

    @Test
    fun hidingInEveryWardrobeWorksLikeV03() {
        for (room in listOf(KID, MOM, LAUNDRY, CELLAR)) {
            val w = World(room = room, spawn = if (room == KID) "start" else "from_hall")
            val wd = w.wardrobe()
            w.standAt(wd.x + 10f)
            assertEquals("$room: no detecta el armario", wd, w.scene.focused)
            assertEquals("ESCONDERSE", w.input.actionLabel)
            w.pressAction()
            assertEquals(PlayerState.ENTERING_HIDE, w.scene.player.state)
            w.step(60)
            val p = w.scene.player
            assertTrue("$room: no se escondió", p.isHidden)
            assertTrue(w.state.playerHidden)
            assertEquals(0f, p.visibilityAlpha, 0f)
            assertEquals(WardrobePhase.OCCUPIED, wd.phase)
            val x = p.x
            w.walk(false, true, 40)
            assertEquals("escondido no se camina", x, p.x, 0.001f)
            w.step()
            assertEquals("SALIR", w.input.actionLabel)
            w.pressAction()
            w.step(60)
            assertEquals("$room: no salió", PlayerState.NORMAL, p.state)
            assertFalse(w.state.playerHidden)
            val seg = w.scene.currentSegment
            assertEquals(wd.centerX, p.centerX, 0.6f)
            assertTrue(p.x >= seg.leftBoundary && p.right <= seg.rightBoundary)
            assertEquals(seg.floorY, p.bottom, 0f)
            assertTrue(w.scene.events.wasPosted(EventType.ON_HIDE, wd.id))
            assertTrue(w.scene.events.wasPosted(EventType.ON_EXIT_HIDE, wd.id))
        }
    }

    // ================================================================== Introducción narrativa

    @Test
    fun gameStartsInTheChildsRoomAndMomCallsOnlyOnce() {
        val w = World()
        assertEquals(KID, w.scene.currentSegment.id)
        assertTrue(w.state.story.has(StoryFlags.INTRO_STARTED))
        val counts = HashMap<String, Int>()
        w.scene.events.subscribe(EventType.ON_STORY_FLAG) { e -> counts[e.sourceId] = (counts[e.sourceId] ?: 0) + 1 }
        w.step(60 * 4)
        assertFalse("mamá no llama antes de unos segundos", w.state.story.has(StoryFlags.HEARD_CALL))
        w.step(60 * 2)
        assertTrue(w.state.story.has(StoryFlags.HEARD_CALL))
        assertEquals("Cariño, ¿puedes ayudarme?", w.scene.dialogue.current?.text)
        assertEquals("MAMÁ", w.scene.dialogue.current?.speaker)
        w.step(60 * 60)
        for (flag in listOf(StoryFlags.HEARD_CALL, StoryFlags.HEARD_PILLS, StoryFlags.HEARD_WATER, StoryFlags.INTRO_CALLS_DONE)) {
            assertTrue(flag, w.state.story.has(flag))
            assertEquals("$flag debe ocurrir una sola vez", 1, counts[flag])
        }
        // salir y volver a la habitación inicial no repite la llamada
        w.scene.loadSegment(HALL, HouseDefinition.fromSpawn(KID), w.state)
        w.scene.loadSegment(KID, "start", w.state)
        w.step(60 * 60)
        for (flag in listOf(StoryFlags.HEARD_CALL, StoryFlags.HEARD_PILLS, StoryFlags.HEARD_WATER)) {
            assertEquals("$flag se repitió", 1, counts[flag])
        }
    }

    @Test
    fun sinkWithoutBeingAskedOnlyDrips() {
        val w = World(room = KITCHEN, spawn = "from_hall")
        w.standAt(165f)
        assertEquals(HouseDefinition.SPOT_SINK, w.scene.focused?.interactionId)
        w.pressAction()
        assertEquals("El grifo gotea. Plic, plic.", w.scene.dialogue.current?.text)
        assertFalse(w.state.story.has(StoryFlags.GOT_WATER))
    }

    @Test
    fun waterAndMedicineDeliveryFlow() {
        val w = World()
        w.step(60 * 60) // la introducción termina de hablar
        assertTrue(w.state.story.has(StoryFlags.HEARD_WATER))
        w.scene.dialogue.clear()

        // mamá, sin agua todavía
        w.scene.loadSegment(MOM, "from_hall", w.state)
        w.standAt(150f)
        assertEquals(HouseDefinition.SPOT_MOM, w.scene.focused?.interactionId)
        assertEquals("HABLAR", w.input.actionLabel)
        w.pressAction()
        assertTrue(w.scene.dialogue.blocksInput)
        w.finishDialogue()
        assertFalse(w.state.story.has(StoryFlags.WATER_DELIVERED))

        // la cocina: recoger el agua (animación PICKUP y luego el vaso en la mano)
        w.scene.loadSegment(KITCHEN, "from_hall", w.state)
        w.standAt(165f)
        assertEquals("TOMAR AGUA", w.input.actionLabel)
        assertEquals(InteractionIcon.PICK, w.input.actionIcon)
        w.pressAction()
        assertEquals(PlayerState.PICKING_UP, w.scene.player.state)
        assertEquals(PixelPose.PICKUP, w.scene.player.pose)
        assertFalse("durante la animación no se camina", w.scene.player.canMove)
        w.step(50)
        assertEquals(PlayerState.NORMAL, w.scene.player.state)
        assertTrue(w.state.inventory.isHolding(ItemRegistry.WATER_GLASS))
        assertEquals(ItemRegistry.WATER_GLASS, w.input.heldItemId)
        assertTrue(w.state.story.has(StoryFlags.GOT_WATER))
        assertEquals(PixelPose.HOLD_ITEM, w.scene.player.pose)
        assertEquals("Lleno un vaso con agua. No lo derramo.", w.scene.dialogue.current?.text)
        assertTrue(w.scene.events.wasPosted(EventType.ON_ITEM_PICKED, ItemRegistry.WATER_GLASS))

        // caminando con el vaso se usan las poses con objeto
        w.walk(false, true, 12)
        assertTrue(w.scene.player.pose in listOf(PixelPose.HOLD_WALK_1, PixelPose.HOLD_WALK_2, PixelPose.HOLD_WALK_3))

        // entregar el agua a mamá
        w.scene.loadSegment(MOM, "from_hall", w.state)
        w.standAt(150f)
        assertEquals("DAR AGUA", w.input.actionLabel)
        assertEquals(InteractionIcon.GIVE, w.input.actionIcon)
        w.pressAction()
        assertEquals(PlayerState.GIVING, w.scene.player.state)
        assertEquals(PixelPose.GIVE_ITEM, w.scene.player.pose)
        w.step(50)
        assertFalse(w.state.inventory.has(ItemRegistry.WATER_GLASS))
        assertNull(w.state.inventory.held)
        assertTrue(w.state.story.has(StoryFlags.WATER_DELIVERED))
        assertTrue(w.state.story.has(StoryFlags.PILLS_REQUESTED))
        assertTrue(w.scene.events.wasPosted(EventType.ON_ITEM_GIVEN, ItemRegistry.WATER_GLASS))
        assertTrue(w.scene.dialogue.blocksInput)
        w.finishDialogue()
        assertFalse(w.state.story.has(StoryFlags.INTRO_DONE))

        // las cajitas son objetos: coger la blanca y entregarla a mamá es un error
        val boxes = w.scene.currentSegment.objects.filterIsInstance<WorldPickup>()
        assertEquals(3, boxes.size)
        val white = boxes.first { it.id == HouseDefinition.PICKUP_WHITE }
        val orange = boxes.first { it.id == HouseDefinition.PICKUP_ORANGE }
        val blue = boxes.first { it.id == HouseDefinition.PICKUP_BLUE }
        w.standAt(293f)
        assertEquals(white, w.scene.focused)
        assertEquals("RECOGER", w.input.actionLabel)
        w.pressAction()
        w.step(50)
        assertTrue(w.state.inventory.isHolding(ItemRegistry.PILL_BOX_WHITE))
        assertFalse(white.isAtHome)
        w.scene.dialogue.clear()

        // con las manos ocupadas no se coge otra
        w.standAt(273f)
        assertEquals(blue, w.scene.focused)
        w.pressAction()
        assertEquals("Tengo las manos ocupadas.", w.scene.dialogue.current?.text)
        assertTrue(blue.isAtHome)

        w.standAt(150f)
        assertEquals("DAR CAJA", w.input.actionLabel)
        w.pressAction()
        assertEquals("Esa no, cariño. La azul.", w.scene.dialogue.current?.text)
        assertTrue("la caja equivocada no se entrega", w.state.inventory.isHolding(ItemRegistry.PILL_BOX_WHITE))
        assertFalse(w.state.story.has(StoryFlags.INTRO_DONE))

        // dejar la blanca en su sitio
        w.standAt(293f)
        assertEquals("DEJAR", w.input.actionLabel)
        w.pressAction()
        w.step(50)
        assertTrue(white.isAtHome)
        assertNull(w.state.inventory.held)
        assertTrue(w.scene.events.wasPosted(EventType.ON_ITEM_PLACED, ItemRegistry.PILL_BOX_WHITE))
        w.scene.dialogue.clear()

        // la azul sí
        w.standAt(273f)
        w.pressAction()
        w.step(50)
        assertTrue(w.state.inventory.isHolding(ItemRegistry.PILL_BOX_BLUE))
        assertTrue(w.state.story.has(StoryFlags.GOT_PILLS))
        w.scene.dialogue.clear()
        w.standAt(150f)
        w.pressAction()
        w.step(50)
        assertTrue(w.scene.dialogue.blocksInput)
        w.finishDialogue()
        assertTrue(w.state.story.has(StoryFlags.PILLS_DELIVERED))
        assertTrue(w.state.story.has(StoryFlags.INTRO_DONE))
        assertTrue(w.state.inventory.isEmpty)
        assertNull(w.input.heldItemId)

        // no se repite
        w.pressAction()
        assertFalse(w.scene.dialogue.blocksInput)
        assertTrue(w.scene.dialogue.current?.text?.contains("dormidita") == true)
        assertNotEquals(orange, blue)
    }

    @Test
    fun plushFrogBecomesAPersistentCompanionOnTheBack() {
        val w = World(room = KID, spawn = "start")
        // v0.9: Ranita está bloqueada hasta el grito de mamá; aquí se simula ese estado narrativo
        w.state.story.set(StoryFlags.PLUSH_AVAILABLE)
        val plush = w.scene.currentSegment.objects.filterIsInstance<PlushFrog>().first()
        assertEquals(PlushState.ON_FLOOR, plush.state)
        // el mundo lo "descubre" al cargar la habitación
        assertEquals(CompanionState.ON_FLOOR, w.state.inventory.companion.state)
        // x=100: aquí Ranita es la más cercana; el dibujo de la pared (x 98-150) solapa su zona y gana si el niño está más a la derecha
        w.standAt(100f)
        assertEquals(plush, w.scene.focused)
        assertEquals("RECOGER", w.input.actionLabel)
        w.pressAction()
        w.step(50)
        assertEquals(PlushState.HELD, plush.state)
        // v0.7: va al COMPANION SLOT; las manos siguen libres y no hay objeto en la mano
        assertEquals(CompanionState.ON_BACK, w.state.inventory.companion.state)
        assertNull(w.state.inventory.held)
        assertFalse(w.state.inventory.has(ItemRegistry.FROG_PLUSH))
        assertEquals(ItemRegistry.FROG_PLUSH, w.scene.player.companionItemId)
        assertEquals("Ranita. Me la dieron en la farmacia. Siempre sonríe.", w.scene.dialogue.current?.text)
        assertEquals(PixelPose.IDLE, w.scene.player.pose)
        assertTrue(w.scene.events.wasPosted(EventType.COMPANION_PICKED_UP, ItemRegistry.FROG_PLUSH))
        // persiste: no se suelta ni deja de acompañar
        w.finishDialogue()
        w.step(60 * 5)
        assertEquals(CompanionState.ON_BACK, w.state.inventory.companion.state)
        // ya no se puede "dejar" en la cama como un objeto normal: el compañero siempre va con el niño
        w.standAt(190f)
        assertFalse("DEJAR" == w.input.actionLabel)
    }

    @Test
    fun inventoryIsReusable() {
        val inv = Inventory(capacity = 2)
        assertTrue(inv.isEmpty)
        assertTrue(inv.add(ItemRegistry.WATER_GLASS))
        assertEquals(1, inv.count(ItemRegistry.WATER_GLASS))
        assertFalse("un objeto no apilable no se duplica", inv.add(ItemRegistry.WATER_GLASS))
        assertFalse("el compañero no es un objeto normal: no entra en las casillas", inv.add(ItemRegistry.FROG_PLUSH))
        assertTrue(inv.add(ItemRegistry.PILL_BOX_WHITE))
        assertFalse("no cabe nada más", inv.add(ItemRegistry.PILL_BOX_BLUE))
        assertFalse("un objeto no registrado no entra", inv.add("no_existe"))
        assertEquals(2, inv.size)
        assertTrue(inv.hold(ItemRegistry.PILL_BOX_WHITE))
        assertTrue(inv.isHolding(ItemRegistry.PILL_BOX_WHITE))
        assertFalse(inv.hold(ItemRegistry.PILL_BOX_BLUE))
        assertTrue(inv.remove(ItemRegistry.PILL_BOX_WHITE))
        assertNull("al quitar el objeto en mano se liberan las manos", inv.held)
        assertFalse(inv.remove(ItemRegistry.PILL_BOX_WHITE))
        val def = ItemRegistry.require(ItemRegistry.WATER_GLASS)
        assertEquals("Vaso de agua", def.name)
        assertEquals("water_glass", def.icon)
        assertEquals(WorldMode.NORMAL, def.world)
        for (d in ItemRegistry.all) assertTrue(d.name.isNotEmpty() && d.icon.isNotEmpty())
        inv.clear()
        assertTrue(inv.isEmpty)
    }

    @Test
    fun playerPosesFollowStateAndHeldItem() {
        val p = Player(0f, 98f)
        assertEquals(PixelPose.IDLE, p.pose)
        p.heldItemId = ItemRegistry.WATER_GLASS
        assertEquals(PixelPose.HOLD_ITEM, p.pose)
        p.heldItemId = null
        p.update(0.2f, 1f, emptyList(), 146f, 0f, 500f)
        assertTrue(p.pose in listOf(PixelPose.WALK_1, PixelPose.WALK_2, PixelPose.WALK_3))
        p.update(0.5f, 0f, emptyList(), 146f, 0f, 500f)
        p.beginAction(PlayerState.PICKING_UP, 0.5f, null)
        assertEquals(PixelPose.PICKUP, p.pose)
        p.update(0.6f, 1f, emptyList(), 146f, 0f, 500f)
        assertEquals(PlayerState.NORMAL, p.state)
        p.beginAction(PlayerState.GIVING, 0.5f, null)
        assertEquals(PixelPose.GIVE_ITEM, p.pose)
        p.update(0.6f, 0f, emptyList(), 146f, 0f, 500f)
        p.poseOverride = PixelPose.HURT
        assertEquals(PixelPose.HURT, p.pose)
        p.poseOverride = PixelPose.FLASHBACK
        assertEquals(PixelPose.FLASHBACK, p.pose)
    }

    @Test
    fun worldModeIsPreparedButOnlyNormalExists() {
        val st = GameState()
        assertEquals(WorldMode.NORMAL, st.worldMode)
        val def = HouseDefinition.create()
        assertTrue(def.traumaSegments.isEmpty())
        for (seg in def.segments) assertEquals(WorldMode.NORMAL, seg.worldMode)
        assertSame(def.segment(HALL), def.segmentFor(HALL, WorldMode.TRAUMA))
    }

    @Test
    fun traumaVariantsCanBeRegisteredWithoutChangingTheEngine() {
        val spawns = mapOf("a" to SpawnPoint(60f, 1))
        val normal = RoomSegment(id = "s", width = 320f, floorY = 146f, spawnPoints = spawns)
        val trauma = RoomSegment(id = "s", width = 320f, floorY = 146f, spawnPoints = spawns, worldMode = WorldMode.TRAUMA)
        val def = SceneDefinition(
            id = "w", seed = 1L, segments = listOf(normal), startSegmentId = "s", startSpawnId = "a",
            traumaSegments = listOf(trauma)
        )
        assertSame(normal, def.segmentFor("s", WorldMode.NORMAL))
        assertSame(trauma, def.segmentFor("s", WorldMode.TRAUMA))
        val st = GameState()
        st.worldMode = WorldMode.TRAUMA
        val scene: Scene = object : Scene(def) {}
        scene.load(st)
        assertSame(trauma, scene.currentSegment)
    }

    @Test
    fun definitiveProtagonistHasAllRequestedAnimations() {
        val data = ProtagonistSprite.create()
        for (pose in listOf(
            PixelPose.IDLE, PixelPose.WALK_1, PixelPose.WALK_2, PixelPose.WALK_3, PixelPose.PICKUP,
            PixelPose.HOLD_ITEM, PixelPose.GIVE_ITEM, PixelPose.HURT, PixelPose.HIDE, PixelPose.FLASHBACK
        )) assertTrue("falta $pose", data.hasPose(pose))
        val hashes = HashSet<Long>()
        for (pose in PixelPose.values()) {
            if (pose == PixelPose.FLASHBACK) continue // idéntica a IDLE; solo cambia la paleta
            hashes.add(PixelRasterizer.hash(PixelRasterizer.rasterize(data, pose, false, null)))
        }
        assertEquals("cada pose es distinta", PixelPose.values().size - 1, hashes.size)
        for (pose in listOf(PixelPose.HOLD_ITEM, PixelPose.HOLD_WALK_1, PixelPose.HOLD_WALK_2, PixelPose.HOLD_WALK_3, PixelPose.GIVE_ITEM)) {
            val h = data.hand(pose)
            assertNotNull("sin mano en $pose", h)
            assertTrue(h!![0] > 0 && h[1] < 0)
        }
        assertNull(data.hand(PixelPose.IDLE))
        // detalles del diseño: suéter naranja, línea roja, bufanda, marca en el rostro, zapatos blancos
        val used = data.frame(PixelPose.IDLE).toSet()
        for (idx in listOf(
            com.terror2d.pixel.PixelIndex.SHIRT, com.terror2d.pixel.PixelIndex.DETAIL, com.terror2d.pixel.PixelIndex.SCARF,
            com.terror2d.pixel.PixelIndex.FACE_MARK, com.terror2d.pixel.PixelIndex.SHOES, com.terror2d.pixel.PixelIndex.PANTS,
            com.terror2d.pixel.PixelIndex.HAIR
        )) assertTrue("no se usa el color $idx", idx in used)
        assertEquals(0xFFF08A2E.toInt(), data.palette[com.terror2d.pixel.PixelIndex.SHIRT])
        assertEquals(0xFFF4F0E6.toInt(), data.palette[com.terror2d.pixel.PixelIndex.SHOES])
    }

    @Test
    fun oneTimeRoomEventsFireOnlyOnce() {
        val w = World()
        w.scene.loadSegment(HALL, HouseDefinition.fromSpawn(KID), w.state)
        assertEquals("El pasillo está muy largo hoy.", w.scene.dialogue.current?.text)
        w.scene.dialogue.clear()
        w.scene.loadSegment(HALL, HouseDefinition.fromSpawn(KID), w.state)
        assertNull(w.scene.dialogue.current)
    }

    // ================================================================== Personaje pixel art

    private fun tinyData(palette: IntArray): PixelCharacterData {
        val idle = intArrayOf(
            0, 1, 2,
            3, 0, 12
        )
        val frames = arrayOfNulls<IntArray>(PixelPose.values().size)
        frames[PixelPose.IDLE.ordinal] = idle
        return PixelCharacterData("mini", 3, 2, palette, frames, 1)
    }

    private val testPalette = IntArray(13) { i -> if (i == 0) 0 else (0xFF shl 24) or (i * 18 shl 16) or (i * 9 shl 8) or (255 - i * 10) }

    @Test
    fun rasterizerInterpretsTheIndexMatrixExactly() {
        val px = PixelRasterizer.rasterize(tinyData(testPalette), PixelPose.IDLE, false, null)
        assertEquals(6, px.size)
        assertEquals(0, px[0])
        assertEquals(testPalette[1], px[1])
        assertEquals(testPalette[2], px[2])
        assertEquals(testPalette[3], px[3])
        assertEquals(0, px[4])
        assertEquals(testPalette[12], px[5])
        // un pose sin datos usa IDLE
        val other = PixelRasterizer.rasterize(tinyData(testPalette), PixelPose.WALK_1, false, null)
        assertEquals(PixelRasterizer.hash(px), PixelRasterizer.hash(other))
    }

    @Test
    fun flipMirrorsAroundTheAnchor() {
        val data = tinyData(testPalette)
        val n = PixelRasterizer.rasterize(data, PixelPose.IDLE, false, null)
        val f = PixelRasterizer.rasterize(data, PixelPose.IDLE, true, null)
        assertEquals(n[0], f[2]); assertEquals(n[1], f[1]); assertEquals(n[2], f[0])
        assertEquals(n[3], f[5]); assertEquals(n[5], f[3])
    }

    @Test
    fun sameMatrixSamePixelsAndDifferentPalettesDiffer() {
        val a = PixelRasterizer.rasterize(tinyData(testPalette), PixelPose.IDLE, false, null)
        val b = PixelRasterizer.rasterize(tinyData(testPalette), PixelPose.IDLE, false, null)
        assertEquals(PixelRasterizer.hash(a), PixelRasterizer.hash(b))
        val alt = testPalette.copyOf()
        alt[3] = 0xFF123456.toInt()
        val c = PixelRasterizer.rasterize(tinyData(alt), PixelPose.IDLE, false, null)
        assertNotEquals(PixelRasterizer.hash(a), PixelRasterizer.hash(c))
        val protagonist = ProtagonistSprite.create()
        val flash = protagonist.withPalette(ProtagonistSprite.PALETTE_FLASHBACK)
        assertNotEquals(
            PixelRasterizer.hash(PixelRasterizer.rasterize(protagonist, PixelPose.IDLE, false, null)),
            PixelRasterizer.hash(PixelRasterizer.rasterize(flash, PixelPose.IDLE, false, null))
        )
    }

    @Test
    fun protagonistIsAnEightYearOldAtTheRightScale() {
        val data = ProtagonistSprite.create()
        // v0.6: 96x128 píxeles internos a escala 0.5 = la misma presencia en pantalla que el 48x64 anterior
        assertEquals(96, data.width)
        assertEquals(128, data.height)
        assertEquals(0.5f, data.scale, 0f)
        assertEquals(38, data.palette.size)
        for (pose in PixelPose.values()) assertTrue("falta la pose $pose", data.hasPose(pose))
        val rows = data.visibleRows(PixelPose.IDLE)
        val visible = rows[1] - rows[0] + 1
        assertTrue("alto visible $visible px del sprite", visible in 94..106)
        val logical = visible * data.scale
        assertTrue("alto lógico $logical (el mismo ~50 px que antes)", logical in 44f..53f)
        assertEquals("los pies tocan el suelo", 127, rows[1])
        assertTrue("densidad de píxeles", data.filledPixels(PixelPose.IDLE) > 3000)
        val idle = PixelRasterizer.hash(PixelRasterizer.rasterize(data, PixelPose.IDLE, false, null))
        val walks = listOf(PixelPose.WALK_1, PixelPose.WALK_2, PixelPose.WALK_3).map {
            PixelRasterizer.hash(PixelRasterizer.rasterize(data, it, false, null))
        }
        assertEquals("las tres poses de caminar son distintas", 3, walks.toSet().size)
        for (h in walks) assertNotEquals(idle, h)
        // el protagonista generado dos veces es idéntico
        assertEquals(idle, PixelRasterizer.hash(PixelRasterizer.rasterize(ProtagonistSprite.create(), PixelPose.IDLE, false, null)))
    }

    @Test
    fun protagonistFaceHasEyesPupilsEyelidsMouthAndBlinks() {
        val data = ProtagonistSprite.create()
        val face = data.face
        assertNotNull(face)
        val open = PixelRasterizer.composeIndices(data, PixelPose.IDLE, PixelRasterizer.PART_ALL, EyeState.OPEN, MouthState.NEUTRAL)
        val closed = PixelRasterizer.composeIndices(data, PixelPose.IDLE, PixelRasterizer.PART_ALL, EyeState.CLOSED, MouthState.NEUTRAL)
        val half = PixelRasterizer.composeIndices(data, PixelPose.IDLE, PixelRasterizer.PART_ALL, EyeState.HALF, MouthState.NEUTRAL)
        // ojos abiertos: esclerótica, iris y pupila; cerrados: párpado y pestañas, sin iris
        assertTrue(open.contains(com.terror2d.pixel.PixelIndex.SCLERA))
        assertTrue(open.contains(com.terror2d.pixel.PixelIndex.IRIS))
        assertTrue(open.contains(com.terror2d.pixel.PixelIndex.EYE))
        assertFalse(closed.contains(com.terror2d.pixel.PixelIndex.IRIS))
        assertFalse(closed.contains(com.terror2d.pixel.PixelIndex.SCLERA))
        assertTrue(closed.contains(com.terror2d.pixel.PixelIndex.LID))
        assertNotEquals(PixelRasterizer.hash(open), PixelRasterizer.hash(closed))
        assertNotEquals(PixelRasterizer.hash(open), PixelRasterizer.hash(half))
        // la marca de la mejilla y el rubor están en la cara
        val base = data.frame(PixelPose.IDLE)
        assertTrue(base.contains(com.terror2d.pixel.PixelIndex.FACE_MARK))
        assertTrue(base.contains(com.terror2d.pixel.PixelIndex.BLUSH))
        // la boca tiene variaciones expresivas distintas
        val mouths = MouthState.values().map {
            PixelRasterizer.hash(PixelRasterizer.composeIndices(data, PixelPose.IDLE, PixelRasterizer.PART_ALL, EyeState.OPEN, it))
        }
        assertEquals(MouthState.values().size, mouths.toSet().size)
        // el parpadeo del jugador: abre -> medio -> cerrado -> medio -> abre, y vuelve a abrir
        val w = World(room = KID, spawn = "start")
        val p = w.scene.player
        val seen = ArrayList<EyeState>()
        repeat(60 * 12) {
            w.step()
            if (seen.isEmpty() || seen.last() != p.eyes) seen.add(p.eyes)
        }
        assertTrue("parpadea", seen.contains(EyeState.CLOSED) && seen.contains(EyeState.HALF))
        assertEquals(EyeState.OPEN, seen.first())
        assertTrue("vuelve a abrir los ojos", seen.indexOf(EyeState.CLOSED) < seen.lastIndexOf(EyeState.OPEN))
        // poses con expresión propia
        p.poseOverride = PixelPose.HURT
        p.speaking = false
        assertEquals(EyeState.CLOSED, p.eyes)
        assertEquals(MouthState.OPEN, p.mouth)
        p.poseOverride = null
    }

    @Test
    fun heldObjectsAreGrippedByTheFrontHand() {
        val data = ProtagonistSprite.create()
        for (pose in listOf(PixelPose.HOLD_ITEM, PixelPose.HOLD_WALK_1, PixelPose.HOLD_WALK_2, PixelPose.HOLD_WALK_3, PixelPose.GIVE_ITEM)) {
            assertNotNull("sin capa de mano en $pose", data.frontFrame(pose))
            assertNotNull(data.hand(pose))
        }
        assertNull(data.frontFrame(PixelPose.IDLE))
        // todos los objetos usan el mismo sistema: un sprite canónico con su punto de agarre
        for (id in listOf(ItemRegistry.WATER_GLASS, ItemRegistry.PILL_BOX_BLUE, ItemRegistry.PILL_BOX_ORANGE, ItemRegistry.PILL_BOX_WHITE, ItemRegistry.FROG_PLUSH)) {
            val item = ItemSprites.get(id)
            assertNotNull("sin sprite para $id", item)
            assertEquals(0.5f, item!!.scale, 0f)
            assertTrue(item.gripX in 0 until item.width && item.gripY in 0 until item.height)
        }
    }

    @Test
    fun plushHasOneCanonicalScaleEverywhere() {
        val sprite = ItemSprites.get(ItemRegistry.FROG_PLUSH)!!
        // 32x32 px de sprite a escala 0.5 = 16x16 lógicos: del tamaño de una ranita que un niño sostiene
        assertEquals(16f, ItemSprites.logicalWidth(ItemRegistry.FROG_PLUSH), 0f)
        assertEquals(16f, ItemSprites.logicalHeight(ItemRegistry.FROG_PLUSH), 0f)
        assertEquals(PlushFrog.WIDTH, ItemSprites.logicalWidth(ItemRegistry.FROG_PLUSH), 0f)
        assertEquals(PlushFrog.HEIGHT, ItemSprites.logicalHeight(ItemRegistry.FROG_PLUSH), 0f)
        // pequeño en la habitación (menos de la mitad del niño) y grande en la mano (no diminuto)
        val kid = Player.HEIGHT
        assertTrue(PlushFrog.HEIGHT < kid * 0.5f)
        assertTrue(PlushFrog.HEIGHT > kid * 0.25f)
        // un único objeto: la misma instancia de datos para suelo, cama, mano, inventario y HOLD_ITEM
        assertSame(sprite, ItemSprites.get(ItemRegistry.FROG_PLUSH))
        // cabeza grande, ojos saltones y cruz: usa verdes, blancos, cruz y costuras
        val used = sprite.frame(PixelPose.IDLE).toSet()
        assertTrue(used.size >= 12)
        // las cajas conservan la huella de v0.5 (8x11) y el vaso 7x11
        assertEquals(8f, ItemSprites.logicalWidth(ItemRegistry.PILL_BOX_BLUE), 0f)
        assertEquals(11f, ItemSprites.logicalHeight(ItemRegistry.PILL_BOX_BLUE), 0f)
        assertEquals(7f, ItemSprites.logicalWidth(ItemRegistry.WATER_GLASS), 0f)
        // en el mundo ocupa exactamente lo mismo estando en el suelo que sobre la cama
        val w = World(room = KID, spawn = "start")
        val plush = w.scene.currentSegment.objects.filterIsInstance<PlushFrog>().first()
        assertEquals(PlushFrog.WIDTH, plush.width, 0f)
        assertEquals(PlushFrog.HEIGHT, plush.height, 0f)
        plush.placeAt(172f, 104f)
        assertEquals(PlushFrog.WIDTH, plush.width, 0f)
        assertEquals(PlushFrog.HEIGHT, plush.height, 0f)
    }

    @Test
    fun paperEffectsArePreparedAsPaperOverlays() {
        for (kind in PaperEffects.ALL_KINDS) {
            val s = PaperEffects.sprite(kind)
            assertTrue("el efecto $kind tiene dibujo", s.ops.isNotEmpty())
            assertEquals("determinista", s.hash(1L), PaperEffects.sprite(kind).hash(1L))
        }
        assertEquals(5, PaperEffects.ALL_KINDS.size)
        // el protagonista sigue siendo pixel art: los efectos son una capa aparte (máscara de bits del jugador)
        val w = World(room = KID, spawn = "start")
        assertEquals(0, w.scene.player.paperEffects)
        w.scene.player.paperEffects = PaperEffects.TEARS or PaperEffects.SWEAT
        assertTrue(w.scene.player.paperEffects and PaperEffects.TEARS != 0)
    }

    @Test
    fun lightingChangesTheCharacterPixels() {
        val data = ProtagonistSprite.create()
        val bright = LightingSample().also { it.set(1f, 1f, 1f, 1f) }
        val dark = LightingSample().also { it.set(0f, 1f, 1f, 1f) }
        val warm = LightingSample().also { it.set(1f, 1f, 0.85f, 0.55f) }
        val hb = PixelRasterizer.hash(PixelRasterizer.rasterize(data, PixelPose.IDLE, false, bright))
        val hd = PixelRasterizer.hash(PixelRasterizer.rasterize(data, PixelPose.IDLE, false, dark))
        val hw = PixelRasterizer.hash(PixelRasterizer.rasterize(data, PixelPose.IDLE, false, warm))
        assertNotEquals(hb, hd)
        assertNotEquals(hb, hw)
        // en la sombra la piel es más oscura; con luz cálida baja el azul
        val skinIdx = com.terror2d.pixel.PixelIndex.SKIN
        val i = data.frame(PixelPose.IDLE).indexOfFirst { it == skinIdx }
        val pb = PixelRasterizer.rasterize(data, PixelPose.IDLE, false, bright)[i]
        val pd = PixelRasterizer.rasterize(data, PixelPose.IDLE, false, dark)[i]
        val pw = PixelRasterizer.rasterize(data, PixelPose.IDLE, false, warm)[i]
        assertTrue((pd shr 16 and 0xFF) < (pb shr 16 and 0xFF))
        assertTrue((pw and 0xFF) < (pb and 0xFF))
    }

    @Test
    fun theHouseLightsReachThePlayer() {
        val w = World(room = HALL, spawn = HouseDefinition.fromSpawn(KID))
        w.standAt(125f)
        val underLamp = w.scene.player.light.brightness
        val warmR = w.scene.player.light.tintR
        val warmB = w.scene.player.light.tintB
        w.standAt(831f)
        val inShadow = w.scene.player.light.brightness
        assertTrue("bajo la lámpara $underLamp, en sombra $inShadow", underLamp > inShadow + 0.3f)
        assertTrue("la luz cálida tiñe al personaje", warmR > warmB)
        val k = LightingSample()
        val seg = HouseDefinition.create().segment(HALL)
        LightField.sample(135f, 54f, seg.lights, seg.ambientDark, seg.darkZones, 0f, k)
        assertTrue(k.brightness > 0.9f)
    }

    @Test
    fun lightFieldFalloffMatchesTheDarknessMask() {
        assertEquals(1f, LightField.falloff(0f), 0.001f)
        assertEquals(0f, LightField.falloff(1f), 0.001f)
        assertEquals(0.588f, LightField.falloff(0.5f), 0.01f)
        var prev = 2f
        var t = 0f
        while (t <= 1f) {
            val v = LightField.falloff(t)
            assertTrue(v <= prev + 0.0001f)
            prev = v
            t += 0.05f
        }
    }

    // ================================================================== Crayón determinista

    @Test
    fun crayonDrawingsAreDeterministic() {
        fun draw(seed: Long): Long {
            val b = CrayonBuilder(SeededRandom(seed))
            b.box(0f, 0f, 40f, 30f, 0xFFC98E52.toInt())
            b.face(20f, 15f, 8f, 0xFFFFD2A8.toInt(), 1)
            return b.finish().hash(7L)
        }
        assertEquals(draw(3L), draw(3L))
        assertNotEquals(draw(3L), draw(4L))
    }

    @Test
    fun backdropIsChunkedAndDeterministic() {
        val seg = HouseDefinition.create().segment(HALL)
        val a = BackdropBuilder.build(seg, 11L)
        val b = BackdropBuilder.build(seg, 11L)
        val c = BackdropBuilder.build(seg, 12L)
        assertEquals(6, a.size)
        var ha = 0L; var hb = 0L; var hc = 0L
        for (i in a.indices) { ha = a[i].hash(ha); hb = b[i].hash(hb); hc = c[i].hash(hc) }
        assertEquals(ha, hb)
        assertNotEquals(ha, hc)
        assertTrue("el fondo tiene detalle", a.sumOf { it.ops.size } > 100)
    }

    @Test
    fun sameSeedSameHouse() {
        val a = World(seed = 5L)
        val b = World(seed = 5L)
        val c = World(seed = 6L)
        for (room in allRooms) {
            a.scene.loadSegment(room, spawnFor(room), a.state)
            b.scene.loadSegment(room, spawnFor(room), b.state)
            c.scene.loadSegment(room, spawnFor(room), c.state)
            assertEquals("$room: misma semilla, mismo aspecto", a.scene.visualFingerprint(), b.scene.visualFingerprint())
            assertNotEquals("$room: otra semilla, otro aspecto", a.scene.visualFingerprint(), c.scene.visualFingerprint())
        }
    }

    @Test
    fun seedNeverChangesStructure() {
        val a = HouseDefinition.create(1L)
        val b = HouseDefinition.create(987654L)
        for (i in a.segments.indices) {
            val sa = a.segments[i]
            val sb = b.segments[i]
            assertEquals(sa.id, sb.id)
            assertEquals(sa.width, sb.width, 0f)
            assertEquals(sa.objects.size, sb.objects.size)
            for (j in sa.doors.indices) {
                assertEquals(sa.doors[j].x, sb.doors[j].x, 0f)
                assertEquals(sa.doors[j].target?.segmentId, sb.doors[j].target?.segmentId)
            }
            for (j in sa.objects.indices) {
                assertEquals(sa.objects[j].x, sb.objects[j].x, 0f)
                assertEquals(sa.objects[j].y, sb.objects[j].y, 0f)
            }
            assertEquals(sa.lights.size, sb.lights.size)
            for (k in sa.spawnPoints.keys) assertEquals(sa.spawnPoints[k]!!.x, sb.spawnPoints[k]!!.x, 0f)
        }
    }

    // ================================================================== Iluminación por habitación

    @Test
    fun everyRoomIsDarkWithItsOwnLighting() {
        val def = HouseDefinition.create()
        for (seg in def.segments) {
            assertTrue("${seg.id} no es oscura", seg.ambientDark >= 0.7f)
            assertTrue("${seg.id} sin luz", seg.lights.isNotEmpty())
        }
        assertEquals(CELLAR, def.segments.maxByOrNull { it.ambientDark }!!.id)
        assertEquals(Palette.DARK_COLD, def.segment(BATH).ambientColor)
        assertEquals(Palette.DARK_COLD, def.segment(LAUNDRY).ambientColor)
        assertEquals(Palette.DARK_WARM, def.segment(KITCHEN).ambientColor)
        assertTrue(def.segment(KITCHEN).ambientDark < def.segment(DINING).ambientDark)
        assertTrue(def.segment(HALL).lights.size >= 4)
        assertTrue(def.segment(HALL).darkZones.isNotEmpty())
        assertEquals(1, def.segment(CELLAR).lights.count { it.radius > 70f })
    }

    // ================================================================== Base v0.3 (texto, eventos, transición, render)

    @Test
    fun messagesAndDialoguesStillWork() {
        val d = DialogueManager()
        d.showMessage("Hola")
        assertFalse(d.blocksInput)
        repeat(400) { d.update(dt) }
        assertFalse(d.isActive)
        var finished = false
        d.startDialogue(listOf(DialogueLine("Niño", "Uno"), DialogueLine(null, "Dos")), { finished = true })
        assertTrue(d.blocksInput)
        d.advance(); d.advance(); d.advance(); d.advance()
        assertFalse(d.isActive)
        assertTrue(finished)
    }

    @Test
    fun eventBusDeliversEvents() {
        val bus = EventBus()
        var count = 0
        bus.subscribe(EventType.ON_HIDE) { count++ }
        bus.post(EventType.ON_HIDE, "a")
        bus.post(EventType.ON_STORY_FLAG, "a")
        assertEquals(1, count)
        assertTrue(bus.wasPosted(EventType.ON_STORY_FLAG))
    }

    @Test
    fun sceneTransitionStateMachine() {
        val t = SceneTransition()
        t.start(DoorTarget("x", "y"), null)
        var loads = 0
        repeat(120) { if (t.update(dt)) loads++ }
        assertEquals(1, loads)
        assertFalse(t.isActive)
    }

    @Test
    fun renderingConfigurationIsUnchanged() {
        assertEquals(320, GameConfig.LOGICAL_WIDTH)
        assertEquals(180, GameConfig.LOGICAL_HEIGHT)
        assertEquals(GameConfig.LOGICAL_WIDTH / 2, LightingRenderer.MASK_W)
        assertEquals(GameConfig.LOGICAL_HEIGHT / 2, LightingRenderer.MASK_H)
        val v = Viewport()
        v.update(1920, 1080)
        assertEquals(6f, v.scale, 0.001f)
        val w = World()
        w.walk(false, true, 200)
        assertEquals(0f, w.state.visualCorruption, 0f)
    }

    @Test
    fun lightSourceStillModelsStateAndFade() {
        val l = LightSource(100f, 50f, 80f, 0xFFFFD27A.toInt(), 0.8f)
        assertTrue(l.reaches(100f, 100f))
        l.active = false
        repeat(60) { l.update(dt) }
        assertEquals(0f, l.effectiveIntensity(0f), 0f)
    }

    // ================================================================== v0.6: documentos, puzzle y primera persona

    private fun dragBox(p: MedicinePuzzle, index: Int, tx: Float, ty: Float) {
        val b = p.boxes[index]
        p.onPress(b.x, b.y)
        p.onDrag(b.x + 12f, b.y + 12f)
        p.update(0.05f)
        p.onDrag(tx, ty)
        repeat(40) { p.update(1f / 60f) }
        p.onRelease(tx, ty)
        repeat(60) { p.update(1f / 60f) }
    }

    private fun boxIndex(p: MedicinePuzzle, itemId: String): Int = p.boxes.indexOfFirst { it.itemId == itemId }

    @Test
    fun thereAreExactlyThreeRelevantDocuments() {
        assertEquals(3, Documents.ALL.size)
        assertEquals(setOf(Documents.MEDICAL, Documents.FINANCE, Documents.PHARMACY), Documents.ALL.map { it.id }.toSet())
        for (d in Documents.ALL) {
            assertTrue(d.lines.isNotEmpty())
            assertTrue("${d.id}: líneas demasiado largas para la pantalla", d.lines.all { it.length <= 34 })
            assertTrue(d.reaction.isNotEmpty())
            assertTrue("el niño no explica la enfermedad", d.reaction.all { it.speaker == null && it.text.length < 60 })
        }
        // el niño reacciona como un niño de 8 años
        assertEquals("No entiendo…", Documents.medical.reaction.first().text)
        assertEquals("¿Por qué mamá tiene tantas cartas?", Documents.finance.reaction.first().text)
        assertEquals("¿Otra vez las medicinas?", Documents.pharmacy.reaction.first().text)
        // económico: la situación familiar está afectada por el tratamiento
        assertTrue(Documents.finance.lines.any { it.contains("ADEUDADO") })
        assertNotNull(Documents.finance.handwritten)
        // el médico no revela la enfermedad principal
        assertTrue(Documents.medical.lines.none { it.contains("cáncer", ignoreCase = true) || it.contains("diagnóstico", ignoreCase = true) })
        // y están realmente en la casa
        val def = HouseDefinition.create()
        val mom = def.segment(MOM).objects.filterIsInstance<com.terror2d.world.ScriptedSpot>().map { it.id }
        val kitchen = def.segment(KITCHEN).objects.filterIsInstance<com.terror2d.world.ScriptedSpot>().map { it.id }
        assertTrue(HouseDefinition.SPOT_DOC_MEDICAL in mom)
        assertTrue(HouseDefinition.SPOT_PUZZLE in mom)
        assertTrue(HouseDefinition.SPOT_DOC_FINANCE in kitchen)
    }

    @Test
    fun documentsOpenAsPaperAndTheChildReactsLikeAChild() {
        val w = World(room = MOM, spawn = "from_hall")
        w.step(60 * 60)
        w.scene.dialogue.clear()
        w.standAt(100f)
        assertEquals(HouseDefinition.SPOT_DOC_MEDICAL, w.scene.focused?.interactionId)
        assertEquals("LEER", w.input.actionLabel)
        w.pressAction()
        assertEquals(Documents.medical, w.scene.reading)
        assertTrue(w.state.story.has(StoryFlags.READ_DOC_MEDICAL))
        assertTrue(w.scene.events.wasPosted(EventType.ON_DOCUMENT_READ, Documents.MEDICAL))
        // con el papel abierto el niño no se mueve y el botón dice CERRAR
        val x0 = w.scene.player.x
        w.walk(false, true, 30)
        assertEquals(x0, w.scene.player.x, 0f)
        assertEquals("CERRAR", w.input.actionLabel)
        w.step(30)
        w.pressAction()
        assertNull(w.scene.reading)
        assertEquals("No entiendo…", w.scene.dialogue.current?.text)
        w.finishDialogue()

        val k = World(room = KITCHEN, spawn = "from_hall")
        k.step(60 * 60)
        k.scene.dialogue.clear()
        k.standAt(355f)
        assertEquals(HouseDefinition.SPOT_DOC_FINANCE, k.scene.focused?.interactionId)
        k.pressAction()
        assertEquals(Documents.finance, k.scene.reading)
        assertTrue(k.state.story.has(StoryFlags.READ_DOC_FINANCE))
    }

    @Test
    fun medicineBoxesFormTheWordAndHaveATimeOfDayEach() {
        val p = MedicinePuzzle()
        assertEquals(3, p.boxes.size)
        assertEquals(MedicinePuzzle.PASSWORD, p.boxes.sortedBy { it.timeSlot }.map { it.letter }.joinToString(""))
        assertEquals(setOf(0, 1, 2), p.boxes.map { it.timeSlot }.toSet())
        assertFalse(p.solved)
        assertFalse(p.isSolution())
        for (b in p.boxes) assertEquals("al empezar están sueltas", -1, b.slot)
    }

    @Test
    fun boxesFollowTheFingerLikePhysicalObjects() {
        val p = MedicinePuzzle()
        val b = p.boxes[0]
        val x0 = b.x
        p.onPress(b.x, b.y)
        assertSame(b, p.dragging)
        p.onDrag(b.x + 40f, b.y + 25f)
        repeat(3) { p.update(1f / 60f) }
        assertTrue("la caja se levanta y empieza a seguir el dedo", b.x > x0 && b.lift > 0f)
        assertEquals(1, p.handKind)
        repeat(60) { p.update(1f / 60f) }
        assertEquals(x0 + 40f, b.x, 0.5f)
        assertTrue("se inclina con la inercia o ya se asentó", kotlin.math.abs(b.tilt) <= 9.5f)
        p.onRelease(b.x, b.y)
        assertNull(p.dragging)
        assertEquals("se queda donde se soltó", x0 + 40f, b.x, 0.5f)
        // un toque corto da la vuelta a la caja (reverso con las indicaciones)
        val c = p.boxes[1]
        p.onPress(c.x, c.y)
        p.onRelease(c.x, c.y)
        assertTrue(c.flipped)
        repeat(60) { p.update(1f / 60f) }
        assertEquals(1f, c.flipT, 0f)
        // tocar la hoja de la farmacia la abre para leerla
        p.onPress(PuzzleLayout.PAPER_X, PuzzleLayout.PAPER_Y)
        p.onRelease(PuzzleLayout.PAPER_X, PuzzleLayout.PAPER_Y)
        assertEquals(Documents.PHARMACY, p.requestedDocument)
    }

    @Test
    fun puzzleSolvesOnlyWithTheRightOrderAndNeverShowsAnError() {
        val p = MedicinePuzzle()
        val white = boxIndex(p, ItemRegistry.PILL_BOX_WHITE)
        val orange = boxIndex(p, ItemRegistry.PILL_BOX_ORANGE)
        val blue = boxIndex(p, ItemRegistry.PILL_BOX_BLUE)
        // orden equivocado: blanca - naranja - azul
        dragBox(p, white, PuzzleLayout.SLOT_X[0], PuzzleLayout.SLOT_Y)
        dragBox(p, orange, PuzzleLayout.SLOT_X[1], PuzzleLayout.SLOT_Y)
        dragBox(p, blue, PuzzleLayout.SLOT_X[2], PuzzleLayout.SLOT_Y)
        assertEquals(0, p.boxes[white].slot)
        assertEquals(1, p.boxes[orange].slot)
        assertEquals(2, p.boxes[blue].slot)
        assertFalse("un orden incorrecto no resuelve nada", p.solved)
        assertFalse(p.justSolved)
        assertNull("sin mensajes de error ni reacción", p.requestedDocument)
        // arrastrar la azul sobre el primer hueco ocupado intercambia las cajas
        dragBox(p, blue, PuzzleLayout.SLOT_X[0], PuzzleLayout.SLOT_Y)
        assertEquals(0, p.boxes[blue].slot)
        assertEquals(1, p.boxes[orange].slot)
        assertEquals("la blanca ocupa el hueco que dejó la azul", 2, p.boxes[white].slot)
        assertTrue(p.solved)
        assertTrue(p.justSolved)
        assertEquals(PuzzleLayout.SLOT_X[0], p.boxes[blue].x, 0.5f)
        assertEquals(PuzzleLayout.SLOT_X[2], p.boxes[white].x, 0.5f)
        // resuelto: las cajas quedan bloqueadas
        p.onPress(p.boxes[blue].x, p.boxes[blue].y)
        assertNull(p.dragging)
    }

    @Test
    fun puzzleSwitchesToFirstPersonDragsThreeBoxesAndReturnsToThirdPerson() {
        val w = World(room = MOM, spawn = "from_hall")
        w.step(60 * 60)
        w.scene.dialogue.clear()
        w.standAt(268f)
        assertNotEquals("antes de la introducción el puzzle no está disponible", HouseDefinition.SPOT_PUZZLE, w.scene.focused?.interactionId)
        w.state.story.set(StoryFlags.INTRO_DONE)
        w.standAt(268f)
        assertEquals(HouseDefinition.SPOT_PUZZLE, w.scene.focused?.interactionId)
        assertEquals("ORDENAR", w.input.actionLabel)
        assertEquals(FirstPersonView.Phase.NONE, w.scene.firstPerson.phase)

        // TERCERA PERSONA -> PRIMERA PERSONA
        w.pressAction()
        assertEquals(FirstPersonView.Phase.ENTERING, w.scene.firstPerson.phase)
        assertTrue(w.state.story.has(StoryFlags.PUZZLE_STARTED))
        w.step(60)
        assertEquals(FirstPersonView.Phase.ACTIVE, w.scene.firstPerson.phase)
        assertEquals(1f, w.scene.firstPerson.blend, 0f)
        val p = w.scene.puzzle!!
        assertTrue(w.input.puzzleMode)
        assertFalse("sin botón de acción en primera persona", w.input.actionEnabled)
        val x0 = w.scene.player.x
        w.walk(false, true, 30)
        assertEquals("el niño no camina mientras tanto", x0, w.scene.player.x, 0f)

        // TOCAR + MANTENER + ARRASTRAR + SOLTAR (las tres cajas, con el dedo)
        fun finger(index: Int, tx: Float, ty: Float) {
            val b = p.boxes[index]
            w.input.setPointer(true, b.x, b.y)
            w.step(2)
            w.input.setPointer(true, b.x + 20f, b.y + 20f)
            w.step(3)
            w.input.setPointer(true, tx, ty)
            w.step(30)
            w.input.setPointer(false, tx, ty)
            w.step(40)
        }
        finger(boxIndex(p, ItemRegistry.PILL_BOX_BLUE), PuzzleLayout.SLOT_X[0], PuzzleLayout.SLOT_Y)
        finger(boxIndex(p, ItemRegistry.PILL_BOX_ORANGE), PuzzleLayout.SLOT_X[1], PuzzleLayout.SLOT_Y)
        assertFalse(p.solved)
        finger(boxIndex(p, ItemRegistry.PILL_BOX_WHITE), PuzzleLayout.SLOT_X[2], PuzzleLayout.SLOT_Y)
        assertTrue(p.solved)
        assertTrue(w.scene.events.wasPosted(EventType.MEDICINE_PUZZLE_COMPLETED, MedicinePuzzle.ID))
        assertTrue(w.state.story.has(StoryFlags.MEDICINE_PUZZLE_DONE))
        assertTrue(w.state.story.has(StoryFlags.MEDICINE_CODE_KNOWN))

        // PRIMERA PERSONA -> TERCERA PERSONA
        w.step(60 * 5)
        assertEquals(FirstPersonView.Phase.NONE, w.scene.firstPerson.phase)
        assertNull(w.scene.puzzle)
        assertFalse(w.input.puzzleMode)
        assertTrue(w.scene.events.wasPosted(EventType.ON_PUZZLE_ENDED, MedicinePuzzle.ID))
        // v0.9: terminar el puzzle abre la noche: el niño dice que se va a dormir y pierde el control (ver NarrativeTest)
        w.step(60 * 8)
        assertEquals(com.terror2d.story.NarrativePhase.CHILD_GOES_TO_BED, w.state.story.phase)
        assertTrue(w.scene.narrative.bedtime.active)
        // ya no se puede repetir el puzzle: la mesita solo se examina
        assertTrue(w.state.story.has(StoryFlags.MEDICINE_PUZZLE_DONE))
    }

    @Test
    fun puzzleCanBeLeftWithTheBackTabWithoutSolving() {
        val w = World(room = MOM, spawn = "from_hall")
        w.step(60 * 60)
        w.state.story.set(StoryFlags.INTRO_DONE)
        w.standAt(268f)
        w.pressAction()
        w.step(60)
        w.input.setPointer(true, PuzzleLayout.BACK_X + 8f, PuzzleLayout.BACK_Y + 6f)
        w.step(2)
        w.input.setPointer(false, PuzzleLayout.BACK_X + 8f, PuzzleLayout.BACK_Y + 6f)
        w.step(60 * 2)
        assertEquals(FirstPersonView.Phase.NONE, w.scene.firstPerson.phase)
        assertFalse(w.state.story.has(StoryFlags.MEDICINE_PUZZLE_DONE))
        assertFalse(w.scene.events.wasPosted(EventType.MEDICINE_PUZZLE_COMPLETED, MedicinePuzzle.ID))
    }

    @Test
    fun pointerEdgesAreDetected() {
        val input = InputController()
        input.setPointer(true, 10f, 20f)
        assertTrue(input.pointerPressed && input.pointerDown)
        input.endFrame()
        assertFalse(input.pointerPressed)
        input.setPointer(true, 30f, 40f)
        assertFalse(input.pointerPressed)
        input.setPointer(false, 30f, 40f)
        assertTrue(input.pointerReleased && !input.pointerDown)
        assertEquals(30f, input.pointerX, 0f)
    }
}
