package com.terror2d

import com.terror2d.audio.AmbienceId
import com.terror2d.audio.AudioDirector
import com.terror2d.audio.AudioEngine
import com.terror2d.audio.AudioPort
import com.terror2d.audio.Emotion
import com.terror2d.audio.MusicId
import com.terror2d.audio.OfflineAudioSink
import com.terror2d.audio.SfxId
import com.terror2d.audio.Surface
import com.terror2d.audio.VoiceId
import com.terror2d.audio.VoiceKind
import com.terror2d.core.GameState
import com.terror2d.core.WorldMode
import com.terror2d.creature.CreatureState
import com.terror2d.events.EventType
import com.terror2d.events.GameEvent
import com.terror2d.input.InputAction
import com.terror2d.input.InputController
import com.terror2d.pixel.PixelPose
import com.terror2d.scene.HouseDefinition
import com.terror2d.scene.HouseDefinition.HALL
import com.terror2d.scene.HouseDefinition.KID
import com.terror2d.scene.HouseDefinition.MOM
import com.terror2d.scene.HouseScene
import com.terror2d.scene.Scene
import com.terror2d.scene.SceneDefinition
import com.terror2d.story.BedGeometry
import com.terror2d.story.BedtimeSequence
import com.terror2d.story.CreatureIntro
import com.terror2d.story.Documents
import com.terror2d.story.NarrativePhase
import com.terror2d.story.Poi
import com.terror2d.story.PointOfInterest
import com.terror2d.story.PointsOfInterest
import com.terror2d.story.StoryFlags
import com.terror2d.story.StoryState
import com.terror2d.world.Player
import com.terror2d.world.PlushFrog
import com.terror2d.world.PlushState
import com.terror2d.world.ProceduralWindow
import com.terror2d.world.RainField
import com.terror2d.world.StoryGate
import com.terror2d.world.WindowRainOverlay
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/** Pruebas de 0.9: la desaparición de mamá y la primera aparición de la criatura. */
class NarrativeTest {

    private open class World(room: String = KID, spawn: String = "start", scene0: Scene? = null) {
        val state = GameState()
        val input = InputController()
        val scene: Scene = (scene0 ?: HouseScene(HouseDefinition.DEFAULT_SEED)).also { it.load(state) }

        init {
            if (room != KID || spawn != "start") scene.loadSegment(room, spawn, state)
        }

        fun step(n: Int = 1) {
            repeat(n) {
                scene.update(1f / 60f, input, state)
                input.endFrame()
            }
        }

        fun pressAction() {
            input.setAction(InputAction.INTERACT, true)
            step(1)
            input.setAction(InputAction.INTERACT, false)
        }

        fun standCenterAt(cx: Float) {
            scene.player.x = cx - Player.WIDTH / 2f
            step()
        }

        fun finishDialogue() {
            var n = 0
            while (scene.dialogue.blocksInput && n < 30) {
                pressAction()
                n++
            }
        }

        /** Simula el final correcto del puzzle (el MISMO hito y evento que publica la escena). */
        fun completePuzzle() {
            state.story.set(StoryFlags.INTRO_DONE)
            if (state.story.set(StoryFlags.MEDICINE_PUZZLE_COMPLETED)) {
                scene.events.post(EventType.ON_STORY_FLAG, StoryFlags.MEDICINE_PUZZLE_COMPLETED, scene.currentSegment.id)
            }
        }

        fun stepUntil(maxSteps: Int, cond: () -> Boolean): Boolean {
            var i = 0
            while (i < maxSteps) {
                if (cond()) return true
                step()
                i++
            }
            return cond()
        }
    }

    private fun plushOf(w: World): PlushFrog = w.scene.currentSegment.objects.filterIsInstance<PlushFrog>().first()

    /** Corre toda la secuencia de dormir y devuelve las fases por las que pasó, en orden. */
    private fun runNight(w: World, onFrame: () -> Unit = {}): List<BedtimeSequence.Phase> {
        val seen = ArrayList<BedtimeSequence.Phase>()
        var steps = 0
        while (steps < 60 * 90) {
            val ph = w.scene.narrative.bedtime.phase
            if (ph != BedtimeSequence.Phase.IDLE && (seen.isEmpty() || seen.last() != ph)) seen.add(ph)
            if (ph == BedtimeSequence.Phase.DONE) break
            onFrame()
            w.step()
            steps++
        }
        return seen
    }

    // ------------------------------------------------------------------ 1. Ranita bloqueada / desbloqueada

    @Test
    fun plushIsVisibleButLockedAtTheStart() {
        val w = World()
        val plush = plushOf(w)
        assertTrue(plush.visible)
        assertFalse(w.state.story.has(StoryFlags.PLUSH_AVAILABLE))
        w.standCenterAt(plush.centerX)
        assertTrue("Ranita no es interactuable mientras está bloqueada", w.scene.focused !== plush)
        w.pressAction()
        w.step(60)
        assertEquals(PlushState.ON_FLOOR, plush.state)
        assertFalse(w.state.inventory.companion.isCarried)
    }

    @Test
    fun plushUnlocksFromTheNarrativeStateNotFromACoordinate() {
        val w = World()
        val plush = plushOf(w)
        w.state.story.set(StoryFlags.PLUSH_AVAILABLE)
        w.standCenterAt(plush.centerX)
        assertTrue(w.scene.focused === plush)
        // el desbloqueo es el hito, así que vale desde cualquier punto en el que el jugador pueda alcanzarla
        w.standCenterAt(plush.centerX + 6f)
        assertTrue(w.scene.focused === plush)
    }

    // ------------------------------------------------------------------ 2. puzzle -> dormir

    @Test
    fun medicineCompletionStartsTheBedtimeSequenceOnlyOnce() {
        val w = World(MOM, "from_hall")
        var started = 0
        w.scene.events.subscribe(EventType.BEDTIME_STARTED) { started++ }
        assertEquals(NarrativePhase.INITIAL_ROUTINE, w.state.story.phase)
        w.step(60 * 5)
        assertEquals("sin puzzle no hay noche", BedtimeSequence.Phase.IDLE, w.scene.narrative.bedtime.phase)
        w.completePuzzle()
        assertEquals(NarrativePhase.MEDICINE_COMPLETED, w.state.story.phase)
        assertTrue(w.stepUntil(60 * 6) { w.scene.narrative.bedtime.active })
        assertEquals("Bueno... debería irme a mi habitación ya. Es tarde.", w.scene.dialogue.current?.text)
        assertEquals(NarrativePhase.CHILD_GOES_TO_BED, w.state.story.phase)
        // repetir el evento no reinicia nada
        w.scene.events.post(EventType.ON_STORY_FLAG, StoryFlags.MEDICINE_PUZZLE_COMPLETED, MOM)
        w.step(60)
        assertEquals(1, started)
    }

    @Test
    fun theWholeNightRunsWalkClimbSettleLieFadeScreamAndWake() {
        val w = World(MOM, "from_hall")
        var screams = 0
        w.scene.events.subscribe(EventType.MOM_SCREAM) { screams++ }
        var steps = 0
        w.scene.events.subscribe(EventType.FOOTSTEP) { steps++ }
        var maxBlack = 0f
        var restChecked = false
        var lastFade = -1f
        var fadeMonotone = true
        w.completePuzzle()
        val seen = runNight(w) {
            val a = w.scene.transitionAlpha
            if (a > maxBlack) maxBlack = a
            val seq = w.scene.narrative.bedtime
            if (seq.phase == BedtimeSequence.Phase.FADE_OUT) {
                if (a < lastFade - 1e-4f) fadeMonotone = false
                lastFade = a
            }
            if (seq.phase == BedtimeSequence.Phase.REST) {
                restChecked = true
                assertEquals(-90f, w.scene.player.bodyAngle, 0f)
                assertTrue(w.scene.player.bodyLift > 20f)
                assertEquals(PixelPose.IDLE, w.scene.player.poseOverride)
            }
            if (seq.active) assertTrue("el jugador no controla durante la secuencia", w.scene.narrative.controlLocked)
        }
        val expected = listOf(
            BedtimeSequence.Phase.SAY, BedtimeSequence.Phase.WALK, BedtimeSequence.Phase.CLIMB, BedtimeSequence.Phase.SETTLE,
            BedtimeSequence.Phase.LIE, BedtimeSequence.Phase.REST, BedtimeSequence.Phase.FADE_OUT, BedtimeSequence.Phase.BLACK,
            BedtimeSequence.Phase.WAKE, BedtimeSequence.Phase.DONE
        )
        assertEquals(expected, seen)
        assertTrue(restChecked)
        assertTrue("el fundido a negro es progresivo", fadeMonotone)
        assertEquals("llega a negro total", 1f, maxBlack, 0.001f)
        assertTrue("pasos del niño durante la secuencia", steps > 10)
        // termina en su cuarto, con el control de vuelta
        w.step(30)
        assertEquals(KID, w.scene.currentSegment.id)
        assertEquals(0f, w.scene.transitionAlpha, 0.001f)
        assertEquals(0f, w.scene.player.bodyAngle, 0f)
        assertNull(w.scene.player.poseOverride)
        assertEquals(NarrativePhase.PLUSH_UNLOCKED, w.state.story.phase)
        assertTrue(w.state.story.has(StoryFlags.PLUSH_AVAILABLE))
        val x0 = w.scene.player.x
        w.input.setDirection(false, true)
        w.step(30)
        w.input.setDirection(false, false)
        assertTrue("el jugador recupera el control", w.scene.player.x > x0)
        // el grito ocurrió una sola vez, aunque pase mucho tiempo
        w.step(60 * 20)
        assertEquals(1, screams)
    }

    @Test
    fun plushBecomesAvailableAfterTheScream() {
        val w = World(KID, "start")
        val plush = plushOf(w)
        w.completePuzzle()
        assertFalse(w.state.story.has(StoryFlags.PLUSH_AVAILABLE))
        runNight(w)
        w.scene.dialogue.clear()
        w.standCenterAt(plush.centerX)
        assertTrue(w.scene.focused === plush)
    }

    // ------------------------------------------------------------------ 7-8. habitación de mamá, ventana, lluvia

    private fun nightPassed(w: World) {
        w.state.story.set(StoryFlags.PLUSH_AVAILABLE)
        w.state.story.set(StoryFlags.MOM_SCREAM_HEARD)
        w.state.story.advanceTo(NarrativePhase.MOM_SCREAM)
        w.state.story.advanceTo(NarrativePhase.PLUSH_UNLOCKED)
    }

    @Test
    fun motherRoomHasAProceduralWindowThatBreaksAfterTheScream() {
        val def = HouseDefinition.create()
        val windows = def.segment(MOM).objects.filterIsInstance<ProceduralWindow>()
        assertEquals(1, windows.size)
        assertTrue(def.pointsOfInterest.has(Poi.MOTHER_WINDOW))

        val before = World(MOM, "from_hall")
        val win = before.scene.currentSegment.objects.filterIsInstance<ProceduralWindow>().first()
        assertFalse(win.broken)
        assertFalse(win.coldLight.active)

        val w = World(MOM, "from_hall")
        nightPassed(w)
        w.scene.loadSegment(MOM, "from_hall", w.state)
        val win2 = w.scene.currentSegment.objects.filterIsInstance<ProceduralWindow>().first()
        assertTrue(win2.broken)
        assertTrue("luz fría coherente con el hueco", win2.coldLight.active)
        val figures = w.scene.currentSegment.objects.filterIsInstance<StoryGate>()
        assertTrue("mamá, el charco, la cama revuelta y la nota dependen del estado", figures.size >= 4)
        // mamá ya no está: queda solo lo que aparece tras el grito
        assertTrue(figures.any { it.visible })
        assertTrue(figures.any { !it.visible })
    }

    @Test
    fun rainIsGeneratedByTheEngineAndFallsOnlyThroughTheBrokenWindow() {
        val w = World(MOM, "from_hall")
        val overlay = w.scene.currentSegment.objects.filterIsInstance<WindowRainOverlay>().first()
        var splashes = 0
        w.step(120)
        assertEquals("ventana entera: no entra lluvia", 0, overlay.rain.splashCount)

        nightPassed(w)
        w.scene.loadSegment(MOM, "from_hall", w.state)
        repeat(240) {
            w.step()
            if (overlay.rain.splashCount > splashes) splashes = overlay.rain.splashCount
            assertTrue(overlay.rain.allInside())
        }
        assertTrue("hay salpicaduras en el suelo", splashes > 0)
    }

    @Test
    fun rainFieldIsDeterministicAndBounded() {
        val a = RainField(12, 100f, 140f, 50f, 140f, 12f, 160f, true, 77)
        val b = RainField(12, 100f, 140f, 50f, 140f, 12f, 160f, true, 77)
        val la = FloatArray(12 * 4)
        val lb = FloatArray(12 * 4)
        repeat(90) { a.update(1f / 60f); b.update(1f / 60f) }
        assertEquals(12 * 4, a.lines(la))
        b.lines(lb)
        assertTrue(la.contentEquals(lb))
        assertTrue(a.allInside())
        for (i in 0 until 12) {
            val y1 = la[i * 4 + 1]
            val y2 = la[i * 4 + 3]
            assertTrue("las gotas caen", y2 > y1)
        }
    }

    // ------------------------------------------------------------------ 9. la nota

    @Test
    fun theNoteCanBeReadAndRecordsTheNarrativeEvent() {
        assertEquals("Me fui al hospital, deberías alcanzarme!", Documents.momNote.handwritten)
        assertEquals(Documents.MOM_NOTE, Documents.get(Documents.MOM_NOTE)?.id)
        assertEquals("sigue habiendo tres documentos de rutina", 3, Documents.ALL.size)

        val w = World(MOM, "from_hall")
        nightPassed(w)
        w.scene.loadSegment(MOM, "from_hall", w.state)
        w.scene.dialogue.clear()
        val note = w.scene.definition.pointsOfInterest.require(Poi.MOTHER_NOTE)
        w.standCenterAt(note.x)
        assertEquals(Poi.MOTHER_NOTE, w.scene.focused?.interactionId)
        assertEquals("LEER", w.input.actionLabel)
        assertFalse(w.state.story.has(StoryFlags.MOM_NOTE_READ))
        w.pressAction()
        assertEquals(Documents.MOM_NOTE, w.scene.reading?.id)
        assertTrue(w.state.story.has(StoryFlags.MOM_NOTE_READ))
        assertTrue(w.scene.events.wasPosted(EventType.ON_DOCUMENT_READ, Documents.MOM_NOTE))
        assertEquals(NarrativePhase.MOM_NOTE_READ, w.state.story.phase)
    }

    @Test
    fun enteringMotherRoomIsDiscoveredOnlyAfterTheNight() {
        val early = World(KID, "start")
        early.scene.loadSegment(MOM, "from_hall", early.state)
        assertEquals(NarrativePhase.INITIAL_ROUTINE, early.state.story.phase)

        val w = World(KID, "start")
        nightPassed(w)
        w.scene.loadSegment(MOM, "from_hall", w.state)
        assertEquals(NarrativePhase.MOTHER_ROOM_DISCOVERED, w.state.story.phase)
        assertTrue(w.state.story.has(StoryFlags.MOTHER_ROOM_DISCOVERED))
    }

    // ------------------------------------------------------------------ 10. la criatura

    private fun readNote(w: World) {
        w.scene.loadSegment(MOM, "from_hall", w.state)
        w.scene.dialogue.clear()
        w.standCenterAt(w.scene.definition.pointsOfInterest.require(Poi.MOTHER_NOTE).x)
        w.pressAction()
        w.step(30)
        w.pressAction()            // cierra el documento
        w.finishDialogue()
    }

    @Test
    fun creatureDoesNotAppearBeforeTheNoteIsRead() {
        val w = World(KID, "start")
        nightPassed(w)
        val trig = w.scene.definition.pointsOfInterest.require(Poi.HALLWAY_CREATURE_TRIGGER)
        w.scene.loadSegment(HALL, HouseDefinition.fromSpawn(MOM), w.state)
        w.scene.dialogue.clear()
        w.standCenterAt(trig.x)
        w.step(60 * 10)
        assertNull(w.scene.creature)
        assertEquals(CreatureIntro.Phase.LOCKED, w.scene.narrative.creatureIntro.phase)
        assertFalse(w.state.story.has(StoryFlags.CREATURE_INTRO_UNLOCKED))
    }

    @Test
    fun noteUnlocksTheIntroAndTheHallwayTriggerPlaysAReveal() {
        val w = World(KID, "start")
        nightPassed(w)
        readNote(w)
        assertEquals(CreatureIntro.Phase.LOCKED, w.scene.narrative.creatureIntro.phase)
        assertNull(w.scene.creature)
        w.step(60 * 4)
        assertEquals(NarrativePhase.CREATURE_INTRO_UNLOCKED, w.state.story.phase)
        assertEquals(CreatureIntro.Phase.WAITING, w.scene.narrative.creatureIntro.phase)

        var captures = 0
        w.scene.events.subscribe(EventType.CREATURE_CAPTURE) { captures++ }
        val trig = w.scene.definition.pointsOfInterest.require(Poi.HALLWAY_CREATURE_TRIGGER)
        w.scene.loadSegment(HALL, HouseDefinition.fromSpawn(MOM), w.state)
        w.scene.dialogue.clear()
        assertNull("en cuanto el niño entra al pasillo aún no aparece", w.scene.creature)
        w.standCenterAt(trig.x)
        w.step(2)
        assertNotNull("el trigger del pasillo la hace aparecer", w.scene.creature)
        assertTrue(w.scene.narrative.creatureIntro.active)
        var sawLook = false
        var steps = 0
        while (w.scene.narrative.creatureIntro.phase != CreatureIntro.Phase.DONE && steps < 60 * 40) {
            val c = w.scene.creature
            if (c != null) {
                assertEquals("no es una persecución", CreatureState.PATROL, c.state)
                if (w.scene.narrative.creatureIntro.phase == CreatureIntro.Phase.LOOK) sawLook = true
            }
            w.step()
            steps++
        }
        assertTrue(sawLook)
        assertEquals(0, captures)
        assertFalse(w.scene.capture.active)
        assertNull("desaparece de la vista", w.scene.creature)
        assertTrue(w.state.story.has(StoryFlags.CREATURE_INTRO_DONE))
        assertTrue("queda preparado el survival de 0.10", w.state.story.has(StoryFlags.SURVIVAL_READY))
        assertEquals(NarrativePhase.SURVIVAL_READY, w.state.story.phase)
    }

    @Test
    fun theOldPuzzleHookNoLongerStartsTheCreaturePatrol() {
        val w = World(MOM, "from_hall")
        w.completePuzzle()
        assertFalse(w.state.story.has(StoryFlags.CREATURE_ACTIVE))
        w.scene.loadSegment(HALL, HouseDefinition.fromSpawn(MOM), w.state)
        assertNull(w.scene.creature)
    }

    // ------------------------------------------------------------------ 12-13. arquitectura

    @Test
    fun phasesNeverGoBackwardsAndAreStoredAsFlags() {
        val s = StoryState()
        assertEquals(NarrativePhase.INITIAL_ROUTINE, s.phase)
        assertTrue(s.advanceTo(NarrativePhase.MOM_SCREAM))
        assertFalse(s.advanceTo(NarrativePhase.MEDICINE_COMPLETED))
        assertFalse(s.advanceTo(NarrativePhase.MOM_SCREAM))
        assertEquals(NarrativePhase.MOM_SCREAM, s.phase)
        assertTrue(s.has(NarrativePhase.MOM_SCREAM.flag))
        assertTrue(s.isAtLeast(NarrativePhase.SLEEP_SEQUENCE))
    }

    @Test
    fun theSequenceFollowsTheBedPointOfInterestInsteadOfFixedCoordinates() {
        val base = HouseDefinition.create()
        val moved = ArrayList<PointOfInterest>()
        for (id in base.pointsOfInterest.ids) {
            val p = base.pointsOfInterest.require(id)
            moved.add(if (id == Poi.CHILD_BED) PointOfInterest(p.id, p.segmentId, p.x - 40f, p.width, p.rise) else p)
        }
        val def = SceneDefinition(
            base.id, base.seed, base.segments, base.startSegmentId, base.startSpawnId, base.triggers, base.scripts,
            base.traumaSegments, base.conversations, base.creature, PointsOfInterest(moved)
        )
        val bed = def.pointsOfInterest.require(Poi.CHILD_BED)
        val w = World(KID, "start", object : Scene(def) {})
        w.completePuzzle()
        var lieX = -1f
        runNight(w) {
            if (w.scene.narrative.bedtime.phase == BedtimeSequence.Phase.REST) lieX = w.scene.player.centerX
        }
        assertTrue(lieX > 0f)
        assertEquals(BedGeometry.lieFeetX(bed), lieX, 1f)
        val original = HouseDefinition.create().pointsOfInterest.require(Poi.CHILD_BED)
        assertNotEquals(BedGeometry.lieFeetX(original), lieX, 5f)
    }

    @Test
    fun narrativeLogicHasNoRoomNamesOrHouseReferences() {
        val files = listOf(
            "scene/NarrativeDirector.kt", "story/BedtimeSequence.kt", "story/CreatureIntro.kt"
        )
        for (f in files) {
            val file = listOf(
                java.io.File("src/main/java/com/terror2d/$f"),
                java.io.File("app/src/main/java/com/terror2d/$f")
            ).firstOrNull { it.exists() } ?: return
            val text = file.readText()
            for (banned in listOf("KidRoom", "MomRoom", "\"Hall\"", "HouseDefinition")) {
                assertFalse("$f no debe nombrar '$banned'", text.contains(banned))
            }
        }
    }

    @Test
    fun houseDefinesEveryPointOfInterestTheStoryNeeds() {
        val pois = HouseDefinition.create().pointsOfInterest
        for (id in listOf(
            Poi.CHILD_BEDROOM, Poi.CHILD_BED, Poi.MOTHER_BEDROOM, Poi.MOTHER_BED, Poi.MOTHER_WINDOW, Poi.MOTHER_NOTE,
            Poi.HALLWAY_CREATURE_TRIGGER, Poi.HALLWAY_CREATURE_STAGE
        )) assertTrue("falta $id", pois.has(id))
        val def = HouseDefinition.create()
        assertNotNull(def.routeDoor(MOM, KID))
        assertNull(def.routeDoor(KID, KID))
    }

    // ------------------------------------------------------------------ secuencias puras

    @Test
    fun bedtimeSequenceTimelineIsOrderedAndScreamsOnce() {
        val s = BedtimeSequence()
        s.start()
        val order = ArrayList<BedtimeSequence.Phase>()
        var screams = 0
        var crashes = 0
        var n = 0
        while (!s.isDone && n < 60 * 60) {
            if (order.isEmpty() || order.last() != s.phase) order.add(s.phase)
            s.update(1f / 60f, true, true)
            if (s.takeScream()) screams++
            if (s.takeCrash()) crashes++
            n++
        }
        assertEquals(1, screams)
        assertEquals(1, crashes)
        assertEquals(BedtimeSequence.Phase.SAY, order.first())
        assertEquals(BedtimeSequence.Phase.WAKE, order.last())
        assertFalse(s.takeScream())
        assertEquals(0f, s.blackAlpha, 0f)
    }

    @Test
    fun creatureIntroIsScriptedAndNeverChases() {
        val ci = CreatureIntro()
        ci.begin(850f, 750f, 890f)
        assertEquals(CreatureIntro.Phase.LOCKED, ci.phase)
        ci.unlock()
        ci.begin(850f, 750f, 890f)
        assertTrue(ci.active)
        var x = 850f
        var looked = false
        var n = 0
        while (ci.phase != CreatureIntro.Phase.DONE && n < 60 * 60) {
            ci.update(1f / 60f, x, 640f)
            if (ci.phase == CreatureIntro.Phase.LOOK) {
                looked = true
                assertTrue(ci.gaze)
                assertEquals(-1f, ci.facing, 0f)
            }
            val dx = ci.goalX - x
            val step = minOf(ci.speed / 60f, abs(dx))
            x += if (dx > 0f) step else -step
            n++
        }
        assertTrue(looked)
        assertEquals(CreatureIntro.Phase.DONE, ci.phase)
    }

    // ------------------------------------------------------------------ audio

    private class RecordingAudio : AudioPort {
        val calls = ArrayList<String>()
        override fun playVoice(voice: VoiceId, emotion: Emotion, intensity: Float, kind: VoiceKind, units: Int, seed: Int) {}
        override fun playSfx(sfx: SfxId, intensity: Float, surface: Surface) { calls.add("sfx:$sfx") }
        override fun playMusic(music: MusicId, fadeSeconds: Float) { calls.add("music:$music") }
        override fun setAmbience(ambience: AmbienceId, fadeSeconds: Float) { calls.add("ambience:$ambience") }
        override fun setWorld(mode: WorldMode) {}
        override fun duck(level: Float, seconds: Float) { calls.add("duck:$level") }
        override fun stopAll() {}
    }

    @Test
    fun audioDirectorMapsTheNightToProceduralAudioEvents() {
        val a = RecordingAudio()
        val d = AudioDirector(a) { Surface.WOOD }
        d.onEvent(GameEvent(EventType.CHILD_CLIMBS_BED, "b", "s"))
        d.onEvent(GameEvent(EventType.CHILD_LIES_DOWN, "b", "s"))
        d.onEvent(GameEvent(EventType.SLEEP_FADE_STARTED, "b", "s"))
        d.onEvent(GameEvent(EventType.MOM_SCREAM, "m", "s"))
        d.onEvent(GameEvent(EventType.WINDOW_CRASH, "w", "s"))
        d.onEvent(GameEvent(EventType.WEATHER_CHANGED, "STORM_INSIDE", "s"))
        d.onEvent(GameEvent(EventType.CREATURE_INTRO_STARTED, "creature", "s"))
        for (c in listOf("sfx:BED_CLIMB", "sfx:BED_SETTLE", "sfx:MOM_SCREAM", "sfx:WINDOW_CRASH", "sfx:CREATURE_REVEAL",
            "ambience:SILENT", "ambience:STORM", "music:SILENCE", "music:TENSION")) assertTrue("falta $c", a.calls.contains(c))
        assertTrue(a.calls.any { it.startsWith("duck:") })
    }

    private fun engine(): AudioEngine = AudioEngine(OfflineAudioSink(), 44100, 11).also { it.enableOfflineMode() }

    private fun renderEnergy(e: AudioEngine, blocks: Int): Float {
        val buf = FloatArray(AudioEngine.BLOCK)
        var s = 0.0
        var n = 0
        for (b in 0 until blocks) {
            e.renderBlock(buf, AudioEngine.BLOCK)
            if (b > blocks / 2) for (x in buf) { assertTrue(x.isFinite()); s += x * x; n++ }
        }
        return (s / n.coerceAtLeast(1)).toFloat()
    }

    @Test
    fun stormAmbienceIsProceduralAndStrongerThanTheCalmHouse() {
        val house = engine()
        house.setAmbience(AmbienceId.HOUSE, 0.1f)
        val calm = renderEnergy(house, 400)
        val storm = engine()
        storm.setAmbience(AmbienceId.STORM, 0.1f)
        val loud = renderEnergy(storm, 400)
        assertTrue(loud > 0f)
        assertTrue("la lluvia y el viento se oyen más que la casa en calma", loud > calm)
        val far = engine()
        far.setAmbience(AmbienceId.STORM_FAR, 0.1f)
        assertTrue(renderEnergy(far, 400) > 0f)
    }

    @Test
    fun screamIsAnInHouseSoundWithAnAudibleBody() {
        val e = engine()
        e.playSfx(SfxId.MOM_SCREAM, 1f, Surface.WOOD)
        val buf = FloatArray(AudioEngine.BLOCK)
        var peak = 0f
        for (b in 0 until 200) {
            e.renderBlock(buf, AudioEngine.BLOCK)
            for (x in buf) { assertTrue(x.isFinite()); if (abs(x) > peak) peak = abs(x) }
        }
        assertTrue(peak > 0.01f)
    }
}
