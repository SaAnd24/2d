package com.terror2d.chapter.mech

import com.terror2d.audio.SfxId

/**
 * N2 — El horario que nadie escribió. Habitación de mamá: ventana, cortina con lamas, taza y reloj de mesita.
 *  - La CORTINA se abre / cierra arrastrando su cordón. Las LAMAS se inclinan arrastrando la varilla.
 *  - El RELOJ gira con un gesto circular (o con los botones ◀ ▶): la hora decide dónde cae el rayo de sol.
 *  - El rayo (si hay abertura) cae en (x(hora), y(lamas)). Tres marcas de lápiz en la habitación son las tres fases
 *    de D03 EN ORDEN: la cortina, la taza (ya fría) y el mueble del pasillo oscuro. Cada marca se corresponde con
 *    una hora marcada a lápiz en la esfera (las 8, las 10 y las 2).
 *  - Una fase solo se registra si es la SIGUIENTE y el rayo se sostiene sobre su marca (no basta con pasar rápido).
 *    Acertar una fase da una reacción parcial; no completa el puzle. Ambiental: ninguna hora médica.
 */
class RoutineMech : Mechanism("N2") {

    /** 0 = cortina cerrada, 1 = abierta. */
    var curtain = 0.15f
    /** -1 = lamas hacia abajo, +1 = hacia arriba. */
    var tilt = 0f
    /** Hora de la esfera en vueltas de 12 (0..12). */
    var hour = 5.0f

    val done = BooleanArray(3)
    val phase: Int get() = done.count { it }
    private var hold = 0f
    private var holdIdx = -1
    private var drag = 0 // 1 cordón, 2 varilla, 3 reloj
    private var lastTickHour = -1
    private var orderCool = 0f

    val beamOn: Boolean get() = curtain >= 0.35f
    val beamX: Float get() = 40f + (hour / 12f) * 240f
    val beamY: Float get() = 130f - (tilt + 1f) * 35f

    /** Cuánto se acerca el rayo a una marca (0..1) para el destello de aproximación. */
    fun nearness(k: Int): Float {
        if (!beamOn) return 0f
        val d = dist(beamX, beamY, MARK_X[k], MARK_Y[k])
        return if (d >= 36f) 0f else 1f - d / 36f
    }

    private fun onMark(k: Int): Boolean =
        beamOn && kotlin.math.abs(beamX - MARK_X[k]) <= TOL_X && kotlin.math.abs(beamY - MARK_Y[k]) <= TOL_Y

    override fun onDown(x: Float, y: Float) {
        drag = 0
        // botones de ayuda táctil
        if (hit(x, y, 214f, 150f, 12f)) { applyCurtain(curtain - 0.12f); return }
        if (hit(x, y, 258f, 150f, 12f)) { applyCurtain(curtain + 0.12f); return }
        if (hit(x, y, 300f, 122f, 12f)) { applyTilt(tilt + 0.16f); return }
        if (hit(x, y, 300f, 146f, 12f)) { applyTilt(tilt - 0.16f); return }
        if (hit(x, y, 116f, 164f, 11f)) { applyHour(hour - 0.5f); return }
        if (hit(x, y, 184f, 164f, 11f)) { applyHour(hour + 0.5f); return }
        if (dist(x, y, CLOCK_X, CLOCK_Y) <= 30f) { drag = 3; return }
        if (x in 186f..290f && y in 98f..128f) { drag = 1; onMove(x, y, 0f, 0f); return }
        if (x >= 278f && y in 20f..110f) { drag = 2; onMove(x, y, 0f, 0f); return }
    }

    private fun hit(x: Float, y: Float, cx: Float, cy: Float, r: Float) = dist(x, y, cx, cy) <= r

    override fun onMove(x: Float, y: Float, dx: Float, dy: Float) {
        when (drag) {
            1 -> applyCurtain((x - 196f) / 80f)
            2 -> applyTilt(-(y - 63f) / 37f)
            3 -> {
                val a = angleOf(CLOCK_X, CLOCK_Y, x, y)
                var h = ((a + 90f) / 30f)
                if (h < 0f) h += 12f
                // sigue la mano por el camino más corto (sin saltos de 12 a 0)
                var d = h - hour
                while (d > 6f) d -= 12f
                while (d < -6f) d += 12f
                applyHour(hour + d)
            }
        }
    }

    override fun onUp(x: Float, y: Float) { drag = 0 }

    private fun applyCurtain(v: Float) {
        val n = v.coerceIn(0f, 1f)
        if (kotlin.math.abs(n - curtain) > 0.02f) play(SfxId.MECH_WOOD_SLIDE, 0.2f)
        curtain = n
    }

    private fun applyTilt(v: Float) {
        val n = v.coerceIn(-1f, 1f)
        if (kotlin.math.abs(n - tilt) > 0.05f) play(SfxId.MECH_WOOD_CLICK, 0.18f)
        tilt = n
    }

    private fun applyHour(v: Float) {
        var h = v % 12f
        if (h < 0f) h += 12f
        hour = h
        val q = (h * 2f).toInt()
        if (q != lastTickHour) {
            lastTickHour = q
            play(SfxId.MECH_CLOCK_TICK, 0.35f) // pequeños clics mecánicos de la maquinaria
        }
    }

    override fun update(dt: Float) {
        if (orderCool > 0f) orderCool -= dt
        var onIdx = -1
        for (k in 0 until 3) if (onMark(k)) onIdx = k
        if (onIdx >= 0 && drag != 0 || onIdx >= 0 && !pointerDown) {
            if (onIdx == holdIdx) hold += dt else { holdIdx = onIdx; hold = 0f }
            if (hold >= 0.8f && !solved) {
                if (onIdx == phase && !done[onIdx]) {
                    done[onIdx] = true
                    hold = 0f
                    play(SfxId.MECH_CLOCK_TICK, 0.7f)
                    play(if (onIdx == 1) SfxId.MECH_CERAMIC else SfxId.MECH_WOOD_CLICK, 0.5f)
                    say(PHASE_TEXT[onIdx], 3.4f)
                } else if (onIdx > phase && orderCool <= 0f) {
                    // la marca es buena, pero la rutina no ha llegado hasta aquí: el reloj se atasca un instante
                    orderCool = 2.5f
                    play(SfxId.MECH_CLOCK_TICK, 0.5f)
                    mistake("Esto todavía no toca. Antes pasa otra cosa.")
                }
            }
        } else {
            holdIdx = -1
            hold = 0f
        }
        if (!solved && done[0] && done[1] && done[2]) {
            markSolved()
            later(0.8f, SfxId.MECH_WOOD_SLIDE, 0.7f)
            later(1.6f, SfxId.MECH_WOOD_CLICK, 0.6f)
            later(2.2f, SfxId.PUZZLE_SOLVED, 0.6f)
        }
    }

    /** 0..1 de apertura del cajón de la cómoda tras resolverlo. */
    val drawerOpen: Float get() = if (!solved) 0f else ((solvedTime - 0.6f) / 2.4f).coerceIn(0f, 1f)

    override fun solvedHold(): Float = 3.4f

    companion object {
        const val CLOCK_X = 150f
        const val CLOCK_Y = 146f
        val MARK_X = floatArrayOf(200f, 240f, 80f)
        val MARK_Y = floatArrayOf(70f, 112f, 122f)
        const val TOL_X = 12f
        const val TOL_Y = 11f
        /** Horas marcadas a lápiz en la esfera: 8, 10 y 2. */
        val CLOCK_TICKS = floatArrayOf(8f, 10f, 2f)
        val PHASE_TEXT = arrayOf(
            "La luz llega a la cortina. El borde queda alineado.",
            "La taza ya no está caliente: el reflejo del café ha cambiado.",
            "Y el pasillo se queda oscuro."
        )
    }
}
