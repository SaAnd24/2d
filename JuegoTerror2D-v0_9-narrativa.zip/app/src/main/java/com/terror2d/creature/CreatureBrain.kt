package com.terror2d.creature

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class CreatureState { PATROL, INVESTIGATE, CHASE, LOST_TARGET, RETURN_TO_PATROL }

/** Intervalo X que la criatura no puede cruzar (hueco pequeño, ventilación). [blocksSight] = false: se ve a través. */
class Blocker(val x0: Float, val x1: Float, val blocksSight: Boolean)

/** Lo que la criatura puede saber en cada paso: nada de «posición mágica» del niño salvo lo que ve. */
class Senses(
    var playerX: Float = 0f,
    var playerSegmentId: String = "",
    var playerHidden: Boolean = false,
    /** Brillo de la luz sobre el niño (0 = oscuridad, 1 = iluminado). */
    var playerLight: Float = 1f,
    var blockers: List<Blocker> = emptyList(),
    var now: Float = 0f
)

/**
 * Cerebro de la criatura en vista lateral (1 eje). Máquina de estados PATROL → INVESTIGATE → CHASE →
 * LOST_TARGET → RETURN_TO_PATROL. Determinista (sin azar por frame) y barato: la IA corre a [AI_STEP].
 */
class CreatureBrain(
    var x: Float,
    val segmentId: String,
    private val patrolMin: Float,
    private val patrolMax: Float,
    private val seed: Int = 1
) {
    var state = CreatureState.PATROL
        private set
    var facing = 1f
        private set
    var speed = 0f
        private set
    /** 0..1: intensidad (respiración, bocas, música). Sube rápido al ver al niño y baja despacio. */
    var arousal = 0.15f
        private set
    var lastKnownX = x
        private set
    var targetX = x
        private set
    var captured = false
        private set

    private var timer = 0f
    private var lostTimer = 0f
    private var patrolIdx = 0
    private var aiAcc = 0f
    private var lookDir = 1f

    fun update(dt: Float, s: Senses, noises: List<NoiseEvent>) {
        if (captured) { speed = 0f; return }
        aiAcc += dt
        if (aiAcc >= AI_STEP) { think(aiAcc, s, noises); aiAcc = 0f }
        move(dt, s)
        val goal = when (state) {
            CreatureState.CHASE -> 1f
            CreatureState.LOST_TARGET -> 0.7f
            CreatureState.INVESTIGATE -> 0.45f
            else -> 0.15f
        }
        val rate = if (goal > arousal) 2.5f else 0.25f   // sube de golpe, baja gradualmente
        arousal += (goal - arousal) * min(1f, rate * dt)
    }

    private fun think(dt: Float, s: Senses, noises: List<NoiseEvent>) {
        val sees = canSee(s)
        if (sees) {
            lastKnownX = s.playerX
            lostTimer = 0f
            if (state != CreatureState.CHASE) { state = CreatureState.CHASE; timer = 0f }
            targetX = s.playerX
            if (s.playerSegmentId == segmentId && abs(s.playerX - x) < CAPTURE_RANGE && !s.playerHidden) captured = true
            return
        }
        if (state == CreatureState.CHASE) {
            lostTimer += dt
            targetX = lastKnownX
            if (lostTimer > LOSE_DELAY || stuckBehindBlocker(s)) { state = CreatureState.LOST_TARGET; timer = 0f }
            return
        }
        // oído: solo cambia de PATROL / RETURN / INVESTIGATE; durante la búsqueda cercana reacciona al ruido más fuerte
        var best: NoiseEvent? = null
        var bestI = 0f
        for (n in noises) {
            if (n.segmentId != segmentId) continue
            val i = Hearing.perceivedIntensity(n, x)
            if (i >= Hearing.THRESHOLD && i > bestI) { best = n; bestI = i }
        }
        if (best != null && (state != CreatureState.INVESTIGATE || bestI > 0.3f)) {
            targetX = Hearing.perceivedX(best, x, seed).coerceIn(patrolMin, patrolMax)
            state = CreatureState.INVESTIGATE
            timer = 0f
        }
        timer += dt
        when (state) {
            CreatureState.INVESTIGATE -> if (arrived()) {
                lookAround(dt)
                if (timer > INVESTIGATE_TIME) { state = CreatureState.LOST_TARGET; timer = 0f; targetX = x }
            }
            CreatureState.LOST_TARGET -> {
                if (arrived()) lookAround(dt)
                if (timer > LOST_TIME) { state = CreatureState.RETURN_TO_PATROL; timer = 0f; targetX = nearestPatrolPoint() }
            }
            CreatureState.RETURN_TO_PATROL -> if (arrived()) { state = CreatureState.PATROL; timer = 0f; patrolIdx = nearestIdx() }
            CreatureState.PATROL -> {
                if (arrived()) {
                    // pausa para mirar alrededor y siguiente punto
                    lookAround(dt)
                    if (timer > 1.5f + 2f * Det.hash01(seed, patrolIdx)) {
                        patrolIdx = (patrolIdx + 1) % PATROL_POINTS
                        targetX = patrolPoint(patrolIdx)
                        timer = 0f
                    }
                } else timer = 0f
            }
            else -> {}
        }
    }

    private fun lookAround(dt: Float) {
        lookTimer += dt
        if (lookTimer > 1.1f) { lookTimer = 0f; lookDir = -lookDir; facing = lookDir }
    }
    private var lookTimer = 0f

    private fun move(dt: Float, s: Senses) {
        val sp = when (state) {
            CreatureState.CHASE -> CHASE_SPEED
            CreatureState.INVESTIGATE -> INVESTIGATE_SPEED
            CreatureState.LOST_TARGET -> LOST_SPEED
            CreatureState.RETURN_TO_PATROL -> PATROL_SPEED * 1.2f
            CreatureState.PATROL -> PATROL_SPEED
        }
        val dx = targetX - x
        if (abs(dx) < ARRIVE) { speed = 0f; return }
        val dir = if (dx > 0) 1f else -1f
        facing = dir
        var step = min(sp * dt, abs(dx))
        var nx = x + dir * step
        for (b in s.blockers) {
            // el cuerpo grande no cabe: se detiene en el borde del hueco
            if (dir > 0 && x + HALF_BODY <= b.x0 && nx + HALF_BODY > b.x0) nx = b.x0 - HALF_BODY
            if (dir < 0 && x - HALF_BODY >= b.x1 && nx - HALF_BODY < b.x1) nx = b.x1 + HALF_BODY
        }
        nx = nx.coerceIn(patrolMin, patrolMax)
        step = abs(nx - x)
        speed = if (dt > 0f) step / dt else 0f
        x = nx
    }

    private fun stuckBehindBlocker(s: Senses): Boolean {
        for (b in s.blockers) {
            val edge = if (facing > 0) b.x0 - HALF_BODY else b.x1 + HALF_BODY
            if (abs(x - edge) < 1f && ((facing > 0 && s.playerX > b.x0) || (facing < 0 && s.playerX < b.x1))) return true
        }
        return false
    }

    /** Visión: mismo segmento, distancia (reducida por oscuridad), campo de visión, sin obstáculos opacos, sin armario. */
    fun canSee(s: Senses): Boolean {
        if (s.playerSegmentId != segmentId || s.playerHidden) return false
        val dx = s.playerX - x
        val d = abs(dx)
        val range = VISION_RANGE * (0.35f + 0.65f * s.playerLight.coerceIn(0f, 1f))
        if (d > range) return false
        val inFront = dx * facing > 0f
        if (!inFront && d > REAR_AWARENESS) return false
        val lo = min(x, s.playerX)
        val hi = max(x, s.playerX)
        for (b in s.blockers) if (b.blocksSight && b.x0 < hi && b.x1 > lo) return false
        return true
    }

    private fun arrived() = abs(targetX - x) < ARRIVE
    private fun patrolPoint(i: Int) = patrolMin + (patrolMax - patrolMin) * (i / (PATROL_POINTS - 1f))
    private fun nearestIdx(): Int {
        var bi = 0
        for (i in 0 until PATROL_POINTS) if (abs(patrolPoint(i) - x) < abs(patrolPoint(bi) - x)) bi = i
        return bi
    }
    private fun nearestPatrolPoint() = patrolPoint(nearestIdx())

    /**
     * v0.9: movimiento guionizado (primera aparición). Ignora sentidos y estados: no ve, no oye, no persigue ni captura.
     * Va hacia [goalX] a [sp] px/s y mira hacia [face] (0 = hacia donde camina).
     */
    fun scripted(dt: Float, goalX: Float, sp: Float, face: Float) {
        val dx = goalX - x
        if (sp <= 0f || abs(dx) < 0.5f) {
            speed = 0f
        } else {
            val dir = if (dx > 0f) 1f else -1f
            val step = min(sp * dt, abs(dx))
            x += dir * step
            speed = if (dt > 0f) step / dt else 0f
            if (face == 0f) facing = dir
        }
        if (face != 0f) facing = face
        arousal += (0.3f - arousal) * min(1f, dt)
    }

    /** Para la captura/escena: la devuelve a patrulla tras despertar al niño. */
    fun reset(newX: Float) {
        x = newX; captured = false; state = CreatureState.PATROL; arousal = 0.15f
        targetX = newX; timer = 0f; lostTimer = 0f; patrolIdx = nearestIdx()
    }

    companion object {
        const val AI_STEP = 1f / 15f
        const val PATROL_POINTS = 4
        const val PATROL_SPEED = 18f
        const val INVESTIGATE_SPEED = 34f
        const val LOST_SPEED = 40f
        /** Siempre mayor que Player.SPEED (68): la criatura gana en línea recta. */
        const val CHASE_SPEED = 96f
        const val HALF_BODY = 26f
        const val ARRIVE = 3f
        const val VISION_RANGE = 190f
        const val REAR_AWARENESS = 14f
        const val CAPTURE_RANGE = 24f
        const val LOSE_DELAY = 0.8f
        const val INVESTIGATE_TIME = 4f
        const val LOST_TIME = 5f
    }
}
