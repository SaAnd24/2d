package com.terror2d

import com.terror2d.chapter.ChapterFlags
import com.terror2d.chapter.PuzzleBook
import com.terror2d.chapter.mech.*
import com.terror2d.core.Depth
import org.junit.Assert.*
import org.junit.Test

/**
 * v0.17 — pruebas 2.5D de los 15 puzles del Capítulo 1. Reproducen GESTOS reales (pulsar, arrastrar, soltar)
 * sobre la lógica pura, con la profundidad correcta de cada mecanismo. Cada puzle tiene un positivo (la entrada
 * correcta resuelve) y un negativo (una entrada incorrecta NO resuelve). Escritas sin poder compilarlas ni
 * ejecutarlas en el entorno donde se hicieron (sin Kotlin/Gradle).
 *
 * Salas y profundidades (ver PuzzleBook): N1 Dining 0.60 · N2 MomRoom 0.45 · N3 KidRoom 0.60 · N4 Hall 0.30 ·
 * N5 Electric 0.30 · T1 Pantry 0.30 · T2 MomRoom 0.45 · T3 Hall 0.45 · T4 Boiler 0.50 · T5 Roof 0.70 ·
 * C1 Living 0.30 · C2 Closet 0.60 · C3 Storage 0.25 · C4 Study 0.60 · C5 Roof 0.70.
 */
class PuzzleDepthTest {

    private fun press(m: Mechanism, x: Float, y: Float) { m.feed(true, true, false, x, y); m.tick(0.016f) }
    private fun move(m: Mechanism, x: Float, y: Float) { m.feed(true, false, false, x, y); m.tick(0.016f) }
    private fun release(m: Mechanism, x: Float, y: Float) { m.feed(false, false, true, x, y); m.tick(0.016f) }
    private fun tap(m: Mechanism, x: Float, y: Float) { press(m, x, y); release(m, x, y) }
    private fun wait(m: Mechanism, s: Float) { var t = 0f; while (t < s) { m.tick(0.02f); t += 0.02f } }

    private fun drag(m: Mechanism, x0: Float, y0: Float, x1: Float, y1: Float) {
        press(m, x0, y0)
        val n = 12
        for (i in 1..n) move(m, x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n)
        release(m, x1, y1)
    }

    // ------------------------------------------------------------------ contrato 2.5D

    @Test
    fun depthScaleIsTheSingleFormula() {
        assertEquals(0.82f, Mechanism.depthScale(0f), 0.001f)
        assertEquals(0.97f, Mechanism.depthScale(0.5f), 0.001f)
        assertEquals(1.12f, Mechanism.depthScale(1f), 0.001f)
        assertEquals(Mechanism.depthScale(0.25f), Depth.depthScale(0.25f), 0.0001f)
        // fuera de rango se limita, no se sale de la escala
        assertEquals(0.82f, Mechanism.depthScale(-1f), 0.001f)
        assertEquals(1.12f, Mechanism.depthScale(2f), 0.001f)
    }

    @Test
    fun allFifteenPuzzlesHaveRoomAndDepthInRange() {
        val expected = mapOf(
            "N1" to ("Dining" to 0.60f), "N2" to ("MomRoom" to 0.45f), "N3" to ("KidRoom" to 0.60f),
            "N4" to ("Hall" to 0.30f), "N5" to ("Electric" to 0.30f), "T1" to ("Pantry" to 0.30f),
            "T2" to ("MomRoom" to 0.45f), "T3" to ("Hall" to 0.45f), "T4" to ("Boiler" to 0.50f),
            "T5" to ("Roof" to 0.70f), "C1" to ("Living" to 0.30f), "C2" to ("Closet" to 0.60f),
            "C3" to ("Storage" to 0.25f), "C4" to ("Study" to 0.60f), "C5" to ("Roof" to 0.70f)
        )
        assertEquals(15, PuzzleBook.ALL.size)
        for ((id, roomDepth) in expected) {
            val def = PuzzleBook.get(id)!!
            assertEquals("$id sala", roomDepth.first, def.room)
            assertEquals("$id profundidad", roomDepth.second, def.depth, 0.001f)
            val m = MechRegistry.create(id)!!
            assertEquals("$id mech sala", def.room, m.roomId)
            assertEquals("$id mech profundidad", def.depth, m.depth, 0.001f)
            assertTrue("$id profundidad en rango", m.depth in 0f..1f)
        }
        // orden de dibujo por profundidad: el fondo (C3) va antes que el primer plano (T5)
        val sorted = MechRendererOrderForTest.sortedByDepth(
            listOf(MechRegistry.create("T5")!!, MechRegistry.create("C3")!!, MechRegistry.create("N1")!!)
        )
        assertEquals(listOf("C3", "N1", "T5"), sorted.map { it.id })
    }

    @Test
    fun onlyC3RequiresCrouchAndOnlyC5RequiresObserveDepth() {
        for (id in MechRegistry.MIGRATED) {
            val m = MechRegistry.create(id)!!
            if (id == "C3") {
                assertEquals(MoveMode.CROUCH, m.requiredMoveMode)
                assertTrue(ChapterFlags.C3_REQUIRES_CROUCH)
            } else assertNull("$id no exige modo", m.requiredMoveMode)
            if (id == "C5") {
                assertEquals(ChapterFlags.C5_OBSERVE_DEPTH_MIN, m.observeDepthMin!!, 0.001f)
                assertEquals(0.6f, m.observeDepthMin!!, 0.001f)
            } else assertNull("$id no exige profundidad de observación", m.observeDepthMin)
        }
    }

    // ------------------------------------------------------------------ N1..N5 (positivo + negativo)

    @Test
    fun n1SolvesAtDepth060AndWrongPlacementDoesNot() {
        val m = TableMech()
        assertEquals(0.60f, m.depth, 0.001f)
        drag(m, 150f, 104f, 100f, 110f)
        drag(m, 170f, 90f, 204f, 80f)
        drag(m, 276f, 118f, 150f, 52f)
        wait(m, 0.1f)
        assertFalse(m.solved)
        drag(m, 100f, 110f, TableMech.CUP_X, TableMech.CUP_Y)
        drag(m, 204f, 80f, TableMech.PLATE_X, TableMech.PLATE_Y)
        drag(m, 150f, 52f, TableMech.CHAIR_X, TableMech.CHAIR_Y)
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun n2SolvesInOrderAtDepth045AndOutOfOrderDoesNot() {
        val m = RoutineMech()
        assertEquals(0.45f, m.depth, 0.001f)
        fun hourBtn(n: Int) { repeat(n) { tap(m, 184f, 164f) } }
        fun tilt(n: Int, up: Boolean) { repeat(n) { tap(m, 300f, if (up) 122f else 146f) } }
        repeat(2) { tap(m, 258f, 150f) }
        hourBtn(10); tilt(3, false) // fase 2 antes que la 1
        wait(m, 1.2f)
        assertFalse(m.done[1])
        assertFalse(m.solved)
        // volver a la fase 1 y hacer el orden completo: 8/cortina, 10/taza, 2/pasillo
        hourBtn(20); tilt(7, true) // hora 8 (10 + 10 = 20 -> 8), rayo alto
        wait(m, 1.1f); assertTrue(m.done[0])
        hourBtn(4); tilt(7, false) // hora 10, rayo bajo
        wait(m, 1.1f); assertTrue(m.done[1])
        hourBtn(8); tilt(2, false) // hora 2
        wait(m, 1.1f)
        assertTrue(m.solved)
    }

    @Test
    fun n3SolvesInRowOrderAtDepth060AndWrongRowDoesNot() {
        val m = DrawingsMech()
        assertEquals(0.60f, m.depth, 0.001f)
        repeat(3) { tap(m, 70f, 64f) }
        repeat(2) { tap(m, 240f, 70f) }
        tap(m, 236f, 134f)
        drag(m, 236f, 134f, 70f, 140f) // D primero: fila equivocada
        drag(m, 120f, 130f, 134f, 140f)
        drag(m, 240f, 70f, 198f, 140f)
        drag(m, 70f, 64f, 262f, 140f)
        wait(m, 0.1f)
        assertFalse(m.solved)
    }

    @Test
    fun n4FramesSettleAtDepth030() {
        val m = FramesMech()
        assertEquals(0.30f, m.depth, 0.001f)
        assertEquals("Hall", m.roomId)
        val taps = intArrayOf(-11, 6, -14, 13)
        for (i in 0 until 4) {
            val bx = m.centerX[i] + (if (taps[i] < 0) -17f else 17f)
            repeat(Math.abs(taps[i])) { tap(m, bx, FramesMech.ARROW_Y) }
            wait(m, 0.8f)
            assertTrue("marco $i", m.settled[i])
        }
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun n5WrongCableDoesNotLockAtDepth030() {
        val m = FuseBoxMech()
        assertEquals(0.30f, m.depth, 0.001f)
        drag(m, FuseBoxMech.SRC_X + 14f, FuseBoxMech.SRC_Y[0], FuseBoxMech.TERM_X, FuseBoxMech.TERM_Y[0])
        wait(m, 1.6f)
        assertEquals(0, m.lockedCount)
        assertFalse(m.solved)
        val dest = intArrayOf(2, 1, 0, 3)
        for (b in 0 until 4) {
            drag(m, FuseBoxMech.SRC_X + 14f, FuseBoxMech.SRC_Y[b], FuseBoxMech.TERM_X, FuseBoxMech.TERM_Y[dest[b]])
            assertTrue(m.isLocked(b))
        }
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    // ------------------------------------------------------------------ T1..T5

    @Test
    fun t1RhythmSolvesAtDepth030AndWrongMarkDoesNot() {
        val m = MarksMech()
        assertEquals(0.30f, m.depth, 0.001f)
        tap(m, m.markX(1), 90f) // marca corta = espera: error
        assertTrue(m.failures >= 1)
        assertFalse(m.solved)
        wait(m, 4.5f)
        tap(m, m.markX(0), 90f); wait(m, 0.84f)
        tap(m, m.markX(2), 90f); wait(m, 0.84f)
        tap(m, m.markX(4), 90f); wait(m, 0.42f)
        tap(m, m.markX(5), 90f)
        assertTrue(m.solved)
    }

    @Test
    fun t2PiecesSolveAtDepth045AndWrongHoleDoesNot() {
        val m = PortraitMech()
        assertEquals(0.45f, m.depth, 0.001f)
        repeat(3) { tap(m, 236f, 56f) }
        tap(m, 280f, 128f)
        drag(m, 236f, 56f, m.holeX[0], m.holeY[0])
        drag(m, 286f, 56f, m.holeX[1], m.holeY[1])
        drag(m, 236f, 112f, m.holeX[2], m.holeY[2])
        assertFalse(m.solved)
        drag(m, 280f, 128f, m.holeX[3], m.holeY[3])
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun t3CorridorFollowsTheCrackAtDepth045() {
        val m = CorridorMech()
        assertEquals(0.45f, m.depth, 0.001f)
        assertEquals("Hall", m.roomId)
        assertTrue(m.solution.contentEquals(intArrayOf(1, 0, 2)))
        assertEquals(0.35f, m.doorDepth(0), 0.001f)
        assertEquals(0.55f, m.doorDepth(1), 0.001f)
        assertEquals(0.75f, m.doorDepth(2), 0.001f)
        // puerta equivocada primero: vuelve al distribuidor y no resuelve
        tap(m, m.doorX(0), m.doorY(0))
        assertEquals(0, m.stage)
        assertTrue(m.failures >= 1)
        assertFalse(m.solved)
        // orden de la grieta: medio, izquierda, derecha
        tap(m, m.doorX(1), m.doorY(1))
        assertEquals(1, m.stage)
        assertFalse(m.solved)
        tap(m, m.doorX(1), m.doorY(1)) // repetir la misma: fuera de orden, vuelve a 0
        assertEquals(0, m.stage)
        tap(m, m.doorX(1), m.doorY(1))
        tap(m, m.doorX(0), m.doorY(0))
        assertEquals(2, m.stage)
        assertFalse(m.solved)
        tap(m, m.doorX(2), m.doorY(2))
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun t4ValvesLockAtDepth050() {
        val m = BoilerMech()
        assertEquals(0.50f, m.depth, 0.001f)
        val taps = intArrayOf(-5, -2, 2, 5)
        for (v in 0 until 4) {
            val bx = m.valveX[v] + (if (taps[v] < 0) -16f else 16f)
            repeat(Math.abs(taps[v])) { tap(m, bx, 153f) }
            wait(m, 1.2f)
            assertTrue("válvula $v", m.locked[v])
        }
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun t5AntennaSolvesAtDepth070AndOneArmDoesNot() {
        val m = AntennaMech()
        assertEquals(0.70f, m.depth, 0.001f)
        wait(m, 1f)
        assertFalse(m.solved)
        m.theta[0] = AntennaMech.SOLUTION[0]
        wait(m, 1.5f)
        assertFalse(m.solved)
        for (i in 0 until 3) m.theta[i] = AntennaMech.SOLUTION[i]
        wait(m, 1.5f)
        assertTrue(m.solved)
    }

    // ------------------------------------------------------------------ C1..C5

    @Test
    fun c1JointsInOrderAtDepth030() {
        val m = WallJointMech()
        assertEquals(0.30f, m.depth, 0.001f)
        fun carryTo(j: Int) {
            press(m, m.strip.x, m.strip.y)
            var guard = 0
            while (m.jointUnder() != j && guard++ < 600) {
                val dx = m.jointX[j] - m.strip.x
                val dy = m.jointY[j] - m.strip.y
                val l = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
                move(m, m.px + dx / l * 3f, m.py + dy / l * 3f)
            }
            assertEquals(j, m.jointUnder())
            wait(m, 0.8f)
            release(m, m.px, m.py)
        }
        carryTo(1)
        assertFalse(m.activated[1])
        carryTo(0); assertTrue(m.activated[0])
        carryTo(1); assertTrue(m.activated[1])
        assertFalse(m.solved)
        carryTo(2); assertTrue(m.activated[2])
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun c2BoxRightAndMarkTurnedAtDepth060() {
        val m = FootprintsMech()
        assertEquals(0.60f, m.depth, 0.001f)
        assertEquals("Closet", m.roomId)
        assertEquals(0.75f, m.boxDepth, 0.001f)
        assertEquals(0.30f, m.markDepth, 0.001f)
        // empujar a la izquierda: no resuelve, aunque la marca esté girada
        drag(m, m.box.x, m.box.y, m.box.x - 60f, m.box.y)
        assertEquals(0, m.push)
        assertTrue(m.failures >= 1)
        tap(m, m.markX, m.markY)
        tap(m, m.markX, m.markY)
        assertEquals(2, m.markRot)
        wait(m, 0.1f)
        assertFalse(m.solved)
        // empujar a la derecha con la marca girada: resuelve
        drag(m, m.box.x, m.box.y, m.box.x + 90f, m.box.y)
        assertEquals(1, m.push)
        assertTrue(m.pushOk)
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun c2RightPushButVerticalMarkDoesNotSolve() {
        val m = FootprintsMech()
        drag(m, m.box.x, m.box.y, m.box.x + 90f, m.box.y)
        assertEquals(1, m.push)
        assertEquals(0, m.markRot)
        wait(m, 0.1f)
        assertFalse(m.solved)
    }

    @Test
    fun c3ThirdPanelAtTheBackAtDepth025() {
        val m = PanelsMech()
        assertEquals(0.25f, m.depth, 0.001f)
        assertEquals("Storage", m.roomId)
        assertEquals(MoveMode.CROUCH, m.requiredMoveMode)
        // al entrar se mira a la izquierda: tocar la zona de un panel solo gira la vista al fondo, no abre nada
        tap(m, m.panelX(2), m.panelY(2))
        assertEquals(1, m.facing)
        assertFalse(m.solved)
        assertEquals(-1, m.openPanel)
        // ya encarando el fondo, tocar un panel equivocado: no resuelve
        assertTrue(m.panelsVisible)
        tap(m, m.panelX(0), m.panelY(0))
        assertTrue(m.failures >= 1)
        assertFalse(m.solved)
        tap(m, m.panelX(3), m.panelY(3))
        assertFalse(m.solved)
        // tercer panel contando desde la izquierda: resuelve
        tap(m, m.panelX(2), m.panelY(2))
        assertEquals(2, m.openPanel)
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun c3PanelsBlockedWhenStanding() {
        val m = PanelsMech()
        m.playerMoveMode = MoveMode.WALK
        assertFalse(m.canReachPanels)
        tap(m, 160f, 100f) // encarar el fondo
        tap(m, m.panelX(2), m.panelY(2))
        assertFalse(m.solved)
        m.playerMoveMode = MoveMode.CROUCH
        assertTrue(m.canReachPanels)
        tap(m, m.panelX(2), m.panelY(2))
        assertTrue(m.solved)
    }

    @Test
    fun c4LetterNeedsBothWorldsAtDepth060() {
        val m = LetterMech()
        assertEquals(0.60f, m.depth, 0.001f)
        repeat(3) { tap(m, m.a.x - 10f, m.a.y) }
        repeat(4) { tap(m, m.b.x + 10f, m.b.y) }
        assertTrue(m.uprightBoth())
        drag(m, 228f, 110f, 192f, 96f)
        assertTrue(m.aligned)
        m.trauma = false
        wait(m, 1.3f)
        assertFalse(m.solved)
        m.trauma = true
        wait(m, 1.3f)
        assertTrue(m.solved)
    }

    @Test
    fun c5SignalsInOrderAtDepth070() {
        val m = SignalsMech()
        assertEquals(0.70f, m.depth, 0.001f)
        assertEquals("Roof", m.roomId)
        assertTrue(m.def.solution.contentEquals(intArrayOf(2, 0, 1)))
        // orden equivocado: luz arriba, sombra en medio, espejo abajo
        drag(m, m.tokens[0].x, m.tokens[0].y, m.slotX(0), m.slotY(0))
        drag(m, m.tokens[2].x, m.tokens[2].y, m.slotX(1), m.slotY(1))
        drag(m, m.tokens[1].x, m.tokens[1].y, m.slotX(2), m.slotY(2))
        wait(m, 0.1f)
        assertFalse(m.solved)
        assertTrue(m.failures >= 1)
        // reordenar a la solución: primero sacar la sombra del hueco del medio, luego luz al medio y sombra arriba
        drag(m, m.tokens[2].x, m.tokens[2].y, 160f, 90f)
        assertEquals(-1, m.slotOf(2))
        drag(m, m.tokens[0].x, m.tokens[0].y, m.slotX(1), m.slotY(1))
        assertEquals(1, m.slotOf(0))
        drag(m, m.tokens[2].x, m.tokens[2].y, m.slotX(0), m.slotY(0))
        assertEquals(0, m.slotOf(2))
        assertEquals(2, m.slotOf(1)) // el espejo ya estaba abajo
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun c5TokenDroppedFarAwayReturnsHome() {
        val m = SignalsMech()
        drag(m, m.tokens[2].x, m.tokens[2].y, 160f, 90f)
        assertEquals(-1, m.slotOf(2))
        assertEquals(SignalsMech.TOKEN_X, m.tokens[2].x, 0.01f)
        assertFalse(m.solved)
    }

    /** Orden de capas sin depender del renderer de Android (la lógica es la misma que MechRenderer.sortedByDepth). */
    private object MechRendererOrderForTest {
        fun sortedByDepth(mechs: List<Mechanism>): List<Mechanism> = mechs.sortedBy { it.depth }
    }
}
