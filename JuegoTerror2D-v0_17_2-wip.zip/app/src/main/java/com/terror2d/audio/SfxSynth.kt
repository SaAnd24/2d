package com.terror2d.audio

/**
 * Efectos de sonido procedurales. Cada recibo es una receta corta de voces (tonos, golpes de ruido filtrado) con
 * pequeñas variaciones aleatorias para que dos pasos nunca suenen idénticos. Sin archivos de audio.
 */
class SfxSynth(private val core: EngineCore) {

    private var stepCount = 0

    fun play(sfx: SfxId, intensity: Float, surface: Surface) {
        val g = intensity.coerceIn(0f, 1.5f)
        when (sfx) {
            SfxId.FOOTSTEP -> footstep(surface, g)
            SfxId.PICKUP -> pickup(g)
            SfxId.DROP -> drop(g)
            SfxId.INTERACT -> interact(g)
            SfxId.DOCUMENT_OPEN -> paper(g, 0.34f, 5)
            SfxId.PAPER -> paper(g, 0.16f, 3)
            SfxId.GLASS -> glass(g)
            SfxId.WATER -> water(g)
            SfxId.MEDICINE -> medicine(g)
            SfxId.DOOR_OPEN -> doorOpen(g)
            SfxId.DOOR_CLOSE -> doorClose(g)
            SfxId.BREATH -> breath(g)
            SfxId.THUD -> thud(g, 80f, 0.5f)
            SfxId.CLICK -> click(g, 1700f)
            SfxId.HEARTBEAT -> heartbeat(g)
            SfxId.CLOTH -> cloth(g, 0.12f)
            SfxId.PLUSH_TAP -> plushTap(g)
            SfxId.TEXT_TICK -> textTick(g)
            SfxId.CHIME -> chime(g)
            SfxId.CREATURE_BREATH -> creatureBreath(g)
            SfxId.CREATURE_STEP -> creatureStep(g)
            SfxId.CREATURE_ARM -> creatureArm(g)
            SfxId.CREATURE_WET -> creatureWet(g)
            SfxId.CREATURE_MOUTH -> creatureMouth(g)
            SfxId.CREATURE_GROWL -> creatureGrowl(g)
            SfxId.CREATURE_ALERT -> creatureAlert(g)
            SfxId.CREATURE_CHASE -> creatureChase(g)
            SfxId.CREATURE_LOST -> creatureLost(g)
            SfxId.CREATURE_CAPTURE -> creatureCapture(g)
            SfxId.MOM_SCREAM -> momScream(g)
            SfxId.WINDOW_CRASH -> windowCrash(g)
            SfxId.BED_CLIMB -> bedClimb(g)
            SfxId.BED_SETTLE -> bedSettle(g)
            SfxId.CREATURE_REVEAL -> creatureReveal(g)
            SfxId.CREATURE_BREATH_SEARCH -> creatureBreathSearch(g)
            SfxId.CREATURE_BREATH_CHASE -> creatureBreathChase(g)
            SfxId.CREATURE_SNIFF -> creatureSniff(g)
            SfxId.CREATURE_STEP_FAR -> creatureStepFar(g)
            SfxId.CREATURE_BREATH_FAR -> creatureBreathFar(g)
            SfxId.WINDOW_CLIMB -> windowClimb(g)
            SfxId.CLOSET_CREAK -> closetCreak(g)
            SfxId.CLOSET_DOOR -> closetDoor(g)
            SfxId.LIGHT_BREAK -> lightBreak(g)
            SfxId.LIGHT_FLICKER -> lightFlicker(g)
            SfxId.SCREAM_IMPACT -> screamImpact(g)
            SfxId.SCREAM_ROAR -> screamRoar(g)
            SfxId.SCREAM_GRAB -> screamGrab(g)
            SfxId.SCREAM_FINAL -> screamFinal(g)
            SfxId.SCREAM_PRE -> screamPre(g)
            SfxId.FAR_CREAK -> farCreak(g)
            SfxId.FAR_THUD -> farThud(g)
            SfxId.MS_KNOCK -> msKnock(g)
            SfxId.MS_SCRAPE -> msScrape(g)
            SfxId.MS_PENCIL -> msPencil(g)
            SfxId.MS_TINKLE -> msTinkle(g)
            SfxId.MS_DRIP -> msDrip(g, 0.35f)
            SfxId.MS_DRIP_LONG -> msDrip(g, 1.0f)
            SfxId.MS_WHISPER -> msWhisper(g)
            SfxId.MS_VOICE_CLICK -> msVoiceClick(g)
            SfxId.MS_SOB -> msSob(g)
            SfxId.MS_MURMUR -> msMurmur(g)
            SfxId.MS_HOLLOW -> msHollow(g)
            SfxId.MS_HUM_CUT -> msHumCut(g)
            SfxId.MS_RUSTLE -> msRustle(g)
            SfxId.PUZZLE_SOLVED -> puzzleSolved(g)
            SfxId.PUZZLE_WRONG -> puzzleWrong(g)
            SfxId.MIRROR_SWITCH -> mirrorSwitch(g)
            SfxId.MECH_CERAMIC -> mechCeramic(g)
            SfxId.MECH_WOOD_SLIDE -> mechWoodSlide(g)
            SfxId.MECH_WOOD_CLICK -> mechWoodClick(g)
            SfxId.MECH_METAL_CLINK -> mechMetalClink(g)
            SfxId.MECH_ZAP -> mechZap(g)
            SfxId.MECH_PIPE -> mechPipe(g)
            SfxId.MECH_RESONANCE -> mechResonance(g)
            SfxId.MECH_MUFFLED -> mechMuffled(g)
            SfxId.MECH_HOOK -> mechHook(g)
            SfxId.MECH_CLOCK_TICK -> mechClockTick(g)
            SfxId.MECH_PAPER_FLEX -> paper(g * 0.7f, 0.16f, 3)
            SfxId.MECH_STONE_DRAG -> mechStoneDrag(g)
            SfxId.MECH_DEEP_THUMP -> mechDeepThump(g)
        }
    }

    // ---------------------------------------------------------------- bloques de construcción

    private fun tone(wave: Int, f0: Float, f1: Float, att: Float, hold: Float, rel: Float, level: Float, delayS: Float = 0f): SynthVoice {
        val v = core.pool.obtain(Bus.SFX)
        v.wave = wave
        v.freq = f0
        v.freqEnd = f1
        v.glide = core.samples(hold + rel)
        v.env(att, 0f, 1f, hold, rel)
        v.curve = 2
        v.level = level
        v.delay = core.samples(delayS)
        v.pitchMul = core.pitchMul
        v.send = 0.10f
        return v
    }

    private fun noise(att: Float, hold: Float, rel: Float, level: Float, mode: Int, c0: Float, c1: Float, q: Float, delayS: Float = 0f): SynthVoice {
        val v = core.pool.obtain(Bus.SFX)
        v.wave = Wave.NOISE
        v.env(att, 0f, 1f, hold, rel)
        v.curve = 2
        v.setFilter(mode, c0 * core.pitchMul, c1 * core.pitchMul, q)
        v.level = level
        v.delay = core.samples(delayS)
        v.send = 0.10f
        return v
    }

    private fun vary(): Float = core.rng.range(0.92f, 1.08f)

    // ---------------------------------------------------------------- recetas

    private fun footstep(surface: Surface, g: Float) {
        val r = core.rng
        val lvl = g * r.range(0.8f, 1.1f)
        // pie izquierdo / derecho: ligeramente distinto
        val side = if ((stepCount++ and 1) == 0) 1f else 0.93f
        when (surface) {
            Surface.WOOD -> {
                tone(Wave.SINE, 118f * vary() * side, 52f, 0.002f, 0.02f, 0.10f, 0.50f * lvl)
                noise(0.002f, 0.015f, 0.05f, 0.30f * lvl, 1, 1500f, 500f, 0.8f)
                if (r.chance(0.10f)) {          // madera que cruje de vez en cuando
                    val c = tone(Wave.SAW, r.range(190f, 260f), r.range(140f, 190f), 0.01f, 0.07f, 0.09f, 0.045f * lvl, 0.03f)
                    c.setFilter(1, 700f, 500f, 2.5f)
                    c.vibRate = 24f; c.vibDepth = 0.05f
                }
            }
            Surface.TILE -> {
                noise(0.001f, 0.006f, 0.03f, 0.45f * lvl, 2, 2600f * side, 1800f, 3.0f)
                tone(Wave.SINE, 1500f * vary(), 900f, 0.001f, 0.006f, 0.03f, 0.10f * lvl)
                tone(Wave.SINE, 95f, 60f, 0.002f, 0.01f, 0.07f, 0.25f * lvl)
            }
            Surface.GROUND -> {
                noise(0.004f, 0.02f, 0.08f, 0.40f * lvl, 1, 1900f, 700f, 0.7f)
                for (k in 0 until 3) noise(0.001f, 0.004f, 0.012f, 0.12f * lvl, 3, 3000f, 3000f, 1f, r.range(0.01f, 0.08f))
                tone(Wave.SINE, 85f, 55f, 0.003f, 0.015f, 0.07f, 0.22f * lvl)
            }
            Surface.HOSPITAL -> {
                noise(0.001f, 0.006f, 0.03f, 0.40f * lvl, 2, 2300f, 1700f, 3.0f)
                // chirrido de goma
                val sq = tone(Wave.SINE, 1700f * vary(), 2400f * vary(), 0.004f, 0.04f, 0.04f, 0.05f * lvl, 0.01f)
                sq.send = 0.35f
                tone(Wave.SINE, 100f, 60f, 0.002f, 0.01f, 0.06f, 0.20f * lvl)
            }
        }
    }

    private fun pickup(g: Float) {
        noise(0.01f, 0.05f, 0.07f, 0.20f * g, 2, 2800f, 4200f, 1.2f)
        tone(Wave.SINE, 520f * vary(), 700f * vary(), 0.005f, 0.05f, 0.08f, 0.11f * g, 0.02f)
        tone(Wave.TRI, 780f * vary(), 980f, 0.005f, 0.03f, 0.08f, 0.05f * g, 0.07f)
    }

    private fun drop(g: Float) {
        noise(0.004f, 0.03f, 0.06f, 0.20f * g, 2, 3600f, 2200f, 1.0f)
        tone(Wave.SINE, 150f * vary(), 70f, 0.002f, 0.03f, 0.10f, 0.40f * g, 0.03f)
    }

    private fun interact(g: Float) {
        tone(Wave.SINE, 640f * vary(), 640f, 0.003f, 0.02f, 0.07f, 0.10f * g)
        tone(Wave.SINE, 960f * vary(), 960f, 0.003f, 0.02f, 0.07f, 0.06f * g, 0.045f)
    }

    private fun paper(g: Float, length: Float, grains: Int) {
        val r = core.rng
        val step = length / grains
        for (k in 0 until grains) {
            val t = k * step * r.range(0.7f, 1.2f)
            noise(0.004f, step * 0.5f, step * 0.8f, 0.17f * g * r.range(0.6f, 1.1f), 2, r.range(2600f, 4200f), r.range(1800f, 3200f), 0.9f, t)
        }
        noise(0.02f, length * 0.6f, length * 0.4f, 0.05f * g, 3, 5000f, 3500f, 0.7f)
    }

    private fun glass(g: Float) {
        val base = 2350f * vary()
        tone(Wave.SINE, base, base, 0.001f, 0.01f, 0.30f, 0.12f * g).send = 0.30f
        tone(Wave.SINE, base * 1.51f, base * 1.51f, 0.001f, 0.01f, 0.20f, 0.07f * g).send = 0.30f
        tone(Wave.SINE, base * 2.19f, base * 2.19f, 0.001f, 0.005f, 0.12f, 0.04f * g).send = 0.30f
        noise(0.001f, 0.004f, 0.02f, 0.12f * g, 3, 4500f, 4500f, 1f)
    }

    private fun water(g: Float) {
        val r = core.rng
        noise(0.12f, 0.75f, 0.30f, 0.14f * g, 2, 1100f, 1500f, 1.6f)
        for (k in 0 until 7) {
            val f = r.range(380f, 900f)
            tone(Wave.SINE, f, f * 1.9f, 0.002f, 0.015f, 0.05f, 0.05f * g, r.range(0.05f, 1.0f))
        }
    }

    private fun medicine(g: Float) {
        val r = core.rng
        for (k in 0 until 4) noise(0.001f, 0.004f, 0.02f, 0.14f * g, 2, r.range(1800f, 2800f), 1800f, 2.5f, k * r.range(0.04f, 0.08f))
        tone(Wave.SINE, 190f, 110f, 0.002f, 0.02f, 0.08f, 0.22f * g, 0.02f)
    }

    private fun doorOpen(g: Float) {
        click(g * 0.6f, 900f)
        val c = tone(Wave.SAW, 130f, 190f, 0.05f, 0.40f, 0.12f, 0.07f * g, 0.04f)
        c.setFilter(1, 700f, 1100f, 2.8f)
        c.vibRate = 22f; c.vibDepth = 0.06f
        c.curve = 1
        noise(0.05f, 0.35f, 0.15f, 0.04f * g, 2, 500f, 800f, 2f, 0.05f)
    }

    private fun doorClose(g: Float) {
        thud(g, 70f, 0.6f)
        click(g * 0.7f, 1200f)
    }

    private fun thud(g: Float, f: Float, level: Float) {
        tone(Wave.SINE, f * vary() * 1.6f, f, 0.002f, 0.025f, 0.14f, level * g)
        noise(0.002f, 0.012f, 0.05f, 0.25f * g, 1, 900f, 400f, 0.8f)
    }

    private fun click(g: Float, f: Float) {
        noise(0.001f, 0.003f, 0.015f, 0.30f * g, 2, f * vary(), f, 3f)
        tone(Wave.SINE, f * 0.6f, f * 0.4f, 0.001f, 0.004f, 0.02f, 0.10f * g)
    }

    /** Una inhalación y una exhalación (ruido de banda estrecha con envolvente lenta). */
    private fun breath(g: Float) {
        val inhale = noise(0.30f, 0.20f, 0.32f, 0.10f * g, 2, 650f, 900f, 1.1f)
        inhale.send = 0.15f
        val exhale = noise(0.18f, 0.30f, 0.50f, 0.085f * g, 2, 900f, 520f, 1.0f, 0.95f)
        exhale.send = 0.15f
    }

    // ---------------------------------------------------------------- v0.8: la criatura

    /** Respiración húmeda y pesada: aire filtrado + un gorgoteo grave. */
    private fun creatureBreath(g: Float) {
        noise(0.35f, 0.25f, 0.45f, 0.11f * g, 2, 420f * vary(), 620f, 0.9f).send = 0.2f
        tone(Wave.TRI, 58f * vary(), 46f, 0.2f, 0.2f, 0.4f, 0.05f * g).setFilter(1, 220f, 180f, 1.2f)
        noise(0.2f, 0.35f, 0.5f, 0.08f * g, 2, 650f, 380f, 1.2f, 0.9f).send = 0.2f
    }

    private var creatureStepCount = 0

    /**
     * v0.10: paso de un cuerpo enorme y desigual. Apoyo ALTERNO pesado/ligero (cojea), golpe muy grave que hace vibrar
     * el suelo, planta palmeada que se pega y se despega, y a veces un segundo apoyo torpe o un crujido de madera.
     * No se parece a un paso humano con otro tono: tiene arrastre, retardo y asimetría.
     */
    private fun creatureStep(g: Float) {
        val heavy = (creatureStepCount++ and 1) == 0
        thud(g * (if (heavy) 1.3f else 0.85f), if (heavy) 48f else 62f, if (heavy) 0.85f else 0.55f)
        noise(0.006f, 0.05f, 0.22f, 0.15f * g, 2, 380f * vary(), 170f, 1.2f, 0.02f)            // planta que se pega
        if (core.rng.chance(0.65f)) noise(0.02f, 0.10f, 0.22f, 0.08f * g, 2, 700f, 280f, 0.9f, 0.11f)   // se despega
        if (!heavy && core.rng.chance(0.5f)) thud(g * 0.4f, 88f, 0.24f)                       // segundo apoyo torpe
        if (core.rng.chance(0.35f)) tone(Wave.SAW, 95f * vary(), 68f, 0.01f, 0.08f, 0.2f, 0.03f * g, 0.05f).setFilter(1, 300f, 210f, 2.2f)
    }

    /** Brazos largos que rozan o arrastran. */
    private fun creatureArm(g: Float) {
        noise(0.05f, 0.12f, 0.22f, 0.10f * g, 2, 1100f * vary(), 520f, 0.8f)
        thud(g * 0.35f, 90f, 0.25f)
    }

    private fun creatureWet(g: Float) {
        noise(0.01f, 0.03f, 0.10f, 0.14f * g, 2, 900f * vary(), 1900f, 2.0f)
        tone(Wave.SINE, 240f * vary(), 520f, 0.004f, 0.02f, 0.05f, 0.05f * g)
    }

    /** Boca secundaria: chasquido, aire o gemido minúsculo (nunca habla). */
    private fun creatureMouth(g: Float) {
        when (core.rng.pick(3)) {
            0 -> click(g * 0.5f, 1400f)
            1 -> noise(0.03f, 0.05f, 0.12f, 0.07f * g, 2, 800f * vary(), 500f, 1.5f)
            else -> tone(Wave.TRI, 210f * vary(), 150f, 0.03f, 0.08f, 0.15f, 0.045f * g).setFilter(1, 700f, 400f, 1.4f)
        }
        creatureWet(g * 0.5f)
    }

    /** Gruñido de la boca principal. */
    private fun creatureGrowl(g: Float) {
        val a = tone(Wave.SAW, 70f * vary(), 52f, 0.06f, 0.35f, 0.40f, 0.20f * g)
        a.setFilter(1, 520f, 260f, 1.8f)
        tone(Wave.SQUARE, 35f, 30f, 0.08f, 0.30f, 0.40f, 0.05f * g).setFilter(1, 140f, 100f, 1f)
        noise(0.05f, 0.25f, 0.4f, 0.10f * g, 2, 700f, 400f, 1.0f)
    }

    /** Alerta: inspiración brusca y un tono triste y roto (no es una sirena). */
    private fun creatureAlert(g: Float) {
        noise(0.04f, 0.08f, 0.18f, 0.20f * g, 2, 500f, 1500f, 1.2f)
        tone(Wave.TRI, 190f, 120f, 0.04f, 0.25f, 0.35f, 0.10f * g, 0.12f).setFilter(1, 900f, 400f, 1.6f)
        creatureWet(g * 0.8f)
    }

    private fun creatureChase(g: Float) {
        creatureGrowl(g * 1.1f)
        noise(0.02f, 0.10f, 0.20f, 0.22f * g, 2, 900f, 2200f, 1.0f, 0.05f)
        tone(Wave.SAW, 140f, 90f, 0.01f, 0.12f, 0.18f, 0.10f * g, 0.08f).setFilter(1, 1100f, 500f, 2f)
    }

    private fun creatureLost(g: Float) {
        tone(Wave.TRI, 160f, 95f, 0.12f, 0.30f, 0.55f, 0.10f * g).setFilter(1, 600f, 260f, 1.4f)
        noise(0.3f, 0.3f, 0.6f, 0.10f * g, 2, 550f, 350f, 1.0f, 0.1f)
    }

    /** Captura: golpe, distorsión y un chillido húmedo que se corta. */
    private fun creatureCapture(g: Float) {
        thud(g * 1.3f, 48f, 0.8f)
        creatureGrowl(g * 1.4f)
        val v = tone(Wave.SAW, 320f, 80f, 0.005f, 0.30f, 0.35f, 0.16f * g, 0.05f)
        v.setFilter(1, 2400f, 300f, 2.4f)
        noise(0.01f, 0.20f, 0.30f, 0.25f * g, 2, 1800f, 400f, 1.6f, 0.04f)
    }

    // ---------------------------------------------------------------- v0.9: la noche en que mamá desaparece

    /**
     * Grito de mamá oído desde otra habitación de la casa: inhalación brusca, grito agudo y áspero que sube y se
     * quiebra, filtrado (paredes) y con mucha reverberación. Sin voz de texto: es un sonido, no una pista musical.
     */
    private fun momScream(g: Float) {
        noise(0.05f, 0.10f, 0.12f, 0.10f * g, 2, 700f, 1800f, 1.2f).send = 0.40f
        val a = tone(Wave.SAW, 390f * vary(), 780f, 0.05f, 0.50f, 0.50f, 0.22f * g, 0.16f)
        a.setFilter(1, 2000f, 1100f, 1.6f)
        a.vibRate = 7.5f; a.vibDepth = 0.04f; a.send = 0.55f
        val b = tone(Wave.SQUARE, 780f * vary(), 1560f, 0.05f, 0.45f, 0.45f, 0.05f * g, 0.16f)
        b.setFilter(1, 1500f, 900f, 1.2f)
        b.vibRate = 9f; b.vibDepth = 0.05f; b.send = 0.5f
        noise(0.06f, 0.80f, 0.45f, 0.10f * g, 2, 1500f, 900f, 0.9f, 0.16f).send = 0.5f
        // se rompe: segundo tramo más grave y roto, y se corta
        val c = tone(Wave.SAW, 620f, 230f, 0.01f, 0.20f, 0.35f, 0.14f * g, 1.05f)
        c.setFilter(1, 1300f, 600f, 1.8f)
        c.vibRate = 14f; c.vibDepth = 0.08f; c.send = 0.6f
    }

    /** Cristal que revienta y se esparce, lejos, con un golpe sordo. */
    private fun windowCrash(g: Float) {
        val r = core.rng
        noise(0.001f, 0.012f, 0.40f, 0.30f * g, 3, 3500f, 2500f, 1f).send = 0.35f
        thud(g * 0.8f, 70f, 0.5f)
        for (k in 0 until 9) {
            val f = r.range(2200f, 6200f)
            tone(Wave.SINE, f, f * 0.97f, 0.001f, 0.004f, r.range(0.12f, 0.35f), 0.04f * g, 0.03f + k * r.range(0.02f, 0.06f)).send = 0.35f
        }
    }

    /** Subir a la cama: colchón que cede, tela y un golpe sordo. */
    private fun bedClimb(g: Float) {
        cloth(g, 0.26f)
        thud(g * 0.5f, 95f, 0.28f)
        val c = tone(Wave.SAW, 170f * vary(), 140f, 0.04f, 0.12f, 0.10f, 0.04f * g, 0.06f)
        c.setFilter(1, 600f, 450f, 2.5f)
    }

    /** Acostarse: muelles, sábanas y un suspiro de aire. */
    private fun bedSettle(g: Float) {
        cloth(g, 0.45f)
        val c = tone(Wave.SAW, 200f * vary(), 150f, 0.05f, 0.18f, 0.14f, 0.04f * g, 0.05f)
        c.setFilter(1, 650f, 480f, 2.5f)
        c.vibRate = 18f; c.vibDepth = 0.05f
        thud(g * 0.4f, 85f, 0.22f)
        noise(0.20f, 0.30f, 0.50f, 0.06f * g, 2, 700f, 500f, 1.0f, 0.45f)
    }

    /** Primera aparición de la criatura: un temblor muy grave que crece y su respiración húmeda al fondo. */
    private fun creatureReveal(g: Float) {
        tone(Wave.SINE, 46f, 38f, 0.90f, 0.60f, 1.30f, 0.30f * g)
        tone(Wave.TRI, 92f, 70f, 1.00f, 0.50f, 1.20f, 0.05f * g).setFilter(1, 240f, 160f, 1.2f)
        noise(0.70f, 0.40f, 0.80f, 0.08f * g, 2, 420f, 600f, 0.9f, 0.3f).send = 0.3f
        creatureBreath(g * 0.7f)
    }

    private fun heartbeat(g: Float) {
        tone(Wave.SINE, 62f, 42f, 0.004f, 0.04f, 0.14f, 0.50f * g)
        tone(Wave.SINE, 56f, 40f, 0.004f, 0.04f, 0.16f, 0.38f * g, 0.20f)
    }

    private fun cloth(g: Float, length: Float) {
        noise(0.02f, length * 0.5f, length * 0.6f, 0.09f * g, 2, 1800f, 2600f, 0.7f)
        noise(0.03f, length * 0.4f, length * 0.5f, 0.05f * g, 1, 600f, 400f, 0.7f, 0.02f)
    }

    private fun plushTap(g: Float) {
        thud(g * 0.6f, 120f, 0.30f)
        cloth(g * 0.9f, 0.14f)
    }

    private fun textTick(g: Float) {
        tone(Wave.TRI, 1100f * vary(), 1100f, 0.001f, 0.004f, 0.025f, 0.04f * g)
    }

    private fun chime(g: Float) {
        val notes = floatArrayOf(784f, 988f, 1175f)
        for (k in 0 until 3) tone(Wave.SINE, notes[k], notes[k], 0.004f, 0.05f, 0.7f, 0.06f * g, k * 0.12f).send = 0.35f
    }

    // ---------------------------------------------------------------- v0.10: survival

    /** Respiración al buscar (LOST_TARGET / RETURN): ancha y lenta, con olfateos secos y gorgoteo. Distinta a la de persecución. */
    private fun creatureBreathSearch(g: Float) {
        noise(0.5f, 0.35f, 0.7f, 0.12f * g, 2, 300f * vary(), 520f, 0.8f).send = 0.3f
        tone(Wave.TRI, 44f * vary(), 38f, 0.35f, 0.4f, 0.6f, 0.06f * g).setFilter(1, 170f, 140f, 1.1f)
        noise(0.06f, 0.05f, 0.14f, 0.08f * g, 3, 2200f, 1500f, 2.0f, 0.95f)
        noise(0.02f, 0.03f, 0.10f, 0.06f * g, 3, 2600f, 1800f, 2.0f, 1.12f)
        noise(0.45f, 0.4f, 0.8f, 0.10f * g, 2, 520f, 240f, 1.0f, 1.2f).send = 0.3f
        if (core.rng.chance(0.5f)) tone(Wave.SAW, 70f * vary(), 55f, 0.05f, 0.2f, 0.3f, 0.025f * g, 1.35f).setFilter(1, 260f, 200f, 3f)
    }

    /** Respiración de persecución: corta, rasposa, jadeante, con vibración en la garganta. */
    private fun creatureBreathChase(g: Float) {
        noise(0.05f, 0.10f, 0.20f, 0.16f * g, 2, 700f * vary(), 1000f, 1.4f)
        val t = tone(Wave.SAW, 62f * vary(), 52f, 0.03f, 0.14f, 0.2f, 0.07f * g)
        t.setFilter(1, 300f, 260f, 2.6f)
        t.vibRate = 17f; t.vibDepth = 0.06f
        noise(0.04f, 0.10f, 0.20f, 0.13f * g, 2, 900f, 500f, 1.6f, 0.34f)
        tone(Wave.TRI, 48f * vary(), 40f, 0.03f, 0.10f, 0.15f, 0.05f * g, 0.34f)
    }

    /** Olfateo (junto a un armario ocupado, o al perder el rastro). */
    private fun creatureSniff(g: Float) {
        for (k in 0 until 3) noise(0.01f, 0.04f, 0.09f, 0.09f * g, 3, 2400f * vary(), 1700f, 2.2f, k * 0.17f)
        noise(0.12f, 0.1f, 0.3f, 0.07f * g, 2, 400f, 300f, 1f, 0.6f)
    }

    /** Pasos oídos a través de una pared o desde otra habitación: solo el golpe grave y un roce sordo. */
    private fun creatureStepFar(g: Float) {
        val heavy = (creatureStepCount++ and 1) == 0
        tone(Wave.SINE, if (heavy) 44f else 58f, if (heavy) 36f else 48f, 0.004f, 0.04f, 0.3f, 0.45f * g)
        noise(0.02f, 0.06f, 0.25f, 0.05f * g, 1, 260f, 140f, 0.9f, 0.03f)
    }

    /** Respiración grave oída desde otra habitación: casi solo un retumbo. */
    private fun creatureBreathFar(g: Float) {
        noise(0.6f, 0.4f, 0.8f, 0.06f * g, 1, 200f, 260f, 0.9f)
        tone(Wave.TRI, 40f * vary(), 34f, 0.5f, 0.5f, 0.7f, 0.04f * g).setFilter(1, 120f, 100f, 1f)
    }

    /** Trepar por la ventana: cuerpo contra el marco, tela, golpe sordo y el aldabón. */
    private fun windowClimb(g: Float) {
        cloth(g * 1.1f, 0.30f)
        click(g * 0.6f, 900f)
        thud(g * 0.7f, 100f, 0.38f)
        tone(Wave.SAW, 150f * vary(), 120f, 0.03f, 0.12f, 0.12f, 0.035f * g, 0.22f).setFilter(1, 500f, 380f, 2.5f)
        thud(g * 0.55f, 84f, 0.3f)
    }

    /** La puerta del armario se asoma: bisagra que chirría despacio. */
    private fun closetCreak(g: Float) {
        val c = tone(Wave.SAW, 230f * vary(), 330f, 0.2f, 0.55f, 0.35f, 0.045f * g)
        c.setFilter(1, 900f, 600f, 3.5f)
        c.vibRate = 9f; c.vibDepth = 0.04f
        noise(0.1f, 0.4f, 0.4f, 0.04f * g, 2, 1500f, 900f, 1.5f)
    }

    /** Puerta de armario que se abre/cierra (suave: el niño no quiere hacer ruido). */
    private fun closetDoor(g: Float) {
        thud(g * 0.45f, 110f, 0.28f)
        cloth(g * 0.7f, 0.18f)
        click(g * 0.3f, 1100f)
    }

    /** Un foco que revienta: chasquido, estallido de vidrio, zumbido que muere. */
    private fun lightBreak(g: Float) {
        noise(0.001f, 0.006f, 0.12f, 0.35f * g, 3, 4200f, 3000f, 1f).send = 0.3f
        thud(g * 0.5f, 120f, 0.3f)
        val r = core.rng
        for (k in 0 until 6) {
            val f = r.range(2600f, 6800f)
            tone(Wave.SINE, f, f * 0.96f, 0.001f, 0.004f, r.range(0.1f, 0.3f), 0.035f * g, 0.02f + k * r.range(0.02f, 0.05f)).send = 0.3f
        }
        tone(Wave.SAW, 120f, 60f, 0.01f, 0.1f, 0.4f, 0.03f * g).setFilter(1, 600f, 200f, 2f)
    }

    /** Parpadeo del foco: zumbido corto. */
    private fun lightFlicker(g: Float) {
        click(g * 0.35f, 2200f)
        tone(Wave.SAW, 100f, 100f, 0.002f, 0.05f, 0.08f, 0.02f * g).setFilter(1, 900f, 900f, 2f)
    }

    /**
     * v0.10.1: UNA voz de grito humano desesperado: diente de sierra con formantes de vocal abierta ("aaah", o la más aguda y estridente
     * "iii" con [vowel] = 1), vibrato irregular, aliento rasposo ([rasp]) y una brillantez que sube con el tono. Sustituye al rugido grave.
     */
    private fun screamVoice(g: Float, delayS: Float, f0: Float, f1: Float, hold: Float, rel: Float, level: Float, vowel: Int, rasp: Float, vib: Float = 6.5f): SynthVoice {
        val v = tone(Wave.SAW, f0 * vary(), f1 * vary(), 0.012f, hold, rel, level * g, delayS)
        if (vowel == 0) v.setFormants(900f, 1550f, 6f, 8f) else v.setFormants(480f, 2500f, 6f, 9f)
        v.noiseMix = rasp
        v.vibRate = vib
        v.vibDepth = 0.035f
        v.send = 0.28f
        return v
    }

    /** Un grito completo (subida, pico y caída) con coro desafinado que le da cuerpo, como varias gargantas gritando a la vez. */
    private fun screamBody(g: Float, delayS: Float, lo: Float, hi: Float, riseS: Float, fallS: Float, level: Float) {
        for (k in 0 until 3) {
            val d = 1f + (k - 1) * 0.014f                      // desafinado del coro
            val lv = if (k == 1) level else level * 0.40f
            screamVoice(g, delayS, lo * d, hi * d, riseS, 0.04f, lv, 0, 0.20f, 6.2f + k * 1.1f)
            screamVoice(g, delayS + riseS * 0.9f, hi * d, lo * 0.82f * d, fallS, 0.30f, lv, 0, 0.22f, 6.8f + k * 0.9f)
        }
        // chillido agudo encima (vocal estridente) y aliento
        screamVoice(g, delayS + riseS * 0.5f, hi * 1.5f, hi * 1.25f, fallS * 0.7f, 0.2f, level * 0.28f, 1, 0.30f, 8.5f)
        noise(0.03f, riseS + fallS, 0.35f, 0.10f * g, 2, 2600f, 1900f, 1.1f, delayS).send = 0.3f
    }

    /**
     * v0.10.1 (estilo FNAF): capas CRUDAS y saturadas en vez de un tono limpio. [growl] = rugido ronco con modulación de frecuencia y
     * cuantización (suena a bestia/garganta rota); [screech] = ráfaga de chillidos metálicos que saltan de tono; [staticBurst] = estallido
     * de ruido blanco de banda ancha como el de las cintas de los sustos. Los niveles suman por encima del limitador A PROPÓSITO:
     * `softClip` lo satura de forma suave y eso es lo que da la agresividad.
     */
    private fun growl(g: Float, delayS: Float, f0: Float, f1: Float, hold: Float, rel: Float, level: Float): SynthVoice {
        val v = tone(Wave.SAW, f0 * vary(), f1, 0.008f, hold, rel, level * g, delayS)
        v.fmRatio = 1.5f; v.fmDepth = 1.2f; v.crush = 9; v.noiseMix = 0.35f
        v.vibRate = 28f; v.vibDepth = 0.12f
        v.setFilter(1, 3200f, 1800f, 1.4f)
        v.send = 0.2f
        return v
    }

    private fun screech(g: Float, delayS: Float, len: Float, level: Float) {
        val r = core.rng
        var t = 0f
        while (t < len) {
            val f = r.range(1700f, 3300f)
            val d = r.range(0.06f, 0.13f)
            val v = tone(Wave.SAW, f, f * r.range(0.8f, 1.3f), 0.004f, d, 0.03f, level * g, delayS + t)
            v.fmRatio = 2.3f; v.fmDepth = 0.8f; v.noiseMix = 0.25f; v.send = 0.25f
            t += d * 0.8f
        }
    }

    private fun staticBurst(g: Float, delayS: Float, len: Float, level: Float) {
        noise(0.001f, len, len * 0.6f, level * g, 3, 1200f, 600f, 0.8f, delayS).send = 0.3f
        noise(0.001f, len * 0.8f, len * 0.5f, level * 0.6f * g, 2, 3500f, 2200f, 0.7f, delayS).send = 0.3f
    }

    /**
     * v0.17: ANTES del golpe: inhalación INVERTIDA (ruido que crece despacio y se corta de golpe, como un sonido
     * reproducido al revés) + un tono que cae, y después NADA durante ~0,25 s: el silencio raro. No es un aviso:
     * es el aire que falta. Suena al empezar la captura (FREEZE); el golpe llega con SCREAM_IMPACT 0,08 s después
     * de empezar el screamer. Casi sin reverb, para que el hueco que sigue sea de verdad silencio.
     */
    private fun screamPre(g: Float) {
        noise(0.20f, 0.03f, 0.015f, 0.20f * g, 2, 500f, 1600f, 1.2f).send = 0.15f
        val rev = tone(Wave.SAW, 880f * vary(), 170f, 0.22f, 0.0f, 0.012f, 0.05f * g)
        rev.setFilter(1, 1400f, 500f, 1.6f)
        rev.vibRate = 11f; rev.vibDepth = 0.06f; rev.send = 0.15f
    }

    /** SCREAMER, embestida (fotograma 2): golpe seco + golpe GRAVE debajo + inhalación brusca + arranque del grito. */
    private fun screamImpact(g: Float) {
        thud(g * 1.2f, 40f, 0.85f)
        tone(Wave.SINE, 38f, 27f, 0.002f, 0.05f, 0.30f, 0.85f * g)   // subgrave: se siente en el pecho, no se oye
        noise(0.001f, 0.04f, 0.35f, 0.30f * g, 3, 5200f, 1400f, 0.9f).send = 0.3f
        screamVoice(g, 0.0f, 640f, 1050f, 0.22f, 0.05f, 0.30f, 0, 0.25f)
        screamVoice(g, 0.0f, 655f, 1065f, 0.22f, 0.05f, 0.20f, 0, 0.25f, 7.4f)
        staticBurst(g, 0f, 0.28f, 0.42f)
        growl(g, 0f, 190f, 120f, 0.30f, 0.15f, 0.22f)
    }

    /** SCREAMER, grito principal (fotograma 5): el grito desesperado, fuerte y corto, que sube y se quiebra. */
    private fun screamRoar(g: Float) {
        screamBody(g, 0f, 900f, 1480f, 0.28f, 0.50f, 0.26f)
        // voz grave del monstruo que gruñe por debajo: formantes del perfil MONSTER de VoiceSynth (tracto vocal
        // corto y roto: la "a" grave del monstruo, no un tono genérico). Es lo que dice que no es solo un niño.
        val monster = VoiceProfiles.get(VoiceId.MONSTER)
        val low = tone(Wave.SAW, 150f * vary(), 105f, 0.04f, 0.55f, 0.25f, 0.12f * g)
        low.setFormants(Vowels.f1(0) * monster.formantScale, Vowels.f2(0) * monster.formantScale, 5f, 7f)
        low.noiseMix = 0.3f; low.vibRate = 17f; low.vibDepth = 0.08f; low.send = 0.2f
        growl(g, 0.02f, 210f, 95f, 0.55f, 0.25f, 0.26f)
        screech(g, 0.10f, 0.6f, 0.12f)
        staticBurst(g, 0.05f, 0.35f, 0.30f)
    }

    /** SCREAMER, agarre (fotograma 9): la voz se quiebra hacia un chillido agudo y vuelve a caer, con el golpe de la mano. */
    private fun screamGrab(g: Float) {
        thud(g * 1.1f, 55f, 0.85f)
        cloth(g * 1.3f, 0.32f)
        screamVoice(g, 0f, 1000f, 1750f, 0.14f, 0.05f, 0.34f, 1, 0.35f, 9f)
        staticBurst(g, 0f, 0.18f, 0.35f)
        screech(g, 0f, 0.35f, 0.14f)
        screamVoice(g, 0.16f, 1750f, 1050f, 0.22f, 0.12f, 0.30f, 0, 0.30f, 7.5f)
        noise(0.004f, 0.06f, 0.25f, 0.16f * g, 2, 3200f, 2200f, 1.2f).send = 0.3f
    }

    /**
     * SCREAMER, último plano (fotograma 16): el grito final, agudo y roto, que se corta. Antes terminaba en 5
     * sollozos (~1,6 s de llanto que se apagaba): ahora UN solo hipido roto y corte. El negro hace el resto.
     */
    private fun screamFinal(g: Float) {
        thud(g * 1.4f, 32f, 1.0f)
        tone(Wave.SINE, 34f, 24f, 0.002f, 0.04f, 0.25f, 0.8f * g)
        noise(0.001f, 0.04f, 0.45f, 0.30f * g, 3, 4800f, 900f, 0.9f).send = 0.35f
        screamVoice(g, 0f, 1250f, 1560f, 0.22f, 0.10f, 0.36f, 0, 0.28f, 8f)
        screamVoice(g, 0f, 1262f, 1575f, 0.22f, 0.10f, 0.22f, 1, 0.35f, 9.5f)
        screamVoice(g, 0.20f, 1560f, 820f, 0.30f, 0.30f, 0.32f, 0, 0.30f, 7f)
        staticBurst(g, 0f, 0.35f, 0.40f)
        growl(g, 0f, 230f, 100f, 0.45f, 0.2f, 0.26f)
        screech(g, 0.02f, 0.5f, 0.14f)
        // un solo hipido roto y corte (antes eran 5 sollozos)
        val sob = screamVoice(g, 0.52f, 640f, 460f, 0.08f, 0.09f, 0.20f, 0, 0.35f, 13f)
        sob.send = 0.35f
    }

    /** Crujido de la casa a lo lejos (madera, tubería). */
    private fun farCreak(g: Float) {
        val c = tone(Wave.SAW, 150f * vary(), 110f, 0.05f, 0.25f, 0.45f, 0.035f * g)
        c.setFilter(1, 420f, 260f, 2.8f)
        noise(0.04f, 0.15f, 0.3f, 0.025f * g, 2, 700f, 400f, 1.4f)
    }

    /** Un golpe sordo lejano (puerta, algo que cae en otra parte de la casa). */
    private fun farThud(g: Float) {
        tone(Wave.SINE, 70f, 42f, 0.004f, 0.05f, 0.35f, 0.30f * g).setFilter(1, 240f, 140f, 1f)
        noise(0.01f, 0.04f, 0.2f, 0.04f * g, 1, 300f, 160f, 0.9f)
    }

    // ---------------------------------------------------------------- Capítulo I: micro-sustos y puzles
    // Todos son MUY suaves y cortos: el miedo sale del origen, la cercanía y el silencio previo, no del volumen.

    /** Un golpe seco y mate dentro de una pared o una tubería. */
    private fun msKnock(g: Float) {
        tone(Wave.SINE, 95f * vary(), 58f, 0.002f, 0.03f, 0.16f, 0.24f * g).setFilter(1, 320f, 180f, 0.9f)
        noise(0.002f, 0.02f, 0.10f, 0.07f * g, 1, 500f, 200f, 0.9f)
    }

    /** Grafito raspando papel, o uñas deslizándose sobre una superficie lisa. */
    private fun msScrape(g: Float) {
        noise(0.03f, 0.22f, 0.25f, 0.050f * g, 2, 3600f, 2400f, 1.8f)
        noise(0.05f, 0.18f, 0.20f, 0.025f * g, 3, 6500f, 5200f, 1.2f, 0.04f)
        tone(Wave.SAW, 3300f, 2700f, 0.04f, 0.12f, 0.12f, 0.012f * g, 0.08f).setFilter(2, 3000f, 2600f, 4f)
    }

    /** Un lápiz infantil que traza dos líneas y se levanta. */
    private fun msPencil(g: Float) {
        noise(0.012f, 0.11f, 0.05f, 0.060f * g, 2, 4200f, 3400f, 1.4f)
        noise(0.012f, 0.14f, 0.05f, 0.055f * g, 2, 4600f, 3600f, 1.4f, 0.26f)
        noise(0.001f, 0.003f, 0.015f, 0.10f * g, 2, 2600f, 2600f, 3f, 0.62f)
    }

    /** Un tintineo tardío de cristal que sigue vibrando. */
    private fun msTinkle(g: Float) {
        val base = 3050f * vary()
        tone(Wave.SINE, base, base, 0.001f, 0.01f, 0.55f, 0.045f * g).send = 0.4f
        tone(Wave.SINE, base * 1.52f, base * 1.52f, 0.001f, 0.005f, 0.35f, 0.025f * g, 0.18f).send = 0.4f
    }

    /** Una gota sobre agua; [reverb] alto = resonancia demasiado larga para el tamaño del espacio. */
    private fun msDrip(g: Float, reverb: Float) {
        val v = tone(Wave.SINE, 1500f * vary(), 520f, 0.001f, 0.012f, if (reverb > 0.5f) 0.9f else 0.12f, 0.09f * g)
        v.send = reverb
        if (reverb > 0.5f) tone(Wave.SINE, 760f, 380f, 0.004f, 0.02f, 1.1f, 0.03f * g, 0.05f).send = 0.95f
    }

    /** Una sílaba lejana arrastrada por el viento: no llega a ser una palabra. */
    private fun msWhisper(g: Float) {
        noise(0.20f, 0.18f, 0.40f, 0.035f * g, 2, 900f, 1500f, 4.5f)
        noise(0.30f, 0.10f, 0.35f, 0.020f * g, 2, 1800f, 1200f, 5f, 0.12f)
    }

    /** Un fragmento de voz ininteligible y un clic eléctrico (televisor apagado). */
    private fun msVoiceClick(g: Float) {
        tone(Wave.SAW, 170f, 150f, 0.01f, 0.11f, 0.09f, 0.045f * g).setFilter(2, 900f, 1300f, 3f)
        tone(Wave.SAW, 210f, 180f, 0.01f, 0.08f, 0.07f, 0.030f * g, 0.14f).setFilter(2, 1100f, 800f, 3f)
        noise(0.001f, 0.003f, 0.015f, 0.20f * g, 2, 2200f, 2200f, 3f, 0.36f)
    }

    /** Sollozos entrecortados de un niño, sobre un fondo de aire (ambiente del deterioro de NORMAL). */
    private fun msSob(g: Float) {
        val r = core.rng
        var f = r.range(500f, 580f)
        for (k in 0 until 3) {
            val t = k * r.range(0.30f, 0.38f)
            val v = tone(Wave.TRI, f, f * 0.82f, 0.03f, 0.10f, 0.14f, 0.040f * g, t)
            v.vibRate = 7f; v.vibDepth = 0.05f
            v.setFilter(1, 1500f, 900f, 1.2f)
            noise(0.02f, 0.10f, 0.14f, 0.020f * g, 2, 1500f, 1100f, 1.1f, t)
            f *= 0.92f
        }
    }

    /** Un murmullo grave que intenta formar palabras sin conseguirlo (bocas de TRAUMA). */
    private fun msMurmur(g: Float) {
        val v = tone(Wave.SAW, 112f * vary(), 96f, 0.12f, 0.45f, 0.35f, 0.040f * g)
        v.setFilter(2, 520f, 880f, 3.5f)
        v.vibRate = 5f; v.vibDepth = 0.08f
        noise(0.10f, 0.40f, 0.30f, 0.018f * g, 2, 700f, 500f, 2.5f, 0.05f)
    }

    /** Un golpe grave y hueco (tanque de agua). */
    private fun msHollow(g: Float) {
        tone(Wave.SINE, 64f, 52f, 0.01f, 0.18f, 0.36f, 0.20f * g).setFilter(1, 220f, 160f, 1f)
        noise(0.01f, 0.05f, 0.20f, 0.03f * g, 1, 260f, 140f, 1.2f)
    }

    /** Un zumbido eléctrico que se corta un instante. */
    private fun msHumCut(g: Float) {
        tone(Wave.SAW, 100f, 100f, 0.02f, 0.26f, 0.03f, 0.040f * g).setFilter(1, 420f, 420f, 1.5f)
        noise(0.001f, 0.003f, 0.012f, 0.10f * g, 2, 1500f, 1500f, 3f, 0.30f)
    }

    /** Un roce de tela o de madera detrás del niño. */
    private fun msRustle(g: Float) {
        cloth(g * 0.9f, 0.26f)
        noise(0.04f, 0.10f, 0.14f, 0.030f * g, 3, 4200f, 3000f, 0.8f, 0.05f)
    }

    private fun puzzleSolved(g: Float) {
        val notes = floatArrayOf(392f, 523f, 659f)
        for (k in 0 until 3) tone(Wave.SINE, notes[k], notes[k], 0.004f, 0.04f, 0.5f, 0.05f * g, k * 0.10f).send = 0.35f
        noise(0.01f, 0.05f, 0.18f, 0.05f * g, 1, 500f, 250f, 0.9f, 0.30f)
    }

    // ---------------------------------------------------------------- v0.15: mecanismos de los puzles

    /** Cerámica: un golpecito corto y seco (taza o plato sobre madera). */
    private fun mechCeramic(g: Float) {
        val base = 1480f * vary()
        tone(Wave.SINE, base, base, 0.001f, 0.008f, 0.09f, 0.08f * g).send = 0.18f
        tone(Wave.SINE, base * 1.62f, base * 1.62f, 0.001f, 0.006f, 0.05f, 0.04f * g).send = 0.18f
        noise(0.001f, 0.003f, 0.018f, 0.10f * g, 2, 2400f, 2000f, 2f)
    }

    /** Roce suave de madera o papel pintado. */
    private fun mechWoodSlide(g: Float) {
        noise(0.03f, 0.10f, 0.14f, 0.045f * g, 2, 900f * vary(), 1300f, 1.1f)
        noise(0.04f, 0.06f, 0.10f, 0.02f * g, 3, 2600f, 2000f, 0.8f, 0.02f)
    }

    /** Clic seco de madera (hendidura, gancho, pestillo). */
    private fun mechWoodClick(g: Float) {
        noise(0.001f, 0.004f, 0.025f, 0.22f * g, 2, 1100f * vary(), 800f, 3.2f)
        tone(Wave.SINE, 240f, 170f, 0.001f, 0.006f, 0.04f, 0.08f * g)
    }

    /** Metal fino contra metal (terminal, articulación, lámina). */
    private fun mechMetalClink(g: Float) {
        val f = 3100f * vary()
        tone(Wave.SINE, f, f, 0.001f, 0.004f, 0.16f, 0.06f * g).send = 0.25f
        tone(Wave.SINE, f * 2.76f, f * 2.76f, 0.001f, 0.003f, 0.07f, 0.03f * g).send = 0.25f
        noise(0.001f, 0.002f, 0.012f, 0.08f * g, 3, 5200f, 4800f, 1.4f)
    }

    /** Chisporroteo corto de corriente (el zumbido se corta). */
    private fun mechZap(g: Float) {
        val r = core.rng
        for (k in 0 until 4) noise(0.001f, 0.004f, 0.02f, 0.10f * g, 2, r.range(2200f, 4200f), 1800f, 2.4f, k * r.range(0.02f, 0.05f))
        tone(Wave.SAW, 100f, 96f, 0.004f, 0.10f, 0.08f, 0.05f * g).setFilter(1, 500f, 300f, 1.2f)
    }

    /** Golpe de tubería: grave, metálico y hueco. */
    private fun mechPipe(g: Float) {
        tone(Wave.SINE, 140f * vary(), 78f, 0.002f, 0.03f, 0.30f, 0.20f * g).send = 0.30f
        tone(Wave.SINE, 410f, 300f, 0.001f, 0.01f, 0.14f, 0.05f * g).send = 0.30f
        noise(0.002f, 0.01f, 0.06f, 0.10f * g, 1, 700f, 300f, 1f)
    }

    /** Resonancia larga de una marca raspada (pulsación mantenida). */
    private fun mechResonance(g: Float) {
        tone(Wave.SINE, 118f * vary(), 104f, 0.01f, 0.18f, 0.55f, 0.16f * g).setFilter(1, 360f, 220f, 1.1f)
        tone(Wave.SINE, 236f, 208f, 0.01f, 0.10f, 0.40f, 0.05f * g)
    }

    /** Eco amortiguado desde el muro (golpe incorrecto). */
    private fun mechMuffled(g: Float) {
        tone(Wave.SINE, 70f, 48f, 0.004f, 0.03f, 0.22f, 0.15f * g).setFilter(1, 200f, 120f, 0.8f)
        noise(0.004f, 0.02f, 0.14f, 0.03f * g, 1, 260f, 140f, 0.8f)
    }

    /** Gancho de marco que se asienta. */
    private fun mechHook(g: Float) {
        click(g * 0.55f, 1500f)
        tone(Wave.SINE, 620f, 520f, 0.001f, 0.006f, 0.05f, 0.04f * g, 0.012f)
    }

    /** Tic mecánico de un reloj de mesita. */
    private fun mechClockTick(g: Float) {
        click(g * 0.4f, 2600f)
    }

    /** Roce pesado de piedra o caja contra el suelo. */
    private fun mechStoneDrag(g: Float) {
        noise(0.05f, 0.25f, 0.20f, 0.07f * g, 1, 500f, 300f, 1.2f)
        noise(0.05f, 0.20f, 0.15f, 0.03f * g, 2, 1500f, 1000f, 0.9f, 0.04f)
    }

    /** Golpe grave que parece venir de dentro de la pared, con cola larga. */
    private fun mechDeepThump(g: Float) {
        tone(Wave.SINE, 62f, 38f, 0.006f, 0.12f, 0.90f, 0.26f * g).send = 0.45f
        tone(Wave.SINE, 124f, 70f, 0.006f, 0.05f, 0.50f, 0.07f * g).send = 0.45f
        noise(0.004f, 0.03f, 0.30f, 0.05f * g, 1, 300f, 120f, 0.8f)
    }

    private fun puzzleWrong(g: Float) {
        tone(Wave.SINE, 190f, 150f, 0.004f, 0.05f, 0.18f, 0.10f * g).setFilter(1, 600f, 400f, 1f)
        click(g * 0.5f, 900f)
    }

    private fun mirrorSwitch(g: Float) {
        glass(g * 0.6f)
        noise(0.04f, 0.18f, 0.22f, 0.035f * g, 2, 3200f, 1800f, 1.6f, 0.04f)
        tone(Wave.SINE, 220f, 140f, 0.02f, 0.10f, 0.30f, 0.06f * g, 0.06f).send = 0.5f
    }
}
