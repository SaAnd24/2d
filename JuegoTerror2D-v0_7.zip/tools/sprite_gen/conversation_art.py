"""Arte de la ESCENA DE CONVERSACIÓN (v0.7): las dos manos del niño sujetando el peluche, en primera persona, sobre negro.

Solo para GENERAR los datos del juego (el juego no usa Python). Resolución 640x360 = el doble de la pantalla lógica
(320x180), igual que el protagonista (1 píxel = 0.5 px lógicos), pero con una densidad de detalle brutal: cada capa se
construye como un MAPA DE ALTURAS (dedos = cápsulas segmentadas, peluche = elipsoides), se ilumina con una lámpara
tenue (difuso + brillo + subsuperficie cálida + sombras de contacto) y se cuantiza a una paleta de ~170 colores.

Capas (de abajo arriba): 0 peluche (INMÓVIL), 1-2 base de la mano izq./der. (dorso, muñeca, manga, pulgar),
3-6 dedos de la izquierda (índice..meñique), 7-10 dedos de la derecha. Los dedos son capas separadas para poder
respirar y temblar de forma independiente.

Uso:  python3 conversation_art.py     (escribe app/.../pixel/ConversationArtData.kt y una vista previa)
"""
import os
import numpy as np
from scipy import ndimage as ndi
from PIL import Image, ImageDraw

W, H = 640, 360
YY, XX = np.mgrid[0:H, 0:W].astype(np.float32)
RNG = np.random.RandomState(70)

OUT_KT = os.path.join(os.path.dirname(__file__), '..', '..', 'app', 'src', 'main', 'java', 'com', 'terror2d', 'pixel',
                      'ConversationArtData.kt')


def nrm(v):
    v = np.array(v, dtype=np.float32)
    return v / np.linalg.norm(v)


LIGHT = nrm([-0.42, -0.60, 0.68])       # lámpara arriba a la izquierda, delante
HALF = nrm(LIGHT + np.array([0, 0, 1.0]))
RIM = nrm([0.8, -0.1, 0.35])


def blur(a, s):
    return ndi.gaussian_filter(a, s, mode='nearest')


def noise(scale, seed):
    r = np.random.RandomState(seed).randn(H, W).astype(np.float32)
    n = blur(r, scale)
    return n / (n.std() + 1e-6)


def smoothstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)


def rot(v, deg):
    """Giro visual antihorario (y hacia abajo)."""
    a = np.radians(deg)
    return (v[0] * np.cos(a) + v[1] * np.sin(a), -v[0] * np.sin(a) + v[1] * np.cos(a))


def lamp(cx=300, cy=150, r=400):
    d = np.hypot(XX - cx, YY - cy)
    f = np.clip(1 - d / r, 0, 1) ** 1.25
    return (0.05 + 1.12 * f).astype(np.float32)


FALLOFF = lamp()


# ------------------------------------------------------------------ superficie con mapa de alturas
class Surf:
    def __init__(self):
        self.h = np.zeros((H, W), np.float32)
        self.alb = np.zeros((H, W, 3), np.float32)
        self.ks = np.zeros((H, W), np.float32)
        self.sh = np.full((H, W), 8, np.float32)
        self.sss = np.zeros((H, W), np.float32)
        self.mask = np.zeros((H, W), bool)
        self.ao = np.ones((H, W), np.float32)
        self.rim = np.zeros((H, W), np.float32)

    def put(self, h, mask, alb, ks=0.0, sh=8.0, sss=0.0, z0=0.0, rim=0.0):
        hh = h + z0
        upd = mask & ((hh > self.h) | ~self.mask)
        self.h[upd] = hh[upd]
        self.alb[upd] = np.broadcast_to(np.asarray(alb, np.float32), (H, W, 3))[upd]
        self.ks[upd] = ks
        self.sh[upd] = sh
        self.sss[upd] = sss
        self.rim[upd] = rim
        self.mask |= mask

    def paint(self, mask, alb, alpha=1.0, ks=None, sh=None, dh=0.0):
        m = mask & self.mask
        a = (np.asarray(alpha, np.float32) * m)[..., None]
        self.alb = self.alb * (1 - a) + np.broadcast_to(np.asarray(alb, np.float32), (H, W, 3)) * a
        if ks is not None:
            self.ks[m] = ks
        if sh is not None:
            self.sh[m] = sh
        if dh:
            self.h[m] += dh * (np.asarray(alpha) if np.ndim(alpha) else 1.0) if np.ndim(alpha) == 0 else 0
            if np.ndim(alpha):
                self.h += dh * a[..., 0]

    def shade(self, ambient=0.07):
        hs = blur(self.h, 0.9)
        gy, gx = np.gradient(hs)
        n = np.stack([-gx, -gy, np.ones_like(gx)], -1)
        n /= np.linalg.norm(n, axis=-1, keepdims=True)
        ndl = n @ LIGHT
        diff = np.clip((ndl + self.sss) / (1 + self.sss), 0, 1)
        lit = ambient + (1 - ambient) * diff
        col = self.alb * (lit * self.ao)[..., None]
        # subsuperficie: rojo cálido en la zona de penumbra de la piel
        pen = (self.sss > 0) * smoothstep(0.0, 0.5, 1 - diff) * smoothstep(0.0, 0.25, diff + 0.25)
        col += pen[..., None] * np.array([0.20, 0.035, 0.02], np.float32) * self.ao[..., None]
        spec = self.ks * np.clip(n @ HALF, 0, 1) ** self.sh
        col += (spec * self.ao)[..., None] * np.array([1.0, 0.96, 0.9], np.float32)
        rim = self.rim * np.clip(n @ RIM, 0, 1) ** 2
        col += rim[..., None] * np.array([0.30, 0.22, 0.17], np.float32)
        col *= FALLOFF[..., None]
        return np.clip(col, 0, 1)


def shadow_from(occ, dx, dy, sigma, strength):
    s = ndi.shift(occ.astype(np.float32), (dy, dx), order=1, mode='constant')
    s = blur(s, sigma)
    return 1 - strength * np.clip(s * 1.4, 0, 1)


# ------------------------------------------------------------------ primitivas
def ellipsoid(cx, cy, rx, ry, hz, ang=0.0):
    c, s = np.cos(np.radians(ang)), np.sin(np.radians(ang))
    dx, dy = XX - cx, YY - cy
    u = (dx * c + dy * s) / rx
    v = (-dx * s + dy * c) / ry
    d = u * u + v * v
    m = d < 1
    return (hz * np.sqrt(np.clip(1 - d, 0, 1))).astype(np.float32), m, u, v


def capsule(pts, radii, zs=1.0):
    """Cápsula segmentada con radio variable. Devuelve (h, mask, s=longitud de arco, u=lateral con signo, r)."""
    best = np.full((H, W), 9e9, np.float32)
    bs = np.zeros((H, W), np.float32)
    bu = np.zeros((H, W), np.float32)
    br = np.ones((H, W), np.float32)
    cum = 0.0
    for i in range(len(pts) - 1):
        ax, ay = pts[i]
        bx, by = pts[i + 1]
        abx, aby = bx - ax, by - ay
        l2 = abx * abx + aby * aby
        ln = np.sqrt(l2)
        t = np.clip(((XX - ax) * abx + (YY - ay) * aby) / l2, 0, 1)
        px, py = ax + t * abx, ay + t * aby
        d = np.hypot(XX - px, YY - py)
        r = radii[i] + (radii[i + 1] - radii[i]) * t
        score = d / r
        upd = score < best
        cross = abx * (YY - ay) - aby * (XX - ax)
        best = np.where(upd, score, best)
        bs = np.where(upd, cum + t * ln, bs)
        bu = np.where(upd, np.sign(cross) * d, bu)
        br = np.where(upd, r, br)
        cum += ln
    m = best < 1
    h = (br * zs * np.sqrt(np.clip(1 - best * best, 0, 1))).astype(np.float32)
    return h, m, bs, bu, br


def seg_points(origin, direction, length, curls, fracs, radii):
    p = [origin]
    d = direction
    for k, f in enumerate(fracs):
        if k > 0:
            d = rot(d, curls[k - 1])
        p.append((p[-1][0] + d[0] * length * f, p[-1][1] + d[1] * length * f))
    return p, d


def bezier(p0, p1, p2, n=200):
    t = np.linspace(0, 1, n)[:, None]
    pts = (1 - t) ** 2 * np.array(p0) + 2 * (1 - t) * t * np.array(p1) + t ** 2 * np.array(p2)
    return pts


def stroke_mask(points, width):
    im = Image.new('L', (W, H), 0)
    ImageDraw.Draw(im).line([tuple(map(float, p)) for p in points], fill=255, width=int(width), joint='curve')
    return np.array(im) > 0


def stitched_line(points, width, dash=7, gap=3, tick=0, tick_every=2):
    """Costura: dashes a lo largo de la curva (+ puntadas perpendiculares opcionales)."""
    pts = np.asarray(points)
    seg = np.hypot(*np.diff(pts, axis=0).T)
    arc = np.concatenate([[0], np.cumsum(seg)])
    total = arc[-1]
    m = np.zeros((H, W), bool)
    s, k = 0.0, 0
    while s < total:
        e = min(total, s + dash)
        idx = np.where((arc >= s) & (arc <= e))[0]
        if len(idx) >= 2:
            m |= stroke_mask(pts[idx], width)
        if tick and k % tick_every == 0:
            i = np.searchsorted(arc, (s + e) / 2)
            i = min(max(i, 1), len(pts) - 1)
            d = pts[i] - pts[i - 1]
            d = d / (np.linalg.norm(d) + 1e-6)
            nx, ny = -d[1], d[0]
            c = pts[i]
            m |= stroke_mask([(c[0] - nx * tick, c[1] - ny * tick), (c[0] + nx * tick, c[1] + ny * tick)], max(2, width - 1))
        s += dash + gap
        k += 1
    return m


def fiber_map(count, seed, lo=2, hi=6):
    r = np.random.RandomState(seed)
    im = Image.new('L', (W, H), 0)
    dr = ImageDraw.Draw(im)
    for _ in range(count):
        x, y = r.uniform(0, W), r.uniform(0, H)
        a = r.uniform(0, 2 * np.pi)
        l = r.uniform(lo, hi)
        dr.line([(x, y), (x + np.cos(a) * l, y + np.sin(a) * l)], fill=int(r.uniform(90, 255)), width=1)
    return np.array(im).astype(np.float32) / 255.0


# ------------------------------------------------------------------ PELUCHE (capa 0, inmóvil)
FAB = np.array([0.52, 0.62, 0.43], np.float32)        # verde salvia apagado
FAB_D = np.array([0.36, 0.45, 0.31], np.float32)
BELLY = np.array([0.80, 0.77, 0.64], np.float32)
CAPC = np.array([0.82, 0.79, 0.68], np.float32)
CROSS = np.array([0.30, 0.50, 0.28], np.float32)
THREAD = np.array([0.20, 0.14, 0.12], np.float32)
THREAD_L = np.array([0.46, 0.38, 0.30], np.float32)
SCLERA = np.array([0.90, 0.88, 0.76], np.float32)
PATCHC = np.array([0.62, 0.55, 0.42], np.float32)
BLUSHC = np.array([0.78, 0.55, 0.52], np.float32)

# geometría del peluche (se reutiliza para las sombras y la vista previa)
EYE_L = (254, 114, 38)
EYE_R = (390, 106, 41)


def build_plush():
    s = Surf()
    weave = 1 + 0.075 * np.sin(2 * np.pi * (XX * 0.7 + YY * 0.3) / 3.3) * np.sin(2 * np.pi * (XX * -0.3 + YY * 0.7) / 3.3)
    fab_tex = (weave * (1 + 0.05 * noise(1.1, 1) + 0.05 * noise(5, 2) + 0.28 * fiber_map(1400, 3)))[..., None]
    fab = FAB * fab_tex

    # piernas, cuerpo, brazos (el izquierdo más largo y caído; el derecho más corto)
    h, m, _, _ = ellipsoid(274, 300, 46, 27, 36)
    s.put(h, m, fab, sh=3)
    h, m, _, _ = ellipsoid(368, 303, 43, 24, 31)
    s.put(h, m, fab, sh=3)
    h, m, _, _ = ellipsoid(320, 250, 67, 60, 74)
    s.put(h, m, fab, sh=3)
    h, m, _, _, _ = capsule([(262, 214), (237, 258), (226, 296)], [18, 16, 13], 1.0)
    s.put(h, m, fab, z0=26)
    h, m, _, _, _ = capsule([(380, 214), (404, 250), (412, 276)], [17, 15, 12], 1.0)
    s.put(h, m, fab, z0=26)
    # cabeza grande y ancha (por encima del cuerpo)
    h, m, _, _ = ellipsoid(320, 164, 106, 59, 70)
    s.put(h, m, fab, z0=20)
    # ojos saltones y desiguales: domo de tela + esclerótica de plástico envejecido + pupila MUY pequeña
    for (cx, cy, r) in (EYE_L, EYE_R):
        h, m, _, _ = ellipsoid(cx, cy, r, r, r * 1.05)
        s.put(h, m, fab * 0.92, z0=48)
        h2, m2, _, _ = ellipsoid(cx, cy + 2, r - 8, r - 9, (r - 8) * 0.9)
        eye_alb = SCLERA * (1 + 0.04 * noise(2, 9))[..., None]
        s.put(h2, m2, eye_alb, ks=0.55, sh=48, z0=58)
    # sombra de párpado y aro de costura alrededor de cada ojo
    for (cx, cy, r) in (EYE_L, EYE_R):
        ring = (np.hypot(XX - cx, YY - cy) > r - 9) & (np.hypot(XX - cx, YY - cy) < r - 6.5)
        s.paint(ring, THREAD_L * 0.7, 0.8)
        lid = (np.hypot(XX - cx, YY - (cy + 2)) < r - 8) & (YY < cy - (r - 8) * 0.35)
        s.ao *= np.where(lid, 0.82, 1.0)
    pup = ((258, 124, 8.5), (383, 116, 10.5))
    for (px, py, pr) in pup:
        ring = np.hypot(XX - px, YY - py) < pr + 5
        s.paint(ring, np.array([0.42, 0.38, 0.28]), 0.45)
        h, m, _, _ = ellipsoid(px, py, pr, pr, pr * 0.9)
        s.put(h, m, np.array([0.025, 0.02, 0.03]), ks=1.0, sh=70, z0=s.h[int(py), int(px)] + 1)
        # reflejo pequeño de ventana
        win = (np.abs(XX - (px - pr * 0.35)) < 2.2) & (np.abs(YY - (py - pr * 0.4)) < 1.8)
        s.paint(win, np.array([1.0, 0.98, 0.92]), 0.95)
    # gorrito de la farmacia (ladeado) con cruz bordada
    h, m, _, _ = ellipsoid(322, 98, 34, 21, 22, ang=-6)
    s.put(h, m, CAPC * fab_tex, sh=3, z0=66)
    for (x0, y0, x1, y1) in ((322, 84, 322, 108), (310, 96, 336, 96)):
        s.paint(stroke_mask([(x0, y0), (x1, y1)], 5), CROSS, 0.95, dh=1.2)
    # parche del vientre con cruz y costura
    belly_m = (((XX - 320) / 40) ** 2 + ((YY - 264) / 36) ** 2 < 1) & (s.h > 40)
    s.paint(belly_m, BELLY * fab_tex, 0.95, dh=2.5)
    for (x0, y0, x1, y1) in ((320, 246, 320, 284), (301, 266, 342, 270)):
        s.paint(stroke_mask([(x0, y0), (x1, y1)], 6), CROSS, 0.95, dh=1.5)
    ang = np.linspace(0, 2 * np.pi, 160)
    belly_ring = np.stack([320 + 41 * np.cos(ang), 264 + 37 * np.sin(ang)], 1)
    s.paint(stitched_line(belly_ring, 2, dash=6, gap=3), THREAD, 0.95, ks=0.2, sh=16, dh=1.4)
    # remiendo de tela en la pierna izquierda
    patch_m = (XX > 246) & (XX < 288) & (YY > 288) & (YY < 318) & (s.h > 8)
    s.paint(patch_m, PATCHC * fab_tex, 0.97, dh=1.8)
    pe = [(246, 288), (288, 288), (288, 318), (246, 318), (246, 288)]
    s.paint(stitched_line(pe, 2, dash=5, gap=3), THREAD, 0.95, dh=1.4)
    # mejillas desvaídas
    for (cx, cy) in ((232, 196), (410, 192)):
        cm = (((XX - cx) / 24) ** 2 + ((YY - cy) / 12) ** 2 < 1)
        s.paint(cm, BLUSHC, 0.42)
    # costura del cuello (puntada en cruz) entre cabeza y cuerpo
    neck = bezier((226, 214), (320, 238), (414, 212), 160)
    s.paint(stitched_line(neck, 2, dash=5, gap=4, tick=5, tick_every=1), THREAD, 0.95, ks=0.2, sh=16, dh=1.4)
    # SONRISA COSIDA, demasiado ancha: casi de mejilla a mejilla, algo más alta a la derecha, remate en gancho
    mouth = bezier((214, 176), (318, 226), (426, 170), 260)
    hook = bezier((426, 170), (434, 164), (432, 152), 24)
    smile = stitched_line(mouth, 5, dash=10, gap=2, tick=8, tick_every=2)
    smile |= stitched_line(hook, 4, dash=8, gap=1)
    s.paint(smile, np.array([0.10, 0.06, 0.06]), 1.0, ks=0.35, sh=22, dh=3.2)
    # hilo suelto colgando de la comisura izquierda
    loose = bezier((214, 177), (200, 192), (212, 214), 40)
    s.paint(stroke_mask(loose, 2), THREAD_L, 0.95, dh=1.2)
    # pliegue de unión: oscurecer donde se juntan partes (cavidad)
    cav = blur(s.h, 6) - s.h
    s.ao *= np.clip(1 - 0.011 * np.clip(cav, 0, 40), 0.55, 1)
    # pelusa en la silueta
    grow = ndi.binary_dilation(s.mask, iterations=2) & ~s.mask
    fuzz = grow & (np.random.RandomState(5).rand(H, W) < 0.30)
    s.h[fuzz] = 1.5
    s.alb[fuzz] = FAB * 0.78
    s.ks[fuzz] = 0
    s.mask |= fuzz
    # arrugas suaves y manchas de uso (peluche querido): ligero ruido de albedo ya incluido; mancha en la mejilla
    s.paint(((XX - 360) ** 2 / 400 + (YY - 148) ** 2 / 120) < 1, np.array([0.44, 0.50, 0.34]), 0.25)
    return s


# ------------------------------------------------------------------ MANOS
SKIN = np.array([0.90, 0.66, 0.52], np.float32)
SKIN_FLUSH = np.array([0.86, 0.46, 0.40], np.float32)
SKIN_FOLD = np.array([0.62, 0.36, 0.30], np.float32)
NAIL = np.array([0.95, 0.78, 0.74], np.float32)
NAIL_L = np.array([0.98, 0.90, 0.86], np.float32)
SLEEVE = np.array([0.88, 0.50, 0.16], np.float32)
SLEEVE_D = np.array([0.62, 0.30, 0.10], np.float32)
RED = np.array([0.78, 0.20, 0.16], np.float32)


class HandSpec:
    def __init__(self, side, theta, knuckle, lengths, curls, spread, nail_bitten=None, seed=0):
        self.side, self.theta, self.knuckle = side, theta, knuckle
        self.lengths, self.curls, self.spread = lengths, curls, spread
        self.nail_bitten = nail_bitten
        self.seed = seed


def P(side, x, y):
    return (x, y) if side > 0 else (W - x, y)


def build_hand(sp):
    """Devuelve (base_surf, [finger_surfs]) en coordenadas de pantalla."""
    side = sp.side
    th = np.radians(sp.theta)
    a = np.array([np.cos(th), -np.sin(th)], np.float32)          # eje de la mano (hacia los dedos)
    p = np.array([np.sin(th), np.cos(th)], np.float32)           # perpendicular (hacia el meñique)
    if side < 0:
        a = np.array([-a[0], a[1]], np.float32)
        p = np.array([-p[0], p[1]], np.float32)
    K = np.array(P(side, *sp.knuckle), np.float32)
    rngh = np.random.RandomState(sp.seed)
    fine = 1 + 0.035 * noise(1.0, 20 + sp.seed) + 0.02 * noise(3.5, 30 + sp.seed)
    skin = SKIN * fine[..., None]

    # ---- base: dorso (elipsoide alargado), nudillos, tendones, muñeca, manga, pulgar
    base = Surf()
    c0 = K - a * 40
    dx, dy = XX - c0[0], YY - c0[1]
    ua = (dx * a[0] + dy * a[1])
    up = (dx * p[0] + dy * p[1])
    width = 38 * (0.74 + 0.26 * (ua + 46) / 92)
    d = (ua / 50) ** 2 + (up / width) ** 2
    dm = d < 1
    dorsum = (24 * np.sqrt(np.clip(1 - d, 0, 1))).astype(np.float32)
    # nudillos y tendones
    kn = []
    for i in range(4):
        kp = K + p * (i - 1.5) * sp.spread
        kn.append(kp)
        dorsum += 4.6 * np.exp(-((XX - kp[0]) ** 2 + (YY - kp[1]) ** 2) / (2 * 6.5 ** 2))
        lat = ((XX - kp[0]) * p[0] + (YY - kp[1]) * p[1])
        along = ((XX - kp[0]) * a[0] + (YY - kp[1]) * a[1])
        ridge = np.exp(-lat ** 2 / (2 * 2.6 ** 2)) * ((along < 0) & (along > -62)) * (1 - np.clip(-along / 62, 0, 1) * 0.6)
        dorsum += 2.0 * ridge
    base.put(dorsum, dm | (dorsum > 3), skin, ks=0.14, sh=14, sss=0.45, rim=0.5)
    # muñeca
    wr = K - a * 88
    h, m, _, _, _ = capsule([tuple(K - a * 70), tuple(wr), tuple(K - a * 120)], [28, 27, 29], 0.95)
    base.put(h, m, skin, ks=0.1, sh=12, sss=0.45, rim=0.4)
    # manga de lana con puño acanalado y línea roja
    cs = K - a * 108
    pts = [tuple(cs), tuple(cs - a * 150), tuple(cs - a * 330)]
    h, m, s_arc, u_lat, rr = capsule(pts, [42, 48, 56], 0.85)
    k1 = np.sin(2 * np.pi * u_lat / 4.0)
    k2 = np.sin(2 * np.pi * (s_arc * 0.5 + 2 * np.abs(((u_lat) % 4) - 2)) / 5.0)
    knit = np.where(s_arc < 16, 0.78 + 0.22 * k1, 0.86 + 0.12 * k2) * (1 + 0.05 * noise(1.0, 41))
    sl = SLEEVE * knit[..., None]
    sl = np.where((s_arc < 16)[..., None], SLEEVE_D * knit[..., None] * 1.15, sl)
    stripe = (s_arc > 34) & (s_arc < 44)
    sl = np.where(stripe[..., None], RED * (0.9 + 0.1 * k2)[..., None], sl)
    base.put(h, m, sl, ks=0.04, sh=6, z0=-2)
    base.h += blur(m.astype(np.float32), 2) * (np.abs(k1) * 1.2)
    # pulgar (por debajo del peluche, apretando)
    t0 = K - a * 54 + p * 30
    td = rot(tuple(a), -8)
    tp, _ = seg_points(tuple(t0), tuple(a), 66, [-22, -18], [0.46, 0.30, 0.24], None)
    h, m, ts, tu, tr = capsule(tp, [13.5, 12.2, 10.4, 8.8], 1.0)
    base.put(h, m, skin, ks=0.12, sh=14, sss=0.45, z0=4, rim=0.4)
    # arrugas en el pulgar (articulación) y mancha de tinta azul (imperfección)
    for sj in (30, 52):
        w = np.exp(-((ts - sj + 0.012 * tu ** 2) / 1.1) ** 2) * (np.abs(tu) < tr * 0.85) * m
        base.alb *= (1 - 0.42 * w)[..., None] * 0 + (1 - 0.42 * w)[..., None]
    # arrugas del dorso, venas muy tenues y pecas
    for i in range(3):
        kp = kn[i + 1] - a * 18
        w = np.exp(-(((XX - kp[0]) * a[0] + (YY - kp[1]) * a[1] + 0.015 * ((XX - kp[0]) * p[0] + (YY - kp[1]) * p[1]) ** 2) / 1.0) ** 2)
        w *= (np.abs((XX - kp[0]) * p[0] + (YY - kp[1]) * p[1]) < 8) * dm
        base.alb *= (1 - 0.26 * w)[..., None]
    fr = np.random.RandomState(sp.seed + 3)
    for _ in range(4):
        fx, fy = K - a * fr.uniform(30, 70) + p * fr.uniform(-22, 22)
        fm = ((XX - fx) ** 2 + (YY - fy) ** 2) < 2.4
        base.paint(fm & dm, np.array([0.55, 0.34, 0.26]), 0.7)
    base.paint(dm, SKIN_FLUSH, 0.10 * smoothstep(-20, 30, ua))
    base.ao *= 1 - 0.0 * base.h

    # ---- dedos: 4 capas independientes
    fingers = []
    base_r = [9.8, 10.4, 9.6, 8.2]
    for i in range(4):
        f = Surf()
        L = sp.lengths[i]
        cu = sp.curls[i]
        pts, dend = seg_points(tuple(kn[i] + a * 2), tuple(a), L, cu, [0.46, 0.30, 0.24], None)
        r0 = base_r[i]
        radii = [r0, r0 * 0.92, r0 * 0.85, r0 * 0.76]
        h, m, s_arc, u_lat, rr = capsule(pts, radii, 1.0)
        # carne con trama de piel fina
        ftex = SKIN * (1 + 0.03 * noise(1.0, 50 + i + sp.seed))[..., None]
        # rubor: articulaciones y yema
        f.put(h, m, ftex, ks=0.16, sh=15, sss=0.5, rim=0.5)
        seg_len = [L * 0.46, L * 0.30, L * 0.24]
        j1, j2 = seg_len[0], seg_len[0] + seg_len[1]
        # pliegues de las articulaciones (2-3 arrugas por nudillo), más marcadas en los costados
        for jj, (sj, nlines) in enumerate(((j1, 3), (j2, 2))):
            for k in range(nlines):
                off = (k - (nlines - 1) / 2) * 2.7
                curve = 0.018 if jj == 0 else 0.022
                w = np.exp(-((s_arc - (sj + off) + curve * u_lat ** 2) / 0.95) ** 2)
                w = w * (np.abs(u_lat) < rr * 0.9) * (0.6 + 0.4 * (np.abs(u_lat) / rr))
                f.alb *= (1 - 0.40 * w)[..., None] * 1 + 0 * f.alb
                f.h -= 0.8 * w
            band = np.exp(-((s_arc - sj) / 5.5) ** 2) * m
            f.paint(m, SKIN_FLUSH, 0.22 * band)
        # yema del dedo (rubor) y brillo graso en el nudillo
        tip = smoothstep(j2 + seg_len[2] * 0.55, j2 + seg_len[2] * 1.0, s_arc)
        f.paint(m, SKIN_FLUSH, 0.40 * tip)
        # uña
        P2 = np.array(pts[2]);
        P3 = np.array(pts[3])
        dd = P3 - P2
        dl = np.linalg.norm(dd)
        dd = dd / dl
        nc = P2 + dd * (dl * 0.55)
        ndx, ndy = XX - nc[0], YY - nc[1]
        nu = ndx * dd[0] + ndy * dd[1]
        nv = -ndx * dd[1] + ndy * dd[0]
        nl, nw = dl * 0.44, rr * 0.62 + 0.2
        if sp.nail_bitten == i:
            nl, nw = nl * 0.62, nw * 0.92
        nm = ((nu / nl) ** 2 + (nv / nw) ** 2 < 1) & m
        grad = np.clip((nu / nl + 1) / 2, 0, 1)               # 0 = cutícula, 1 = borde libre
        nail_alb = NAIL[None, None, :] * (1 - grad[..., None] * 0) + 0
        nail_alb = np.where((grad < 0.28)[..., None], NAIL_L, np.where((grad > 0.86)[..., None], NAIL_L * 1.02, NAIL))
        nail_alb = np.broadcast_to(nail_alb, (H, W, 3))
        f.paint(nm, nail_alb, 0.97, ks=0.65, sh=34)
        cut = (np.abs(((nu / nl) ** 2 + (nv / nw) ** 2) - 0.85) < 0.16) & ((nu / nl) < -0.1) & m
        f.paint(cut, SKIN_FOLD, 0.75)
        edge = ((nu / nl) ** 2 + (nv / nw) ** 2 > 0.80) & nm
        f.paint(edge, np.array([0.70, 0.44, 0.40]), 0.55)
        # el borde de la uña sobresale un pelín
        f.h += 1.1 * blur(nm.astype(np.float32), 0.8)
        if sp.nail_bitten == i:
            rag = (np.random.RandomState(8).rand(H, W) < 0.5) & nm & (grad > 0.78)
            f.paint(rag, SKIN, 0.9)
        fingers.append((f, m, pts))
    # imperfecciones: marca de bolígrafo azul en el índice y rasguño en el dorso (según el lado)
    if side > 0:
        f0, m0, pts0 = fingers[0]
        bx, by = pts0[1]
        ink = ((XX - (bx + 3)) ** 2 + (YY - (by - 3)) ** 2) < 7
        f0.paint(ink & m0, np.array([0.22, 0.32, 0.62]), 0.55)
    else:
        sc = stroke_mask([tuple(K - a * 26 + p * (-6)), tuple(K - a * 40 + p * 6)], 1)
        base.paint(sc & dm, np.array([0.70, 0.28, 0.24]), 0.8)
        sc2 = stroke_mask([tuple(K - a * 30 + p * (-2)), tuple(K - a * 42 + p * 9)], 1)
        base.paint(sc2 & dm, np.array([0.62, 0.30, 0.26]), 0.55)
    return base, [f for f, _, _ in fingers]


# ------------------------------------------------------------------ composición, sombras y cuantización
def main():
    plush = build_plush()
    left = HandSpec(+1, 24, (214, 306), [68, 74, 68, 52], [[20, 30], [22, 32], [24, 36], [28, 40]], 20.5, nail_bitten=None, seed=1)
    right = HandSpec(-1, 20, (212, 310), [66, 72, 70, 54], [[18, 34], [24, 28], [20, 38], [30, 36]], 21.0, nail_bitten=3, seed=2)
    lb, lf = build_hand(left)
    rb, rf = build_hand(right)
    # orden de dibujo de los dedos: meñique -> índice (el índice queda arriba)
    lf = lf[::-1]
    rf = rf[::-1]
    layers = [('plush', plush), ('hand_l', lb), ('hand_r', rb)] + \
             [('l_%d' % (3 - k), f) for k, f in enumerate(lf)] + [('r_%d' % (3 - k), f) for k, f in enumerate(rf)]
    # sombras: cada capa recibe la sombra de las que se dibujan por encima
    masks = [s.mask for _, s in layers]
    for i, (name, s) in enumerate(layers):
        above = np.zeros((H, W), bool)
        for mk in masks[i + 1:]:
            above |= mk
        if above.any():
            s.ao *= shadow_from(above, 9, 11, 8.0, 0.62) * shadow_from(above, 3, 4, 2.6, 0.38)
    # color final
    rgbs = [s.shade() for _, s in layers]
    # cuantización conjunta (paleta única) con un dither ordenado muy sutil
    bayer = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]], np.float32) / 16.0 - 0.5
    tile = np.tile(bayer, (H // 4 + 1, W // 4 + 1))[:H, :W]
    px = []
    for rgb, (_, s) in zip(rgbs, layers):
        r = np.clip(rgb * 255 + tile[..., None] * 3.2, 0, 255).astype(np.uint8)
        px.append(r[s.mask])
    allpx = np.concatenate(px, 0)
    strip = Image.fromarray(allpx.reshape(1, -1, 3), 'RGB')
    q = strip.quantize(colors=176, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
    pal = np.array(q.getpalette()[:176 * 3], np.uint8).reshape(-1, 3)
    qi = np.array(q).reshape(-1)
    out_layers = []
    o = 0
    for (name, s), p_ in zip(layers, px):
        n = len(p_)
        idx = np.zeros((H, W), np.int32)
        idx[s.mask] = qi[o:o + n] + 1            # 0 = transparente
        o += n
        ys, xs = np.nonzero(s.mask)
        x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
        out_layers.append((name, int(x0), int(y0), idx[y0:y1, x0:x1]))
    emit(pal, out_layers)
    preview(pal, out_layers)


ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-'


def b64(v):
    return ALPHABET[v // 64] + ALPHABET[v % 64]


def rle_tokens(a):
    flat = a.flatten()
    toks, i, n = [], 0, len(flat)
    while i < n:
        v, j = int(flat[i]), i
        while j < n and flat[j] == v and j - i < 70:
            j += 1
        toks.append(b64(v) + chr(48 + (j - i)))
        i = j
    return toks


def esc(s):
    return s.replace('\\', '\\\\').replace('$', '\\$').replace('"', '\\"')


def emit(pal, layers):
    L = []
    w = L.append
    w('package com.terror2d.pixel')
    w('')
    w('/**')
    w(' * DATOS GENERADOS por tools/sprite_gen (python3 conversation_art.py). NO editar a mano: edita el generador.')
    w(' * Arte de la ESCENA DE CONVERSACIÓN (v0.7): manos del niño + peluche, 640x360 (1 px = 0.5 px lógicos).')
    w(' * Cada capa es un recorte (x, y, ancho, alto) con índices de paleta (0 = transparente) en tramos RLE de 3 caracteres:')
    w(' * 2 caracteres base-64 (índice) + 1 carácter 48+longitud. Se parte en cadenas de <= 12000 tramos (límite de la JVM).')
    w(' */')
    w('object ConversationArtData {')
    w(f'    const val WIDTH = {W}')
    w(f'    const val HEIGHT = {H}')
    w('    const val ALPHABET = "%s"' % ALPHABET)
    w('')
    w('    val PALETTE: IntArray = intArrayOf(0x00000000.toInt(), ' + ', '.join('0xFF%02X%02X%02X.toInt()' % tuple(c) for c in pal) + ')')
    w('')
    w('    val LAYER_NAMES: Array<String> = arrayOf(' + ', '.join('"%s"' % n for n, _, _, _ in layers) + ')')
    w('    /** [x, y, ancho, alto] de cada capa dentro de los 640x360. */')
    w('    val LAYER_RECT: Array<IntArray> = arrayOf(' + ', '.join('intArrayOf(%d, %d, %d, %d)' % (x, y, a.shape[1], a.shape[0]) for _, x, y, a in layers) + ')')
    w('')
    w('    val LAYER_DATA: Array<Array<String>> = arrayOf(')
    blocks = []
    total = 0
    for name, x, y, a in layers:
        toks = rle_tokens(a)
        total += len(toks)
        chunks = [toks[i:i + 12000] for i in range(0, len(toks), 12000)]
        blocks.append('        arrayOf(\n' + ',\n'.join('            "' + esc(''.join(c)) + '"' for c in chunks) + '\n        )')
    w(',\n'.join(blocks))
    w('    )')
    w('}')
    os.makedirs(os.path.dirname(OUT_KT), exist_ok=True)
    open(OUT_KT, 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    print('escrito', os.path.abspath(OUT_KT), os.path.getsize(OUT_KT), 'bytes;', total, 'tramos;', len(pal), 'colores')


def preview(pal, layers):
    full = np.zeros((H, W, 3), np.uint8)
    full[:] = (4, 4, 5)
    for name, x, y, a in layers:
        m = a > 0
        rgb = pal[np.clip(a - 1, 0, len(pal) - 1)]
        region = full[y:y + a.shape[0], x:x + a.shape[1]]
        region[m] = rgb[m]
    os.makedirs('/home/claude/preview', exist_ok=True)
    Image.fromarray(full).save('/home/claude/preview/conv.png')
    Image.fromarray(full).resize((W * 2, H * 2), Image.NEAREST).crop((200, 160, 1080, 720)).save('/home/claude/preview/conv_zoom.png')


if __name__ == '__main__':
    main()
