package com.terror2d.audio

import com.terror2d.core.WorldMode

/**
 * API de audio de ALTO NIVEL de MYMom (v0.7). La lógica de juego pide EVENTOS de audio ("suena la voz de la rana con esta
 * emoción", "pasos sobre madera") y no sabe nada de síntesis. Quien implementa el puerto es [AudioEngine] (síntesis
 * procedural en tiempo real) o [NullAudioPort] (silencio: tests, equipos sin audio).
 *
 * Todas las llamadas son baratas y NO bloquean: solo dejan una orden en una cola que consume el hilo de audio.
 */

/** Quién habla. DOCTOR, NEIGHBOR y MONSTER están preparados (perfil registrado) pero todavía no se usan en 0.7. */
enum class VoiceId { CHILD, MOTHER, FROG, DOCTOR, NEIGHBOR, MONSTER }

/** Emoción de una voz: modula tono, ritmo, respiración y vibrato. */
enum class Emotion { NEUTRAL, SOFT, WARM, HAPPY, WORRIED, SAD, TENSE, TIRED, CALM }

/** Forma del sonido vocal: balbuceo de sílabas no lingüísticas, un "mmm" largo o un "hm" corto. */
enum class VoiceKind { BABBLE, HUM, HM }

/** Efectos de sonido procedurales. */
enum class SfxId {
    FOOTSTEP, PICKUP, DROP, INTERACT, DOCUMENT_OPEN, PAPER, GLASS, WATER, MEDICINE,
    DOOR_OPEN, DOOR_CLOSE, BREATH, THUD, CLICK, HEARTBEAT, CLOTH, PLUSH_TAP, TEXT_TICK, CHIME
}

/** Superficie sobre la que suenan los pasos. HOSPITAL está preparada aunque no se use todavía. */
enum class Surface { WOOD, TILE, GROUND, HOSPITAL }

/** Piezas / estados de música. SILENCE = silencio dinámico (solo queda el murmullo de la casa). */
enum class MusicId { SILENCE, HOME, CHILD_THEME, FROG_SCENE, TENSION }

/** Perfiles de ambiente (qué canales de la casa están presentes). */
enum class AmbienceId { SILENT, HOUSE, CONVERSATION }

interface AudioPort {
    /** Una frase vocal. [units] = sílabas (BABBLE) o décimas de segundo x2.5 (HUM); [seed] varía el balbuceo. */
    fun playVoice(voice: VoiceId, emotion: Emotion, intensity: Float, kind: VoiceKind = VoiceKind.BABBLE, units: Int = 3, seed: Int = 0)

    fun playSfx(sfx: SfxId, intensity: Float = 1f, surface: Surface = Surface.WOOD)

    fun playMusic(music: MusicId, fadeSeconds: Float = 2f)

    fun setAmbience(ambience: AmbienceId, fadeSeconds: Float = 2f)

    /** NORMAL y TRAUMA comparten los mismos eventos con parámetros distintos (tono, reverb, distorsión, resonancia). */
    fun setWorld(mode: WorldMode)

    /** Baja temporalmente música y ambiente (escenas de conversación). 1 = sin bajar. */
    fun duck(level: Float, seconds: Float)

    fun stopAll()
}

/** Puerto vacío: no suena nada. */
object NullAudioPort : AudioPort {
    override fun playVoice(voice: VoiceId, emotion: Emotion, intensity: Float, kind: VoiceKind, units: Int, seed: Int) {}
    override fun playSfx(sfx: SfxId, intensity: Float, surface: Surface) {}
    override fun playMusic(music: MusicId, fadeSeconds: Float) {}
    override fun setAmbience(ambience: AmbienceId, fadeSeconds: Float) {}
    override fun setWorld(mode: WorldMode) {}
    override fun duck(level: Float, seconds: Float) {}
    override fun stopAll() {}
}
