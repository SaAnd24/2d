package com.terror2d.scene

import com.terror2d.conversation.ConversationDef
import com.terror2d.core.WorldMode
import com.terror2d.events.EventTrigger
import com.terror2d.story.SceneScript

/** Punto de aparición: X del CENTRO de los pies y hacia dónde mira. La Y la da el suelo del segmento. */
class SpawnPoint(val x: Float, val facing: Int = 1)

/**
 * Descripción de una escena (p. ej. una casa): una semilla y una lista de segmentos laterales
 * conectados por puertas, más reglas de eventos opcionales. Futuras escenas solo necesitan crear
 * una definición, sin tocar el motor.
 */
class SceneDefinition(
    val id: String,
    val seed: Long,
    val segments: List<RoomSegment>,
    val startSegmentId: String,
    val startSpawnId: String = "start",
    val triggers: List<EventTrigger> = emptyList(),
    val scripts: List<SceneScript> = emptyList(),
    /**
     * Versiones TRAUMA de los segmentos (mismo id que el segmento NORMAL). Vacío en v0.5: la arquitectura
     * ya contempla el segundo mundo, pero no existe ningún mapa del Mundo Trauma todavía.
     */
    val traumaSegments: List<RoomSegment> = emptyList(),
    /** v0.7: conversaciones del compañero de esta escena (datos puros; ver [com.terror2d.conversation.Conversations]). */
    val conversations: List<ConversationDef> = emptyList()
) {
    /** Segmento [id] en el mundo [mode]; si ese mundo no define una variante, se usa el NORMAL. */
    fun segmentFor(id: String, mode: WorldMode): RoomSegment {
        if (mode == WorldMode.TRAUMA) {
            val v = traumaSegments.firstOrNull { it.id == id }
            if (v != null) return v
        }
        return segment(id)
    }

    fun segment(id: String): RoomSegment =
        segments.firstOrNull { it.id == id }
            ?: throw IllegalArgumentException("Segmento no definido en $id: $id")
}
