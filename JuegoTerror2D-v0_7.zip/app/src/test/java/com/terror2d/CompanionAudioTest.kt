package com.terror2d

import com.terror2d.audio.AmbienceId
import com.terror2d.audio.AudioEngine
import com.terror2d.audio.AudioPort
import com.terror2d.audio.AudioDirector
import com.terror2d.audio.Emotion
import com.terror2d.audio.MusicId
import com.terror2d.audio.OfflineAudioSink
import com.terror2d.audio.SfxId
import com.terror2d.audio.Surface
import com.terror2d.audio.VoiceId
import com.terror2d.audio.VoiceKind
import com.terror2d.audio.VoiceProfiles
import com.terror2d.audio.VoiceSynth
import com.terror2d.audio.WorldAudioProfile
import com.terror2d.companion.CompanionSlot
import com.terror2d.companion.CompanionState
import com.terror2d.companion.HandState
import com.terror2d.companion.Hands
import com.terror2d.conversation.ConversationDef
import com.terror2d.conversation.ConversationLine
import com.terror2d.conversation.ConversationSystem
import com.terror2d.conversation.ConversationView
import com.terror2d.conversation.Speaker
import com.terror2d.conversation.VoiceCue
import com.terror2d.core.GameState
import com.terror2d.core.WorldMode
import com.terror2d.events.EventType
import com.terror2d.events.GameEvent
import com.terror2d.input.InputAction
import com.terror2d.input.InputController
import com.terror2d.inventory.ItemRegistry
import com.terror2d.pixel.ConversationArtData
import com.terror2d.scene.HouseDefinition
import com.terror2d.scene.HouseDefinition.KID
import com.terror2d.scene.HouseScene
import com.terror2d.story.StoryFlags
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/** Pruebas de 0.7: COMPANION SLOT + HAND SLOT, conversaciones, escena en primera persona y audio procedural. */
class CompanionAudioTest {

    // ------------------------------------------------------------------ harness

    private class World {
        val state = GameState()
        val input = InputController()
        val scene = HouseScene(HouseDefinition.DEFAULT_SEED).also { it.load(state) }
        val log = RecordingAudio()

        init {
            scene.loadSegment(KID, "start", state)
            state.audio = log
        }

        fun step(n: Int = 1) {
            repeat(n) {
                scene.update(1f / 60f, input, state)
                input.endFrame()
            }
        }

        fun pressAction() {
            input.setAction(InputAction.INTERACT, true)
            step(1)
            input.setAction(InputAction.INTERACT, false)
        }

        fun pressTalk() {
            input.setAction(InputAction.TALK, true)
            step(1)
            input.setAction(InputAction.TALK, false)
        }

        fun tap() {
            input.setPointer(true, 100f, 100f)
            step(1)
            input.setPointer(false, 100f, 100f)
            step(1)
        }

        /** Recoge el peluche de la habitación del niño. */
        fun pickUpPlush() {
            scene.player.x = 120f
            step()
            pressAction()
            step(50)
            scene.dialogue.clear()
        }
    }

    private class RecordingAudio : AudioPort {
        val calls = ArrayList<String>()
        override fun playVoice(voice: VoiceId, emotion: Emotion, intensity: Float, kind: VoiceKind, units: Int, seed: Int) {
            calls.add("voice:$voice:$kind")
        }

        override fun playSfx(sfx: SfxId, intensity: Float, surface: Surface) {
            calls.add("sfx:$sfx")
        }

        override fun playMusic(music: MusicId, fadeSeconds: Float) {
            calls.add("music:$music")
        }

        override fun setAmbience(ambience: AmbienceId, fadeSeconds: Float) {
            calls.add("amb:$ambience")
        }

        override fun setWorld(mode: WorldMode) {
            calls.add("world:$mode")
        }

        override fun duck(level: Float, seconds: Float) {
            calls.add("duck:$level")
        }

        override fun stopAll() {
            calls.add("stop")
        }
    }

    private fun engine(seed: Int = 7): AudioEngine = AudioEngine(OfflineAudioSink(), 44100, seed).also { it.enableOfflineMode() }

    private fun render(e: AudioEngine, blocks: Int): FloatArray {
        val out = FloatArray(blocks * AudioEngine.BLOCK)
        val buf = FloatArray(AudioEngine.BLOCK)
        for (b in 0 until blocks) {
            e.renderBlock(buf, AudioEngine.BLOCK)
            System.arraycopy(buf, 0, out, b * AudioEngine.BLOCK, AudioEngine.BLOCK)
        }
        return out
    }

    private fun peak(a: FloatArray): Float {
        var p = 0f
        for (x in a) if (abs(x) > p) p = abs(x)
        return p
    }

    private fun energy(a: FloatArray, from: Int = 0, to: Int = a.size): Float {
        var s = 0.0
        for (i in from until to) s += a[i] * a[i]
        return (s / (to - from).coerceAtLeast(1)).toFloat()
    }

    // ------------------------------------------------------------------ COMPANION SLOT + HAND SLOT

    @Test
    fun companionStatesAndHandStates() {
        val c = CompanionSlot()
        assertEquals(CompanionState.NOT_FOUND, c.state)
        assertFalse(c.canTalk(HandState.EMPTY))
        c.discover()
        assertEquals(CompanionState.ON_FLOOR, c.state)
        assertTrue(c.pickUp(ItemRegistry.FROG_PLUSH))
        assertEquals(CompanionState.ON_BACK, c.state)
        assertFalse("no se recoge dos veces", c.pickUp(ItemRegistry.FROG_PLUSH))
        assertTrue(c.canTalk(HandState.EMPTY))
        assertFalse("con objeto en las manos no se habla", c.canTalk(HandState.HOLDING_WATER))
        assertTrue(c.beginTalk())
        assertEquals(CompanionState.TALKING, c.state)
        assertTrue(c.isCarried)
        c.endTalk()
        assertEquals(CompanionState.ON_BACK, c.state)
        assertEquals(HandState.EMPTY, Hands.stateOf(null))
        assertEquals(HandState.HOLDING_WATER, Hands.stateOf(ItemRegistry.WATER_GLASS))
        assertEquals(HandState.HOLDING_MEDICINE, Hands.stateOf(ItemRegistry.PILL_BOX_ORANGE))
        assertEquals(HandState.HOLDING_OBJECT, Hands.stateOf("otra_cosa"))
    }

    @Test
    fun plushDoesNotConsumeTheHandSlot() {
        val w = World()
        w.pickUpPlush()
        val inv = w.state.inventory
        assertEquals(CompanionState.ON_BACK, inv.companion.state)
        assertEquals(HandState.EMPTY, inv.handState)
        // el vaso sigue cabiendo en las manos y no desplaza al peluche
        assertTrue(inv.add(ItemRegistry.WATER_GLASS))
        assertTrue(inv.hold(ItemRegistry.WATER_GLASS))
        assertEquals(HandState.HOLDING_WATER, inv.handState)
        assertEquals(CompanionState.ON_BACK, inv.companion.state)
        assertEquals(ItemRegistry.FROG_PLUSH, inv.companion.itemId)
        // ni las medicinas lo reemplazan
        inv.remove(ItemRegistry.WATER_GLASS)
        assertTrue(inv.add(ItemRegistry.PILL_BOX_BLUE))
        assertTrue(inv.hold(ItemRegistry.PILL_BOX_BLUE))
        assertEquals(HandState.HOLDING_MEDICINE, inv.handState)
        assertEquals(CompanionState.ON_BACK, inv.companion.state)
    }

    // ------------------------------------------------------------------ HABLAR

    @Test
    fun talkButtonOnlyWithCompanionOnBackAndEmptyHands() {
        val w = World()
        w.step(3)
        assertFalse("sin peluche no hay HABLAR", w.input.talkEnabled)
        w.pickUpPlush()
        w.step(3)
        assertTrue(w.input.talkEnabled)
        assertEquals("HABLAR CON RANITA", w.input.talkLabel)
        // con un objeto en las manos desaparece: primero hay que dejarlo
        w.state.inventory.add(ItemRegistry.WATER_GLASS)
        w.state.inventory.hold(ItemRegistry.WATER_GLASS)
        w.step(3)
        assertFalse(w.input.talkEnabled)
        w.pressTalk()
        assertFalse("no se inicia la conversación con las manos ocupadas", w.scene.conversation.isActive)
        w.state.inventory.release()
        w.step(3)
        assertTrue(w.input.talkEnabled)
    }

    @Test
    fun talkStartsTheFirstPersonSceneAndReturnsToGameplay() {
        val w = World()
        w.pickUpPlush()
        w.step(3)
        w.pressTalk()
        val conv = w.scene.conversation
        assertTrue(conv.isActive)
        assertEquals(CompanionState.TALKING, w.state.inventory.companion.state)
        assertTrue(w.scene.events.wasPosted(EventType.FROG_TALK))
        assertTrue(w.scene.events.wasPosted(EventType.CONVERSATION_STARTED, "frog_idle"))
        // el niño no se mueve y no hay botones: el dedo es un puntero
        val x = w.scene.player.x
        w.input.setDirection(false, true)
        w.step(30)
        w.input.setDirection(false, false)
        assertEquals(x, w.scene.player.x, 0f)
        assertFalse(w.input.talkEnabled)
        // se juega la conversación hasta el final tocando la pantalla
        var n = 0
        while (conv.isActive && n < 1500) {
            if (conv.waitingForTap) w.tap() else w.step(1)
            n++
        }
        assertFalse(conv.isActive)
        assertEquals(CompanionState.ON_BACK, w.state.inventory.companion.state)
        assertTrue(w.scene.events.wasPosted(EventType.CONVERSATION_ENDED, "frog_idle"))
        // vuelve el gameplay: HABLAR otra vez disponible (cooldown aparte) y el niño se vuelve a mover
        w.step(200)
        assertTrue(w.input.talkEnabled)
        w.input.setDirection(false, true)
        w.step(30)
        w.input.setDirection(false, false)
        assertTrue(w.scene.player.x > x)
    }

    // ------------------------------------------------------------------ disparadores temporales

    @Test
    fun waterDeliveredTriggersTheFirstConversation() {
        val w = World()
        w.pickUpPlush()
        // la bandera narrativa publica también el evento de alto nivel WATER_DELIVERED
        w.scene.events.post(EventType.ON_STORY_FLAG, StoryFlags.WATER_DELIVERED, KID)
        assertTrue(w.scene.events.wasPosted(EventType.WATER_DELIVERED))
        assertFalse("hay una pausa antes de hablar", w.scene.conversation.isActive)
        w.step(60)
        assertFalse(w.scene.conversation.isActive)
        w.step(120)
        assertTrue(w.scene.conversation.isActive)
        assertEquals("frog_after_water", w.scene.conversation.def?.id)
        var n = 0
        val seen = ArrayList<String>()
        while (w.scene.conversation.isActive && n < 2000) {
            val l = w.scene.conversation.line
            if (l != null && w.scene.conversation.visibleChars >= l.text.length && l.text !in seen) seen.add(l.text)
            if (w.scene.conversation.waitingForTap) w.tap() else w.step(1)
            n++
        }
        assertTrue(seen.contains("¿Ya terminaste?"))
        assertEquals(1, w.scene.conversations.timesPlayed("frog_after_water"))
        assertTrue(w.log.calls.any { it.startsWith("voice:FROG") })
        // una sola vez
        w.scene.events.post(EventType.WATER_DELIVERED, "x", KID)
        w.step(400)
        assertFalse(w.scene.conversation.isActive)
    }

    @Test
    fun medicinePuzzleCompletedTriggersTheSpecialPhrase() {
        val w = World()
        w.pickUpPlush()
        w.scene.events.post(EventType.MEDICINE_PUZZLE_COMPLETED, "medicine_puzzle", KID)
        w.step(60)
        assertFalse(w.scene.conversation.isActive)
        w.step(120)
        assertTrue(w.scene.conversation.isActive)
        assertEquals("frog_after_medicine", w.scene.conversation.def?.id)
        var shown = false
        var n = 0
        while (w.scene.conversation.isActive && n < 3000) {
            val l = w.scene.conversation.line
            if (l != null && l.text == "Sabía que eres un niño especial." && w.scene.conversation.visibleChars == l.text.length) shown = true
            if (w.scene.conversation.waitingForTap) w.tap() else w.step(1)
            n++
        }
        assertTrue("debe mostrarse la frase", shown)
        assertEquals(CompanionState.ON_BACK, w.state.inventory.companion.state)
    }

    @Test
    fun pendingConversationWaitsForTheCompanionAndEmptyHands() {
        val w = World()
        // sin peluche: el disparador queda pendiente y no habla solo
        w.scene.events.post(EventType.MEDICINE_PUZZLE_COMPLETED, "medicine_puzzle", KID)
        w.step(400)
        assertFalse(w.scene.conversation.isActive)
        assertEquals(1, w.scene.conversations.pendingCount)
        // al recoger el peluche (manos vacías) la conversación pendiente arranca tras la pausa
        w.pickUpPlush()
        w.step(300)
        assertTrue(w.scene.conversation.isActive)
    }

    // ------------------------------------------------------------------ sistema de conversaciones

    @Test
    fun conversationSystemHonoursPriorityCooldownAndRepeat() {
        val st = GameState()
        val line = listOf(ConversationLine(Speaker.COMPANION, "x"))
        val low = ConversationDef("low", line, triggerType = EventType.ON_DOOR_OPEN, delay = 0.5f, priority = 1, repeatable = true, cooldown = 5f)
        val high = ConversationDef("high", line, triggerType = EventType.ON_DOOR_OPEN, delay = 0.5f, priority = 9)
        val sys = ConversationSystem(listOf(low, high))
        sys.onEvent(GameEvent(EventType.ON_DOOR_OPEN, "d", "s"))
        assertEquals(2, sys.pendingCount)
        assertNull("aún dentro de la pausa", sys.update(0.3f, true, st))
        // si algo interrumpe la calma, la pausa se reinicia
        assertNull(sys.update(0.1f, false, st))
        assertNull(sys.update(0.3f, true, st))
        val first = sys.update(0.3f, true, st)
        assertEquals("gana la de mayor prioridad", "high", first?.id)
        sys.markStarted(first!!)
        sys.markEnded(first)
        val second = sys.update(0.6f, true, st)
        assertEquals("low", second?.id)
        sys.markStarted(second!!)
        sys.markEnded(second)
        // no repetibles: no vuelve a encolarse
        sys.onEvent(GameEvent(EventType.ON_DOOR_OPEN, "d", "s"))
        assertEquals("low en cooldown", 0, sys.pendingCount)
        assertFalse(sys.isPending("high"))
        sys.update(6f, true, st)
        sys.onEvent(GameEvent(EventType.ON_DOOR_OPEN, "d", "s"))
        assertTrue("tras el cooldown la repetible vuelve", sys.isPending("low"))
    }

    // ------------------------------------------------------------------ escena de primera persona: ritmo

    @Test
    fun conversationRhythmIsSoundSilenceBreathThenPhrase() {
        val def = com.terror2d.conversation.Conversations.defaults().first { it.id == "frog_after_medicine" }
        val audio = TimedAudio()
        val v = ConversationView()
        v.begin(def, audio)
        var t = 0f
        var textAt = -1f
        var steps = 0
        while (v.isActive && steps < 6000) {
            audio.now = t
            v.update(1f / 60f, false)
            if (textAt < 0f && v.visibleChars > 0) textAt = t
            t += 1f / 60f
            steps++
            if (v.waitingForTap) break
        }
        assertTrue("el texto aparece", textAt > 0f)
        val hum = audio.times["voice:HUM"] ?: -1f
        val breath = audio.times["sfx:BREATH"] ?: -1f
        assertTrue("primero el sonido suave del peluche", hum >= 0f)
        assertTrue("después la respiración", breath > hum)
        assertTrue("y por último la frase", textAt > breath)
        assertTrue("con un silencio apreciable antes de la frase", textAt - hum > 2.0f)
        // las manos tiemblan más durante la espera y el peluche no tiene ninguna animación
        assertTrue(v.handTremorIntensity > ConversationView.BASE_TREMOR + 0.3f)
        assertTrue(v.breathingIntensity > ConversationView.BASE_BREATHING + 0.15f)
    }

    private class TimedAudio : AudioPort {
        var now = 0f
        val times = HashMap<String, Float>()
        override fun playVoice(voice: VoiceId, emotion: Emotion, intensity: Float, kind: VoiceKind, units: Int, seed: Int) {
            times.putIfAbsent("voice:$kind", now)
        }

        override fun playSfx(sfx: SfxId, intensity: Float, surface: Surface) {
            times.putIfAbsent("sfx:$sfx", now)
        }

        override fun playMusic(music: MusicId, fadeSeconds: Float) {}
        override fun setAmbience(ambience: AmbienceId, fadeSeconds: Float) {}
        override fun setWorld(mode: WorldMode) {}
        override fun duck(level: Float, seconds: Float) {}
        override fun stopAll() {}
    }

    // ------------------------------------------------------------------ arte hiperdetallado

    @Test
    fun conversationArtDataIsConsistent() {
        val d = ConversationArtData
        assertEquals(11, d.LAYER_NAMES.size)
        assertEquals("plush", d.LAYER_NAMES[0])
        assertTrue(d.PALETTE.size in 100..300)
        assertEquals(0, d.PALETTE[0])
        for (i in d.LAYER_NAMES.indices) {
            val r = d.LAYER_RECT[i]
            assertTrue(r[2] > 0 && r[3] > 0)
            assertTrue(r[0] >= 0 && r[1] >= 0 && r[0] + r[2] <= d.WIDTH && r[1] + r[3] <= d.HEIGHT)
            var total = 0
            for (chunk in d.LAYER_DATA[i]) {
                var k = 0
                while (k + 2 < chunk.length) {
                    val idx = d.ALPHABET.indexOf(chunk[k]) * 64 + d.ALPHABET.indexOf(chunk[k + 1])
                    assertTrue("índice de paleta válido", idx in 0 until d.PALETTE.size)
                    total += chunk[k + 2].code - 48
                    k += 3
                }
            }
            assertEquals("capa ${d.LAYER_NAMES[i]} completa", r[2] * r[3], total)
        }
    }

    // ------------------------------------------------------------------ audio procedural

    @Test
    fun audioEngineRendersFiniteBoundedSound() {
        val e = engine()
        e.playSfx(SfxId.FOOTSTEP, 1f, Surface.WOOD)
        e.playVoice(VoiceId.FROG, Emotion.SOFT, 0.6f, VoiceKind.HUM, 3, 1)
        e.playMusic(MusicId.CHILD_THEME, 0.5f)
        e.setAmbience(AmbienceId.HOUSE, 0.5f)
        val out = render(e, 400)
        for (x in out) assertTrue(x.isFinite())
        assertTrue("suena", peak(out) > 0.01f)
        assertTrue("sin saturar", peak(out) <= 1.0f)
    }

    @Test
    fun audioIsDeterministicForTheSameSeed() {
        val a = engine(11)
        val b = engine(11)
        for (e in listOf(a, b)) {
            e.playVoice(VoiceId.CHILD, Emotion.HAPPY, 0.8f, VoiceKind.BABBLE, 5, 3)
            e.playSfx(SfxId.PICKUP, 1f, Surface.WOOD)
        }
        val x = render(a, 60)
        val y = render(b, 60)
        for (i in x.indices) assertEquals(x[i], y[i], 0f)
        val c = engine(12)
        c.playVoice(VoiceId.CHILD, Emotion.HAPPY, 0.8f, VoiceKind.BABBLE, 5, 3)
        c.playSfx(SfxId.PICKUP, 1f, Surface.WOOD)
        val z = render(c, 60)
        var diff = 0
        for (i in x.indices) if (x[i] != z[i]) diff++
        assertTrue("otra semilla da otra variación", diff > 0)
    }

    @Test
    fun voiceProfilesAreDifferentAndFutureOnesExist() {
        val sig = HashMap<VoiceId, FloatArray>()
        for (id in listOf(VoiceId.CHILD, VoiceId.MOTHER, VoiceId.FROG)) {
            val e = engine(5)
            e.playVoice(id, Emotion.NEUTRAL, 0.7f, VoiceKind.BABBLE, 4, 9)
            val o = render(e, 80)
            assertTrue("$id suena", energy(o) > 1e-7f)
            sig[id] = o
        }
        assertFalse(sig[VoiceId.CHILD]!!.contentEquals(sig[VoiceId.MOTHER]!!))
        assertFalse(sig[VoiceId.CHILD]!!.contentEquals(sig[VoiceId.FROG]!!))
        // la madre es más grave que el niño y que la rana
        assertTrue(VoiceProfiles.get(VoiceId.MOTHER).basePitch < VoiceProfiles.get(VoiceId.CHILD).basePitch)
        assertTrue(VoiceProfiles.get(VoiceId.CHILD).basePitch < VoiceProfiles.get(VoiceId.FROG).basePitch)
        // perfiles preparados para el futuro
        for (id in listOf(VoiceId.DOCTOR, VoiceId.NEIGHBOR, VoiceId.MONSTER)) assertEquals(id, VoiceProfiles.get(id).id)
        // las emociones modulan la voz
        val happy = engine(5).also { it.playVoice(VoiceId.MOTHER, Emotion.HAPPY, 0.7f, VoiceKind.BABBLE, 4, 9) }
        val sad = engine(5).also { it.playVoice(VoiceId.MOTHER, Emotion.SAD, 0.7f, VoiceKind.BABBLE, 4, 9) }
        assertFalse(render(happy, 60).contentEquals(render(sad, 60)))
    }

    @Test
    fun voiceDurationEstimateMatchesTheSynthesis() {
        val secs = VoiceSynth.estimateSeconds(VoiceKind.HUM, 3, Emotion.CALM, VoiceId.FROG)
        assertTrue(secs in 0.7f..1.2f)
        val e = engine()
        e.playVoice(VoiceId.FROG, Emotion.CALM, 0.8f, VoiceKind.HUM, 3, 1)
        val out = render(e, 200)           // ~2,3 s
        val blk = AudioEngine.BLOCK
        val early = energy(out, 0, blk * 40)
        val late = energy(out, blk * 150, blk * 200)
        assertTrue("el sonido acaba y deja silencio", early > late * 20f)
    }

    @Test
    fun footstepsDifferBySurface() {
        val outs = ArrayList<FloatArray>()
        for (s in Surface.values()) {
            val e = engine(3)
            e.playSfx(SfxId.FOOTSTEP, 1f, s)
            val o = render(e, 20)
            assertTrue("$s suena", peak(o) > 0.005f)
            outs.add(o)
        }
        for (i in 0 until outs.size) for (j in i + 1 until outs.size) assertFalse(outs[i].contentEquals(outs[j]))
    }

    @Test
    fun everySfxMakesSound() {
        for (s in SfxId.values()) {
            val e = engine(4)
            e.playSfx(s, 1f, Surface.WOOD)
            val o = render(e, 200)
            assertTrue("$s no suena", peak(o) > 0.002f)
            for (x in o) assertTrue(x.isFinite())
        }
    }

    @Test
    fun musicCanTransitionAndFallIntoDynamicSilence() {
        val e = engine(8)
        e.playMusic(MusicId.HOME, 0.2f)
        val home = render(e, 500)
        assertTrue(energy(home, 200 * 512, 500 * 512) > 1e-7f)
        e.playMusic(MusicId.SILENCE, 0.2f)
        render(e, 1000)           // deja que mueran las notas largas
        val after = render(e, 100)
        // solo queda el murmullo de la casa (ambiente SILENT), nunca silencio artificial total
        assertTrue(energy(after) < energy(home, 200 * 512, 500 * 512))
        assertEquals(MusicId.SILENCE, e.currentMusic)
        for (m in MusicId.values()) {
            val x = engine(2)
            x.playMusic(m, 0.1f)
            for (v in render(x, 600)) assertTrue(v.isFinite())
        }
    }

    @Test
    fun ambienceNeverFullySilentAndCanAppearAndDisappear() {
        val e = engine(6)
        val silent = render(e, 100)
        assertTrue("el murmullo de la casa nunca desaparece del todo", energy(silent) > 1e-9f)
        e.setAmbience(AmbienceId.HOUSE, 0.2f)
        val house = render(e, 800)
        assertTrue(energy(house, 400 * 512, 800 * 512) > energy(silent))
        e.setAmbience(AmbienceId.SILENT, 0.2f)
        val back = render(e, 600)
        assertTrue(energy(back, 400 * 512, 600 * 512) < energy(house, 400 * 512, 800 * 512))
    }

    @Test
    fun normalAndTraumaShareEventsWithDifferentParameters() {
        val n = WorldAudioProfile.of(WorldMode.NORMAL)
        val t = WorldAudioProfile.of(WorldMode.TRAUMA)
        assertTrue(t.pitchMul < n.pitchMul)
        assertTrue(t.reverbReturn > n.reverbReturn)
        assertTrue(t.drive > n.drive)
        assertTrue(t.lowpassHz < n.lowpassHz)
        assertTrue(t.resonanceMix > n.resonanceMix)
        val a = engine(9)
        val b = engine(9)
        b.setWorld(WorldMode.TRAUMA)
        for (e in listOf(a, b)) e.playSfx(SfxId.FOOTSTEP, 1f, Surface.TILE)
        render(a, 150)
        render(b, 150)
        for (e in listOf(a, b)) e.playSfx(SfxId.FOOTSTEP, 1f, Surface.TILE)   // MISMO evento, otro mundo
        val x = render(a, 40)
        val y = render(b, 40)
        assertFalse(x.contentEquals(y))
    }

    @Test
    fun voicePoolNeverGrowsUnderLoad() {
        val e = engine(1)
        repeat(300) { e.playSfx(SfxId.FOOTSTEP, 1f, Surface.WOOD) }
        render(e, 4)
        assertTrue(e.activeVoices <= 56)
        for (x in render(e, 100)) assertTrue(x.isFinite())
        e.stopAll()
        render(e, 2)
        assertEquals(0, e.activeVoices)
    }

    @Test
    fun audioEngineStartsStopsAndReleasesCleanly() {
        val sink = OfflineAudioSink()
        val e = AudioEngine(sink)
        e.start()
        assertTrue(e.isRunning)
        e.playSfx(SfxId.PICKUP, 1f, Surface.WOOD)
        Thread.sleep(120)
        e.stop()
        assertFalse(e.isRunning)
        assertTrue("el hilo escribió bloques", sink.written > 0)
        // se puede reanudar y liberar
        e.start()
        assertTrue(e.isRunning)
        e.release()
        assertFalse(e.isRunning)
        assertEquals(0, e.activeVoices)
    }

    // ------------------------------------------------------------------ GameLogic -> evento -> audio

    @Test
    fun gameplayEventsBecomeAudioRequestsOnlyThroughTheDirector() {
        val log = RecordingAudio()
        val d = AudioDirector(log) { Surface.TILE }
        d.onEvent(GameEvent(EventType.FOOTSTEP, "player", "s"))
        d.onEvent(GameEvent(EventType.ON_ITEM_PICKED, ItemRegistry.WATER_GLASS, "s"))
        d.onEvent(GameEvent(EventType.ON_DOCUMENT_READ, "doc", "s"))
        d.onEvent(GameEvent(EventType.COMPANION_PICKED_UP, ItemRegistry.FROG_PLUSH, "s"))
        d.onEvent(GameEvent(EventType.DIALOGUE_LINE, "MAMÁ", "s", 30))
        d.onEvent(GameEvent(EventType.DIALOGUE_LINE, "KID", "s", 12))
        d.onEvent(GameEvent(EventType.CONVERSATION_STARTED, "x", "s"))
        assertTrue(log.calls.contains("sfx:FOOTSTEP"))
        assertTrue(log.calls.contains("sfx:GLASS"))
        assertTrue(log.calls.contains("sfx:DOCUMENT_OPEN"))
        assertTrue(log.calls.contains("sfx:PLUSH_TAP"))
        assertTrue(log.calls.contains("voice:MOTHER:BABBLE"))
        assertTrue(log.calls.contains("voice:CHILD:BABBLE"))
        assertTrue(log.calls.contains("duck:0.3"))
        assertNotEquals(0, log.calls.size)
    }

    @Test
    fun walkingPostsFootstepEventsWithoutFillingTheHistory() {
        val w = World()
        val steps = ArrayList<String>()
        w.scene.events.subscribe(EventType.FOOTSTEP) { steps.add(it.sourceId) }
        w.input.setDirection(false, true)
        w.step(120)
        w.input.setDirection(false, false)
        assertTrue("hay pasos", steps.size >= 4)
        assertFalse("los pasos no ensucian el historial narrativo", w.scene.events.wasPosted(EventType.FOOTSTEP))
    }

    @Test
    fun unloadingTheSceneAbortsTheConversation() {
        val w = World()
        w.pickUpPlush()
        w.step(3)
        w.pressTalk()
        assertTrue(w.scene.conversation.isActive)
        w.scene.unload(w.state)
        assertFalse(w.scene.conversation.isActive)
        assertEquals(CompanionState.ON_BACK, w.state.inventory.companion.state)
    }
}
