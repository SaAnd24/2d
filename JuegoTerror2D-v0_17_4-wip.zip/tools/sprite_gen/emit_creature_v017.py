"""Genera app/src/main/java/com/terror2d/pixel/CreatureSpriteData.kt desde el diseño PROCEDURAL de creature.py
(v0.17, rediseño por silueta: cabeza grande y torcida, ojos asimétricos, brazos demasiado largos).

Uso:  python3 emit_creature_v017.py   (desde tools/sprite_gen; solo necesita numpy + PIL, sin imágenes de
referencia). La app no contiene ninguna imagen: únicamente las matrices de paleta que se escriben en el .kt (RLE:
índice de paleta + longitud, ambos como chr(48+n); las decodifica SpriteCodec).

NO confundir con emit_creature.py: ese emisor usaba creature_ref.py (traducción fiel de dos JPG de referencia
que ya no están en esta VM) y es el que generó los datos v0.8-v0.16 (cuerpo 160x200). Este emisor sustituye
esos datos por el diseño procedural de creature.py (cuerpo 160x176, cabeza 78x72). El esquema del .kt es EL
MISMO (mismos nombres de campos y mismo orden), así CreatureSprite.kt no cambia de forma: solo cambian los
valores (y el índice de piel del hombro, que pasa a ser SK=2 en la paleta procedural).
"""
import os

import creature as cr
from emit_kotlin import rle

OUT = os.path.join(os.path.dirname(__file__), '..', '..', 'app', 'src', 'main', 'java', 'com', 'terror2d', 'pixel', 'CreatureSpriteData.kt')


def ks(a):
    return '        "%s"' % rle(a)


def ints(vals):
    return 'intArrayOf(' + ', '.join(str(int(v)) for v in vals) + ')'


def argb(c):
    r, g, b, a = c
    return '0x%02X%02X%02X%02X' % (a, r, g, b)


def main():
    L = []
    w = L.append
    w('package com.terror2d.pixel')
    w('')
    w('/**')
    w(' * DATOS GENERADOS por tools/sprite_gen (python3 emit_creature_v017.py desde creature.py). NO editar a mano.')
    w(' * Diseño v0.17 (procedural, sin imágenes de referencia): cabeza grande y torcida (78x72), ojos asimétricos')
    w(' * (uno más alto y más grande que el otro), sonrisa torcida, brazos demasiado largos y 7 bocas del vientre.')
    w(' * Cuerpo 160x176 a la misma densidad que el niño (1 px de sprite = 0,5 px lógicos). La app NO contiene')
    w(' * ninguna imagen: solo estas matrices, que el motor pixelado dibuja y anima.')
    w(' */')
    w('object CreatureSpriteData {')
    w(f'    const val BODY_W = {cr.W}')
    w(f'    const val BODY_H = {cr.H}')
    w(f'    /** Columna del cuerpo que cae sobre el centro de la criatura (la cadera). */')
    w(f'    const val ANCHOR_X = {cr.ANCHOR_X}')
    w('    val PALETTE: IntArray = intArrayOf(' + ', '.join(argb(c) + '.toInt()' for c in cr.PAL) + ')')
    names = list(cr.POSES.keys())
    assert len(names) == 21, names
    w('    /** Orden: IDLE, INVESTIGATE, ALERT, CAPTURE, HURT_LIGHT, WALK_0..7, RUN_0..7. */')
    w('    val BODY_POSES: Array<String> = arrayOf(' + ', '.join('"%s"' % n for n in names) + ')')
    bodies = [cr.build_body(n) for n in names]
    w('    val BODY_DATA: Array<String> = arrayOf(')
    w(',\n'.join(ks(b.a) for b, _ in bodies))
    w('    )')
    w('    /** Por pose: [headX, headY (esquina sup. izq. de la cabeza), bellyX, bellyY (centro del vientre), hombro delantero x,y, hombro trasero x,y, variante de cabeza]. */')
    w('    val BODY_ANCHORS: Array<IntArray> = arrayOf(' + ', '.join(
        ints(list(i['head']) + list(i['belly']) + list(i['lead']) + list(i['trail']) + [i['variant']]) for _, i in bodies) + ')')
    w(f'    val ARM_SWING: IntArray = {ints(cr.ARM_SWING)}')
    w(f'    val ARM_BEND: IntArray = {ints(cr.ARM_BEND)}')
    for lead, nm in ((True, 'LEAD'), (False, 'TRAIL')):
        arms = [cr.build_arm(si, bi, lead) for si in range(len(cr.ARM_SWING)) for bi in range(len(cr.ARM_BEND))]
        assert len(arms) == 30, len(arms)
        w(f'    /** Brazo {"delantero (delante del cuerpo)" if lead else "trasero (detrás del cuerpo)"}: índice = balanceo * {len(cr.ARM_BEND)} + codo. */')
        w(f'    val ARM_{nm}: Array<String> = arrayOf(')
        w(',\n'.join(ks(a.a) for a, _ in arms))
        w('    )')
        w(f'    /** [ancho, alto, hombroX, hombroY] de cada recorte de ARM_{nm}. */')
        w(f'    val ARM_{nm}_INFO: Array<IntArray> = arrayOf(' + ', '.join(
            ints([a.w, a.h, info[0], info[1]]) for a, info in arms) + ')')
    # cabezas (2 variantes con su propio tamaño)
    heads = [cr.build_head(v) for v in (0, 1)]
    w('    /** Cabeza 0 = frontal, 1 = girada (la de caminar). Cada una con su tamaño. */')
    w('    val HEAD_DATA: Array<String> = arrayOf(')
    w(',\n'.join(ks(h.a) for h in heads))
    w('    )')
    w('    /** [ancho, alto] de cada variante de cabeza. */')
    w('    val HEAD_SIZES: IntArray = ' + ints([x for h in heads for x in (h.w, h.h)]))
    w('    val EYE_STATES: Array<String> = arrayOf(' + ', '.join('"%s"' % s for s in cr.EYE_STATES) + ')')
    ec, esz, eyeL, eyeR = [], [], [], []
    for v in (0, 1):
        (lx, ly), (rx, ry) = cr.EYE_CENTERS[v]
        ec += [lx, ly, rx, ry]
        for r, outer, store in ((cr.EYE_R[v][0], -1, eyeL), (cr.EYE_R[v][1], +1, eyeR)):
            ps = [cr.eye_patch(r, s, outer) for s in cr.EYE_STATES]
            esz.append(ps[0].w)
            store += ps
    # EYE_CENTERS por variante: [Lx, Ly, Rx, Ry]
    w('    /** Por variante: centro del ojo trasero (x,y) y del delantero (x,y), en celdas de la cabeza. */')
    w(f'    val EYE_CENTERS: IntArray = {ints(ec)}')
    w('    /** Por variante: lado (cuadrado) del parche del ojo trasero y del delantero. */')
    w(f'    val EYE_SIZES: IntArray = {ints(esz)}')
    w('    /** Índice = variante * 5 + estado (OPEN, HALF, CLOSED, LOOK_DOWN, WIDE). */')
    w('    val EYE_DATA_L: Array<String> = arrayOf(')
    w(',\n'.join(ks(p.a) for p in eyeL))
    w('    )')
    w('    val EYE_DATA_R: Array<String> = arrayOf(')
    w(',\n'.join(ks(p.a) for p in eyeR))
    w('    )')
    w('    val MAIN_MOUTH_STATES: Array<String> = arrayOf(' + ', '.join('"%s"' % s for s in cr.MOUTH_NAMES) + ')')
    msz, mpos, mdata = [], [], []
    for v in (0, 1):
        ps = [cr.main_mouth(v, s) for s in range(len(cr.MOUTH_NAMES))]
        spr, pcx, pcy = ps[0]
        msz += [spr.w, spr.h]
        mpos += [cr.MOUTH_AT[v][0] - pcx, cr.MOUTH_AT[v][1] - pcy]
        mdata += [p[0] for p in ps]
    w('    /** Por variante: ancho y alto del parche de la sonrisa. */')
    w(f'    val MAIN_MOUTH_SIZES: IntArray = {ints(msz)}')
    w('    /** Por variante: esquina sup. izq. del parche en celdas de la cabeza. */')
    w(f'    val MAIN_MOUTH_POS: IntArray = {ints(mpos)}')
    w('    /** Índice = variante * 4 + estado (CLOSED = sonrisa; TENSE = tensa; OPEN/WIDE = abierta/gruñendo). */')
    w('    val MAIN_MOUTH_DATA: Array<String> = arrayOf(')
    w(',\n'.join(ks(p.a) for p in mdata))
    w('    )')
    sizes, origins, sdata, tm = [], [], [], []
    for i in range(7):
        ps = [cr.belly_mouth(i, s) for s in range(4)]
        spr, pcx, pcy = ps[0]
        sizes += [spr.w, spr.h]
        origins += [pcx, pcy]
        sdata += [p[0] for p in ps]
        tm.append([i, cr.BELLY_MOUTHS[i][0], cr.BELLY_MOUTHS[i][1], 0])
    w('    /** 7 bocas del vientre; 4 estados cada una (0 casi cerrada ... 3 muy abierta). Índice = boca * 4 + estado. */')
    w('    const val SEC_STATES = 4')
    w(f'    val SEC_SIZES: IntArray = {ints(sizes)}')
    w(f'    val SEC_ORIGINS: IntArray = {ints(origins)}')
    w('    val SEC_DATA: Array<String> = arrayOf(')
    w(',\n'.join(ks(p.a) for p in sdata))
    w('    )')
    w('    /** El diseño no tiene bocas secundarias en la cabeza (la sonrisa grande es la boca principal). */')
    w('    val HEAD_MOUTHS: Array<IntArray> = arrayOf()')
    w('    /** Bocas del vientre: [id de boca, x, y relativos al centro del vientre, 0]. */')
    w('    val TORSO_MOUTHS: Array<IntArray> = arrayOf(' + ', '.join(ints(t) for t in tm) + ')')
    w('}')
    open(OUT, 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    print('escrito', os.path.abspath(OUT), os.path.getsize(OUT), 'bytes')
    print('cuerpo', cr.W, 'x', cr.H, 'cabeza', heads[0].w, 'x', heads[0].h,
          'ojos', esz, 'centros', ec, 'boca', msz, 'paleta', len(cr.PAL))


if __name__ == '__main__':
    main()
