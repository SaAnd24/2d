# MYMom — Reestructuración v0.17.0 (2.5D, exploración, guardado)

**Versión:** 0.17.0 (`versionCode` 13) · **Estado de verificación: código ESCRITO, NO compilado ni ejecutado**
(el entorno de trabajo no tiene Java/Gradle/Android SDK). Lo primero al abrir el proyecto:
`./gradlew testDebugUnitTest` y jugar la secuencia carta → apagón → patrulla → escondite → puzzle
(ver «Cómo probar» al final). Las pruebas nuevas (`SaveManagerTest`, `Restructure017Test`) están
escritas pero **sin ejecutar**; el Kotlin se revisó solo de forma estática (imports, nombres y firmas
contra los archivos reales).

**Qué es 0.17:** la reestructuración jugable que pediste. El juego hasta 0.16 se sentía vago y lineal:
recorres una casa bonita, lees papeles y resuelves puzles, pero casi siempre sabes dónde ir y la criatura
llega tarde. En 0.17 la casa se convierte en un espacio que se **explora** (como en *FNAF: Into the Pit* o
*Fran Bow*): profundidad 2.5D, moverse con intención (andar, correr, sigilo, agacharse), esconderse de
verdad (armario, debajo de la cama, tras la cortina) y un guardado que por fin existe. **No cambia el
arte** (pixel art + crayón sobre papel, 320×180, sin motor gráfico ni assets externos) ni la historia
del Capítulo I (ver `docs/CAPITULO1.md` y `docs/DESIGN_BIBLE.md`).

**Cómo se trabajó:** 0.17 se hizo en frentes paralelos. Este documento recoge la visión y los contratos
comunes; cada frente es dueño de su parte. La tabla de «Contratos entre frentes» al final dice qué está
entregado y qué sigue pendiente de cada frente.

---

## 1. Decisiones por sistema

### 1.1 Profundidad 2.5D (contrato ENTREGADO por el frente de movimiento)

- Cada cosa del mundo tiene una `depth: Float` de **0.0 (fondo, lejos) a 1.0 (primer plano, cerca)**.
- La escala a esa profundidad es **`depthScale = 0.82 + 0.30 * depth`** (fondo 0.82×, primer plano 1.12×).
  La fórmula vive en `core/Depth.kt` (`Depth.depthScale()`; fuera de rango se limita a [0, 1]) y sus
  constantes en `core/GameConfig.kt` (`DEPTH_SCALE_FAR = 0.82`, `DEPTH_SCALE_SPAN = 0.30`).
- Hay un **plano de referencia** (`DEPTH_REFERENCE = 0.6`, la profundidad por defecto del jugador):
  ahí la escala es exactamente 1.0 y los pies quedan sobre `floorY`, así que todo lo dibujado hasta
  0.16 se ve igual sin tocarlo.
- El suelo es una **banda vertical** (`DepthBand`: `footY`/`depthAt`, altura `FLOOR_BAND_HEIGHT = 26`):
  mayor depth = más abajo en pantalla y mayor escala. Las capas de render son `DepthLayer`
  (BACK/MID/FRONT) y dentro de cada capa manda la profundidad (`Depth.sortByDepth`). El fondo tiene
  parallax (`Depth.parallaxFactor`: 55 % lejos, 100 % cerca).
- La profundidad es solo presentación y colisión: **no cambia la lógica de puzles ni de historia**
  (los puzles se resuelven igual; lo que cambia es dónde están y cómo se llega a ellos).
- Pendiente (frente de escena/mapa): asignar `depth` a cada objeto y segmento de `ChapterHouse.kt`
  y que el render pinte por capas. Mientras no esté, el juego se ve como en 0.16 y los tests de
  `Restructure017Test` solo comprueban la fórmula, la banda y las velocidades.

### 1.2 Movimiento (contrato y números ENTREGADOS por el frente de movimiento)

- `core/Depth.kt` define `MoveMode { WALK, RUN, SNEAK, CROUCH }` y `core/GameConfig.kt` sus números:
  - **WALK**: el paso normal de siempre (`WALK_SPEED = 68` px/s, igual que `Player.SPEED` en 0.16).
  - **RUN**: correr (`RUN_SPEED = 110`). Más rápido, pero **hace ruido** y la criatura lo oye; gasta
    stamina (`STAMINA_DRAIN_RUN = 22`/s, ~4,5 s de carrera; mínimo 8 para empezar; a 0 cae a WALK).
  - **SNEAK**: sigilo (`SNEAK_SPEED = 32`). Lento y silencioso; para cruzar cerca de la criatura sin
    que te oiga. Visibilidad 0.8.
  - **CROUCH**: agachado (`CROUCH_SPEED = 22`). Para pasar por huecos bajos (el del pasillo, x=410..440)
    y para no ser visto por encima de muebles bajos. Altura visual 0.72, visibilidad 0.6.
  - El suelo también importa (`FloorType`: WOOD cruje, CARPET amortigua, TILE, STAIRS crujen mucho).
- Pendiente (frente de movimiento): conectar cada modo con `Player` (velocidad, ruido, poses, stamina),
  asignar sus controles (ver «Controles») y que la criatura reaccione distinto a cada uno
  (RUN se oye lejos, SNEAK casi no se oye, CROUCH no se ve por encima de un mueble).
- Regla: el sigilo y el agacharse **nunca** hacen al niño invisible; solo le dan margen. Si la
  criatura te ve entrar en un escondite, te saca (como ya hace con el armario en 0.10).
- Ojo: existe OTRO `MoveMode` en `chapter/mech/Mechanism.kt` (paquete `com.terror2d.chapter.mech`,
  gestos de puzle). No choca en compilación (paquete distinto) pero es otro tipo: el de juego es
  siempre `com.terror2d.core.MoveMode`. Conviene unificar el nombre en una limpieza posterior.

### 1.3 Escondites (contrato entregado, cableado parcial)

- `core/HideSpot.kt` (este frente) define `HideSpotType { CLOSET, UNDER_BED, CURTAINS }`:
  - **CLOSET**: armario/ropero. Es el escondite de siempre (`Wardrobe`, `ClosetView`/`ClosetRenderer`,
    rendija arrastrable, `ClosetMemory` con escalada PASS → SUSPICION → WARNING → CAPTURE). Ya existe
    en 0.16 en casi todas las salas (ver 0.16, §2) y **no se toca su comportamiento**.
  - **UNDER_BED**: debajo de la cama. Escondite nuevo: solo cabe agachado, se ve poco, se sale rápido.
    Solo hay camas donde tiene sentido (habitación del niño, habitación de mamá).
  - **CURTAINS**: tras la cortina. Escondite nuevo: te tapa si no te mueves, pero la cortina se mueve
    si pasas corriendo y la criatura puede notar el bulto.
- Pendiente (frente de escondites): marcar en el mapa qué objeto es cada tipo, la vista en primera
  persona de UNDER_BED y CURTAINS, y que la criatura los trate como el armario (si te vio entrar,
  te busca ahí; si no, escucha y se va). El `playerHidden` de `GameState` ya existe y sirve para los tres.

### 1.4 Mapa (sin cambios de estructura en 0.17)

- El mapa sigue siendo el de `docs/CAPITULO1.md`: **19 segmentos** en 4 plantas (segundo piso, planta
  baja, sótano, azotea) más la habitación imposible. Cada planta es un pasillo con las habitaciones
  colgando; puertas reales que la criatura usa; pasos secretos (★) de los puzles.
- 0.17 no añade habitaciones ni mueve puertas: solo añade **profundidad** a lo que ya hay y
  **escondites** donde faltaban. Si al probar un escondite tapa una puerta o un puzle, se mueve el
  escondite, nunca la puerta ni el puzle.
- La criatura ya navega toda la casa por conectores reales (`creature/HousePatrol.kt`, 0.16) y eso no
  se toca: la patrulla arranca al terminar la introducción y las luces solo la frenan persiguiendo.

### 1.5 Puzles (sin cambios de solución en 0.17)

- Los 15 puzles del Capítulo I mantienen **soluciones y piezas** (ver `docs/CAPITULO1.md`): en 0.17 los 15 tienen mecanismo propio — T3, C2, C3 y C5 se migraron (CorridorMech, FootprintsMech, PanelsMech, SignalsMech); ya no queda ninguno con el panel clásico.
- Lo que cambia en 0.17 es **cómo se llega a ellos**: con profundidad y escondites, el recorrido entre
  puzles deja de ser un pasillo recto. Las dependencias entre puzles (N1 → N2 → N3 → N4 → llave → N5,
  T1..T5, C1..C5) no se tocan; tampoco las pistas de luces de N5 ni su efecto sobre el sótano.
- El apagón (0.16) sigue igual: se dispara una sola vez al cerrar la primera lectura de la carta
  (`doc_mom_note`), quedan 4 luces, y resolver N5 estabiliza el sótano sin encender más luces.

### 1.6 Monstruo y screamer (frente aparte; aquí solo el contrato que le afecta)

- La criatura sigue siendo la gran rana deforme y triste con muchas bocas (0.8–0.10.1): patrulla,
  oído, vista, investigación, persecución, pérdida y captura **sin Game Over** (despertar en el
  dormitorio; la captura no toca el progreso narrativo).
- Lo que 0.17 le pide al frente del monstruo (pedido directo tuyo, pendiente de ese frente):
  1. **Rehacer el pixel art de la rana** (el actual no te convence).
  2. **Rehacer el screamer** (los 18 fotogramas deformados de la referencia de 0.10.1 no te convencen).
  3. **Rehacer el sonido del screamer** (el grito/llanto sintetizado de 0.10.1 no te convence).
- Mientras ese frente no entregue, el juego usa el monstruo, el screamer y el audio de 0.10.1/0.16
  sin cambios. El guardado **sí** registra las capturas (`captureCount`): si el nuevo screamer
  necesita saber cuántas veces te han atrapado, el dato ya está guardado.
- El sonido sigue siendo 100 % procedural (`AudioEngine`, sin MP3/WAV); cualquier screamer nuevo
  debe seguir sintetizándose, no grabarse.

### 1.7 Guardado mínimo — ENTREGADO en este frente

- **Por fin hay guardado.** `core/SaveManager.kt` (`SharedPreferences`, fichero `mymom_save`).
- Se guarda **solo progreso, nunca la escena**: diario (`DiaryState.toSaveString()`), hitos
  narrativos (`StoryState`, con su fase derivada), `blackoutDone`, objetos soltados (`DroppedItems`)
  y `captureCount`. No se guardan posición del niño, sala actual, estado de la criatura ni
  `elapsedTime`: al cargar, la partida arranca en la escena inicial con el progreso restaurado.
- La carga es tolerante: cadenas mal formadas se ignoran por partes y nunca rompen la partida
  (probado en `SaveManagerTest`).
- **Integración pendiente (la aplica el coordinador; ver «Snippets de integración» abajo).**
  El apagón ya está preparado para la carga: `BlackoutDirector` pasa a DONE si `blackoutDone`
  viene en true, así que cargar con el apagón hecho no re-revienta los focos.
- `DiaryState` ya tenía `toSaveString/loadSaveString` (0.16) y ahora se usan de verdad. Se añadieron
  los mismos métodos a `StoryState` (`story/Story.kt`) y a `DroppedItems`
  (`inventory/DroppedItems.kt`); no se cambió ninguna firma existente.

### 1.8 Diario y documentos (sin cambios en 0.17)

- «Mi diario» (0.16) sigue igual: orden de descubrimiento, una nota por documento (NORMAL/TRAUMA
  comparten entrada), el mundo se congela mientras está abierto. Ahora, además, **persiste** entre
  sesiones gracias al guardado.
- Los documentos siguen siendo papeles físicos en el suelo (`world/DocumentProp.kt`).

## 2. Controles

Resolución lógica 320×180, landscape. Controles que existen hoy (sin cambios en 0.17):

| Acción | Teclado | Táctil |
|---|---|---|
| Moverse | A / D o flechas | Botones de dirección |
| Interactuar / examinar / leer | Espacio, Enter o E | Botón de acción contextual |
| Correr | (botón RUN) | Botón RUN (`InputAction.RUN`) |
| Hablar con Ranita | T o Q | Botón «HABLAR CON RANITA» |
| Espejo | M | Botón espejo |
| Esconderse (armario) | — | Botón HIDE / tocar el armario |
| Abrir «Mi diario» | — | Icono de cuaderno (arriba a la izquierda) |
| Soltar objeto en mano | — | Botón de soltar (junto al objeto, arriba a la derecha) |
| Rendija del armario | A / D | Arrastrar con el dedo |

**Pendiente (frente de movimiento):** asignar controles a SNEAK y CROUCH (teclado y táctil) sin
chocar con los de arriba. Sugerencia: mantener pulsado para sigilo/agacharse, no un interruptor.

## 3. Mapa (resumen; el detalle está en `docs/CAPITULO1.md`)

```
SEGUNDO PISO  Pasillo (Hall): Kid 70 · Bath 200 · Mom 330 · Closet 460 · Study 590 (cerrada) ·
              ESCALERA 720 · TRAMPILLA 900
              Closet ★C2★ Study (pared compartida)
PLANTA BAJA   Pasillo único (Foyer, 980 px): puerta principal 50 · ESCALERA ARRIBA 170 · Living 330 ·
              Dining 460 · Kitchen 590 · Baño de servicio 720 · puerta trasera (cerrada) 800 ·
              ESCALERA DE SERVICIO ABAJO 900
              Kitchen ─ Pantry. Living ★C1★ Pantry.
SÓTANO        Desembarco (Cellar): escalera arriba 24 · Laundry 420 · Electric 490 · Boiler 560 · Storage 630
              Storage: hueco bajo los cimientos al fondo (muro ★T4)
AZOTEA        Roof (por la trampilla del pasillo)
ESPECIAL      Closet ★C5 ▶ Impossible ─▶ pasillo de planta baja ─▶ puerta principal ─▶ «Fin del capítulo I»
```

Luces que sobreviven al apagón (una por planta): Pasillo x655, Vestíbulo x120, Descansillo del
sótano x210, Azotea x300.

## 4. API del guardado (`core/SaveManager.kt`)

```kotlin
// Almacén mínimo (interfaz; el juego usa SharedPreferences, los tests uno en memoria)
interface SaveStore {
    fun getString(key: String, default: String?): String?
    fun getBoolean(key: String, default: Boolean): Boolean
    fun getInt(key: String, default: Int): Int
    fun putString(key: String, value: String)
    fun putBoolean(key: String, value: Boolean)
    fun putInt(key: String, value: Int)
    fun clear()
    fun commit()          // escritura síncrona de todo lo acumulado
}
class SharedPreferencesStore(prefs: SharedPreferences) : SaveStore

class SaveManager(store: SaveStore) {
    fun hasSave(): Boolean
    fun save(state: GameState)      // sobrescribe el guardado anterior
    fun load(state: GameState): Boolean   // false si no había guardado (state intacto)
    fun clearSave()                 // nueva partida desde cero
    companion object {
        const val PREFS_NAME = "mymom_save"
        const val SAVE_VERSION = 17
        fun fromContext(context: Context): SaveManager
    }
}
```

Claves: `save_version`, `diary`, `story_flags`, `blackout_done`, `dropped`, `capture_count`.

### Snippets de integración (para el coordinador — NO aplicados en este frente)

`Game.kt` y `MainActivity.kt` (y `GameView.kt`) pueden estar tocándolos otros frentes en paralelo,
así que no se editaron aquí. Snippets exactos, en el orden en que deben quedar:

**1. `core/Game.kt`** — al final de la clase (junto a `resumeAudio`/`pauseAudio`):

```kotlin
/** v0.17: guardado. Lo instala GameView (tiene el Context); sin él, cargar/guardar no hacen nada. */
var saveManager: SaveManager? = null

/** Carga el progreso guardado (diario, hitos, apagón, objetos soltados, capturas). Llamar una vez al arrancar. */
fun loadProgress() { saveManager?.load(state) }

/** Guarda el progreso actual. Llamar en onPause. */
fun saveProgress() { saveManager?.save(state) }
```

**2. `core/GameView.kt`** — al principio del bloque `init` (antes de `holder.addCallback(this)`):

```kotlin
game.saveManager = SaveManager.fromContext(context)   // v0.17
game.loadProgress()                                    // v0.17: restaura el progreso guardado
```

(Se hace aquí y no en `Game.init` porque `Game` no tiene `Context`; `GameView` se crea antes de
que arranque el bucle, así que la carga ocurre antes del primer update/render. La escena ya se
cargó en `Game.init`, pero el progreso solo toca `GameState` y la escena lo lee en cada update:
el apagón cargado lo recoge `BlackoutDirector` solo.)

**3. `MainActivity.kt`** — en `onPause()`, antes de `gameView.pauseGame()`:

```kotlin
gameView.game.saveProgress()   // v0.17: guarda diario, hitos, apagón, objetos soltados y capturas
```

## 5. Tests nuevos

- `app/src/test/java/com/terror2d/SaveManagerTest.kt` (9 tests): cargar sin guardado no rompe;
  ida y vuelta del diario (orden y no leídas), de los hitos (la fase se restaura), del apagón, de
  los objetos soltados y de `captureCount`; el segundo guardado sobrescribe; `clearSave()`; cadenas
  mal formadas no rompen la carga; una captura no borra el progreso.
- `app/src/test/java/com/terror2d/Restructure017Test.kt` (9 tests): la fórmula de profundidad
  (0.82 / 1.0 en el plano de referencia 0.6 / 1.12, límites y monotonía), la banda de suelo
  (`DepthBand.footY`/`depthAt`), las velocidades por modo (andar 68, orden RUN > WALK > SNEAK >
  CROUCH), los valores de `MoveMode` y `HideSpotType`, y la **secuencia completa a nivel de estado** (carta → apagón → patrulla → escondite → puzzle, con
  guardado y carga en medio). El archivo documenta en su cabecera qué tests faltan por cada frente
  que aún no ha entregado su cableado.
- El workflow `.github/workflows/build.yml` sigue válido para 0.17 sin cambios:
  `assembleDebug` + `testDebugUnitTest`, mismo JDK 17 y Gradle 8.7.

## 6. Cómo probar cada sistema (en el dispositivo, tras compilar)

**Secuencia completa (carta → apagón → patrulla → escondite → puzzle):**
1. Nueva partida: intro (agua → pastillas → puzzle de medicinas) → el niño se va a dormir →
   grito de mamá → despertar → habitación de mamá vacía.
2. **Carta:** leer la nota de mamá («Me fui al hospital…»); abrir «Mi diario» (cuaderno arriba a la
   izquierda) y comprobar que la nota está archivada, en orden.
3. **Apagón:** al cerrar la carta, los focos revientan en secuencia y quedan 4 luces. Salir de la
   app (botón inicio) y volver a entrar: el apagón sigue hecho (las luces rotas no vuelven).
4. **Patrulla:** esperar en el pasillo; la criatura debe rondar por las habitaciones (entra y sale
   por las puertas) sin quedarse quieta en una sala.
5. **Escondite:** con la criatura cerca, entrar en un armario (CLOSET): vista en primera persona
   con rendija; si no te vio entrar, escucha y se va; salir ileso. Probar también UNDER_BED y
   CURTAINS cuando el frente de escondites los entregue.
6. **Puzzle:** resolver un puzle de mecanismo (p. ej. N1 o N5) y comprobar que el progreso queda
   (salir de la app y volver: el puzle resuelto sigue resuelto y la pista de N5 sigue en la cocina).
7. **Guardado (prueba específica):** con la carta leída, el apagón hecho y algún objeto soltado en
   el suelo, pulsar inicio (onPause) → **matar la app desde recientes** → volver a abrirla: el
   diario, los hitos, el apagón, el objeto soltado y las capturas deben seguir ahí. Repetir tras
   una captura: la captura no borra nada.
8. **Profundidad y movimiento:** caminar del fondo al primer plano: el niño debe cambiar de tamaño
   de forma continua (0.82× → 1.12×) sin saltos. Probar RUN (la criatura se gira hacia el ruido),
   SNEAK (cruzar cerca sin que reaccione) y CROUCH (pasar por el hueco bajo del pasillo).

**Qué NO se puede probar todavía:** UNDER_BED y CURTAINS, los controles de SNEAK/CROUCH, la
profundidad visible en el mapa y el nuevo arte/sonido del monstruo y del screamer (frentes pendientes).

## 7. Limitaciones conocidas

- **Sin compilar ni ejecutar en este entorno.** Todo lo de 0.17 (guardado, contrato, tests, docs)
  está revisado estáticamente; la primera compilación puede sacar errores y hay que corregirlos
  antes de dar 0.17 por cerrada.
- El guardado **no** guarda sala actual, posición del niño, estado de la criatura ni tiempo de juego:
  al cargar se empieza en la escena inicial con el progreso restaurado. Es deliberado (guardado
  mínimo), pero si al jugar se siente mal (p. ej. aparecer lejos de donde estabas), habrá que
  guardar también la sala actual.
- El guardado es **un solo slot** y se sobrescribe en cada `onPause`. No hay «continuar / nueva
  partida» en menú (no hay menú): si quieres empezar de cero hay que borrar los datos de la app
  (o llamar a `SaveManager.clearSave()` desde donde el coordinador decida ponerlo).
- La criatura no entra en el Estudio ni en la habitación imposible (limitación heredada de 0.16).
- Los 15 puzles no se han tocado salvo lo ya hecho en 0.15/0.16.
- El README cronológico se detiene en v0.10.1; lo de v0.11–v0.16 vive en `docs/CAPITULO1.md`
  y `docs/ACTUALIZACION_0_16.md` (no se reescribió la crónica: solo se añadió la entrada de 0.17).

## 8. Contratos entre frentes (0.17)

| Frente | API / contrato | Estado |
|---|---|---|
| Guardado + docs + versión + tests (este frente) | `SaveManager`, `SaveStore`, `HideSpotType`, `toSaveString/loadSaveString` en `StoryState` y `DroppedItems`, versión 0.17.0/13 | Entregado (falta aplicar los 3 snippets) |
| Movimiento 2.5D | `MoveMode`, `Depth.depthScale`/`DepthBand`/`DepthLayer` en `core/Depth.kt`, constantes y velocidades en `GameConfig` | Contrato y números entregados; cableado con `Player` y controles pendientes |
| Escondites | `HideSpotType` en `core/HideSpot.kt` (este frente); `Wardrobe`/`ClosetView` existentes | Contrato entregado; UNDER_BED y CURTAINS pendientes |
| Escena / mapa 2.5D | `depth` por objeto, render por capas (`DepthLayer`, orden por profundidad) | Pendiente |
| Monstruo / screamer | Nuevo pixel art de la rana, nuevo screamer, nuevo sonido del screamer | Pendiente |
| Puzles en 2.5D | Adaptar los 15 puzles al entorno con profundidad | Pendiente (soluciones intactas) |

## 9. Archivos tocados en este frente

- `app/build.gradle.kts`: `versionName "0.17.0"`, `versionCode 13`.
- `app/src/main/java/com/terror2d/core/SaveManager.kt` (nuevo): `SaveStore`,
  `SharedPreferencesStore`, `SaveManager`.
- `app/src/main/java/com/terror2d/core/HideSpot.kt` (nuevo): `HideSpotType` (el resto del contrato
  2.5D — `MoveMode`, `Depth`, `GameConfig` — ya lo había entregado el frente de movimiento; una
  primera versión de este frente con esos mismos tipos se eliminó al detectar la duplicidad).
- `app/src/main/java/com/terror2d/story/Story.kt`: `StoryState.toSaveString/loadSaveString/snapshot`.
- `app/src/main/java/com/terror2d/inventory/DroppedItems.kt`: `toSaveString/loadSaveString`.
- `app/src/test/java/com/terror2d/SaveManagerTest.kt` (nuevo, 9 tests).
- `app/src/test/java/com/terror2d/Restructure017Test.kt` (nuevo, 7 tests).
- `docs/REESTRUCTURACION_0_17.md` (nuevo, este documento).
- `README.md`: versión actual a 0.17.0 y hoja de ruta actualizada (sin borrar la crónica).
- **No tocados:** `Game.kt`, `MainActivity.kt`, `GameView.kt` (snippets pendientes para el
  coordinador), `Scene.kt`, `ChapterHouse.kt`, `CreatureBrain.kt`, `chapter/mech/*`, `pixel/*`,
  `.github/workflows/build.yml` (válido sin cambios).

## 10. Integración del coordinador — estado final v0.17.0-wip

Esta sección corrige el estado "pendiente" de las secciones anteriores: los 5 frentes entregaron y el coordinador integró.

- **Deduplicación aplicada:** `MoveMode` y la fórmula `depthScale = 0.82 + 0.30*depth` viven SOLO en `core/Depth.kt`. Se eliminaron el `MoveMode` y el objeto `PuzzleDepth` provisionales de `chapter/mech/Mechanism.kt` (ahora importan de core); `FootprintsMech`, `SignalsMech`, `MechRenderer` y `PuzzleDepthTest` re-apuntan a `core.Depth`. `ChapterDirector` importa `core.MoveMode`. No quedan duplicados de tipos de nivel superior (verificado por búsqueda).
- **Cableado en `Scene.kt` (aplicado):** `player.requestMode(input.requestedMode)`, `floorType` por segmento, `player.update(..., input.moveY, ...)`, stamina/etiqueta de modo, `chapter.playerMoveMode = player.moveMode`, pisadas con `noise.emitFootstep(...)`, `s.playerDepth / s.playerVisibility / s.creatureDepth`, `camera.updateDepthFocus(...)`, vista interior de escondite por tipo, respiración contenida + latido, `updateHideSearch(...)` tras `closets.decay(dt)`, fondo con `drawBackdropDepth` y criatura con `drawCreature(it, it.brain.depth)`.
- **Guardado aplicado:** `Game.saveManager` + `loadProgress()/saveProgress()`, `GameView` inyecta `SaveManager.fromContext` y carga al arrancar, `MainActivity.onPause()` guarda, `Game.render()` aplica `viewport.setZoom(camera.depthZoom)`, `GameRenderer` aplica el zoom 2.5D alrededor del centro.
- **Screamer aplicado:** `CaptureSequence` FREEZE 0.5 s → 0.12 s (el renderer nuevo solo pre-decodifica el fotograma 0).
- **Puzles:** los 15 con mecanismo propio; T3, C2, C3 y C5 migrados (ver informe del frente de puzles). C3 exige CROUCH dentro del mecanismo; C5 exige profundidad >= 0.6 para observar.
- **Pendiente / limitaciones conocidas (probar en dispositivo antes de dar 0.17 por cerrada):**
  1. Sin compilar localmente en esta VM (no hay Java/Gradle/Android SDK): primera verificación real es GitHub Actions (`assembleDebug` + `testDebugUnitTest`, 317 tests @Test en total).
  2. Arte del screamer NO regenerado: falta la imagen de referencia en este entorno (`screamer_anim.py` no pudo correr). El renderer y la temporización nuevos (0,92 s) funcionan con el arte actual; al regenerar, mantener 4 cues y actualizar `ScreamerView` a la vez.
  3. C5: la observación `obs_C5` aún no comprueba la profundidad >= 0.6 en el spot (el dato está en `ChapterFlags.C5_OBSERVE_DEPTH_MIN`); C3: la entrada al hueco aún no exige CROUCH, solo el mecanismo dentro.
  4. La criatura patrulla en el plano de referencia (su `brain.depth` existe para percepción/render, pero aún no se mueve en la banda de profundidad).
  5. Oclusión jugador↔mecanismo: los mecanismos siguen dibujándose como overlay a pantalla completa (`WorldRenderer.drawMechanism`); `MechRenderer.drawWithOcclusion/drawLayered` están listos para cuando se dibujen en el mundo.
  6. Los muebles aún no tienen profundidad propia: se tratan como si ocuparan toda la banda (hay que rodearlos en horizontal). Implementar `DepthAware` en un mueble lo habilita.
  7. Guardado de un solo slot, sin menú continuar/nueva partida; no guarda sala/posición/estado de la criatura (deliberado).
