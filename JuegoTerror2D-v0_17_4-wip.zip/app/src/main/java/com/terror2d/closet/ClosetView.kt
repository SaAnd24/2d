package com.terror2d.closet

import com.terror2d.core.HideSpotType
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * v0.10.1: estado de la ESCENA DEL ARMARIO en primera persona. Mientras el niño está escondido el mundo se cubre con una
 * MÁSCARA NEGRA ANCHA y solo queda una RENDIJA estrecha por la que se ve el exterior; el jugador arrastra el dedo en
 * horizontal para desplazarla y mirar otras zonas. En la parte baja se ven sus brazos abrazando algo contra el pecho
 * (a Ranita si la lleva; si no, nada: nunca se muestra un peluche que no lleva).
 *
 * No tiene lógica de IA y mirar NO altera nada del juego: el desplazamiento de la rendija es solo visión. La escena le
 * dice si hay peligro cerca ([danger], 0..1) y si la criatura se asoma ([peek]); la posición real de la criatura en
 * pantalla llega por [setFace], de modo que su ojo/sonrisa solo aparece donde de verdad está.
 *
 * v0.17: la misma vista sirve para los tres tipos de escondite ([spotType]). La rendija cambia con
 * el tipo — debajo de la cama es más estrecha y baja ([slitFactor] 0.8), tras la cortina más ancha
 * (1.3: se ve más, pero también te ven más) — y el rótulo interior ([interiorLabel]) dice dónde
 * está el niño. Además: aguantar la respiración ([holdingBreath], máx. [BREATH_HOLD_LIMIT] s;
 * si se agota, [gaspPending] avisa de que el niño tiene que tomar aire y delata su posición) y
 * el latido ([heartbeatIntensity] / [heartbeatInterval]): si el niño corrió mucho antes de
 * esconderse ([exertion], lo alimenta el frente motor desde `MoveMode.RUN`), el corazón se oye
 * más fuerte y más rápido; con el peligro también sube.
 */
class ClosetView {
    var active = false
        private set
    /** 0..1: fundido hacia/desde la escena. */
    var blend = 0f
        private set
    var time = 0f
        private set
    /** true = Ranita acompaña al niño (la escena la muestra abrazada). */
    var withFrog = false
        private set
    /** v0.17: en qué tipo de escondite está el niño (armario por defecto, como siempre). */
    var spotType = HideSpotType.CLOSET
        private set
    /** 0..1: cercanía de la criatura (la rendija se estrecha, el niño respira más y tiembla). */
    var danger = 0f
        private set
    /** 0..1: la criatura abre la puerta un poco y se asoma (ojo y sonrisa en la rendija si pasa por delante). */
    var peek = 0f
        private set

    /** Centro objetivo de la rendija (px lógicos de pantalla) y centro suavizado que se dibuja. */
    var slitTarget = DEFAULT_SLIT_X
        private set
    var slitCenter = DEFAULT_SLIT_X
        private set
    /** Posición en pantalla (px lógicos) del rostro de la criatura si puede verse desde la puerta; NaN si no. */
    var faceX = Float.NaN
        private set
    /** Distancia total arrastrada (para pruebas y para que el audio sepa que el niño está mirando). */
    var dragTotal = 0f
        private set

    private var wantPeek = false
    private var wantActive = false

    val breathingIntensity: Float get() = 0.25f + 0.75f * danger
    val tremorIntensity: Float get() = 0.1f + 0.9f * danger

    /** Rótulo interior según el escondite (el renderer lo usa para la viñeta de cada tipo). */
    val interiorLabel: String get() = when (spotType) {
        HideSpotType.CLOSET -> "ARMARIO"
        HideSpotType.UNDER_BED -> "DEBAJO DE LA CAMA"
        HideSpotType.CURTAINS -> "DETRÁS DE LA CORTINA"
    }

    /** Factor de anchura de la rendija por tipo: bajo la cama se ve menos, tras la cortina se ve más. */
    val slitFactor: Float get() = when (spotType) {
        HideSpotType.CLOSET -> 1f
        HideSpotType.UNDER_BED -> 0.8f
        HideSpotType.CURTAINS -> 1.3f
    }

    /** Ancho de la rendija (px lógicos): se estrecha un poco con el peligro y se abre al asomarse la criatura. */
    val slitWidth: Float get() = (BASE_WIDTH * slitFactor - 3f * danger + 5f * peek).coerceIn(MIN_WIDTH, MAX_WIDTH)
    val slitLeft: Float get() = slitCenter - slitWidth / 2f
    val slitRight: Float get() = slitCenter + slitWidth / 2f

    // ------------------------------------------------------------------ v0.17: respiración y latido

    /** true mientras el niño aguanta la respiración (la escena lo pone cuando la criatura escucha o el jugador mantiene la acción). */
    var holdingBreath = false
        private set
    /** Segundos seguidos aguantando la respiración (se resetea al soltar). */
    var breathHoldElapsed = 0f
        private set
    /** true UNA vez cuando se agota el aire: el niño tiene que tomar aire y eso hace ruido ([consumeGasp]). */
    var gaspPending = false
        private set
    /** La respiración del niño se oye (false mientras aguanta: eso es lo que lo salva... hasta que se le acaba el aire). */
    val breathingAudible: Boolean get() = !holdingBreath

    /** 0..1: cuánto corrió el niño justo antes de esconderse (lo fija la escena; el frente motor lo alimenta desde `MoveMode.RUN`). */
    var exertion = 0f
        private set
    fun setExertion(v: Float) { exertion = v.coerceIn(0f, 1f) }

    /** 0..1: fuerza del latido (corre mucho antes + peligro cerca). La escena toca `SfxId.HEARTBEAT` a este ritmo. */
    val heartbeatIntensity: Float get() = (0.35f * exertion + 0.65f * danger).coerceIn(0f, 1f)
    /** Segundos entre latidos: ~1.05 s en calma, ~0.5 s con el corazón desbocado. */
    val heartbeatInterval: Float get() = 1.05f - 0.55f * heartbeatIntensity

    fun setHoldingBreath(v: Boolean) {
        if (v == holdingBreath) return
        holdingBreath = v
        if (!v) breathHoldElapsed = 0f
    }

    /** Consume el aviso de «me quedo sin aire» (true una sola vez por cada vez que se agota). */
    fun consumeGasp(): Boolean {
        val g = gaspPending
        gaspPending = false
        return g
    }

    fun begin(frogAccompanies: Boolean) {
        begin(frogAccompanies, HideSpotType.CLOSET)
    }

    fun begin(frogAccompanies: Boolean, type: HideSpotType) {
        spotType = type
        withFrog = frogAccompanies
        wantActive = true
        active = true
        time = 0f
        peek = 0f
        slitTarget = DEFAULT_SLIT_X
        slitCenter = DEFAULT_SLIT_X
        faceX = Float.NaN
        holdingBreath = false
        breathHoldElapsed = 0f
        gaspPending = false
        exertion = 0f
    }

    fun end() { wantActive = false }

    /** Corta de golpe (descarga de la escena / captura). */
    fun abort() { wantActive = false; active = false; blend = 0f; peek = 0f; danger = 0f; wantPeek = false; faceX = Float.NaN; holdingBreath = false; breathHoldElapsed = 0f; gaspPending = false; exertion = 0f }

    fun setPeeking(v: Boolean) { wantPeek = v }

    /** La escena indica dónde está el rostro de la criatura en pantalla (o NaN si no se asoma / no es visible). */
    fun setFace(screenX: Float) { faceX = screenX }

    /** Desplazamiento horizontal del dedo (px lógicos): mueve la rendija sin saltos y sin salirse de los límites. */
    fun drag(dx: Float) {
        if (!active || !wantActive || dx == 0f) return
        slitTarget = (slitTarget + dx).coerceIn(SLIT_MIN, SLIT_MAX)
        dragTotal += abs(dx)
    }

    fun update(dt: Float, dangerNow: Float) {
        if (!active) return
        time += dt
        val target = if (wantActive) 1f else 0f
        blend = if (blend < target) min(target, blend + dt / FADE_IN) else max(target, blend - dt / FADE_OUT)
        if (!wantActive && blend <= 0f) { active = false; peek = 0f; danger = 0f; faceX = Float.NaN; holdingBreath = false; breathHoldElapsed = 0f; gaspPending = false; return }
        danger += (dangerNow.coerceIn(0f, 1f) - danger) * min(1f, 3f * dt)
        val pt = if (wantPeek) 1f else 0f
        peek += (pt - peek) * min(1f, 2.4f * dt)
        // aguantar la respiración tiene límite: al agotarse el aire el niño tiene que respirar (aviso para la escena)
        if (holdingBreath) {
            breathHoldElapsed += dt
            if (breathHoldElapsed >= BREATH_HOLD_LIMIT) {
                holdingBreath = false
                breathHoldElapsed = 0f
                gaspPending = true
            }
        } else if (breathHoldElapsed > 0f) breathHoldElapsed = 0f
        // la rendija sigue al dedo con un suavizado corto: continuidad visual, sin saltos ni huecos
        val k = min(1f, 22f * dt)
        slitCenter += (slitTarget - slitCenter) * k
    }

    companion object {
        const val FADE_IN = 0.45f
        const val FADE_OUT = 0.3f
        /** Segundos seguidos que el niño puede aguantar la respiración antes de tener que tomar aire. */
        const val BREATH_HOLD_LIMIT = 6f
        const val DEFAULT_SLIT_X = 160f
        const val SLIT_MIN = 14f
        const val SLIT_MAX = 306f
        const val BASE_WIDTH = 13f
        const val MIN_WIDTH = 8f
        const val MAX_WIDTH = 22f
    }
}
