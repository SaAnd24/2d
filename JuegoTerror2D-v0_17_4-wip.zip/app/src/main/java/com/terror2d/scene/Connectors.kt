package com.terror2d.scene

import com.terror2d.creature.Connector
import com.terror2d.creature.ConnectorKind
import com.terror2d.world.WindowPassage

/**
 * v0.10: deriva de la definición de la casa TODAS las conexiones físicas (puertas y ventanas). La IA no sabe de
 * habitaciones concretas: solo de esta lista de conexiones. La casa definitiva podrá aportar las suyas
 * (escaleras, huecos, atajos...) sin tocar la IA.
 */
fun SceneDefinition.buildConnectors(): List<Connector> {
    val out = ArrayList<Connector>()
    for (seg in segments) {
        for (d in seg.doors) {
            val t = d.target ?: continue
            val dest = segments.firstOrNull { it.id == t.segmentId } ?: continue
            val sp = dest.spawnPoints[t.spawnId] ?: continue
            out.add(Connector(d.id, ConnectorKind.DOOR, seg.id, d.centerX, dest.id, sp.x))
        }
        for (o in seg.objects) {
            if (o !is WindowPassage) continue
            val dest = segments.firstOrNull { it.id == o.target.segmentId } ?: continue
            val sp = dest.spawnPoints[o.target.spawnId] ?: continue
            out.add(Connector(o.id, ConnectorKind.WINDOW, seg.id, o.centerX, dest.id, sp.x))
        }
    }
    return out
}

/**
 * v0.17: el mismo mapa como grafo no lineal ([HouseGraph]): puertas, escaleras, trampilla, pasos
 * secretos y ventanas. Los conectores de [buildConnectors] son la vista que usa la criatura
 * (puertas y ventanas); el grafo es la vista completa para el diseño, la patrulla con atajos y
 * las pruebas de conectividad.
 */
fun SceneDefinition.buildHouseGraph(): HouseGraph = HouseGraph.fromScene(this)

/**
 * v0.17: problemas de conexión de la escena (lista vacía = mapa sano). Comprueba, por cada puerta
 * y ventana: que el destino exista, que el punto de aparición exista en el destino, que haya una
 * puerta de vuelta (salvo desde la estancia imposible, cuya salida es de sentido único por diseño)
 * y que no haya ids de puerta duplicados; y que ningún conector derivado sea huérfano (sus dos
 * extremos son zonas de la escena). Las puertas bloqueadas (sin destino) no son un problema: son
 * salidas cerradas por historia.
 */
fun SceneDefinition.connectorProblems(): List<String> {
    val problems = ArrayList<String>()
    val ids = segments.map { it.id }.toSet()
    val seenDoorIds = HashSet<String>()
    for (seg in segments) {
        for (d in seg.doors) {
            if (!seenDoorIds.add(d.id)) problems.add("puerta duplicada: " + d.id)
            val t = d.target ?: continue
            if (t.segmentId !in ids) {
                problems.add("puerta " + d.id + " (" + seg.id + ") apunta a zona inexistente: " + t.segmentId)
                continue
            }
            if (segment(t.segmentId).spawnPoints[t.spawnId] == null) {
                problems.add("puerta " + d.id + " (" + seg.id + ") apunta a aparición inexistente: " + t.segmentId + "/" + t.spawnId)
                continue
            }
            if (seg.id != ChapterHouse.IMPOSSIBLE &&
                segment(t.segmentId).doors.none { it.target?.segmentId == seg.id }
            ) {
                problems.add("puerta " + d.id + " (" + seg.id + " -> " + t.segmentId + ") sin puerta de vuelta")
            }
        }
        for (o in seg.objects) {
            if (o !is WindowPassage) continue
            val t = o.target
            if (t.segmentId !in ids) {
                problems.add("ventana " + o.id + " (" + seg.id + ") apunta a zona inexistente: " + t.segmentId)
                continue
            }
            if (segment(t.segmentId).spawnPoints[t.spawnId] == null) {
                problems.add("ventana " + o.id + " (" + seg.id + ") apunta a aparición inexistente: " + t.segmentId + "/" + t.spawnId)
            }
        }
    }
    for (c in buildConnectors()) {
        if (c.fromSeg !in ids || c.toSeg !in ids) problems.add("conector huérfano: " + c.id + " (" + c.fromSeg + " -> " + c.toSeg + ")")
    }
    return problems
}
