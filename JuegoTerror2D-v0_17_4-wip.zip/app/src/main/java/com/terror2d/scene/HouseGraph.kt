package com.terror2d.scene

import com.terror2d.chapter.ChapterFlags
import com.terror2d.creature.Connector
import com.terror2d.creature.ConnectorKind
import com.terror2d.world.ScriptedSpot
import com.terror2d.world.WindowPassage

/** Qué une dos zonas del grafo. Las escaleras/trampilla son puertas invisibles para el niño (las usa tocando la escalera); los pasos secretos son [ScriptedSpot]s, no [com.terror2d.world.Door]s. */
enum class HouseEdgeKind { DOOR, STAIRS, TRAPDOOR, SECRET_PASSAGE, WINDOW, NARROW_GAP }

/**
 * Una arista del grafo de la casa: del segmento [from] al [to].
 *
 *  - [cost]: coste de cruzarla (puerta 1, secreto 1.5, escalera/trampilla 2, ventana 2.5). El camino
 *    más corto es Dijkstra sobre este coste.
 *  - [creatureCanPass]: false = solo el niño. Los pasos secretos son estrechos o se abren con un
 *    mecanismo que la criatura no conoce: la criatura NO los usa (su patrulla va por [Connector]s,
 *    que solo nacen de puertas y ventanas). El hueco estrecho del pasillo tampoco lo cruza.
 *  - [requiresFlag]: hito que debe estar activo para que el paso exista (puzles C1/C2/C5). null =
 *    siempre abierto. Con [HouseGraph.pathTo] se puede pedir el mapa «potencial» (sin filtrar) o el
 *    mapa «real ahora mismo» (pasando los hitos resueltos).
 */
data class HouseEdge(
    val id: String,
    val from: String,
    val to: String,
    val kind: HouseEdgeKind,
    val cost: Float = 1f,
    val creatureCanPass: Boolean = true,
    val requiresFlag: String? = null,
    val label: String = ""
)

/** Un paso secreto conocido del Capítulo I: a dónde lleva y qué hito lo abre. */
data class SecretSpec(val to: String, val flag: String)

/**
 * v0.17: el MAPA como grafo no lineal (estilo FNAF: Into the Pit / Fran Bow). Los nodos son las
 * zonas ([RoomSegment.id]) y las aristas, TODAS las conexiones reales: puertas, escaleras,
 * trampilla, pasos secretos y ventanas del laboratorio (estas últimas solo en la casa original).
 *
 * El grafo es el mapa de verdad, no un dibujo aparte: se construye desde la [SceneDefinition]
 * ([fromScene]) leyendo sus puertas y sus pasos secretos, así que nunca se desincroniza del juego.
 * La patrulla de la criatura ([com.terror2d.creature.HousePatrol]) hace BFS sobre los mismos
 * conectores, así que todo camino del grafo que la criatura puede usar es un camino que la
 * criatura realmente recorre.
 *
 * Hub: [ChapterHouse.FOYER] en planta baja (6 salidas) y [HouseDefinition.CELLAR] en el sótano (5).
 * Atajos nuevos de v0.17 (puertas reales, transitables por niño Y criatura): Comedor↔Cocina,
 * Lavandería↔Cuarto eléctrico, Caldera↔Almacén, Dormitorio↔Baño↔Dormitorio de mamá y
 * Despensa↔Baño de servicio. El paso secreto Living↔Pantry (C1) ya existía.
 */
class HouseGraph(val nodes: List<String>, val edges: List<HouseEdge>) {

    /** Aristas que salen de [roomId]. Con [forCreature] solo las que la criatura puede cruzar. Con [solvedFlags] (null = mapa potencial) solo los secretos ya abiertos. */
    fun exitsOf(roomId: String, forCreature: Boolean = false, solvedFlags: Set<String>? = null): List<HouseEdge> {
        val out = ArrayList<HouseEdge>()
        for (e in edges) {
            if (e.from != roomId) continue
            if (forCreature && !e.creatureCanPass) continue
            if (solvedFlags != null && e.requiresFlag != null && e.requiresFlag !in solvedFlags) continue
            out.add(e)
        }
        return out
    }

    /** Número de salidas de [roomId] (mismo filtro que [exitsOf]). */
    fun degree(roomId: String, forCreature: Boolean = false, solvedFlags: Set<String>? = null): Int =
        exitsOf(roomId, forCreature, solvedFlags).size

    /** true si hay una arista [from] -> [to] (de [kind] si se indica). */
    fun hasEdge(from: String, to: String, kind: HouseEdgeKind? = null): Boolean =
        edges.any { it.from == from && it.to == to && (kind == null || it.kind == kind) }

    /**
     * Camino más corto (Dijkstra sobre [HouseEdge.cost]) de [from] a [to]; null si no existe.
     * Vacío si ya está allí. Determinista: a igualdad de coste gana la arista que aparece antes
     * en la definición. Con [forCreature] los pasos secretos quedan fuera; con [solvedFlags] solo
     * cuentan los secretos ya abiertos.
     */
    fun pathTo(from: String, to: String, forCreature: Boolean = false, solvedFlags: Set<String>? = null): List<HouseEdge>? {
        if (from == to) return emptyList()
        if (from !in nodes || to !in nodes) return null
        val dist = HashMap<String, Float>()
        val prev = HashMap<String, HouseEdge>()
        val done = HashSet<String>()
        for (n in nodes) dist[n] = Float.MAX_VALUE
        dist[from] = 0f
        while (true) {
            var cur: String? = null
            var best = Float.MAX_VALUE
            for (n in nodes) {
                val d = dist[n] ?: Float.MAX_VALUE
                if (n !in done && d < best) { best = d; cur = n }
            }
            val at = cur ?: break
            if (at == to) break
            done.add(at)
            for (e in exitsOf(at, forCreature, solvedFlags)) {
                val nd = (dist[at] ?: Float.MAX_VALUE) + e.cost
                if (nd < (dist[e.to] ?: Float.MAX_VALUE)) {
                    dist[e.to] = nd
                    prev[e.to] = e
                }
            }
        }
        if ((dist[to] ?: Float.MAX_VALUE) == Float.MAX_VALUE) return null
        val path = ArrayList<HouseEdge>()
        var at = to
        while (at != from) {
            val e = prev[at] ?: return null
            path.add(0, e)
            at = e.from
        }
        return path
    }

    /** Zonas alcanzables desde [from] (mismo filtro que [pathTo]). */
    fun reachableFrom(from: String, forCreature: Boolean = false, solvedFlags: Set<String>? = null): Set<String> {
        val seen = LinkedHashSet<String>()
        val queue = ArrayDeque<String>()
        queue.add(from)
        seen.add(from)
        while (queue.isNotEmpty()) {
            val cur = queue.removeFirst()
            for (e in exitsOf(cur, forCreature, solvedFlags)) {
                if (seen.add(e.to)) queue.add(e.to)
            }
        }
        return seen
    }

    /** true si todas las zonas se alcanzan desde [from] (el hub). */
    fun isConnected(from: String, forCreature: Boolean = false, solvedFlags: Set<String>? = null): Boolean =
        reachableFrom(from, forCreature, solvedFlags).containsAll(nodes)

    /** Zonas con menos de 2 salidas: las excepciones documentadas (estudio, azotea, imposible) salen aquí. */
    fun singleExitRooms(forCreature: Boolean = false, solvedFlags: Set<String>? = null): List<String> =
        nodes.filter { degree(it, forCreature, solvedFlags) < 2 }

    companion object {
        /**
         * Pasos secretos del Capítulo I (los [ScriptedSpot]s que cambian de zona). El destino NO se
         * puede leer del spot (su acción es una lambda), así que la tabla es explícita y el grafo
         * avisa en los tests si un spot de la tabla falta en la escena. La vuelta
         * (Estudio→Armario) no tiene condición propia en el juego — solo se llega al estudio
         * tras C2 — pero el grafo le pone la misma para no dibujar un atajo que no existe.
         */
        val KNOWN_SECRETS: Map<String, SecretSpec> = mapOf(
            "living_secret_pantry" to SecretSpec(ChapterHouse.PANTRY, ChapterFlags.solved("C1")),
            "pantry_secret_living" to SecretSpec(ChapterHouse.LIVING, ChapterFlags.solved("C1")),
            "closet_secret_study" to SecretSpec(ChapterHouse.STUDY, ChapterFlags.solved("C2")),
            "study_secret_closet" to SecretSpec(ChapterHouse.CLOSET, ChapterFlags.solved("C2")),
            "closet_to_impossible" to SecretSpec(ChapterHouse.IMPOSSIBLE, ChapterFlags.HOUSE_EXIT_UNLOCKED)
        )

        /** Grafo completo de una escena: puertas + escaleras/trampilla + secretos + ventanas. */
        fun fromScene(def: SceneDefinition): HouseGraph {
            val nodes = def.segments.map { it.id }
            val edges = ArrayList<HouseEdge>()
            for (seg in def.segments) {
                for (d in seg.doors) {
                    val t = d.target ?: continue
                    val kind = when {
                        !d.playerUsable && d.id.contains("roof") -> HouseEdgeKind.TRAPDOOR
                        !d.playerUsable -> HouseEdgeKind.STAIRS
                        else -> HouseEdgeKind.DOOR
                    }
                    edges.add(HouseEdge(d.id, seg.id, t.segmentId, kind, if (kind == HouseEdgeKind.DOOR) 1f else 2f, creatureCanPass = true))
                }
                for (o in seg.objects) {
                    when (o) {
                        is ScriptedSpot -> {
                            val spec = KNOWN_SECRETS[o.id] ?: continue
                            edges.add(HouseEdge(o.id, seg.id, spec.to, HouseEdgeKind.SECRET_PASSAGE, 1.5f, creatureCanPass = false, requiresFlag = spec.flag))
                        }
                        is WindowPassage -> {
                            edges.add(HouseEdge(o.id, seg.id, o.target.segmentId, HouseEdgeKind.WINDOW, 2.5f, creatureCanPass = true))
                        }
                    }
                }
            }
            return HouseGraph(nodes, edges)
        }

        /**
         * Grafo solo con [Connector]s (puertas y ventanas): el que ve la criatura. Pierde la
         * distinción escalera/trampilla (los conectores no la guardan) y los secretos, que la
         * criatura no usa. Sirve para comprobar que patrulla y grafo dicen lo mismo.
         */
        fun fromConnectors(connectors: List<Connector>): HouseGraph {
            val nodeSet = LinkedHashSet<String>()
            for (c in connectors) { nodeSet.add(c.fromSeg); nodeSet.add(c.toSeg) }
            val edges = connectors.map { c ->
                HouseEdge(c.id, c.fromSeg, c.toSeg, if (c.kind == ConnectorKind.WINDOW) HouseEdgeKind.WINDOW else HouseEdgeKind.DOOR,
                    if (c.kind == ConnectorKind.WINDOW) 2.5f else 1f, creatureCanPass = true)
            }
            return HouseGraph(nodeSet.toList(), edges)
        }
    }
}
