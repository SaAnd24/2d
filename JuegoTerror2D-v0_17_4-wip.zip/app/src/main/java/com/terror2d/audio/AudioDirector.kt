package com.terror2d.audio

import com.terror2d.events.EventListener
import com.terror2d.events.EventType
import com.terror2d.events.GameEvent
import com.terror2d.inventory.ItemRegistry

/**
 * El ÚNICO sitio que conoce qué suena con cada evento de juego:
 *
 *   GAMEPLAY -> EVENTO -> AudioDirector -> AudioPort (AudioEngine) -> SÍNTESIS
 *
 * Para cambiar cómo suena el juego se edita este archivo o los sintetizadores; la narrativa y el GameLogic no se
 * tocan. Equivalencias con los nombres conceptuales de la especificación: OBJECT_PICKED_UP = ON_ITEM_PICKED,
 * OBJECT_DROPPED = ON_ITEM_GIVEN / ON_ITEM_PLACED.
 *
 * @param surface superficie bajo los pies del niño ahora mismo (la escena la deduce del suelo del segmento).
 */
class AudioDirector(
    private val audio: AudioPort,
    private val surface: () -> Surface
) : EventListener {

    private var started = false

    /** v0.9: tiempo que se oye ahora (lo anuncia la escena con WEATHER_CHANGED). Decide el ambiente "de casa". */
    private var weather = "CALM"

    private fun houseAmbience(): AmbienceId = when (weather) {
        "STORM_INSIDE" -> AmbienceId.STORM
        "STORM_FAR" -> AmbienceId.STORM_FAR
        else -> AmbienceId.HOUSE
    }
    private var lineCounter = 0

    override fun onEvent(event: GameEvent) {
        when (event.type) {
            EventType.FOOTSTEP -> audio.playSfx(SfxId.FOOTSTEP, 1f, surface())

            EventType.ON_ENTER_ROOM -> if (!started) {
                started = true
                audio.setAmbience(AmbienceId.HOUSE, 4f)
                audio.playMusic(MusicId.HOME, 5f)
            }

            EventType.ON_ITEM_PICKED -> when (event.sourceId) {
                ItemRegistry.FROG_PLUSH -> {}       // lo cubre COMPANION_PICKED_UP
                ItemRegistry.WATER_GLASS -> {
                    audio.playSfx(SfxId.PICKUP, 0.7f)
                    audio.playSfx(SfxId.GLASS, 0.6f)
                }
                else -> {
                    audio.playSfx(SfxId.PICKUP, 0.9f)
                    audio.playSfx(SfxId.MEDICINE, 0.7f)
                }
            }

            EventType.COMPANION_PICKED_UP -> {
                audio.playSfx(SfxId.CLOTH, 0.9f)
                audio.playSfx(SfxId.PLUSH_TAP, 0.8f)
            }

            EventType.ON_ITEM_GIVEN ->
                if (event.sourceId == ItemRegistry.WATER_GLASS) audio.playSfx(SfxId.GLASS, 0.9f)
                else audio.playSfx(SfxId.DROP, 0.8f)

            EventType.ON_ITEM_PLACED -> audio.playSfx(SfxId.DROP, 0.9f)
            EventType.WATER_DELIVERED -> audio.playSfx(SfxId.WATER, 0.6f)
            EventType.ON_DOOR_OPEN -> audio.playSfx(SfxId.DOOR_OPEN, 0.9f)
            EventType.ON_DOCUMENT_READ -> audio.playSfx(SfxId.DOCUMENT_OPEN, 0.9f)
            EventType.ON_INTERACT -> audio.playSfx(SfxId.INTERACT, 0.5f)
            EventType.ON_HIDE, EventType.ON_EXIT_HIDE -> { audio.playSfx(SfxId.CLOTH, 0.8f); audio.playSfx(SfxId.CLOSET_DOOR, 0.7f) }
            EventType.WINDOW_CROSSED -> audio.playSfx(SfxId.WINDOW_CLIMB, 0.95f)
            EventType.CREATURE_FOCUS_LOST -> {
                // la tensión de la persecución cede (aún no hay calma): queda la respiración de búsqueda
                audio.playSfx(SfxId.CREATURE_LOST, 0.7f)
                audio.playMusic(MusicId.SILENCE, 1.5f)
            }
            EventType.CREATURE_CLOSET_PEEK -> { audio.playSfx(SfxId.CLOSET_CREAK, 0.9f); audio.playSfx(SfxId.CREATURE_SNIFF, 0.8f) }
            EventType.LIGHT_BROKEN -> audio.playSfx(SfxId.LIGHT_BREAK, 1f)
            EventType.LIGHT_DEGRADED -> audio.playSfx(SfxId.LIGHT_FLICKER, 0.7f)
            EventType.ON_PUZZLE_STARTED -> audio.playSfx(SfxId.PAPER, 0.8f)
            EventType.MEDICINE_PUZZLE_COMPLETED -> audio.playSfx(SfxId.CHIME, 0.9f)

            EventType.DIALOGUE_LINE -> dialogueVoice(event)

            // ---- v0.8: la criatura. value de CREATURE_STEP = bit0 persecución | (cercanía 0..100) << 1
            EventType.CREATURE_STEP -> {
                val chasing = (event.value and 1) == 1
                val prox = ((event.value shr 1) / 100f).coerceIn(0f, 1f)
                if (prox > 0.03f) audio.playSfx(SfxId.CREATURE_STEP, (if (chasing) 1.0f else 0.7f) * prox, surface())
            }
            EventType.CREATURE_STATE -> when (event.sourceId) {
                "INVESTIGATE" -> { audio.playSfx(SfxId.CREATURE_ALERT, 0.55f); audio.playSfx(SfxId.CREATURE_WET, 0.5f) }
                "CHASE" -> {
                    audio.playSfx(SfxId.CREATURE_CHASE, 1f)
                    audio.playMusic(MusicId.TENSION, 0.6f)
                }
                "LOST_TARGET" -> audio.playSfx(SfxId.CREATURE_LOST, 0.8f)
                "RETURN_TO_PATROL" -> audio.playMusic(MusicId.HOME, 8f)   // la tensión baja gradualmente
                else -> {}
            }
            EventType.CREATURE_CAPTURE -> {
                // v0.17: nada de rugido largo aquí: inhalación invertida + silencio raro (la música se corta de
                // golpe y el ambiente baja). El golpe llega con el screamer (SCREAM_IMPACT en el cue 0, a los
                // 0,08 s). La música queda en SILENCE hasta que la captura termina y Scene la restaura en HOME.
                audio.playSfx(SfxId.SCREAM_PRE, 1f)
                audio.playMusic(MusicId.SILENCE, 0.15f)
                audio.duck(0.15f, 0.1f)
            }

            EventType.FROG_TALK -> {
                audio.playSfx(SfxId.CLOTH, 0.6f)
                audio.playSfx(SfxId.PLUSH_TAP, 0.6f)
            }

            EventType.CONVERSATION_STARTED -> {
                audio.duck(0.30f, 1.0f)
                audio.setAmbience(AmbienceId.CONVERSATION, 1.5f)
                audio.playMusic(MusicId.FROG_SCENE, 2.5f)
            }

            EventType.CONVERSATION_ENDED -> {
                audio.duck(1f, 2.5f)
                audio.setAmbience(houseAmbience(), 3f)
                audio.playMusic(MusicId.HOME, 4f)
            }

            // ---- v0.9: la noche en que mamá desaparece
            EventType.CHILD_CLIMBS_BED -> audio.playSfx(SfxId.BED_CLIMB, 0.9f)
            EventType.CHILD_LIES_DOWN -> audio.playSfx(SfxId.BED_SETTLE, 0.9f)
            EventType.SLEEP_FADE_STARTED -> {
                // el mundo se apaga: música fuera, ambiente casi en silencio, todo baja
                audio.duck(0.18f, 2.2f)
                audio.playMusic(MusicId.SILENCE, 2f)
                audio.setAmbience(AmbienceId.SILENT, 2.5f)
            }
            EventType.MOM_SCREAM -> audio.playSfx(SfxId.MOM_SCREAM, 1f)
            EventType.WINDOW_CRASH -> audio.playSfx(SfxId.WINDOW_CRASH, 0.9f)
            EventType.CHILD_WAKES -> {
                audio.duck(1f, 3.5f)
                audio.setAmbience(houseAmbience(), 3f)
            }
            EventType.WEATHER_CHANGED -> {
                weather = event.sourceId
                audio.setAmbience(houseAmbience(), 3f)
            }
            EventType.CREATURE_INTRO_STARTED -> {
                audio.playSfx(SfxId.CREATURE_REVEAL, 1f)
                audio.playMusic(MusicId.TENSION, 2.5f)
            }
            EventType.CREATURE_INTRO_ENDED -> audio.playMusic(MusicId.HOME, 8f)

            else -> {}
        }
    }

    /** Voz del niño o de mamá al empezar cada línea de texto: balbuceo cuya longitud sigue a la del texto. */
    private fun dialogueVoice(e: GameEvent) {
        val units = (e.value / 6).coerceIn(2, 9)
        lineCounter++
        if (e.sourceId == KID) {
            audio.playVoice(VoiceId.CHILD, Emotion.SOFT, 0.55f, VoiceKind.BABBLE, units, lineCounter)
        } else if (e.sourceId.startsWith("MAM")) {
            audio.playVoice(VoiceId.MOTHER, Emotion.WARM, 0.55f, VoiceKind.BABBLE, units, lineCounter)
        }
    }

    companion object {
        const val KID = "KID"
    }
}
