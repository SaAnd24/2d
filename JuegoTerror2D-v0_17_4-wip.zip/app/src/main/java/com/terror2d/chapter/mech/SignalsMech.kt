package com.terror2d.chapter.mech
import com.terror2d.core.Depth

import com.terror2d.audio.SfxId
import com.terror2d.chapter.ChapterFlags
import kotlin.math.abs

/**
 * C5 — El reflejo que no pertenece a la casa. La azotea (Roof) en TRAUMA, con la arandela ya encajada en la base
 * de la antena. Hay que alinear las tres señales de la carta C4, EN SU ORDEN, de arriba abajo:
 * sombra de la antena, luz fija del distribuidor, reflejo del espejo ([def.solution] = 2, 0, 1).
 *
 *  - Tres SEÑALES (fichas) a la izquierda —sombra, luz, espejo— que se ARRASTRAN a tres huecos ordenados a la
 *    derecha (arriba, medio, abajo). Al soltar cerca de un hueco, la ficha encaja en él; si el hueco está ocupado
 *    o se suelta lejos, vuelve a su sitio. No hay PROBAR: en cuanto las tres están en su orden, los haces se
 *    alinean y el espejo se oscurece.
 *  - Una ficha en un hueco equivocado no bloquea nada: se puede volver a coger; solo cuenta como equivocación
 *    para las pistas (los haces se cruzan y parpadean).
 *  - Profundidad 2.5D: las fichas son objetos en primer plano (depth 0.75, se agarran grandes) y los huecos están
 *    en la pared del fondo (depth 0.30); la vista global está en depth 0.70 ([PuzzleBook]). La arandela se dibuja
 *    encajada en la base de la antena (viene de C3; el director ya exige GOT_WASHER en [def.requires]).
 *  - Observación: para ver la luz fija del distribuidor desde la azotea hay que estar en el borde
 *    ([observeDepthMin] = [ChapterFlags.C5_OBSERVE_DEPTH_MIN] = 0.6); esa observación (`obs_C5`, en Roof NORMAL)
 *    la exige el director en [def.requires] y la controla la escena.
 */
class SignalsMech : Mechanism("C5") {

    override val observeDepthMin: Float? = ChapterFlags.C5_OBSERVE_DEPTH_MIN

    /** Señales: 0 luz fija del distribuidor, 1 reflejo del espejo, 2 sombra de la antena. */
    val tokens = arrayOf(
        Draggable(TOKEN_X, TOKEN_Y[0], 18f), // luz
        Draggable(TOKEN_X, TOKEN_Y[1], 18f), // espejo
        Draggable(TOKEN_X, TOKEN_Y[2], 18f)  // sombra
    )

    /** Señal colocada en cada hueco (0..2, de arriba abajo) o -1 si está vacío. */
    val placed = IntArray(3) { -1 }

    /** Profundidad 2.5D de las fichas (primer plano) y de los huecos (fondo). */
    val tokenDepth: Float get() = 0.75f
    val slotDepth: Float get() = 0.30f

    private var active = -1

    fun slotX(k: Int): Float = SLOT_X
    fun slotY(k: Int): Float = SLOT_Y[k]

    /** Hueco donde está la señal [s], o -1 si no está colocada. */
    fun slotOf(s: Int): Int = placed.indexOf(s)

    /** true si la señal [s] está en el hueco que le corresponde según la solución. */
    fun signalOk(s: Int): Boolean {
        val k = slotOf(s)
        return k >= 0 && def.solution[k] == s
    }

    private fun slotAt(x: Float, y: Float): Int {
        for (k in 0 until 3) {
            if (abs(x - SLOT_X) <= SLOT_HALF * Depth.depthScale(slotDepth) &&
                abs(y - SLOT_Y[k]) <= SLOT_HALF * Depth.depthScale(slotDepth)
            ) return k
        }
        return -1
    }

    override fun onDown(x: Float, y: Float) {
        active = -1
        var best = -1
        var bd = 1e9f
        for (s in 0 until 3) {
            val d = dist(x, y, tokens[s].x, tokens[s].y)
            if (d <= tokens[s].grab * Depth.depthScale(tokenDepth) + 4f && d < bd) { bd = d; best = s }
        }
        if (best < 0) return
        active = best
        // al coger una ficha colocada, su hueco queda libre
        val k = slotOf(best)
        if (k >= 0) placed[k] = -1
        tokens[best].begin(x, y)
        play(SfxId.MECH_METAL_CLINK, 0.3f)
    }

    override fun onMove(x: Float, y: Float, dx: Float, dy: Float) {
        val s = active
        if (s < 0) return
        tokens[s].dragTo(x, y, 20f, 20f, 300f, 164f)
    }

    override fun onUp(x: Float, y: Float) {
        val s = active
        active = -1
        if (s < 0) return
        tokens[s].end()
        val k = slotAt(tokens[s].x, tokens[s].y)
        if (k < 0) {
            // lejos de todo hueco: vuelve a su sitio
            tokens[s].x = TOKEN_X
            tokens[s].y = TOKEN_Y[s]
            return
        }
        if (placed[k] >= 0) {
            tokens[s].x = TOKEN_X
            tokens[s].y = TOKEN_Y[s]
            say("Ese hueco ya tiene su señal.", 1.8f)
            return
        }
        placed[k] = s
        tokens[s].x = SLOT_X
        tokens[s].y = SLOT_Y[k]
        play(SfxId.MECH_METAL_CLINK, 0.6f)
        if (!signalOk(s)) {
            mistake("Los haces se cruzan. Esa señal no va ahí.")
        } else {
            say(SIGNAL_TEXT[s], 2.4f)
        }
    }

    override fun update(dt: Float) {
        if (!solved && active < 0 && placed.contentEquals(def.solution)) {
            markSolved()
            later(0.4f, SfxId.MECH_RESONANCE, 0.6f)
            later(1.4f, SfxId.MECH_DEEP_THUMP, 0.8f)
            later(2.2f, SfxId.PUZZLE_SOLVED, 0.5f)
        }
    }

    /** 0..1 de cuánto se ha oscurecido el reflejo del espejo tras resolver (para el dibujo). */
    val mirrorDark: Float get() = if (!solved) 0f else (solvedTime / 1.8f).coerceIn(0f, 1f)

    override fun solvedHold(): Float = 4.0f

    companion object {
        const val TOKEN_X = 72f
        val TOKEN_Y = floatArrayOf(52f, 96f, 140f)
        const val SLOT_X = 252f
        val SLOT_Y = floatArrayOf(48f, 90f, 132f)
        const val SLOT_HALF = 17f
        val SIGNAL_TEXT = arrayOf(
            "La luz fija del distribuidor queda en su sitio.",
            "El reflejo del espejo queda en su sitio.",
            "La sombra de la antena queda en su sitio."
        )
    }
}
