package com.terror2d.chapter.mech
import com.terror2d.core.Depth

import com.terror2d.audio.SfxId
import kotlin.math.abs

/**
 * C2 — Las huellas que retroceden. El armario (Closet): una caja en el suelo y, en la pared del fondo, la marca
 * del retrato. Dos gestos físicos, sin ranuras ni PROBAR:
 *
 *  - EMPUJAR LA CAJA: se ARRASTRA. Al soltar, el desplazamiento decide la dirección: a la derecha (solución),
 *    a la izquierda o hacia el fondo (arrastrar hacia arriba). Un empujón en dirección equivocada no bloquea nada:
 *    la caja se puede volver a empujar; solo cuenta como equivocación para las pistas.
 *  - LA MARCA DEL RETRATO: se TOCA para girarla (vertical -> horizontal -> girada -> vertical...). La solución es
 *    GIRADA, como el símbolo del retrato de T2 y la marca de la puerta del estudio.
 *  - Se resuelve cuando la caja está empujada a la derecha Y la marca está girada, a la vez. Detrás de la caja
 *    aparece el pestillo y se abre la puerta secundaria hacia el estudio.
 *  - Profundidad 2.5D: la caja está en primer plano (suelo, depth 0.75) y la marca en la pared del fondo
 *    (depth 0.30); la vista global está en depth 0.60 ([PuzzleBook]). La zona táctil de la marca es más pequeña
 *    que la de la caja, como se ve.
 *  - La pista clave (las huellas entran en la pared por la derecha) es la observación `obs_C2` en TRAUMA, que el
 *    director ya exige en [def.requires]; en TRAUMA el mecanismo dibuja las huellas continuando hacia la pared.
 */
class FootprintsMech : Mechanism("C2") {

    /** Caja: empieza en el centro del suelo; se arrastra. */
    val box = Draggable(BOX_START_X, BOX_START_Y, 22f)

    /** Última dirección de empujón al soltar: -1 ninguno, 0 izquierda, 1 derecha, 2 fondo. */
    var push: Int = -1
        private set

    /** Orientación de la marca: 0 vertical, 1 horizontal, 2 girada. */
    var markRot: Int = 0
        private set

    /** Centro de la marca del retrato en la pared del fondo. */
    val markX: Float get() = MARK_X
    val markY: Float get() = MARK_Y

    /** Profundidad 2.5D de cada plano: caja en primer plano, marca en la pared del fondo. */
    val boxDepth: Float get() = 0.75f
    val markDepth: Float get() = 0.30f

    private var dragging = false

    val pushOk: Boolean get() = push == def.solution[0]
    val markOk: Boolean get() = markRot == def.solution[1]

    override fun onDown(x: Float, y: Float) {
        // la marca está en la pared del fondo: zona táctil pequeña (escalada por SU profundidad, 0.30)
        if (dist(x, y, MARK_X, MARK_Y) <= MARK_GRAB * Depth.depthScale(markDepth)) {
            markRot = (markRot + 1) % 3
            play(SfxId.MECH_WOOD_CLICK, 0.5f)
            say(MARK_TEXT[markRot], 2.0f)
            return
        }
        if (box.hitScaled(x, y, Depth.depthScale(boxDepth))) {
            box.begin(x, y)
            dragging = true
            play(SfxId.MECH_WOOD_SLIDE, 0.3f)
        }
    }

    override fun onMove(x: Float, y: Float, dx: Float, dy: Float) {
        if (!dragging) return
        box.dragTo(x, y, 52f, 92f, 268f, 152f)
    }

    override fun onUp(x: Float, y: Float) {
        if (!dragging) return
        dragging = false
        box.end()
        val dx = box.x - BOX_START_X
        val dy = box.y - BOX_START_Y
        push = when {
            dx >= PUSH_MIN -> 1 // derecha
            dx <= -PUSH_MIN -> 0 // izquierda
            dy <= -PUSH_MIN -> 2 // fondo (hacia arriba en la vista)
            else -> -1
        }
        when (push) {
            1 -> {
                box.x = BOX_START_X + PUSH_SNAP
                box.y = BOX_START_Y
                play(SfxId.MECH_WOOD_SLIDE, 0.6f)
                say("La caja se mueve a la derecha. Detrás hay algo.", 2.4f)
            }
            0, 2 -> {
                box.x = if (push == 0) BOX_START_X - PUSH_SNAP else BOX_START_X
                box.y = if (push == 2) BOX_START_Y - PUSH_SNAP else BOX_START_Y
                play(SfxId.MECH_WOOD_SLIDE, 0.5f)
                mistake("Por ahí la caja no deja ver nada. Las huellas van hacia el otro lado.")
            }
            else -> {
                // empujón demasiado corto: la caja vuelve a su sitio, sin contar como error
                box.x = BOX_START_X
                box.y = BOX_START_Y
            }
        }
    }

    override fun update(dt: Float) {
        if (!solved && pushOk && markOk) {
            markSolved()
            later(0.4f, SfxId.MECH_METAL_CLINK, 0.7f)
            later(1.2f, SfxId.MECH_STONE_DRAG, 0.6f)
            later(2.0f, SfxId.PUZZLE_SOLVED, 0.5f)
        }
    }

    /** 0..1 de cuánto se ha abierto el pestillo tras la caja (para el dibujo). */
    val latchOpen: Float get() = if (!solved) 0f else (solvedTime / 1.6f).coerceIn(0f, 1f)

    override fun solvedHold(): Float = 3.2f

    companion object {
        const val BOX_START_X = 150f
        const val BOX_START_Y = 130f
        const val PUSH_MIN = 28f
        const val PUSH_SNAP = 40f
        const val MARK_X = 250f
        const val MARK_Y = 58f
        const val MARK_GRAB = 18f
        val MARK_TEXT = arrayOf(
            "La marca queda vertical.",
            "La marca queda horizontal.",
            "La marca queda girada, como el símbolo del retrato."
        )
    }
}
