package com.terror2d.chapter.mech

import com.terror2d.audio.SfxId

/**
 * T3 — El pasillo que no cabe. El pasillo del segundo piso en TRAUMA, visto en profundidad: tres puertas que
 * retroceden (izquierda cerca, medio, derecha lejos). No hay ranuras ni PROBAR: se TOCA una puerta para cruzarla.
 *
 *  - La solución es la de siempre ([def.solution] = medio, izquierda, derecha): hay que seguir la GRIETA, que baja
 *    por el medio, se desvía a la izquierda y termina a la derecha. La grieta se dibuja continua y se ilumina por
 *    tramos a medida que se acierta (con [assist] >= 1 se ve más clara desde el principio).
 *  - Una puerta equivocada NO es un callejón sin salida: el niño vuelve al distribuidor ([stage] = 0) y lo vuelve a
 *    intentar; los aciertos no se pierden más allá del tramo en curso (un error nunca reinicia el capítulo).
 *  - Profundidad 2.5D: cada puerta está en su propio plano (izquierda 0.35, medio 0.55, derecha 0.75); su zona
 *    táctil se escala con [Mechanism.depthScale] (la puerta lejana es más pequeña al tacto, como se ve). La vista
 *    global del mecanismo está en depth 0.45 ([PuzzleBook]).
 *  - No exige modo de movimiento: la puerta de entrada es la observación `obs_T3` (la grieta), que el director ya
 *    exige en [def.requires] antes de abrir el puzle.
 */
class CorridorMech : Mechanism("T3") {

    /** Puertas acertadas seguidas en el orden de la grieta (0..3; 3 = resuelto). */
    var stage: Int = 0
        private set

    /** Solución del libro (medio, izquierda, derecha): índices de puerta en orden. */
    val solution: IntArray get() = def.solution

    /** Centro de cada puerta (índice 0 izquierda, 1 medio, 2 derecha). */
    fun doorX(i: Int): Float = DOOR_X[i]
    fun doorY(i: Int): Float = DOOR_Y[i]

    /** Profundidad 2.5D de cada puerta (la lejana es más pequeña y está más alta en la vista). */
    fun doorDepth(i: Int): Float = DOOR_DEPTH[i]

    /** 0..1 de cuánto se ha iluminado el tramo de grieta que lleva a la puerta [i] (para el dibujo). */
    fun crackLit(i: Int): Float {
        if (solved) return 1f
        // el tramo k une la puerta solution[k-1] (o el inicio) con solution[k]; se ilumina al acertar
        val k = solution.indexOf(i)
        return if (k in 0 until stage) 1f else 0.25f + 0.2f * assist
    }

    private fun doorAt(x: Float, y: Float): Int {
        for (i in 0 until 3) {
            if (hitRectScaled(x, y, DOOR_X[i], DOOR_Y[i], DOOR_HALF_W, DOOR_HALF_H, DOOR_DEPTH[i])) return i
        }
        return -1
    }

    override fun onDown(x: Float, y: Float) {
        val i = doorAt(x, y)
        if (i < 0) return
        if (i == solution[stage]) {
            stage++
            play(SfxId.MECH_WOOD_CLICK, 0.7f)
            say(DOOR_TEXT[stage - 1], 2.6f)
            if (stage >= 3) {
                markSolved()
                later(0.5f, SfxId.MECH_STONE_DRAG, 0.7f)
                later(1.4f, SfxId.PUZZLE_SOLVED, 0.55f)
            }
        } else {
            // puerta equivocada: vuelta al distribuidor, sin perder nada más
            play(SfxId.MECH_MUFFLED, 0.6f)
            stage = 0
            mistake("Esa puerta no era. Vuelvo al distribuidor y sigo la grieta.")
        }
    }

    override fun solvedHold(): Float = 3.2f

    companion object {
        val DOOR_X = floatArrayOf(70f, 160f, 250f)
        val DOOR_Y = floatArrayOf(96f, 88f, 96f)
        /** Profundidad de cada puerta: izquierda cerca, medio, derecha lejos. */
        val DOOR_DEPTH = floatArrayOf(0.35f, 0.55f, 0.75f)
        const val DOOR_HALF_W = 26f
        const val DOOR_HALF_H = 62f
        val DOOR_TEXT = arrayOf(
            "La grieta baja por el medio. Esta puerta es la buena.",
            "Ahora se desvía a la izquierda.",
            "Y termina a la derecha. El reverso del estudio está ahí."
        )
    }
}
