package com.terror2d.chapter

/**
 * Capítulo I (la casa de los dos mundos): todos los hitos viven en el [com.terror2d.story.StoryState] de siempre,
 * como simples nombres. NINGUNO depende del nivel visual de deterioro (regla de los seis estados).
 */
object ChapterFlags {
    const val MIRROR_FRAGMENT_OBTAINED = "mirror_fragment_obtained"
    const val MIRROR_USED = "mirror_used_once"
    const val HOUSE_EXIT_UNLOCKED = "house_exit_unlocked"
    const val CHAPTER_COMPLETE = "chapter1_complete"

    // piezas y datos que dan los puzles (no son un inventario: son hitos)
    const val GOT_BRASS = "got_brass_strip"          // N1
    const val GOT_LETTER_A = "got_letter_a"          // N2
    const val N3_PATTERN_KNOWN = "n3_pattern_known"  // N3
    const val GOT_PANEL_KEY = "got_panel_key"        // N4
    const val GOT_LETTER_B = "got_letter_b"          // estudio (TRAUMA)
    const val GOT_GLASS = "got_glass_water"          // cocina: el vaso con agua va en las manos (inventario)
    const val GLASS_PLACED = "glass_placed_bath"     // baño familiar: el vaso queda sobre el lavabo
    const val OBS_C3_N = "obs_c3_normal"             // reflejo visto en NORMAL
    const val OBS_C3_T = "obs_c3_trauma"             // figura vista en TRAUMA (con ambos queda observed("C3"))
    const val GOT_WASHER = "got_washer"              // C3

    // v0.17 (2.5D): reglas de profundidad / movimiento de los puzles (los valores viven aquí, no en cada mecanismo).
    /** C5: para OBSERVAR la luz fija del distribuidor desde la azotea hay que estar en el borde (profundidad >= 0.6). */
    const val C5_OBSERVE_DEPTH_MIN = 0.6f
    /** C3: el hueco bajo los cimientos solo se recorre agachado ([com.terror2d.core.MoveMode.CROUCH]). */
    const val C3_REQUIRES_CROUCH = true

    fun solved(id: String) = "puzzle_" + id + "_solved"
    fun started(id: String) = "puzzle_" + id + "_started"

    /** Dato observado en el OTRO mundo (los puzles CROSS se preparan mirando en un mundo y actuando en el otro). */
    fun observed(id: String) = "obs_" + id

    val PUZZLE_IDS: List<String> = listOf(
        "N1", "N2", "N3", "N4", "N5",
        "T1", "T2", "T3", "T4", "T5",
        "C1", "C2", "C3", "C4", "C5"
    )
}

/**
 * Nivel visual (1..3) de cada mundo. Es PURAMENTE visual: lo calcula la capa de presentación a partir de las capturas
 * del sistema de progresión ya existente ([com.terror2d.core.GameState.captureCount]); nada de la lógica lo lee.
 */
object VisualLevels {
    fun of(captureCount: Int): Int = when {
        captureCount <= 0 -> 1
        captureCount == 1 -> 2
        else -> 3
    }
}
