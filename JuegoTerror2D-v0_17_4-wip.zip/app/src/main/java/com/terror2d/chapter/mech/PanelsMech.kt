package com.terror2d.chapter.mech

import com.terror2d.audio.SfxId
import com.terror2d.core.MoveMode
import kotlin.math.abs

/**
 * C3 — El vaso de agua (los paneles del hueco). El hueco bajo los cimientos del almacén (Storage), al fondo: un
 * pasadizo bajo y estrecho con tres paredes y, bajo el tubo, cuatro paneles de mantenimiento. Sin ranuras ni PROBAR:
 *
 *  - Se TOCA una pared para encararla (izquierda / fondo / derecha). Al entrar se mira a la izquierda (tuberías);
 *    los paneles solo están en la pared del FONDO.
 *  - Encarando el fondo, se TOCA un panel: el tercero contando desde la izquierda (solución [def.solution] =
 *    fondo + tercer panel) se abre y dentro está la arandela; los demás no se mueven (equivocación para las pistas,
 *    sin perder nada).
 *  - Profundidad 2.5D: los paneles están en el plano más lejano del capítulo (depth 0.25, [PuzzleBook]): se ven
 *    pequeños y sus zonas táctiles son las más pequeñas del juego. El tubo pasa por delante de ellos (plano 0.5).
 *  - CROUCH: el hueco es bajo; el puzle exige [MoveMode.CROUCH] ([requiredMoveMode]). El director escribe el modo
 *    del jugador en [playerMoveMode]; mientras sea null (el motor aún no lo expone) el mecanismo es permisivo, y
 *    si llega un modo distinto de CROUCH los paneles no responden hasta agacharse. La entrada al hueco en sí la
 *    controla la escena (spot `spot_C3` en Storage, que ya exige T4 resuelto).
 *  - La pista (el reflejo del vaso señala el fondo, tercer panel) es la observación `obs_C3` en el baño familiar,
 *    que el director ya exige en [def.requires].
 */
class PanelsMech : Mechanism("C3") {

    override val requiredMoveMode: MoveMode? = MoveMode.CROUCH

    /** Pared que se está mirando: 0 izquierda, 1 fondo, 2 derecha. Al entrar se mira a la izquierda. */
    var facing: Int = 0
        private set

    /** Panel abierto al resolver (-1 = ninguno). */
    var openPanel: Int = -1
        private set

    val panelsVisible: Boolean get() = facing == WALL_BACK

    /** Los paneles responden solo agachado (o si el motor aún no dice en qué modo va el niño). */
    val canReachPanels: Boolean get() = playerMoveMode == null || playerMoveMode == MoveMode.CROUCH

    /** Centro del panel [i] (0..3) en la pared del fondo. */
    fun panelX(i: Int): Float = PANEL_X0 + i * PANEL_DX
    fun panelY(i: Int): Float = PANEL_Y

    override fun onDown(x: Float, y: Float) {
        if (facing == WALL_BACK) {
            val p = panelAt(x, y)
            if (p >= 0) {
                if (!canReachPanels) {
                    say("El hueco es bajo. Tengo que agacharme para llegar a los paneles.", 2.6f)
                    return
                }
                if (p == def.solution[1]) {
                    openPanel = p
                    play(SfxId.MECH_METAL_CLINK, 0.8f)
                    markSolved()
                    later(0.5f, SfxId.MECH_STONE_DRAG, 0.6f)
                    later(1.4f, SfxId.PUZZLE_SOLVED, 0.5f)
                } else {
                    play(SfxId.MECH_MUFFLED, 0.6f)
                    mistake("Ese panel no se mueve. Detrás solo hay tubería.")
                }
                return
            }
        }
        val w = wallAt(x, y)
        if (w >= 0 && w != facing) {
            facing = w
            play(SfxId.MECH_WOOD_SLIDE, 0.25f)
            if (w == WALL_BACK) say("Cuatro paneles bajo el tubo. El reflejo señalaba hacia aquí.", 2.6f)
        }
    }

    private fun wallAt(x: Float, y: Float): Int {
        if (y < WALL_TOP || y > WALL_BOTTOM) return -1
        return when {
            x < WALL_MID_L -> 0
            x <= WALL_MID_R -> 1
            x <= WALL_RIGHT -> 2
            else -> -1
        }
    }

    private fun panelAt(x: Float, y: Float): Int {
        for (i in 0 until 4) {
            if (abs(x - panelX(i)) <= PANEL_HALF_W * touchScale && abs(y - PANEL_Y) <= PANEL_HALF_H * touchScale) return i
        }
        return -1
    }

    /** 0..1 de cuánto se ha abierto el panel correcto (para el dibujo). */
    val panelOpen: Float get() = if (!solved) 0f else (solvedTime / 1.4f).coerceIn(0f, 1f)

    override fun solvedHold(): Float = 3.2f

    companion object {
        const val WALL_BACK = 1
        const val WALL_TOP = 30f
        const val WALL_BOTTOM = 160f
        const val WALL_MID_L = 108f
        const val WALL_MID_R = 212f
        const val WALL_RIGHT = 300f
        const val PANEL_X0 = 128f
        const val PANEL_DX = 28f
        const val PANEL_Y = 95f
        const val PANEL_HALF_W = 15f
        const val PANEL_HALF_H = 26f
    }
}
