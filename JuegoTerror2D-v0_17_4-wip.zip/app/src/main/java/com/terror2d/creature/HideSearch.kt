package com.terror2d.creature

import com.terror2d.core.HideSpot
import com.terror2d.core.HideSpotType
import kotlin.math.abs
import kotlin.math.min

/** Una parada del registro: la criatura va hasta [x] y revisa el escondite [spotId] durante [checkSeconds]. */
data class HideCheck(
    val spotId: String,
    val x: Float,
    val checkSeconds: Float,
    /** Probabilidad de encontrar al niño SI está escondido ahí (0..1). No es saber dónde está: es revisar. */
    val findChance: Float
)

/**
 * v0.17: la criatura BUSCA. Cuando entra en una sala con sospecha (o porque oyó un ruido en ella)
 * no sabe dónde está el niño: revisa los escondites de la sala uno por uno, del más cercano al
 * más lejano, y en cada uno decide con [resolve] si lo encuentra.
 *
 * Reglas (todas documentadas, ninguna es «saber la posición»):
 *  - Se busca solo si hay motivo: algún escondite de la sala en SUSPICION o peor, o un ruido oído
 *    en la sala ([shouldSearch]). Sin motivo, la criatura patrulla y pasa de largo.
 *  - Orden: por distancia a la criatura. Si el niño está en el escondite más lejano, la criatura
 *    pierde tiempo revisando los demás antes: eso es la ventana de escape.
 *  - [checkSeconds]: 1.4 s base + 0.4 s por uso acumulado del escondite (máx. +1.6 s). Cuanto más
 *    se abusa de un escondite, más a fondo lo revisa.
 *  - [findChance] si el niño está ahí: armario 0.30, debajo de la cama 0.25, cortinas 0.45 (la
 *    cortina tapa menos: [HideSpot.coverValue]) + 0.12 por uso acumulado (máx. 0.90 en total).
 *    Aguantar la respiración ([BREATH_HOLD_FIND_FACTOR]) lo reduce a la mitad: respirar delata.
 *  - La tirada es determinista ([rollFor] con [Det.hash01]): mismo intento, mismo resultado.
 *
 * Esto es lógica pura: la escena decide CUÁNDO buscar (al entrar en INVESTIGATE o al agotar la
 * estancia con sospecha), mueve a la criatura hasta cada [HideCheck.x] y resuelve con [resolve].
 * Si [resolve] dice que lo encontró, la escena la pone en CHASE hacia ese escondite (ver el
 * snippet de integración del informe); si no, sigue con el siguiente escondite y luego retoma
 * la ronda. El niño NUNCA es descubierto por estar en la sala: solo por estar en el escondite
 * revisado y perder la tirada.
 */
object HideSearch {

    const val BASE_CHECK_SECONDS = 1.4f
    const val CHECK_PER_SUSPICION = 0.4f
    const val MAX_SUSPICION_BONUS = 1.6f
    const val FIND_PER_SUSPICION = 0.12f
    const val MAX_FIND_CHANCE = 0.9f
    /** Encontrar a alguien que aguanta la respiración es la mitad de probable. */
    const val BREATH_HOLD_FIND_FACTOR = 0.5f

    /** true si hay motivo para registrar la sala: sospecha en algún escondite o ruido oído en ella. */
    fun shouldSearch(roomReaction: ClosetReaction, heardNoiseInRoom: Boolean): Boolean =
        roomReaction >= ClosetReaction.SUSPICION || heardNoiseInRoom

    /** Probabilidad base de encontrar al niño si está en [spot] (antes del modificador de respiración). */
    fun findChance(spot: HideSpot): Float {
        val base = when (spot.type) {
            HideSpotType.CLOSET -> 0.30f
            HideSpotType.UNDER_BED -> 0.25f
            HideSpotType.CURTAINS -> 0.45f
        }
        return (base + FIND_PER_SUSPICION * spot.suspicion).coerceIn(0f, MAX_FIND_CHANCE)
    }

    /** Tiempo que la criatura dedica a revisar [spot]. */
    fun checkSeconds(spot: HideSpot): Float =
        BASE_CHECK_SECONDS + min(MAX_SUSPICION_BONUS, CHECK_PER_SUSPICION * spot.suspicion)

    /**
     * Plan de registro de una sala: sus escondites ordenados del más cercano al más lejano a la
     * criatura. Los [HideSpot] deben llevar su sospecha actual (ver
     * [ClosetMemory.withSuspicion]); la lista vacía significa «nada que revisar aquí».
     */
    fun plan(spots: List<HideSpot>, creatureX: Float): List<HideCheck> =
        spots.sortedBy { abs(it.x - creatureX) }.map { s ->
            HideCheck(s.id, s.x, checkSeconds(s), findChance(s))
        }

    /**
     * ¿Encuentra la criatura al niño en este escondite? Solo puede ser true si el niño está
     * escondido AHÍ ([childHiddenHere]); en cualquier otro caso es false, por muy alta que sea
     * [check.findChance]. [roll01] es la tirada determinista ([rollFor]).
     */
    fun resolve(check: HideCheck, childHiddenHere: Boolean, holdingBreath: Boolean, roll01: Float): Boolean {
        if (!childHiddenHere) return false
        val chance = check.findChance * if (holdingBreath) BREATH_HOLD_FIND_FACTOR else 1f
        return roll01 < chance
    }

    /** Tirada determinista 0..1 para revisar [spotId] en el intento [attempt] (misma semilla, mismo resultado). */
    fun rollFor(spotId: String, seed: Int, attempt: Int): Float =
        Det.hash01(seed, spotId.hashCode(), attempt)
}
