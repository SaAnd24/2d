package com.terror2d.creature

import com.terror2d.core.FloorType
import com.terror2d.core.MoveMode
import kotlin.math.abs

/** Tipo de ruido. [base] es la intensidad típica (0..1): caminar poco, un florero caído muchísimo. */
enum class NoiseType(val base: Float, val duration: Float, val carries: Boolean = false) {
    /** v0.16: pisadas más discretas: solo las oye si está bastante cerca (antes la atraían desde media habitación). */
    WALK(0.14f, 0.2f),
    RUN(0.5f, 0.3f),
    /** v0.17: pisada en sigilo: tan baja que queda bajo el umbral de oído en casi cualquier suelo. */
    SNEAK(0.05f, 0.2f),
    /** v0.17: pisada agachado: prácticamente inaudible. */
    CROUCH(0.03f, 0.2f),
    DOOR(0.5f, 0.5f),
    OBJECT_HIT(0.75f, 0.6f),
    PLAYER_FALL(0.75f, 0.6f),
    VASE_FALL(1.0f, 1.0f),
    OBJECT_BROKEN(1.0f, 1.0f),
    /** v0.10: atravesar una ventana (trepar, caer al otro lado). */
    WINDOW(0.55f, 0.6f),
    /** v0.10: interactuar con objetos (cajones, interruptores, tirar de algo). */
    INTERACT(0.3f, 0.3f),
    /** v0.10: un foco que revienta. */
    LIGHT_BREAK(0.85f, 0.8f),
    /** v0.10: abrir/cerrar la puerta de un armario. */
    CLOSET(0.28f, 0.4f),
    /** v0.16: un objeto soltado en el suelo. Es lo bastante fuerte como para que la criatura sepa EN QUÉ HABITACIÓN fue. */
    OBJECT_DROP(0.9f, 0.9f, carries = true)
}

/** Un ruido NO es «el jugador está aquí»: lleva posición, intensidad, duración, tipo y el momento en que sonó. */
class NoiseEvent(
    val x: Float,
    val segmentId: String,
    val type: NoiseType,
    val intensity: Float = type.base,
    val duration: Float = type.duration,
    val time: Float = 0f,
    /** v0.17: profundidad en la que sonó (0 fondo .. 1 primer plano). Un ruido lejos en profundidad se oye más débil. */
    val depth: Float = 0.6f
)

/**
 * Ruido de pasos del jugador según CÓMO se mueve y SOBRE QUÉ pisa (v0.17).
 * La madera cruje, la alfombra amortigua, las escaleras crujen mucho:
 *
 *   modo \ suelo | MADERA | ALFOMBRA | BALDOSA | ESCALERAS
 *   ANDAR        |  0.161 |   0.028  |  0.119  |  0.189
 *   CORRER       |  0.575 |   0.100  |  0.425  |  0.675
 *   SIGILO       |  0.058 |   0.010  |  0.043  |  0.068
 *   AGACHADO     |  0.035 |   0.006  |  0.026  |  0.041
 *
 * El umbral de oído es 0.08: andar sobre madera se oye de cerca; en sigilo o agachado, o
 * andando sobre alfombra, el paso queda por debajo del umbral (la criatura no lo oye).
 */
object FootstepNoise {
    fun baseIntensity(mode: MoveMode): Float = when (mode) {
        MoveMode.WALK -> NoiseType.WALK.base
        MoveMode.RUN -> NoiseType.RUN.base
        MoveMode.SNEAK -> NoiseType.SNEAK.base
        MoveMode.CROUCH -> NoiseType.CROUCH.base
    }

    /** Multiplicador del suelo: la madera cruje (x1.15), la alfombra casi no suena (x0.2). */
    fun floorMultiplier(floor: FloorType): Float = when (floor) {
        FloorType.WOOD -> 1.15f
        FloorType.CARPET -> 0.2f
        FloorType.TILE -> 0.85f
        FloorType.STAIRS -> 1.35f
    }

    fun intensity(mode: MoveMode, floor: FloorType): Float =
        (baseIntensity(mode) * floorMultiplier(floor)).coerceIn(0f, 1f)

    fun type(mode: MoveMode): NoiseType = when (mode) {
        MoveMode.WALK -> NoiseType.WALK
        MoveMode.RUN -> NoiseType.RUN
        MoveMode.SNEAK -> NoiseType.SNEAK
        MoveMode.CROUCH -> NoiseType.CROUCH
    }

    /** Evento de pisada listo para emitir: tipo e intensidad salen del modo y del suelo. */
    fun event(
        x: Float,
        segmentId: String,
        mode: MoveMode,
        floor: FloorType,
        depth: Float,
        time: Float
    ): NoiseEvent {
        val t = type(mode)
        return NoiseEvent(x, segmentId, t, intensity(mode, floor), t.duration, time, depth)
    }
}

/** Cola de ruidos recientes (el juego publica, la criatura consulta). Sin allocations por frame salvo el propio ruido. */
class NoiseBus {
    private val list = ArrayList<NoiseEvent>()
    val recent: List<NoiseEvent> get() = list

    fun emit(n: NoiseEvent) { list.add(n) }

    /** Emite una pisada del jugador con el ruido real de su modo y su suelo (v0.17). */
    fun emitFootstep(
        x: Float,
        segmentId: String,
        mode: MoveMode,
        floor: FloorType,
        depth: Float,
        time: Float
    ) {
        list.add(FootstepNoise.event(x, segmentId, mode, floor, depth, time))
    }

    /** Descarta los ruidos que ya terminaron (duración + margen). */
    fun prune(now: Float) {
        var i = 0
        while (i < list.size) {
            if (now - list[i].time > list[i].duration + 0.25f) list.removeAt(i) else i++
        }
    }
}

/** Hash determinista (0..1) para variaciones que NO deben ser azar por frame. */
object Det {
    fun hash01(a: Int, b: Int, c: Int = 0): Float {
        var h = a * 374761393 + b * 668265263 + c * 2147483647
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFFFF) / 16777216f
    }
}

/** Oído de la criatura: lo que percibe es posición APROXIMADA y se debilita con la distancia. */
object Hearing {
    const val RANGE = 260f
    const val THRESHOLD = 0.08f

    /** v0.17: cuánto amortigua la diferencia de profundidad (0.30 = un ruido en el extremo opuesto de la banda se oye un 30% más débil). */
    const val DEPTH_ATTENUATION = 0.30f

    fun perceivedIntensity(n: NoiseEvent, listenerX: Float): Float =
        perceivedIntensity(n, listenerX, n.depth)

    /** Intensidad percibida: se debilita con la distancia en X y con la diferencia de profundidad. */
    fun perceivedIntensity(n: NoiseEvent, listenerX: Float, listenerDepth: Float): Float {
        val d = abs(n.x - listenerX)
        if (d >= RANGE) return 0f
        val depthFactor = 1f - DEPTH_ATTENUATION * abs(n.depth - listenerDepth).coerceIn(0f, 1f)
        return n.intensity * (1f - d / RANGE) * depthFactor
    }

    /** Posición que la criatura CREE haber oído: el error crece con la distancia y baja con la intensidad. */
    fun perceivedX(n: NoiseEvent, listenerX: Float, seed: Int): Float {
        val d = abs(n.x - listenerX)
        val err = (Det.hash01(seed, (n.time * 100f).toInt(), n.type.ordinal) - 0.5f) * 2f * d * 0.18f * (1f - n.intensity * 0.5f)
        return n.x + err
    }
}
