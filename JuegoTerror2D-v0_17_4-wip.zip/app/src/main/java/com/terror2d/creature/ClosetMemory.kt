package com.terror2d.creature

import com.terror2d.core.HideSpot

/**
 * v0.10: reacción de la criatura ante un escondite según el abuso. Base de la regla de escalada:
 * PASS (uso normal) -> SUSPICION (se detiene y se asoma: advertencia) -> WARNING -> CAPTURE (ya no se deja engañar).
 * Cada escondite tiene su propio contador; en 0.10 solo SUSPICION y CAPTURE tenían efecto de juego, pero la estructura
 * ya existe para no rehacer nada en 0.11.
 *
 * v0.17: la memoria cubre TODOS los tipos de escondite ([com.terror2d.core.HideSpotType]: armario,
 * debajo de la cama, detrás de las cortinas). La clave sigue siendo el id del escondite, así que
 * el mismo contador, los mismos umbrales y el mismo olvido valen para los tres tipos sin cambiar
 * la API que ya usa la escena (`register(id)`, `current(id)`, `forgive(id)`, `decay(dt)`). Las
 * sobrecargas con [HideSpot] son azúcar para no pasar ids sueltos.
 */
enum class ClosetReaction { PASS, SUSPICION, WARNING, CAPTURE }

class ClosetMemory(
    /** Usos a partir de los cuales aparece cada reacción (usos totales del MISMO armario). */
    private val suspicionAt: Int = 3,
    private val warningAt: Int = 4,
    private val captureAt: Int = 6
) {
    private val uses = HashMap<String, Int>()

    fun usesOf(closetId: String): Int = uses[closetId] ?: 0

    /** El niño entra en [closetId]. Devuelve la reacción que corresponde a ESTE uso. */
    fun register(closetId: String): ClosetReaction {
        val n = usesOf(closetId) + 1
        uses[closetId] = n
        return reactionFor(n)
    }

    fun reactionFor(n: Int): ClosetReaction = when {
        n >= captureAt -> ClosetReaction.CAPTURE
        n >= warningAt -> ClosetReaction.WARNING
        n >= suspicionAt -> ClosetReaction.SUSPICION
        else -> ClosetReaction.PASS
    }

    /** Reacción actual sin contar un uso nuevo. */
    fun current(closetId: String): ClosetReaction = reactionFor(usesOf(closetId))

    /** El niño entra en el escondite [spot] (cualquier tipo): mismo contador, mismos umbrales. */
    fun register(spot: HideSpot): ClosetReaction = register(spot.id)

    /** Reacción actual del escondite [spot] (cualquier tipo) sin contar un uso nuevo. */
    fun current(spot: HideSpot): ClosetReaction = current(spot.id)

    /** Usos acumulados del escondite [spot] (su sospecha, para el plan de búsqueda). */
    fun suspicionOf(spot: HideSpot): Int = usesOf(spot.id)

    /** Copia de [spot] con su sospecha actual (para [HideSearch.plan] y los tests). */
    fun withSuspicion(spot: HideSpot): HideSpot = spot.copy(suspicion = usesOf(spot.id))

    /** Tras una captura el armario "se olvida": el niño vuelve a su refugio. */
    fun forgive(closetId: String) { uses.remove(closetId) }

    fun reset() { uses.clear(); decayClock = 0f }

    private var decayClock = 0f

    /**
     * v0.16: el armario «olvida» con el tiempo: cada [DECAY_SECONDS] s de juego se descuenta un uso de cada armario. Así la
     * criatura no se vuelve sospechosa de TODOS los armarios para siempre (solo del que se abusa en poco tiempo).
     * v0.17: el olvido vale para TODOS los tipos de escondite (cada escondite tiene su propio contador y todos se
     * descuentan a la vez, un uso cada 40 s).
     */
    fun decay(dt: Float) {
        decayClock += dt
        if (decayClock < DECAY_SECONDS) return
        decayClock = 0f
        val it = uses.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            if (e.value <= 1) it.remove() else e.setValue(e.value - 1)
        }
    }

    companion object {
        const val DECAY_SECONDS = 40f
    }
}
