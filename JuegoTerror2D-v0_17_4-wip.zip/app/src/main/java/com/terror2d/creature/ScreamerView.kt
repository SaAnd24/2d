package com.terror2d.creature

import kotlin.math.sin

/**
 * v0.17: estado del SCREAMER de captura, REHECHO para ser corto y brutal. El arte sigue siendo los 18 fotogramas
 * de la MISMA cara reconstruida de forma procedural (ver tools/sprite_gen/screamer_face.py y screamer_anim.py),
 * que dibuja [com.terror2d.render.ScreamerRenderer]; aquí solo viven los TIEMPOS. Lo que cambia respecto a v0.10.1:
 *
 *  - Dura 0,92 s (antes 2,45 s): los 18 fotogramas pasan en menos de un segundo, sin tiempo de prepararse.
 *  - NO hay pausa de preparación: el primer fotograma ya sale con zoom 1,6 (la cara ya está encima) y el zoom
 *    crece hasta 2,3 en 0,25 s. La "pausa previa" de 0,5 s (FREEZE en CaptureSequence) ya no hace falta para
 *    descomprimir nada: el renderer nuevo decodifica bajo demanda (ver ScreamerRenderer).
 *  - Corte a negro ([cutToBlack]) a los 0,88 s: el susto se corta, no se desinfla.
 *  - Los cues de audio son los mismos 4 golpes de siempre (IMPACT, ROAR, GRAB, FINAL), pero mucho antes:
 *    0,08 / 0,20 / 0,46 / 0,87 s. El sonido previo (inhalación invertida + silencio raro) NO es un cue: lo
 *    dispara AudioDirector con SCREAM_PRE al empezar la captura.
 *
 *  fotograma 0      la cara tal cual, PERO ya con zoom 1,6 encima
 *  fotogramas 1-2   aproximación en perspectiva, la mandíbula empieza a abrirse
 *  fotograma 2      IMPACTO: la cara llena la pantalla                                   (CUE_IMPACT, 0,08 s)
 *  fotograma 5      RUGIDO: boca abierta, los brazos largos entran por los lados          (CUE_ROAR, 0,20 s)
 *  fotograma 9      AGARRE: la mano cae sobre la pantalla                                 (CUE_GRAB, 0,46 s)
 *  fotogramas 10-15 cabeza ladeada, ojo gigante, gaznate, mandíbula temblando
 *  fotograma 16     último plano de impacto (solo parpadea un fotograma)              (CUE_FINAL, 0,87 s)
 *  fotograma 17     no llega a verse: a los 0,88 s ya es NEGRO (corte)
 */
class ScreamerView {
    var active = false
        private set
    var time = 0f
        private set
    private var cueIndex = 0

    /** Fotograma de arte (0 until [FRAME_COUNT]) que toca ahora. */
    val frame: Int
        get() {
            var f = 0
            for (i in FRAME_START.indices) if (time >= FRAME_START[i]) f = i
            return f
        }

    /** 0..1 sacudida de pantalla: temblor constante (0,18) + pico en cada impacto (ventana de 0,20 s). */
    val shake: Float
        get() {
            var s = 0.18f
            for (c in CUE_TIMES) {
                val d = time - c
                if (d in 0f..0.20f) s = maxOf(s, 1f - d / 0.20f)
            }
            return s * (0.75f + 0.25f * sin(time * 90f))
        }

    /** 0..1 destello rojo/blanco del impacto (solo ~0,10 s tras la embestida y el agarre). */
    val flash: Float
        get() {
            var f = 0f
            for (c in CUE_TIMES) { val d = time - c; if (d in 0f..0.10f) f = maxOf(f, 1f - d / 0.10f) }
            return f
        }

    /**
     * Zoom del primerísimo plano: EMPIEZA en 1,6 (la cara ya está encima en el fotograma 0, no emerge de la
     * oscuridad) y crece hasta 2,3 en los primeros 0,25 s. Antes empezaba en 1,0 y apenas llegaba a 1,06.
     */
    val zoom: Float get() = 1.6f + 0.7f * (time / 0.25f).coerceIn(0f, 1f) + 0.08f * shake

    /**
     * Los últimos 0,04 s son negro puro: el último plano (fotograma 16) solo parpadea un fotograma y la cara
     * DESAPARECE de golpe en mitad del grito, no se desinfla. El renderer deja de dibujar la cara.
     */
    val cutToBlack: Boolean get() = active && time >= CUT_TO_BLACK_AT

    val done: Boolean get() = active && time >= DURATION

    fun begin() { active = true; time = 0f; cueIndex = 0 }
    fun end() { active = false }

    fun update(dt: Float) {
        if (!active) return
        time += dt
    }

    /** Devuelve (una vez) el siguiente cue de audio cuyo instante ya pasó, o -1. Los cues coinciden con cambios de fotograma. */
    fun consumeCue(): Int {
        if (!active || cueIndex >= CUE_TIMES.size) return -1
        if (time >= CUE_TIMES[cueIndex]) return cueIndex++
        return -1
    }

    companion object {
        const val FRAME_COUNT = 18
        /** Menos de un segundo: el susto no da tiempo a prepararse ni a apartar la vista. */
        const val DURATION = 0.92f
        /** La cara desaparece a los 0,88 s (el fotograma 16 solo parpadea un fotograma); quedan 0,04 s de negro. */
        const val CUT_TO_BLACK_AT = 0.88f
        /** Instante de inicio de cada fotograma: los 18 fotogramas de antes comprimidos en 0,92 s. */
        val FRAME_START = floatArrayOf(0f, 0.04f, 0.08f, 0.12f, 0.16f, 0.20f, 0.26f, 0.32f, 0.39f, 0.46f, 0.53f, 0.60f, 0.66f, 0.72f, 0.78f, 0.83f, 0.87f, 0.90f)
        /** Fotogramas en los que cae cada cue de audio (los mismos que en v0.10.1). */
        const val FRAME_IMPACT = 2
        const val FRAME_ROAR = 5
        const val FRAME_GRAB = 9
        const val FRAME_FINAL = 16
        /** Cues de audio: sincronizados con el inicio de su fotograma (sin retraso). */
        val CUE_TIMES = floatArrayOf(FRAME_START[FRAME_IMPACT], FRAME_START[FRAME_ROAR], FRAME_START[FRAME_GRAB], FRAME_START[FRAME_FINAL])
        const val CUE_IMPACT = 0
        const val CUE_ROAR = 1
        const val CUE_GRAB = 2
        const val CUE_FINAL = 3
    }
}
