package com.terror2d.creature

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class CreatureState { PATROL, INVESTIGATE, CHASE, LOST_TARGET, RETURN_TO_PATROL }

/** Intervalo X que la criatura no puede cruzar (hueco pequeño, ventilación). [blocksSight] = false: se ve a través. */
class Blocker(
    val x0: Float, val x1: Float, val blocksSight: Boolean, val isLight: Boolean = false,
    /** v0.16: un hueco estrecho que la criatura SÍ cruza (agachada y despacio) durante su ronda tranquila, pero no al perseguir. */
    val passableWhenCalm: Boolean = false
)

/**
 * v0.10.1: parámetros de la visión de la criatura (todos configurables; las pruebas usan otros valores sin tocar el código).
 *  - [range]: alcance con el niño bien iluminado (px de mundo).
 *  - [darkFactor]: fracción del alcance que conserva en oscuridad total (el alcance escala linealmente con la luz del niño).
 *  - [rearAwareness]: distancia a la que percibe lo que tiene a la espalda.
 *  - [holdMargin]: histéresis. Mientras ya lo está viendo (o lo vio hace menos de [holdWindow]) el alcance crece este
 *    porcentaje, para que la detección no se active y desactive a cada paso en el límite de distancia.
 *  - [checkInterval]: cada cuántos segundos reevalúa lo que ve (la IA corre a ese ritmo).
 *  - [headBonus]: v0.17, la cabeza es más grande y está más alta que antes: ve 12 px más lejos en cualquier luz
 *    (no es un aumento de dificultad, es la silueta nueva: la cabeza sobresale por encima de obstáculos bajos).
 *
 * El campo de visión es 1D (vista lateral): "delante" = el lado al que mira; las paredes (Blocker con blocksSight) cortan la vista.
 */
class VisionConfig(
    val range: Float = 300f,
    val darkFactor: Float = 0.5f,
    val rearAwareness: Float = 40f,
    val holdMargin: Float = 0.15f,
    val holdWindow: Float = 0.6f,
    val checkInterval: Float = 1f / 15f,
    val headBonus: Float = 12f
) {
    /** Alcance efectivo según la luz del niño (0..1) y si ya lo está siguiendo. */
    fun effectiveRange(light: Float, tracking: Boolean): Float {
        val base = range * (darkFactor + (1f - darkFactor) * light.coerceIn(0f, 1f))
        return (if (tracking) base * (1f + holdMargin) else base) + headBonus
    }
}

/** Lo que la criatura puede saber en cada paso: nada de «posición mágica» del niño salvo lo que ve. */
class Senses(
    var playerX: Float = 0f,
    var playerSegmentId: String = "",
    var playerHidden: Boolean = false,
    /** Brillo de la luz sobre el niño (0 = oscuridad, 1 = iluminado). */
    var playerLight: Float = 1f,
    var blockers: List<Blocker> = emptyList(),
    var now: Float = 0f,
    /** v0.10: el niño está entrando en un escondite o ya dentro (la criatura puede haberlo VISTO entrar). */
    var playerHiding: Boolean = false,
    /** v0.10: el niño está dentro de una zona de refugio de luz (foco que funciona). */
    var playerInRefuge: Boolean = false,
    /** v0.10: reacción acumulada de este armario ([ClosetReaction.ordinal]); 0 = uso normal. */
    var closetReaction: Int = 0,
    /** v0.17: profundidad del niño en la banda de suelo (0 fondo .. 1 primer plano). */
    var playerDepth: Float = 0.6f,
    /** v0.17: lo visible que es el niño según su modo (1 andar, 0.8 sigilo, 0.6 agachado, 1.15 corriendo). */
    var playerVisibility: Float = 1f,
    /** v0.17: profundidad de la propia criatura (para oír con atenuación por profundidad). */
    var creatureDepth: Float = 0.6f
)

/**
 * Cerebro de la criatura en vista lateral (1 eje). Máquina de estados PATROL → INVESTIGATE → CHASE →
 * LOST_TARGET → RETURN_TO_PATROL. Determinista (sin azar por frame) y barato: la IA corre a [AI_STEP].
 */
class CreatureBrain(
    var x: Float,
    val segmentId: String,
    private val patrolMin: Float,
    private val patrolMax: Float,
    private val seed: Int = 1,
    /** v0.10: rango REAL de movimiento (toda la habitación). La patrulla usa [patrolMin]..[patrolMax]. */
    private val moveMin: Float = patrolMin,
    private val moveMax: Float = patrolMax,
    /** v0.10.1: visión configurable. */
    val vision: VisionConfig = VisionConfig()
) {
    var state = CreatureState.PATROL
        private set
    var facing = 1f
        private set
    var speed = 0f
        private set
    /** v0.17: profundidad de la criatura en la banda de suelo (0 fondo .. 1 primer plano). La escribe la escena. */
    var depth: Float = 0.6f
    /** 0..1: intensidad (respiración, bocas, música). Sube rápido al ver al niño y baja despacio. */
    var arousal = 0.15f
        private set
    var lastKnownX = x
        private set
    var targetX = x
        private set
    var captured = false
        private set
    /** v0.10: capturado sacándolo del armario (la criatura lo VIO entrar). */
    var closetCapture = false
        private set
    /** v0.10: recuerda que el niño entró en un armario (conocimiento > estado de escondido). */
    var witnessedHide = false
        private set
    var hideX = 0f
        private set
    /** v0.10: parada a escuchar junto a un armario ocupado que NO vio ocupar. */
    val listening: Boolean get() = listenTimer > 0f
    /** v0.10: frenada por una zona de luz (fotofobia). */
    var blockedByLight = false
        private set
    /** v0.10: contador de cada vez que la luz la frena (para desgastar el foco). */
    var lightHits = 0
        private set
    /** v0.10: pidió asomarse al armario sospechoso (la escena lo consume). */
    private var peekPending = false
    /** 0..1: aceleración de la persecución (arranca lento, el niño gana unos metros). */
    var chaseRamp = 0f
        private set
    val reacting: Boolean get() = state == CreatureState.CHASE && reactTimer > 0f

    private var timer = 0f
    private var reactTimer = 0f
    private var listenTimer = 0f
    private var listenLatch = false
    private var sinceSeen = 99f
    private var blockedTimer = 0f
    private var refugeGiveUp = 0f
    private var lostTimer = 0f
    private var patrolIdx = 0
    private var aiAcc = 0f
    private var lookDir = 1f
    /** v0.16: meta de salida (X de la puerta/escalera por la que seguirá su ronda). NaN = se queda patrullando esta sala. */
    private var exitGoalX = Float.NaN
    /** v0.16: llegó a la salida pedida con [requestExit] (la escena entonces la saca de la sala). */
    var exitArrived = false
        private set
    /** v0.16: segundos de «calma» tras investigar: durante ellos ignora los ruidos pequeños. */
    private var calm = 0f

    fun update(dt: Float, s: Senses, noises: List<NoiseEvent>) {
        if (captured) { speed = 0f; return }
        if (calm > 0f) calm -= dt
        sinceSeen += dt
        if (refugeGiveUp > 0f) refugeGiveUp -= dt
        if (state == CreatureState.CHASE && reactTimer <= 0f) chaseRamp = min(1f, chaseRamp + dt / RAMP_TIME)
        else if (state != CreatureState.CHASE) chaseRamp = 0f
        aiAcc += dt
        if (aiAcc >= vision.checkInterval) { think(aiAcc, s, noises); aiAcc = 0f }
        move(dt, s)
        val goal = when (state) {
            CreatureState.CHASE -> 1f
            CreatureState.LOST_TARGET -> 0.7f
            CreatureState.INVESTIGATE -> 0.45f
            else -> 0.15f
        }
        val rate = if (goal > arousal) 2.5f else 0.25f   // sube de golpe, baja gradualmente
        arousal += (goal - arousal) * min(1f, rate * dt)
    }

    private fun think(dt: Float, s: Senses, noises: List<NoiseEvent>) {
        val sees = canSee(s) && !(s.playerInRefuge && refugeGiveUp > 0f)
        if (sees) sinceSeen = 0f
        if (!s.playerHiding) witnessedHide = false
        // v0.17.3: el pestillo de escucha solo se libera cuando ya NO hay nadie escondido cerca. Antes se
        // liberaba en cada tick de IA (playerHiding es false casi siempre) y la rama de escucha rearmaba
        // listenTimer a 2,2 s en cada tick: la criatura quedaba clavada escuchando para siempre junto al
        // escondido y nunca llegaba al punto de patrulla (losingTargetGoesLostThenReturnsToPatrol se
        // quedaba en RETURN_TO_PATROL). Escuchar sigue siendo una sola parada por encuentro: al expirar
        // el temporizador la criatura reanuda la marcha y no vuelve a escuchar hasta que el escondido
        // salga del alcance y vuelva a acercarse.
        if (!(s.playerHidden && s.playerSegmentId == segmentId && abs(s.playerX - x) < LISTEN_RANGE)) listenLatch = false
        // v0.10: el conocimiento manda. Si lo vio entrar en el armario, no se deja engañar por el estado "escondido".
        if (s.playerHiding) {
            // v0.16: solo cuenta como testigo si está razonablemente cerca (a más distancia el niño tuvo tiempo de ocultarse)
            val knew = canSeePosition(s) && sinceSeen <= WITNESS_WINDOW && abs(s.playerX - x) <= WITNESS_RANGE
            if (!witnessedHide && (knew || s.closetReaction >= ClosetReaction.CAPTURE.ordinal) && s.playerSegmentId == segmentId) {
                witnessedHide = true
                hideX = s.playerX
                lastKnownX = s.playerX
            }
        }
        if (witnessedHide) {
            if (state != CreatureState.CHASE) { state = CreatureState.CHASE; timer = 0f; chaseRamp = 0.5f; reactTimer = 0f }
            targetX = hideX
            lostTimer = 0f
            if (s.playerHidden && abs(hideX - x) < CLOSET_REACH) { captured = true; closetCapture = true }
            return
        }
        if (sees) {
            lastKnownX = s.playerX
            lostTimer = 0f
            val justSpotted = state != CreatureState.CHASE
            if (justSpotted) {
                state = CreatureState.CHASE; timer = 0f
                reactTimer = REACTION_TIME            // se queda un instante mirando: ventana real de supervivencia
                chaseRamp = 0f
                facing = if (s.playerX >= x) 1f else -1f
            }
            targetX = s.playerX
            // v0.17.3: si al verlo ya lo tiene a distancia de captura, lo agarra sin esperar la pausa de sorpresa:
            // esa pausa es para acercarse (el niño gana unos metros), no para quedarse mirando con el niño en
            // brazos. Sin esto, REACTION_TIME (0,85 s) hacía imposible capturar en menos de ~0,9 s aunque el
            // niño estuviera a 10 px (capturingSetsFlagWhenReached: 0,5 s de margen).
            val inReach = s.playerSegmentId == segmentId && abs(s.playerX - x) < CAPTURE_RANGE && !s.playerHidden
            if (inReach && (reactTimer <= 0f || justSpotted)) captured = true
            return
        }
        // v0.10: armario ocupado sin haber visto entrar: se detiene a escuchar (y, si ya sospecha, se asoma)
        if (s.playerHidden && s.playerSegmentId == segmentId && abs(s.playerX - x) < LISTEN_RANGE && state != CreatureState.CHASE) {
            if (!listenLatch) {
                listenLatch = true
                listenTimer = LISTEN_TIME + (if (s.closetReaction >= ClosetReaction.SUSPICION.ordinal) 1.6f else 0f)
                if (s.closetReaction >= ClosetReaction.SUSPICION.ordinal) peekPending = true
                facing = if (s.playerX >= x) 1f else -1f
            }
        }
        if (state == CreatureState.CHASE) {
            lostTimer += dt
            targetX = lastKnownX
            if (lostTimer > LOSE_DELAY || stuckBehindBlocker(s)) { state = CreatureState.LOST_TARGET; timer = 0f }
            return
        }
        // oído: solo cambia de PATROL / RETURN / INVESTIGATE; durante la búsqueda cercana reacciona al ruido más fuerte
        var best: NoiseEvent? = null
        var bestI = 0f
        for (n in noises) {
            if (n.segmentId != segmentId) continue
            // v0.16: tras investigar, durante unos segundos ignora los ruidos pequeños (pisadas): no lo arrastran sin parar
            if (calm > 0f && n.intensity < CALM_NOISE_LIMIT) continue
            // v0.17: el ruido se oye más débil si suena en otra profundidad (el oído usa la depth del cerebro)
            val i = Hearing.perceivedIntensity(n, x, depth)
            if (i >= Hearing.THRESHOLD && i > bestI) { best = n; bestI = i }
        }
        if (best != null && (state != CreatureState.INVESTIGATE || bestI > 0.3f)) {
            targetX = Hearing.perceivedX(best, x, seed).coerceIn(moveMin, moveMax)
            state = CreatureState.INVESTIGATE
            timer = 0f
        }
        timer += dt
        when (state) {
            CreatureState.INVESTIGATE -> if (arrived()) {
                lookAround(dt)
                if (timer > INVESTIGATE_TIME) { state = CreatureState.LOST_TARGET; timer = 0f; targetX = x; calm = CALM_TIME }
            }
            CreatureState.LOST_TARGET -> {
                if (arrived()) lookAround(dt)
                if (timer > LOST_TIME) { state = CreatureState.RETURN_TO_PATROL; timer = 0f; targetX = nearestPatrolPoint(); calm = maxOf(calm, CALM_TIME) }
            }
            CreatureState.RETURN_TO_PATROL -> if (arrived()) { state = CreatureState.PATROL; timer = 0f; patrolIdx = nearestIdx() }
            CreatureState.PATROL -> {
                if (!exitGoalX.isNaN()) {
                    // v0.16: ronda por la casa: se dirige a la puerta o escalera elegida; al llegar la escena la saca de la sala
                    targetX = exitGoalX
                    if (abs(targetX - x) < ARRIVE) exitArrived = true
                } else if (arrived()) {
                    // pausa para mirar alrededor y siguiente punto
                    lookAround(dt)
                    if (timer > 1.5f + 2f * Det.hash01(seed, patrolIdx)) {
                        patrolIdx = (patrolIdx + 1) % PATROL_POINTS
                        targetX = patrolPoint(patrolIdx)
                        timer = 0f
                    }
                } else timer = 0f
            }
            else -> {}
        }
    }

    private fun lookAround(dt: Float) {
        lookTimer += dt
        if (lookTimer > 1.1f) { lookTimer = 0f; lookDir = -lookDir; facing = lookDir }
    }
    private var lookTimer = 0f

    private fun move(dt: Float, s: Senses) {
        blockedByLight = false
        if (listenTimer > 0f) { listenTimer -= dt; speed = 0f; return }
        if (state == CreatureState.CHASE && reactTimer > 0f) { reactTimer -= dt; speed = 0f; return }
        val sp = currentSpeed()
        val dx = targetX - x
        if (abs(dx) < ARRIVE) { speed = 0f; blockedTimer = 0f; return }
        val dir = if (dx > 0) 1f else -1f
        facing = dir
        var step = min(sp * dt, abs(dx))
        var nx = x + dir * step
        var lightHit = false
        for (b in s.blockers) {
            // v0.16: la luz solo la frena mientras PERSIGUE (zona segura). Patrullando, investigando o volviendo la atraviesa:
            // antes se quedaba clavada en el borde de cada foco y nunca recorría la casa.
            if (b.isLight && state != CreatureState.CHASE) continue
            if (b.passableWhenCalm && (state == CreatureState.PATROL || state == CreatureState.RETURN_TO_PATROL)) continue
            // el cuerpo grande no cabe: se detiene en el borde del hueco (o de la luz)
            if (dir > 0 && x + HALF_BODY <= b.x0 && nx + HALF_BODY > b.x0) { nx = b.x0 - HALF_BODY; if (b.isLight) lightHit = true }
            if (dir < 0 && x - HALF_BODY >= b.x1 && nx - HALF_BODY < b.x1) { nx = b.x1 + HALF_BODY; if (b.isLight) lightHit = true }
        }
        nx = nx.coerceIn(moveMin, moveMax)
        step = abs(nx - x)
        speed = if (dt > 0f) step / dt else 0f
        x = nx
        if (lightHit || (step < 0.01f && lightNear(s))) {
            if (!blockedByLight && blockedTimer == 0f) lightHits++
            blockedByLight = true
            blockedTimer += dt
            if (blockedTimer > LIGHT_PATIENCE && state == CreatureState.CHASE) {
                // se rinde ante la luz: retrocede y pierde interés durante un rato
                refugeGiveUp = LIGHT_GIVEUP
                blockedTimer = 0f
                state = CreatureState.LOST_TARGET
                timer = 0f
                targetX = (x - dir * 80f).coerceIn(moveMin, moveMax)
            }
        } else blockedTimer = 0f
    }

    private fun lightNear(s: Senses): Boolean {
        if (state != CreatureState.CHASE) return false
        for (b in s.blockers) if (b.isLight && (abs(x + HALF_BODY - b.x0) < 1.5f || abs(x - HALF_BODY - b.x1) < 1.5f)) return true
        return false
    }

    /** Velocidad actual (px/s): la persecución arranca despacio y acelera ([chaseRamp]). */
    fun currentSpeed(): Float = when (state) {
        CreatureState.CHASE -> CHASE_START_SPEED + (CHASE_SPEED - CHASE_START_SPEED) * chaseRamp
        CreatureState.INVESTIGATE -> INVESTIGATE_SPEED
        CreatureState.LOST_TARGET -> LOST_SPEED
        CreatureState.RETURN_TO_PATROL -> PATROL_SPEED * 1.2f
        CreatureState.PATROL -> PATROL_SPEED
    }

    /** true UNA vez cuando la criatura quiere asomarse al armario sospechoso. */
    fun consumePeek(): Boolean { val p = peekPending; peekPending = false; return p }

    /**
     * v0.10: una VENTANA rompe la persecución. Pierde el foco directo (sale de CHASE hacia LOST_TARGET), conserva la
     * última posición conocida ([atX]) y la investigará. No olvida que el niño existe: el ruido y la vista lo reactivan.
     */
    fun loseFocus(atX: Float) {
        lastKnownX = atX
        targetX = atX.coerceIn(moveMin, moveMax)
        state = CreatureState.LOST_TARGET
        timer = 0f; lostTimer = 0f; reactTimer = 0f; chaseRamp = 0f
        witnessedHide = false
        // v0.17.3: piensa en el próximo update, antes de moverse. La IA corre a 15 Hz pero el movimiento es
        // por frame: sin esto, move() giraba a la criatura hacia lastKnownX (facing) en los 3 primeros frames,
        // antes del primer think, y el niño que quedaba a su espalda —a 80 px, fuera de rearAwareness (40)—
        // ya no volvía a ser visto (afterLosingFocus... por vista). Perder el foco es un evento: la IA debe
        // reaccionar a la situación nueva antes de dar la espalda y marcharse.
        aiAcc = vision.checkInterval
    }

    /** v0.10: la criatura aparece en una habitación (llegó por una puerta o ventana) con un estado ya decidido. */
    fun restore(newState: CreatureState, lastKnown: Float, face: Float, arousalNow: Float) {
        state = newState
        lastKnownX = lastKnown
        targetX = lastKnown.coerceIn(moveMin, moveMax)
        facing = if (face < 0f) -1f else 1f
        arousal = arousalNow
        timer = 0f; lostTimer = 0f; chaseRamp = if (newState == CreatureState.CHASE) 0.6f else 0f
        reactTimer = 0f
        clearExit()
    }

    /** v0.16: pide a la criatura que abandone la sala por la salida situada en [goalX] (solo en PATROL). */
    fun requestExit(goalX: Float) {
        exitGoalX = goalX.coerceIn(moveMin, moveMax)
        exitArrived = false
    }

    fun clearExit() {
        exitGoalX = Float.NaN
        exitArrived = false
    }

    val wantsToLeave: Boolean get() = !exitGoalX.isNaN()

    private fun stuckBehindBlocker(s: Senses): Boolean {
        for (b in s.blockers) {
            val edge = if (facing > 0) b.x0 - HALF_BODY else b.x1 + HALF_BODY
            if (abs(x - edge) < 1f && ((facing > 0 && s.playerX > b.x0) || (facing < 0 && s.playerX < b.x1))) return true
        }
        return false
    }

    /** Visión: mismo segmento, distancia (reducida por oscuridad), campo de visión, sin obstáculos opacos, sin armario. */
    fun canSee(s: Senses): Boolean {
        if (s.playerHidden) return false
        return canSeePosition(s)
    }

    /** Igual que [canSee] pero ignorando que el niño esté escondido: ¿ve el LUGAR donde está? (testigo de que entra). */
    fun canSeePosition(s: Senses): Boolean {
        if (s.playerSegmentId != segmentId) return false
        val dx = s.playerX - x
        val d = abs(dx)
        val tracking = state == CreatureState.CHASE || sinceSeen < vision.holdWindow
        // v0.17: el alcance se encoge si el niño va agachado/en sigilo (menos visible) y si está
        // en otra profundidad (la diferencia de profundidad desenfoca: hasta un 25% menos).
        val depthFactor = 1f - DEPTH_VISION_PENALTY * abs(s.playerDepth - depth).coerceIn(0f, 1f)
        val range = vision.effectiveRange(s.playerLight, tracking) *
            s.playerVisibility.coerceIn(0f, 1.5f) * depthFactor
        if (d > range) return false
        val inFront = dx * facing > 0f
        if (!inFront && d > vision.rearAwareness) return false
        val lo = min(x, s.playerX)
        val hi = max(x, s.playerX)
        for (b in s.blockers) if (b.blocksSight && b.x0 < hi && b.x1 > lo) return false
        return true
    }

    private fun arrived() = abs(targetX - x) < ARRIVE
    private fun patrolPoint(i: Int) = patrolMin + (patrolMax - patrolMin) * (i / (PATROL_POINTS - 1f))
    private fun nearestIdx(): Int {
        var bi = 0
        for (i in 0 until PATROL_POINTS) if (abs(patrolPoint(i) - x) < abs(patrolPoint(bi) - x)) bi = i
        return bi
    }
    private fun nearestPatrolPoint() = patrolPoint(nearestIdx())

    /**
     * v0.9: movimiento guionizado (primera aparición). Ignora sentidos y estados: no ve, no oye, no persigue ni captura.
     * Va hacia [goalX] a [sp] px/s y mira hacia [face] (0 = hacia donde camina).
     */
    fun scripted(dt: Float, goalX: Float, sp: Float, face: Float) {
        val dx = goalX - x
        if (sp <= 0f || abs(dx) < 0.5f) {
            speed = 0f
        } else {
            val dir = if (dx > 0f) 1f else -1f
            val step = min(sp * dt, abs(dx))
            x += dir * step
            speed = if (dt > 0f) step / dt else 0f
            if (face == 0f) facing = dir
        }
        if (face != 0f) facing = face
        arousal += (0.3f - arousal) * min(1f, dt)
    }

    /** Para la captura/escena: la devuelve a patrulla tras despertar al niño. */
    fun reset(newX: Float) {
        x = newX; captured = false; closetCapture = false; witnessedHide = false; listenTimer = 0f; chaseRamp = 0f; state = CreatureState.PATROL; arousal = 0.15f
        depth = 0.6f
        clearExit()
        targetX = newX; timer = 0f; lostTimer = 0f; patrolIdx = nearestIdx()
    }

    companion object {
        const val AI_STEP = 1f / 15f
        const val PATROL_POINTS = 4
        const val PATROL_SPEED = 18f
        const val INVESTIGATE_SPEED = 34f
        const val LOST_SPEED = 40f
        /** Siempre mayor que Player.SPEED (68): la criatura gana en línea recta. */
        const val CHASE_SPEED = 84f
        /** v0.10: velocidad al empezar a perseguir (acelera hasta [CHASE_SPEED] en [RAMP_TIME]). Carrera de desgaste. */
        const val CHASE_START_SPEED = 44f
        const val RAMP_TIME = 2.2f
        /** Pausa de sorpresa al ver al niño: tiempo real para reaccionar (v0.16: casi el doble que antes). */
        const val REACTION_TIME = 0.85f
        const val WITNESS_WINDOW = 0.7f
        /** v0.16: más lejos que esto no puede ver ENTRAR al niño en un armario (le dio tiempo de esconderse). */
        const val WITNESS_RANGE = 170f
        /** v0.17: cuánto encoge la diferencia de profundidad el alcance de la vista (hasta un 25%). */
        const val DEPTH_VISION_PENALTY = 0.25f
        /** v0.16: tras investigar ignora los ruidos menores que [CALM_NOISE_LIMIT] durante [CALM_TIME] s. */
        const val CALM_TIME = 7f
        const val CALM_NOISE_LIMIT = 0.3f
        const val CLOSET_REACH = 34f
        const val LISTEN_RANGE = 70f
        const val LISTEN_TIME = 2.2f
        const val LIGHT_PATIENCE = 3.2f
        const val LIGHT_GIVEUP = 5f
        const val HALF_BODY = 26f
        const val ARRIVE = 3f
        /** Valores por defecto de [VisionConfig] (v0.10 tenía 190 y 14: el niño solo se veía casi a su lado). */
        const val VISION_RANGE = 300f
        const val REAR_AWARENESS = 40f
        const val CAPTURE_RANGE = 17f
        const val LOSE_DELAY = 1.2f
        const val INVESTIGATE_TIME = 4f
        const val LOST_TIME = 5f
    }
}
