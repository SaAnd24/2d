package com.terror2d.inventory

/** Un objeto soltado en el suelo de una habitación. */
class DroppedItem(val itemId: String, val segmentId: String, var x: Float, val time: Float)

/**
 * v0.16: el mundo RECUERDA dónde dejó el niño cada objeto. Vive en el estado global: el objeto sigue en el suelo aunque el niño
 * cambie de habitación, de mundo o sea capturado. Lógica pura.
 */
class DroppedItems {
    private val list = ArrayList<DroppedItem>()

    val all: List<DroppedItem> get() = list

    fun drop(itemId: String, segmentId: String, x: Float, time: Float): DroppedItem {
        val d = DroppedItem(itemId, segmentId, x, time)
        list.add(d)
        return d
    }

    fun inSegment(segmentId: String): List<DroppedItem> = list.filter { it.segmentId == segmentId }

    fun remove(d: DroppedItem): Boolean = list.remove(d)

    /** ¿Dónde dejó este objeto? (null si no está soltado). */
    fun whereIs(itemId: String): DroppedItem? = list.firstOrNull { it.itemId == itemId }

    fun clear() = list.clear()

    /** v0.17: texto estable para el guardado: una línea por objeto «itemId|segmento|x|tiempo». */
    fun toSaveString(): String {
        val sb = StringBuilder()
        for (d in list) {
            if (sb.isNotEmpty()) sb.append('\n')
            sb.append(d.itemId).append('|').append(d.segmentId).append('|').append(d.x).append('|').append(d.time)
        }
        return sb.toString()
    }

    /** v0.17: restaura los objetos soltados. Las líneas mal formadas se ignoran. */
    fun loadSaveString(text: String) {
        list.clear()
        if (text.isBlank()) return
        for (line in text.split("\n")) {
            val p = line.split("|")
            if (p.size < 4 || p[0].isEmpty()) continue
            list.add(DroppedItem(p[0], p[1], p[2].toFloatOrNull() ?: 0f, p[3].toFloatOrNull() ?: 0f))
        }
    }
}
