package com.terror2d.render

import android.graphics.Canvas
import android.graphics.Color
import com.terror2d.core.GameConfig
import com.terror2d.core.GameState
import com.terror2d.core.Viewport
import com.terror2d.input.InputController
import com.terror2d.scene.SceneManager

/**
 * Orquesta un frame: barras negras, escala a resolución lógica 320x180, cámara lateral, mundo
 * (fondo -> objetos -> personaje -> iluminación, vía SceneManager), viñeta, texto, HUD y fundido
 * de transición. El estilo visual lo decide [renderer].
 */
class GameRenderer(private val viewport: Viewport) {

    /** Intercambiable en el futuro (CrayonRenderer, GraphiteRenderer...). */
    var renderer: WorldRenderer = CrayonRenderer()

    /** v0.16: icono de «Mi diario», botón de soltar y el libro abierto. */
    private val diaryRenderer = DiaryRenderer()

    fun render(
        canvas: Canvas,
        sceneManager: SceneManager,
        state: GameState,
        input: InputController,
        debugText: CharSequence?
    ) {
        canvas.drawColor(Color.BLACK)
        val scene = sceneManager.current ?: return

        canvas.save()
        canvas.translate(viewport.offsetX, viewport.offsetY)
        canvas.scale(viewport.scale, viewport.scale)
        // v0.17: zoom 2.5D alrededor del centro lógico (lo escribe Game.render desde camera.depthZoom)
        val dz = viewport.zoom
        if (dz != 1f) {
            canvas.translate(160f, 90f)
            canvas.scale(dz, dz)
            canvas.translate(-160f, -90f)
        }
        canvas.clipRect(0f, 0f, GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat())

        renderer.beginFrame(canvas, state.visualCorruption, state.elapsedTime)
        renderer.drawBackground()

        // Mundo: coordenadas del mundo -> cámara -> pantalla lógica. En el cambio a PRIMERA PERSONA la cámara
        // "se acerca" a la mesita (zoom hacia ella) y el mundo se funde con la mesa vista desde los ojos del niño.
        val fp = scene.firstPerson
        val blend = fp.blend
        if (blend < 0.98f) {
            canvas.save()
            if (blend > 0.001f) {
                val fx = scene.player.centerX + 16f - scene.camera.snappedX
                val fy = scene.currentSegment.floorY - 34f - scene.camera.snappedY
                val z = 1f + 2.6f * blend
                canvas.translate(fx, fy)
                canvas.scale(z, z)
                canvas.translate(-fx, -fy)
            }
            canvas.translate(-scene.camera.snappedX, -scene.camera.snappedY)
            sceneManager.render(renderer)
            canvas.restore()
        }
        val pz = scene.puzzle
        if (pz != null && blend > 0.02f) {
            renderer.drawPuzzleView(pz, ((blend - 0.35f) / 0.65f).coerceIn(0f, 1f))
        }

        // Escena de conversación (v0.7): negro + manos + peluche, SIN HUD ni texto del mundo.
        val conv = scene.conversation
        val closet = scene.closetView
        if (conv.isActive) {
            renderer.drawConversation(conv)
        } else if (!closet.active) {
            renderer.releaseConversation()
            renderer.releaseCloset()
        }
        if (closet.active && !conv.isActive) renderer.drawCloset(closet)

        // Viñeta, texto, HUD y fundido (coordenadas lógicas de pantalla)
        if (!conv.isActive) {
            renderer.drawVignette()
            val doc = scene.reading
            if (doc != null) renderer.drawDocument(doc, scene.readingTime)
            val chapterPanel = scene.chapter.panel
            if (chapterPanel != null) renderer.drawChapterPanel(chapterPanel)
            val chapterMech = scene.chapter.mech
            if (chapterMech != null) renderer.drawMechanism(chapterMech)
            renderer.drawTextBox(scene.dialogue)
            renderer.drawHud(input)
            // v0.16: icono discreto del diario (arriba a la izquierda) y botón de soltar con un objeto en las manos
            diaryRenderer.drawIcon(canvas, state.diary.unread > 0, scene.diary.isOpen)
            if (input.heldItemId != null) diaryRenderer.drawDropButton(canvas, false)
            if (scene.focusCandidates > 1 && scene.focused != null) renderer.drawFocusSelector(scene.focusCandidates, scene.focusIndex)
            if (scene.chapter.endingActive) renderer.drawChapterEnding(scene.chapter.endingTime)
        }
        if (scene.diary.isOpen && !conv.isActive) diaryRenderer.drawBook(canvas, scene.diary, state.diary, state.elapsedTime)
        val cap = scene.capture
        if (cap.active) {
            renderer.prepareScreamer()
            if (cap.screamer.active) renderer.drawScreamer(cap.screamer)
        } else renderer.releaseScreamer()
        renderer.drawFade(scene.transitionAlpha)
        if (debugText != null) renderer.drawDebug(debugText)

        canvas.restore()
    }
}
