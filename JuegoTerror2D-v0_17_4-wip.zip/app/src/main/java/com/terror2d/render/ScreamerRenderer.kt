package com.terror2d.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import com.terror2d.core.GameConfig
import com.terror2d.creature.ScreamerView
import com.terror2d.pixel.ScreamerArtData
import com.terror2d.pixel.ScreamerCodec
import kotlin.math.cos
import kotlin.math.sin

/**
 * Dibuja el SCREAMER de captura: los fotogramas dedicados de [ScreamerArtData] (arte 640x360 de la cara reconstruida
 * de forma procedural; zlib+base64, ver [ScreamerCodec]), con sacudida, zoom de embestida, destello de impacto y viñeta.
 *
 * v0.17: el susto ya NO necesita la pausa de preparación de 0,5 s para descomprimir. Antes [prepare] decodificaba
 * los 18 fotogramas (~4 MB de índices) durante el FREEZE y [bitmapFor] creaba un Bitmap por fotograma reciclando
 * los anteriores. Ahora hay UN SOLO Bitmap reutilizable y UN SOLO búfer de píxeles: cada fotograma se decodifica
 * bajo demanda al cambiar (una inflación zlib de ~230 KB, unos pocos ms) y se vuelca con setPixels sobre el mismo
 * Bitmap. Memoria en el susto: ~0,9 MB de Bitmap + ~0,9 MB de búfer + un ByteArray transitorio por fotograma.
 * [prepare] solo deja listo el fotograma 0 (para que el primer fotograma no tenga ni ese tirón) y [release]
 * libera el Bitmap al terminar. Si el arte se regenera con menos fotogramas (ver docs del screamer), nada de
 * aquí cambia: todo se lee de [ScreamerArtData.FRAME_COUNT] y [ScreamerView.FRAME_COUNT].
 */
class ScreamerRenderer {
    private var bitmap: Bitmap? = null
    private var pixelBuffer = IntArray(0)
    private var lastFrame = -1
    private val paint = Paint().apply { isAntiAlias = false; isFilterBitmap = false; isDither = false }

    /** Deja listo el primer fotograma (el único que se ve en el instante 0). Barato: un solo fotograma. */
    fun prepare() {
        ensureFrame(0)
    }

    fun release() {
        bitmap?.recycle()
        bitmap = null
        lastFrame = -1
    }

    /** Decodifica el fotograma [index] en el Bitmap reutilizable (nada si ya es el actual). */
    private fun ensureFrame(index: Int) {
        if (index == lastFrame && bitmap != null) return
        val idx = ScreamerCodec.indices(index)
        val pal = ScreamerArtData.PALETTE
        val n = idx.size
        if (pixelBuffer.size < n) pixelBuffer = IntArray(n)
        for (i in 0 until n) pixelBuffer[i] = pal[idx[i].toInt() and 0xFF]
        var bmp = bitmap
        if (bmp == null || bmp.isRecycled) {
            bmp = Bitmap.createBitmap(ScreamerArtData.WIDTH, ScreamerArtData.HEIGHT, Bitmap.Config.ARGB_8888)
            bitmap = bmp
        }
        bmp.setPixels(pixelBuffer, 0, ScreamerArtData.WIDTH, 0, 0, ScreamerArtData.WIDTH, ScreamerArtData.HEIGHT)
        lastFrame = index
    }

    fun draw(canvas: Canvas, v: ScreamerView) {
        if (!v.active) return
        val w = GameConfig.LOGICAL_WIDTH.toFloat()
        val h = GameConfig.LOGICAL_HEIGHT.toFloat()
        paint.style = Paint.Style.FILL
        paint.color = 0xFF020102.toInt()
        canvas.drawRect(0f, 0f, w, h, paint)
        // corte a negro: la cara desaparece de golpe en mitad del grito (nada de fundido).
        if (v.cutToBlack) return
        ensureFrame(v.frame.coerceIn(0, ScreamerArtData.FRAME_COUNT - 1))
        val bmp = bitmap ?: return
        val shake = v.shake
        val dx = sin(v.time * 131f) * 5f * shake
        val dy = cos(v.time * 97f) * 4f * shake
        canvas.save()
        canvas.translate(w / 2f + dx, h / 2f + dy)
        canvas.scale(v.zoom, v.zoom)
        canvas.translate(-w / 2f, -h / 2f)
        canvas.scale(0.5f, 0.5f)                // 640x360 de arte -> 320x180 lógicos
        paint.alpha = 255
        canvas.drawBitmap(bmp, 0f, 0f, paint)
        canvas.restore()
        // viñeta de bordes oscuros (ocupa la pantalla y deja el centro cargado)
        for (i in 0 until 5) {
            paint.color = ((26 + i * 7) shl 24) or 0x020102
            val e = 3f + i * 5f
            canvas.drawRect(0f, 0f, e, h, paint); canvas.drawRect(w - e, 0f, w, h, paint)
            canvas.drawRect(0f, 0f, w, e * 0.6f, paint); canvas.drawRect(0f, h - e * 0.6f, w, h, paint)
        }
        val f = v.flash
        if (f > 0.01f) {
            paint.color = ((f * 150f).toInt() shl 24) or 0xE8D4C0
            canvas.drawRect(0f, 0f, w, h, paint)
        }
    }
}
