package com.terror2d.core

import com.terror2d.world.WorldObject
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Comportamiento de la cámara dentro de un segmento.
 * FIXED y SIDE_SCROLLING (v0.2). En v0.3 el encuadre es cercano: no se amplía la imagen, sino que
 * la escala lógica del mundo (personaje, muebles, habitaciones) se diseñó para esta cámara, de modo
 * que una habitación pequeña cabe entera en FIXED y una larga se recorre con SIDE_SCROLLING.
 */
enum class CameraMode {
    /** La cámara no se mueve en X: la composición del segmento queda fija. */
    FIXED,

    /** Sigue al jugador solo en horizontal, con zona muerta y suavizado. */
    SIDE_SCROLLING
}

/**
 * Cámara 2D lateral: Mundo -> Cámara -> Pantalla (lógica).
 * El eje Y queda BLOQUEADO por segmento (se calcula en [configure]); nunca sigue al jugador
 * verticalmente. Respeta los límites horizontales del segmento y, si el segmento cabe en
 * pantalla, lo centra (composición controlada).
 */
class Camera(val viewWidth: Float, val viewHeight: Float) {
    /** Esquina superior izquierda de la cámara en coordenadas del mundo. */
    var x: Float = 0f
        private set

    /** Fija por segmento. Solo cambia con [configure]. */
    var y: Float = 0f
        private set

    var mode: CameraMode = CameraMode.SIDE_SCROLLING
        private set

    var deadZoneHalfWidth: Float = 14f
    var smoothing: Float = 9f

    private var sceneWidth: Float = viewWidth

    /** Posición redondeada a píxel lógico (evita temblor en las líneas). */
    val snappedX: Float get() = x.roundToInt().toFloat()
    val snappedY: Float get() = y.roundToInt().toFloat()

    // ------------------------------------------------------------------ respiración 2.5D (v0.17)

    /**
     * Profundidad a la que mira la cámara (suavizada hacia la del jugador con [updateDepthFocus]).
     * Empieza en el plano de referencia: sin jugador en profundidad, la cámara no se mueve.
     */
    var depthFocus: Float = GameConfig.DEPTH_REFERENCE
        private set

    /**
     * La cámara respira con la profundidad del jugador: acerca el foco poco a poco
     * (nunca de golpe). Llamar cada frame con `player.depth`.
     */
    fun updateDepthFocus(targetDepth: Float, dt: Float) {
        val t = min(1f, GameConfig.DEPTH_FOCUS_SMOOTHING * dt)
        depthFocus += (targetDepth.coerceIn(GameConfig.DEPTH_MIN, GameConfig.DEPTH_MAX) - depthFocus) * t
    }

    /**
     * Desplazamiento vertical suave de la vista (px lógicos, ±[GameConfig.DEPTH_SHIFT_MAX]).
     * Jugador cerca (depth alta) -> el mundo sube un poco en pantalla; lejos -> baja.
     * Es solo respiración: nunca saca el segmento del encuadre 320x180.
     */
    val depthShiftY: Float get() = (depthFocus - GameConfig.DEPTH_REFERENCE) * GameConfig.DEPTH_SHIFT_MAX

    /**
     * Zoom sutil alrededor del plano de referencia (1.0 ahí, ~1.02 cerca, ~0.98 lejos).
     * La cámara no lo aplica sola: quien dibuja lo usa con [com.terror2d.core.Viewport.setZoom]
     * (ver snippet de integración en GameView).
     */
    val depthZoom: Float get() = 1f + (depthFocus - GameConfig.DEPTH_REFERENCE) * GameConfig.DEPTH_ZOOM_SPAN

    fun worldToScreenX(worldX: Float): Float = worldX - snappedX
    fun worldToScreenY(worldY: Float): Float = worldY - snappedY - depthShiftY
    fun screenToWorldX(screenX: Float): Float = screenX + snappedX
    fun screenToWorldY(screenY: Float): Float = screenY + snappedY + depthShiftY

    /** Prepara la cámara para un segmento nuevo (tamaño y modo). */
    fun configure(sceneWidth: Float, sceneHeight: Float, mode: CameraMode) {
        this.sceneWidth = sceneWidth
        this.mode = mode
        // Vertical fijo: segmento más bajo que la pantalla -> centrado; más alto -> anclado al suelo.
        y = if (sceneHeight <= viewHeight) (sceneHeight - viewHeight) / 2f else sceneHeight - viewHeight
        x = clampX(x)
        // v0.17: al cambiar de sala la respiración de profundidad vuelve al plano de referencia.
        depthFocus = GameConfig.DEPTH_REFERENCE
    }

    /** Coloca la cámara de golpe sobre el objetivo (solo X). */
    fun snapTo(targetX: Float) {
        x = clampX(targetX - viewWidth / 2f)
    }

    /** Seguimiento horizontal con zona muerta y suavizado. */
    fun follow(targetX: Float, dt: Float) {
        if (mode == CameraMode.FIXED || sceneWidth <= viewWidth) {
            x = clampX(x)
            return
        }
        val cx = x + viewWidth / 2f
        var desiredX = x
        if (targetX > cx + deadZoneHalfWidth) desiredX += targetX - (cx + deadZoneHalfWidth)
        else if (targetX < cx - deadZoneHalfWidth) desiredX += targetX - (cx - deadZoneHalfWidth)
        val t = min(1f, smoothing * dt)
        x = clampX(x + (desiredX - x) * t)
    }

    fun isVisible(o: WorldObject, margin: Float = 8f): Boolean =
        o.right > x - margin && o.x < x + viewWidth + margin &&
            o.bottom > y - margin && o.y < y + viewHeight + margin

    private fun clampX(value: Float): Float {
        if (sceneWidth <= viewWidth) return (sceneWidth - viewWidth) / 2f // segmento pequeño: centrado
        return value.coerceIn(0f, sceneWidth - viewWidth)
    }
}
