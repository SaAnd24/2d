package com.terror2d.core

/**
 * v0.17: CONTRATO de escondites (tipos de escondite del mapa).
 *
 * El resto del contrato 2.5D (profundidad, modos de movimiento) ya lo entregó el frente de
 * movimiento en `core/Depth.kt` (`Depth.depthScale`, `MoveMode`) y `core/GameConfig.kt` (constantes
 * DEPTH_*, velocidades y stamina): este archivo solo añade lo que aún no existía, los tipos de
 * escondite, para que el frente de escondites y los tests hablen de lo mismo.
 *
 * - CLOSET: armario/ropero. Es el escondite de siempre (`Wardrobe`, `ClosetView`/`ClosetRenderer`,
 *   rendija arrastrable, `ClosetMemory` con escalada PASS → SUSPICION → WARNING → CAPTURE).
 * - UNDER_BED: debajo de la cama. Solo cabe agachado, se ve poco, se sale rápido.
 * - CURTAINS: tras la cortina. Tapa si no te mueves; la cortina se mueve si pasas corriendo.
 *
 * Si el frente de escondites necesita mover este tipo (p. ej. a `world/` junto a `Wardrobe`), que lo
 * mueva sin cambiar su nombre ni sus valores: los tests de `Restructure017Test` dependen de ellos.
 */
enum class HideSpotType {
    CLOSET,
    UNDER_BED,
    CURTAINS
}

/**
 * v0.17 (frente mapa + escondites): UN escondite del mapa, sea del tipo que sea.
 *
 *  - [id]: id único del mueble/zona (p. ej. `wardrobe_kid`, `hide_underbed_kid`, `hide_curtains_study`).
 *  - [type]: [HideSpotType] del contrato.
 *  - [roomId]: zona del grafo donde está (id de segmento de `ChapterHouse`).
 *  - [x]: centro del escondite en coordenadas del mundo de su sala.
 *  - [depth]: profundidad 0.0 (fondo) a 1.0 (primer plano). La escala visual la aplica el frente
 *    motor con [Depth.depthScale] (`0.82 + 0.30 * depth`); este dato NO la duplica. Valores de
 *    diseño: armario 0.45 (plano medio), cortinas 0.55, debajo de la cama 0.85 (bajo y cerca).
 *  - [suspicion]: usos acumulados de ESTE escondite (lo escribe [com.terror2d.creature.ClosetMemory];
 *    0 = sin sospecha). La reacción (PASS → SUSPICION → WARNING → CAPTURE) se deriva de aquí.
 *
 * Implementa [DepthAware] para que el render pueda ordenar el escondite por profundidad sin
 * conocer su tipo.
 */
data class HideSpot(
    val id: String,
    val type: HideSpotType,
    val roomId: String,
    val x: Float,
    override val depth: Float,
    val suspicion: Int = 0
) : DepthAware {

    /** Cuánto tapa este tipo (0..1): la cortina tapa menos que el armario o la cama. */
    fun coverValue(): Float = when (type) {
        HideSpotType.CLOSET -> 0.75f
        HideSpotType.UNDER_BED -> 0.70f
        HideSpotType.CURTAINS -> 0.55f
    }
}
