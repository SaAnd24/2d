package com.terror2d.core

import android.content.Context
import android.content.SharedPreferences

/**
 * v0.17: GUARDADO MÍNIMO de progreso (SharedPreferences).
 *
 * Guarda SOLO progreso, nunca la escena entera: el diario («Mi diario», [com.terror2d.diary.DiaryState]),
 * los hitos narrativos ([com.terror2d.story.StoryState]), si ya ocurrió el apagón, los objetos soltados
 * ([com.terror2d.inventory.DroppedItems]) y cuántas veces ha capturado la criatura al niño.
 * Al cargar, el juego arranca en la escena inicial con ese progreso restaurado: la escena, la casa y la
 * criatura se reconstruyen desde los hitos (el apagón, por ejemplo, ya lo recoge `BlackoutDirector`:
 * con `blackoutDone` en true pasa directamente a DONE).
 *
 * Diseño: [SaveManager] solo habla con [SaveStore], una interfaz clave-valor mínima. En el juego real el
 * almacén es [SharedPreferencesStore] (un `SharedPreferences` de Android); en los tests unitarios se usa un
 * almacén en memoria, así que el guardado se prueba sin Android.
 *
 * Integración (la aplica el coordinador; ver docs/REESTRUCTURACION_0_17.md):
 *  - `Game`: campo `var saveManager: SaveManager? = null` + `loadProgress()` / `saveProgress()`.
 *  - `GameView.init`: `game.saveManager = SaveManager.fromContext(context)` y `game.loadProgress()`.
 *  - `MainActivity.onPause`: `gameView.game.saveProgress()` antes de `pauseGame()`.
 */
interface SaveStore {
    fun getString(key: String, default: String?): String?
    fun getBoolean(key: String, default: Boolean): Boolean
    fun getInt(key: String, default: Int): Int
    fun putString(key: String, value: String)
    fun putBoolean(key: String, value: Boolean)
    fun putInt(key: String, value: Int)

    /** Borra todo lo guardado (se hace efectivo en [commit]). */
    fun clear()

    /** Escribe de forma síncrona todo lo acumulado con los `put*` / `clear`. */
    fun commit()
}

/** [SaveStore] sobre un `SharedPreferences` de Android. Los `put*` se acumulan y [commit] los escribe. */
class SharedPreferencesStore(private val prefs: SharedPreferences) : SaveStore {
    private var editor: SharedPreferences.Editor? = null

    private fun edit(): SharedPreferences.Editor {
        val existing = editor
        if (existing != null) return existing
        val created: SharedPreferences.Editor = prefs.edit()
        editor = created
        return created
    }

    override fun getString(key: String, default: String?): String? = prefs.getString(key, default)
    override fun getBoolean(key: String, default: Boolean): Boolean = prefs.getBoolean(key, default)
    override fun getInt(key: String, default: Int): Int = prefs.getInt(key, default)
    override fun putString(key: String, value: String) { edit().putString(key, value) }
    override fun putBoolean(key: String, value: Boolean) { edit().putBoolean(key, value) }
    override fun putInt(key: String, value: Int) { edit().putInt(key, value) }
    override fun clear() { edit().clear() }
    override fun commit() {
        editor?.commit()
        editor = null
    }
}

class SaveManager(private val store: SaveStore) {

    /** ¿Hay algún guardado? (un guardado existe cuando se escribió su versión). */
    fun hasSave(): Boolean = store.getInt(KEY_VERSION, 0) > 0

    /** Guarda el progreso actual de [state]. Sobrescribe el guardado anterior, si lo había. */
    fun save(state: GameState) {
        store.putInt(KEY_VERSION, SAVE_VERSION)
        store.putString(KEY_DIARY, state.diary.toSaveString())
        store.putString(KEY_STORY_FLAGS, state.story.toSaveString())
        store.putBoolean(KEY_BLACKOUT_DONE, state.blackoutDone)
        store.putString(KEY_DROPPED, state.dropped.toSaveString())
        store.putInt(KEY_CAPTURE_COUNT, state.captureCount)
        store.commit()
    }

    /**
     * Restaura el progreso guardado en [state]. Devuelve false si no había ningún guardado (en ese
     * caso [state] queda intacto). Las cadenas mal formadas no rompen la carga: cada parte ignora
     * lo que no entiende y conserva el resto.
     */
    fun load(state: GameState): Boolean {
        if (!hasSave()) return false
        state.diary.loadSaveString(store.getString(KEY_DIARY, "") ?: "")
        state.story.loadSaveString(store.getString(KEY_STORY_FLAGS, "") ?: "")
        state.blackoutDone = store.getBoolean(KEY_BLACKOUT_DONE, false)
        state.dropped.loadSaveString(store.getString(KEY_DROPPED, "") ?: "")
        state.captureCount = store.getInt(KEY_CAPTURE_COUNT, 0)
        return true
    }

    /** Borra el guardado (nueva partida desde cero). */
    fun clearSave() {
        store.clear()
        store.commit()
    }

    companion object {
        /** Nombre del fichero de preferencias. */
        const val PREFS_NAME = "mymom_save"

        /** Versión del formato de guardado. Subirla si cambia el significado de alguna clave. */
        const val SAVE_VERSION = 17

        const val KEY_VERSION = "save_version"
        const val KEY_DIARY = "diary"
        const val KEY_STORY_FLAGS = "story_flags"
        const val KEY_BLACKOUT_DONE = "blackout_done"
        const val KEY_DROPPED = "dropped"
        const val KEY_CAPTURE_COUNT = "capture_count"

        /** Guardado real del juego, sobre las preferencias privadas de la app. */
        fun fromContext(context: Context): SaveManager =
            SaveManager(SharedPreferencesStore(context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)))
    }
}
