package com.terror2d.core

/**
 * Contrato compartido del falso 2.5D (v0.17).
 *
 * La profundidad es un eje más del mundo, no un efecto visual suelto:
 *  - `depth` en 0.0 (fondo, lejos) a 1.0 (primer plano, cerca).
 *  - Escala: `depthScale(depth) = 0.82 + 0.30 * depth`. En el plano de referencia
 *    ([GameConfig.DEPTH_REFERENCE] = 0.6) la escala es exactamente 1.0, así que todo lo
 *    dibujado hasta v0.16 se ve igual sin tocarlo.
 *  - El suelo es una BANDA vertical: mayor depth = más abajo en pantalla y mayor escala.
 *    Los pies del jugador se apoyan en [DepthBand.footY]; en el plano de referencia los pies
 *    quedan exactamente sobre `floorY`, como siempre.
 *
 * Capas de render ([DepthLayer]): BACK se dibuja antes que el jugador, FRONT después.
 * Dentro de una misma capa, el orden es por profundidad creciente (lejos -> cerca).
 *
 * Los modos de movimiento ([MoveMode]) y los tipos de suelo ([FloorType]) viven aquí para que
 * `world` (jugador) y `creature` (ruido/percepción) los compartan sin dependencias circulares.
 */
enum class DepthLayer { BACK, MID, FRONT }

/** Modo de desplazamiento del niño. RUN gasta stamina y hace ruido; SNEAK/CROUCH son silenciosos. */
enum class MoveMode { WALK, RUN, SNEAK, CROUCH }

/** Superficie bajo los pies: la madera cruje, la alfombra amortigua, las escaleras crujen mucho. */
enum class FloorType { WOOD, CARPET, TILE, STAIRS }

/** Algo del mundo que tiene una profundidad propia (muebles, criatura, objetos). Si no la tiene, se usa la de referencia. */
interface DepthAware {
    val depth: Float
}

object Depth {

    /** Escala visual según la profundidad (contrato): 0.82 lejos, 1.0 en el plano de referencia, 1.12 cerca. */
    fun depthScale(depth: Float): Float =
        GameConfig.DEPTH_SCALE_FAR + GameConfig.DEPTH_SCALE_SPAN * depth.coerceIn(
            GameConfig.DEPTH_MIN,
            GameConfig.DEPTH_MAX
        )

    /** Capa de render según la profundidad. El jugador (0.6 por defecto) está en MID. */
    fun depthLayerOf(depth: Float): DepthLayer = when {
        depth < 0.34f -> DepthLayer.BACK
        depth < 0.67f -> DepthLayer.MID
        else -> DepthLayer.FRONT
    }

    /** Profundidad efectiva de un objeto: la suya si es [DepthAware], si no la de referencia. */
    fun depthOf(o: Any?, defaultDepth: Float = GameConfig.PLAYER_DEFAULT_DEPTH): Float =
        if (o is DepthAware) o.depth.coerceIn(GameConfig.DEPTH_MIN, GameConfig.DEPTH_MAX) else defaultDepth

    /** Capa de render efectiva de un objeto. */
    fun layerOf(o: Any?, defaultDepth: Float = GameConfig.PLAYER_DEFAULT_DEPTH): DepthLayer =
        depthLayerOf(depthOf(o, defaultDepth))

    /** true si el objeto está DELANTE del jugador (mayor depth): se dibuja después que él y puede taparlo. */
    fun isInFrontOf(o: Any?, playerDepth: Float): Boolean = depthOf(o) > playerDepth

    /**
     * Orden de pintado por profundidad (lejos -> cerca, estable: a igual depth se conserva el orden dado).
     * El jugador se inserta en su posición por depth, no por capa fija.
     */
    fun <T> sortByDepth(items: List<T>, depthOfItem: (T) -> Float): List<T> =
        items.sortedBy { depthOfItem(it).coerceIn(GameConfig.DEPTH_MIN, GameConfig.DEPTH_MAX) }

    /**
     * Parallax del fondo: factor por el que se desplaza una capa con la cámara.
     * Lejos (0.0) se mueve al 55% (casi quieto), cerca (1.0) al 100%. El muro de fondo usa ~0.6.
     */
    fun parallaxFactor(depth: Float): Float =
        0.55f + 0.45f * depth.coerceIn(GameConfig.DEPTH_MIN, GameConfig.DEPTH_MAX)

    /** Desplazamiento de cámara con parallax para una capa a [depth]: el fondo se mueve menos que el suelo. */
    fun parallaxCamX(camX: Float, depth: Float): Float = camX * parallaxFactor(depth)

    /**
     * Tipo de suelo a partir del nombre de [com.terror2d.scene.FloorPattern] del segmento
     * (WOOD/TILES/CONCRETE/CARPET). Sin importar `scene` desde `core`: la escena pasa `seg.floorPattern.name`.
     */
    fun floorTypeOf(patternName: String): FloorType = when (patternName) {
        "CARPET" -> FloorType.CARPET
        "TILES", "CONCRETE" -> FloorType.TILE
        else -> FloorType.WOOD
    }
}

/**
 * La banda de suelo de una sala: el rectángulo vertical dentro del cual se mueven los pies.
 * Arriba = fondo (lejos, pequeño), abajo = primer plano (cerca, grande).
 * En el plano de referencia ([GameConfig.DEPTH_REFERENCE]) los pies quedan sobre `floorY`, como en v0.16.
 */
class DepthBand(val floorY: Float, val height: Float = GameConfig.FLOOR_BAND_HEIGHT) {

    /** Y de los pies para una profundidad dada. */
    fun footY(depth: Float): Float =
        floorY + (depth.coerceIn(GameConfig.DEPTH_MIN, GameConfig.DEPTH_MAX) - GameConfig.DEPTH_REFERENCE) * height

    /** Profundidad que corresponde a una Y de pies dada (inversa de [footY]). */
    fun depthAt(footY: Float): Float =
        (GameConfig.DEPTH_REFERENCE + (footY - floorY) / height)
            .coerceIn(GameConfig.DEPTH_MIN, GameConfig.DEPTH_MAX)

    /** Y de los pies en el fondo de la banda (depth 0) y en el primer plano (depth 1). */
    val backY: Float get() = footY(GameConfig.DEPTH_MIN)
    val frontY: Float get() = footY(GameConfig.DEPTH_MAX)
}
