package com.terror2d.core

import kotlin.math.floor
import kotlin.math.min

/**
 * Relación entre la resolución lógica (320x180) y la pantalla real.
 * Mantiene la proporción (letterbox) y evita deformaciones.
 *
 * v0.17: [zoom] es la respiración 2.5D (la cámara lo escribe desde su [Camera.depthZoom]).
 * Amplía alrededor del centro lógico (160, 90), limitado a ±5%, así que el encuadre
 * 320x180 nunca se rompe. Con zoom = 1.0 las conversiones son exactamente las de siempre.
 */
class Viewport {
    @Volatile var screenWidth: Int = 1
    @Volatile var screenHeight: Int = 1
    @Volatile var scale: Float = 1f
    @Volatile var offsetX: Float = 0f
    @Volatile var offsetY: Float = 0f

    /** Zoom 2.5D alrededor del centro lógico (1 = sin zoom). */
    @Volatile var zoom: Float = 1f
        private set

    /** Fija el zoom 2.5D, limitado a ±5% para no romper el encuadre. */
    fun setZoom(z: Float) {
        zoom = z.coerceIn(0.95f, 1.05f)
    }

    fun update(width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        screenWidth = width
        screenHeight = height
        var s = min(
            width.toFloat() / GameConfig.LOGICAL_WIDTH,
            height.toFloat() / GameConfig.LOGICAL_HEIGHT
        )
        if (GameConfig.INTEGER_SCALING && s >= 1f) s = floor(s)
        scale = s
        offsetX = (width - GameConfig.LOGICAL_WIDTH * s) / 2f
        offsetY = (height - GameConfig.LOGICAL_HEIGHT * s) / 2f
    }

    fun toLogicalX(screenX: Float): Float {
        val raw = (screenX - offsetX) / scale
        val cx = GameConfig.LOGICAL_WIDTH / 2f
        return cx + (raw - cx) / zoom
    }

    fun toLogicalY(screenY: Float): Float {
        val raw = (screenY - offsetY) / scale
        val cy = GameConfig.LOGICAL_HEIGHT / 2f
        return cy + (raw - cy) / zoom
    }

    /** Inversa de [toLogicalX]/[toLogicalY]: de coordenadas lógicas a píxeles de pantalla. */
    fun toScreenX(logicalX: Float): Float {
        val cx = GameConfig.LOGICAL_WIDTH / 2f
        return offsetX + (cx + (logicalX - cx) * zoom) * scale
    }

    fun toScreenY(logicalY: Float): Float {
        val cy = GameConfig.LOGICAL_HEIGHT / 2f
        return offsetY + (cy + (logicalY - cy) * zoom) * scale
    }
}
