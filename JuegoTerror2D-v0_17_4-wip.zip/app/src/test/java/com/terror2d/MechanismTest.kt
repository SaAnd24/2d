package com.terror2d

import com.terror2d.chapter.mech.*
import org.junit.Assert.*
import org.junit.Test

/**
 * v0.15 — pruebas de los mecanismos propios de los puzles. Reproducen GESTOS reales (pulsar, arrastrar, soltar) sobre la
 * lógica pura. OJO: escritas sin poder compilarlas ni ejecutarlas en el entorno donde se hicieron (sin Kotlin/Gradle).
 */
class MechanismTest {

    private fun press(m: Mechanism, x: Float, y: Float) { m.feed(true, true, false, x, y); m.tick(0.016f) }
    private fun move(m: Mechanism, x: Float, y: Float) { m.feed(true, false, false, x, y); m.tick(0.016f) }
    private fun release(m: Mechanism, x: Float, y: Float) { m.feed(false, false, true, x, y); m.tick(0.016f) }
    private fun tap(m: Mechanism, x: Float, y: Float) { press(m, x, y); release(m, x, y) }
    private fun wait(m: Mechanism, s: Float) { var t = 0f; while (t < s) { m.tick(0.02f); t += 0.02f } }

    private fun drag(m: Mechanism, x0: Float, y0: Float, x1: Float, y1: Float) {
        press(m, x0, y0)
        val n = 12
        for (i in 1..n) move(m, x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n)
        release(m, x1, y1)
    }

    @Test
    fun fifteenPuzzlesHaveOwnMechanismAndNoneStartsSolved() {
        assertEquals(15, MechRegistry.MIGRATED.size)
        for (id in MechRegistry.MIGRATED) {
            val m = MechRegistry.create(id)
            assertNotNull(id, m)
            assertFalse("$id nace resuelto", m!!.solved)
        }
        // v0.17: los cuatro puzles espaciales ya tienen mecanismo propio (T3, C2, C3, C5)
        for (id in listOf("T3", "C2", "C3", "C5")) assertNotNull(id, MechRegistry.create(id))
        assertNull("id desconocido", MechRegistry.create("N9"))
    }

    @Test
    fun n1TableSolvesByDraggingObjectsToTheirMarks() {
        val m = TableMech()
        drag(m, 150f, 104f, TableMech.CUP_X, TableMech.CUP_Y)
        drag(m, 170f, 90f, TableMech.PLATE_X, TableMech.PLATE_Y)
        assertFalse(m.solved)
        drag(m, 276f, 118f, TableMech.CHAIR_X, TableMech.CHAIR_Y)
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun n1WrongPlacementIsNotReturnedAndDoesNotSolve() {
        val m = TableMech()
        drag(m, 150f, 104f, 100f, 110f)
        assertEquals(100f, m.cup.x, 0.5f)
        drag(m, 170f, 90f, 204f, 80f)
        drag(m, 276f, 118f, 150f, 52f)
        wait(m, 0.1f)
        assertFalse(m.solved)
    }

    @Test
    fun n2NeedsThePhasesInOrder() {
        val m = RoutineMech()
        fun hourBtn(n: Int, dir: Int) { repeat(n) { tap(m, if (dir > 0) 184f else 116f, 164f) } }
        fun tiltBtn(n: Int, up: Boolean) { repeat(n) { tap(m, 300f, if (up) 122f else 146f) } }
        repeat(2) { tap(m, 258f, 150f) } // abrir la cortina
        // fase 2 antes que la 1: no se registra
        hourBtn(10, 1) // 5.0 -> 10.0
        tiltBtn(3, false) // el rayo cae sobre la marca B
        wait(m, 0.1f)
        for (i in 0 until 3) assertFalse(m.done[i])
        // el rayo sobre B sin que le toque: no se completa nada y el puzle sigue abierto
        wait(m, 1.2f)
        assertFalse(m.done[1])
        assertFalse(m.solved)
    }

    @Test
    fun n2SolvesWithRealObjectsInOrder() {
        val m = RoutineMech()
        fun hourBtn(n: Int) { repeat(n) { tap(m, 184f, 164f) } }
        fun tilt(n: Int, up: Boolean) { repeat(n) { tap(m, 300f, if (up) 122f else 146f) } }
        repeat(2) { tap(m, 258f, 150f) }
        hourBtn(6); tilt(4, true)        // hora 8, rayo alto: la cortina
        wait(m, 1.1f); assertTrue(m.done[0]); assertFalse(m.solved)
        hourBtn(4); tilt(7, false)       // hora 10, rayo bajo: la taza
        wait(m, 1.1f); assertTrue(m.done[1]); assertFalse(m.solved)
        hourBtn(8); tilt(2, false)       // hora 2: el mueble del pasillo
        wait(m, 1.1f)
        assertTrue(m.solved)
    }

    @Test
    fun n3SheetsFormTheChain() {
        val m = DrawingsMech()
        // girar: A(1)->0, B(2)->0, C ya derecha, D(3)->0
        repeat(3) { tap(m, 70f, 64f) }
        repeat(2) { tap(m, 240f, 70f) }
        repeat(1) { tap(m, 236f, 134f) }
        assertTrue(m.upright())
        drag(m, 236f, 134f, 262f, 140f)  // D
        drag(m, 120f, 130f, 198f, 140f)  // C
        drag(m, 240f, 70f, 70f, 140f)    // B
        drag(m, 70f, 64f, 134f, 140f)    // A
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun n3WrongOrderDoesNotSolve() {
        val m = DrawingsMech()
        repeat(3) { tap(m, 70f, 64f) }
        repeat(2) { tap(m, 240f, 70f) }
        tap(m, 236f, 134f)
        drag(m, 236f, 134f, 70f, 140f)   // D primero
        drag(m, 120f, 130f, 134f, 140f)
        drag(m, 240f, 70f, 198f, 140f)
        drag(m, 70f, 64f, 262f, 140f)
        wait(m, 0.1f)
        assertFalse(m.solved)
    }

    @Test
    fun n4FramesSettleOneByOneThenWallOpens() {
        val m = FramesMech()
        val taps = intArrayOf(-11, 6, -14, 13) // pulsaciones de ◀ (negativo) o ▶ (positivo)
        for (i in 0 until 4) {
            val n = Math.abs(taps[i])
            val bx = m.centerX[i] + (if (taps[i] < 0) -17f else 17f)
            repeat(n) { tap(m, bx, FramesMech.ARROW_Y) }
            wait(m, 0.8f)
            assertTrue("marco $i", m.settled[i])
            if (i < 3) assertFalse(m.solved)
        }
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun n5WrongCableDoesNotKeepAndRightCablesStay() {
        val m = FuseBoxMech()
        // rama 0 al terminal 0: incompatible
        drag(m, FuseBoxMech.SRC_X + 14f, FuseBoxMech.SRC_Y[0], FuseBoxMech.TERM_X, FuseBoxMech.TERM_Y[0])
        assertEquals(0, m.lockedCount)
        wait(m, 1.6f)
        assertEquals(0, m.lockedCount)
        val dest = intArrayOf(2, 1, 0, 3) // terminal que corresponde a cada rama
        for (b in 0 until 4) {
            drag(m, FuseBoxMech.SRC_X + 14f, FuseBoxMech.SRC_Y[b], FuseBoxMech.TERM_X, FuseBoxMech.TERM_Y[dest[b]])
            assertTrue(m.isLocked(b))
            if (b < 3) assertFalse(m.solved)
        }
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun t1RhythmNeedsTimingAndKeepsPartialHits() {
        val m = MarksMech()
        // golpear una espera (marca corta) es un error, no reinicia
        tap(m, m.markX(1), 90f)
        assertTrue(m.failures >= 1)
        wait(m, 4.5f)
        // repetición limpia: marcas 0,2,4,5 con pausas de 2,2 y 1 pasos
        tap(m, m.markX(0), 90f); wait(m, 0.84f)
        tap(m, m.markX(2), 90f); wait(m, 0.84f)
        tap(m, m.markX(4), 90f); wait(m, 0.42f)
        assertFalse(m.solved)
        tap(m, m.markX(5), 90f)
        assertTrue(m.solved)
    }

    @Test
    fun t1OffBeatKeepsProgressMarkAndReplaysReference() {
        val m = MarksMech()
        tap(m, m.markX(0), 90f); wait(m, 0.84f)
        tap(m, m.markX(2), 90f); wait(m, 0.1f) // demasiado pronto
        tap(m, m.markX(4), 90f)
        assertFalse(m.solved)
        assertTrue(m.best >= 2)
        assertTrue(m.isPlayingRef)
    }

    @Test
    fun t2PiecesRotateAndSnapIntoTheirOwnHoles() {
        val m = PortraitMech()
        repeat(3) { tap(m, 236f, 56f) }   // L: de 1 a 0
        tap(m, 280f, 128f)                // alargada: pasa a vertical
        drag(m, 236f, 56f, m.holeX[0], m.holeY[0])
        drag(m, 286f, 56f, m.holeX[1], m.holeY[1])
        drag(m, 236f, 112f, m.holeX[2], m.holeY[2])
        assertFalse(m.solved)
        drag(m, 280f, 128f, m.holeX[3], m.holeY[3])
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun t4ValvesLockInTheirOwnBandAndSolve() {
        val m = BoilerMech()
        val taps = intArrayOf(-5, -2, 2, 5) // v0: 7->2 (callada), v1: 10->8 (dos golpes), v2: 1->3 (continua), v3: 4->9 (incompleta)
        for (v in 0 until 4) {
            val bx = m.valveX[v] + (if (taps[v] < 0) -16f else 16f)
            repeat(Math.abs(taps[v])) { tap(m, bx, 153f) }
            wait(m, 1.2f)
            assertTrue("válvula $v", m.locked[v])
            if (v < 3) assertFalse(m.solved)
        }
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun t5ChainedArmsSolveOnlyWhenAllShadowsMatch() {
        val m = AntennaMech()
        wait(m, 1f)
        assertFalse(m.solved)
        // el primero bien y los demás no: no se resuelve (y mover el primero arrastra a los otros: cadena)
        m.theta[0] = AntennaMech.SOLUTION[0]
        wait(m, 1.5f)
        assertFalse(m.solved)
        for (i in 0 until 3) m.theta[i] = AntennaMech.SOLUTION[i]
        wait(m, 1.5f)
        assertTrue(m.solved)
    }

    @Test
    fun c1JointsMustBeActivatedInOrder() {
        val m = WallJointMech()
        fun carryTo(j: Int) {
            press(m, m.strip.x, m.strip.y)
            var guard = 0
            while (m.jointUnder() != j && guard++ < 600) {
                val dx = m.jointX[j] - m.strip.x
                val dy = m.jointY[j] - m.strip.y
                val l = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
                move(m, m.px + dx / l * 3f, m.py + dy / l * 3f)
            }
            assertEquals(j, m.jointUnder())
            wait(m, 0.8f)
            release(m, m.px, m.py)
        }
        carryTo(1) // fuera de turno: no cede
        assertFalse(m.activated[1])
        assertTrue(m.failures >= 1)
        carryTo(0); assertTrue(m.activated[0])
        carryTo(1); assertTrue(m.activated[1])
        assertFalse(m.solved)
        carryTo(2); assertTrue(m.activated[2])
        wait(m, 0.1f)
        assertTrue(m.solved)
    }

    @Test
    fun c4NeedsAlignedFragmentsAndBothWorlds() {
        val m = LetterMech()
        repeat(3) { tap(m, m.a.x - 10f, m.a.y) }
        repeat(4) { tap(m, m.b.x + 10f, m.b.y) }
        assertTrue(m.uprightBoth())
        drag(m, 228f, 110f, 192f, 96f)
        assertTrue(m.aligned)
        m.trauma = false
        wait(m, 1.3f)
        assertFalse("solo se ha visto NORMAL", m.solved)
        m.trauma = true
        wait(m, 1.3f)
        assertTrue(m.solved)
    }

    @Test
    fun hintsEscalateWithFailuresAndNeverGiveTheSolution() {
        val m = MarksMech()
        repeat(10) { tap(m, m.markX(1), 90f); wait(m, 4f) }
        assertTrue(m.assist >= 3)
        assertFalse(m.solved)
    }
}
