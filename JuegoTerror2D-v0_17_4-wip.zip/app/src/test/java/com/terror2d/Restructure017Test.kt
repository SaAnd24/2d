package com.terror2d

import com.terror2d.core.Depth
import com.terror2d.core.DepthBand
import com.terror2d.core.GameConfig
import com.terror2d.core.GameState
import com.terror2d.core.HideSpotType
import com.terror2d.core.MoveMode
import com.terror2d.core.SaveManager
import com.terror2d.core.SaveStore
import com.terror2d.story.Documents
import com.terror2d.story.NarrativePhase
import com.terror2d.story.StoryFlags
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v0.17: pruebas de integración de la reestructuración.
 *
 * REGLA DE ESTE ARCHIVO: solo usa APIs que existen. El contrato 2.5D ya lo entregó el frente de
 * movimiento y ESTÁ en el árbol: `core/Depth.kt` (`Depth.depthScale`, `MoveMode`, `DepthBand`,
 * `DepthLayer`, `FloorType`) y `core/GameConfig.kt` (constantes DEPTH_*, velocidades por modo y
 * stamina). `HideSpotType` lo crea este frente (`core/HideSpot.kt`) porque no existía en ningún
 * sitio. `SaveManager` también es de este frente.
 *
 * Qué depende de qué frente (si un test de aquí falla, es ese frente el que cambió el contrato):
 *  - MOVIMIENTO: `Depth.depthScale`, `MoveMode`, velocidades y stamina en `GameConfig`. El cableado
 *    con `Player` (qué velocidad usa cada modo, ruido, poses, controles de SNEAK/CROUCH) es suyo:
 *    cuando esté, aquí faltará un test de velocidad/ruido por modo.
 *  - ESCONDITES: `HideSpotType` (este frente) + `Wardrobe`/`ClosetView` existentes. Marcar en el mapa
 *    qué objeto es UNDER_BED o CURTAINS y su vista en primera persona es suyo: cuando esté, aquí
 *    faltará un test por tipo (entrar/salir, la criatura no ve al niño).
 *  - ESCENA/MAPA: asignar `depth` a objetos y segmentos y pintar por capas (`DepthLayer`, orden por
 *    profundidad). La prueba de la secuencia completa es a nivel de ESTADO (hitos, diario, apagón,
 *    escondite, captura), no de coordenadas.
 *  - MONSTRUO/SCREAMER: nuevo pixel art de la rana, nuevo screamer y su sonido. Aquí la patrulla y
 *    la captura se simulan con los hitos y contadores que ya existen (`CREATURE_ACTIVE`,
 *    `captureCount`).
 *
 * OJO: existe OTRO `MoveMode` en `chapter/mech/Mechanism.kt` (paquete `com.terror2d.chapter.mech`,
 * gestos de puzle). No choca en compilación (paquete distinto), pero no es el mismo tipo: estos
 * tests usan siempre `com.terror2d.core.MoveMode`.
 */
class Restructure017Test {

    /** Almacén en memoria (el mismo de SaveManagerTest, repetido para que este archivo sea autónomo). */
    private class MemoryStore : SaveStore {
        private val strings = HashMap<String, String>()
        private val booleans = HashMap<String, Boolean>()
        private val ints = HashMap<String, Int>()

        override fun getString(key: String, default: String?): String? = strings[key] ?: default
        override fun getBoolean(key: String, default: Boolean): Boolean = booleans[key] ?: default
        override fun getInt(key: String, default: Int): Int = ints[key] ?: default
        override fun putString(key: String, value: String) { strings[key] = value }
        override fun putBoolean(key: String, value: Boolean) { booleans[key] = value }
        override fun putInt(key: String, value: Int) { ints[key] = value }
        override fun clear() { strings.clear(); booleans.clear(); ints.clear() }
        override fun commit() {}
    }

    // ------------------------------------------------------------------ profundidad 2.5D

    @Test
    fun depthScaleIs082AtTheBackOneAtTheReferencePlaneAnd112AtTheFront() {
        assertEquals(0.82f, Depth.depthScale(0.0f), 1e-6f)
        assertEquals(1.0f, Depth.depthScale(GameConfig.DEPTH_REFERENCE), 1e-6f)
        assertEquals(1.0f, Depth.depthScale(0.6f), 1e-6f)
        assertEquals(1.12f, Depth.depthScale(1.0f), 1e-6f)
        assertEquals(0.97f, Depth.depthScale(0.5f), 1e-6f)
        assertEquals(GameConfig.DEPTH_SCALE_FAR, Depth.depthScale(0.0f), 1e-6f)
    }

    @Test
    fun depthScaleClampsOutsideZeroToOne() {
        assertEquals(0.82f, Depth.depthScale(-0.5f), 1e-6f)
        assertEquals(1.12f, Depth.depthScale(1.5f), 1e-6f)
        assertEquals(0.82f, Depth.depthScale(Float.NEGATIVE_INFINITY), 1e-6f)
        assertEquals(1.12f, Depth.depthScale(Float.POSITIVE_INFINITY), 1e-6f)
    }

    @Test
    fun depthScaleGrowsMonotonicallyFromBackToFront() {
        var prev = Depth.depthScale(0f)
        for (i in 1..10) {
            val cur = Depth.depthScale(i / 10f)
            assertTrue("la escala crece con la profundidad", cur > prev)
            prev = cur
        }
    }

    @Test
    fun depthBandKeepsFeetOnTheFloorAtTheReferencePlane() {
        val band = DepthBand(floorY = 150f)
        assertEquals(150f, band.footY(GameConfig.DEPTH_REFERENCE), 1e-6f)
        assertEquals(150f, band.footY(0.6f), 1e-6f)
        assertTrue("el fondo queda por encima del suelo", band.backY < 150f)
        assertTrue("el primer plano queda por debajo del suelo", band.frontY > 150f)
        assertEquals(0.6f, band.depthAt(150f), 1e-6f)
        assertEquals(0.8f, band.depthAt(band.footY(0.8f)), 1e-6f)
    }

    @Test
    fun movementSpeedsKeepWalkAt68AndOrderRunWalkSneakCrouch() {
        assertEquals("andar es la velocidad de siempre", 68f, GameConfig.WALK_SPEED, 1e-6f)
        assertTrue(GameConfig.RUN_SPEED > GameConfig.WALK_SPEED)
        assertTrue(GameConfig.WALK_SPEED > GameConfig.SNEAK_SPEED)
        assertTrue(GameConfig.SNEAK_SPEED > GameConfig.CROUCH_SPEED)
        assertEquals("la stamina se agota en ~4.5 s de carrera", 22f, GameConfig.STAMINA_DRAIN_RUN, 1e-6f)
    }

    // ------------------------------------------------------------------ contrato de movimiento y escondites

    @Test
    fun moveModesAreWalkRunSneakCrouch() {
        assertEquals(listOf(MoveMode.WALK, MoveMode.RUN, MoveMode.SNEAK, MoveMode.CROUCH), MoveMode.values().toList())
        assertEquals(MoveMode.RUN, MoveMode.valueOf("RUN"))
        assertEquals(MoveMode.CROUCH, MoveMode.valueOf("CROUCH"))
    }

    @Test
    fun hideSpotTypesAreClosetUnderBedCurtains() {
        assertEquals(
            listOf(HideSpotType.CLOSET, HideSpotType.UNDER_BED, HideSpotType.CURTAINS),
            HideSpotType.values().toList()
        )
        assertEquals(HideSpotType.UNDER_BED, HideSpotType.valueOf("UNDER_BED"))
    }

    // ------------------------------------------------------------------ secuencia completa (nivel de estado)

    /**
     * La secuencia carta → apagón → patrulla → escondite → puzzle, a nivel de estado: los hitos, el
     * diario, el apagón, el escondite y la captura sobreviven a guardar, cerrar y volver a cargar.
     * No usa coordenadas ni escenas: eso es del frente de escena/mapa.
     */
    @Test
    fun fullSequenceLetterBlackoutPatrolHidePuzzleSurvivesSaveAndLoad() {
        val saves = SaveManager(MemoryStore())
        val s = GameState()

        // 1. CARTA: el niño lee la nota de mamá y queda archivada en «Mi diario».
        assertEquals(NarrativePhase.INITIAL_ROUTINE, s.story.phase)
        s.story.set(StoryFlags.MEDICINE_PUZZLE_COMPLETED)
        s.story.advanceTo(NarrativePhase.MEDICINE_COMPLETED)
        s.story.set(StoryFlags.MOM_SCREAM_HEARD)
        s.story.advanceTo(NarrativePhase.MOM_SCREAM)
        assertTrue(s.diary.add(Documents.MOM_NOTE, "MomRoom", 100f, 10f))
        s.story.set(StoryFlags.MOM_NOTE_READ)
        s.story.advanceTo(NarrativePhase.MOM_NOTE_READ)
        assertEquals(NarrativePhase.MOM_NOTE_READ, s.story.phase)

        // 2. APAGÓN: al cerrar la carta revientan los focos (una sola vez).
        assertFalse(s.blackoutDone)
        s.blackoutDone = true

        // 3. PATRULLA: tras la introducción la criatura ronda la casa.
        s.story.set(StoryFlags.CREATURE_INTRO_UNLOCKED)
        s.story.set(StoryFlags.CREATURE_INTRO_DONE)
        s.story.set(StoryFlags.CREATURE_ACTIVE)
        s.story.set(StoryFlags.SURVIVAL_READY)
        s.story.advanceTo(NarrativePhase.SURVIVAL_READY)
        assertEquals(NarrativePhase.SURVIVAL_READY, s.story.phase)

        // 4. ESCONDITE: el niño se esconde (armario) y sale; luego lo capturan una vez.
        s.playerHidden = true
        assertTrue(s.playerHidden)
        s.playerHidden = false
        s.captureCount = 1
        s.story.set(StoryFlags.CREATURE_FIRST_CAPTURE)

        // 5. PUZZLE: el progreso de puzles también son hitos, y el vaso soltado queda en el suelo.
        s.story.set(StoryFlags.PUZZLE_STARTED)
        s.story.set(StoryFlags.MEDICINE_CODE_KNOWN)
        s.dropped.drop("water_glass", "Kitchen", 120f, 42f)

        saves.save(s)

        // Cerrar y volver a abrir: todo el progreso sigue ahí.
        val loaded = GameState()
        assertTrue(saves.load(loaded))
        assertTrue(loaded.diary.has(Documents.MOM_NOTE))
        assertEquals(listOf(Documents.MOM_NOTE), loaded.diary.entries.map { it.docId })
        assertEquals(NarrativePhase.SURVIVAL_READY, loaded.story.phase)
        assertTrue(loaded.story.has(StoryFlags.CREATURE_ACTIVE))
        assertTrue(loaded.story.has(StoryFlags.SURVIVAL_READY))
        assertTrue(loaded.blackoutDone)
        assertFalse("al cargar no se está escondido", loaded.playerHidden)
        assertEquals(1, loaded.captureCount)
        assertTrue(loaded.story.has(StoryFlags.CREATURE_FIRST_CAPTURE))
        assertTrue(loaded.story.has(StoryFlags.MEDICINE_CODE_KNOWN))
        assertEquals("Kitchen", loaded.dropped.whereIs("water_glass")?.segmentId)
    }

    @Test
    fun newGameHasNoProgressButKeepsTheContract() {
        val saves = SaveManager(MemoryStore())
        val fresh = GameState()
        assertFalse(saves.load(fresh))
        assertEquals(NarrativePhase.INITIAL_ROUTINE, fresh.story.phase)
        assertEquals(0, fresh.diary.size)
        assertFalse(fresh.blackoutDone)
        assertEquals(0, fresh.captureCount)
        // el contrato 2.5D existe aunque no haya partida
        assertEquals(0.82f, Depth.depthScale(0f), 1e-6f)
        assertEquals(MoveMode.WALK, MoveMode.valueOf("WALK"))
        assertEquals(HideSpotType.CLOSET, HideSpotType.valueOf("CLOSET"))
    }
}
