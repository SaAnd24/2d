package com.terror2d

import com.terror2d.chapter.ChapterFlags
import com.terror2d.closet.ClosetView
import com.terror2d.core.Depth
import com.terror2d.core.HideSpot
import com.terror2d.core.HideSpotType
import com.terror2d.creature.ClosetMemory
import com.terror2d.creature.ClosetReaction
import com.terror2d.creature.HideSearch
import com.terror2d.creature.HousePatrol
import com.terror2d.scene.ChapterHouse
import com.terror2d.scene.HouseDefinition
import com.terror2d.scene.HouseEdgeKind
import com.terror2d.scene.buildConnectors
import com.terror2d.scene.buildHouseGraph
import com.terror2d.scene.connectorProblems
import com.terror2d.world.Wardrobe
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v0.17 (frente mapa + escondites): grafo no lineal, atajos, patrulla por el grafo y escondites de los 3 tipos. */
class HouseGraphTest {

    private val def = ChapterHouse.create()
    private val graph = def.buildHouseGraph()

    // ------------------------------------------------------------------ grafo

    @Test
    fun graphHasNineteenNodesAndIsConnectedFromTheHubWithoutOrphans() {
        assertEquals(19, graph.nodes.size)
        assertEquals(ChapterHouse.HUB, ChapterHouse.FOYER)
        assertTrue("todo alcanzable desde el hub", graph.isConnected(ChapterHouse.HUB))
        assertTrue("sin conectores huérfanos ni puertas sin vuelta", def.connectorProblems().isEmpty())
        val cons = def.buildConnectors()
        val ids = def.segments.map { it.id }.toSet()
        assertEquals("ids de conector únicos", cons.size, cons.map { it.id }.toSet().size)
        for (c in cons) {
            assertTrue(c.id, ids.contains(c.fromSeg))
            assertTrue(c.id, ids.contains(c.toSeg))
        }
    }

    @Test
    fun everyMainRoomHasAtLeastTwoExits() {
        val main = listOf(
            HouseDefinition.KID, HouseDefinition.BATH, HouseDefinition.MOM, HouseDefinition.HALL,
            ChapterHouse.LIVING, HouseDefinition.DINING, HouseDefinition.KITCHEN, ChapterHouse.PANTRY,
            ChapterHouse.SERVICE_BATH, ChapterHouse.FOYER, HouseDefinition.CELLAR, HouseDefinition.LAUNDRY,
            ChapterHouse.ELECTRIC, ChapterHouse.BOILER, ChapterHouse.STORAGE
        )
        for (room in main) assertTrue(room + " tiene " + graph.degree(room) + " salidas", graph.degree(room) >= 2)
        // excepciones documentadas (una sola salida, por diseño): estudio (secreto C2), azotea (trampilla) e imposible (sala final)
        assertEquals(
            listOf(ChapterHouse.STUDY, ChapterHouse.ROOF, ChapterHouse.IMPOSSIBLE),
            graph.singleExitRooms()
        )
    }

    @Test
    fun newShortcutsExistInBothDirectionsAndShortenRoutes() {
        for ((a, b) in ChapterHouse.NEW_SHORTCUTS) {
            assertTrue("$a -> $b", graph.hasEdge(a, b, HouseEdgeKind.DOOR))
            assertTrue("$b -> $a", graph.hasEdge(b, a, HouseEdgeKind.DOOR))
        }
        // ★S1: comedor-cocina directo (1) en vez de por el vestíbulo (2)
        assertEquals(1, graph.pathTo(HouseDefinition.KITCHEN, HouseDefinition.DINING)!!.size)
        // ★S2 y ★S6: directos en el sótano
        assertEquals(1, graph.pathTo(HouseDefinition.LAUNDRY, ChapterHouse.ELECTRIC)!!.size)
        assertEquals(1, graph.pathTo(ChapterHouse.BOILER, ChapterHouse.STORAGE)!!.size)
        // ★S5: despensa-baño de servicio directo (1) en vez de por cocina+vestíbulo (3)
        assertEquals(1, graph.pathTo(ChapterHouse.PANTRY, ChapterHouse.SERVICE_BATH)!!.size)
        // ★S3: del dormitorio del niño al de mamá por el baño (2 tramos)
        assertEquals(2, graph.pathTo(HouseDefinition.KID, HouseDefinition.MOM)!!.size)
        assertTrue(graph.hasEdge(HouseDefinition.KID, HouseDefinition.BATH, HouseEdgeKind.DOOR))
        assertTrue(graph.hasEdge(HouseDefinition.BATH, HouseDefinition.MOM, HouseEdgeKind.DOOR))
    }

    @Test
    fun secretsAreChildOnlyAndNeedTheirPuzzle() {
        // la criatura no usa secretos: sin ellos el estudio es inalcanzable, y a la despensa tiene que rodear (3 tramos en vez de 1)
        assertNull(graph.pathTo(ChapterHouse.CLOSET, ChapterHouse.STUDY, forCreature = true))
        assertEquals(1, graph.pathTo(ChapterHouse.LIVING, ChapterHouse.PANTRY)!!.size)
        assertEquals(3, graph.pathTo(ChapterHouse.LIVING, ChapterHouse.PANTRY, forCreature = true)!!.size)
        // el niño sí, pero solo con el puzle resuelto
        val toStudy = graph.pathTo(ChapterHouse.CLOSET, ChapterHouse.STUDY)!!
        assertEquals(1, toStudy.size)
        assertEquals(HouseEdgeKind.SECRET_PASSAGE, toStudy[0].kind)
        assertEquals(ChapterFlags.solved("C2"), toStudy[0].requiresFlag)
        assertFalse(toStudy[0].creatureCanPass)
        assertNull(graph.pathTo(ChapterHouse.CLOSET, ChapterHouse.STUDY, solvedFlags = emptySet()))
        assertNotNull(graph.pathTo(ChapterHouse.CLOSET, ChapterHouse.STUDY, solvedFlags = setOf(ChapterFlags.solved("C2"))))
        val toImpossible = graph.pathTo(ChapterHouse.CLOSET, ChapterHouse.IMPOSSIBLE)!!
        assertEquals(ChapterFlags.HOUSE_EXIT_UNLOCKED, toImpossible[0].requiresFlag)
    }

    @Test
    fun baseHouseGraphIsConnectedThroughWindows() {
        val g = HouseDefinition.graph()
        assertEquals(8, g.nodes.size)
        assertTrue(g.isConnected(HouseDefinition.HALL))
        assertTrue(g.hasEdge(HouseDefinition.HALL, HouseDefinition.KID, HouseEdgeKind.DOOR))
        assertTrue("la ventana del laboratorio une KidRoom con Bathroom", g.hasEdge(HouseDefinition.KID, HouseDefinition.BATH, HouseEdgeKind.WINDOW))
    }

    // ------------------------------------------------------------------ patrulla por el grafo

    @Test
    fun patrolUsesShortcutsAndCanFlankThroughThem() {
        val patrol = HousePatrol(def.buildConnectors())
        // el camino más corto ya usa el atajo ★S1
        assertEquals(1, patrol.pathTo(HouseDefinition.KITCHEN, HouseDefinition.DINING)!!.size)
        assertTrue(patrol.pathUsesShortcut(HouseDefinition.KITCHEN, HouseDefinition.DINING, setOf("door_kitchen_dining")))
        assertFalse(patrol.pathUsesShortcut(HouseDefinition.KITCHEN, HouseDefinition.DINING, setOf("door_kitchen_corridor")))
        // rodeo: de la sala a la cocina pasando por el comedor (aparece por el otro lado)
        val flank = patrol.flankPath(ChapterHouse.LIVING, HouseDefinition.KITCHEN, HouseDefinition.DINING)!!
        assertEquals(3, flank.size)
        assertEquals(ChapterHouse.LIVING, flank.first().fromSeg)
        assertEquals(HouseDefinition.KITCHEN, flank.last().toSeg)
        assertTrue("el rodeo usa el atajo", flank.any { it.id == "door_dining_kitchen" })
        // alcanzable a pie (sin secretos): todo menos estudio e imposible
        val expected = def.segments.map { it.id }.toSet() - setOf(ChapterHouse.STUDY, ChapterHouse.IMPOSSIBLE)
        assertEquals(expected, patrol.reachableRooms(HouseDefinition.KITCHEN))
        assertEquals("el hub tiene 6 salidas", 6, patrol.exitsCount(ChapterHouse.FOYER))
        assertEquals("la cocina tiene 3 salidas", 3, patrol.exitsCount(HouseDefinition.KITCHEN))
    }

    // ------------------------------------------------------------------ escondites (3 tipos)

    @Test
    fun hideSpotsCoverAllThreeTypes() {
        val spots = ChapterHouse.hideSpots(def)
        assertEquals("un armario por zona (19) + 2 bajo la cama + 2 tras cortinas", 23, spots.size)
        assertEquals(19, spots.count { it.type == HideSpotType.CLOSET })
        assertEquals(2, spots.count { it.type == HideSpotType.UNDER_BED })
        assertEquals(2, spots.count { it.type == HideSpotType.CURTAINS })
        assertEquals("ids únicos", spots.size, spots.map { it.id }.toSet().size)
        val rooms = def.segments.map { it.id }.toSet()
        for (s in spots) {
            assertTrue(s.id, rooms.contains(s.roomId))
            assertTrue(s.id, s.depth in 0f..1f)
        }
        val underKid = spots.first { it.id == "hide_underbed_kid" }
        assertEquals(HouseDefinition.KID, underKid.roomId)
        assertEquals(HideSpotType.UNDER_BED, underKid.type)
        assertEquals(0.85f, underKid.depth, 0f)
        val underMom = spots.first { it.id == "hide_underbed_mom" }
        assertEquals(HouseDefinition.MOM, underMom.roomId)
        val curtLiving = spots.first { it.id == "hide_curtains_living" }
        assertEquals(ChapterHouse.LIVING, curtLiving.roomId)
        val curtStudy = spots.first { it.id == "hide_curtains_study" }
        assertEquals(ChapterHouse.STUDY, curtStudy.roomId)
        // la profundidad usa la escala del contrato (0.85 -> 1.075)
        assertEquals(1.075f, Depth.depthScale(underKid.depth), 1e-6f)
        // el botón dice dónde se mete el niño
        val kidWardrobes = def.segment(HouseDefinition.KID).objects.filterIsInstance<Wardrobe>()
        assertEquals("DEBAJO DE LA CAMA", kidWardrobes.first { it.id == "hide_underbed_kid" }.promptText)
        assertEquals("ESCONDERSE", kidWardrobes.first { it.id == HouseDefinition.WARDROBE_KID }.promptText)
        val studyWardrobes = def.segment(ChapterHouse.STUDY).objects.filterIsInstance<Wardrobe>()
        assertEquals("TRAS LA CORTINA", studyWardrobes.first { it.id == "hide_curtains_study" }.promptText)
    }

    // ------------------------------------------------------------------ escalada + olvido (todos los tipos)

    @Test
    fun suspicionEscalatesAndForgetsForEveryHideType() {
        val m = ClosetMemory()
        for (id in listOf(HouseDefinition.WARDROBE_KID, "hide_underbed_kid", "hide_curtains_living")) {
            assertEquals(id, ClosetReaction.PASS, m.register(id))
            assertEquals(id, ClosetReaction.PASS, m.register(id))
            assertEquals(id, ClosetReaction.SUSPICION, m.register(id))
            assertEquals(id, ClosetReaction.WARNING, m.register(id))
            assertEquals(id, ClosetReaction.WARNING, m.register(id))
            assertEquals(id, ClosetReaction.CAPTURE, m.register(id))
            m.forgive(id)
            assertEquals(id, ClosetReaction.PASS, m.current(id))
        }
        // olvido cada 40 s: a los 39 s nada cambia; a los 40 s se descuenta un uso en TODOS los tipos
        val m2 = ClosetMemory()
        repeat(3) { m2.register("hide_underbed_mom") }
        assertEquals(ClosetReaction.SUSPICION, m2.current("hide_underbed_mom"))
        m2.decay(39f)
        assertEquals(ClosetReaction.SUSPICION, m2.current("hide_underbed_mom"))
        m2.decay(1f)
        assertEquals("un uso menos: 3 -> 2", ClosetReaction.PASS, m2.current("hide_underbed_mom"))
        assertEquals(2, m2.usesOf("hide_underbed_mom"))
        // sobrecargas con HideSpot
        val spot = HideSpot("hide_curtains_study", HideSpotType.CURTAINS, ChapterHouse.STUDY, 112f, 0.55f)
        val m3 = ClosetMemory()
        assertEquals(ClosetReaction.PASS, m3.register(spot))
        assertEquals(1, m3.suspicionOf(spot))
        assertEquals(1, m3.withSuspicion(spot).suspicion)
        assertEquals(ClosetReaction.PASS, m3.current(spot))
    }

    // ------------------------------------------------------------------ búsqueda de la criatura

    @Test
    fun creatureSearchesNearbyHidesWithoutKnowingWhereTheChildIs() {
        val spots = listOf(
            HideSpot("a", HideSpotType.CLOSET, ChapterHouse.LIVING, 100f, 0.45f, suspicion = 0),
            HideSpot("b", HideSpotType.UNDER_BED, ChapterHouse.LIVING, 200f, 0.85f, suspicion = 3),
            HideSpot("c", HideSpotType.CURTAINS, ChapterHouse.LIVING, 150f, 0.55f, suspicion = 0)
        )
        // orden: del más cercano al más lejano a la criatura (x=140)
        val plan = HideSearch.plan(spots, 140f)
        assertEquals(listOf("c", "a", "b"), plan.map { it.spotId })
        // más sospecha = más tiempo revisando (1.4 s base + 0.4 s por uso)
        assertEquals(1.4f, plan.first { it.spotId == "a" }.checkSeconds, 0.001f)
        assertEquals(2.6f, plan.first { it.spotId == "b" }.checkSeconds, 0.001f)
        // la cortina tapa menos: más fácil de encontrar que el armario
        assertTrue(HideSearch.findChance(spots[2]) > HideSearch.findChance(spots[0]))
        assertEquals(0.45f, HideSearch.findChance(spots[2]), 0.001f)
        assertEquals(0.61f, HideSearch.findChance(spots[1]), 0.001f)
        // solo se busca con motivo
        assertFalse(HideSearch.shouldSearch(ClosetReaction.PASS, false))
        assertTrue(HideSearch.shouldSearch(ClosetReaction.SUSPICION, false))
        assertTrue(HideSearch.shouldSearch(ClosetReaction.PASS, true))
        // resolver: un escondite vacío nunca «encuentra» al niño, por muy baja que sea la tirada
        val check = plan.first { it.spotId == "c" }
        assertFalse(HideSearch.resolve(check, childHiddenHere = false, holdingBreath = false, roll01 = 0f))
        assertTrue(HideSearch.resolve(check, childHiddenHere = true, holdingBreath = false, roll01 = 0f))
        assertTrue("tirada 0.30 < 0.45: lo encuentra", HideSearch.resolve(check, true, false, 0.3f))
        assertFalse("aguantando la respiración la probabilidad es la mitad (0.225): se salva", HideSearch.resolve(check, true, true, 0.3f))
        assertEquals(HideSearch.rollFor("a", 7, 1), HideSearch.rollFor("a", 7, 1), 0f)
    }

    // ------------------------------------------------------------------ vista interior por tipo

    @Test
    fun closetViewChangesWithHideTypeBreathAndHeartbeat() {
        val under = ClosetView()
        under.begin(false, HideSpotType.UNDER_BED)
        assertEquals("DEBAJO DE LA CAMA", under.interiorLabel)
        assertEquals(0.8f, under.slitFactor, 0f)
        assertTrue("bajo la cama la rendija es más estrecha", under.slitWidth < 13f)
        val curtains = ClosetView()
        curtains.begin(false, HideSpotType.CURTAINS)
        assertEquals("DETRÁS DE LA CORTINA", curtains.interiorLabel)
        assertTrue("tras la cortina la rendija es más ancha", curtains.slitWidth > 13f)
        val closet = ClosetView()
        closet.begin(false)
        assertEquals("ARMARIO", closet.interiorLabel)
        assertEquals(13f, closet.slitWidth, 0.001f)
        // latido: en calma ~1.05 s entre latidos; tras correr mucho y con peligro, ~0.5 s
        assertEquals(0f, closet.heartbeatIntensity, 0f)
        assertEquals(1.05f, closet.heartbeatInterval, 0.001f)
        closet.setExertion(2f)
        assertEquals("el esfuerzo se acota a 0..1", 1f, closet.exertion, 0f)
        repeat(40) { closet.update(0.1f, 1f) }
        assertTrue(closet.heartbeatIntensity > 0.9f)
        assertTrue(closet.heartbeatInterval < 0.6f)
        // aguantar la respiración: 6 s de aire; al agotarse, aviso de que hay que respirar
        val held = ClosetView()
        held.begin(false)
        held.setHoldingBreath(true)
        assertFalse(held.breathingAudible)
        repeat(61) { held.update(0.1f, 0f) }
        assertTrue("se acabó el aire", held.consumeGasp())
        assertFalse("el aviso es una sola vez", held.consumeGasp())
        assertFalse(held.holdingBreath)
        assertTrue(held.breathingAudible)
    }
}
