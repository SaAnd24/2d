package com.terror2d

import com.terror2d.audio.SfxId
import com.terror2d.chapter.ChapterDocuments
import com.terror2d.chapter.ChapterFlags
import com.terror2d.chapter.MicroScareDirector
import com.terror2d.chapter.MicroScares
import com.terror2d.chapter.PuzzleBook
import com.terror2d.chapter.PuzzlePanel
import com.terror2d.chapter.VisualLevels
import com.terror2d.core.WorldMode
import com.terror2d.scene.ChapterHouse
import com.terror2d.scene.HouseDefinition
import com.terror2d.story.Documents
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Capítulo I: puzles, documentos, casa de dos mundos, micro-sustos y niveles visuales. (Escritas sin poder ejecutarlas.) */
class ChapterTest {

    @Test
    fun fifteenPuzzlesWithFixedIds() {
        assertEquals(15, PuzzleBook.ALL.size)
        assertEquals(ChapterFlags.PUZZLE_IDS, PuzzleBook.ALL.map { it.id })
        assertEquals(5, PuzzleBook.ALL.count { it.id.startsWith("N") })
        assertEquals(5, PuzzleBook.ALL.count { it.id.startsWith("T") })
        assertEquals(5, PuzzleBook.ALL.count { it.id.startsWith("C") })
    }

    @Test
    fun everyPuzzleIsDeterministicAndFair() {
        for (d in PuzzleBook.ALL) {
            assertEquals(d.id, d.slots.size, d.solution.size)
            for (i in d.slots.indices) assertTrue(d.id, d.solution[i] in d.slots[i].options.indices)
            assertFalse("nace resuelto: " + d.id, d.startValues.contentEquals(d.solution))
            assertTrue("pistas: " + d.id, d.hints.isNotEmpty())
            assertTrue(d.solvedText.isNotEmpty())
        }
    }

    @Test
    fun panelSolvesOnlyWithTheSolution() {
        val d = PuzzleBook.N1
        val p = PuzzlePanel(d)
        assertFalse(p.test())
        for (i in d.slots.indices) while (p.values[i] != d.solution[i]) p.tapSlot(i)
        assertTrue(p.test())
        assertTrue(p.solved)
    }

    @Test
    fun wrongAttemptsGiveEscalatingHints() {
        val p = PuzzlePanel(PuzzleBook.N2)
        p.test()
        p.test()
        assertTrue(p.message.contains(PuzzleBook.N2.hints[0]))
    }

    @Test
    fun rhythmOfT1MatchesItsSolutionAndMarks() {
        val d = PuzzleBook.T1
        val r = d.rhythm!!
        val m = d.marks!!
        for (i in r.indices) {
            assertEquals(if (r[i]) 1 else 0, d.solution[i])
            assertEquals(r[i], m[i] >= 2)
        }
        val p = PuzzlePanel(d)
        p.startListen()
        var t = 0f
        while (t < 6f) { p.update(0.05f); t += 0.05f }
        assertEquals(r.count { it }, p.knockSerial)
    }

    @Test
    fun theWholeChapterIsSolvableFromScratch() {
        // simula: observaciones y piezas libres + resolver en cualquier orden lo que ya se pueda
        val flags = HashSet<String>()
        for (id in listOf("C1", "C2", "C3", "C5", "T3")) flags.add(ChapterFlags.observed(id))
        flags.add(ChapterFlags.GOT_GLASS)
        flags.add(ChapterFlags.GOT_LETTER_B)
        // D03 ("Mi horario") se lee en la cocina sin resolver ningún puzle: es una observación libre
        // como las de arriba, y N2 la exige (docs/CAPITULO1.md: "N2 (necesita leer D03 en la cocina)").
        flags.add("read_d03")
        var progress = true
        while (progress) {
            progress = false
            for (d in PuzzleBook.ALL) {
                if (flags.contains(d.solvedFlag)) continue
                if (flags.containsAll(d.requires)) {
                    flags.add(d.solvedFlag)
                    flags.addAll(d.rewards)
                    progress = true
                }
            }
        }
        for (d in PuzzleBook.ALL) assertTrue("sin salida: " + d.id, flags.contains(d.solvedFlag))
        assertTrue(flags.contains(ChapterFlags.HOUSE_EXIT_UNLOCKED))
    }

    @Test
    fun twentyTwoDocumentsFitThePaper() {
        val bases = ChapterDocuments.ALL.map { it.id.removeSuffix("_t").removeSuffix("a").removeSuffix("b").removeSuffix("c") }.toSet()
        assertTrue(bases.size >= 20)
        assertEquals(ChapterDocuments.ALL.size, ChapterDocuments.ALL.map { it.id }.toSet().size)
        for (d in ChapterDocuments.ALL) {
            assertTrue(d.id, d.lines.size <= ChapterDocuments.MAX_LINES)
            for (l in d.lines) assertTrue(d.id + ": " + l, l.length <= 32)
            assertNotNull(Documents.get(d.id))
        }
        assertEquals(3, Documents.ALL.size)
    }

    @Test
    fun documentsChangeWithTheWorld() {
        assertEquals("d01_t", ChapterDocuments.idFor("d01", WorldMode.TRAUMA))
        assertEquals("d01", ChapterDocuments.idFor("d01", WorldMode.NORMAL))
        assertEquals("d02", ChapterDocuments.idFor("d02", WorldMode.TRAUMA))
    }

    @Test
    fun theHouseHasTwentySegmentsAndTwoWorldsWithTheSameMap() {
        val def = ChapterHouse.create()
        assertEquals(8 + ChapterHouse.NEW_ROOMS.size, def.segments.size)
        for (r in ChapterHouse.NEW_ROOMS + HouseDefinition.ROOMS + HouseDefinition.HALL) assertNotNull(r, def.segments.firstOrNull { it.id == r })
        for (t in def.traumaSegments) {
            val n = def.segments.first { it.id == t.id }
            assertEquals(n.width, t.width, 0f)
            assertEquals(n.floorY, t.floorY, 0f)
            assertEquals(WorldMode.TRAUMA, t.worldMode)
            // misma geometría jugable: los mismos objetos que colisionan
            assertEquals(n.objects.count { it.collidable }, t.objects.count { it.collidable })
        }
        assertEquals(def.segments.size - 1, def.traumaSegments.size)
        assertEquals(19, def.segments.size)
    }

    @Test
    fun theOriginalHouseIsUntouched() {
        assertEquals(8, HouseDefinition.create().segments.size)
    }

    private fun floorOf(def: com.terror2d.scene.SceneDefinition, id: String): String =
        ChapterHouse.FLOORS.entries.first { it.value.contains(id) }.key

    @Test
    fun everyDoorLeadsToARealSpawnAndHasAWayBack() {
        val def = ChapterHouse.create()
        val ids = def.segments.map { it.id }.toSet()
        for (s in def.segments) for (d in s.doors) {
            if (s.id == ChapterHouse.IMPOSSIBLE) continue // salida final controlada
            val t = d.target ?: continue
            assertTrue(ids.contains(t.segmentId))
            assertNotNull(t.spawnId, def.segment(t.segmentId).spawnPoints[t.spawnId])
            // vuelta: la estancia de destino tiene alguna puerta que regresa a esta
            assertTrue(s.id + " -> " + t.segmentId, def.segment(t.segmentId).doors.any { it.target?.segmentId == s.id })
        }
    }

    @Test
    fun everyZoneBelongsToOneFloor() {
        val def = ChapterHouse.create()
        val all = ChapterHouse.FLOORS.values.flatten()
        assertEquals(19, all.size)
        assertEquals(all.size, all.toSet().size)
        assertEquals(def.segments.map { it.id }.toSet(), all.toSet())
    }

    @Test
    fun onlyTheStairsAndTheTrapdoorCrossFloors() {
        val def = ChapterHouse.create()
        val allowed = setOf(
            setOf(HouseDefinition.HALL, ChapterHouse.FOYER),                  // escalera principal
            setOf(ChapterHouse.FOYER, HouseDefinition.CELLAR),                // escalera de servicio
            setOf(HouseDefinition.HALL, ChapterHouse.ROOF)                    // trampilla
        )
        for (s in def.segments) for (d in s.doors) {
            if (s.id == ChapterHouse.IMPOSSIBLE) continue // salida final controlada (C5)
            val t = d.target ?: continue
            if (floorOf(def, s.id) != floorOf(def, t.segmentId)) assertTrue(s.id + "->" + t.segmentId, allowed.contains(setOf(s.id, t.segmentId)))
        }
    }

    @Test
    fun everyRoomIsReachableOnFootFromTheChildsRoom() {
        val def = ChapterHouse.create()
        val seen = HashSet<String>()
        val todo = ArrayDeque<String>()
        todo.add(HouseDefinition.KID)
        while (todo.isNotEmpty()) {
            val id = todo.removeFirst()
            if (!seen.add(id)) continue
            for (d in def.segment(id).doors) d.target?.let { todo.add(it.segmentId) }
        }
        // sin los pasos secretos solo faltan: estudio (C2) e imposible (C5)
        assertEquals(def.segments.map { it.id }.toSet() - setOf(ChapterHouse.STUDY, ChapterHouse.IMPOSSIBLE), seen)
    }

    @Test
    fun kitchenIsReachedWalkingAlongTheGroundFloorCorridor() {
        val def = ChapterHouse.create()
        fun to(from: String) = def.segment(from).doors.mapNotNull { it.target?.segmentId }
        assertTrue(to(HouseDefinition.HALL).contains(ChapterHouse.FOYER))
        assertFalse(to(HouseDefinition.HALL).contains(HouseDefinition.KITCHEN))
        for (r in listOf(ChapterHouse.LIVING, HouseDefinition.DINING, HouseDefinition.KITCHEN, ChapterHouse.SERVICE_BATH, HouseDefinition.CELLAR)) {
            assertTrue(r, to(ChapterHouse.FOYER).contains(r))
        }
        assertTrue(to(HouseDefinition.KITCHEN).contains(ChapterHouse.PANTRY))
        assertFalse(to(HouseDefinition.CELLAR).contains(HouseDefinition.HALL))
    }

    @Test
    fun noWindowShortcutsRemain() {
        val def = ChapterHouse.create()
        for (s in def.segments + def.traumaSegments) for (o in s.objects) assertFalse(s.id, o is com.terror2d.world.WindowPassage)
    }

    @Test
    fun theWaterGlassNeedsTheFullRoundTrip() {
        val c3 = PuzzleBook.C3
        assertTrue(c3.requires.contains(ChapterFlags.observed("C3")))
        assertTrue(c3.requires.contains(ChapterFlags.solved("T4")))
        assertEquals("N2 necesita D03", listOf("read_d03"), PuzzleBook.N2.requires)
    }

    @Test
    fun microScaresAreSpacedAndOnlyFireOnce() {
        val played = ArrayList<SfxId>()
        val d = MicroScareDirector { s, _ -> played.add(s) }
        val a = MicroScares.get("foyer_coatrack")!!
        val b = MicroScares.get("cellar_creak")!!
        d.request(a, false)
        d.request(b, false)
        val marked = ArrayList<String>()
        var t = 0f
        while (t < 30f) {
            d.update(0.1f, false, true) { marked.add(it.id) }
            t += 0.1f
        }
        assertEquals(listOf("foyer_coatrack", "cellar_creak"), marked)
        assertEquals(2, played.size)
        d.request(a, true)
        d.update(0.1f, false, true) { marked.add(it.id) }
        assertEquals(2, marked.size)
    }

    @Test
    fun microScareIdsAreUniqueAndGentle() {
        assertEquals(MicroScares.ALL.size, MicroScares.ALL.map { it.id }.toSet().size)
        for (s in MicroScares.ALL) for (st in s.steps) assertTrue(s.id, st.intensity <= 1f)
    }

    @Test
    fun visualLevelsFollowCapturesAndNeverGoBeyondThree() {
        assertEquals(1, VisualLevels.of(0))
        assertEquals(2, VisualLevels.of(1))
        assertEquals(3, VisualLevels.of(2))
        assertEquals(3, VisualLevels.of(50))
    }
}
