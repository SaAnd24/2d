package com.terror2d

import com.terror2d.core.GameState
import com.terror2d.core.SaveManager
import com.terror2d.core.SaveStore
import com.terror2d.story.NarrativePhase
import com.terror2d.story.StoryFlags
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * v0.17: pruebas del guardado mínimo ([SaveManager]).
 *
 * El guardado real usa `SharedPreferences` de Android, que no existe en los tests unitarios de la JVM:
 * aquí se prueba [SaveManager] contra un almacén en memoria que implementa la misma interfaz
 * ([SaveStore]). El adaptador real (`SharedPreferencesStore`) es solo traducción clave-valor y se
 * verifica en el dispositivo (ver docs/REESTRUCTURACION_0_17.md, «Cómo probar el guardado»).
 */
class SaveManagerTest {

    /** Almacén en memoria con la misma interfaz que el de Android. */
    private class MemoryStore : SaveStore {
        private val strings = HashMap<String, String>()
        private val booleans = HashMap<String, Boolean>()
        private val ints = HashMap<String, Int>()

        override fun getString(key: String, default: String?): String? = strings[key] ?: default
        override fun getBoolean(key: String, default: Boolean): Boolean = booleans[key] ?: default
        override fun getInt(key: String, default: Int): Int = ints[key] ?: default
        override fun putString(key: String, value: String) { strings[key] = value }
        override fun putBoolean(key: String, value: Boolean) { booleans[key] = value }
        override fun putInt(key: String, value: Int) { ints[key] = value }
        override fun clear() { strings.clear(); booleans.clear(); ints.clear() }
        override fun commit() {}
    }

    private fun playedState(): GameState {
        val s = GameState()
        s.story.set(StoryFlags.INTRO_DONE)
        s.story.set(StoryFlags.MEDICINE_PUZZLE_COMPLETED)
        s.story.advanceTo(NarrativePhase.MOM_SCREAM)
        s.diary.add("d05", "Hall", 10f, 1f)
        s.diary.add("d01", "KidRoom", 20f, 2f)
        s.diary.markAllSeen()
        s.diary.add("d19", "KidRoom", 5f, 3f)
        s.blackoutDone = true
        s.dropped.drop("water_glass", "Kitchen", 120f, 42f)
        s.dropped.drop("medicine_blue", "MomRoom", 30f, 50f)
        s.captureCount = 2
        return s
    }

    @Test
    fun loadWithoutSaveReturnsFalseAndLeavesStateUntouched() {
        val saves = SaveManager(MemoryStore())
        val fresh = GameState()
        assertFalse(saves.hasSave())
        assertFalse(saves.load(fresh))
        assertEquals(NarrativePhase.INITIAL_ROUTINE, fresh.story.phase)
        assertEquals(0, fresh.diary.size)
        assertFalse(fresh.blackoutDone)
        assertEquals(0, fresh.dropped.all.size)
        assertEquals(0, fresh.captureCount)
    }

    @Test
    fun saveWritesVersionAndHasSaveBecomesTrue() {
        val saves = SaveManager(MemoryStore())
        saves.save(GameState())
        assertTrue(saves.hasSave())
    }

    @Test
    fun diaryRoundTripKeepsOrderAndUnread() {
        val store = MemoryStore()
        val saves = SaveManager(store)
        saves.save(playedState())

        val loaded = GameState()
        assertTrue(saves.load(loaded))
        assertEquals(listOf("d05", "d01", "d19"), loaded.diary.entries.map { it.docId })
        assertEquals("las dos primeras estaban vistas, la tercera no", 1, loaded.diary.unread)
        assertTrue(loaded.diary.has("d01"))
        assertTrue("la variante TRAUMA comparte entrada", loaded.diary.has("d01_t"))
    }

    @Test
    fun storyFlagsRoundTripRestoresPhase() {
        val saves = SaveManager(MemoryStore())
        saves.save(playedState())

        val loaded = GameState()
        assertTrue(saves.load(loaded))
        assertTrue(loaded.story.has(StoryFlags.INTRO_DONE))
        assertTrue(loaded.story.has(StoryFlags.MEDICINE_PUZZLE_COMPLETED))
        assertEquals(NarrativePhase.MOM_SCREAM, loaded.story.phase)
        assertTrue(loaded.story.isAtLeast(NarrativePhase.MEDICINE_COMPLETED))
    }

    @Test
    fun blackoutDroppedAndCaptureCountRoundTrip() {
        val saves = SaveManager(MemoryStore())
        saves.save(playedState())

        val loaded = GameState()
        assertTrue(saves.load(loaded))
        assertTrue(loaded.blackoutDone)
        assertEquals(2, loaded.dropped.all.size)
        assertEquals("Kitchen", loaded.dropped.whereIs("water_glass")?.segmentId)
        assertEquals(120f, loaded.dropped.whereIs("water_glass")?.x ?: -1f, 0.001f)
        assertEquals(1, loaded.dropped.inSegment("MomRoom").size)
        assertEquals(2, loaded.captureCount)
    }

    @Test
    fun savingAgainOverwritesThePreviousSave() {
        val saves = SaveManager(MemoryStore())
        saves.save(playedState())
        val later = GameState()
        later.story.set(StoryFlags.SURVIVAL_READY)
        later.story.advanceTo(NarrativePhase.SURVIVAL_READY)
        later.captureCount = 5
        saves.save(later)

        val loaded = GameState()
        assertTrue(saves.load(loaded))
        assertEquals(NarrativePhase.SURVIVAL_READY, loaded.story.phase)
        assertFalse("el diario viejo no sobrevive al segundo guardado", loaded.diary.has("d05"))
        assertFalse(loaded.blackoutDone)
        assertEquals(5, loaded.captureCount)
    }

    @Test
    fun clearRemovesTheSave() {
        val saves = SaveManager(MemoryStore())
        saves.save(playedState())
        assertTrue(saves.hasSave())
        saves.clearSave()
        assertFalse(saves.hasSave())
        assertFalse(saves.load(GameState()))
    }

    @Test
    fun malformedSavedStringsDoNotBreakLoading() {
        val store = MemoryStore()
        val saves = SaveManager(store)
        store.putInt(SaveManager.KEY_VERSION, SaveManager.SAVE_VERSION)
        store.putString(SaveManager.KEY_DIARY, "esto no es un diario")
        store.putString(SaveManager.KEY_STORY_FLAGS, "intro_done\n\nmedicine_puzzle_done")
        store.putString(SaveManager.KEY_DROPPED, "solo-una-parte\na|b|c\nwater_glass|Kitchen|no-numero|42")
        store.commit()

        val loaded = GameState()
        assertTrue(saves.load(loaded))
        assertEquals("el diario mal formado se descarta sin romper", 0, loaded.diary.size)
        assertTrue(loaded.story.has(StoryFlags.INTRO_DONE))
        assertTrue(loaded.story.has(StoryFlags.MEDICINE_PUZZLE_COMPLETED))
        assertEquals("las líneas incompletas se ignoran", 1, loaded.dropped.all.size)
        assertEquals("water_glass", loaded.dropped.all[0].itemId)
        assertEquals("un número roto vale 0, no una excepción", 0f, loaded.dropped.all[0].x, 0.001f)
    }

    @Test
    fun captureDoesNotWipeProgress() {
        val saves = SaveManager(MemoryStore())
        val s = playedState()
        s.captureCount = 3
        saves.save(s)

        val loaded = GameState()
        assertTrue(saves.load(loaded))
        assertEquals(3, loaded.captureCount)
        assertEquals(3, loaded.diary.size)
        assertTrue(loaded.story.has(StoryFlags.MEDICINE_PUZZLE_COMPLETED))
        assertTrue(loaded.blackoutDone)
        assertEquals(2, loaded.dropped.all.size)
    }
}
