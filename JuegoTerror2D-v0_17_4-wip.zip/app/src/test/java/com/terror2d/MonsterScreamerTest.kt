package com.terror2d

import com.terror2d.audio.AudioDirector
import com.terror2d.audio.AudioEngine
import com.terror2d.audio.AudioPort
import com.terror2d.audio.Emotion
import com.terror2d.audio.MusicId
import com.terror2d.audio.OfflineAudioSink
import com.terror2d.audio.SfxId
import com.terror2d.audio.Surface
import com.terror2d.audio.VoiceId
import com.terror2d.audio.VoiceKind
import com.terror2d.core.WorldMode
import com.terror2d.creature.Creature
import com.terror2d.creature.CreatureBrain
import com.terror2d.creature.MouthAnimator
import com.terror2d.creature.ScreamerView
import com.terror2d.creature.Senses
import com.terror2d.creature.VisionConfig
import com.terror2d.events.EventType
import com.terror2d.events.GameEvent
import com.terror2d.pixel.CreatureSprite
import com.terror2d.pixel.CreatureSpriteData
import com.terror2d.pixel.ScreamerArtData
import com.terror2d.pixel.ScreamerCodec
import com.terror2d.render.CreatureRenderer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/**
 * Pruebas v0.17 del frente MONSTRUO + SCREAMER + AUDIO.
 *
 * Silueta nueva (generada por tools/sprite_gen/emit_creature_v017.py desde creature.py, procedural):
 * cuerpo 160x176 a la misma densidad que el niño (0,5), cabeza 78x72 (antes 62x69 / 71x70 en los datos de
 * referencia), ojo trasero 4-5 px MÁS ALTO que el delantero y de distinto tamaño según la variante, brazos
 * traseros con 143 px de caída en reposo (antes 95). Si el generador cambia, estos números cambian: son el
 * contrato de la silueta, no casualidad.
 */
class MonsterScreamerTest {

    // ------------------------------------------------------------------ silueta del monstruo

    @Test fun creatureSpriteKeepsTheChildPixelDensity() {
        assertEquals(160, CreatureSpriteData.BODY_W)
        assertEquals(176, CreatureSpriteData.BODY_H)
        assertEquals(0.5f, CreatureSprite.SCALE, 0f)
        assertEquals(80, CreatureSpriteData.ANCHOR_X)
        assertEquals("29 colores (transparente + 28)", 29, CreatureSpriteData.PALETTE.size)
        assertEquals(21, CreatureSpriteData.BODY_POSES.size)
        assertEquals(21, CreatureSpriteData.BODY_DATA.size)
        assertEquals(30, CreatureSpriteData.ARM_LEAD.size)
        assertEquals(30, CreatureSpriteData.ARM_TRAIL.size)
        assertEquals(2, CreatureSpriteData.HEAD_DATA.size)
        assertEquals(10, CreatureSpriteData.EYE_DATA_L.size)
        assertEquals(10, CreatureSpriteData.EYE_DATA_R.size)
        assertEquals(8, CreatureSpriteData.MAIN_MOUTH_DATA.size)
        assertEquals(28, CreatureSpriteData.SEC_DATA.size)
        assertEquals("7 bocas del vientre, ninguna en la cabeza", 7, CreatureSprite.SECONDARY_MOUTHS)
    }

    @Test fun creatureHeadIsBiggerAndCrooked() {
        // cabeza 78x72: casi la mitad del ancho del cuerpo (antes 62 px de ancho en frontal, 39% del cuerpo)
        assertEquals(78, CreatureSprite.headW(0))
        assertEquals(72, CreatureSprite.headH(0))
        assertEquals(78, CreatureSprite.headW(1))
        assertEquals(72, CreatureSprite.headH(1))
        assertTrue("la cabeza ocupa casi la mitad del cuerpo", CreatureSprite.headW(0) * 2 > CreatureSpriteData.BODY_W * 0.9f)
        // asimetría documentada: el ojo trasero (L) está 4-5 px MÁS ALTO (menor Y) que el delantero (R)
        val ec = CreatureSpriteData.EYE_CENTERS
        assertEquals("frontal: ojo L 4 px más alto", 4, ec[3] - ec[1])
        assertEquals("girada: ojo L 5 px más alto", 5, ec[7] - ec[5])
        // ... y de distinto TAMAÑO, y el grande cambia de lado al girar la cabeza
        assertEquals(25, CreatureSprite.eyeSizeL(0))
        assertEquals(21, CreatureSprite.eyeSizeR(0))
        assertEquals(19, CreatureSprite.eyeSizeL(1))
        assertEquals(23, CreatureSprite.eyeSizeR(1))
        // la cabeza sobresale por encima del cuerpo (ancla Y negativa en reposo): silueta más alta
        assertTrue("la cabeza asoma por encima del cuerpo", CreatureSpriteData.BODY_ANCHORS[0][1] < 0)
        assertEquals(94f, Creature.HEIGHT, 0f)
        assertEquals(52f, Creature.BODY_WIDTH, 0f)
    }

    @Test fun creatureArmsAreLongerAndReachTheFloor() {
        // índice 13 = balanceo 0° (colgando) + codo 0°: altura del recorte en reposo
        assertEquals(129, CreatureSpriteData.ARM_LEAD_INFO[13][1])
        assertEquals(143, CreatureSpriteData.ARM_TRAIL_INFO[13][1])
        assertTrue("el brazo trasero es más largo que el delantero", CreatureSpriteData.ARM_TRAIL_INFO[13][1] > CreatureSpriteData.ARM_LEAD_INFO[13][1])
        // caída real del brazo trasero en reposo: 143 px de recorte menos 9 px de hombro = 134 px; el suelo
        // está a 175-46 = 129 px del hombro: los dedos llegan 5 px por debajo, rozando/arrastrando por el suelo.
        val trailDrop = CreatureSpriteData.ARM_TRAIL_INFO[13][1] - CreatureSpriteData.ARM_TRAIL_INFO[13][3]
        assertTrue("los dedos rozan el suelo (caída $trailDrop px, suelo a 129 px del hombro)", trailDrop in 125..140)
    }

    @Test fun creatureSpriteDecodesWithoutHoles() {
        val body = CreatureSprite.bodies[0]
        assertEquals(CreatureSpriteData.BODY_W * CreatureSpriteData.BODY_H, body.size)
        assertTrue("el cuerpo IDLE tiene masa", body.count { it != 0 } > 8000)
        assertTrue(CreatureSprite.bodies[5].count { it != 0 } > 5000)
        assertTrue(CreatureSprite.bodies[13].count { it != 0 } > 5000)
        val head = CreatureSprite.heads[0]
        assertEquals(78 * 72, head.size)
        assertTrue(head.count { it != 0 } > 3000)
        assertTrue("el ojo tiene dibujo", CreatureSprite.eyesL[0].any { it != 0 })
        assertTrue("la boca del vientre tiene dibujo", CreatureSprite.secMouths[0].any { it != 0 })
        // la rótula del hombro es PIEL (índice 2 de la paleta procedural), no el negro del ojo (23 en la
        // paleta antigua de referencias): con el 23 el hombro salía negro.
        assertEquals(2, CreatureSprite.SHOULDER_SKIN)
        assertEquals(0xFF857D4D.toInt(), CreatureSpriteData.PALETTE[CreatureSprite.SHOULDER_SKIN])
        val c = CreatureSprite.SHOULDER_D / 2
        assertEquals(CreatureSprite.SHOULDER_SKIN, CreatureSprite.shoulderJoint[c * CreatureSprite.SHOULDER_D + c])
    }

    @Test fun creatureBreathHasIrregularPausesAndHeadTics() {
        val c = Creature(400f, "hall", 100f, 700f, seed = 3)
        val s = Senses(playerX = 5000f, playerSegmentId = "hall")
        var maxTic = 0f
        var minBreath = 1f
        var maxBreath = -1f
        var quietStretch = 0
        var quietBest = 0
        var t = 0f
        while (t < 60f) {
            c.update(1f / 60f, s, emptyList())
            maxTic = maxOf(maxTic, abs(c.headTicX()))
            minBreath = minOf(minBreath, c.breath())
            maxBreath = maxOf(maxBreath, c.breath())
            // una pausa rara: 0,4 s seguidos con la respiración casi parada (|x| < 0,2). Un seno perfecto no
            // puede: cerca de un cruce por cero solo aguanta ~0,24 s por debajo de 0,2.
            if (abs(c.breath()) < 0.2f) { quietStretch++; quietBest = maxOf(quietBest, quietStretch) } else quietStretch = 0
            t += 1f / 60f
        }
        assertTrue("la respiración no es un seno: recorre más de 1 px", maxBreath - minBreath > 1f)
        assertTrue("hay pausas raras (0,4 s casi sin respirar)", quietBest >= 24)
        assertTrue("hay tics de cabeza", maxTic > 1f)
        // determinista: dos criaturas con la misma semilla tican igual
        val a = Creature(400f, "hall", 100f, 700f, seed = 3)
        val b = Creature(400f, "hall", 100f, 700f, seed = 3)
        repeat(300) {
            a.update(1f / 60f, s, emptyList())
            b.update(1f / 60f, s, emptyList())
            assertEquals(a.headTicX(), b.headTicX(), 0f)
            assertEquals(a.breath(), b.breath(), 0f)
        }
    }

    @Test fun creatureDepthScaleChangesEffectiveScale() {
        val c = Creature(400f, "hall", 100f, 700f, seed = 3)
        val r = CreatureRenderer()
        assertEquals(0.5f, r.scaleFor(c), 0f)
        // mismo rango que Depth.depthScale (0,82 lejos .. 1,12 cerca): la criatura se ve distinta según el plano
        c.depthScale = 0.82f
        assertEquals(0.41f, r.scaleFor(c), 0.001f)
        c.depthScale = 1.12f
        assertEquals(0.56f, r.scaleFor(c), 0.001f)
        c.depthScale = 0.1f
        assertEquals("lejos tiene un mínimo", 0.41f, r.scaleFor(c), 0.001f)
        c.depthScale = 3f
        assertEquals("cerca tiene un máximo", 0.56f, r.scaleFor(c), 0.001f)
    }

    @Test fun creatureVisionIncludesTallerHead() {
        assertEquals(312f, VisionConfig().effectiveRange(1f, false), 0.001f)
        assertEquals(150f + 12f, VisionConfig().effectiveRange(0f, false), 0.001f)
        val b = CreatureBrain(400f, "hall", 100f, 700f, seed = 3)
        assertTrue("a 305 px con luz: la cabeza alta lo ve", b.canSee(Senses(playerX = 705f, playerSegmentId = "hall")))
        assertFalse("a 330 px ya no", b.canSee(Senses(playerX = 730f, playerSegmentId = "hall")))
    }

    @Test fun bellyMouthsOpenAtDifferentTimes() {
        val m = MouthAnimator(7, 5)
        for (p in m.params) assertTrue("ciclo entre 0,14 y 0,48", p.cycleSpeed in 0.14f..0.48f)
        assertTrue(m.params.map { it.phaseOffset }.toSet().size > 5)
        var maxOpen = 0
        var t = 0f
        while (t < 30f) { maxOpen = maxOf(maxOpen, m.openCount(t, 0.15f)); t += 0.05f }
        assertTrue("nunca todas las bocas a la vez", maxOpen < 7)
    }

    // ------------------------------------------------------------------ screamer (< 1 s)

    @Test fun screamerIsUnderOneSecondWithNoLongBuildUp() {
        assertTrue(ScreamerView.DURATION < 1f)
        assertEquals(0.92f, ScreamerView.DURATION, 0f)
        assertEquals(18, ScreamerView.FRAME_COUNT)
        assertEquals(ScreamerArtData.FRAME_COUNT, ScreamerView.FRAME_COUNT)
        val v = ScreamerView()
        v.begin()
        assertEquals(0, v.frame)
        assertTrue("el primer fotograma ya sale encima (zoom > 1,6)", v.zoom > 1.6f)
        assertFalse(v.cutToBlack)
        v.update(0.10f)
        assertEquals(2, v.frame)
        v.update(0.40f)
        assertEquals(9, v.frame)
        assertFalse(v.cutToBlack)
        v.update(0.39f)
        assertTrue("a los 0,89 s ya es negro", v.cutToBlack)
        assertFalse(v.done)
        v.update(0.05f)
        assertTrue(v.done)
    }

    @Test fun screamerCuesFireInOrderUnderOneSecond() {
        val v = ScreamerView()
        v.begin()
        val got = ArrayList<Pair<Int, Float>>()
        var t = 0f
        while (t < 1f) {
            v.update(1f / 60f)
            t += 1f / 60f
            val cue = v.consumeCue()
            if (cue >= 0) got.add(cue to t)
        }
        assertEquals(listOf(0, 1, 2, 3), got.map { it.first })
        assertEquals(0.08f, got[0].second, 0.03f)
        assertEquals(0.20f, got[1].second, 0.03f)
        assertEquals(0.46f, got[2].second, 0.03f)
        assertEquals(0.87f, got[3].second, 0.03f)
        assertTrue("todos los cues caen antes de 1 s", got.all { it.second < 1f })
        assertEquals(-1, v.consumeCue())
    }

    @Test fun screamerArtDataMatchesView() {
        assertEquals(640 * 360, ScreamerCodec.indices(0).size)
        assertEquals(640 * 360, ScreamerCodec.indices(17).size)
        assertTrue(ScreamerArtData.PALETTE.isNotEmpty())
    }

    // ------------------------------------------------------------------ sonido del screamer

    private fun engine(seed: Int = 7): AudioEngine = AudioEngine(OfflineAudioSink(), 44100, seed).also { it.enableOfflineMode() }

    /** Renderiza [seconds] segundos y devuelve las muestras. */
    private fun render(e: AudioEngine, seconds: Float): FloatArray {
        val blocks = (seconds * 44100f / AudioEngine.BLOCK).toInt() + 1
        val out = FloatArray(blocks * AudioEngine.BLOCK)
        val buf = FloatArray(AudioEngine.BLOCK)
        for (b in 0 until blocks) {
            e.renderBlock(buf, AudioEngine.BLOCK)
            System.arraycopy(buf, 0, out, b * AudioEngine.BLOCK, AudioEngine.BLOCK)
        }
        return out
    }

    private fun energy(a: FloatArray, fromS: Float, toS: Float): Float {
        val from = (fromS * 44100f).toInt().coerceIn(0, a.size)
        val to = (toS * 44100f).toInt().coerceIn(0, a.size)
        var s = 0.0
        for (i in from until to) s += a[i] * a[i]
        return (s / (to - from).coerceAtLeast(1)).toFloat()
    }

    private fun peak(a: FloatArray): Float {
        var p = 0f
        for (x in a) if (abs(x) > p) p = abs(x)
        return p
    }

    @Test fun screamPreIsInhaleThenSilence() {
        val e = engine()
        e.playSfx(SfxId.SCREAM_PRE, 1f, Surface.WOOD)
        val out = render(e, 0.7f)
        assertTrue("la inhalación suena", peak(out) > 0.01f)
        assertTrue("hay aire al principio", energy(out, 0f, 0.25f) > 0f)
        assertTrue("y después silencio raro (la cola es menos de la mitad)",
            energy(out, 0.30f, 0.60f) < energy(out, 0f, 0.25f) * 0.5f)
    }

    @Test fun screamLayersHitHardAndCutShort() {
        for (id in listOf(SfxId.SCREAM_IMPACT, SfxId.SCREAM_ROAR, SfxId.SCREAM_GRAB, SfxId.SCREAM_FINAL)) {
            val e = engine()
            e.playSfx(id, 1f, Surface.WOOD)
            val out = render(e, 1.5f)
            assertTrue("$id no se oye", peak(out) > 0.05f)
            assertTrue("$id tiene cuerpo al principio", energy(out, 0f, 0.5f) > 0f)
        }
        // el final ya no se deshace en llanto: a los 0,9 s casi no queda nada (antes había 5 sollozos hasta 1,6 s)
        val e = engine()
        e.playSfx(SfxId.SCREAM_FINAL, 1f, Surface.WOOD)
        val out = render(e, 1.5f)
        assertTrue("el grito final se corta", energy(out, 0.9f, 1.5f) < energy(out, 0f, 0.5f) * 0.25f)
    }

    @Test fun audioDirectorPlaysScreamPreOnCapture() {
        val log = RecordingAudio()
        val d = AudioDirector(log) { Surface.WOOD }
        d.onEvent(GameEvent(EventType.CREATURE_CAPTURE, "creature", "s"))
        assertTrue("falta SCREAM_PRE", log.calls.contains("sfx:SCREAM_PRE"))
        assertTrue("la música se corta", log.calls.contains("music:SILENCE"))
        assertTrue("el ambiente baja", log.calls.any { it.startsWith("duck:") })
        assertFalse("ya no suena el rugido largo de captura", log.calls.contains("sfx:CREATURE_CAPTURE"))
    }

    private class RecordingAudio : AudioPort {
        val calls = ArrayList<String>()
        override fun playVoice(voice: VoiceId, emotion: Emotion, intensity: Float, kind: VoiceKind, units: Int, seed: Int) {
            calls.add("voice:$voice:$kind")
        }

        override fun playSfx(sfx: SfxId, intensity: Float, surface: Surface) {
            calls.add("sfx:$sfx")
        }

        override fun playMusic(music: MusicId, fadeSeconds: Float) {
            calls.add("music:$music")
        }

        override fun setAmbience(ambience: com.terror2d.audio.AmbienceId, fadeSeconds: Float) {
            calls.add("amb:$ambience")
        }

        override fun setWorld(mode: WorldMode) {
            calls.add("world:$mode")
        }

        override fun duck(level: Float, seconds: Float) {
            calls.add("duck:$level")
        }

        override fun stopAll() {
            calls.add("stop")
        }
    }
}
