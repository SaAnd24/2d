package com.terror2d

import com.terror2d.core.GameState
import com.terror2d.scene.TestScene
import com.terror2d.util.SeededRandom
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineTest {

    @Test
    fun sameSeedProducesSameSequence() {
        val a = SeededRandom(42L)
        val b = SeededRandom(42L)
        for (i in 0 until 1000) assertEquals(a.nextLong(), b.nextLong())
    }

    @Test
    fun differentSeedsProduceDifferentSequences() {
        assertNotEquals(SeededRandom(1L).nextLong(), SeededRandom(2L).nextLong())
    }

    @Test
    fun floatsStayInRange() {
        val r = SeededRandom(7L)
        for (i in 0 until 1000) {
            val f = r.nextFloat()
            assertTrue(f >= 0f && f < 1f)
        }
    }

    @Test
    fun sameSeedProducesSameVisuals() {
        val a = TestScene(123L).also { it.load(GameState()) }
        val b = TestScene(123L).also { it.load(GameState()) }
        assertEquals(a.visualFingerprint(), b.visualFingerprint())
    }

    @Test
    fun differentSeedProducesDifferentVisuals() {
        val a = TestScene(123L).also { it.load(GameState()) }
        val b = TestScene(124L).also { it.load(GameState()) }
        assertNotEquals(a.visualFingerprint(), b.visualFingerprint())
    }

    @Test
    fun wallsBlockPlayer() {
        val scene = TestScene().also { it.load(GameState()) }
        val solids = ArrayList<com.terror2d.world.WorldObject>()
        solids.addAll(scene.definition.objects.filter { it.collidable })
        val p = scene.player
        for (i in 0 until 1200) p.move(1f / 60f, -1f, 0f, solids, scene.width, scene.height)
        assertTrue("jugador atravesó la pared izquierda: x=${p.x}", p.x >= 16f - 0.001f)
        for (i in 0 until 1200) p.move(1f / 60f, 0f, -1f, solids, scene.width, scene.height)
        assertTrue("jugador atravesó la pared superior: y=${p.y}", p.y >= 16f - 0.001f)
    }
}
