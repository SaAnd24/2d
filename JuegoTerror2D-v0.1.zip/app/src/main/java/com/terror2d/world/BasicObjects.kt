package com.terror2d.world

import com.terror2d.render.BaseRenderer
import com.terror2d.render.Palette
import com.terror2d.util.SeededRandom
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Pared sólida. */
class Wall(x: Float, y: Float, w: Float, h: Float) : WorldObject(x, y, w, h) {
    init {
        collidable = true
        fillColor = Palette.WALL_FILL
        hatchColor = Palette.WALL_HATCH
        lineColor = Palette.WALL_LINE
    }
}

/** Objeto sólido genérico (caja, mesa, pilar...). Solo para pruebas en v0.1. */
class Block(
    x: Float, y: Float, w: Float, h: Float,
    fill: Int, hatchTone: Int
) : WorldObject(x, y, w, h) {
    init {
        collidable = true
        fillColor = fill
        hatchColor = hatchTone
    }
}

/** Alfombra: decoración sin colisión, siempre bajo el jugador. */
class Rug(x: Float, y: Float, w: Float, h: Float) : WorldObject(x, y, w, h) {
    init {
        collidable = false
        layer = Layer.DECOR
        fillColor = Palette.RUG_FILL
        hatchColor = Palette.RUG_HATCH
        hatchSpacing = 2.5f
    }
}

/** Garabato en espiral: decoración infantil determinista (sin colisión). */
class Doodle(x: Float, y: Float, size: Float) : WorldObject(x, y, size, size) {
    init {
        collidable = false
        layer = Layer.DECOR
        lineColor = Palette.BLUE_HATCH
    }

    override fun prepareVisuals(rng: SeededRandom) {
        val segs = 36
        val arr = FloatArray(segs * 4)
        val cx = centerX
        val cy = centerY
        val maxR = min(width, height) / 2f
        var px = cx
        var py = cy
        for (i in 0 until segs) {
            val t = (i + 1) / segs.toFloat()
            val ang = t * 3.5f * 2f * PI.toFloat()
            val r = maxR * t + rng.nextSigned() * 0.6f
            val nx = cx + cos(ang) * r
            val ny = cy + sin(ang) * r
            arr[i * 4] = px
            arr[i * 4 + 1] = py
            arr[i * 4 + 2] = nx
            arr[i * 4 + 3] = ny
            px = nx
            py = ny
        }
        hatch = arr
        outline = EMPTY
    }

    override fun render(r: BaseRenderer) {
        r.drawStrokes(hatch, lineColor, 1.3f)
    }
}
