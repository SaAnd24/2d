package com.terror2d.world

/** Colisiones rectangulares (AABB), ejes separados. Sin allocations. */
object CollisionSystem {

    fun overlaps(a: WorldObject, b: WorldObject): Boolean =
        a.x < b.right && a.right > b.x && a.y < b.bottom && a.bottom > b.y

    /**
     * Mueve [mover] (dx, dy) y lo resuelve contra los límites de la escena y los sólidos.
     * Resuelve primero X y luego Y para permitir deslizarse por las paredes.
     */
    fun moveAndCollide(
        mover: WorldObject,
        dx: Float,
        dy: Float,
        solids: List<WorldObject>,
        boundsWidth: Float,
        boundsHeight: Float
    ) {
        // Eje X
        mover.x += dx
        if (mover.x < 0f) mover.x = 0f
        if (mover.x + mover.width > boundsWidth) mover.x = boundsWidth - mover.width
        for (i in 0 until solids.size) {
            val s = solids[i]
            if (s === mover || !s.collidable) continue
            if (overlaps(mover, s)) {
                if (dx > 0f) mover.x = s.x - mover.width
                else if (dx < 0f) mover.x = s.right
            }
        }

        // Eje Y
        mover.y += dy
        if (mover.y < 0f) mover.y = 0f
        if (mover.y + mover.height > boundsHeight) mover.y = boundsHeight - mover.height
        for (i in 0 until solids.size) {
            val s = solids[i]
            if (s === mover || !s.collidable) continue
            if (overlaps(mover, s)) {
                if (dy > 0f) mover.y = s.y - mover.height
                else if (dy < 0f) mover.y = s.bottom
            }
        }
    }
}
