package com.terror2d.world

import com.terror2d.render.BaseRenderer
import kotlin.math.sqrt

/**
 * Jugador placeholder. Su caja de colisión son los PIES (8x6); el dibujo se
 * eleva sobre ella (vista cenital con perspectiva ligera).
 */
class Player(x: Float, y: Float) : WorldObject(x, y, WIDTH, HEIGHT) {

    var facingX: Float = 0f
    var facingY: Float = 1f
    var moving: Boolean = false
    var animTime: Float = 0f

    /** Futuro: correr, ralentizar, etc. */
    var speedMultiplier: Float = 1f

    init {
        collidable = false // el jugador no está en la lista de sólidos
    }

    /** Mueve según una dirección (-1..1 por eje) resolviendo colisiones. */
    fun move(
        dt: Float,
        dirX: Float,
        dirY: Float,
        solids: List<WorldObject>,
        boundsWidth: Float,
        boundsHeight: Float
    ) {
        var dx = dirX
        var dy = dirY
        val len = sqrt(dx * dx + dy * dy)
        if (len > 1f) {
            dx /= len
            dy /= len
        }
        moving = len > 0.01f
        if (moving) {
            facingX = dx / len
            facingY = dy / len
            animTime += dt
        } else {
            animTime = 0f
        }
        val step = SPEED * speedMultiplier * dt
        CollisionSystem.moveAndCollide(this, dx * step, dy * step, solids, boundsWidth, boundsHeight)
    }

    override fun prepareVisuals(rng: com.terror2d.util.SeededRandom) {
        // El personaje se dibuja proceduralmente; no necesita trazos precalculados en v0.1.
    }

    override fun render(r: BaseRenderer) {
        r.drawPlayer(this)
    }

    companion object {
        const val WIDTH = 8f
        const val HEIGHT = 6f
        /** Velocidad en píxeles lógicos por segundo. */
        const val SPEED = 56f
    }
}
