package com.terror2d.world

import com.terror2d.render.BaseRenderer
import com.terror2d.util.SeededRandom

/** Capas de dibujado. FLOOR/DECOR van siempre debajo; OBJECT se ordena por profundidad con el jugador. */
object Layer {
    const val FLOOR = 0
    const val DECOR = 1
    const val OBJECT = 2
}

/**
 * Base de todo lo que existe en el mundo (en coordenadas del mundo, no de pantalla).
 * Futuro: puertas, muebles, objetos interactivos, NPCs, enemigos, decoración...
 */
open class WorldObject(
    var x: Float,
    var y: Float,
    var width: Float,
    var height: Float
) {
    var visible: Boolean = true
    var collidable: Boolean = false
    var layer: Int = Layer.OBJECT

    // Aspecto (crayón)
    var fillColor: Int = 0xB0AAAAAA.toInt()
    var hatchColor: Int = 0xCC777777.toInt()
    var lineColor: Int = 0xFF3A2A20.toInt()
    var hatchSpacing: Float = 3f

    /** Imperfecciones precalculadas (se rellenan en prepareVisuals con la semilla). */
    var outline: FloatArray = EMPTY
    var hatch: FloatArray = EMPTY

    val right: Float get() = x + width
    val bottom: Float get() = y + height
    val centerX: Float get() = x + width * 0.5f
    val centerY: Float get() = y + height * 0.5f

    /** Genera el aspecto dibujado a mano de forma determinista. */
    open fun prepareVisuals(rng: SeededRandom) {
        outline = SketchBuilder.buildOutline(x, y, width, height, rng)
        hatch = SketchBuilder.buildHatch(x, y, width, height, hatchSpacing, rng)
    }

    open fun update(dt: Float) {}

    open fun render(r: BaseRenderer) {
        r.drawSketchBox(this)
    }

    companion object {
        val EMPTY = FloatArray(0)
    }
}
