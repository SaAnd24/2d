package com.terror2d.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.terror2d.core.GameConfig
import com.terror2d.input.InputController
import com.terror2d.world.Player
import com.terror2d.world.WorldObject
import kotlin.math.round

/**
 * Renderizador base (etapa crayón). Todo el dibujo del mundo pasa por aquí.
 * Futuro: CrayonRenderer, GraphiteRenderer, ShadowRenderer, LightingRenderer,
 * DistortionRenderer, ScratchRenderer pueden heredar o componerse sobre esta clase.
 * No crea objetos en el bucle de dibujo (Paint/Path/RectF reutilizados).
 */
open class BaseRenderer {

    protected lateinit var canvas: Canvas
    protected var corruption: Float = 0f

    protected val paint = Paint().apply {
        isAntiAlias = false
        isFilterBitmap = false
        isDither = false
        strokeCap = Paint.Cap.SQUARE
        strokeJoin = Paint.Join.MITER
    }

    private val textPaint = Paint().apply {
        isAntiAlias = true
        textSize = 7f
        typeface = Typeface.MONOSPACE
        color = Palette.OUTLINE
    }

    private val path = Path()
    private val oval = RectF()

    open fun beginFrame(canvas: Canvas, visualCorruption: Float) {
        this.canvas = canvas
        this.corruption = visualCorruption
    }

    /**
     * Gancho de corrupción visual: 0.0 devuelve el color intacto.
     * Futuro: más saturación perdida, tintes, grafito...
     */
    protected open fun tint(c: Int): Int {
        val k = corruption
        if (k <= 0.001f) return c
        val a = (c ushr 24) and 0xFF
        val r = (c shr 16) and 0xFF
        val g = (c shr 8) and 0xFF
        val b = c and 0xFF
        val gray = r * 0.30f + g * 0.59f + b * 0.11f
        val t = k * 0.85f
        val nr = (r + (gray - r) * t).toInt()
        val ng = (g + (gray - g) * t).toInt()
        val nb = (b + (gray - b) * t).toInt()
        return (a shl 24) or (nr shl 16) or (ng shl 8) or nb
    }

    /** Fondo de papel (zona lógica completa, coordenadas de pantalla lógica). */
    open fun drawBackground() {
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.PAPER)
        canvas.drawRect(0f, 0f, GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat(), paint)
    }

    /** Suelo de la escena (coordenadas del mundo). */
    open fun drawFloor(width: Float, height: Float, strokes: FloatArray, speckles: FloatArray) {
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.FLOOR)
        canvas.drawRect(0f, 0f, width, height, paint)
        drawStrokes(strokes, Palette.FLOOR_STROKE, 1.5f)
        if (speckles.isNotEmpty()) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1f
            paint.color = tint(Palette.SPECKLE)
            canvas.drawPoints(speckles, paint)
        }
    }

    /** Líneas sueltas (pares x1,y1,x2,y2). */
    open fun drawStrokes(lines: FloatArray, color: Int, strokeWidth: Float) {
        if (lines.isEmpty()) return
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = strokeWidth
        paint.color = tint(color)
        canvas.drawLines(lines, paint)
    }

    /** Caja con relleno de crayón, trazos de sombreado y contorno doble imperfecto. */
    open fun drawSketchBox(o: WorldObject) {
        paint.style = Paint.Style.FILL
        paint.color = tint(o.fillColor)
        canvas.drawRect(o.x, o.y, o.right, o.bottom, paint)
        drawStrokes(o.hatch, o.hatchColor, 1.4f)
        drawStrokes(o.outline, o.lineColor, 1f)
    }

    /** Personaje placeholder con aire de dibujo infantil. */
    open fun drawPlayer(p: Player) {
        val bx = round(p.x + p.width * 0.5f)
        val by = round(p.y + p.height)
        val walkOn = p.moving && ((p.animTime * 8f).toInt() and 1) == 0
        val bob = if (walkOn) -1f else 0f

        // Sombra
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.SHADOW)
        oval.set(bx - 5f, by - 2f, bx + 5f, by + 1.5f)
        canvas.drawOval(oval, paint)

        // Piernas
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.4f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawLine(bx - 1.5f, by - 4f, bx - 1.5f, by - (if (walkOn) 1f else 0f), paint)
        canvas.drawLine(bx + 1.5f, by - 4f, bx + 1.5f, by - (if (walkOn) 0f else 1f), paint)

        // Vestido
        path.reset()
        path.moveTo(bx - 3f, by - 11f + bob)
        path.lineTo(bx + 3f, by - 11f + bob)
        path.lineTo(bx + 5.5f, by - 4f)
        path.lineTo(bx - 5.5f, by - 4f)
        path.close()
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.PLAYER_DRESS)
        canvas.drawPath(path, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawPath(path, paint)

        // Brazos
        val sw = if (walkOn) 1.5f else 0f
        canvas.drawLine(bx - 3f, by - 10f + bob, bx - 5.5f, by - 6.5f + sw + bob, paint)
        canvas.drawLine(bx + 3f, by - 10f + bob, bx + 5.5f, by - 6.5f - sw + bob, paint)

        // Cabeza
        val hy = by - 15f + bob
        paint.style = Paint.Style.FILL
        paint.color = tint(Palette.PLAYER_SKIN)
        canvas.drawCircle(bx, hy, 4.5f, paint)

        // Pelo (de espaldas cubre toda la cabeza)
        paint.color = tint(Palette.PLAYER_HAIR)
        if (p.facingY < -0.5f) {
            canvas.drawCircle(bx, hy, 4.3f, paint)
        } else {
            oval.set(bx - 4.5f, hy - 4.5f, bx + 4.5f, hy + 4.5f)
            canvas.drawArc(oval, 180f, 180f, true, paint)
        }

        // Contorno doble (trazo duplicado sutil)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = tint(Palette.OUTLINE)
        canvas.drawCircle(bx, hy, 4.5f, paint)
        canvas.drawCircle(bx + 0.5f, hy + 0.4f, 4.3f, paint)

        // Ojos
        if (p.facingY >= -0.5f) {
            val ex = p.facingX * 1.2f
            paint.style = Paint.Style.FILL
            canvas.drawRect(bx - 2.2f + ex, hy, bx - 1.2f + ex, hy + 1.6f, paint)
            canvas.drawRect(bx + 1.2f + ex, hy, bx + 2.2f + ex, hy + 1.6f, paint)
        }
    }

    /** HUD en coordenadas lógicas de pantalla: joystick virtual. */
    open fun drawHud(input: InputController) {
        val active = input.joystickActive
        val bx = if (active) input.joyBaseX else InputController.DEFAULT_BASE_X
        val by = if (active) input.joyBaseY else InputController.DEFAULT_BASE_Y
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f
        paint.color = if (active) 0x99402A1E.toInt() else 0x33402A1E
        canvas.drawCircle(bx, by, InputController.JOY_RADIUS, paint)
        if (active) {
            paint.style = Paint.Style.FILL
            paint.color = 0xAA402A1E.toInt()
            canvas.drawCircle(input.joyKnobX, input.joyKnobY, InputController.JOY_KNOB_RADIUS, paint)
        }
    }

    open fun drawDebug(text: CharSequence) {
        canvas.drawText(text, 0, text.length, 3f, 9f, textPaint)
    }
}
