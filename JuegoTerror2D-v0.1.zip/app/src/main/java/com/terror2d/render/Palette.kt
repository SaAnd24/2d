package com.terror2d.render

/** Paleta inicial (etapa crayón). Valores ARGB. Futuras etapas aportarán paletas de grafito. */
object Palette {
    const val PAPER = 0xFFF4ECD8.toInt()
    const val FLOOR = 0xFFF3E0A8.toInt()
    const val FLOOR_STROKE = 0x66E0A84A.toInt()
    const val SPECKLE = 0x44806040.toInt()
    const val OUTLINE = 0xFF3A2A20.toInt()

    const val WALL_FILL = 0xB07B5FC7.toInt()
    const val WALL_HATCH = 0xCC5B3FA8.toInt()
    const val WALL_LINE = 0xFF2B2140.toInt()

    const val CRATE_FILL = 0xB0E8944A.toInt()
    const val CRATE_HATCH = 0xCCC46A1F.toInt()

    const val BLUE_FILL = 0xB05AA6E8.toInt()
    const val BLUE_HATCH = 0xCC2F7BC4.toInt()

    const val GREEN_FILL = 0xB07CC96B.toInt()
    const val GREEN_HATCH = 0xCC4F9A3E.toInt()

    const val RUG_FILL = 0x80E8604C.toInt()
    const val RUG_HATCH = 0xAAC93B2E.toInt()

    const val PLAYER_DRESS = 0xFFE8604C.toInt()
    const val PLAYER_SKIN = 0xFFFFD9B3.toInt()
    const val PLAYER_HAIR = 0xFF6B4226.toInt()
    const val SHADOW = 0x33000000

}
