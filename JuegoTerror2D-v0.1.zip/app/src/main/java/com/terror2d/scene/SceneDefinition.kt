package com.terror2d.scene

import com.terror2d.world.WorldObject

/** Punto de aparición del jugador (posición de los PIES, en coordenadas del mundo). */
class SpawnPoint(val x: Float, val y: Float)

/**
 * Descripción de una escena. Futuras escenas (casa, calle, parque...) solo
 * necesitan crear una definición, sin tocar el motor.
 */
class SceneDefinition(
    val id: String,
    val width: Float,
    val height: Float,
    val seed: Long,
    val objects: List<WorldObject>,
    val spawnPoint: SpawnPoint
)
