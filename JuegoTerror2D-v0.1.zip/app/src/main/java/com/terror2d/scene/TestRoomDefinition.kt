package com.terror2d.scene

import com.terror2d.render.Palette
import com.terror2d.world.Block
import com.terror2d.world.Doodle
import com.terror2d.world.Rug
import com.terror2d.world.Wall
import com.terror2d.world.WorldObject

/** Habitación técnica de pruebas del motor (416 x 240, mayor que la pantalla 320 x 180). */
object TestRoomDefinition {
    const val ID = "test_room"
    const val DEFAULT_SEED = 20260101L

    const val WIDTH = 416f
    const val HEIGHT = 240f
    private const val T = 16f // grosor de pared

    /** Crea objetos NUEVOS en cada llamada (cada carga de escena parte limpia). */
    fun create(seed: Long = DEFAULT_SEED): SceneDefinition {
        val objects = ArrayList<WorldObject>()

        // Decoración de suelo
        objects.add(Rug(130f, 96f, 120f, 84f))
        objects.add(Doodle(40f, 168f, 40f))

        // Cuatro paredes
        objects.add(Wall(0f, 0f, WIDTH, T))
        objects.add(Wall(0f, HEIGHT - T, WIDTH, T))
        objects.add(Wall(0f, T, T, HEIGHT - 2 * T))
        objects.add(Wall(WIDTH - T, T, T, HEIGHT - 2 * T))

        // Objetos sólidos de prueba
        objects.add(Block(60f, 80f, 24f, 20f, Palette.CRATE_FILL, Palette.CRATE_HATCH))
        objects.add(Block(165f, 124f, 44f, 24f, Palette.GREEN_FILL, Palette.GREEN_HATCH))
        objects.add(Block(320f, 56f, 20f, 36f, Palette.BLUE_FILL, Palette.BLUE_HATCH))
        objects.add(Block(300f, 160f, 32f, 24f, Palette.CRATE_FILL, Palette.CRATE_HATCH))
        objects.add(Block(100f, 190f, 16f, 16f, Palette.BLUE_FILL, Palette.BLUE_HATCH))

        return SceneDefinition(
            id = ID,
            width = WIDTH,
            height = HEIGHT,
            seed = seed,
            objects = objects,
            spawnPoint = SpawnPoint(200f, 70f)
        )
    }
}
