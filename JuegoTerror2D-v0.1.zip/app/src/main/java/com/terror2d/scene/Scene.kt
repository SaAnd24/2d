package com.terror2d.scene

import com.terror2d.core.Camera
import com.terror2d.core.GameConfig
import com.terror2d.core.GameState
import com.terror2d.input.InputController
import com.terror2d.render.BaseRenderer
import com.terror2d.util.SeededRandom
import com.terror2d.world.Layer
import com.terror2d.world.Player
import com.terror2d.world.SketchBuilder
import com.terror2d.world.WorldObject

/**
 * Escena base: contiene objetos, jugador, cámara y colisiones.
 * Las escenas concretas (TestScene, y en el futuro Casa, Calle...) heredan de aquí.
 */
abstract class Scene(val definition: SceneDefinition) {

    val id: String get() = definition.id
    val width: Float get() = definition.width
    val height: Float get() = definition.height

    val camera = Camera(GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat())
    lateinit var player: Player
        private set

    private val objects = ArrayList<WorldObject>()
    private val solids = ArrayList<WorldObject>()
    private val groundObjects = ArrayList<WorldObject>() // FLOOR / DECOR
    private val sortedObjects = ArrayList<WorldObject>() // OBJECT, ordenados por "bottom"

    private var floorStrokes: FloatArray = WorldObject.EMPTY
    private var speckles: FloatArray = WorldObject.EMPTY

    fun load(state: GameState) {
        objects.clear()
        solids.clear()
        groundObjects.clear()
        sortedObjects.clear()
        objects.addAll(definition.objects)

        // Imperfecciones visuales deterministas. La semilla de cada objeto depende de su
        // índice y de la semilla de la escena (no del orden de ejecución).
        val seed = definition.seed
        for (i in 0 until objects.size) {
            objects[i].prepareVisuals(SeededRandom(SeededRandom.derive(seed, i + 1)))
        }
        val floorRng = SeededRandom(SeededRandom.derive(seed, FLOOR_SALT))
        floorStrokes = SketchBuilder.buildHatch(0f, 0f, width, height, 6f, floorRng)
        speckles = SketchBuilder.buildSpeckles(width, height, (width * height / 450f).toInt(), floorRng)

        for (i in 0 until objects.size) {
            val o = objects[i]
            if (o.collidable) solids.add(o)
            if (o.layer < Layer.OBJECT) groundObjects.add(o) else sortedObjects.add(o)
        }
        sortedObjects.sortBy { it.bottom }

        val sp = definition.spawnPoint
        player = Player(sp.x - Player.WIDTH / 2f, sp.y - Player.HEIGHT)
        camera.snapTo(player.centerX, player.bottom - CAMERA_FOCUS_OFFSET, width, height)

        state.currentSceneId = id
        state.playerX = player.x
        state.playerY = player.y
        onLoad(state)
    }

    open fun onLoad(state: GameState) {}

    open fun unload(state: GameState) {}

    /** Orden: jugador -> objetos -> cámara. */
    open fun update(dt: Float, input: InputController, state: GameState) {
        player.move(dt, input.moveX, input.moveY, solids, width, height)
        for (i in 0 until objects.size) objects[i].update(dt)
        camera.follow(player.centerX, player.bottom - CAMERA_FOCUS_OFFSET, width, height, dt)
        state.playerX = player.x
        state.playerY = player.y
    }

    /** Dibuja en coordenadas del mundo (la transformación de cámara ya está aplicada). */
    open fun render(r: BaseRenderer) {
        r.drawFloor(width, height, floorStrokes, speckles)

        for (i in 0 until groundObjects.size) {
            val o = groundObjects[i]
            if (o.visible && camera.isVisible(o)) o.render(r)
        }

        // Profundidad: lo que queda "detrás" del jugador, el jugador, y lo que queda delante.
        val playerBottom = player.bottom
        var i = 0
        val n = sortedObjects.size
        while (i < n && sortedObjects[i].bottom <= playerBottom) {
            val o = sortedObjects[i]
            if (o.visible && camera.isVisible(o)) o.render(r)
            i++
        }
        player.render(r)
        while (i < n) {
            val o = sortedObjects[i]
            if (o.visible && camera.isVisible(o)) o.render(r)
            i++
        }
    }

    /** Huella de todo el aspecto generado: misma semilla => mismo valor (usada en tests). */
    fun visualFingerprint(): Long {
        var h = 1125899906842597L
        h = hashArray(h, floorStrokes)
        h = hashArray(h, speckles)
        for (i in 0 until objects.size) {
            h = hashArray(h, objects[i].outline)
            h = hashArray(h, objects[i].hatch)
        }
        return h
    }

    private fun hashArray(seed: Long, a: FloatArray): Long {
        var h = seed
        for (i in a.indices) h = 31L * h + a[i].toRawBits().toLong()
        return h
    }

    companion object {
        private const val FLOOR_SALT = 0x7F10
        private const val CAMERA_FOCUS_OFFSET = 8f
    }
}
