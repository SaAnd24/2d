package com.terror2d.scene

/** Escena técnica para comprobar que el motor funciona. */
class TestScene(seed: Long = TestRoomDefinition.DEFAULT_SEED) : Scene(TestRoomDefinition.create(seed))
