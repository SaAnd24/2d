package com.terror2d.input

import android.view.KeyEvent
import android.view.MotionEvent
import com.terror2d.core.GameConfig
import com.terror2d.core.Viewport
import kotlin.math.sqrt

/** Acciones previstas para futuras versiones (en v0.1 solo hay movimiento). */
enum class InputAction { INTERACT, RUN, HIDE, EXAMINE, CONFIRM, CANCEL }

/**
 * Traduce eventos táctiles/teclado a un estado de entrada abstracto.
 * La lógica del juego solo lee moveX/moveY y las acciones; nunca MotionEvent.
 * Joystick virtual flotante en la mitad izquierda de la pantalla (coordenadas lógicas).
 */
class InputController {

    /** Dirección de movimiento normalizada, cada eje en [-1, 1]. */
    @Volatile var moveX: Float = 0f
        private set
    @Volatile var moveY: Float = 0f
        private set

    // Estado del joystick para dibujar el HUD
    @Volatile var joystickActive: Boolean = false
        private set
    @Volatile var joyBaseX: Float = DEFAULT_BASE_X
        private set
    @Volatile var joyBaseY: Float = DEFAULT_BASE_Y
        private set
    @Volatile var joyKnobX: Float = DEFAULT_BASE_X
        private set
    @Volatile var joyKnobY: Float = DEFAULT_BASE_Y
        private set

    private val actionDown = BooleanArray(InputAction.values().size)
    private val actionPressed = BooleanArray(InputAction.values().size)

    private var joyPointerId = -1
    private var joyX = 0f
    private var joyY = 0f
    private var keyLeft = false
    private var keyRight = false
    private var keyUp = false
    private var keyDown = false

    fun isDown(action: InputAction): Boolean = actionDown[action.ordinal]

    /** true durante el primer update tras pulsar. */
    fun wasPressed(action: InputAction): Boolean = actionPressed[action.ordinal]

    fun setAction(action: InputAction, down: Boolean) {
        val i = action.ordinal
        if (down && !actionDown[i]) actionPressed[i] = true
        actionDown[i] = down
    }

    /** Se llama al final de cada update para limpiar las pulsaciones puntuales. */
    fun endFrame() {
        for (i in actionPressed.indices) actionPressed[i] = false
    }

    fun onTouchEvent(e: MotionEvent, viewport: Viewport): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                val lx = viewport.toLogicalX(e.getX(i))
                val ly = viewport.toLogicalY(e.getY(i))
                if (joyPointerId == -1 && lx < GameConfig.LOGICAL_WIDTH * JOY_ZONE) {
                    startJoystick(e.getPointerId(i), lx, ly)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (joyPointerId != -1) {
                    val idx = e.findPointerIndex(joyPointerId)
                    if (idx >= 0) {
                        updateJoystick(viewport.toLogicalX(e.getX(idx)), viewport.toLogicalY(e.getY(idx)))
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                if (e.getPointerId(e.actionIndex) == joyPointerId) stopJoystick()
            }
            MotionEvent.ACTION_CANCEL -> stopJoystick()
        }
        return true
    }

    /** Teclado (útil en emulador / mando): flechas o WASD, ESPACIO = interactuar. */
    fun onKey(keyCode: Int, down: Boolean): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_A -> keyLeft = down
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_D -> keyRight = down
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_W -> keyUp = down
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_S -> keyDown = down
            KeyEvent.KEYCODE_SPACE -> setAction(InputAction.INTERACT, down)
            else -> return false
        }
        publish()
        return true
    }

    private fun startJoystick(pointerId: Int, lx: Float, ly: Float) {
        joyPointerId = pointerId
        val margin = JOY_RADIUS + 4f
        joyBaseX = lx.coerceIn(margin, GameConfig.LOGICAL_WIDTH * JOY_ZONE)
        joyBaseY = ly.coerceIn(margin, GameConfig.LOGICAL_HEIGHT - margin)
        joyKnobX = joyBaseX
        joyKnobY = joyBaseY
        joyX = 0f
        joyY = 0f
        joystickActive = true
        publish()
    }

    private fun updateJoystick(lx: Float, ly: Float) {
        val dx = lx - joyBaseX
        val dy = ly - joyBaseY
        val dist = sqrt(dx * dx + dy * dy)
        if (dist < 0.0001f) {
            joyX = 0f
            joyY = 0f
            joyKnobX = joyBaseX
            joyKnobY = joyBaseY
        } else {
            val clamped = if (dist > JOY_RADIUS) JOY_RADIUS else dist
            joyKnobX = joyBaseX + dx / dist * clamped
            joyKnobY = joyBaseY + dy / dist * clamped
            val m = clamped / JOY_RADIUS
            val strength = if (m < DEAD_ZONE) 0f else (m - DEAD_ZONE) / (1f - DEAD_ZONE)
            joyX = dx / dist * strength
            joyY = dy / dist * strength
        }
        publish()
    }

    private fun stopJoystick() {
        joyPointerId = -1
        joystickActive = false
        joyX = 0f
        joyY = 0f
        publish()
    }

    private fun publish() {
        var kx = 0f
        var ky = 0f
        if (keyLeft) kx -= 1f
        if (keyRight) kx += 1f
        if (keyUp) ky -= 1f
        if (keyDown) ky += 1f
        moveX = (joyX + kx).coerceIn(-1f, 1f)
        moveY = (joyY + ky).coerceIn(-1f, 1f)
    }

    companion object {
        const val JOY_RADIUS = 26f
        const val JOY_KNOB_RADIUS = 10f
        const val JOY_ZONE = 0.5f
        const val DEAD_ZONE = 0.18f
        const val DEFAULT_BASE_X = 46f
        const val DEFAULT_BASE_Y = 134f
    }
}
