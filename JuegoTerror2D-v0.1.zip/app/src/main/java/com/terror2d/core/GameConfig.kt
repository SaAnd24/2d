package com.terror2d.core

/** Constantes globales del motor. */
object GameConfig {
    /** Resolución lógica interna (16:9). */
    const val LOGICAL_WIDTH = 320
    const val LOGICAL_HEIGHT = 180

    const val TARGET_FPS = 60

    /** Paso fijo de la simulación (segundos). */
    const val FIXED_STEP = 1f / 60f

    /** Máximo delta aceptado por frame (evita saltos tras pausas). */
    const val MAX_FRAME_TIME = 0.1f

    /** Máximo de pasos de simulación por frame. */
    const val MAX_STEPS_PER_FRAME = 5

    /** true = escala entera (pixel perfect, con más barras negras). */
    const val INTEGER_SCALING = false

    /** Muestra FPS y datos técnicos en pantalla (v0.1: activo para verificar el motor). */
    const val DEBUG_OVERLAY = true
}
