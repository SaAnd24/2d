package com.terror2d.core

import com.terror2d.world.WorldObject
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Cámara 2D: Mundo -> Cámara -> Pantalla (lógica).
 * Sigue un objetivo con zona muerta y suavizado, y respeta los límites de la escena.
 */
class Camera(val viewWidth: Float, val viewHeight: Float) {
    /** Esquina superior izquierda de la cámara en coordenadas del mundo. */
    var x: Float = 0f
        private set
    var y: Float = 0f
        private set

    var deadZoneHalfWidth: Float = 20f
    var deadZoneHalfHeight: Float = 14f
    var smoothing: Float = 10f

    /** Posición redondeada a píxel lógico (evita temblor en las líneas). */
    val snappedX: Float get() = x.roundToInt().toFloat()
    val snappedY: Float get() = y.roundToInt().toFloat()

    fun worldToScreenX(worldX: Float): Float = worldX - snappedX
    fun worldToScreenY(worldY: Float): Float = worldY - snappedY
    fun screenToWorldX(screenX: Float): Float = screenX + snappedX
    fun screenToWorldY(screenY: Float): Float = screenY + snappedY

    /** Coloca la cámara de golpe sobre el objetivo. */
    fun snapTo(targetX: Float, targetY: Float, sceneWidth: Float, sceneHeight: Float) {
        x = clampAxis(targetX - viewWidth / 2f, viewWidth, sceneWidth)
        y = clampAxis(targetY - viewHeight / 2f, viewHeight, sceneHeight)
    }

    fun follow(targetX: Float, targetY: Float, sceneWidth: Float, sceneHeight: Float, dt: Float) {
        val cx = x + viewWidth / 2f
        val cy = y + viewHeight / 2f
        var desiredX = x
        var desiredY = y
        if (targetX > cx + deadZoneHalfWidth) desiredX += targetX - (cx + deadZoneHalfWidth)
        else if (targetX < cx - deadZoneHalfWidth) desiredX += targetX - (cx - deadZoneHalfWidth)
        if (targetY > cy + deadZoneHalfHeight) desiredY += targetY - (cy + deadZoneHalfHeight)
        else if (targetY < cy - deadZoneHalfHeight) desiredY += targetY - (cy - deadZoneHalfHeight)

        val t = min(1f, smoothing * dt)
        x = clampAxis(x + (desiredX - x) * t, viewWidth, sceneWidth)
        y = clampAxis(y + (desiredY - y) * t, viewHeight, sceneHeight)
    }

    fun isVisible(o: WorldObject, margin: Float = 8f): Boolean =
        o.right > x - margin && o.x < x + viewWidth + margin &&
            o.bottom > y - margin && o.y < y + viewHeight + margin

    private fun clampAxis(value: Float, view: Float, scene: Float): Float {
        if (scene <= view) return (scene - view) / 2f // escena más pequeña: centrada
        return value.coerceIn(0f, scene - view)
    }
}
