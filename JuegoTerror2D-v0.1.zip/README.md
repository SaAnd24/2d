# Juego de Terror 2D — v0.1 (Fundación del motor)

## Proyecto
Juego de terror psicológico 2D para Android, con estética de dibujo infantil sobre papel que irá
degenerándose (crayón → crayón + grafito → grafito, rasguños y papel deteriorado).
**v0.1 no es el juego: es el motor real** sobre el que se construirán las siguientes versiones.
100 % nativo (Kotlin + Android Canvas), sin motores externos, sin internet, sin backend.

## Versión
**v0.1.0** — Al abrirla verás una habitación de prueba, el personaje, un joystick táctil
(mitad izquierda de la pantalla), cámara que lo sigue y colisiones con paredes y objetos.

## Arquitectura
Paquete `com.terror2d`:

| Pieza | Archivo | Responsabilidad |
|---|---|---|
| Canvas | `core/GameView.kt` | `SurfaceView`; solo conecta Android (superficie, touch, teclas) con `Game`. |
| Game | `core/Game.kt` | Coordina estado, escena, input, update y render. Sin lógica de juego. |
| Game Loop | `core/GameLoop.kt` | Hilo propio. Calcula `deltaTime`, simulación a **paso fijo de 60 Hz**, render desacoplado, límite de FPS. |
| GameState | `core/GameState.kt` | Estado global mínimo + `visualCorruption` (0.0 en v0.1). |
| Viewport | `core/Viewport.kt` | Resolución lógica **320×180** escalada a la pantalla sin deformar (barras negras). |
| Camera | `core/Camera.kt` | Mundo → cámara → pantalla; zona muerta, suavizado, límites de escena, ajuste a píxel. |
| InputController | `input/InputController.kt` | Joystick flotante + teclado; expone `moveX/moveY` y acciones futuras (`InputAction`). |
| SceneManager / Scene | `scene/` | `register`, `loadScene`, `changeScene`, `update`, `render`. `TestScene` es la escena técnica. |
| SceneDefinition | `scene/SceneDefinition.kt` | `id, width, height, seed, objects, spawnPoint`. |
| WorldObject | `world/WorldObject.kt` | Base de objetos: `x, y, width, height, visible, collidable`. |
| CollisionSystem | `world/CollisionSystem.kt` | AABB con ejes separados (deslizamiento por paredes), sin allocations. |
| SeededRandom | `util/SeededRandom.kt` | SplitMix64: **misma semilla = mismo resultado**. |
| Renderers | `render/BaseRenderer.kt`, `GameRenderer.kt` | `BaseRenderer` dibuja en estilo crayón; `GameRenderer` orquesta el frame y permite cambiar de renderizador. |

### Semillas (regla importante)
`SeededRandom` solo se usa para **imperfecciones visuales** (contornos dobles, trazos de relleno,
motas de papel, garabatos). Se genera todo **una vez al cargar la escena**; durante el render solo se
leen arrays. El gameplay es 100 % determinista: no hay aleatoriedad en colisiones, posiciones ni lógica.

## Build (GitHub Actions)
El workflow `.github/workflows/build.yml` se ejecuta en cada push a `main`/`master`, en pull requests
y manualmente (*Run workflow*). Instala JDK 17 y Gradle 8.7, regenera `gradle-wrapper.jar` si falta,
ejecuta `./gradlew assembleDebug`, localiza el APK en `app/build/outputs/apk/debug/`, lo publica como
artifact **`JuegoTerror2D-debug-apk`** y después ejecuta los tests unitarios (`testDebugUnitTest`).

Para descargar el APK: pestaña **Actions** → ejecución más reciente → sección **Artifacts**.

## Flujo recomendado
```
Claude → ZIP → Descomprimir → Subir a GitHub → Actions → build.yml → APK
```
La raíz del ZIP es directamente la raíz del repositorio.

## Controles
- Táctil: arrastra con el pulgar en la mitad izquierda (joystick flotante).
- Teclado (emulador): flechas o WASD; Espacio = interactuar (reservado).

## Próxima versión
**v0.2** añadirá principalmente: movimiento más refinado, personaje, cámara, límites y colisiones.
