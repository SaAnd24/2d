import numpy as np
from PIL import Image
import creature_ref as c

PALRGBA = np.array(c.PAL, np.uint8)


def to_img(idx):
    return Image.fromarray(PALRGBA[idx], 'RGBA')


def compose(name='IDLE', lead=(4, 1), trail=(4, 1), eye=0, mouth=0, mo=(3, 3, 3, 3, 3, 3, 3), scale=3, bg=(214, 206, 186, 255)):
    body, info = c.build_body(name)
    img = Image.new('RGBA', (c.W, c.H), bg)

    def put(idx, x, y):
        im = to_img(idx)
        tmp = Image.new('RGBA', img.size, (0, 0, 0, 0))
        tmp.paste(im, (int(x), int(y)))
        img.alpha_composite(tmp)
    a, (w, h, ax, ay) = c.build_arm(trail[0], trail[1], False)
    put(a, info['trail'][0] - ax, info['trail'][1] - ay)
    put(body, 0, 0)
    v = info['variant']
    hs, _ = c.head_sprite(v)
    hx, hy = info['head']
    put(hs, hx, hy)
    for side in ('L', 'R'):
        spr, w, h, (cxc, cyc) = c.eye_patches(v, side)[eye]
        put(spr, cxc - w // 2 - c.HEAD_CELL[v][0] + hx, cyc - h // 2 - c.HEAD_CELL[v][1] + hy)
    spr, w, h, (cxc, cyc) = c.main_mouth_patches(v)[mouth]
    put(spr, cxc - w // 2 - c.HEAD_CELL[v][0] + hx, cyc - h // 2 - c.HEAD_CELL[v][1] + hy)
    bx, by = info['belly']
    for i in range(7):
        spr, w, h, (cxc, cyc) = c.belly_patches(i)[mo[i]]
        put(spr, cxc - c.CELL0[0] - w // 2 + (bx - c.BELLY_C[0]), cyc - c.CELL0[1] - h // 2 + (by - c.BELLY_C[1]))
    a, (w, h, ax, ay) = c.build_arm(lead[0], lead[1], True)
    put(a, info['lead'][0] - ax, info['lead'][1] - ay)
    return img.resize((c.W * scale, c.H * scale), Image.NEAREST)


if __name__ == '__main__':
    ims = [compose('IDLE', scale=3), compose('WALK_2', lead=(3, 1), trail=(5, 1), scale=3)]
    sh = Image.new('RGBA', (sum(i.width for i in ims), ims[0].height))
    x = 0
    for i in ims:
        sh.paste(i, (x, 0)); x += i.width
    sh.save('/home/claude/ref_preview.png'); print(sh.size)
