"""Genera app/src/main/java/com/terror2d/pixel/SpriteData.kt a partir de los dibujos de Python.

Uso:  python3 emit_kotlin.py            (desde tools/sprite_gen)
Formato: cada matriz se guarda comprimida por tramos (RLE): 2 caracteres por tramo = índice de paleta + longitud,
ambos como chr(48 + n). Un tramo largo se parte en varios. Cada cadena queda por debajo del límite de 64 KB de la JVM.
"""
import os, sys
import numpy as np
import protagonist as pr, face, items, hands
from pixlib import PALETTE

OUT = os.path.join(os.path.dirname(__file__), '..', '..', 'app', 'src', 'main', 'java', 'com', 'terror2d', 'pixel', 'SpriteData.kt')


def rle(a):
    flat = a.flatten()
    out, i, n = [], 0, len(flat)
    while i < n:
        v, j = int(flat[i]), i
        while j < n and flat[j] == v and j - i < 70:
            j += 1
        out.append(chr(48 + v) + chr(48 + (j - i)))
        i = j
    s = ''.join(out)
    return s.replace('\\', '\\\\').replace('$', '\\$').replace('"', '\\"')


def kstr(name, a, indent='        '):
    return f'{indent}"{rle(a)}"'


def argb(c):
    r, g, b, a = c
    return '0x%02X%02X%02X%02X' % (a, r, g, b)


def pal_kt(pal):
    return ', '.join(argb(c) + '.toInt()' for c in pal)


def main():
    lines = []
    w = lines.append
    w('package com.terror2d.pixel')
    w('')
    w('/**')
    w(' * DATOS GENERADOS por tools/sprite_gen (python3 emit_kotlin.py). NO editar a mano: edita el generador.')
    w(' * Matrices de índices de paleta comprimidas por tramos; las decodifica [SpriteCodec].')
    w(' */')
    w('object SpriteData {')
    w(f'    const val PROTAGONIST_W = {pr.W}')
    w(f'    const val PROTAGONIST_H = {pr.H}')
    w(f'    const val PROTAGONIST_ANCHOR_X = {pr.AX}')
    w('')
    w('    val PROTAGONIST_PALETTE: IntArray = intArrayOf(' + pal_kt(PALETTE) + ')')
    w('')
    # poses
    names = list(pr.POSES.keys())
    w('    /** Orden = ordinal de [PixelPose]. */')
    w('    val POSE_NAMES: Array<String> = arrayOf(' + ', '.join('"%s"' % n for n in names) + ')')
    w('')
    base_rows, fg_rows, heads, hands_xy = [], [], [], []
    for n in names:
        cv, info = pr.build(pr.POSES[n])
        base, fg = pr.split_front_hand(cv, info, pr.POSES[n])
        base_rows.append(base)
        fg_rows.append(fg)
        heads.append(info['head'])
        hands_xy.append(info['hand'])
    w('    val PROTAGONIST_BASE: Array<String> = arrayOf(')
    w(',\n'.join(kstr(n, b) for n, b in zip(names, base_rows)))
    w('    )')
    w('')
    w('    /** Capa de primer plano (mano delantera): se dibuja DESPUÉS del objeto sostenido. "" = no hay. */')
    w('    val PROTAGONIST_FRONT: Array<String> = arrayOf(')
    w(',\n'.join(('        ""' if f is None else kstr(n, f)) for n, f in zip(names, fg_rows)))
    w('    )')
    w('')
    w('    /** Centro de la cabeza por pose (ancla de los parches de cara). */')
    w('    val PROTAGONIST_HEAD: Array<IntArray> = arrayOf(' + ', '.join('intArrayOf(%d, %d)' % h for h in heads) + ')')
    w('')
    w('    /** Punto de agarre de la mano por pose (columna, fila) en píxeles del sprite; vacío = no sostiene. */')
    w('    val PROTAGONIST_HAND: Array<IntArray> = arrayOf(' + ', '.join(('intArrayOf()' if h is None else 'intArrayOf(%d, %d)' % h) for h in hands_xy) + ')')
    w('')
    # caras
    w('    // ---------------- cara: parches de ojos y boca (0 = no tocar el píxel de debajo)')
    w('    val EYE_STATES: Array<String> = arrayOf(' + ', '.join('"%s"' % s for s in face.EYE_STATES) + ')')
    w('    val MOUTH_STATES: Array<String> = arrayOf(' + ', '.join('"%s"' % s for s in face.MOUTH_STATES) + ')')
    eyes = [face.eye_patch(s) for s in face.EYE_STATES]
    mouths = [face.mouth_patch(s) for s in face.MOUTH_STATES]
    w('    /** [ancho, alto, desplazamiento x, desplazamiento y] respecto al centro de la cabeza. */')
    w('    val EYE_META: Array<IntArray> = arrayOf(' + ', '.join('intArrayOf(%d, %d, %d, %d)' % (a.shape[1], a.shape[0], ox, oy) for ox, oy, a in eyes) + ')')
    w('    val EYE_DATA: Array<String> = arrayOf(')
    w(',\n'.join(kstr('e', a) for ox, oy, a in eyes))
    w('    )')
    w('    val MOUTH_META: Array<IntArray> = arrayOf(' + ', '.join('intArrayOf(%d, %d, %d, %d)' % (a.shape[1], a.shape[0], ox, oy) for ox, oy, a in mouths) + ')')
    w('    val MOUTH_DATA: Array<String> = arrayOf(')
    w(',\n'.join(kstr('m', a) for ox, oy, a in mouths))
    w('    )')
    w('')
    # objetos
    its = items.all_items()
    w('    // ---------------- objetos (escala canónica única: 1 píxel = 0.5 px lógicos)')
    w('    val ITEM_IDS: Array<String> = arrayOf(' + ', '.join('"%s"' % k for k in its) + ')')
    w('    val ITEM_META: Array<IntArray> = arrayOf(' + ', '.join('intArrayOf(%d, %d, %d, %d)' % (cv.w, cv.h, g[0], g[1]) for cv, pal, g in its.values()) + ')')
    w('    val ITEM_PALETTES: Array<IntArray> = arrayOf(')
    w(',\n'.join('        intArrayOf(' + pal_kt(pal) + ')' for cv, pal, g in its.values()))
    w('    )')
    w('    val ITEM_DATA: Array<String> = arrayOf(')
    w(',\n'.join(kstr(k, cv.a) for k, (cv, pal, g) in its.items()))
    w('    )')
    w('')
    # manos 1ª persona
    w('    // ---------------- manos en primera persona')
    w(f'    const val HANDS_W = {hands.W}')
    w(f'    const val HANDS_H = {hands.H}')
    w('    val HAND_KINDS: Array<String> = arrayOf("REST", "GRAB", "POINT")')
    w('    val HAND_DATA: Array<String> = arrayOf(')
    w(',\n'.join(kstr(k, hands.build(k).a) for k in ('REST', 'GRAB', 'POINT')))
    w('    )')
    w('}')
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    open(OUT, 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
    sizes = [len(rle(b)) for b in base_rows]
    print('escrito', os.path.abspath(OUT), os.path.getsize(OUT), 'bytes; mayor cadena', max(sizes))


if __name__ == '__main__':
    main()
