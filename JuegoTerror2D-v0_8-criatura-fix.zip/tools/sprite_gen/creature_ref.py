"""Rig de la criatura FIEL a las referencias: poses, caminata, brazos péndulo, cabezas, ojos y bocas (parches).
Todo lo que sale de aquí son matrices de índices de paleta (las que emite emit_creature.py)."""
import math
import numpy as np
from refrig import *
from refparts import *

W, H = CW, CH
ANCHOR_X = int(round(((P(*HIP_L)[0] + P(*HIP_R)[0]) / 2 - WX0) / S))
CELL0 = (WX0 // S, WY0 // S)


def cell(pt):
    x, y = P(*pt)
    return (int(round((x - WX0) / S)), int(round((y - WY0) / S)))


def cell_abs(pt):
    x, y = P(*pt)
    return (int(round(x / S)), int(round(y / S)))


# ---------------------------------------------------------------- poses (en píxeles de sprite = celdas)
BOB8 = [2, 3, 0, -2, 2, 3, 0, -2]
SWAY8 = [1, 2, 2, 1, -1, -2, -2, -1]
LAG8 = [0, 1, 2, 1, 0, 1, 2, 1]


def gait_foot(psi, Sx, Lift):
    psi = psi % 1.0
    if psi < 0.5:
        return Sx * (1 - 4 * psi), 0.0, -6 + 10 * (psi / 0.5) + (16 if psi > 0.4 else 0)
    q = (psi - 0.5) * 2
    return -Sx + 2 * Sx * q, Lift * math.sin(math.pi * q) ** 0.9, 22 * math.sin(math.pi * q) - 6 * q


def pose_walk(k, run=False):
    Sx = 24.0 if run else 12.0
    Lf = 15.0 if run else 7.0
    phi = k / 8.0
    xl, ll, pl = gait_foot(phi, Sx, Lf)
    xt, lt, pt = gait_foot(phi + 0.5, Sx, Lf)
    bob = [4, 6, -1, -4, 4, 6, -1, -4][k] if run else BOB8[k]
    sway = int(round(SWAY8[k] * (1.0 if run else 1.3)))
    lean = 5 if run else 1
    return dict(bob=bob, sway=sway, lean=lean, chest_dy=(2 if run else 0) + (1 if k in (1, 5) else 0),
                belly=(int(round(-sway * 0.4)), LAG8[k] * (2 if run else 1)),
                head=(-int(round(sway * 0.3)) + (4 if run else 0), (4 if run else 0) + LAG8[k]), variant=1,
                lead=(xl, ll, pl), trail=(xt, lt, pt))


def poses():
    P_ = {}
    z = dict(lead=(0, 0, 0), trail=(0, 0, 0))
    P_['IDLE'] = dict(bob=0, sway=0, lean=0, chest_dy=0, belly=(0, 0), head=(0, 0), variant=0, **z)
    P_['INVESTIGATE'] = dict(bob=2, sway=1, lean=4, chest_dy=3, belly=(1, 1), head=(5, 5), variant=1, **z)
    P_['ALERT'] = dict(bob=-2, sway=0, lean=-2, chest_dy=-2, belly=(0, -1), head=(-2, -4), variant=0, **z)
    P_['CAPTURE'] = dict(bob=4, sway=2, lean=9, chest_dy=4, belly=(2, 2), head=(8, 5), variant=1, **z)
    P_['HURT_LIGHT'] = dict(bob=3, sway=-2, lean=-5, chest_dy=2, belly=(-1, 2), head=(-5, 5), variant=0, **z)
    for k in range(8):
        P_['WALK_%d' % k] = pose_walk(k)
    for k in range(8):
        P_['RUN_%d' % k] = pose_walk(k, run=True)
    return P_


POSES = poses()
HEAD_CELL = []        # esquina (celdas, ventana del cuerpo) de cada variante de cabeza en reposo
for v in (0, 1):
    pc = HEAD_PC[v]
    h, w = pc.a.shape
    cx0, cy0, cw, ch = bbox_cells(np.pad(pc.a, ((pc.oy, BH - pc.oy - h), (pc.ox, BW - pc.ox - w))))
    HEAD_CELL.append((cx0, cy0, cw, ch))
BELLY_C = cell((435, 590))
SH_LEAD = cell(SH_L)
SH_TRAIL = cell(SH_R)


# ---------------------------------------------------------------- piernas con IK y piezas
def _fk(pt):
    return np.array(P(*pt), float)


def _two_bone(Hp, Ap, l1, l2, sign):
    d = Ap - Hp
    dist = np.linalg.norm(d)
    dist = min(max(dist, abs(l1 - l2) + 1), l1 + l2 - 1)
    u = d / max(1e-6, np.linalg.norm(d))
    a = (l1 * l1 - l2 * l2 + dist * dist) / (2 * dist)
    hh = math.sqrt(max(0.0, l1 * l1 - a * a))
    perp = np.array([-u[1], u[0]]) * sign
    return Hp + u * a + perp * hh, Hp + u * dist


def _ang(v):
    return math.degrees(math.atan2(v[1], v[0]))


def build_leg(side, pose, hip_off, ank_nominal):
    hip0, kn0, ak0 = {'lead': (HIP_L, KN_L, AK_L), 'trail': (HIP_R, KN_R, AK_R)}[side]
    H0, K0, A0 = _fk(hip0), _fk(kn0), _fk(ak0)
    th, sh, ft = LEG_PCS[side]
    gx, lift, pitch = pose[side]
    if gx == 0 and lift == 0 and pitch == 0 and hip_off[0] == 0 and hip_off[1] == 0:
        return [th, sh, ft]
    l1, l2 = np.linalg.norm(K0 - H0), np.linalg.norm(A0 - K0)
    rest_sign = np.sign((A0 - H0)[0] * (K0 - H0)[1] - (A0 - H0)[1] * (K0 - H0)[0]) or 1.0
    # signo del desplazamiento perpendicular que reproduce la rodilla del reposo
    u0 = (A0 - H0) / np.linalg.norm(A0 - H0)
    perp0 = np.array([-u0[1], u0[0]])
    sign = 1.0 if np.dot(K0 - H0, perp0) >= 0 else -1.0
    H1 = H0 + np.array(hip_off, float) * S
    A1 = A0 + np.array([(gx + ank_nominal) * S, -lift * S])
    K1, A1c = _two_bone(H1, A1, l1, l2, sign)
    a_t = _ang(K1 - H1) - _ang(K0 - H0)
    a_s = _ang(A1c - K1) - _ang(A0 - K0)
    sgn = 1.0 if side == 'lead' else -1.0
    p_th = xf(th, a_t, tuple(H0), tuple(H1 - H0))
    p_sh = xf(sh, a_s, tuple(K0), tuple(K1 - K0))
    p_ft = xf(ft, pitch * sgn * 0.7 - a_s * 0.35, tuple(A0), tuple(A1c - A0))
    return [p_th, p_sh, p_ft]


# apoyo nominal de cada pie respecto a la ley de paso (para que el reposo == la imagen)
NOM_LEAD = (P(*AK_L)[0] - (P(*HIP_L)[0] + P(*HIP_R)[0]) / 2) / S - 12.0
NOM_TRAIL = (P(*AK_R)[0] - (P(*HIP_L)[0] + P(*HIP_R)[0]) / 2) / S + 12.0


def build_body(name):
    p = POSES[name]
    rgb, a = canvas()
    hip_off = (p['sway'], p['bob'])
    for side, nom in (('trail', NOM_TRAIL), ('lead', NOM_LEAD)):
        for pc in build_leg(side, p, hip_off, 0):
            blit(rgb, a, pc)
    cdx, cdy = p['lean'] + int(round(p['sway'] * 0.5)), p['bob'] + p['chest_dy']
    bdx, bdy = p['sway'] + p['belly'][0], p['bob'] + p['belly'][1]
    blit(rgb, a, xf(CHEST_PC, 0, (0, 0), (cdx * S, cdy * S)))
    blit(rgb, a, xf(BELLY_PC, 0, (0, 0), (bdx * S, bdy * S)))
    v = p['variant']
    hx = HEAD_CELL[v][0] - CELL0[0] + cdx + int(round(p['sway'] * 0.5)) * 0 + p['head'][0]
    hy = HEAD_CELL[v][1] - CELL0[1] + cdy + p['head'][1]
    info = dict(head=(hx, hy), belly=(BELLY_C[0] + bdx, BELLY_C[1] + bdy),
                lead=(SH_LEAD[0] + cdx, SH_LEAD[1] + cdy), trail=(SH_TRAIL[0] + cdx, SH_TRAIL[1] + cdy), variant=v)
    return sprite(rgb, a, WX0, WY0, CW * S, CH * S), info


# ---------------------------------------------------------------- brazos (péndulo: balanceo x codo)
ARM_SWING = [-40, -30, -20, -10, 0, 10, 20, 30, 42, 60]
ARM_BEND = [-14, 0, 14]


def build_arm(si, bi, lead):
    sw, bd = ARM_SWING[si], ARM_BEND[bi]
    key = 'lead' if lead else 'trail'
    up, fo = ARM_PCS[key]
    sh0, el0 = (SH_L, EL_L) if lead else (SH_R, EL_R)
    Sp, Ep = tuple(_fk(sh0)), tuple(_fk(el0))
    rgb, a = canvas()
    # + swing = hacia delante (+x): giro antihorario en pantalla
    fo2 = xf(xf(fo, -bd, Ep), -sw, Sp)
    up2 = xf(up, -sw, Sp)
    blit(rgb, a, fo2)
    blit(rgb, a, up2)
    cx0, cy0, w, h = bbox_cells(a)
    spr = sprite(rgb, a, cx0 * S, cy0 * S, w * S, h * S)
    anc = cell_abs(sh0)
    # ancla = celda del hombro en reposo (absoluta) -> relativa al recorte
    return spr, (w, h, anc[0] - cx0, anc[1] - cy0)


# ---------------------------------------------------------------- cabezas y parches (ojos, sonrisa, bocas del vientre)
def head_sprite(v):
    cx0, cy0, w, h = HEAD_CELL[v]
    rgb, a = canvas()
    blit(rgb, a, HEAD_PC[v])
    return sprite(rgb, a, cx0 * S, cy0 * S, w * S, h * S), (w, h)


def remap_patch(src_rgb, src_a, center, theta, Ulens, h0, sag, o, cells_hint=None, dy_shift=0.0, up_extra=14, r_extra=16, o_fade=True):
    """Parche de una boca/ojo: remuestra la referencia comprimiendo/estirando la abertura (h0) por el factor o,
    alrededor de una línea central curva (sag), con identidad en el borde del parche. Devuelve (sprite, w, h, (cx,cy) celda)."""
    cxh, cyh = P(*center)
    th = -math.radians(theta)                 # el espejo invierte el ángulo
    c, s = math.cos(th), math.sin(th)
    Up = Ulens + up_extra
    R = max(h0 + r_extra, 1.55 * h0 + 8)
    # ventana: caja que contiene la región (u,w) tras la curva
    uu = np.linspace(-Up, Up, 41)
    ww = np.array([-R, R])
    pts = []
    for u in uu:
        vc = -sag * (u / max(1.0, Ulens)) ** 2
        for w in ww:
            v = vc + w
            pts.append((cxh + u * c - v * s, cyh + u * s + v * c))
    pts = np.array(pts)
    cxc, cyc = int(round(cxh / S)), int(round(cyh / S))
    hw = int(math.ceil(max(abs(pts[:, 0] - cxc * S).max(), 1))) // S + 2
    hh = int(math.ceil(max(abs(pts[:, 1] - cyc * S).max(), 1))) // S + 2
    if cells_hint:
        hw, hh = cells_hint
    wc, hc = hw * 2, hh * 2
    ox, oy = (cxc - hw) * S, (cyc - hh) * S
    yy, xx = np.mgrid[oy:oy + hc * S, ox:ox + wc * S]
    X, Y = xx - cxh + 0.5, yy - cyh + 0.5 - dy_shift
    u = X * c + Y * s
    v = -X * s + Y * c
    vc = -sag * (u / max(1.0, Ulens)) ** 2
    w = v - vc
    fade = np.clip((Up - np.abs(u)) / (0.30 * Up), 0, 1) if o_fade else np.ones_like(u)
    oe = 1.0 + (o - 1.0) * fade
    aw = np.abs(w)
    inner = aw <= oe * h0
    wp = np.where(inner, w / oe, np.sign(w) * (h0 + (aw - oe * h0) * (R - h0) / np.maximum(R - oe * h0, 1e-3)))
    vp = wp + vc
    sx = cxh + u * c - vp * s
    sy = cyh + u * s + vp * c
    six = np.clip(np.round(sx - 0.5).astype(int), 0, BW - 1)
    siy = np.clip(np.round(sy - 0.5).astype(int), 0, BH - 1)
    rgb = src_rgb[siy, six]
    al = src_a[siy, six] & (np.abs(u) <= Up) & (aw <= R)
    big_rgb = np.zeros((BH, BW, 3), np.uint8)
    big_a = np.zeros((BH, BW), bool)
    big_rgb[oy:oy + hc * S, ox:ox + wc * S] = rgb
    big_a[oy:oy + hc * S, ox:ox + wc * S] = al
    return sprite(big_rgb, big_a, ox, oy, wc * S, hc * S), wc, hc, (cxc, cyc)


EYE_STATES = ['OPEN', 'HALF', 'CLOSED', 'LOOK_DOWN', 'WIDE']
EYE_O = {'OPEN': 1.0, 'HALF': 0.72, 'CLOSED': 0.10, 'LOOK_DOWN': 1.0, 'WIDE': 1.18}
MOUTH_NAMES = ['CLOSED', 'TENSE', 'OPEN', 'WIDE']

# (centro orig, rx, ry) de cada ojo por variante: L = ojo trasero (izq. tras espejar), R = delantero
EYES = {0: {'L': ((375, 170), 33, 27), 'R': ((258, 178), 34, 28)},
        1: {'L': ((295, 170), 33, 27), 'R': ((210, 168), 17, 24)}}
# boca principal: (centro, ángulo orig, semilongitud, h0, sag)
MAIN = {0: ((330, 297), -6.8, 125, 46, 87), 1: ((295, 282), -21, 100, 40, 35)}
MAIN_O = [1.0, 0.80, 1.22, 1.45]


def eye_patches(v, side):
    (ctr, rx, ry) = EYES[v][side]
    out = []
    n = int(math.ceil(max(rx + 12, ry * 0.95 + 14) / S)) + 2
    for st in EYE_STATES:
        spr, w, h, c = remap_patch(RGB_A if v == 0 else RGB_B, A_A if v == 0 else A_B, ctr, 0.0, rx, ry * 0.95, 0.0, EYE_O[st],
                                   dy_shift=(9.0 if st == 'LOOK_DOWN' else 0.0), up_extra=12, r_extra=14, cells_hint=(n, n))
        out.append((spr, w, h, c))
    # todos los estados con el mismo tamaño
    return out


def main_mouth_patches(v):
    ctr, th, U, h0, sag = MAIN[v]
    return [remap_patch(RGB_A if v == 0 else RGB_B, A_A if v == 0 else A_B, ctr, th, U, h0, sag, o, up_extra=16, r_extra=22) for o in MAIN_O]


# (centro orig, semilongitud lente, h0, ángulo orig, sag)
BELLY_MOUTHS = [((390, 527), 80, 33, -3, 0), ((285, 543), 42, 15, 10, 0), ((350, 607), 68, 30, 22, 0), ((488, 592), 72, 28, -22, 0),
                ((597, 575), 45, 28, -18, 0), ((460, 665), 58, 14, -8, 8), ((555, 505), 42, 9, -10, 0)]
BELLY_O = [0.10, 0.40, 0.70, 1.0]


def belly_patches(i):
    ctr, U, h0, th, sag = BELLY_MOUTHS[i]
    return [remap_patch(RGB_A, A_A, ctr, th, U, h0, sag, o, up_extra=14, r_extra=16) for o in BELLY_O]
