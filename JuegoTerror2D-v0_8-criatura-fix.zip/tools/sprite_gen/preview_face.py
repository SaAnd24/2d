from PIL import Image
from pixlib import Cv, to_image, PALETTE
import protagonist as pr, face
import numpy as np
tiles = []
for e, m in [('OPEN','NEUTRAL'),('HALF','SMILE'),('CLOSED','SAD'),('WIDE','OPEN'),('DOWN','SPEAK')]:
    cv, info = pr.build(pr.POSES['IDLE'])
    cv.a = face.apply(cv.a, info['head'], e, m)
    hx, hy = info['head']
    sub = Cv(44, 44)
    sub.a = cv.a[hy-26:hy+18, hx-22:hx+22].copy()
    tiles.append(to_image(sub, 8))
sheet = Image.new('RGBA', (sum(t.width for t in tiles), tiles[0].height))
x = 0
for t in tiles:
    sheet.paste(t, (x, 0)); x += t.width
sheet.save('/home/claude/preview/face.png'); print(sheet.size)
