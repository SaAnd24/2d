"""Conversión FIEL de las dos imágenes de referencia de la criatura (frontal y caminando) a matrices de píxeles de
paleta (los datos RLE del motor pixelado) + rig por piezas para animarla. SOLO se ejecuta en desarrollo: la app no
contiene ninguna imagen, únicamente las matrices que emite emit_creature.py.

Pipeline: recorte del fondo de cuadros -> espejo (la criatura mira a la DERECHA) -> piezas (cabeza, pecho, vientre,
brazos en 2 tramos, piernas en muslo/espinilla/pie) -> transformaciones por rotación (vecino más cercano, a alta
resolución) -> reducción x6 con prioridad al contorno oscuro -> cuantización a una paleta de 31 colores.
"""
import math
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage as ndi

S = 6                              # factor de reducción (1 píxel de sprite = 6 px de la referencia)
BW, BH = 2160, 1560               # lienzo de trabajo (alta resolución)
X0, Y0 = 700, 134                  # dónde cae la referencia espejada en el lienzo
WX0, WY0 = 660, 102                # ventana del cuerpo (múltiplos de S)
CW, CH = 960 // S, 1200 // S       # tamaño del sprite de cuerpo (160 x 200)

PA = '/mnt/user-data/uploads/1791372924369.jpg'
PB = '/mnt/user-data/uploads/1791372912870.jpg'


def P(x, y):
    """Coordenadas de la referencia (sin espejar) -> lienzo de trabajo (espejado)."""
    return (895 - x + X0, y + Y0)


def Ppoly(pts):
    return [P(x, y) for x, y in pts]


def _load(path):
    im = np.array(Image.open(path).convert('RGB')).astype(np.int16)
    mx, mn = im.max(2), im.min(2)
    bg = ((mx - mn) < 16) & (mn > 140)
    fg = ndi.binary_opening(~bg, iterations=1)
    lab, n = ndi.label(fg)
    sz = ndi.sum(fg, lab, range(1, n + 1))
    m = lab == (1 + int(np.argmax(sz)))
    rgb = np.zeros((BH, BW, 3), np.uint8)
    a = np.zeros((BH, BW), bool)
    h, w = m.shape
    rgb[Y0:Y0 + h, X0:X0 + w] = im[:, ::-1].astype(np.uint8)
    a[Y0:Y0 + h, X0:X0 + w] = m[:, ::-1]
    return rgb, a


RGB_A, A_A = _load(PA)
RGB_B, A_B = _load(PB)


def poly_mask(pts):
    im = Image.new('L', (BW, BH), 0)
    ImageDraw.Draw(im).polygon([tuple(p) for p in Ppoly(pts)], fill=1)
    return np.array(im, bool)


def half_plane(p0, d, sign=1):
    """Máscara de los puntos q con (q - p0)·d >= 0 (p0 y d en coords de referencia sin espejar)."""
    px, py = P(*p0)
    dx, dy = -d[0], d[1]                       # el espejo invierte x
    yy, xx = np.mgrid[0:BH, 0:BW]
    return ((xx - px) * dx + (yy - py) * dy) * sign >= 0


# ---------------------------------------------------------------- piezas
class Piece:
    def __init__(self, rgb, a, ox, oy):
        self.rgb, self.a, self.ox, self.oy = rgb, a, ox, oy


def cut(rgb, a, mask):
    m = a & mask
    ys, xs = np.nonzero(m)
    if len(xs) == 0:
        return Piece(np.zeros((1, 1, 3), np.uint8), np.zeros((1, 1), bool), 0, 0)
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    return Piece(np.where(m[y0:y1, x0:x1, None], rgb[y0:y1, x0:x1], 0).astype(np.uint8), m[y0:y1, x0:x1].copy(), x0, y0)


def xf(p, ang, pivot, trans=(0.0, 0.0)):
    """Rotación (grados, + = horario en pantalla) alrededor de pivot (coords de lienzo) + traslación; vecino más cercano."""
    if abs(ang) < 1e-6 and trans == (0.0, 0.0):
        return p
    c, s = math.cos(math.radians(ang)), math.sin(math.radians(ang))
    px, py = pivot
    tx, ty = trans
    h, w = p.a.shape
    xs, ys = [], []
    for (qx, qy) in ((p.ox, p.oy), (p.ox + w, p.oy), (p.ox, p.oy + h), (p.ox + w, p.oy + h)):
        rx, ry = qx - px, qy - py
        xs.append(c * rx - s * ry + px + tx)
        ys.append(s * rx + c * ry + py + ty)
    ox2, oy2 = int(math.floor(min(xs))) - 1, int(math.floor(min(ys))) - 1
    w2, h2 = int(math.ceil(max(xs))) - ox2 + 2, int(math.ceil(max(ys))) - oy2 + 2
    M = np.array([[c, -s], [s, c]])
    off = np.array([-s * (ox2 - px - tx) + c * (oy2 - py - ty) + py - p.oy,
                    c * (ox2 - px - tx) + s * (oy2 - py - ty) + px - p.ox])
    # in_y = c*i - s*j + off0 ; in_x = s*i + c*j + off1  (i = fila de salida, j = columna)
    rgb = np.stack([ndi.affine_transform(p.rgb[:, :, k], M, offset=off, output_shape=(h2, w2), order=0, cval=0) for k in range(3)], 2)
    a = ndi.affine_transform(p.a.astype(np.uint8), M, offset=off, output_shape=(h2, w2), order=0, cval=0) > 0
    return Piece(rgb, a, ox2, oy2)


def blit(dst_rgb, dst_a, p):
    h, w = p.a.shape
    x0, y0 = max(p.ox, 0), max(p.oy, 0)
    x1, y1 = min(p.ox + w, BW), min(p.oy + h, BH)
    if x1 <= x0 or y1 <= y0:
        return
    sub = p.a[y0 - p.oy:y1 - p.oy, x0 - p.ox:x1 - p.ox]
    r = dst_rgb[y0:y1, x0:x1]
    r[sub] = p.rgb[y0 - p.oy:y1 - p.oy, x0 - p.ox:x1 - p.ox][sub]
    dst_a[y0:y1, x0:x1] |= sub


def canvas():
    return np.zeros((BH, BW, 3), np.uint8), np.zeros((BH, BW), bool)


# ---------------------------------------------------------------- reducción x6 con prioridad al contorno + paleta
DARK = 62


def down(rgb, a, x0, y0, w, h):
    """Reduce la ventana (múltiplos de S) a celdas: contorno oscuro con prioridad, resto = media de los claros."""
    sub = rgb[y0:y0 + h, x0:x0 + w].astype(np.float32)
    am = a[y0:y0 + h, x0:x0 + w]
    gh, gw = h // S, w // S
    blk = sub.reshape(gh, S, gw, S, 3).transpose(0, 2, 1, 3, 4).reshape(gh, gw, S * S, 3)
    ab = am.reshape(gh, S, gw, S).transpose(0, 2, 1, 3).reshape(gh, gw, S * S)
    lum = blk.mean(3)
    dk = ab & (lum < DARK)
    lt = ab & ~(lum < DARK)
    n, nd, nl = ab.sum(2), dk.sum(2), lt.sum(2)
    mean_d = (blk * dk[..., None]).sum(2) / np.maximum(nd, 1)[..., None]
    mean_l = (blk * lt[..., None]).sum(2) / np.maximum(nl, 1)[..., None]
    use_d = (nd >= 0.40 * n) | (nl == 0)
    col = np.where(use_d[..., None], mean_d, mean_l)
    op = n >= S * S * 0.5
    return col.astype(np.uint8), op


def kmeans_palette(samples, k, seed=3):
    rs = np.random.RandomState(seed)
    c = samples[rs.choice(len(samples), k, replace=False)].astype(float)
    for _ in range(30):
        d = ((samples[:, None, :] - c[None]) ** 2).sum(2)
        a = d.argmin(1)
        for j in range(k):
            m = samples[a == j]
            if len(m):
                c[j] = m.mean(0)
    return c


def build_palette():
    cols = []
    for rgb, a in ((RGB_A, A_A), (RGB_B, A_B)):
        col, op = down(rgb, a, WX0, WY0, CW * S, CH * S)
        cols.append(col[op])
    smp = np.concatenate(cols).astype(float)
    # reserva el contorno casi negro y el más oscuro; el resto, k-means
    k = kmeans_palette(smp, 30)
    k = k[np.argsort(k.sum(1))]
    pal = [(0, 0, 0, 0)] + [(int(r), int(g), int(b), 255) for r, g, b in k]
    return pal


PAL = build_palette()
_PAL_RGB = np.array([c[:3] for c in PAL[1:]], float)


def quant(col, op):
    d = ((col[..., None, :].astype(float) - _PAL_RGB) ** 2).sum(-1)
    idx = d.argmin(-1) + 1
    return np.where(op, idx, 0).astype(np.int32)


def sprite(rgb, a, x0, y0, w, h, clean=True):
    col, op = down(rgb, a, x0, y0, w, h)
    if clean:       # quita motas sueltas (restos de la rotación por vecino más cercano): componentes de < 5 celdas
        lab, n = ndi.label(op, structure=np.ones((3, 3)))
        if n > 1:
            sz = ndi.sum(op, lab, range(1, n + 1))
            for k, z in enumerate(sz, 1):
                if z < 5:
                    op[lab == k] = False
    return quant(col, op)


def bbox_cells(a, pad=0):
    ys, xs = np.nonzero(a)
    x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
    cx0, cy0 = x0 // S - pad, y0 // S - pad
    cx1, cy1 = -(-x1 // S) + pad, -(-y1 // S) + pad
    return cx0, cy0, cx1 - cx0, cy1 - cy0
