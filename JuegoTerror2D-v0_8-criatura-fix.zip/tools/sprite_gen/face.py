"""Parches de cara (ojos y boca) relativos al centro de la cabeza. Índices de paleta como en pixlib.P."""
import numpy as np
from pixlib import P

L = dict(k=P['EYE'], w=P['SCLERA'], i=P['IRIS'], d=P['IRIS_D'], p=P['EYE'], h=P['HI'], l=P['LID'],
         s=P['SKIN_S'], b=P['HAIR_D'], m=P['MOUTH'], r=P['LIP'], t=P['TEETH'], c=P['SKIN_D'], x=P['SKIN'], u=P['BLUSH'])


def parse(rows):
    h = len(rows)
    w = max(len(r) for r in rows)
    a = np.zeros((h, w), dtype=np.int32)
    for j, r in enumerate(rows):
        for i, ch in enumerate(r):
            if ch != '.':
                a[j, i] = L[ch]
    return a

# ojo cercano 9x10 (ox=4, oy=-5): ceja arriba + ojo. Mira hacia delante (derecha).
EYE_NEAR = {
    'OPEN': [
        ".bbbbbb..",
        "bb.......",
        "..kkkkk..",
        ".kwwwiik.",
        ".kwwiddk.",
        ".kwidppk.",
        ".kwidphk.",
        "..kiddk..",
        "...lll...",
        ".........",
    ],
    'HALF': [
        ".bbbbbb..",
        "bb.......",
        "..kkkkk..",
        ".llllllll",
        ".kllillk.",
        ".kwidppk.",
        "..kwddk..",
        "...lll...",
        ".........",
        ".........",
    ],
    'CLOSED': [
        ".bbbbbb..",
        "bb.......",
        ".........",
        ".........",
        "..lllll..",
        ".kkkkkkk.",
        "k.l.l.l.k",
        "..sssss..",
        ".........",
        ".........",
    ],
    'WIDE': [
        "bbbbbbb..",
        "b........",
        ".kkkkkkk.",
        "kwwwwwiik",
        "kwwwiiddk",
        "kwwidpppk",
        "kwwidphpk",
        "kwwiddddk",
        ".kwwwwwk.",
        "..kkkkk..",
    ],
    'DOWN': [
        ".bbbbbb..",
        "bb.......",
        "..kkkkk..",
        ".kllllllk",
        ".kwwwwwwk",
        ".kwwiddik",
        ".kwidppik",
        "..kddphk.",
        "...kkk...",
        ".........",
    ],
}
# ojo lejano 5x8 (ox=14, oy=-4): más estrecho (perspectiva) y sin ceja marcada
EYE_FAR = {
    'OPEN': [
        "bbbb.",
        ".kkk.",
        "kwiik",
        "kidpk",
        "kdpp.",
        "kdph.",
        ".kk..",
        ".....",
    ],
    'HALF': [
        ".bbb.",
        ".....",
        ".lll.",
        "klllk",
        "kidpk",
        ".kdk.",
        ".....",
        ".....",
    ],
    'CLOSED': [
        ".bbb.",
        ".....",
        ".....",
        ".....",
        ".lll.",
        "kkkkk",
        ".sss.",
        ".....",
    ],
    'WIDE': [
        "bbbbb",
        ".kkk.",
        "kwwwk",
        "kwiik",
        "kidpk",
        "kdppk",
        ".kdk.",
        ".kk..",
    ],
    'DOWN': [
        "bbbb.",
        ".kkk.",
        "kllk.",
        "kwwwk",
        "kidpk",
        "kddpk",
        ".kk..",
        ".....",
    ],
}

# boca (ox=9, oy=11)
MOUTH = {
    'NEUTRAL': [
        ".........",
        "..mmmmmm.",
        "..rrrrrr.",
        ".........",
    ],
    'SMILE': [
        ".c.......",
        ".mm.mmmm.",
        "..mmrrrm.",
        "....rrr..",
    ],
    'SAD': [
        ".........",
        "...mmmm..",
        "..mrrrrm.",
        ".mr....rm",
    ],
    'OPEN': [
        "..mmmm...",
        ".mtttmm..",
        ".mmmmmm..",
        "..mrrm...",
    ],
    'SPEAK': [
        "..mmmmm..",
        "..mmmmm..",
        "..rrrrr..",
        ".........",
    ],
}
EYE_NEAR_OFF = (4, -5)
EYE_FAR_OFF = (14, -4)
MOUTH_OFF = (7, 9)

EYE_STATES = ['OPEN', 'HALF', 'CLOSED', 'WIDE', 'DOWN']
MOUTH_STATES = ['NEUTRAL', 'SMILE', 'SAD', 'OPEN', 'SPEAK']


def eye_patch(state):
    """Un solo parche (ojo cercano + ojo lejano) relativo al centro de la cabeza. Devuelve (ox, oy, array)."""
    near, far = parse(EYE_NEAR[state]), parse(EYE_FAR[state])
    ox = EYE_NEAR_OFF[0]
    oy = min(EYE_NEAR_OFF[1], EYE_FAR_OFF[1])
    w = EYE_FAR_OFF[0] + far.shape[1] - ox
    h = max(EYE_NEAR_OFF[1] + near.shape[0], EYE_FAR_OFF[1] + far.shape[0]) - oy
    a = np.zeros((h, w), dtype=np.int32)
    for (arr, (px, py)) in ((far, EYE_FAR_OFF), (near, EYE_NEAR_OFF)):
        for j in range(arr.shape[0]):
            for i in range(arr.shape[1]):
                if arr[j, i]:
                    a[py - oy + j, px - ox + i] = arr[j, i]
    return ox, oy, a


def mouth_patch(state):
    arr = parse(MOUTH[state])
    return MOUTH_OFF[0], MOUTH_OFF[1], arr


def apply(cv_a, head, eyes, mouth):
    """Compone un parche sobre una matriz de índices (para la vista previa)."""
    out = cv_a.copy()
    hx, hy = head
    for (ox, oy, arr) in (eye_patch(eyes), mouth_patch(mouth)):
        for j in range(arr.shape[0]):
            for i in range(arr.shape[1]):
                if arr[j, i]:
                    x, y = hx + ox + i, hy + oy + j
                    if 0 <= y < out.shape[0] and 0 <= x < out.shape[1]:
                        out[y, x] = arr[j, i]
    return out
