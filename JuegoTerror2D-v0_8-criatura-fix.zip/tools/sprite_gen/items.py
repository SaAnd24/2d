"""Objetos pixelados con ESCALA CANÓNICA ÚNICA (cada píxel = 0.5 px lógicos, igual que el protagonista).

Un solo dibujo por objeto: suelo, cama, mano, inventario, HOLD_ITEM y PLACED usan EXACTAMENTE este sprite.
  - Ranita de peluche: 32x32 px  = 16x16 lógicos
  - Caja de medicinas: 16x22 px  = 8x11 lógicos (la huella de las cajas de v0.5)
  - Vaso de agua:      14x22 px  = 7x11 lógicos
"""
import numpy as np
from pixlib import Cv, P

# colores propios de los objetos (se añaden al final de su paleta)
# v0.7: la ranita es MÁS apagada (tela vieja y querida) y sutilmente inquietante: pupilas pequeñas, sonrisa cosida
# demasiado ancha, ojos y brazos ligeramente asimétricos, costuras visibles, un remiendo y un hilo suelto.
FROG = ['T', 'OUT', 'G', 'G_L', 'G_S', 'G_D', 'BELLY', 'BELLY_S', 'WHITE', 'EYEW', 'PUPIL', 'HI', 'CROSS', 'CROSS_D', 'STITCH',
        'BLUSH', 'MOUTH', 'CAP', 'CAP_S', 'EYE_S', 'PATCH', 'PATCH_S', 'FUZZ', 'THREAD']
FROG_PAL = [
    (0, 0, 0, 0), (0x2B, 0x1A, 0x22, 255),
    (0x8B, 0xA6, 0x78, 255), (0xA9, 0xC0, 0x94, 255), (0x6C, 0x86, 0x5E, 255), (0x4E, 0x66, 0x4A, 255),   # verde salvia apagado
    (0xD9, 0xD3, 0xB6, 255), (0xB7, 0xB0, 0x92, 255), (0xE9, 0xE4, 0xD0, 255), (0xF0, 0xEC, 0xDA, 255),   # vientre / esclerótica envejecida
    (0x1C, 0x14, 0x24, 255), (0xFA, 0xF4, 0xDC, 255), (0x5E, 0x8A, 0x58, 255), (0x44, 0x68, 0x40, 255),
    (0x4A, 0x3A, 0x30, 255), (0xC8, 0x92, 0x88, 255), (0x4A, 0x2A, 0x2E, 255), (0xDA, 0xD4, 0xBE, 255), (0xB5, 0xAF, 0x98, 255),
    (0xC6, 0xBE, 0xA2, 255),                                                                              # 19 sombra del ojo
    (0xA8, 0x98, 0x7A, 255), (0x86, 0x78, 0x5E, 255),                                                     # 20-21 remiendo de tela
    (0xB9, 0xCE, 0xA4, 255), (0x6A, 0x5A, 0x4A, 255),                                                     # 22 pelusa, 23 hilo suelto
]
FI = {n: i for i, n in enumerate(FROG)}


def frog():
    """Ranita de peluche (32x32): cabeza grande, ojos saltones de pupila pequeña, sonrisa cosida demasiado ancha,
    pequeñas asimetrías, costuras visibles, tela con trama, un remiendo y un hilo suelto. Colores infantiles apagados.
    Sigue siendo claramente un peluche infantil: nada de sangre, ojos rojos ni deformaciones."""
    cv = Cv(32, 32)
    g = FI

    def sh(m, base='G', light='G_L', shadow='G_S', deep='G_D'):
        cv.shaded(m, g[base], g[light], g[shadow], g[deep], hb=1, sb=1, db=1)

    # patas traseras (sentada): la derecha un poco más corta y vencida
    sh(cv.ellipse(8, 27, 5, 3))
    sh(cv.ellipse(24, 27, 5, 2))
    for fx in (3, 6, 9):
        cv.put(fx, 29, g['G_S'])
    for fx in (22, 25, 28):
        cv.put(fx, 29, g['G_S'])
    # cuerpo pequeño
    body = cv.ellipse(16, 22, 8, 7)
    sh(body)
    belly = cv.ellipse(16, 24, 5, 4)
    cv.shaded(belly, g['BELLY'], g['HI'], g['BELLY_S'], None, hb=1, sb=1)
    # cruz de la farmacia en la barriga (apagada y algo torcida: se bordó a mano)
    for (x, y) in [(16, 21), (16, 22), (16, 23), (16, 24), (14, 22), (15, 22), (17, 22), (18, 23)]:
        cv.put(x, y, g['CROSS'])
    cv.put(16, 24, g['CROSS_D']); cv.put(18, 23, g['CROSS_D'])
    # bracitos pequeños pero claros; el izquierdo cuelga un poco más bajo
    sh(cv.capsule((9, 17), (5, 24), 1.7, 1.4))
    sh(cv.capsule((23, 17), (27, 22), 1.7, 1.4))
    for (x, y) in [(4, 25), (5, 25), (28, 23), (27, 23)]:
        cv.put(x, y, g['G_S'])
    # remiendo de tela en la pierna izquierda, con su puntada
    patch = cv.rect(5, 25, 8, 27) & cv.ellipse(8, 27, 5, 3)
    cv.a[patch] = g['PATCH']
    for (x, y) in [(5, 25), (7, 25), (6, 27), (8, 27)]:
        if patch[y, x]:
            cv.put(x, y, g['PATCH_S'])
    # cabeza grande y ancha
    head = cv.ellipse(16, 12, 12, 7)
    sh(head)
    # ojos saltones y desiguales: el derecho algo más alto y grande; pupilas MUY pequeñas
    for cx, cy, r in ((9, 6, 4), (23, 5, 4)):
        bump = cv.ellipse(cx, cy, r, r)
        sh(bump)
        cv.a[cv.ellipse(cx, cy, r - 1, r - 1)] = g['EYEW']
        # sombra de párpado arriba y borde inferior algo amarillento: ojos de tela vieja
        cv.a[cv.rect(cx - r + 1, cy - r + 1, cx + r - 1, cy - r + 1) & cv.ellipse(cx, cy, r - 1, r - 1)] = g['EYE_S']
        cv.a[cv.rect(cx - r + 1, cy + r - 1, cx + r - 1, cy + r - 1) & cv.ellipse(cx, cy, r - 1, r - 1)] = g['EYE_S']
    # pupilas: 2x2 (la derecha 2x3), pequeñas y ligeramente desiguales; el brillo va en la esclerótica, no en la pupila
    cv.a[cv.rect(10, 7, 11, 8)] = g['PUPIL']
    cv.a[cv.rect(22, 6, 23, 8)] = g['PUPIL']
    cv.put(8, 5, g['HI'])
    cv.put(21, 4, g['HI'])
    # mejillas desvaídas
    cv.a[cv.ellipse(6, 14, 2, 1)] = g['BLUSH']
    cv.a[cv.ellipse(26, 14, 2, 1)] = g['BLUSH']
    # sonrisa cosida demasiado ancha: casi de lado a lado, puntadas alternas, remata en arco arriba a la derecha
    smile = [(5, 12), (6, 13), (7, 14), (8, 15), (9, 15), (10, 16), (11, 16), (12, 16), (13, 16), (14, 16), (15, 16), (16, 16),
             (17, 16), (18, 16), (19, 16), (20, 16), (21, 15), (22, 15), (23, 15), (24, 14), (25, 13), (26, 12), (27, 11)]
    for i, (x, y) in enumerate(smile):
        cv.put(x, y, g['MOUTH'] if i % 2 == 0 else g['STITCH'])
    # hilo suelto en la comisura izquierda
    cv.put(4, 12, g['THREAD']); cv.put(3, 13, g['THREAD']); cv.put(3, 14, g['THREAD'])
    # gorrito de la farmacia, ladeado
    cap = cv.poly([(12, 5), (20, 5), (21, 3), (20, 1), (12, 1), (11, 3)])
    cv.shaded(cap, g['CAP'], g['HI'], g['CAP_S'], None, hb=1, sb=1)
    for (x, y) in [(16, 1), (16, 2), (16, 3), (15, 2), (17, 2)]:
        cv.put(x, y, g['CROSS'])
    # costuras visibles: cuello (puntada en cruz), costado de la barriga y de la cabeza
    for x in range(10, 23, 2):
        cv.put(x, 18, g['STITCH'])
        cv.put(x + 1, 19, g['STITCH']) if 11 <= x + 1 <= 21 and (x % 4 == 0) else None
    for y in range(26, 30, 2):
        cv.put(16, y, g['STITCH'])
    cv.put(12, 25, g['STITCH']); cv.put(20, 25, g['STITCH'])
    for y in (9, 11):
        cv.put(15, y, g['G_S']); cv.put(18, y + 1, g['G_S'])
    # trama de tela: moteado determinista sobre el verde, y pelusa en el contorno
    base = (cv.a == g['G'])
    for y in range(cv.h):
        for x in range(cv.w):
            if base[y, x] and (x * 7 + y * 13) % 11 == 0:
                cv.a[y, x] = g['G_L'] if (x + y) % 2 == 0 else g['G_S']
    cv.outline(g['OUT'])
    for (x, y) in [(2, 22), (30, 20), (3, 18), (29, 26), (14, 0)]:
        if cv.a[y, x] == 0:
            cv.put(x, y, g['FUZZ'])
    return cv, FROG_PAL, (16, 26)       # agarre: la barriguita / patitas


# ---- caja de medicinas 16x22 ----
def pill_box(body, light, shadow, accent, name_color):
    pal = [(0, 0, 0, 0), (0x2B, 0x1A, 0x22, 255), body, light, shadow, accent, (0xF8, 0xF2, 0xE0, 255), name_color,
           (0x6A, 0x5A, 0x4A, 255)]
    cv = Cv(16, 22)
    m = cv.rect(1, 1, 14, 20)
    cv.shaded(m, 2, 3, 4, None, hb=1, sb=1)
    # solapa superior
    cv.a[cv.rect(1, 1, 14, 3)] = 3
    cv.a[cv.rect(1, 3, 14, 3)] = 4
    # etiqueta blanca y cruz
    cv.a[cv.rect(3, 6, 12, 15)] = 6
    for (x, y) in [(7, 7), (8, 7), (7, 8), (8, 8), (6, 9), (7, 9), (8, 9), (9, 9), (6, 10), (7, 10), (8, 10), (9, 10), (7, 11), (8, 11), (7, 12), (8, 12)]:
        pass
    cv.a[cv.rect(7, 7, 8, 12)] = 5
    cv.a[cv.rect(5, 9, 10, 10)] = 5
    # líneas de texto
    cv.a[cv.rect(4, 13, 11, 13)] = 8
    cv.a[cv.rect(4, 15, 9, 15)] = 8
    cv.a[cv.rect(3, 18, 12, 18)] = 7       # franja con el color de la marca
    cv.outline(1)
    return cv, pal, (8, 13)


def glass():
    """Vaso transparente con agua (14x22)."""
    pal = [(0, 0, 0, 0), (0x2B, 0x1A, 0x22, 255), (0xDD, 0xEE, 0xF8, 255), (0xBF, 0xE4, 0xFF, 255), (0x5A, 0xA6, 0xE8, 255),
           (0x3C, 0x84, 0xC8, 255), (0xFF, 0xFF, 0xFF, 255), (0x9A, 0xC8, 0xE0, 255)]
    cv = Cv(14, 22)
    body = cv.poly([(1, 1), (12, 1), (11, 20), (2, 20)])
    cv.a[body] = 2
    water = cv.poly([(2, 8), (11, 8), (10, 19), (3, 19)])
    cv.shaded(water, 4, 3, 5, None, hb=1, sb=1)
    cv.a[cv.rect(2, 8, 11, 8) & body] = 3
    cv.a[cv.rect(3, 3, 3, 15) & body] = 6        # brillo del cristal
    cv.a[cv.rect(10, 4, 10, 17) & body] = 7
    cv.a[cv.rect(2, 19, 11, 20) & body] = 7
    cv.outline(1)
    return cv, pal, (7, 14)


def all_items():
    out = {}
    cv, pal, grip = frog()
    out['frog_plush'] = (cv, pal, grip)
    out['pill_box_blue'] = pill_box((0x5A, 0x8F, 0xE0, 255), (0x86, 0xB4, 0xF2, 255), (0x3A, 0x68, 0xB4, 255), (0x3C, 0x84, 0xC8, 255), (0x2F, 0x5F, 0xA8, 255))
    out['pill_box_orange'] = pill_box((0xE8, 0x94, 0x4A, 255), (0xF8, 0xB8, 0x78, 255), (0xB8, 0x68, 0x28, 255), (0xD9, 0x4F, 0x3D, 255), (0xB8, 0x4A, 0x1A, 255))
    out['pill_box_white'] = pill_box((0xF2, 0xEE, 0xE0, 255), (0xFF, 0xFF, 0xF4, 255), (0xC9, 0xC4, 0xB4, 255), (0x4F, 0x9A, 0x3E, 255), (0x3C, 0x84, 0x36, 255))
    cv, pal, grip = glass()
    out['water_glass'] = (cv, pal, grip)
    return out
