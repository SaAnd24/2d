"""Genera app/src/main/java/com/terror2d/pixel/CreatureSpriteData.kt desde las REFERENCIAS de la criatura.

Uso:  python3 emit_creature.py   (desde tools/sprite_gen; necesita las dos imágenes de referencia SOLO aquí, en
desarrollo). La app no contiene ninguna imagen: únicamente las matrices de paleta que se escriben en el .kt (RLE:
índice de paleta + longitud, ambos como chr(48+n)). Rig y reducción: refrig.py / refparts.py / creature_ref.py.
"""
import os
import numpy as np
import creature_ref as cr
from emit_kotlin import rle

OUT = os.path.join(os.path.dirname(__file__), '..', '..', 'app', 'src', 'main', 'java', 'com', 'terror2d', 'pixel', 'CreatureSpriteData.kt')


def ks(a):
    return '        "%s"' % rle(a)


def ints(vals):
    return 'intArrayOf(' + ', '.join(str(int(v)) for v in vals) + ')'


def argb(c):
    r, g, b, a = c
    return '0x%02X%02X%02X%02X' % (a, r, g, b)


def main():
    L = []
    w = L.append
    w('package com.terror2d.pixel')
    w('')
    w('/**')
    w(' * DATOS GENERADOS por tools/sprite_gen (python3 emit_creature.py). NO editar a mano.')
    w(' * Diseño canónico v0.8: matrices de paleta obtenidas de las dos imágenes de referencia (frontal y caminando),')
    w(' * reducidas píxel a píxel (x6) y separadas en piezas (cabeza, pecho, vientre, brazos, piernas, ojos, bocas).')
    w(' * La app NO contiene las imágenes: solo estas matrices, que el motor pixelado dibuja y anima.')
    w(' */')
    w('object CreatureSpriteData {')
    w(f'    const val BODY_W = {cr.W}')
    w(f'    const val BODY_H = {cr.H}')
    w(f'    /** Columna del cuerpo que cae sobre el centro de la criatura (la cadera). */')
    w(f'    const val ANCHOR_X = {cr.ANCHOR_X}')
    w('    val PALETTE: IntArray = intArrayOf(' + ', '.join(argb(c) + '.toInt()' for c in cr.PAL) + ')')
    names = list(cr.POSES.keys())
    w('    /** Orden: IDLE, INVESTIGATE, ALERT, CAPTURE, HURT_LIGHT, WALK_0..7, RUN_0..7. */')
    w('    val BODY_POSES: Array<String> = arrayOf(' + ', '.join('"%s"' % n for n in names) + ')')
    bodies = [cr.build_body(n) for n in names]
    w('    val BODY_DATA: Array<String> = arrayOf(')
    w(',\n'.join(ks(b) for b, _ in bodies))
    w('    )')
    w('    /** Por pose: [headX, headY (esquina sup. izq. de la cabeza), bellyX, bellyY (centro del vientre), hombro delantero x,y, hombro trasero x,y, variante de cabeza]. */')
    w('    val BODY_ANCHORS: Array<IntArray> = arrayOf(' + ', '.join(
        ints(list(i['head']) + list(i['belly']) + list(i['lead']) + list(i['trail']) + [i['variant']]) for _, i in bodies) + ')')
    w(f'    val ARM_SWING: IntArray = {ints(cr.ARM_SWING)}')
    w(f'    val ARM_BEND: IntArray = {ints(cr.ARM_BEND)}')
    for lead, nm in ((True, 'LEAD'), (False, 'TRAIL')):
        arms = [cr.build_arm(si, bi, lead) for si in range(len(cr.ARM_SWING)) for bi in range(len(cr.ARM_BEND))]
        w(f'    /** Brazo {"delantero (delante del cuerpo)" if lead else "trasero (detrás del cuerpo)"}: índice = balanceo * {len(cr.ARM_BEND)} + codo. */')
        w(f'    val ARM_{nm}: Array<String> = arrayOf(')
        w(',\n'.join(ks(a) for a, _ in arms))
        w('    )')
        w(f'    /** [ancho, alto, hombroX, hombroY] de cada recorte de ARM_{nm}. */')
        w(f'    val ARM_{nm}_INFO: Array<IntArray> = arrayOf(' + ', '.join(ints(info) for _, info in arms) + ')')
    # cabezas (2 variantes con su propio tamaño)
    heads = [cr.head_sprite(v) for v in (0, 1)]
    w('    /** Cabeza 0 = frontal, 1 = girada (la de caminar). Cada una con su tamaño. */')
    w('    val HEAD_DATA: Array<String> = arrayOf(')
    w(',\n'.join(ks(h) for h, _ in heads))
    w('    )')
    w('    /** [ancho, alto] de cada variante de cabeza. */')
    w('    val HEAD_SIZES: IntArray = ' + ints([x for _, sz in heads for x in sz]))
    w('    val EYE_STATES: Array<String> = arrayOf(' + ', '.join('"%s"' % s for s in cr.EYE_STATES) + ')')
    ec, esz, eyeL, eyeR = [], [], [], []
    for v in (0, 1):
        hc = cr.HEAD_CELL[v]
        for side, store in (('L', eyeL), ('R', eyeR)):
            ps = cr.eye_patches(v, side)
            spr, pw, ph, (cxc, cyc) = ps[0]
            ec += [cxc - hc[0], cyc - hc[1]]
            esz.append(pw)
            store += [p[0] for p in ps]
    # EYE_CENTERS por variante: [Lx, Ly, Rx, Ry]
    w('    /** Por variante: centro del ojo trasero (x,y) y del delantero (x,y), en celdas de la cabeza. */')
    w(f'    val EYE_CENTERS: IntArray = {ints(ec)}')
    w('    /** Por variante: lado (cuadrado) del parche del ojo trasero y del delantero. */')
    w(f'    val EYE_SIZES: IntArray = {ints(esz)}')
    w('    /** Índice = variante * 5 + estado (OPEN, HALF, CLOSED, LOOK_DOWN, WIDE). */')
    w('    val EYE_DATA_L: Array<String> = arrayOf(')
    w(',\n'.join(ks(p) for p in eyeL))
    w('    )')
    w('    val EYE_DATA_R: Array<String> = arrayOf(')
    w(',\n'.join(ks(p) for p in eyeR))
    w('    )')
    w('    val MAIN_MOUTH_STATES: Array<String> = arrayOf(' + ', '.join('"%s"' % s for s in cr.MOUTH_NAMES) + ')')
    msz, mpos, mdata = [], [], []
    for v in (0, 1):
        ps = cr.main_mouth_patches(v)
        spr, pw, ph, (cxc, cyc) = ps[0]
        hc = cr.HEAD_CELL[v]
        msz += [pw, ph]
        mpos += [cxc - pw // 2 - hc[0], cyc - ph // 2 - hc[1]]
        mdata += [p[0] for p in ps]
    w('    /** Por variante: ancho y alto del parche de la sonrisa. */')
    w(f'    val MAIN_MOUTH_SIZES: IntArray = {ints(msz)}')
    w('    /** Por variante: esquina sup. izq. del parche en celdas de la cabeza. */')
    w(f'    val MAIN_MOUTH_POS: IntArray = {ints(mpos)}')
    w('    /** Índice = variante * 4 + estado (CLOSED = la sonrisa de la referencia; TENSE = tensa; OPEN/WIDE = abierta/gruñendo). */')
    w('    val MAIN_MOUTH_DATA: Array<String> = arrayOf(')
    w(',\n'.join(ks(p) for p in mdata))
    w('    )')
    sizes, origins, sdata, tm = [], [], [], []
    for i in range(7):
        ps = cr.belly_patches(i)
        spr, pw, ph, (cxc, cyc) = ps[0]
        sizes += [pw, ph]
        origins += [pw // 2, ph // 2]
        sdata += [p[0] for p in ps]
        tm.append([i, (cxc - cr.CELL0[0]) - cr.BELLY_C[0], (cyc - cr.CELL0[1]) - cr.BELLY_C[1], 0])
    w('    /** 7 bocas del vientre; 4 estados cada una (0 casi cerrada ... 3 = la boca de la referencia). Índice = boca * 4 + estado. */')
    w('    const val SEC_STATES = 4')
    w(f'    val SEC_SIZES: IntArray = {ints(sizes)}')
    w(f'    val SEC_ORIGINS: IntArray = {ints(origins)}')
    w('    val SEC_DATA: Array<String> = arrayOf(')
    w(',\n'.join(ks(p) for p in sdata))
    w('    )')
    w('    /** El diseño no tiene bocas secundarias en la cabeza (la sonrisa grande es la boca principal). */')
    w('    val HEAD_MOUTHS: Array<IntArray> = arrayOf()')
    w('    /** Bocas del vientre: [id de boca, x, y relativos al centro del vientre, 0]. */')
    w('    val TORSO_MOUTHS: Array<IntArray> = arrayOf(' + ', '.join(ints(t) for t in tm) + ')')
    w('}')
    open(OUT, 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    print('escrito', os.path.abspath(OUT), os.path.getsize(OUT), 'bytes')


if __name__ == '__main__':
    main()
