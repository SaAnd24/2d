"""Mini librería de pixel art (solo para GENERAR los datos del juego; el juego no usa Python).

Lienzo de índices de paleta (0 = transparente), máscaras booleanas y sombreado direccional
(luz arriba-izquierda). Sin antialiasing: todo son píxeles enteros.
"""
import numpy as np
from PIL import Image, ImageDraw

# ---------------------------------------------------------------- paleta (índices estables)
P = dict(
    T=0, OUT=1, HAIR=2, SKIN=3, SKIN_S=4, SHIRT=5, SHIRT_S=6, PANTS=7, PANTS_S=8, SHOES=9, EYE=10,
    RED=11, HI=12, SCARF=13, SCARF_S=14, MARK=15, SHOE_S=16,
    HAIR_D=17, HAIR_L=18, SKIN_L=19, SKIN_D=20, SHIRT_L=21, SHIRT_D=22, RED_D=23,
    PANTS_L=24, PANTS_D=25, SCARF_L=26, SHOE_M=27, SOLE=28, SCLERA=29, IRIS=30, IRIS_D=31,
    BLUSH=32, LIP=33, MOUTH=34, LID=35, TEETH=36, LACE=37,
)
PALETTE = [
    (0, 0, 0, 0),
    (0x2B, 0x1A, 0x22, 255),   # 1 contorno
    (0x7A, 0x4A, 0x2A, 255),   # 2 pelo
    (0xFF, 0xD2, 0xA8, 255),   # 3 piel
    (0xE5, 0xA5, 0x7F, 255),   # 4 sombra piel
    (0xF0, 0x8A, 0x2E, 255),   # 5 suéter
    (0xC9, 0x6A, 0x1A, 255),   # 6 sombra suéter
    (0xB8, 0x99, 0x68, 255),   # 7 pantalón
    (0x8E, 0x74, 0x48, 255),   # 8 sombra pantalón
    (0xF4, 0xF0, 0xE6, 255),   # 9 zapatos
    (0x1C, 0x14, 0x24, 255),   # 10 ojo
    (0xD0, 0x3A, 0x2E, 255),   # 11 línea roja
    (0xFF, 0xF6, 0xD8, 255),   # 12 brillo
    (0x8E, 0x1F, 0x2E, 255),   # 13 bufanda
    (0x5E, 0x12, 0x20, 255),   # 14 sombra bufanda
    (0xB5, 0x54, 0x3F, 255),   # 15 marca
    (0xB8, 0xB4, 0xC8, 255),   # 16 sombra zapatos
    (0x55, 0x32, 0x1C, 255),   # 17 pelo oscuro
    (0xA3, 0x6E, 0x42, 255),   # 18 pelo claro
    (0xFF, 0xE6, 0xCC, 255),   # 19 piel clara
    (0xC4, 0x84, 0x62, 255),   # 20 piel profunda
    (0xFF, 0xAE, 0x54, 255),   # 21 suéter claro
    (0x9C, 0x4E, 0x14, 255),   # 22 suéter profundo
    (0x8E, 0x24, 0x1C, 255),   # 23 rojo oscuro
    (0xD2, 0xB4, 0x84, 255),   # 24 pantalón claro
    (0x68, 0x52, 0x32, 255),   # 25 pantalón profundo
    (0xB8, 0x3A, 0x48, 255),   # 26 bufanda clara
    (0xA8, 0xA4, 0xB8, 255),   # 27 zapato medio
    (0x4A, 0x44, 0x56, 255),   # 28 suela
    (0xFA, 0xF6, 0xEC, 255),   # 29 esclerótica
    (0x8A, 0x52, 0x2A, 255),   # 30 iris
    (0x4A, 0x2A, 0x16, 255),   # 31 iris oscuro
    (0xF2, 0x9A, 0x8C, 255),   # 32 rubor
    (0xC4, 0x5A, 0x5A, 255),   # 33 labio
    (0x6A, 0x24, 0x2E, 255),   # 34 interior boca
    (0xD9, 0x96, 0x72, 255),   # 35 párpado
    (0xFF, 0xFF, 0xF4, 255),   # 36 dientes
    (0x8E, 0x8C, 0xA8, 255),   # 37 cordón
]


class Cv:
    def __init__(self, w, h):
        self.w, self.h = w, h
        self.a = np.zeros((h, w), dtype=np.int32)

    # ---- máscaras
    def blank(self):
        return np.zeros((self.h, self.w), dtype=bool)

    def ellipse(self, cx, cy, rx, ry):
        yy, xx = np.mgrid[0:self.h, 0:self.w]
        return ((xx - cx) / (rx + 0.5)) ** 2 + ((yy - cy) / (ry + 0.5)) ** 2 <= 1.0

    def rect(self, x0, y0, x1, y1):
        m = self.blank()
        m[max(0, y0):min(self.h, y1 + 1), max(0, x0):min(self.w, x1 + 1)] = True
        return m

    def poly(self, pts):
        im = Image.new('L', (self.w, self.h), 0)
        ImageDraw.Draw(im).polygon([(float(x), float(y)) for x, y in pts], fill=255)
        return np.array(im) > 0

    def capsule(self, p0, p1, r0, r1=None):
        """Segmento con extremos redondeados y grosor variable (para extremidades)."""
        if r1 is None:
            r1 = r0
        yy, xx = np.mgrid[0:self.h, 0:self.w]
        x0, y0 = p0
        x1, y1 = p1
        dx, dy = x1 - x0, y1 - y0
        L2 = dx * dx + dy * dy
        if L2 == 0:
            t = np.zeros_like(xx, dtype=float)
        else:
            t = np.clip(((xx - x0) * dx + (yy - y0) * dy) / L2, 0, 1)
        px, py = x0 + t * dx, y0 + t * dy
        r = r0 + (r1 - r0) * t
        return (xx - px) ** 2 + (yy - py) ** 2 <= (r + 0.35) ** 2

    # ---- relleno y sombreado
    def fill(self, m, c, only_empty=False):
        if only_empty:
            m = m & (self.a == 0)
        self.a[m] = c

    @staticmethod
    def shift(m, dx, dy):
        out = np.zeros_like(m)
        h, w = m.shape
        ys0, ys1 = max(0, dy), min(h, h + dy)
        xs0, xs1 = max(0, dx), min(w, w + dx)
        out[ys0:ys1, xs0:xs1] = m[ys0 - dy:ys1 - dy, xs0 - dx:xs1 - dx]
        return out

    def shaded(self, m, base, light=None, shadow=None, deep=None, hb=1, sb=2, db=1):
        """Relleno con volumen: borde iluminado arriba-izquierda, sombra abajo-derecha."""
        self.a[m] = base
        if shadow is not None:
            sh = self.blank()
            for k in range(1, sb + 1):
                sh |= m & ~self.shift(m, -k, -k)   # el vecino abajo-derecha está fuera
                sh |= m & ~self.shift(m, -k, 0) & (k == 1)
            self.a[sh & m] = shadow
            if deep is not None:
                dp = m & ~self.shift(m, -db, -db) & ~self.shift(m, -db, 0)
                self.a[dp & m] = deep
        if light is not None:
            lt = self.blank()
            for k in range(1, hb + 1):
                lt |= m & ~self.shift(m, k, k)
            self.a[lt & m & (self.a == base)] = light

    def outline(self, c, m=None, inner=False):
        """Contorno exterior de 1 px (4 vecinos) alrededor de lo dibujado (o de la máscara m)."""
        src = (self.a != 0) if m is None else m
        nb = np.zeros_like(src)
        nb |= self.shift(src, 1, 0) | self.shift(src, -1, 0) | self.shift(src, 0, 1) | self.shift(src, 0, -1)
        edge = nb & ~src & (self.a == 0)
        self.a[edge] = c

    def sel_outline(self, m, c):
        """Contorno interior de la parte (se dibuja sobre sus propios píxeles de borde)."""
        edge = m & ~(self.shift(m, 1, 0) & self.shift(m, -1, 0) & self.shift(m, 0, 1) & self.shift(m, 0, -1))
        self.a[edge] = c

    def put(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.a[y, x] = c

    def ascii(self, x0, y0, rows, legend, flip=False):
        """Estampa arte ASCII (cada carácter = índice de paleta; '.' = no tocar)."""
        for j, row in enumerate(rows):
            r = row[::-1] if flip else row
            for i, ch in enumerate(r):
                if ch == '.':
                    continue
                self.put(x0 + i, y0 + j, legend[ch])

    def line(self, x0, y0, x1, y1, c):
        n = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
        for i in range(n + 1):
            t = i / max(1, n)
            self.put(int(round(x0 + (x1 - x0) * t)), int(round(y0 + (y1 - y0) * t)), c)


def to_image(cv, scale=1, bg=(236, 226, 200)):
    arr = np.zeros((cv.h, cv.w, 4), dtype=np.uint8)
    for i, c in enumerate(PALETTE):
        arr[cv.a == i] = c
    im = Image.fromarray(arr, 'RGBA')
    base = Image.new('RGBA', im.size, bg + (255,))
    base.alpha_composite(im)
    return base.resize((cv.w * scale, cv.h * scale), Image.NEAREST)
