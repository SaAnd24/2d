"""EL PROTAGONISTA 96x128 (pixel art, de perfil mirando a la derecha).

Niño de 8 años: pelo castaño despeinado, suéter naranja con línea roja, pantalón caqui, zapatos blancos,
bufanda rojo oscuro y una marca en la mejilla. Mismo tamaño en pantalla que el sprite 48x64 anterior
(el renderer lo dibuja a escala 0.5), con el DOBLE de píxeles dentro de la misma silueta.

Cada pose = parámetros. La cara (ojos y boca) NO está en la imagen base: son parches intercambiables
(parpadeo / expresiones) que el juego coloca sobre el ancla de la cabeza de cada pose.
"""
import numpy as np
from pixlib import Cv, P

W, H = 96, 128
AX = 46            # columna del centro del cuerpo (anchor)
GROUND = H - 1

ARM_HANG, ARM_HOLD, ARM_GIVE, ARM_PICK, ARM_HIDE = range(5)


class Pose:
    def __init__(self, bob=0, crouch=0, front=0, back=0, head_dx=0, head_dy=0, arms=ARM_HANG,
                 sway=0, lean=0, lift_back=0, lift_front=0, scarf=0, hair=0, name=''):
        self.bob, self.crouch, self.front, self.back = bob, crouch, front, back
        self.head_dx, self.head_dy, self.arms = head_dx, head_dy, arms
        self.sway, self.lean, self.lift_back, self.lift_front = sway, lean, lift_back, lift_front
        self.scarf, self.hair, self.name = scarf, hair, name


# ------------------------------------------------------------------ piezas
def shoe(cv, x, y, lift=0, toe_up=0):
    """Zapatilla blanca de perfil (puntera a la derecha). (x, y) = esquina sup. izquierda del talón."""
    y -= lift
    body = cv.poly([(x + 1, y + 1), (x + 8, y + 1), (x + 10, y + 3), (x + 15, y + 4), (x + 18, y + 6),
                    (x + 18, y + 9), (x, y + 9), (x, y + 3)])
    cv.shaded(body, P['SHOES'], P['HI'], P['SHOE_S'], None, hb=1, sb=1)
    # suela
    sole = cv.rect(x, y + 8, x + 18, y + 9)
    sole &= body | cv.rect(x, y + 8, x + 18, y + 9)
    cv.a[sole & body] = P['SOLE']
    cv.a[cv.rect(x + 1, y + 7, x + 17, y + 7) & body] = P['SHOE_M']
    # puntera de goma y cordones
    for yy in range(y + 5, y + 8):
        cv.put(x + 17, yy, P['SHOE_M'])
    cv.put(x + 16, y + 5, P['SHOE_M'])
    for i, lx in enumerate((x + 8, x + 10, x + 12)):
        cv.put(lx, y + 3 + (i // 2), P['LACE'])
        cv.put(lx + 1, y + 4 + (i // 2), P['SHOE_S'])
    # borde del tobillo y talón
    cv.a[cv.rect(x + 2, y + 1, x + 7, y + 1) & body] = P['SHOE_S']
    cv.put(x + 1, y + 4, P['SHOE_M'])
    cv.put(x + 1, y + 5, P['SHOE_M'])
    return body


def leg(cv, hx, ankle_x, hip_y, ankle_y, pants, light, shadow, deep, back=False, knee_bend=0):
    """Pierna con pantalón largo: del cadera al tobillo, con rodilla y dobladillo."""
    kx = (hx + ankle_x) / 2 + knee_bend
    ky = (hip_y + ankle_y) / 2
    m = cv.capsule((hx, hip_y), (kx, ky), 5.0, 4.6) | cv.capsule((kx, ky), (ankle_x, ankle_y), 4.6, 4.0)
    cv.shaded(m, pants, light, shadow, deep, hb=1, sb=2, db=1)
    # pliegues de la rodilla y dobladillo
    for dx in (-2, 0, 2):
        cv.put(int(kx) + dx, int(ky) - 1 + abs(dx) // 2, shadow)
    cv.put(int(kx) - 1, int(ky) + 1, deep)
    hem_y = int(ankle_y) - 1
    cv.a[cv.rect(int(ankle_x) - 5, hem_y, int(ankle_x) + 4, hem_y) & m] = deep
    cv.a[cv.rect(int(ankle_x) - 5, hem_y - 2, int(ankle_x) + 4, hem_y - 2) & m] = light
    return m


def hand_hang(cv, x, y, back=False):
    """Mano relajada colgando (dedos curvados, pulgar al frente). (x, y) = muñeca (arriba al centro)."""
    sk, sh, dp, hi = (P['SKIN_S'], P['SKIN_D'], P['SKIN_D'], P['SKIN']) if back else (P['SKIN'], P['SKIN_S'], P['SKIN_D'], P['SKIN_L'])
    rows = [
        ".hhhhh.",
        ".sssssd",
        ".ssssdd",
        ".sssssd",
        ".sssssd",
        ".ssssd.",
        "..ssdd.",
        "..dsd..",
    ]
    leg_ = {'h': hi, 's': sk, 'd': sh, '.': None}
    for j, row in enumerate(rows):
        for i, ch in enumerate(row):
            if leg_[ch] is not None:
                cv.put(x - 3 + i, y + j, leg_[ch])
    # separación de dedos
    cv.put(x - 1, y + 5, dp)
    cv.put(x, y + 6, dp)
    cv.put(x + 1, y + 4, dp)
    # pulgar
    cv.put(x + 3, y + 1, hi)
    cv.put(x + 4, y + 2, sk)
    cv.put(x + 4, y + 3, sh)


def hand_grip(cv, x, y, back=False):
    """Mano que sujeta (dedos hacia el espectador, rodeando el objeto). (x, y) = centro del agarre."""
    sk, sh, dp, hi = (P['SKIN_S'], P['SKIN_D'], P['SKIN_D'], P['SKIN']) if back else (P['SKIN'], P['SKIN_S'], P['SKIN_D'], P['SKIN_L'])
    rows = [
        "..hhhhh..",
        ".hssssssd",
        ".ssssssdd",
        ".sdddddsd",     # dedo 1
        ".ssssssdd",
        ".sdddddsd",     # dedo 2
        ".ssssssdd",
        ".sdddddsd",     # dedo 3
        "..sssssd.",
        "...dsdd..",
    ]
    m = {'h': hi, 's': sk, 'd': sh, '.': None}
    for j, row in enumerate(rows):
        for i, ch in enumerate(row):
            if m[ch] is not None:
                cv.put(x - 4 + i, y - 4 + j, m[ch])
    # pulgar sobre el borde del objeto
    cv.a[y - 6:y - 4, x - 2:x + 2] = np.where(cv.a[y - 6:y - 4, x - 2:x + 2] == 0, hi, cv.a[y - 6:y - 4, x - 2:x + 2])
    cv.put(x - 1, y - 6, hi)
    cv.put(x, y - 6, hi)
    cv.put(x + 1, y - 5, sk)


def hand_open(cv, x, y, back=False, down=False):
    """Mano abierta mirando hacia delante (entregar / alcanzar). (x, y) = muñeca."""
    sk, sh, dp, hi = (P['SKIN_S'], P['SKIN_D'], P['SKIN_D'], P['SKIN']) if back else (P['SKIN'], P['SKIN_S'], P['SKIN_D'], P['SKIN_L'])
    if not down:
        rows = [
            "hhhhhhhh.",
            "ssssssssd",
            "sssssssdd",
            "ssdddddd.",
            "sssssssd.",
            "ssdddddd.",
            "ssssssd..",
            ".ssdddd..",
            "..ddd....",
        ]
    else:
        rows = [
            ".hhhhh...",
            ".sssssd..",
            ".ssssdd..",
            ".sdddsd..",
            ".ssssdd..",
            ".sdddsd..",
            ".ssssdd..",
            ".sdddsd..",
            ".sssssd..",
            "..dsdd...",
        ]
    m = {'h': hi, 's': sk, 'd': sh, '.': None}
    for j, row in enumerate(rows):
        for i, ch in enumerate(row):
            if m[ch] is not None:
                cv.put(x + i - 1, y + j - 1, m[ch])


def sleeve(cv, p0, p1, p2, back=False):
    """Manga de lana (hombro -> codo -> muñeca) con puño acanalado y línea roja."""
    base, light, sh, deep = ((P['SHIRT_S'], P['SHIRT'], P['SHIRT_D'], P['SHIRT_D']) if back
                             else (P['SHIRT'], P['SHIRT_L'], P['SHIRT_S'], P['SHIRT_D']))
    m = cv.capsule(p0, p1, 4.4, 4.0) | cv.capsule(p1, p2, 4.0, 3.5)
    cv.shaded(m, base, light, sh, deep, hb=1, sb=1, db=1)
    # lana: puntitos
    ys, xs = np.nonzero(m)
    for y, x in zip(ys, xs):
        if (x + 2 * y) % 5 == 0 and cv.a[y, x] == base:
            cv.a[y, x] = sh
    # línea roja en el bíceps
    mx, my = (p0[0] * 0.55 + p1[0] * 0.45), (p0[1] * 0.55 + p1[1] * 0.45)
    red = P['RED_D'] if back else P['RED']
    stripe = m & cv.capsule((mx - 2, my - 1), (mx + 2, my + 1), 1.0) 
    # puño acanalado
    cx, cy = int(p2[0]), int(p2[1])
    cuff = m & cv.ellipse(cx, cy, 5, 2)
    cv.a[cuff] = P['SHIRT_D'] if back else P['SHIRT_S']
    for dx in range(-4, 5, 2):
        for dy in (-1, 0, 1):
            if cuff[cy + dy, cx + dx]:
                cv.a[cy + dy, cx + dx] = P['SHIRT_D']
    return m


def build(p: Pose):
    """Devuelve (base, fg, info) con info = dict(head=(hx,hy), hand=(x,y) o None)."""
    cv = Cv(W, H)
    fgm = cv.blank()
    u = p.bob + p.crouch
    ax = AX + p.lean
    info = {}

    # ---------- brazo trasero
    def arm_points(back):
        sx = ax - 1 if back else ax + 6
        sy = 72 + u
        if p.arms == ARM_HANG or p.arms == ARM_HIDE:
            sw = (-p.front // 2 if back else -p.back // 2) * 1.3
            if back:
                sw = p.front * -0.4 + 0
            else:
                sw = p.back * -0.4
            return (sx, sy), (sx + sw * 0.5, sy + 13), (sx + sw, sy + 25)
        if p.arms == ARM_HOLD:
            if back:
                return (sx, sy), (sx + 1, sy + 13), (sx + 3, sy + 25)
            return (sx, sy), (sx + 5, sy + 13), (sx + 17, sy + 17)
        if p.arms == ARM_GIVE:
            if back:
                return (sx, sy), (sx + 1, sy + 13), (sx + 3, sy + 25)
            return (sx, sy), (sx + 11, sy + 6), (sx + 24, sy + 9)
        # ARM_PICK
        if back:
            return (sx, sy), (sx + 6, sy + 12), (sx + 14, sy + 22)
        return (sx, sy), (sx + 10, sy + 11), (sx + 20, sy + 21)

    bs, be, bw = arm_points(True)
    m_back = sleeve(cv, bs, be, bw, back=True)
    if p.arms in (ARM_HANG, ARM_HIDE):
        hand_hang(cv, int(bw[0]), int(bw[1]) + 3, back=True)
    elif p.arms == ARM_HOLD or p.arms == ARM_GIVE:
        hand_hang(cv, int(bw[0]), int(bw[1]) + 3, back=True)
    else:
        hand_open(cv, int(bw[0]), int(bw[1]) + 2, back=True, down=True)

    # ---------- pierna trasera (más oscura) y delantera
    ground = GROUND
    ankle_y = 119
    back_ax = 43 + p.back
    front_ax = 51 + p.front
    leg_back = leg(cv, 44, back_ax, 96 + u, ankle_y - p.lift_back, P['PANTS_S'], P['PANTS'], P['PANTS_D'], P['PANTS_D'],
                   back=True, knee_bend=(-2 if p.back > 0 else 1))
    shoe(cv, back_ax - 6, ground - 8, lift=p.lift_back)
    # ---------- torso: suéter de lana
    torso = cv.poly([(35, 70 + u), (40, 66 + u), (54, 66 + u), (61, 70 + u), (64, 78 + u), (64, 96 + u),
                     (36, 96 + u), (34, 84 + u)])
    cv.shaded(torso, P['SHIRT'], P['SHIRT_L'], P['SHIRT_S'], P['SHIRT_D'], hb=2, sb=2, db=1)
    # lana: trama de puntos en "V"
    for y in range(68 + u, 92 + u):
        for x in range(38, 61):
            if torso[y, x] and cv.a[y, x] == P['SHIRT'] and ((x + y) % 4 == 0 and y % 3 != 0):
                cv.a[y, x] = P['SHIRT_L']
            elif torso[y, x] and cv.a[y, x] == P['SHIRT'] and (x - y) % 6 == 0:
                cv.a[y, x] = P['SHIRT_S']
    # línea roja del pecho (con relieve)
    ry = 79 + u
    stripe = cv.rect(37, ry, 61, ry + 3) & torso
    cv.a[stripe] = P['RED']
    cv.a[cv.rect(37, ry + 3, 61, ry + 3) & torso] = P['RED_D']
    cv.a[cv.rect(37, ry, 61, ry) & torso] = P['SHIRT_L']
    for x in range(38, 61, 3):
        if torso[ry + 1, x]:
            cv.a[ry + 1, x] = P['RED_D']
    # pliegues del suéter (cintura y costado)
    for i in range(5):
        cv.put(42 + i, 90 + u - i // 2, P['SHIRT_D'])
    for i in range(4):
        cv.put(52 + i, 88 + u + i // 2, P['SHIRT_S'])
    # dobladillo acanalado
    hem = cv.rect(37, 91 + u, 61, 96 + u) & torso
    cv.a[hem] = P['SHIRT_S']
    for x in range(38, 61, 2):
        for y in range(92 + u, 96 + u):
            if hem[y, x]:
                cv.a[y, x] = P['SHIRT_D']
    cv.a[cv.rect(37, 91 + u, 61, 91 + u) & torso] = P['SHIRT_L']

    # ---------- pierna delantera
    leg_front = leg(cv, 51, front_ax, 96 + u, ankle_y - p.lift_front, P['PANTS'], P['PANTS_L'], P['PANTS_S'], P['PANTS_D'],
                    knee_bend=(2 if p.front > 0 else -1))
    shoe(cv, front_ax - 6, ground - 8, lift=p.lift_front)
    # cinturón/pretina bajo el suéter
    cv.a[cv.rect(39, 96 + u, 60, 96 + u) & (leg_back | leg_front)] = P['PANTS_D']

    # ---------- bufanda
    sc = p.scarf
    tail = cv.poly([(34, 66 + u), (42, 66 + u), (42 + sc // 2, 92 + u), (34 + sc, 92 + u)])
    cv.shaded(tail, P['SCARF'], P['SCARF_L'], P['SCARF_S'], P['SCARF_S'], hb=1, sb=2)
    cv.a[cv.rect(30, 87 + u, 46, 92 + u) & tail] = P['SCARF_S']
    for y in range(68 + u, 91 + u, 4):
        cv.a[cv.rect(30, y, 46, y) & tail] = P['SCARF_L']
    for y in range(88 + u, 92 + u):          # flecos
        for x in range(34 + sc, 43 + sc // 2, 2):
            cv.put(x, y + 1, P['SCARF_S'] if y % 2 else P['SCARF'])
    wrap = cv.ellipse(49, 64 + u, 14, 5) | cv.rect(38, 60 + u, 61, 67 + u) & cv.ellipse(49, 64 + u, 15, 7)
    cv.shaded(wrap, P['SCARF'], P['SCARF_L'], P['SCARF_S'], P['SCARF_S'], hb=1, sb=2)
    for x in range(38, 62, 3):               # vueltas de lana
        for k in range(5):
            if wrap[60 + u + k, x + k % 2]:
                cv.a[60 + u + k, x + k % 2] = P['SCARF_S'] if k % 2 == 0 else P['SCARF_L']

    # ---------- cabeza
    hx = 51 + p.head_dx + p.lean
    hy = 47 + u + p.head_dy
    info['head'] = (hx, hy)
    cv.a[cv.rect(hx - 4, hy + 14, hx + 5, 64 + u) & ~(wrap)] = P['SKIN_S']     # cuello
    head = cv.ellipse(hx, hy, 17, 16)
    jaw = cv.poly([(hx + 2, hy + 14), (hx + 13, hy + 13), (hx + 17, hy + 7), (hx + 17, hy), (hx - 4, hy + 4)])
    nose = cv.rect(hx + 18, hy + 4, hx + 20, hy + 8)
    nose[hy + 4, hx + 20] = False
    nose[hy + 8, hx + 20] = False
    skull = head | (jaw & cv.ellipse(hx + 1, hy + 1, 18, 17)) | nose
    cv.shaded(skull, P['SKIN'], P['SKIN_L'], P['SKIN_S'], None, hb=2, sb=2)
    # sombra bajo la barbilla / mandíbula
    under = skull & (cv.poly([(hx - 12, hy + 13), (hx + 14, hy + 13), (hx + 9, hy + 17), (hx - 12, hy + 17)]))
    cv.a[under] = P['SKIN_S']
    # nariz: punta, ala y sombra
    cv.put(hx + 20, hy + 5, P['SKIN_L'])
    cv.put(hx + 20, hy + 6, P['SKIN'])
    cv.put(hx + 19, hy + 8, P['SKIN_D'])
    cv.put(hx + 18, hy + 8, P['SKIN_S'])
    cv.put(hx + 17, hy + 9, P['SKIN_S'])
    cv.put(hx + 19, hy + 7, P['SKIN_S'])
    # oreja (con relieve)
    ear = cv.ellipse(hx - 6, hy + 4, 3, 5)
    cv.shaded(ear, P['SKIN'], P['SKIN_L'], P['SKIN_S'], P['SKIN_D'], hb=1, sb=1)
    cv.a[cv.ellipse(hx - 6, hy + 4, 1, 3)] = P['SKIN_D']
    cv.put(hx - 7, hy + 2, P['SKIN_S'])
    cv.put(hx - 5, hy + 3, P['SKIN_S'])
    # rubor y marca de la mejilla
    cv.a[cv.ellipse(hx + 8, hy + 10, 3, 2) & skull] = P['BLUSH']
    for i, (dx, dy) in enumerate([(2, 7), (3, 8), (3, 9), (4, 10), (5, 11)]):
        cv.put(hx + dx, hy + dy, P['MARK'])
    cv.put(hx + 1, hy + 7, P['SKIN_D'])
    cv.put(hx + 4, hy + 11, P['SKIN_D'])
    cv.put(hx + 5, hy + 8, P['MARK'])
    cv.put(hx + 6, hy + 9, P['MARK'])

    # ---------- pelo castaño despeinado
    hair = cv.blank()
    cap = cv.ellipse(hx - 1, hy - 4, 19, 17)
    fringe_edge = lambda x: hy - 9 + int(3 * np.sin(x * 0.9)) 
    ys, xs = np.mgrid[0:H, 0:W]
    top = cap & (ys <= hy - 8 + ((xs * 5 + 2) % 7 - 2) // 2 + np.clip((xs - hx) // 4, -1, 4))
    back = cap & (xs <= hx - 4) & (ys <= hy + 9)
    nape = cv.ellipse(hx - 10, hy + 6, 7, 9) & (xs <= hx - 5)
    sideburn = cv.rect(hx - 4, hy - 2, hx - 1, hy + 5)
    hair = (top | back | nape | sideburn) & (skull | cap) & ~(cv.ellipse(hx - 6, hy + 4, 3, 5)) 
    # mechones de fleco que caen sobre la frente
    tufts = [(hx + 14, hy - 8, 3, 4), (hx + 10, hy - 9, 3, 5), (hx + 6, hy - 9, 3, 3), (hx + 2, hy - 9, 3, 4),
             (hx - 2, hy - 9, 2, 3)]
    for (tx, ty, tw, th) in tufts:
        hair |= cv.poly([(tx, ty - 2), (tx + tw, ty - 2), (tx + tw - 1, ty + th), (tx + 1, ty + th - 1)])
    # remolinos y puntas sueltas arriba (despeinado)
    sw = p.hair
    spikes = [(hx - 12, hy - 14, hx - 15 - sw, hy - 18), (hx - 6, hy - 17, hx - 8 - sw, hy - 22),
              (hx + 1, hy - 18, hx + 1 - sw, hy - 21), (hx + 8, hy - 15, hx + 11 - sw, hy - 19),
              (hx - 15, hy - 6, hx - 20 - sw, hy - 6), (hx - 16, hy + 1, hx - 20 - sw, hy + 4)]
    for (x0, y0, x1, y1) in spikes:
        hair |= cv.capsule((x0, y0), (x1, y1), 2.0, 0.5)
    cv.shaded(hair, P['HAIR'], P['HAIR_L'], P['HAIR_D'], None, hb=2, sb=2)
    # hebras: trazos que siguen la curva del pelo
    rng = np.random.RandomState(7)
    for _ in range(60):
        x = int(rng.randint(hx - 18, hx + 15))
        y = int(rng.randint(hy - 22, hy + 6))
        if 0 <= y < H and 0 <= x < W and hair[y, x] and cv.a[y, x] in (P['HAIR'],):
            cv.put(x, y, P['HAIR_D'] if (x + y) % 3 else P['HAIR_L'])
            if hair[y + 1, x - 1]:
                cv.put(x - 1, y + 1, P['HAIR_D'])
    # brillo del pelo: un arco continuo (sin tramado)
    for x in range(hx - 11, hx + 7):
        y = hy - 14 + int(((x - hx + 3) ** 2) / 20)
        for yy in (y, y + 1):
            if 0 <= yy < H and hair[yy, x] and cv.a[yy, x] in (P['HAIR'], P['HAIR_L']):
                cv.a[yy, x] = P['HAIR_L'] if yy == y else P['HAIR']

    # ---------- brazo delantero
    fs, fe, fw = arm_points(False)
    m_front = sleeve(cv, fs, fe, fw, back=False)
    hand_xy = None
    if p.arms in (ARM_HANG, ARM_HIDE):
        hand_hang(cv, int(fw[0]), int(fw[1]) + 3)
    elif p.arms == ARM_HOLD:
        hand_grip(cv, int(fw[0]) + 2, int(fw[1]) + 1)
        hand_xy = (int(fw[0]) + 2, int(fw[1]) + 1)
    elif p.arms == ARM_GIVE:
        hand_open(cv, int(fw[0]), int(fw[1]) - 1)
        hand_xy = (int(fw[0]) + 5, int(fw[1]) + 3)
    else:
        hand_open(cv, int(fw[0]), int(fw[1]) + 1, down=True)
    info['hand'] = hand_xy

    # contorno exterior general
    cv.outline(P['OUT'])
    return cv, info


def split_front_hand(cv, info, p):
    """Separa la mano delantera como capa de primer plano (se dibuja DESPUÉS del objeto sostenido)."""
    hxy = info.get('hand')
    if hxy is None:
        return cv.a.copy(), None
    x, y = hxy
    m = cv.blank()
    if p.arms == ARM_HOLD:
        m[y - 7:y + 6, x - 6:x + 6] = True
    else:
        m[y - 5:y + 6, x - 6:x + 7] = True
    fg = np.where(m & (cv.a != 0), cv.a, 0)
    base = np.where(m, 0, cv.a)
    return base, fg


POSES = {
    'IDLE': Pose(),
    'WALK_1': Pose(front=8, back=-8, lift_back=3, sway=0, scarf=-1, hair=1),
    'WALK_2': Pose(bob=-2, front=2, back=-2, lift_back=5, scarf=1, hair=0),
    'WALK_3': Pose(front=-8, back=8, lift_front=3, scarf=2, hair=-1),
    'PICKUP': Pose(crouch=8, head_dx=3, head_dy=2, arms=ARM_PICK, lean=2, front=7, back=-4, scarf=1),
    'HOLD_ITEM': Pose(arms=ARM_HOLD),
    'GIVE_ITEM': Pose(head_dx=2, arms=ARM_GIVE, lean=1),
    'HURT': Pose(bob=2, head_dx=2, head_dy=3, scarf=2, front=-3, back=3),
    'HIDE': Pose(crouch=10, head_dx=-2, head_dy=2, arms=ARM_HIDE, front=6, back=-6),
    'FLASHBACK': Pose(),
    'HOLD_WALK_1': Pose(front=8, back=-8, lift_back=3, arms=ARM_HOLD, scarf=-1, hair=1),
    'HOLD_WALK_2': Pose(bob=-2, front=2, back=-2, lift_back=5, arms=ARM_HOLD, scarf=1),
    'HOLD_WALK_3': Pose(front=-8, back=8, lift_front=3, arms=ARM_HOLD, scarf=2, hair=-1),
}
