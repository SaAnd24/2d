from PIL import Image
import numpy as np
import items
tiles = []
for name, (cv, pal, grip) in items.all_items().items():
    arr = np.zeros((cv.h, cv.w, 4), dtype=np.uint8)
    for i, c in enumerate(pal):
        arr[cv.a == i] = c
    im = Image.fromarray(arr, 'RGBA')
    bg = Image.new('RGBA', im.size, (236, 226, 200, 255)); bg.alpha_composite(im)
    tiles.append(bg.resize((cv.w * 10, cv.h * 10), Image.NEAREST))
sheet = Image.new('RGBA', (sum(t.width for t in tiles) + 20 * len(tiles), 330), (236, 226, 200, 255))
x = 0
for t in tiles:
    sheet.paste(t, (x, 0)); x += t.width + 20
sheet.save('/home/claude/preview/items.png'); print(sheet.size)
