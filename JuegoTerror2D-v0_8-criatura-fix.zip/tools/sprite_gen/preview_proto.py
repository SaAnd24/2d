import sys
from PIL import Image
from pixlib import to_image
import protagonist as pr
names = sys.argv[1:] or ['IDLE']
ims = []
for n in names:
    cv, info = pr.build(pr.POSES[n])
    ims.append(to_image(cv, 5))
w = sum(i.width for i in ims)
sheet = Image.new('RGBA', (w, ims[0].height), (236, 226, 200, 255))
x = 0
for i in ims:
    sheet.paste(i, (x, 0)); x += i.width
sheet.save('/home/claude/preview/proto.png')
print(sheet.size)
