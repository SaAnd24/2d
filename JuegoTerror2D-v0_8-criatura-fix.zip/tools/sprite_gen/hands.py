"""Manos del niño en PRIMERA PERSONA (puzzle de medicamentos). 72x80 px (36x40 lógicos).

Antebrazo con la manga naranja y su línea roja entrando por abajo; mano con dedos y uñas.
Tres poses: REST (apoyada), GRAB (agarrando una caja), POINT (señalando / tocando un papel).
La mano izquierda es la derecha volteada.
"""
import numpy as np
from pixlib import Cv, P

W, H = 72, 80


def build(kind):
    cv = Cv(W, H)
    cx = 34
    # manga (antebrazo)
    sleeve = cv.poly([(cx - 17, H - 1), (cx - 14, 52), (cx + 14, 52), (cx + 17, H - 1)])
    cv.shaded(sleeve, P['SHIRT'], P['SHIRT_L'], P['SHIRT_S'], P['SHIRT_D'], hb=2, sb=3, db=1)
    ys, xs = np.nonzero(sleeve)
    for y, x in zip(ys, xs):
        if (x + 2 * y) % 5 == 0 and cv.a[y, x] == P['SHIRT']:
            cv.a[y, x] = P['SHIRT_S']
    # línea roja de la manga
    cv.a[cv.rect(cx - 18, 66, cx + 18, 69) & sleeve] = P['RED']
    cv.a[cv.rect(cx - 18, 69, cx + 18, 69) & sleeve] = P['RED_D']
    cv.a[cv.rect(cx - 18, 66, cx + 18, 66) & sleeve] = P['SHIRT_L']
    # pliegue de la manga
    for i in range(10):
        cv.put(cx - 10 + i, 74 + i // 3, P['SHIRT_D'])
    # puño acanalado
    cuff = cv.rect(cx - 15, 52, cx + 15, 57) & sleeve
    cv.a[cuff] = P['SHIRT_S']
    for x in range(cx - 14, cx + 15, 2):
        cv.a[cv.rect(x, 53, x, 57) & cuff] = P['SHIRT_D']
    cv.a[cv.rect(cx - 15, 52, cx + 15, 52) & cuff] = P['SHIRT_L']
    # muñeca y palma
    wrist = cv.rect(cx - 9, 46, cx + 9, 53)
    cv.shaded(wrist, P['SKIN'], P['SKIN_L'], P['SKIN_S'], None, hb=1, sb=2)
    palm = cv.ellipse(cx, 38, 13, 10)
    cv.shaded(palm, P['SKIN'], P['SKIN_L'], P['SKIN_S'], P['SKIN_D'], hb=2, sb=2)

    def finger(x0, y0, x1, y1, r0, r1, curl=False):
        m = cv.capsule((x0, y0), (x1, y1), r0, r1)
        cv.shaded(m, P['SKIN'], P['SKIN_L'], P['SKIN_S'], P['SKIN_D'], hb=1, sb=1)
        # nudillos / articulaciones
        mx, my = int((x0 + x1) / 2), int((y0 + y1) / 2)
        cv.put(mx - 1, my, P['SKIN_S']); cv.put(mx, my, P['SKIN_S']); cv.put(mx + 1, my, P['SKIN_S'])
        # uña
        ex, ey = int(x1), int(y1)
        cv.a[cv.ellipse(ex, ey - (0 if curl else 2), 2, 1) & m] = P['SKIN_L']
        cv.put(ex, ey - (0 if curl else 2), P['BLUSH'])
        return m

    if kind == 'REST':
        specs = [(cx - 9, 31, cx - 12, 14, 3.2, 2.7), (cx - 3, 29, cx - 4, 8, 3.4, 2.8),
                 (cx + 3, 29, cx + 4, 10, 3.4, 2.8), (cx + 9, 31, cx + 11, 16, 3.0, 2.5)]
        for s in specs:
            finger(*s)
        thumb = cv.capsule((cx + 12, 40), (cx + 22, 31), 3.4, 2.6)
        cv.shaded(thumb, P['SKIN'], P['SKIN_L'], P['SKIN_S'], P['SKIN_D'], hb=1, sb=1)
        cv.put(cx + 22, 30, P['SKIN_L'])
    elif kind == 'GRAB':
        for (x0, y0, x1, y1, r0, r1) in [(cx - 9, 31, cx - 8, 20, 3.4, 3.0), (cx - 3, 29, cx - 2, 17, 3.6, 3.2),
                                         (cx + 3, 29, cx + 4, 17, 3.6, 3.2), (cx + 9, 31, cx + 9, 21, 3.2, 2.8)]:
            finger(x0, y0, x1, y1, r0, r1, curl=True)
            for dy in (0, 5):
                cv.put(int(x1) - 2, int(y1) + 6 + dy, P['SKIN_D']); cv.put(int(x1) + 2, int(y1) + 6 + dy, P['SKIN_D'])
        thumb = cv.capsule((cx + 12, 40), (cx + 16, 24), 3.6, 3.0)
        cv.shaded(thumb, P['SKIN'], P['SKIN_L'], P['SKIN_S'], P['SKIN_D'], hb=1, sb=1)
    else:  # POINT
        finger(cx - 3, 29, cx - 3, 4, 3.4, 2.8)
        for (x0, y0, x1, y1) in [(cx - 9, 31, cx - 9, 24), (cx + 3, 29, cx + 4, 22), (cx + 9, 31, cx + 10, 25)]:
            finger(x0, y0, x1, y1, 3.2, 2.8, curl=True)
        thumb = cv.capsule((cx + 12, 40), (cx + 8, 30), 3.4, 2.8)
        cv.shaded(thumb, P['SKIN'], P['SKIN_L'], P['SKIN_S'], P['SKIN_D'], hb=1, sb=1)
    cv.outline(P['OUT'])
    return cv
