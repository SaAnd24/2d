"""LA CRIATURA de MYMom (v0.8, rediseño): humanoide encorvado, cabeza abombada con sonrisa de dientes finos, ojos tristes
y caídos, vientre colgante con SIETE bocas, brazos larguísimos que casi tocan el suelo, piernas finas con rodillas
nudosas y pies palmeados de dedos largos con bulbos. Piel verde oliva con verrugas amarillas y llagas rojizas.

Todo se DIBUJA aquí con el mismo motor pixelado procedural (pixlib): elipses, cápsulas, sombreado por volumen,
pliegues, verrugas, dientes... NO se usa ninguna imagen como recurso (las dos imágenes de referencia solo sirvieron
para medir proporciones y paleta). Salida: matrices de índices de paleta que emit_creature.py codifica en RLE.

MISMA DENSIDAD que el niño (1 px de sprite = 0,5 px lógicos). Todo mira a la DERECHA; el juego espeja.

Capas (el juego las compone, igual que antes): brazo trasero, CUERPO (piernas+pecho+vientre, una pose por frame de
la animación), cabeza (2 variantes: frontal y girada), ojos, boca principal, 7 bocas del vientre (cada una con su
parche y sus estados) y brazo delantero. Los brazos largos son péndulos: 10 ángulos de balanceo x 3 de codo.
"""
import math
import numpy as np
from pixlib import Cv

PAL = [
    (0, 0, 0, 0),
    (0x1D, 0x13, 0x0C, 255),   # 1 contorno
    (0x85, 0x7D, 0x4D, 255),   # 2 piel
    (0x99, 0x91, 0x5D, 255),   # 3 piel clara
    (0x6C, 0x5F, 0x3C, 255),   # 4 sombra
    (0x4F, 0x42, 0x27, 255),   # 5 sombra profunda
    (0xB2, 0xAD, 0x76, 255),   # 6 brillo
    (0xD1, 0xCE, 0x9B, 255),   # 7 brillo húmedo
    (0x3B, 0x2A, 0x18, 255),   # 8 pliegue
    (0x76, 0x6E, 0x41, 255),   # 9 vientre
    (0x5D, 0x4F, 0x30, 255),   # 10 sombra vientre
    (0xCB, 0xAC, 0x58, 255),   # 11 verruga
    (0x9A, 0x6C, 0x34, 255),   # 12 verruga sombra
    (0x8A, 0x4A, 0x30, 255),   # 13 aro rojizo
    (0x9A, 0x3A, 0x2C, 255),   # 14 llaga
    (0x5E, 0x20, 0x18, 255),   # 15 llaga oscura
    (0x87, 0x60, 0x48, 255),   # 16 labio
    (0x6B, 0x3F, 0x31, 255),   # 17 labio oscuro
    (0x30, 0x0D, 0x04, 255),   # 18 interior boca
    (0x5A, 0x1A, 0x14, 255),   # 19 encía / fondo rojo
    (0x8A, 0x3A, 0x32, 255),   # 20 lengua
    (0xDC, 0xD4, 0xA4, 255),   # 21 dientes
    (0xA8, 0x9E, 0x70, 255),   # 22 sombra dientes
    (0x0E, 0x04, 0x02, 255),   # 23 ojo
    (0xC8, 0xD2, 0xC8, 255),   # 24 reflejo
    (0x7A, 0x6C, 0x42, 255),   # 25 párpado
    (0x4A, 0x3C, 0x24, 255),   # 26 sombra párpado
    (0xB8, 0xA8, 0x78, 255),   # 27 punta de dedo / uña
    (0x6E, 0x4E, 0x40, 255),   # 28 vena / moratón
]
OUT, SK, SKL, SKS, SKD, SKH, SKHH, FOLD, BEL, BELS, WART, WARTD, WARTR, SORE, SORED, LIP, LIPD, MIN, MINR, TON, TEE, TEES, EYB, EYH, LID, LIDS, NAIL, VEIN = range(1, 29)

RAMP_SK = [SKD, SKS, SK, SKL, SKH]
RAMP_BEL = [FOLD, SKD, BELS, BEL, SK]
RAMP_DK = [FOLD, SKD, SKS, SK, SKL]

W, H = 160, 176
GROUND = 175
HIPX = 80
ANCHOR_X = 80

# ---------------------------------------------------------------- utilidades de sombreado por volumen
BAYER = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]) / 16.0 - 0.5


def _sh(m, dx, dy):
    return Cv.shift(m, dx, dy)


def dist_field(m, cap):
    d = np.zeros(m.shape, np.float32)
    cur = m.copy()
    for _ in range(cap):
        d += cur
        cur = cur & _sh(cur, 1, 0) & _sh(cur, -1, 0) & _sh(cur, 0, 1) & _sh(cur, 0, -1)
    return d


def blur3(a):
    p = np.pad(a, 1, mode='edge')
    return (p[:-2, :-2] + p[:-2, 1:-1] + p[:-2, 2:] + p[1:-1, :-2] + p[1:-1, 1:-1] + p[1:-1, 2:] + p[2:, :-2] + p[2:, 1:-1] + p[2:, 2:]) / 9.0


def vshade(cv, m, ramp=RAMP_SK, cap=8, strength=1.0, bias=-0.14, dith=0.12):
    """Sombreado de VOLUMEN: altura = distancia al borde suavizada; luz arriba-izquierda; 5 bandas con tramado 4x4."""
    h = blur3(blur3(dist_field(m, cap)))
    gy, gx = np.gradient(h)
    v = strength * (0.55 * gx + 0.83 * gy) * 1.1 + bias
    v = np.clip(v, -1.0, 1.0)
    yy, xx = np.mgrid[0:cv.h, 0:cv.w]
    v = v + dith * BAYER[yy % 4, xx % 4]
    n = len(ramp)
    idx = np.clip(((v + 1.0) / 2.0 * n).astype(int), 0, n - 1)
    arr = np.array(ramp, dtype=np.int32)[idx]
    cv.a[m] = arr[m]


def rot_ellipse(cv, cx, cy, rx, ry, deg):
    yy, xx = np.mgrid[0:cv.h, 0:cv.w]
    t = math.radians(deg)
    c, s = math.cos(t), math.sin(t)
    X, Y = xx - cx, yy - cy
    u = X * c + Y * s
    v = -X * s + Y * c
    return (u / (rx + 0.5)) ** 2 + (v / (ry + 0.5)) ** 2 <= 1.0


def _rs(seed):
    return np.random.RandomState(seed)


SKINS = (SK, SKL, SKS, SKH, BEL, BELS, SKD)


def poly_curve(cv, pts, color, mask=None, only=SKINS):
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        n = int(max(abs(x1 - x0), abs(y1 - y0))) + 1
        for i in range(n + 1):
            t = i / max(1, n)
            x, y = int(round(x0 + (x1 - x0) * t)), int(round(y0 + (y1 - y0) * t))
            if 0 <= x < cv.w and 0 <= y < cv.h and (mask is None or mask[y, x]) and (only is None or cv.a[y, x] in only):
                cv.a[y, x] = color


def crease(cv, m, x, y, length, seed, droop=1.0, color=FOLD, hl=True, vertical=False):
    """Pliegue de piel: curva oscura con un filo de luz debajo (como las arrugas del dibujo)."""
    rs = _rs(seed)
    pts = []
    ph = rs.uniform(0, 6.28)
    amp = rs.uniform(0.8, 2.2)
    for i in range(length):
        if vertical:
            pts.append((x + amp * math.sin(i / 4.0 + ph), y + i))
        else:
            pts.append((x + i, y + droop * amp * math.sin(i / 4.5 + ph) + i * 0.08 * droop))
    P = [(int(round(a)), int(round(b))) for a, b in pts]
    poly_curve(cv, P, color, m)
    if hl:
        poly_curve(cv, [((a + 1) if vertical else a, b if vertical else (b + 1)) for a, b in P], SKL, m, only=(SK, BEL))


def wart(cv, x, y, r, m=None):
    """Verruga: bulto amarillento con aro rojizo parcial, brillo arriba-izquierda y sombra abajo-derecha."""
    x, y = int(x), int(y)
    core = cv.ellipse(x, y, r, r)
    ring = cv.ellipse(x, y, r + 1, r + 1) & ~core
    if m is not None:
        ring &= m
        core &= m
    yy, xx = np.mgrid[0:cv.h, 0:cv.w]
    ring &= ((xx - x) + (yy - y) >= -1)                       # el aro solo rodea abajo/derecha
    cv.a[ring & np.isin(cv.a, SKINS)] = WARTR
    cv.a[core] = WART
    if r >= 1:
        cv.put(x + r, y + r, WARTD)
        cv.put(x + r - 1, y + r, WARTD)
    cv.put(x - r + (1 if r > 0 else 0), y - r + (1 if r > 0 else 0), SKHH)


def mottle(cv, m, seed, amount=0.5):
    """Piel enferma: manchas bajas de frecuencia (sombra / claro) con tramado, solo sobre tonos de piel."""
    rs = _rs(seed)
    n = rs.rand(cv.h, cv.w)
    for _ in range(3):
        n = blur3(n)
    n = (n - n.min()) / max(1e-6, n.max() - n.min())
    yy, xx = np.mgrid[0:cv.h, 0:cv.w]
    d = BAYER[yy % 4, xx % 4] * 0.12
    dark = m & (cv.a == SK) & (n + d < 0.5 - 0.12 * amount * 2.0)
    light = m & (cv.a == SK) & (n + d > 0.5 + 0.20 * amount * 2.0)
    cv.a[dark] = SKS
    cv.a[light] = SKL


def pores(cv, m, seed, n):
    rs = _rs(seed)
    ys, xs = np.nonzero(m)
    if len(xs) == 0:
        return
    for _ in range(n):
        i = rs.randint(len(xs))
        if cv.a[ys[i], xs[i]] in (SK, SKS, SKL, BEL):
            cv.a[ys[i], xs[i]] = SKD if rs.rand() < 0.7 else SKHH


def sore(cv, x, y, rx, ry, m=None, drip=True):
    x, y = int(x), int(y)
    o = cv.ellipse(x, y, rx + 1, ry + 1)
    c = cv.ellipse(x, y, rx, ry)
    if m is not None:
        o &= m
        c &= m
    cv.a[o & np.isin(cv.a, SKINS)] = WART
    cv.a[c] = SORE
    cv.a[cv.ellipse(x + 1, y, max(1, rx - 2), max(1, ry - 1)) & (cv.a == SORE)] = SORED
    cv.put(x - 1, y - 1, SKHH if rx > 2 else SORE)
    if drip:
        for d in range(2, 5):
            if m is None or (0 <= y + ry + d < cv.h and m[y + ry + d, x]):
                cv.put(x, y + ry + d, SORE if d < 4 else SORED)


def scatter(cv, m, seed, n, rmax=2, keep=None):
    """Verrugas esparcidas dentro de la máscara (posiciones deterministas por semilla)."""
    rs = _rs(seed)
    ys, xs = np.nonzero(m & (_sh(m, 2, 2) & _sh(m, -2, -2) & _sh(m, 2, -2) & _sh(m, -2, 2)))
    if len(xs) == 0:
        return
    for k in range(n):
        i = rs.randint(len(xs))
        r = 2 if (k < max(1, n // 4) and rmax >= 2) else 1
        wart(cv, xs[i], ys[i], r, m)


def paste(dst, src, dx=0, dy=0):
    """Copia los píxeles no transparentes de src (Cv) sobre dst (Cv) desplazados."""
    h, w = src.a.shape
    ys, xs = np.nonzero(src.a)
    X, Y = xs + dx, ys + dy
    ok = (X >= 0) & (X < dst.w) & (Y >= 0) & (Y < dst.h)
    dst.a[Y[ok], X[ok]] = src.a[ys[ok], xs[ok]]


# ---------------------------------------------------------------- BOCAS (parche paramétrico: dientes finos, labios, encía)
def _hash(i, k=0):
    return ((i * 73856093) ^ (k * 19349663) ^ 0x5bd1e995) % 1000 / 1000.0


def mouth_patch(L, hmax, tilt, curve, openness, tooth_top, tooth_bot, period, lip=1.6, seed=0, tongue=True, closed_slit=0.5):
    """Boca en forma de lente (labios + interior + dientes). L = semilongitud, hmax = semialtura a apertura 1.
    tilt en grados (eje largo, + = extremo derecho más bajo); curve = cuánto cae el centro (sonrisa).
    Devuelve (Cv, cx, cy): el parche y el centro de la boca dentro de él."""
    t = math.radians(tilt)
    c, s = math.cos(t), math.sin(t)
    extra = int(lip) + 3 + int(abs(curve)) + 2
    bw = int(2 * L * abs(c) + (2 * hmax + 2 * extra) * abs(s)) + 2 * extra + 4
    bh = int(2 * L * abs(s) + (2 * hmax + 2 * extra) * abs(c)) + 2 * extra + 4
    cv = Cv(bw, bh)
    cx, cy = bw / 2.0 - 0.5, bh / 2.0 - 0.5
    yy, xx = np.mgrid[0:bh, 0:bw]
    X, Y = xx - cx, yy - cy
    u = X * c + Y * s
    v = -X * s + Y * c
    uu = u / L
    inside_u = np.abs(uu) <= 1.0
    vc = curve * (1.0 - uu ** 2)
    rel = v - vc
    half = hmax * openness if openness > 0 else 0.0
    prof = np.clip(1.0 - uu ** 2, 0, 1) ** 0.6
    hw = np.where(inside_u, half * prof, -1.0)
    if openness <= 0:
        lens = inside_u & (np.abs(rel) <= closed_slit * np.clip(prof * 1.5, 0.2, 1.0))
        hw = np.where(inside_u, closed_slit * prof, -1.0)
    else:
        lens = inside_u & (np.abs(rel) <= hw + 0.35)
    # labios (banda alrededor de la apertura)
    band = inside_u & (np.abs(rel) <= np.maximum(hw, 0) + lip * (0.55 + 0.45 * prof)) & ~lens
    ends = (np.abs(uu) <= 1.0 + lip / L) & (np.abs(rel) <= 0.9 + lip * 0.4) & ~lens
    band |= ends
    cv.a[band] = LIP
    cv.a[band & (rel > 0)] = LIPD
    cv.a[band & (rel < -np.maximum(hw, 0) - 0.4 * lip)] = LIP
    if openness <= 0:
        # cerrada: ranura oscura con un labio fruncido de tono piel (sin franja marrón)
        cv.a[band] = 0
        cv.a[band & (rel <= 0)] = SKS
        cv.a[band & (rel > 0)] = SKL
    if openness > 0 or True:
        cv.a[lens] = MIN
    if openness > 0:
        topd = rel + hw          # distancia al borde superior
        botd = hw - rel          # distancia al borde inferior
        ti = np.floor(u / period + 0.37).astype(int)
        ph = (u / period + 0.37) - ti
        tri = 1.0 - np.abs(2 * ph - 1.0)
        hts = np.array([[(0.55 + 0.45 * _hash(int(i) + seed, 1)) for i in range(ti.min(), ti.max() + 1)]])[0]
        ht_top = tooth_top * tri * hts[ti - ti.min()]
        bi = np.floor(u / period + 0.87).astype(int)
        bph = (u / period + 0.87) - bi
        btri = 1.0 - np.abs(2 * bph - 1.0)
        hbs = np.array([[(0.5 + 0.5 * _hash(int(i) + seed, 2)) for i in range(bi.min(), bi.max() + 1)]])[0]
        ht_bot = tooth_bot * btri * hbs[bi - bi.min()]
        gum = lens & ((topd < 1.0) | (botd < 1.0))
        cv.a[gum] = MINR
        tt = lens & (topd >= 0) & (topd <= ht_top + 0.3)
        cv.a[tt] = TEE
        cv.a[tt & (topd > ht_top - 0.9)] = TEES
        tb = lens & (botd >= 0) & (botd <= ht_bot + 0.3) & ~tt
        cv.a[tb] = TEE
        cv.a[tb & (botd > ht_bot - 0.9)] = TEES
        if tongue and openness >= 0.55:
            tg = lens & (rel > half * 0.15) & (np.abs(uu) < 0.62) & (cv.a == MIN)
            cv.a[tg] = TON
            cv.a[tg & (np.abs(uu) < 0.3) & (rel > half * 0.5)] = MINR
        # un hilo de saliva oscuro en el interior
        cv.a[lens & (cv.a == MIN) & (np.abs(uu) < 0.7) & (rel > -half * 0.3) & (rel < -half * 0.1) & ((xx + yy) % 5 == 0)] = MINR
    if openness > 0:
        cv.outline(OUT)
    else:
        cv.a[lens] = FOLD
        cv.a[lens & (np.abs(uu) < 0.25) & (rel > 0)] = LIPD
    return cv, int(round(cx)), int(round(cy))


# ---------------------------------------------------------------- LAS 7 BOCAS DEL VIENTRE (relativas al centro del vientre)
# (dx, dy, semilongitud, semialtura, inclinación°, curva, dientes arriba, dientes abajo, periodo)
BELLY_MOUTHS = [
    (7, -10, 9.0, 5.4, 3, 0.8, 3.2, 2.2, 2.8),      # 0 la grande, arriba al centro
    (22, -7, 4.8, 2.8, -10, 0.6, 1.8, 1.4, 2.5),    # 1 pequeña, a un lado
    (13, 3, 8.0, 4.8, -25, 0.8, 3.0, 2.0, 2.7),     # 2 inclinada, dientes grandes
    (-8, 0, 8.6, 4.4, 25, 0.6, 3.0, 2.0, 2.7),      # 3 almendrada hacia el otro lado
    (-22, -2, 4.8, 4.0, 22, 0.8, 2.6, 1.8, 2.5),    # 4 en el borde
    (-4, 12, 7.2, 2.8, 6, 2.4, 1.8, 1.2, 2.9),      # 5 sonrisa de abajo
    (-17, -10, 4.8, 1.9, 12, 0.4, 1.2, 1.0, 2.6),   # 6 rendija arriba
]
MOUTH_STATES = [0.0, 0.34, 0.68, 1.0]


def belly_mouth(i, state):
    dx, dy, L, hm, tilt, curve, tt, tb, per = BELLY_MOUTHS[i]
    return mouth_patch(L, hm, tilt, curve, MOUTH_STATES[state], tt, tb, per, lip=1.0, seed=i * 17, closed_slit=0.5)


# ---------------------------------------------------------------- PIEZAS ESTÁTICAS DEL CUERPO (se pegan por pose)
B0 = (80, 87)          # centro del vientre en reposo (coords del cuerpo)
C0 = (81, 60)          # centro del pecho en reposo
LEAD_SH = (110, 57)    # hombro delantero (reposo)
TRAIL_SH = (53, 46)    # hombro trasero, el alto y abultado (reposo)


def build_upper():
    cv = Cv(W, H)
    cx, cy = C0
    m = (cv.ellipse(cx, cy + 1, 28, 12) | cv.ellipse(cx + 8, cy - 8, 19, 10)                     # pecho + cuello ancho
         | cv.ellipse(TRAIL_SH[0] + 3, TRAIL_SH[1] - 5, 11, 10)                                  # joroba/hombro trasero
         | cv.ellipse(LEAD_SH[0] - 2, LEAD_SH[1] - 2, 8, 8)                                      # hombro delantero
         | cv.capsule((60, 46), (92, 41), 7, 8))                                                 # trapecio hacia la cabeza
    vshade(cv, m, RAMP_SK, cap=7, strength=0.85)
    # pliegues horizontales (cuello, clavícula, costillas)
    for k, (x, y, ln) in enumerate([(70, 48, 20), (62, 54, 26), (68, 60, 24), (74, 66, 20), (80, 44, 18), (58, 62, 14), (88, 55, 16)]):
        crease(cv, m, x, y, ln, 100 + k, droop=0.8)
    # hombro trasero abultado: aro y verrugas grandes
    wart(cv, TRAIL_SH[0] + 4, TRAIL_SH[1] - 8, 3, m)
    wart(cv, TRAIL_SH[0] - 1, TRAIL_SH[1] - 4, 1, m)
    wart(cv, TRAIL_SH[0] + 7, TRAIL_SH[1] - 3, 1, m)
    wart(cv, LEAD_SH[0] - 3, LEAD_SH[1] - 3, 1, m)
    mottle(cv, m, 71)
    pores(cv, m, 72, 40)
    scatter(cv, m, 311, 5)
    sore(cv, 70, 62, 2, 2, m)             # llaga en el pecho
    sore(cv, 62, 50, 1, 1, m, drip=False)
    cv.outline(OUT)
    return cv


def build_belly():
    cv = Cv(W, H)
    bx, by = B0
    m = (cv.ellipse(bx, by, 28, 17) | cv.ellipse(bx + 1, by + 6, 30, 14) | cv.ellipse(bx - 1, by + 11, 25, 9))
    vshade(cv, m, RAMP_BEL, cap=9, strength=0.8)
    # arrugas colgantes de la piel entre las bocas
    for k, (x, y, ln, dr) in enumerate([(bx - 26, by - 12, 22, 1.0), (bx - 22, by + 6, 26, 1.0), (bx - 14, by + 15, 24, 0.7), (bx + 6, by + 7, 20, 1.0),
                                          (bx - 20, by - 2, 12, 1.2), (bx + 8, by - 16, 20, 0.8), (bx - 10, by - 18, 14, 1.0), (bx + 14, by + 18, 14, 0.8)]):
        crease(cv, m, x, y, ln, 200 + k, droop=dr, hl=True)
    # cada boca: labio abultado (volumen propio, más claro arriba-izquierda) y un surco oscuro en el borde inferior
    for i, (dx, dy, L, hm, tilt, curve, tt, tb, per) in enumerate(BELLY_MOUTHS):
        mx, my = bx + dx, by + dy
        bump = rot_ellipse(cv, mx, my, L + 3.2, hm + 3.4, tilt) & m
        sub = Cv(W, H)
        vshade(sub, bump, [BELS, BEL, SK, SKL, SKH], cap=3, strength=0.9)
        cv.a[bump] = sub.a[bump]
        low = bump & ~_sh(bump, 0, -1)
        low2 = bump & ~_sh(bump, -1, -1)
        cv.a[(low | low2) & (cv.a != OUT)] = FOLD
    mottle(cv, m, 73)
    pores(cv, m, 74, 40)
    scatter(cv, m, 411, 4)
    wart(cv, bx + 12, by - 11, 1, m)
    wart(cv, bx + 15, by - 6, 1, m)
    wart(cv, bx - 18, by + 11, 1, m)
    sore(cv, bx - 24, by - 14, 1, 1, m, drip=False)
    cv.outline(OUT)
    yy, xx = np.mgrid[0:H, 0:W]
    cv.a[(cv.a == OUT) & (yy < by - 11) & (np.abs(xx - bx) < 21)] = 0
    return cv, m


# ---------------------------------------------------------------- PIERNAS (IK de dos huesos + pie palmeado de dedos con bulbo)
L1, L2 = 35.0, 37.0


def two_bone(Hp, Ap, l1, l2, bend=1):
    hx, hy = Hp
    ax, ay = Ap
    dx, dy = ax - hx, ay - hy
    d = math.hypot(dx, dy)
    d = min(max(d, abs(l1 - l2) + 0.5), l1 + l2 - 0.5)
    ux, uy = dx / max(1e-6, math.hypot(dx, dy)), dy / max(1e-6, math.hypot(dx, dy))
    a = (l1 * l1 - l2 * l2 + d * d) / (2 * d)
    hh = math.sqrt(max(0.0, l1 * l1 - a * a))
    px, py = uy * bend, -ux * bend
    return (hx + ux * a + px * hh, hy + uy * a + py * hh), (hx + ux * d, hy + uy * d)


# verrugas de la pierna en coordenadas del hueso: (hueso 0 muslo/1 espinilla, t, desplazamiento, radio)
LEG_WARTS = [(0, 0.4, -3, 2), (1, 0.3, 2, 1), (1, 0.75, -1, 1)]


def build_leg(hip, foot_x, lift, pitch, far, seed):
    cv = Cv(W, H)
    ank = (foot_x, GROUND - 5 - lift)
    knee, ank = two_bone(hip, ank, L1, L2, bend=1)
    thigh = cv.capsule(hip, knee, 8.2, 5.6)
    shin = cv.capsule(knee, ank, 5.4, 3.3)
    kn = cv.ellipse(knee[0], knee[1], 5, 5)
    m = thigh | shin | kn
    # pie: talón + dedos largos con bulbos en las puntas; el ángulo (pitch) = dedos hacia abajo
    ax, ay = ank
    p = math.radians(pitch)
    dirx, diry = math.cos(p), math.sin(p)
    px_, py_ = -diry, dirx
    heel = cv.ellipse(ax + 2, ay + 3, 5, 3)
    toes = cv.blank()
    tips = []
    for j, (off, ln, sp) in enumerate(((-3.0, 14, -10), (0.0, 17, 0), (3.2, 13, 12))):
        a2 = p + math.radians(sp)
        sx, sy = ax + 4 + px_ * off * 0.0, ay + 3 + off * 0.65
        ex, ey = sx + math.cos(a2) * ln, sy + math.sin(a2) * ln * 0.55 + (ln * 0.3 if pitch > 0 else 0)
        toes |= cv.capsule((sx, sy), (ex, ey), 2.2, 1.5)
        toes |= cv.ellipse(ex, ey, 2, 2)
        tips.append((ex, ey))
    foot = heel | toes
    m |= foot
    ramp = RAMP_DK if far else RAMP_SK
    vshade(cv, m, ramp, cap=6, strength=0.75)
    # rodilla nudosa: brillo y arrugas
    kx, ky = int(round(knee[0])), int(round(knee[1]))
    cv.put(kx - 2, ky - 2, SKH)
    cv.put(kx - 1, ky - 2, SKL)
    poly_curve(cv, [(kx + 3, ky - 3), (kx + 4, ky), (kx + 3, ky + 3)], FOLD, m)
    for ex, ey in tips:
        cv.put(int(round(ex)) - 1, int(round(ey)) - 1, SKH)
        cv.put(int(round(ex)), int(round(ey)) + 1, SKS)
    # verrugas por hueso (estables entre frames)
    pts = [(hip, knee), (knee, ank)]
    for bone, t, off, r in LEG_WARTS:
        (x0, y0), (x1, y1) = pts[bone]
        dx, dy = x1 - x0, y1 - y0
        ln = max(1e-6, math.hypot(dx, dy))
        wart(cv, x0 + dx * t - dy / ln * off, y0 + dy * t + dx / ln * off, r, m)
    if not far:
        sore(cv, (knee[0] + ank[0]) / 2 + 1, (knee[1] + ank[1]) / 2, 1, 2, m, drip=False)
    cv.outline(OUT)
    return cv, knee, ank


# ---------------------------------------------------------------- POSES / CICLOS
BOB8 = [2, 3, 0, -2, 2, 3, 0, -2]          # peso: golpea (abajo), se hunde, pasa, sube
SWAY8 = [1, 2, 2, 1, -1, -2, -2, -1]       # el cuerpo carga hacia la pierna de apoyo
BELLY_LAG8 = [0, 1, 2, 1, 0, 1, 2, 1]      # el vientre se hunde un frame después y rebota
HEAD_LAG8 = [0, 1, 2, 1, 0, 1, 2, 1]


def gait_foot(psi, S, Lift):
    """Pie en el ciclo (psi 0..1): 0..0.5 apoyo (de +S a -S), 0.5..1 oscilación con elevación. Devuelve (x, lift, pitch)."""
    psi = psi % 1.0
    if psi < 0.5:
        x = S * (1 - 4 * psi)
        pitch = -8 + 14 * (psi / 0.5) + (22 if psi > 0.4 else 0)
        return x, 0.0, pitch
    q = (psi - 0.5) * 2
    x = -S + 2 * S * q
    return x, Lift * math.sin(math.pi * q) ** 0.9, 28 * math.sin(math.pi * q) - 8 * q


def pose_walk(k, run=False):
    S = 30.0 if run else 15.0
    Lf = 17.0 if run else 9.0
    phi = k / 8.0
    xl, ll, pl = gait_foot(phi, S, Lf)
    xt, lt, pt = gait_foot(phi + 0.5, S, Lf)
    bob = [4, 6, -1, -4, 4, 6, -1, -4][k] if run else BOB8[k]
    sway = (SWAY8[k] * 1.4 if not run else SWAY8[k] * 1.0)
    lean = 10 if run else 3
    return dict(bob=bob, sway=int(round(sway)), lean=lean, chest_dy=(2 if run else 0) + (1 if k in (1, 5) else 0),
                belly=(int(round(-sway * 0.4)) + 0, BELLY_LAG8[k] * (2 if run else 1)),
                head=(lean + (14 if run else 2) - int(round(sway * 0.5)), (6 if run else 1) + HEAD_LAG8[k]), variant=1,
                lead=(xl, ll, pl), trail=(xt, lt, pt))


def poses():
    P = {}
    P['IDLE'] = dict(bob=0, sway=0, lean=0, chest_dy=0, belly=(0, 0), head=(0, 0), variant=0, lead=(15, 0, 0), trail=(-14, 0, 0))
    P['INVESTIGATE'] = dict(bob=2, sway=1, lean=9, chest_dy=3, belly=(1, 1), head=(15, 11), variant=1, lead=(10, 0, 0), trail=(-12, 0, 0))
    P['ALERT'] = dict(bob=-2, sway=0, lean=-3, chest_dy=-3, belly=(0, -1), head=(-2, -7), variant=0, lead=(16, 0, 0), trail=(-15, 0, 0))
    P['CAPTURE'] = dict(bob=4, sway=2, lean=18, chest_dy=5, belly=(2, 2), head=(24, 10), variant=1, lead=(22, 0, 0), trail=(-18, 0, 0))
    P['HURT_LIGHT'] = dict(bob=3, sway=-2, lean=-9, chest_dy=2, belly=(-1, 2), head=(-9, 8), variant=0, lead=(14, 0, 0), trail=(-15, 0, 0))
    for k in range(8):
        P['WALK_%d' % k] = pose_walk(k)
    for k in range(8):
        P['RUN_%d' % k] = pose_walk(k, run=True)
    return P


POSES = poses()

HEAD_REST = {0: (95, 26), 1: (98, 26)}      # centro de cabeza en reposo por variante (coords del cuerpo)
HEAD_C = (34, 31)                            # centro dentro del lienzo de cabeza
HW, HH = 70, 64

_UPPER = None
_BELLY = None


def _statics():
    global _UPPER, _BELLY
    if _UPPER is None:
        _UPPER = build_upper()
        _BELLY = build_belly()[0]
    return _UPPER, _BELLY


def build_body(name):
    p = POSES[name]
    up, bel = _statics()
    cv = Cv(W, H)
    px = HIPX + p['sway']
    py = 100 + p['bob']
    hl = (px + 13, py)
    ht = (px - 13, py)
    leg_t, _, _ = build_leg(ht, HIPX + p['trail'][0], p['trail'][1], p['trail'][2], True, 5)
    leg_l, _, _ = build_leg(hl, HIPX + p['lead'][0], p['lead'][1], p['lead'][2], False, 6)
    paste(cv, leg_t)
    paste(cv, leg_l)
    udx, udy = p['lean'] + int(round(p['sway'] * 0.5)), p['bob'] + p['chest_dy']
    paste(cv, up, udx, udy)
    bdx, bdy = p['sway'] + p['belly'][0], p['bob'] + p['belly'][1]
    paste(cv, bel, bdx, bdy)
    hv = p['variant']
    hc = HEAD_REST[hv]
    hcx, hcy = hc[0] + udx + p['head'][0] - p['lean'] + p['lean'] * 0 , hc[1] + udy + p['head'][1]
    info = dict(head=(hcx - HEAD_C[0], hcy - HEAD_C[1]), belly=(B0[0] + bdx, B0[1] + bdy),
                lead=(LEAD_SH[0] + udx, LEAD_SH[1] + udy), trail=(TRAIL_SH[0] + udx, TRAIL_SH[1] + udy), variant=hv)
    return cv, info


# ---------------------------------------------------------------- BRAZOS LARGOS (péndulo: 10 balanceos x 3 codos, delantero y trasero)
ARM_SWING = [-40, -30, -20, -10, 0, 10, 20, 30, 42, 60]
ARM_BEND = [-14, 0, 14]
UP_LEN, FORE_LEN = 42.0, 55.0          # delantero; el trasero usa UP_TRAIL/FORE_TRAIL
UP_TRAIL, FORE_TRAIL = 48.0, 62.0
ACW, ACH = 230, 150
ASH = (115, 20)


def _dir(a_deg):
    a = math.radians(a_deg)
    return math.sin(a), math.cos(a)


ARM_WARTS = [(0, 0.35, -3, 1), (1, 0.25, 2, 1), (1, 0.6, -2, 2), (1, 0.9, -1, 1)]


def build_arm(si, bi, lead):
    sw, bd = ARM_SWING[si], ARM_BEND[bi]
    cv = Cv(ACW, ACH)
    sx, sy = ASH
    out_u, out_f = (22, -5) if lead else (-20, 3)
    aU = sw + out_u
    aF = sw + out_f + bd
    ux, uy = _dir(aU)
    fx, fy = _dir(aF)
    ul, fl = (UP_LEN - 4, FORE_LEN - 4) if lead else (UP_TRAIL, FORE_TRAIL)
    E = (sx + ux * ul, sy + uy * ul)
    Wr = (E[0] + fx * fl, E[1] + fy * fl)
    up = cv.capsule((sx, sy), E, 8.0, 6.2)
    lo = cv.capsule(E, Wr, 6.4, 4.2)
    elbow = cv.ellipse(E[0], E[1], 5, 5)
    palm = cv.ellipse(Wr[0] + fx * 3, Wr[1] + fy * 3, 4, 5)
    m = up | lo | elbow | palm
    # dedos larguísimos y finos que se curvan hacia fuera (dos falanges)
    fan = [34, 14, -8, -30] if lead else [-34, -14, 8, 30]
    lens1 = [11, 13, 12, 9]
    lens2 = [8, 9, 8, 6]
    fm = cv.blank()
    tips = []
    for j in range(4):
        a1 = aF + fan[j] * 0.7
        d1x, d1y = _dir(a1)
        b = (Wr[0] + fx * 4 + (j - 1.5) * 0.9, Wr[1] + fy * 4)
        k1 = (b[0] + d1x * lens1[j], b[1] + d1y * lens1[j])
        a2 = a1 + (26 if lead else -26) + fan[j] * 0.2
        d2x, d2y = _dir(a2)
        k2 = (k1[0] + d2x * lens2[j], k1[1] + d2y * lens2[j])
        fm |= cv.capsule(b, k1, 1.7, 1.4) | cv.capsule(k1, k2, 1.4, 1.0) | cv.ellipse(k2[0], k2[1], 1, 1)
        tips.append(k2)
    m |= fm
    # el brazo no necesita aro en el hombro: se funde con el cuerpo
    vshade(cv, m, RAMP_SK, cap=6, strength=0.7)
    # codo nudoso
    ex, ey = int(round(E[0])), int(round(E[1]))
    cv.put(ex - 2, ey - 2, SKH)
    cv.put(ex - 1, ey - 2, SKL)
    # arrugas largas a lo largo del brazo
    for t0, off in ((0.15, -3), (0.5, 3), (0.2, 3)):
        poly_curve(cv, [(sx + (E[0] - sx) * t0 + off, sy + (E[1] - sy) * t0), (sx + (E[0] - sx) * (t0 + 0.4) + off, sy + (E[1] - sy) * (t0 + 0.4))], FOLD, m)
    for t0, off in ((0.1, 2), (0.45, -2), (0.7, 2)):
        poly_curve(cv, [(E[0] + (Wr[0] - E[0]) * t0 + off, E[1] + (Wr[1] - E[1]) * t0), (E[0] + (Wr[0] - E[0]) * (t0 + 0.25) + off, E[1] + (Wr[1] - E[1]) * (t0 + 0.25))], FOLD, m)
    for (x2, y2) in tips:
        cv.put(int(round(x2)), int(round(y2)), NAIL)
    # verrugas por hueso
    bones = [((sx, sy), E), (E, Wr)]
    for bone, t, off, r in ARM_WARTS:
        (x0, y0), (x1, y1) = bones[bone]
        dx, dy = x1 - x0, y1 - y0
        ln = max(1e-6, math.hypot(dx, dy))
        wart(cv, x0 + dx * t - dy / ln * off, y0 + dy * t + dx / ln * off, r, m)
    sore(cv, E[0] + (Wr[0] - E[0]) * 0.55, E[1] + (Wr[1] - E[1]) * 0.55, 1, 2, m, drip=False)
    cv.outline(OUT)
    # sin contorno en el hombro (la unión se funde con el cuerpo)
    yy, xx = np.mgrid[0:ACH, 0:ACW]
    cap = ((xx - sx) ** 2 + (yy - sy) ** 2 <= 7.2 ** 2) & (cv.a == OUT)
    cv.a[cap] = 0
    ys, xs = np.nonzero(cv.a)
    x0, x1, y0, y1 = xs.min(), xs.max(), ys.min(), ys.max()
    crop = Cv(x1 - x0 + 1, y1 - y0 + 1)
    crop.a[:, :] = cv.a[y0:y1 + 1, x0:x1 + 1]
    return crop, (sx - x0, sy - y0)


# ---------------------------------------------------------------- CABEZA (2 variantes: frontal, girada) + parches de ojos y boca
EYE_STATES = ['OPEN', 'HALF', 'CLOSED', 'LOOK_DOWN', 'WIDE']
MOUTH_NAMES = ['CLOSED', 'TENSE', 'OPEN', 'WIDE']


def build_head(variant):
    cv = Cv(HW, HH)
    cx, cy = HEAD_C
    if variant == 0:      # frontal: cúpula abombada arriba, mandíbula ancha, bulto arriba a la derecha
        m = (cv.ellipse(cx, cy - 8, 19, 21) | cv.ellipse(cx, cy + 4, 23, 15) | cv.ellipse(cx + 8, cy - 18, 11, 9)
             | cv.ellipse(cx - 17, cy + 8, 8, 10) | cv.ellipse(cx + 18, cy + 8, 8, 10) | cv.ellipse(cx + 2, cy + 17, 18, 8))
    else:                 # girada: la cara se desplaza hacia delante (derecha); atrás, la masa de las mejillas
        m = (cv.ellipse(cx - 2, cy - 8, 20, 21) | cv.ellipse(cx + 8, cy + 3, 21, 16) | cv.ellipse(cx - 9, cy + 9, 19, 15)
             | cv.ellipse(cx - 8, cy - 18, 11, 8) | cv.ellipse(cx + 10, cy + 14, 18, 8) | cv.ellipse(cx - 20, cy + 16, 9, 8))
    vshade(cv, m, RAMP_SK, cap=9, strength=0.85)
    if variant == 0:
        # entrecejo, cejas caídas hacia fuera, nariz de calavera con dos ranuras, pómulos
        brow = cv.capsule((cx - 3, cy - 12), (cx - 16, cy - 7), 2.6, 3.0) | cv.capsule((cx + 3, cy - 13), (cx + 16, cy - 8), 2.6, 3.0)
        cv.a[brow & m] = SKL
        cv.a[brow & m & ~_sh(brow, 0, -1)] = SKH
        poly_curve(cv, [(cx - 18, cy - 5), (cx - 9, cy - 9), (cx - 2, cy - 10)], FOLD, m, only=None)
        poly_curve(cv, [(cx + 18, cy - 6), (cx + 9, cy - 10), (cx + 2, cy - 11)], FOLD, m, only=None)
        nose = cv.capsule((cx, cy - 6), (cx, cy + 6), 2.4, 3.2)
        cv.a[nose & m] = SKL
        cv.a[nose & m & ~_sh(nose, 1, 0)] = SKH
        cv.a[nose & m & ~_sh(nose, -1, 0)] = SKS
        for sx_ in (-2, 2):
            cv.put(cx + sx_, cy + 7, FOLD)
            cv.put(cx + sx_, cy + 8, FOLD)
        poly_curve(cv, [(cx - 22, cy + 6), (cx - 18, cy + 11), (cx - 12, cy + 14)], FOLD, m)
        poly_curve(cv, [(cx + 22, cy + 6), (cx + 18, cy + 11), (cx + 12, cy + 14)], FOLD, m)
        for k, (x, y, ln) in enumerate([(cx - 14, cy - 15, 12), (cx - 4, cy - 17, 16), (cx - 18, cy + 18, 14), (cx - 4, cy + 21, 18)]):
            crease(cv, m, x, y, ln, 500 + k, droop=0.8)
        wart(cv, cx + 9, cy - 24, 3, m); wart(cv, cx + 15, cy - 19, 2, m); wart(cv, cx - 8, cy - 22, 1, m); wart(cv, cx - 15, cy - 14, 1, m)
        wart(cv, cx + 17, cy - 10, 1, m); wart(cv, cx - 21, cy + 2, 1, m); wart(cv, cx + 22, cy + 12, 1, m); wart(cv, cx - 13, cy + 20, 1, m)
        sore(cv, cx + 12, cy - 15, 1, 2, m, drip=False)
        sore(cv, cx - 20, cy - 6, 1, 1, m, drip=False)
    else:
        brow = cv.capsule((cx + 3, cy - 13), (cx + 19, cy - 8), 2.6, 3.0) | cv.capsule((cx - 11, cy - 12), (cx - 1, cy - 12), 2.0, 2.4)
        cv.a[brow & m] = SKL
        cv.a[brow & m & ~_sh(brow, 0, -1)] = SKH
        poly_curve(cv, [(cx + 21, cy - 5), (cx + 12, cy - 9), (cx + 4, cy - 10)], FOLD, m, only=None)
        nose = cv.capsule((cx + 19, cy - 4), (cx + 22, cy + 7), 2.2, 3.0)
        cv.a[nose & m] = SKL
        cv.a[nose & m & ~_sh(nose, 0, -1)] = SKH
        cv.put(cx + 21, cy + 7, FOLD); cv.put(cx + 21, cy + 8, FOLD)
        for k, (x, y, ln, vert) in enumerate([(cx - 18, cy - 4, 20, True), (cx - 12, cy - 3, 22, True), (cx - 6, cy - 2, 22, True), (cx, cy + 0, 20, True),
                                                (cx - 16, cy + 20, 26, False), (cx - 22, cy + 14, 24, False)]):
            crease(cv, m, x, y, ln, 600 + k, droop=0.8, vertical=vert)
        wart(cv, cx - 5, cy - 25, 3, m); wart(cv, cx + 3, cy - 18, 2, m); wart(cv, cx - 12, cy - 20, 1, m); wart(cv, cx + 9, cy - 20, 1, m)
        wart(cv, cx - 20, cy - 8, 1, m); wart(cv, cx - 16, cy + 6, 1, m); wart(cv, cx - 4, cy + 14, 1, m); wart(cv, cx - 20, cy + 14, 1, m)
        sore(cv, cx - 14, cy - 12, 1, 2, m, drip=False)
    cv.outline(OUT)
    return cv


# centros de ojos y boca por variante (coords de cabeza)
EYE_CENTERS = {0: ((HEAD_C[0] - 10, HEAD_C[1] - 3), (HEAD_C[0] + 10, HEAD_C[1] - 4)),
               1: ((HEAD_C[0] + 1, HEAD_C[1] - 4), (HEAD_C[0] + 16, HEAD_C[1] - 3))}
EYE_R = {0: (6.2, 5.8), 1: (4.6, 5.8)}    # radio del ojo trasero / delantero (en la girada el delantero es el cercano)


def eye_patch(r, state, outer):
    """Ojo hundido y negro, con párpado superior pesado que cae hacia el lado de fuera (`outer` = -1 izq., +1 der.),
    bolsa inferior con borde húmedo y un reflejo diminuto. La tristeza viene de la inclinación del párpado."""
    rr = int(math.ceil(r))
    d = rr * 2 + 9
    cv = Cv(d, d)
    c = d // 2
    yy, xx = np.mgrid[0:d, 0:d]
    # cuenca oscura (sombra profunda alrededor del ojo)
    sock = cv.ellipse(c, c + 1, rr + 3, rr + 2)
    cv.a[sock] = SKD
    cv.a[sock & ~cv.ellipse(c, c + 1, rr + 2, rr + 1)] = SKS
    big = 1 if state == 'WIDE' else 0
    eye = cv.ellipse(c, c + 1, rr + big - 1, rr + big - 3)           # almendrado, no una bola
    open_amt = {'OPEN': 1.0, 'HALF': 0.66, 'CLOSED': 0.0, 'LOOK_DOWN': 0.70, 'WIDE': 1.25}[state]
    if state != 'CLOSED':
        cv.a[eye] = EYB
        gx = c - 1 + (1 if outer > 0 else 0)
        gy = c - 1 + (2 if state == 'LOOK_DOWN' else 0)
        cv.put(gx, gy, EYH)
        if state == 'WIDE':
            cv.put(gx + 1, gy + 1, EYH)
    # párpado superior: borde inclinado (más bajo en el lado de fuera)
    cover = (1.0 - min(open_amt, 1.0)) * 2 * rr + 0.30 * rr
    slope = 0.55 * outer * ((xx - c) / max(1.0, rr)) * rr * 0.6
    lid = cv.ellipse(c, c, rr + 2, rr + 1) & (yy <= (c - rr + cover + slope))
    if state == 'CLOSED':
        lid = cv.ellipse(c, c + 1, rr + 2, rr + 1) & (yy <= c + 1 + slope * 0.4)
    cv.a[lid] = LID
    edge = lid & ~_sh(lid, 0, 1)
    cv.a[edge] = FOLD
    cv.a[lid & _sh(edge, 0, 1)] = LIDS
    top = lid & ~_sh(lid, 0, -1)
    cv.a[top] = SKL
    # bolsa inferior: arco claro y borde húmedo rosado
    for x in range(c - rr, c + rr + 1):
        t = (x - c) / (rr + 0.5)
        if abs(t) > 1:
            continue
        yb = c + 1 + int(round((rr - 0.5) * math.sqrt(max(0.0, 1 - t * t))))
        for k, col in ((0, LIPD if state != 'CLOSED' else LIDS), (1, SKL), (2, SKS)):
            if 0 <= yb + k < d and cv.a[yb + k, x] in (0, SKD, SKS, EYB):
                cv.a[yb + k, x] = col
    return cv


MAIN_MOUTH_SPECS = {
    # variante: (semilongitud, semialtura máx, inclinación, curva, dientes arriba, abajo, periodo)
    0: (21.5, 8.6, 0, 6.5, 6.0, 4.4, 3.1),
    1: (20.0, 8.4, 17, 4.0, 6.2, 4.4, 3.1),
}
MAIN_STATES = [0.70, 0.84, 1.10, 1.45]     # la sonrisa SIEMPRE enseña dientes; se abre más al gruñir


def main_mouth(variant, state):
    L, hm, tilt, curve, tt, tb, per = MAIN_MOUTH_SPECS[variant]
    return mouth_patch(L, hm, tilt, curve, MAIN_STATES[state], tt, tb, per, lip=2.0, seed=variant * 31 + 7, closed_slit=1.0)


MOUTH_AT = {0: (HEAD_C[0], HEAD_C[1] + 9), 1: (HEAD_C[0] + 4, HEAD_C[1] + 9)}


# ---------------------------------------------------------------- vista previa
def to_rgba(cv):
    arr = np.zeros((cv.h, cv.w, 4), dtype=np.uint8)
    for i, c in enumerate(PAL):
        arr[cv.a == i] = c
    return arr


def compose(name='IDLE', lead=(4, 1), trail=(4, 1), eye=1, mouth=0, mo=(0, 1, 2, 3, 0, 1, 2), scale=3):
    from PIL import Image
    body, info = build_body(name)
    img = Image.new('RGBA', (W, H), (214, 206, 186, 255))

    def put(cv, x, y):
        im = Image.fromarray(to_rgba(cv), 'RGBA')
        img.alpha_composite(im, (x, y)) if x >= 0 and y >= 0 and x + cv.w <= W and y + cv.h <= H else _clip(img, im, x, y)

    def _clip(img, im, x, y):
        tmp = Image.new('RGBA', img.size, (0, 0, 0, 0))
        tmp.paste(im, (x, y))
        img.alpha_composite(tmp)
    a, (ax, ay) = build_arm(trail[0], trail[1], False)
    put(a, info['trail'][0] - ax, info['trail'][1] - ay)
    put(body, 0, 0)
    v = info['variant']
    hx, hy = info['head']
    put(build_head(v), hx, hy)
    (e0, e1) = EYE_CENTERS[v]
    r0, r1 = EYE_R[v]
    pe0 = eye_patch(r0, EYE_STATES[eye], -1)
    pe1 = eye_patch(r1, EYE_STATES[eye], +1)
    put(pe0, hx + e0[0] - pe0.w // 2, hy + e0[1] - pe0.h // 2)
    put(pe1, hx + e1[0] - pe1.w // 2, hy + e1[1] - pe1.h // 2)
    mm, mcx, mcy = main_mouth(v, mouth)
    put(mm, hx + MOUTH_AT[v][0] - mcx, hy + MOUTH_AT[v][1] - mcy)
    bx, by = info['belly']
    for i, (dx, dy, *_r) in enumerate(BELLY_MOUTHS):
        pm, pcx, pcy = belly_mouth(i, mo[i])
        put(pm, bx + dx - pcx, by + dy - pcy)
    a, (ax, ay) = build_arm(lead[0], lead[1], True)
    put(a, info['lead'][0] - ax, info['lead'][1] - ay)
    return img.resize((W * scale, H * scale), Image.NEAREST)


if __name__ == '__main__':
    from PIL import Image
    ims = [compose('IDLE', scale=3), compose('WALK_1', lead=(3, 1), trail=(5, 1), scale=3)]
    sheet = Image.new('RGBA', (sum(i.width for i in ims), ims[0].height))
    x = 0
    for i in ims:
        sheet.paste(i, (x, 0)); x += i.width
    sheet.save('/home/claude/creature_preview.png')
    print('ok', sheet.size, 'colores', len(PAL))
