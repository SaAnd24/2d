"""Piezas de la criatura a partir de las referencias (coordenadas de la referencia SIN espejar; refrig las espeja)."""
import numpy as np
from refrig import *

# --- polígonos (coords de referencia sin espejar)
HEAD_A = [(180, 20), (480, 20), (555, 185), (570, 215), (520, 300), (480, 420), (300, 440), (240, 400), (205, 340), (180, 200)]
HEAD_B = [(150, 20), (520, 20), (565, 150), (600, 200), (600, 300), (560, 430), (300, 445), (235, 400), (200, 350), (150, 200)]
ARM_L = [(100, 360), (214, 344), (246, 380), (262, 470), (240, 480), (236, 1190), (20, 1190), (20, 360)]
ARM_R = [(575, 240), (650, 240), (900, 300), (900, 1190), (645, 1190), (640, 700), (636, 520), (612, 440), (588, 350)]
LEG_L = [(290, 695), (440, 695), (450, 900), (420, 1190), (236, 1190), (236, 900), (270, 800)]
LEG_R = [(490, 690), (640, 690), (640, 900), (700, 1190), (480, 1190), (500, 900)]

SH_L, EL_L = (232, 398), (135, 628)        # brazo izquierdo de la imagen = brazo DELANTERO tras espejar
SH_R, EL_R = (602, 330), (714, 600)        # brazo derecho de la imagen = TRASERO
HIP_L, KN_L, AK_L = (350, 716), (405, 880), (320, 1058)
HIP_R, KN_R, AK_R = (548, 712), (600, 862), (536, 1052)

M_HEAD_A, M_HEAD_B = poly_mask(HEAD_A), poly_mask(HEAD_B)
M_AL, M_AR = poly_mask(ARM_L), poly_mask(ARM_R)
M_LL, M_LR = poly_mask(LEG_L) & ~M_AL & ~M_AR, poly_mask(LEG_R) & ~M_AL & ~M_AR


def _y(y):
    return y + Y0


TORSO = A_A & ~M_AL & ~M_AR & ~M_LL & ~M_LR & ((np.mgrid[0:BH, 0:BW][0] >= _y(380)) | ~M_HEAD_A)
CHEST = TORSO & (np.mgrid[0:BH, 0:BW][0] < _y(500))
BELLY = TORSO & (np.mgrid[0:BH, 0:BW][0] >= _y(480))

HEAD_PC = [cut(RGB_A, A_A, M_HEAD_A), cut(RGB_B, A_B, M_HEAD_B)]
CHEST_PC = cut(RGB_A, A_A, CHEST)
BELLY_PC = cut(RGB_A, A_A, BELLY)


def split_bone(mask_leg_or_arm, a_pt, b_pt):
    """Parte una extremidad en (antes de b_pt, después de b_pt) con un corte perpendicular al hueso a->b en b."""
    d = (b_pt[0] - a_pt[0], b_pt[1] - a_pt[1])
    after = half_plane(b_pt, d)
    return mask_leg_or_arm & ~after, mask_leg_or_arm & after


# brazos: parte alta (hombro->codo) y antebrazo+mano
UP_L, FORE_L = split_bone(A_A & M_AL, SH_L, EL_L)
UP_R, FORE_R = split_bone(A_A & M_AR, SH_R, EL_R)
ARM_PCS = {'lead': (cut(RGB_A, A_A, UP_L), cut(RGB_A, A_A, FORE_L)), 'trail': (cut(RGB_A, A_A, UP_R), cut(RGB_A, A_A, FORE_R))}

# piernas: muslo, espinilla, pie
def leg_pieces(mask, hip, kn, ak):
    thigh, rest = split_bone(A_A & mask, hip, kn)
    shin, foot = split_bone(rest, kn, ak)
    return cut(RGB_A, A_A, thigh), cut(RGB_A, A_A, shin), cut(RGB_A, A_A, foot)


LEG_PCS = {'lead': leg_pieces(M_LL, HIP_L, KN_L, AK_L), 'trail': leg_pieces(M_LR, HIP_R, KN_R, AK_R)}

if __name__ == '__main__':
    from PIL import Image
    pal = {'head': (255, 80, 80), 'chest': (80, 255, 80), 'belly': (60, 160, 255), 'upL': (255, 255, 0), 'foreL': (255, 160, 0),
           'upR': (255, 0, 255), 'foreR': (160, 0, 160), 'th': (0, 255, 255), 'sh': (0, 160, 160), 'ft': (255, 255, 255)}
    out = np.zeros((BH, BW, 3), np.uint8)
    def paint(pc, col):
        h, w = pc.a.shape
        out[pc.oy:pc.oy + h, pc.ox:pc.ox + w][pc.a] = col
    paint(CHEST_PC, pal['chest']); paint(BELLY_PC, pal['belly']); paint(HEAD_PC[0], pal['head'])
    paint(ARM_PCS['lead'][0], pal['upL']); paint(ARM_PCS['lead'][1], pal['foreL'])
    paint(ARM_PCS['trail'][0], pal['upR']); paint(ARM_PCS['trail'][1], pal['foreR'])
    for k, key in enumerate(('lead', 'trail')):
        paint(LEG_PCS[key][0], pal['th']); paint(LEG_PCS[key][1], pal['sh']); paint(LEG_PCS[key][2], pal['ft'])
    Image.fromarray(out[WY0:WY0 + 1200, WX0:WX0 + 960]).save('/home/claude/ref/parts.png')
    # B head sobre el torso
    out2 = np.zeros_like(out); 
    for pc in (CHEST_PC, BELLY_PC, HEAD_PC[1]):
        h, w = pc.a.shape; out2[pc.oy:pc.oy + h, pc.ox:pc.ox + w][pc.a] = pc.rgb[pc.a]
    Image.fromarray(out2[WY0:WY0 + 1200, WX0:WX0 + 960]).save('/home/claude/ref/partsB.png')
