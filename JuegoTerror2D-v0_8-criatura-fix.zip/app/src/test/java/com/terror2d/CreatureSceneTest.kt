package com.terror2d

import com.terror2d.creature.CreatureState
import com.terror2d.creature.NoiseType
import com.terror2d.core.GameState
import com.terror2d.input.InputController
import com.terror2d.pixel.CreatureSprite
import com.terror2d.pixel.CreatureSpriteData
import com.terror2d.pixel.LightingSample
import com.terror2d.pixel.ProtagonistSprite
import com.terror2d.scene.HouseDefinition
import com.terror2d.scene.HouseScene
import com.terror2d.story.StoryFlags
import com.terror2d.world.NarrowGap
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pruebas de 0.8 a nivel de escena y de sprite: integración de la criatura sin romper lo existente. */
class CreatureSceneTest {

    private class World(active: Boolean = true) {
        val state = GameState()
        val input = InputController()
        val scene = HouseScene(HouseDefinition.DEFAULT_SEED).also { it.load(state) }

        init {
            if (active) state.story.set(StoryFlags.CREATURE_ACTIVE)
            val spawn = scene.definition.segment(HouseDefinition.HALL).spawnPoints.keys.first()
            scene.loadSegment(HouseDefinition.HALL, spawn, state)
            scene.dialogue.clear()
        }

        fun step(n: Int = 1) {
            repeat(n) {
                scene.update(1f / 60f, input, state)
                input.endFrame()
            }
        }
    }

    @Test fun creatureOnlyAppearsOnceActive() {
        assertNull(World(active = false).scene.creature)
        assertNotNull(World(active = true).scene.creature)
    }

    @Test fun hallHasNarrowGapCreatureCannotCross() {
        val w = World()
        assertTrue(w.scene.currentSegment.objects.any { it is NarrowGap })
    }

    @Test fun noiseFromScenePutsCreatureInInvestigate() {
        val w = World()
        w.scene.player.x = 100f
        w.step(2)
        w.scene.makeNoise(NoiseType.OBJECT_BROKEN, 640f)
        w.step(20)
        assertEquals(CreatureState.INVESTIGATE, w.scene.creature!!.state)
    }

    @Test fun seeingTheChildStartsChase() {
        val w = World()
        val c = w.scene.creature!!
        w.scene.player.x = c.x + 40f
        w.step(30)
        assertEquals(CreatureState.CHASE, c.state)
    }

    @Test fun captureReturnsToBedroomWithoutGameOver() {
        val w = World()
        val c = w.scene.creature!!
        w.scene.player.x = c.x + 40f
        var sawCapture = false
        var steps = 0
        while (steps < 60 * 25 && !(sawCapture && !w.scene.capture.active)) {
            w.step()
            if (w.scene.capture.active) { sawCapture = true; assertFalse(w.scene.capture.isGameOver) }
            steps++
        }
        assertTrue(sawCapture)
        assertEquals(HouseDefinition.KID, w.scene.currentSegment.id)
        assertEquals(1, w.state.captureCount)
        assertNull(w.scene.creature)          // la criatura no persigue fuera de su segmento
    }

    @Test fun creatureSharesProtagonistPixelDensity() {
        assertEquals(ProtagonistSprite.SCALE, CreatureSprite.SCALE, 0f)
        // el sprite es mayor que el niño, pero NO se acerca a la densidad de la escena de Ranita (640x360)
        // la criatura (160x200 px de sprite, 0,5 px lógicos cada uno) cabe de sobra en la pantalla lógica de 640x360
        assertTrue(CreatureSpriteData.BODY_W * CreatureSprite.SCALE < 640 && CreatureSpriteData.BODY_H * CreatureSprite.SCALE < 360)
        assertTrue(CreatureSpriteData.BODY_W > ProtagonistSprite.W)
    }

    @Test fun layersDecodeWithPixels() {
        assertTrue(CreatureSprite.bodies.all { b -> b.any { it != 0 } })
        assertTrue(CreatureSprite.head.any { it != 0 })
        // el diseño canónico (v0.8 rediseño) tiene SIETE bocas en el vientre y ninguna secundaria en la cabeza
        assertEquals(7, CreatureSprite.SECONDARY_MOUTHS)
        assertEquals(CreatureSpriteData.HEAD_MOUTHS.size + CreatureSpriteData.TORSO_MOUTHS.size, CreatureSprite.SECONDARY_MOUTHS)
    }

    @Test fun creatureReceivesTheSameLighting() {
        val data = CreatureSprite.bodies[0]
        val n = CreatureSpriteData.BODY_W * CreatureSpriteData.BODY_H
        val lit = IntArray(n); val dark = IntArray(n)
        val l1 = LightingSample().also { it.set(1f, 1f, 1f, 1f) }
        val l0 = LightingSample().also { it.set(0f, 1f, 1f, 1f) }
        CreatureSprite.shade(data, CreatureSpriteData.BODY_W, CreatureSpriteData.BODY_H, l1, lit)
        CreatureSprite.shade(data, CreatureSpriteData.BODY_W, CreatureSpriteData.BODY_H, l0, dark)
        var i = data.indexOfFirst { it != 0 }
        assertTrue(((dark[i] shr 8) and 0xFF) < ((lit[i] shr 8) and 0xFF))
        // la escena le calcula la luz de la habitación a la criatura
        val w = World()
        w.step(2)
        assertTrue(w.scene.creature!!.light.brightness in 0f..1f)
    }
}
