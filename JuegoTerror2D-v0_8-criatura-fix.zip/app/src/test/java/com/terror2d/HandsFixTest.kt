package com.terror2d

import com.terror2d.conversation.ConversationView
import com.terror2d.pixel.ConversationArtData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** v0.8: corrección de las manos de la escena de Ranita. El sistema de temblor y respiración NO cambia. */
class HandsFixTest {
    private val names = ConversationArtData.LAYER_NAMES.toList()

    @Test fun fingersAreDrawnBehindThePlush() {
        val plush = names.indexOf("plush")
        for (n in names) if (n.length == 3 && (n.startsWith("l_") || n.startsWith("r_"))) {
            assertTrue("$n debe quedar detrás de Ranita", names.indexOf(n) < plush)
        }
        assertEquals(8, names.count { it.length == 3 && (it.startsWith("l_") || it.startsWith("r_")) })
    }

    @Test fun onlyTheTwoThumbsAreInFront() {
        val plush = names.indexOf("plush")
        val front = names.filterIndexed { i, _ -> i > plush }
        assertEquals(listOf("l_thumb", "r_thumb"), front)
    }

    @Test fun thumbNamesKeepGroupsAndAreNotFingers() {
        // el renderer reparte grupos por prefijo y solo trata como dedo los nombres de 3 caracteres
        for (n in listOf("l_thumb", "r_thumb")) assertTrue(n.length != 3)
        assertTrue("l_thumb".startsWith("l_"))
    }

    @Test fun tremorAndBreathingConstantsUntouched() {
        val v = ConversationView()
        v.setHandState(0.3f, 0.2f)       // la API existente sigue igual
        assertTrue(v.breathingIntensity >= 0f && v.handTremorIntensity >= 0f)
    }
}
