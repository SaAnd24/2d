package com.terror2d.world

import com.terror2d.pixel.LightingSample

/**
 * Cuánta luz recibe un PUNTO del mundo. Usa el mismo perfil de caída y las mismas luces que la
 * máscara de oscuridad ([com.terror2d.render.LightingRenderer]), de modo que el personaje reciba
 * exactamente la iluminación de la habitación. Lógica pura, sin allocations.
 */
object LightField {

    // Perfil de caída: igual que el degradado de la máscara (0xFF, 0xE6, 0x96, 0x3C, 0x00 en 0, .22, .5, .78, 1)
    private val FX = floatArrayOf(0f, 0.22f, 0.5f, 0.78f, 1f)
    private val FY = floatArrayOf(1f, 0.902f, 0.588f, 0.235f, 0f)

    /** Intensidad relativa (0..1) a la distancia normalizada [t] = distancia / radio. */
    fun falloff(t: Float): Float {
        if (t <= 0f) return 1f
        if (t >= 1f) return 0f
        for (i in 1 until FX.size) {
            if (t <= FX[i]) {
                val u = (t - FX[i - 1]) / (FX[i] - FX[i - 1])
                return FY[i - 1] + (FY[i] - FY[i - 1]) * u
            }
        }
        return 0f
    }

    /** Contribución (0..1) de una luz en (px,py) en el instante [time]. */
    fun contribution(l: LightSource, px: Float, py: Float, time: Float): Float {
        val k = l.effectiveIntensity(time)
        if (k <= 0.003f) return 0f
        val dx = px - l.x
        val dy = py - l.y
        val r2 = l.radius * l.radius
        val d2 = dx * dx + dy * dy
        if (d2 >= r2) return 0f
        val t = kotlin.math.sqrt(d2) / l.radius
        return k * falloff(t)
    }

    /**
     * Rellena [out] con el brillo y el tinte en (px,py): brillo = 1 - oscuridadAmbiente x (1 - luz recibida),
     * atenuado por las zonas oscuras; el tinte es el promedio de los colores de las luces que llegan.
     */
    fun sample(
        px: Float,
        py: Float,
        lights: List<LightSource>,
        ambientDark: Float,
        zones: List<DarkZone>,
        time: Float,
        out: LightingSample
    ) {
        var notLit = 1f
        var wSum = 0f
        var rSum = 0f
        var gSum = 0f
        var bSum = 0f
        for (i in 0 until lights.size) {
            val l = lights[i]
            val c = contribution(l, px, py, time)
            if (c <= 0f) continue
            notLit *= 1f - c
            val w = c * l.tintStrength
            wSum += w
            rSum += w * ((l.color shr 16) and 0xFF) / 255f
            gSum += w * ((l.color shr 8) and 0xFF) / 255f
            bSum += w * (l.color and 0xFF) / 255f
        }
        val lit = 1f - notLit
        var vis = 1f - ambientDark.coerceIn(0f, 1f) * (1f - lit)
        for (i in 0 until zones.size) {
            val z = zones[i]
            if (px >= z.x && px <= z.x + z.width && py >= z.y && py <= z.y + z.height) {
                vis *= 1f - 0.3f * z.strength.coerceIn(0f, 1f)
            }
        }
        if (wSum > 0.001f) {
            val amount = (wSum).coerceIn(0f, 1f) * 0.85f
            val r = rSum / wSum
            val g = gSum / wSum
            val b = bSum / wSum
            out.set(vis.coerceIn(0f, 1f), 1f + (r - 1f) * amount, 1f + (g - 1f) * amount, 1f + (b - 1f) * amount)
        } else {
            out.set(vis.coerceIn(0f, 1f), 1f, 1f, 1f)
        }
    }
}
