package com.terror2d.world

/**
 * Hueco bajo / paso estrecho (v0.8). El niño lo atraviesa caminando; la criatura, enorme, NO cabe: su cuerpo se
 * detiene en el borde. No es una «zona segura» artificial: es una ventaja física del mundo (el niño es pequeño).
 * Se ve a través de él (no bloquea la visión), así que la criatura sabe que el niño sigue ahí pero no puede alcanzarlo.
 */
class NarrowGap(val id: String, x: Float, floorY: Float, width: Float, height: Float = 30f) :
    WorldObject(x, floorY - height, width, height) {
    init {
        layer = Layer.DECOR
        fillColor = 0xE0201A22.toInt()
        hatchColor = 0xFF3A2A30.toInt()
        lineColor = 0xFF1A1218.toInt()
    }
}
