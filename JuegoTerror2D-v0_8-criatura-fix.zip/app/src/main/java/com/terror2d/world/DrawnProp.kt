package com.terror2d.world

import com.terror2d.draw.CrayonBuilder
import com.terror2d.draw.CrayonSprite
import com.terror2d.render.WorldRenderer
import com.terror2d.util.SeededRandom

/**
 * Objeto dibujado a crayón por una función. La función recibe el constructor y la esquina (x, y) del
 * objeto y dibuja en coordenadas absolutas. Se ejecuta UNA vez al cargar el segmento con la semilla
 * derivada del objeto (misma semilla => mismo dibujo, con sus imperfecciones). Sin colisión.
 */
class DrawnProp(
    x: Float,
    y: Float,
    w: Float,
    h: Float,
    layerValue: Int = Layer.OBJECT,
    private val build: (CrayonBuilder, Float, Float) -> Unit
) : WorldObject(x, y, w, h) {

    var sprite: CrayonSprite = CrayonSprite.EMPTY
        private set

    init {
        collidable = false
        layer = layerValue
    }

    override fun prepareVisuals(rng: SeededRandom) {
        val b = CrayonBuilder(rng)
        build(b, x, y)
        sprite = b.finish()
        outline = EMPTY
        hatch = EMPTY
    }

    override fun visualHash(seed: Long): Long = sprite.hash(seed)

    override fun render(r: WorldRenderer) {
        r.drawSprite(sprite)
    }
}
