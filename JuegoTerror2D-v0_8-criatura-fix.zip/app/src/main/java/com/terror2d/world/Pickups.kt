package com.terror2d.world

import com.terror2d.draw.CrayonSprite
import com.terror2d.events.EventType
import com.terror2d.inventory.ItemRegistry
import com.terror2d.interaction.Interactable
import com.terror2d.interaction.InteractionContext
import com.terror2d.interaction.InteractionIcon
import com.terror2d.interaction.InteractionResult
import com.terror2d.render.WorldRenderer
import com.terror2d.util.SeededRandom

/**
 * Objeto del mundo que se puede recoger y volver a dejar en su sitio (cajas de medicinas, etc.).
 * - En su sitio ([isAtHome]): "RECOGER" (animación + va al inventario y a las manos).
 * - Si el niño lo lleva y está cerca: "DEJAR" (animación de entrega + vuelve a su sitio).
 * - Con las manos ocupadas por otra cosa: "Tengo las manos ocupadas."
 * El dibujo se genera una vez con la semilla (misma semilla = mismo dibujo).
 */
class WorldPickup(
    val id: String,
    val itemId: String,
    x: Float,
    y: Float,
    w: Float,
    h: Float,
    private val pickupText: String,
    private val margin: Float = 6f,
    private val onPicked: ((InteractionContext) -> Unit)? = null,
    /** Mientras devuelva false el objeto no se puede coger (p. ej. cuando el puzzle se encarga de las cajas). */
    private val enabledWhen: ((InteractionContext) -> Boolean)? = null
) : WorldObject(x, y, w, h), Interactable {

    var isAtHome: Boolean = true
        private set

    init {
        collidable = false
        layer = Layer.OBJECT
    }

    override fun prepareVisuals(rng: SeededRandom) {
        outline = EMPTY
        hatch = EMPTY
    }

    override fun visualHash(seed: Long): Long = CrayonSprite.EMPTY.hash(seed) + itemId.hashCode()

    /** Se dibuja con el sprite CANÓNICO del objeto (el mismo que en la mano, el HUD y el puzzle). */
    override fun render(r: WorldRenderer) {
        if (isAtHome) r.drawItemOnGround(itemId, centerX, bottom)
    }

    // ---------- Interactable ----------

    override val interactionId: String get() = id
    override val promptText: String get() = if (isAtHome) "RECOGER" else "DEJAR"
    override val promptIcon: InteractionIcon get() = if (isAtHome) InteractionIcon.PICK else InteractionIcon.GIVE
    override val zoneLeft: Float get() = x - margin
    override val zoneRight: Float get() = right + margin
    override val markerX: Float get() = centerX
    override val markerY: Float get() = y - 3f

    override fun canInteract(ctx: InteractionContext): Boolean {
        if (enabledWhen != null && !enabledWhen.invoke(ctx)) return false
        return isAtHome || ctx.inventory.isHolding(itemId)
    }

    override fun executeInteraction(ctx: InteractionContext): InteractionResult {
        if (isAtHome) {
            if (ctx.held != null) return InteractionResult.message("Tengo las manos ocupadas.")
            return InteractionResult.pickup(itemId) { c ->
                isAtHome = false
                onPicked?.invoke(c)
                InteractionResult.message(pickupText)
            }
        }
        return InteractionResult.give(itemId) { c ->
            isAtHome = true
            c.post(EventType.ON_ITEM_PLACED, itemId)
            InteractionResult.message("La dejo donde estaba.")
        }
    }

    /** Vuelve a su sitio (al recargar el segmento). */
    fun reset() {
        isAtHome = true
    }
}

/** Estados del peluche de rana. Todavía NO habla ni tiene personalidad (eso llega en v0.7). */
enum class PlushState { ON_FLOOR, HELD, PLACED }

/**
 * La ranita de peluche (cuerpo completo): en el suelo, en las manos del niño o dejada en un sitio.
 * Es el peluche de la farmacia (cruz verde en la barriga y gorrito). Solo objeto: sin voz ni autonomía.
 */
class PlushFrog(
    val id: String,
    x: Float,
    floorY: Float
) : WorldObject(x, floorY - HEIGHT, WIDTH, HEIGHT), Interactable {

    var state: PlushState = PlushState.ON_FLOOR
        private set

    private val homeX = x
    private val homeY = floorY - HEIGHT

    /** Esquina donde está dibujado ahora (suelo o lugar donde se dejó). */
    private var drawX = x
    private var drawY = floorY - HEIGHT

    init {
        collidable = false
        layer = Layer.OBJECT
    }

    /** Deja el peluche en un sitio (esquina superior izquierda del dibujo). */
    fun placeAt(px: Float, py: Float) {
        state = PlushState.PLACED
        drawX = px
        drawY = py
        x = px
        y = py
    }

    fun reset() {
        state = PlushState.ON_FLOOR
        drawX = homeX
        drawY = homeY
        x = homeX
        y = homeY
    }

    override fun prepareVisuals(rng: SeededRandom) {
        outline = EMPTY
        hatch = EMPTY
    }

    override fun visualHash(seed: Long): Long = CrayonSprite.EMPTY.hash(seed) + ItemRegistry.FROG_PLUSH.hashCode()

    /**
     * ESCALA CANÓNICA ÚNICA: en el suelo, en la cama (PLACED), en la mano, en el inventario y en HOLD_ITEM se
     * dibuja el MISMO sprite de 16x16 px lógicos (32x32 píxeles de pixel art). Nada de versiones por separado.
     */
    override fun render(r: WorldRenderer) {
        if (state != PlushState.HELD) r.drawItemOnGround(ItemRegistry.FROG_PLUSH, drawX + WIDTH / 2f, drawY + HEIGHT)
    }

    // ---------- Interactable ----------

    override val interactionId: String get() = id
    override val promptText: String get() = "RECOGER"
    override val promptIcon: InteractionIcon get() = InteractionIcon.PICK
    override val zoneLeft: Float get() = x - 8f
    override val zoneRight: Float get() = right + 8f
    override val markerX: Float get() = centerX
    override val markerY: Float get() = y - 3f

    override fun canInteract(ctx: InteractionContext): Boolean = state != PlushState.HELD

    override fun executeInteraction(ctx: InteractionContext): InteractionResult {
        if (state == PlushState.HELD) return InteractionResult.IGNORED
        if (ctx.held != null) return InteractionResult.message("Tengo las manos ocupadas.")
        // v0.7: al recogerlo pasa al COMPANION SLOT (a la espalda del niño); [PlushState.HELD] significa "ya lo lleva".
        return InteractionResult.pickup(ItemRegistry.FROG_PLUSH) { _ ->
            state = PlushState.HELD
            InteractionResult.message("Ranita. Me la dieron en la farmacia. Siempre sonríe.")
        }
    }

    companion object {
        /** Tamaño canónico en pantalla (lógico): una ranita pequeña que un niño de 8 años puede sostener. */
        const val WIDTH = 16f
        const val HEIGHT = 16f
    }
}
