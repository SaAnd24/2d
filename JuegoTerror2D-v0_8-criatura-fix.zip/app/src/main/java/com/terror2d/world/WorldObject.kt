package com.terror2d.world

import com.terror2d.render.WorldRenderer
import com.terror2d.util.SeededRandom

/**
 * Capas de dibujado (vista lateral). FLOOR/DECOR van detrás del jugador (pared, cuadros, dibujos);
 * OBJECT también va detrás del jugador (muebles, puertas); FOREGROUND se dibuja DELANTE del
 * jugador (reservado para primeros planos oscuros en futuras versiones).
 */
object Layer {
    const val FLOOR = 0
    const val DECOR = 1
    const val OBJECT = 2
    const val FOREGROUND = 3
}

/**
 * Base de todo lo que existe en el mundo (en coordenadas del mundo, no de pantalla).
 * Vista lateral: la base del objeto (bottom) se apoya en el suelo del segmento.
 * Futuro: muebles (Bed, Table...), objetos interactivos, NPCs, enemigos, decoración...
 */
open class WorldObject(
    var x: Float,
    var y: Float,
    var width: Float,
    var height: Float
) {
    var visible: Boolean = true
    var collidable: Boolean = false
    var layer: Int = Layer.OBJECT

    // Aspecto (crayón)
    var fillColor: Int = 0xB0AAAAAA.toInt()
    var hatchColor: Int = 0xCC777777.toInt()
    var lineColor: Int = 0xFF3A2A20.toInt()
    var hatchSpacing: Float = 3f

    /** Imperfecciones precalculadas (se rellenan en prepareVisuals con la semilla). */
    var outline: FloatArray = EMPTY
    var hatch: FloatArray = EMPTY

    val right: Float get() = x + width
    val bottom: Float get() = y + height
    val centerX: Float get() = x + width * 0.5f
    val centerY: Float get() = y + height * 0.5f

    /** Genera el aspecto dibujado a mano de forma determinista. */
    open fun prepareVisuals(rng: SeededRandom) {
        outline = SketchBuilder.buildOutline(x, y, width, height, rng)
        hatch = SketchBuilder.buildHatch(x, y, width, height, hatchSpacing, rng)
    }

    open fun update(dt: Float) {}

    /** Huella del aspecto generado (misma semilla => mismo valor). Usada en tests. */
    open fun visualHash(seed: Long): Long = hashFloats(hashFloats(seed, outline), hatch)

    open fun render(r: WorldRenderer) {
        r.drawSketchBox(this)
    }

    companion object {
        val EMPTY = FloatArray(0)

        fun hashFloats(seed: Long, a: FloatArray): Long {
            var h = seed
            for (i in a.indices) h = 31L * h + a[i].toRawBits().toLong()
            return h
        }
    }
}
