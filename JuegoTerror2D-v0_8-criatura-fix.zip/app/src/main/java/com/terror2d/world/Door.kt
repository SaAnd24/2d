package com.terror2d.world

import com.terror2d.events.EventType
import com.terror2d.interaction.Interactable
import com.terror2d.interaction.InteractionContext
import com.terror2d.interaction.InteractionIcon
import com.terror2d.interaction.InteractionResult
import com.terror2d.render.WorldRenderer
import kotlin.math.max
import kotlin.math.min

/** Destino de una puerta: segmento y punto de aparición dentro de él. */
class DoorTarget(val segmentId: String, val spawnId: String)

/**
 * Puerta de un segmento lateral. Representa posición, estado abierto/cerrado/bloqueado, destino y
 * la animación de apertura. No tiene colisión: es una zona con la que el jugador interactúa.
 *
 * v0.3: usa el sistema genérico de interacción ([Interactable]). Abrir devuelve una transición
 * (la escena espera a que la hoja termine de abrirse, funde y carga el destino); una puerta
 * bloqueada devuelve un texto en su lugar.
 */
class Door(
    val id: String,
    x: Float,
    floorY: Float,
    width: Float = DEFAULT_WIDTH,
    height: Float = DEFAULT_HEIGHT,
    val target: DoorTarget? = null,
    /** Bloqueada: no se abre; muestra [lockedText]. */
    val locked: Boolean = false,
    val lockedText: String = "La puerta está cerrada.",
    /** Color de la hoja (cada puerta de la casa tiene el suyo). */
    val panelColor: Int = com.terror2d.render.Palette.DOOR_PANEL,
    val panelHatch: Int = com.terror2d.render.Palette.DOOR_HATCH
) : WorldObject(x, floorY - height, width, height), Interactable {

    var isOpen: Boolean = false
        private set

    /** 0 = cerrada, 1 = completamente abierta. */
    var openProgress: Float = 0f
        private set

    /** Cerrándose (animación inversa). */
    private var closing: Boolean = false

    init {
        collidable = false
        layer = Layer.OBJECT
    }

    // ---------- Interactable ----------

    override val interactionId: String get() = id
    override val promptText: String get() = if (locked) "PUERTA" else "ABRIR"
    override val promptIcon: InteractionIcon get() = InteractionIcon.DOOR
    override val zoneLeft: Float get() = x - NEAR_MARGIN
    override val zoneRight: Float get() = right + NEAR_MARGIN
    override val markerX: Float get() = centerX
    override val markerY: Float get() = y - 4f

    override fun canInteract(ctx: InteractionContext): Boolean = !isOpen

    override fun executeInteraction(ctx: InteractionContext): InteractionResult {
        if (locked) return InteractionResult.message(lockedText)
        if (!activate()) return InteractionResult.IGNORED
        ctx.post(EventType.ON_DOOR_OPEN, id)
        val t = target ?: return InteractionResult.DONE
        return InteractionResult.transition(t, this)
    }

    /** ¿Está el jugador lo bastante cerca como para usarla? */
    fun isPlayerNear(p: Player): Boolean = isInRange(p)

    // ---------- Estado ----------

    /** Abre la puerta. Devuelve true si cambió de estado. */
    fun activate(): Boolean {
        if (isOpen || locked) return false
        isOpen = true
        closing = false
        return true
    }

    /** Empieza a cerrarla con animación. Devuelve true si cambió de estado. */
    fun close(): Boolean {
        if (!isOpen) return false
        isOpen = false
        closing = true
        return true
    }

    /** Vuelve a cerrarla de golpe (se llama al cargar el segmento). */
    fun reset() {
        isOpen = false
        closing = false
        openProgress = 0f
    }

    override fun update(dt: Float) {
        if (isOpen && openProgress < 1f) openProgress = min(1f, openProgress + dt / OPEN_TIME)
        if (closing) {
            openProgress = max(0f, openProgress - dt / OPEN_TIME)
            if (openProgress <= 0f) closing = false
        }
    }

    override fun render(r: WorldRenderer) {
        r.drawDoor(this)
    }

    companion object {
        const val DEFAULT_WIDTH = 34f
        const val DEFAULT_HEIGHT = 76f
        const val NEAR_MARGIN = 10f

        /** Segundos que tarda la animación de apertura antes de la transición. */
        const val OPEN_TIME = 0.3f
    }
}
