package com.terror2d.world

import com.terror2d.util.SeededRandom
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Genera, UNA SOLA VEZ al cargar la escena, las imperfecciones "dibujadas a mano".
 * Todo sale de SeededRandom: misma semilla = mismo dibujo. En render solo se leen arrays.
 */
object SketchBuilder {

    /** Contorno de caja: 2 trazos x 4 aristas x 4 floats. */
    const val OUTLINE_FLOATS = 32

    fun buildOutline(x: Float, y: Float, w: Float, h: Float, rng: SeededRandom): FloatArray {
        val out = FloatArray(OUTLINE_FLOATS)
        val cx = FloatArray(4)
        val cy = FloatArray(4)
        for (stroke in 0 until 2) {
            val j = 0.6f + stroke * 0.7f
            cx[0] = x + rng.nextSigned() * j; cy[0] = y + rng.nextSigned() * j
            cx[1] = x + w + rng.nextSigned() * j; cy[1] = y + rng.nextSigned() * j
            cx[2] = x + w + rng.nextSigned() * j; cy[2] = y + h + rng.nextSigned() * j
            cx[3] = x + rng.nextSigned() * j; cy[3] = y + h + rng.nextSigned() * j
            for (e in 0 until 4) {
                val b = (e + 1) % 4
                val dx = cx[b] - cx[e]
                val dy = cy[b] - cy[e]
                val len = max(0.001f, sqrt(dx * dx + dy * dy))
                val over = rng.nextFloat(0f, 1.6f) // el trazo se pasa un poco de la esquina
                val base = stroke * 16 + e * 4
                out[base] = cx[e]
                out[base + 1] = cy[e]
                out[base + 2] = cx[b] + dx / len * over
                out[base + 3] = cy[b] + dy / len * over
            }
        }
        return out
    }

    /** Relleno de crayón: trazos casi horizontales, ligeramente inclinados e irregulares. */
    fun buildHatch(x: Float, y: Float, w: Float, h: Float, spacing: Float, rng: SeededRandom): FloatArray {
        val count = max(1, (h / spacing).toInt())
        val arr = FloatArray(count * 4)
        for (i in 0 until count) {
            val yy = y + (i + 0.5f) * spacing
            var xs = x + 0.5f + rng.nextFloat(0f, 2.5f)
            var xe = x + w - 0.5f - rng.nextFloat(0f, 2.5f)
            if (xe <= xs) {
                xs = x
                xe = x + w
            }
            arr[i * 4] = xs
            arr[i * 4 + 1] = yy + rng.nextSigned() * 0.6f
            arr[i * 4 + 2] = xe
            arr[i * 4 + 3] = yy + rng.nextSigned() * 1.2f
        }
        return arr
    }

    /** Motas de papel: pares x,y dentro del área. */
    fun buildSpeckles(w: Float, h: Float, count: Int, rng: SeededRandom): FloatArray {
        val arr = FloatArray(count * 2)
        for (i in 0 until count) {
            arr[i * 2] = rng.nextFloat(0f, w)
            arr[i * 2 + 1] = rng.nextFloat(0f, h)
        }
        return arr
    }

    /** Relleno de crayón vertical (papel pintado de la pared): trazos casi verticales e irregulares. */
    fun buildVerticalHatch(x: Float, y: Float, w: Float, h: Float, spacing: Float, rng: SeededRandom): FloatArray {
        val count = max(1, (w / spacing).toInt())
        val arr = FloatArray(count * 4)
        for (i in 0 until count) {
            val xx = x + (i + 0.5f) * spacing
            var ys = y + 0.5f + rng.nextFloat(0f, 3f)
            var ye = y + h - 0.5f - rng.nextFloat(0f, 3f)
            if (ye <= ys) {
                ys = y
                ye = y + h
            }
            arr[i * 4] = xx + rng.nextSigned() * 0.8f
            arr[i * 4 + 1] = ys
            arr[i * 4 + 2] = xx + rng.nextSigned() * 1.2f
            arr[i * 4 + 3] = ye
        }
        return arr
    }
}
