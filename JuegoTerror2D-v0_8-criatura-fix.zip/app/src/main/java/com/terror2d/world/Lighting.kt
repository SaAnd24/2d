package com.terror2d.world

import kotlin.math.sin

/** Tipo de fuente de luz (para que futuras versiones traten cada una a su manera). */
enum class LightType {
    /** Lámpara fija de la habitación (la principal fuente de luz de v0.3). */
    LAMP,

    /** Resplandor tenue alrededor del jugador: nunca lo pierdes del todo de vista. */
    GLOW,

    /** Reservada: linterna que el jugador podrá llevar. */
    FLASHLIGHT,

    /** Reservada: velas, fuego, ventanas con luna... */
    AMBIENT_SPOT
}

/**
 * Fuente de luz localizada (solo datos + estado). El dibujo lo hace [com.terror2d.render.LightingRenderer],
 * que "abre" la oscuridad alrededor de cada fuente activa.
 *
 * - [x], [y]: posición en el mundo; [radius]: alcance; [intensity]: 0..1.
 * - [color]: tinte de la luz (ARGB, solo cuenta el RGB); [tintStrength]: cuánto tiñe (0 = nada).
 * - [active]: encendida/apagada; [level] se acerca suavemente al estado (fundido al encender/apagar).
 * - [flicker]: amplitud del parpadeo (0 = estable).
 */
class LightSource(
    var x: Float,
    var y: Float,
    val radius: Float,
    val color: Int,
    val intensity: Float = 1f,
    val type: LightType = LightType.LAMP,
    active: Boolean = true,
    val tintStrength: Float = 1f,
    val flicker: Float = 0f,
    private val flickerPhase: Float = 0f
) {
    var active: Boolean = active
        set(value) {
            field = value
        }

    /** 0 = apagada del todo, 1 = encendida del todo. */
    var level: Float = if (active) 1f else 0f
        private set

    /** Caché reservada al renderizador (shader del tinte); la lógica no la toca. */
    @JvmField var renderCache: Any? = null

    /** Avanza el fundido de encendido/apagado. */
    fun update(dt: Float) {
        val target = if (active) 1f else 0f
        if (level < target) {
            level += dt * FADE_SPEED
            if (level > target) level = target
        } else if (level > target) {
            level -= dt * FADE_SPEED
            if (level < target) level = target
        }
    }

    /** Intensidad final (0..1) en el instante [time]: base x fundido x parpadeo. */
    fun effectiveIntensity(time: Float): Float {
        if (level <= 0.001f) return 0f
        var k = intensity * level
        if (flicker > 0f) {
            val wave = 0.5f + 0.5f * sin(time * 7.3f + flickerPhase) * sin(time * 2.1f + flickerPhase * 0.5f)
            k *= 1f - flicker * wave
        }
        return k.coerceIn(0f, 1f)
    }

    /** ¿Alcanza esta luz al punto (px, py)? (geométrico; para tests y lógica futura) */
    fun reaches(px: Float, py: Float): Boolean {
        val dx = px - x
        val dy = py - y
        return dx * dx + dy * dy <= radius * radius
    }

    companion object {
        const val FADE_SPEED = 5f
    }
}

/** Compatibilidad con v0.2: `Light` es ahora una [LightSource]. */
typealias Light = LightSource

/** Zona oscura rectangular (solo datos). strength: 0 (nada) a 1 (muy oscura). */
class DarkZone(
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val strength: Float
)
