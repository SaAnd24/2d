package com.terror2d.world

/** Colisiones rectangulares (AABB), ejes separados. Sin allocations. */
object CollisionSystem {

    fun overlaps(a: WorldObject, b: WorldObject): Boolean =
        a.x < b.right && a.right > b.x && a.y < b.bottom && a.bottom > b.y

    /** Apoya al [mover] sobre el suelo: su base queda exactamente en [floorY]. */
    fun snapToFloor(mover: WorldObject, floorY: Float) {
        mover.y = floorY - mover.height
    }

    /**
     * Movimiento lateral: mueve [mover] en X, lo limita a [leftBoundary]/[rightBoundary]
     * (cuerpo completo) y lo detiene contra los sólidos. Devuelve true si algo lo bloqueó.
     * El mover debe estar ya apoyado en el suelo ([snapToFloor]).
     */
    fun moveHorizontal(
        mover: WorldObject,
        dx: Float,
        solids: List<WorldObject>,
        leftBoundary: Float,
        rightBoundary: Float
    ): Boolean {
        var blocked = false
        mover.x += dx
        if (mover.x < leftBoundary) {
            mover.x = leftBoundary
            if (dx != 0f) blocked = true
        }
        if (mover.right > rightBoundary) {
            mover.x = rightBoundary - mover.width
            if (dx != 0f) blocked = true
        }
        for (i in 0 until solids.size) {
            val s = solids[i]
            if (s === mover || !s.collidable) continue
            if (overlaps(mover, s)) {
                if (dx > 0f) {
                    mover.x = s.x - mover.width
                    blocked = true
                } else if (dx < 0f) {
                    mover.x = s.right
                    blocked = true
                }
            }
        }
        return blocked
    }

    /**
     * Mueve [mover] (dx, dy) y lo resuelve contra los límites de la escena y los sólidos.
     * Resuelve primero X y luego Y para permitir deslizarse por las paredes.
     */
    fun moveAndCollide(
        mover: WorldObject,
        dx: Float,
        dy: Float,
        solids: List<WorldObject>,
        boundsWidth: Float,
        boundsHeight: Float
    ) {
        // Eje X
        mover.x += dx
        if (mover.x < 0f) mover.x = 0f
        if (mover.x + mover.width > boundsWidth) mover.x = boundsWidth - mover.width
        for (i in 0 until solids.size) {
            val s = solids[i]
            if (s === mover || !s.collidable) continue
            if (overlaps(mover, s)) {
                if (dx > 0f) mover.x = s.x - mover.width
                else if (dx < 0f) mover.x = s.right
            }
        }

        // Eje Y
        mover.y += dy
        if (mover.y < 0f) mover.y = 0f
        if (mover.y + mover.height > boundsHeight) mover.y = boundsHeight - mover.height
        for (i in 0 until solids.size) {
            val s = solids[i]
            if (s === mover || !s.collidable) continue
            if (overlaps(mover, s)) {
                if (dy > 0f) mover.y = s.y - mover.height
                else if (dy < 0f) mover.y = s.bottom
            }
        }
    }
}
