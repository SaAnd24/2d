package com.terror2d.world

import com.terror2d.render.WorldRenderer
import com.terror2d.render.Palette
import com.terror2d.util.SeededRandom
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Pared sólida. */
class Wall(x: Float, y: Float, w: Float, h: Float) : WorldObject(x, y, w, h) {
    init {
        collidable = true
        fillColor = Palette.WALL_FILL
        hatchColor = Palette.WALL_HATCH
        lineColor = Palette.WALL_LINE
    }
}

/** Objeto sólido genérico (caja, cubo de juguete, pilar...). */
class Block(
    x: Float, y: Float, w: Float, h: Float,
    fill: Int, hatchTone: Int
) : WorldObject(x, y, w, h) {
    init {
        collidable = true
        fillColor = fill
        hatchColor = hatchTone
    }
}

/**
 * Objeto del plano de fondo (mueble, caja...): se dibuja detrás del jugador y NO tiene colisión,
 * así que el jugador pasa por delante y nunca queda bloqueado el camino hacia una puerta.
 */
class Prop(
    x: Float, y: Float, w: Float, h: Float,
    fill: Int, hatchTone: Int
) : WorldObject(x, y, w, h) {
    init {
        collidable = false
        layer = Layer.OBJECT
        fillColor = fill
        hatchColor = hatchTone
    }
}

/** Alfombra: decoración sin colisión, siempre bajo el jugador. */
class Rug(x: Float, y: Float, w: Float, h: Float) : WorldObject(x, y, w, h) {
    init {
        collidable = false
        layer = Layer.DECOR
        fillColor = Palette.RUG_FILL
        hatchColor = Palette.RUG_HATCH
        hatchSpacing = 2.5f
    }
}

/** Garabato en espiral: decoración infantil determinista (sin colisión). */
class Doodle(x: Float, y: Float, size: Float) : WorldObject(x, y, size, size) {
    init {
        collidable = false
        layer = Layer.DECOR
        lineColor = Palette.BLUE_HATCH
    }

    override fun prepareVisuals(rng: SeededRandom) {
        val segs = 44
        val arr = FloatArray(segs * 4)
        val cx = centerX
        val cy = centerY
        val maxR = min(width, height) / 2f
        var px = cx
        var py = cy
        for (i in 0 until segs) {
            val t = (i + 1) / segs.toFloat()
            val ang = t * 3.5f * 2f * PI.toFloat()
            val r = maxR * t + rng.nextSigned() * 0.8f
            val nx = cx + cos(ang) * r
            val ny = cy + sin(ang) * r
            arr[i * 4] = px
            arr[i * 4 + 1] = py
            arr[i * 4 + 2] = nx
            arr[i * 4 + 3] = ny
            px = nx
            py = ny
        }
        hatch = arr
        outline = EMPTY
    }

    override fun render(r: WorldRenderer) {
        r.drawStrokes(hatch, lineColor, 1.6f)
    }
}

/**
 * Objeto formado por varias piezas dibujadas (silla, cuadro, lámpara...). Cada pieza deriva su
 * semilla del generador del objeto, así que el resultado es determinista. Sin colisión propia:
 * la colisión, si existe, la define el objeto compuesto.
 */
open class CompositeObject(x: Float, y: Float, w: Float, h: Float) : WorldObject(x, y, w, h) {
    protected val parts = ArrayList<WorldObject>()

    protected fun part(px: Float, py: Float, pw: Float, ph: Float, fill: Int, hatchTone: Int): WorldObject {
        val b = Block(px, py, pw, ph, fill, hatchTone)
        b.collidable = false
        parts.add(b)
        return b
    }

    override fun prepareVisuals(rng: SeededRandom) {
        for (i in 0 until parts.size) parts[i].prepareVisuals(SeededRandom(rng.nextLong()))
        outline = EMPTY
        hatch = EMPTY
    }

    override fun render(r: WorldRenderer) {
        for (i in 0 until parts.size) parts[i].render(r)
    }

    override fun visualHash(seed: Long): Long {
        var h = seed
        for (i in 0 until parts.size) h = parts[i].visualHash(h)
        return h
    }
}

/** Silla de perfil apoyada en el suelo. Decoración del plano de fondo (el jugador pasa por delante). */
class Chair(x: Float, floorY: Float) : CompositeObject(x, floorY - HEIGHT, WIDTH, HEIGHT) {
    init {
        collidable = false
        layer = Layer.OBJECT
        part(x, floorY - 34f, 4f, 20f, Palette.CRATE_FILL, Palette.CRATE_HATCH)                  // respaldo
        part(x, floorY - 16f, WIDTH, 4f, Palette.CRATE_FILL, Palette.CRATE_HATCH)                // asiento
        part(x + 1f, floorY - 12f, 3f, 12f, Palette.CRATE_FILL, Palette.CRATE_HATCH)             // pata trasera
        part(x + WIDTH - 4f, floorY - 12f, 3f, 12f, Palette.CRATE_FILL, Palette.CRATE_HATCH)     // pata delantera
    }

    companion object {
        const val WIDTH = 24f
        const val HEIGHT = 34f
    }
}

/** Caja de juguetes con un par de cubos encima (plano de fondo). */
class ToyBox(x: Float, floorY: Float) : CompositeObject(x, floorY - HEIGHT, WIDTH, HEIGHT) {
    init {
        collidable = false
        layer = Layer.OBJECT
        part(x, floorY - 22f, WIDTH, 22f, Palette.CRATE_FILL, Palette.CRATE_HATCH)
        part(x + 3f, floorY - 32f, 11f, 10f, Palette.BLUE_FILL, Palette.BLUE_HATCH)
        part(x + 16f, floorY - 30f, 10f, 8f, Palette.GREEN_FILL, Palette.GREEN_HATCH)
    }

    companion object {
        const val WIDTH = 34f
        const val HEIGHT = 32f
    }
}

/** Estante de pared con libros. [y] es la altura de la tabla. */
class Shelf(x: Float, y: Float, w: Float) : CompositeObject(x, y - 16f, w, 20f) {
    init {
        collidable = false
        layer = Layer.DECOR
        part(x, y, w, 4f, Palette.PICTURE_FRAME_FILL, Palette.PICTURE_FRAME_HATCH)
        part(x + 4f, y - 14f, 6f, 14f, Palette.BLUE_FILL, Palette.BLUE_HATCH)
        part(x + 11f, y - 11f, 5f, 11f, Palette.GREEN_FILL, Palette.GREEN_HATCH)
        part(x + 17f, y - 16f, 7f, 16f, Palette.CRATE_FILL, Palette.CRATE_HATCH)
    }
}

/** Cuadro de pared con un garabato dentro. Decoración (detrás del jugador). */
class PictureFrame(x: Float, y: Float, w: Float, h: Float) : CompositeObject(x, y, w, h) {
    init {
        collidable = false
        layer = Layer.DECOR
        part(x, y, w, h, Palette.PICTURE_FRAME_FILL, Palette.PICTURE_FRAME_HATCH)
        part(x + 3f, y + 3f, w - 6f, h - 6f, Palette.PICTURE_INNER_FILL, Palette.PICTURE_INNER_HATCH)
        val d = minOf(w, h) - 10f
        parts.add(Doodle(x + (w - d) / 2f, y + (h - d) / 2f, d))
    }
}

/**
 * Lámpara colgante. Es la fuente de luz de la habitación: lleva su [light] asociada para que el
 * segmento la registre. La pantalla y la bombilla se dibujan siempre; la luz las "abre" de la oscuridad.
 */
class Lamp(
    x: Float,
    cordLength: Float,
    radius: Float = 110f,
    intensity: Float = 1f,
    color: Int = Palette.LIGHT_WARM or 0xFF000000.toInt(),
    flicker: Float = 0f,
    startOn: Boolean = true
) : CompositeObject(x - SHADE_W / 2f, 0f, SHADE_W, cordLength + SHADE_H) {

    val light = LightSource(
        x = x,
        y = cordLength + SHADE_H + 2f,
        radius = radius,
        color = color,
        intensity = intensity,
        type = LightType.LAMP,
        active = startOn,
        flicker = flicker,
        flickerPhase = x * 0.37f
    )

    private val bulbX = x
    private val bulbY = cordLength + SHADE_H + 2f

    init {
        collidable = false
        layer = Layer.DECOR
        part(x - 0.75f, 0f, 1.5f, cordLength, Palette.LAMP_CORD, Palette.LAMP_CORD)
        part(x - SHADE_W / 2f, cordLength, SHADE_W, SHADE_H, Palette.LAMP_SHADE_FILL, Palette.LAMP_SHADE_HATCH)
    }

    override fun render(r: WorldRenderer) {
        super.render(r)
        r.drawBulb(bulbX, bulbY, light.level)
    }

    companion object {
        const val SHADE_W = 26f
        const val SHADE_H = 14f
    }
}
