package com.terror2d.world

import com.terror2d.events.EventBus
import com.terror2d.events.EventType
import com.terror2d.interaction.Interactable
import com.terror2d.interaction.InteractionContext
import com.terror2d.interaction.InteractionIcon
import com.terror2d.interaction.InteractionResult
import com.terror2d.render.WorldRenderer
import com.terror2d.util.SeededRandom
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Decoración pintada en la puerta del armario (distingue unos armarios de otros). */
enum class WardrobeDeco { NONE, STAR, STRIPES, MOON }

/**
 * Aspecto de un armario. Es DATO explícito (lo decide el diseño de la habitación), no azar:
 * así los cuatro armarios son distintos de forma estable. El azar ([SeededRandom]) solo añade
 * imperfecciones de trazo y arañazos.
 */
class WardrobeStyle(
    val bodyFill: Int,
    val bodyHatch: Int,
    val doorFill: Int,
    val trim: Int,
    val doorCount: Int = 2,
    val deco: WardrobeDeco = WardrobeDeco.NONE,
    val decoColor: Int = 0xFFFFE066.toInt()
)

/** Fases del armario: mecánica de esconderse en bruto, sin enemigos. */
enum class WardrobePhase {
    CLOSED,
    OPENING_TO_ENTER,
    CLOSING_BEHIND,
    OCCUPIED,
    OPENING_TO_EXIT,
    CLOSING_AFTER_EXIT
}

/**
 * Armario interactuable donde el jugador puede esconderse.
 *
 *   CLOSED -> (acción) OPENING_TO_ENTER -> CLOSING_BEHIND -> OCCUPIED
 *   OCCUPIED -> (acción) OPENING_TO_EXIT -> CLOSING_AFTER_EXIT -> CLOSED
 *
 * Es un mueble del plano de fondo (no tiene colisión): el jugador se coloca delante, la puerta se
 * abre, el personaje se desvanece dentro y la puerta se cierra. Al salir reaparece justo delante
 * del armario ([exitX]), siempre dentro de los límites del segmento.
 */
class Wardrobe(
    val id: String,
    x: Float,
    floorY: Float,
    val style: WardrobeStyle,
    width: Float = DEFAULT_WIDTH,
    height: Float = DEFAULT_HEIGHT
) : WorldObject(x, floorY - height, width, height), Interactable {

    var phase: WardrobePhase = WardrobePhase.CLOSED
        private set

    /** Apertura de la puerta (0..1) para animar el armario. */
    var doorOpen: Float = 0f
        private set

    /** Abertura que se muestra (con rendija mientras hay alguien dentro). */
    val visualOpen: Float
        get() = if (phase == WardrobePhase.OCCUPIED) AJAR else max(doorOpen, if (phase == WardrobePhase.CLOSING_BEHIND) AJAR else 0f)

    val isOccupied: Boolean get() = phase == WardrobePhase.OCCUPIED

    // Aspecto generado con la semilla (trazos del dibujo)
    var deco: FloatArray = WorldObject.EMPTY
    var scratches: FloatArray = WorldObject.EMPTY

    // Estado de la interacción en curso
    private var user: Player? = null
    private var events: EventBus? = null
    private var segmentId: String = ""
    private var segLeft: Float = 0f
    private var segRight: Float = 0f
    private var segCenter: Float = 0f
    private var startX: Float = 0f
    private var examined: Boolean = false

    init {
        collidable = false
        layer = Layer.OBJECT
    }

    // ---------- Posiciones ----------

    /** X (esquina izquierda del jugador) donde reaparece al salir: justo delante, dentro de los límites. */
    val exitX: Float get() = clampPlayerX(centerX - Player.WIDTH / 2f)

    private fun clampPlayerX(px: Float): Float {
        if (segRight <= segLeft) return px
        return px.coerceIn(segLeft, segRight - Player.WIDTH)
    }

    // ---------- Interactable ----------

    override val interactionId: String get() = id
    override val promptText: String get() = if (phase == WardrobePhase.OCCUPIED) "SALIR" else "ESCONDERSE"
    override val promptIcon: InteractionIcon get() = if (phase == WardrobePhase.OCCUPIED) InteractionIcon.EXIT else InteractionIcon.HIDE
    override val zoneLeft: Float get() = x - NEAR_MARGIN
    override val zoneRight: Float get() = right + NEAR_MARGIN
    override val markerX: Float get() = centerX
    override val markerY: Float get() = y - 6f
    override val worksWhileHidden: Boolean get() = true

    override fun canInteract(ctx: InteractionContext): Boolean =
        phase == WardrobePhase.CLOSED && ctx.player.state == PlayerState.NORMAL ||
            phase == WardrobePhase.OCCUPIED && ctx.player.isHidden && user === ctx.player

    override fun executeInteraction(ctx: InteractionContext): InteractionResult {
        events = ctx.events
        segmentId = ctx.segment.id
        segLeft = ctx.segment.leftBoundary
        segRight = ctx.segment.rightBoundary
        segCenter = (ctx.segment.leftBoundary + ctx.segment.rightBoundary) / 2f
        val p = ctx.player
        return when (phase) {
            WardrobePhase.CLOSED -> {
                if (p.state != PlayerState.NORMAL) {
                    InteractionResult.IGNORED
                } else {
                    user = p
                    startX = p.x
                    p.beginHide()
                    phase = WardrobePhase.OPENING_TO_ENTER
                    if (!examined) {
                        examined = true
                        InteractionResult.doneWithMessage("El armario está vacío.")
                    } else {
                        InteractionResult.DONE
                    }
                }
            }
            WardrobePhase.OCCUPIED -> {
                if (user !== p) {
                    InteractionResult.IGNORED
                } else {
                    p.beginLeave()
                    doorOpen = AJAR
                    phase = WardrobePhase.OPENING_TO_EXIT
                    InteractionResult.DONE
                }
            }
            else -> InteractionResult.IGNORED
        }
    }

    // ---------- Animación ----------

    override fun update(dt: Float) {
        val p = user
        when (phase) {
            WardrobePhase.OPENING_TO_ENTER -> {
                doorOpen = min(1f, doorOpen + dt / OPEN_TIME)
                if (p != null) {
                    // El jugador se centra delante del armario y se desvanece al entrar.
                    val tx = exitX
                    p.x = startX + (tx - startX) * min(1f, doorOpen * 1.6f)
                    p.visibilityAlpha = max(0f, 1f - doorOpen)
                }
                if (doorOpen >= 1f) {
                    p?.finishHide()
                    phase = WardrobePhase.CLOSING_BEHIND
                }
            }
            WardrobePhase.CLOSING_BEHIND -> {
                doorOpen = max(AJAR, doorOpen - dt / CLOSE_TIME)
                if (doorOpen <= AJAR) {
                    doorOpen = 0f
                    phase = WardrobePhase.OCCUPIED
                    events?.post(EventType.ON_HIDE, id, segmentId)
                }
            }
            WardrobePhase.OCCUPIED -> {
                doorOpen = 0f
            }
            WardrobePhase.OPENING_TO_EXIT -> {
                doorOpen = min(1f, doorOpen + dt / OPEN_TIME)
                if (p != null) {
                    p.x = exitX
                    p.visibilityAlpha = max(0f, (doorOpen - 0.4f) / 0.6f)
                    p.facing = if (centerX < segCenter) 1f else -1f
                }
                if (doorOpen >= 1f) {
                    if (p != null) {
                        p.x = exitX
                        p.finishLeave()
                    }
                    phase = WardrobePhase.CLOSING_AFTER_EXIT
                }
            }
            WardrobePhase.CLOSING_AFTER_EXIT -> {
                doorOpen = max(0f, doorOpen - dt / CLOSE_TIME)
                if (doorOpen <= 0f) {
                    phase = WardrobePhase.CLOSED
                    user = null
                    events?.post(EventType.ON_EXIT_HIDE, id, segmentId)
                }
            }
            WardrobePhase.CLOSED -> {}
        }
    }

    /** Vuelve al estado inicial (se llama al cargar un segmento). */
    fun reset() {
        phase = WardrobePhase.CLOSED
        doorOpen = 0f
        user = null
        examined = false
    }

    // ---------- Aspecto ----------

    override fun prepareVisuals(rng: SeededRandom) {
        outline = SketchBuilder.buildOutline(x, y, width, height, rng)
        hatch = SketchBuilder.buildHatch(x + 2f, y + 2f, width - 4f, height - 6f, 3f, rng)
        deco = buildDeco(rng)
        // Arañazos: 2..4 trazos cortos en el cuerpo (cantidad y posición con la semilla; solo estética).
        val n = 2 + rng.nextInt(3)
        val arr = FloatArray(n * 4)
        for (i in 0 until n) {
            val sx = x + rng.nextFloat(6f, width - 12f)
            val sy = y + rng.nextFloat(height * 0.55f, height - 12f)
            arr[i * 4] = sx
            arr[i * 4 + 1] = sy
            arr[i * 4 + 2] = sx + rng.nextFloat(3f, 7f)
            arr[i * 4 + 3] = sy + rng.nextFloat(-2f, 3f)
        }
        scratches = arr
    }

    /** Centro de la decoración (en la puerta izquierda, o en la única puerta). */
    val decoCenterX: Float get() = if (style.doorCount >= 2) x + width * 0.30f else x + width * 0.5f
    val decoCenterY: Float get() = y + height * 0.40f

    private fun buildDeco(rng: SeededRandom): FloatArray {
        val cx = decoCenterX
        val cy = decoCenterY
        return when (style.deco) {
            WardrobeDeco.NONE -> WorldObject.EMPTY
            WardrobeDeco.STAR -> {
                // Estrella de 5 puntas: 5 trazos (pentagrama) con temblor de crayón.
                val arr = FloatArray(5 * 4)
                val r = 7f
                for (i in 0 until 5) {
                    val a0 = (-PI / 2.0 + i * 4.0 * PI / 5.0).toFloat()
                    val a1 = (-PI / 2.0 + (i + 1) * 4.0 * PI / 5.0).toFloat()
                    arr[i * 4] = cx + cos(a0) * r + rng.nextSigned() * 0.5f
                    arr[i * 4 + 1] = cy + sin(a0) * r + rng.nextSigned() * 0.5f
                    arr[i * 4 + 2] = cx + cos(a1) * r + rng.nextSigned() * 0.5f
                    arr[i * 4 + 3] = cy + sin(a1) * r + rng.nextSigned() * 0.5f
                }
                arr
            }
            WardrobeDeco.STRIPES -> {
                val arr = FloatArray(3 * 4)
                for (i in 0 until 3) {
                    val yy = cy - 8f + i * 8f
                    arr[i * 4] = cx - 9f + rng.nextSigned() * 0.6f
                    arr[i * 4 + 1] = yy + rng.nextSigned() * 0.6f
                    arr[i * 4 + 2] = cx + 9f + rng.nextSigned() * 0.6f
                    arr[i * 4 + 3] = yy + rng.nextSigned() * 0.9f
                }
                arr
            }
            WardrobeDeco.MOON -> {
                // Media luna: polilínea de 10 segmentos (arco exterior) + arco interior.
                val segs = 8
                val arr = FloatArray(segs * 2 * 4)
                var k = 0
                for (arc in 0 until 2) {
                    val r = if (arc == 0) 8f else 6f
                    val ox = if (arc == 0) 0f else 2.6f
                    for (i in 0 until segs) {
                        val a0 = (PI * 0.35 + i * (PI * 1.3) / segs).toFloat()
                        val a1 = (PI * 0.35 + (i + 1) * (PI * 1.3) / segs).toFloat()
                        arr[k++] = cx + ox + cos(a0) * r + rng.nextSigned() * 0.3f
                        arr[k++] = cy + sin(a0) * r + rng.nextSigned() * 0.3f
                        arr[k++] = cx + ox + cos(a1) * r + rng.nextSigned() * 0.3f
                        arr[k++] = cy + sin(a1) * r + rng.nextSigned() * 0.3f
                    }
                }
                arr
            }
        }
    }

    override fun visualHash(seed: Long): Long {
        var h = WorldObject.hashFloats(seed, outline)
        h = WorldObject.hashFloats(h, hatch)
        h = WorldObject.hashFloats(h, deco)
        return WorldObject.hashFloats(h, scratches)
    }

    override fun render(r: WorldRenderer) {
        r.drawWardrobe(this)
    }

    companion object {
        const val DEFAULT_WIDTH = 46f
        const val DEFAULT_HEIGHT = 76f
        const val NEAR_MARGIN = 12f

        /** Segundos de animación al abrir / cerrar. */
        const val OPEN_TIME = 0.28f
        const val CLOSE_TIME = 0.22f

        /** Rendija con la que queda la puerta cuando hay alguien dentro. */
        const val AJAR = 0.16f
    }
}
