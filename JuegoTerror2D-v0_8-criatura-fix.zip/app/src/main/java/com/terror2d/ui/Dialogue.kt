package com.terror2d.ui

/** Una línea de texto: quién habla (opcional) y qué dice. */
class DialogueLine(val speaker: String?, val text: String)

/**
 * Base mínima del texto del juego (v0.3). Soporta dos usos con la misma maquinaria:
 *  - mensaje breve ([showMessage]): aparece, se escribe y desaparece solo; NO bloquea el movimiento;
 *  - diálogo ([startDialogue]): varias líneas (personaje + texto) que avanzan con la acción
 *    ([advance]); bloquea el movimiento mientras dura.
 * Sin elecciones ni narrativa: eso llegará más adelante sobre esta estructura.
 *
 * Sin dependencias de Android (testeable en JVM). Sin allocations por frame.
 */
class DialogueManager {

    private val lines = ArrayList<DialogueLine>()
    private var index = 0
    private var autoClose = false
    private var onFinished: (() -> Unit)? = null

    /** Línea que se muestra ahora (null = no hay texto). */
    var current: DialogueLine? = null
        private set

    /** Caracteres ya "escritos" de la línea actual. */
    var visibleChars: Int = 0
        private set

    /** Incrementa solo cuando cambia la línea (la UI lo usa para recalcular el ajuste de texto). */
    var lineSerial: Int = 0
        private set

    private var revealClock = 0f
    private var holdClock = 0f

    val isActive: Boolean get() = current != null

    /** true = es un diálogo: bloquea el movimiento y espera a la acción. */
    val blocksInput: Boolean get() = current != null && !autoClose

    val isFullyRevealed: Boolean get() = current?.let { visibleChars >= it.text.length } ?: true

    /** Muestra un texto breve que se cierra solo. Sustituye a cualquier mensaje anterior. */
    fun showMessage(text: String, speaker: String? = null) {
        if (blocksInput) return // un diálogo en curso no se interrumpe con mensajes
        lines.clear()
        lines.add(DialogueLine(speaker, text))
        index = 0
        autoClose = true
        onFinished = null
        begin()
    }

    /** Inicia un diálogo de varias líneas (bloquea el movimiento hasta terminar). */
    fun startDialogue(newLines: List<DialogueLine>, finished: (() -> Unit)? = null) {
        if (newLines.isEmpty()) return
        lines.clear()
        lines.addAll(newLines)
        index = 0
        autoClose = false
        onFinished = finished
        begin()
    }

    /**
     * Acción del jugador: completa la escritura de la línea o pasa a la siguiente.
     * Devuelve true si consumió la pulsación.
     */
    fun advance(): Boolean {
        val c = current ?: return false
        if (visibleChars < c.text.length) {
            visibleChars = c.text.length
            return true
        }
        nextLine()
        return true
    }

    fun clear() {
        current = null
        lines.clear()
        visibleChars = 0
        onFinished = null
    }

    fun update(dt: Float) {
        val c = current ?: return
        if (visibleChars < c.text.length) {
            revealClock += dt
            var n = (revealClock * CHARS_PER_SECOND).toInt()
            if (n > c.text.length) n = c.text.length
            visibleChars = n
            holdClock = 0f
        } else if (autoClose) {
            holdClock += dt
            if (holdClock >= HOLD_BASE + c.text.length * HOLD_PER_CHAR) nextLine()
        }
    }

    private fun begin() {
        current = lines[index]
        visibleChars = 0
        revealClock = 0f
        holdClock = 0f
        lineSerial++
    }

    private fun nextLine() {
        index++
        if (index < lines.size) {
            begin()
        } else {
            val cb = onFinished
            clear()
            cb?.invoke()
        }
    }

    companion object {
        const val CHARS_PER_SECOND = 48f
        const val HOLD_BASE = 1.3f
        const val HOLD_PER_CHAR = 0.03f
    }
}
