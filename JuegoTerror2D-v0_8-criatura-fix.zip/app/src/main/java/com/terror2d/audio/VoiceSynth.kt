package com.terror2d.audio

import kotlin.math.max

/**
 * Perfil de una voz: todo lo que define su carácter. Cambiar un perfil no toca la lógica del juego.
 * Los perfiles DOCTOR, NEIGHBOR y MONSTER ya existen (para añadir personajes sin tocar el motor) pero 0.7 no los usa.
 */
class VoiceProfile(
    val id: VoiceId,
    val basePitch: Float,        // Hz
    val pitchSpread: Float,      // semitonos de variación aleatoria entre sílabas
    val syllable: Float,         // segundos por sílaba
    val gap: Float,              // segundos entre sílabas
    val wave: Int,
    val attack: Float,
    val decay: Float,
    val sustain: Float,
    val release: Float,
    val breath: Float,           // ruido mezclado (0..1)
    val vibRate: Float,
    val vibDepth: Float,
    val formantScale: Float,     // >1 = tracto vocal más corto (voz más aguda/infantil)
    val formantGain: Float,
    val fmRatio: Float,          // timbre "extraño" (FM); 0 = sin FM
    val fmDepth: Float,
    val crush: Int,              // bitcrusher (0 = sin)
    val reverbSend: Float,
    val echoSend: Float,
    val level: Float,
    val consonants: Float        // probabilidad de un pequeño ataque de ruido en cada sílaba
)

/** Cómo una emoción modula una voz. */
class EmotionShape(
    val pitch: Float,
    val contour: Float,          // semitonos por sílaba (sube o baja la frase)
    val speed: Float,
    val breath: Float,
    val vibrato: Float,
    val sustain: Float
)

object EmotionShapes {
    private val shapes = arrayOf(
        EmotionShape(1.00f, 0.0f, 1.00f, 0.00f, 1.0f, 1.0f),    // NEUTRAL
        EmotionShape(1.00f, -0.30f, 0.85f, 0.10f, 1.2f, 1.1f),  // SOFT
        EmotionShape(0.97f, -0.20f, 0.90f, 0.06f, 1.4f, 1.1f),  // WARM
        EmotionShape(1.12f, 0.60f, 1.15f, 0.00f, 1.3f, 0.9f),   // HAPPY
        EmotionShape(1.06f, 0.45f, 1.12f, 0.05f, 2.4f, 0.9f),   // WORRIED
        EmotionShape(0.90f, -0.55f, 0.76f, 0.10f, 1.8f, 1.2f),  // SAD
        EmotionShape(1.04f, 0.10f, 1.22f, 0.00f, 3.0f, 0.8f),   // TENSE
        EmotionShape(0.92f, -0.40f, 0.70f, 0.18f, 1.0f, 1.2f),  // TIRED
        EmotionShape(0.98f, 0.00f, 0.86f, 0.04f, 0.8f, 1.1f)    // CALM
    )

    fun of(e: Emotion): EmotionShape = shapes[e.ordinal]
}

/** Perfiles de voz por defecto (datos puros; también los consulta la escena de conversación para sincronizar). */
object VoiceProfiles {
    val all: List<VoiceProfile> = listOf(
            // CHILD: suave, corta, relativamente aguda, infantil
            VoiceProfile(VoiceId.CHILD, 330f, 3.2f, 0.105f, 0.045f, Wave.SAW, 0.012f, 0.04f, 0.65f, 0.05f,
                0.16f, 5.6f, 0.010f, 1.25f, 2.6f, 0f, 0f, 0, 0.12f, 0f, 0.55f, 0.45f),
            // MOTHER: más cálida y grave, humana
            VoiceProfile(VoiceId.MOTHER, 205f, 2.6f, 0.150f, 0.060f, Wave.SAW, 0.030f, 0.07f, 0.70f, 0.09f,
                0.22f, 5.0f, 0.014f, 1.00f, 2.8f, 0f, 0f, 0, 0.20f, 0f, 0.60f, 0.30f),
            // FROG: artificial, pequeña, infantil, ligeramente extraña (FM + bitcrusher suave + eco). NO terrorífica.
            VoiceProfile(VoiceId.FROG, 520f, 4.0f, 0.090f, 0.055f, Wave.TRI, 0.006f, 0.04f, 0.55f, 0.06f,
                0.05f, 7.0f, 0.016f, 1.50f, 3.0f, 2.01f, 0.30f, 28, 0.20f, 0.14f, 0.50f, 0.20f),
            // Preparadas para el futuro (sin uso todavía)
            VoiceProfile(VoiceId.DOCTOR, 125f, 2.0f, 0.140f, 0.060f, Wave.SAW, 0.02f, 0.06f, 0.7f, 0.08f,
                0.18f, 4.5f, 0.008f, 0.88f, 2.8f, 0f, 0f, 0, 0.25f, 0f, 0.60f, 0.25f),
            VoiceProfile(VoiceId.NEIGHBOR, 165f, 3.0f, 0.130f, 0.055f, Wave.SAW, 0.02f, 0.06f, 0.7f, 0.08f,
                0.20f, 4.8f, 0.012f, 0.95f, 2.8f, 0f, 0f, 0, 0.20f, 0f, 0.60f, 0.30f),
            VoiceProfile(VoiceId.MONSTER, 70f, 5.0f, 0.220f, 0.080f, Wave.SQUARE, 0.03f, 0.10f, 0.7f, 0.20f,
                0.30f, 3.0f, 0.03f, 0.70f, 3.0f, 1.5f, 0.6f, 12, 0.45f, 0.30f, 0.70f, 0.10f)
    )

    private val map = HashMap<VoiceId, VoiceProfile>().also { m -> for (p in all) m[p.id] = p }

    fun get(id: VoiceId): VoiceProfile = map.getValue(id)
}

class VoiceSynth(private val core: EngineCore) {

    private val profiles = HashMap<VoiceId, VoiceProfile>()

    init {
        for (p in VoiceProfiles.all) register(p)
    }

    fun register(p: VoiceProfile) {
        profiles[p.id] = p
    }

    fun profile(id: VoiceId): VoiceProfile = profiles[id] ?: profiles.getValue(VoiceId.CHILD)

    /**
     * Genera una frase vocal. El texto del juego NO se pronuncia: la voz es feedback emocional (balbuceo, "mmm", "hm").
     * Programa voces con retardo en la reserva; no reserva memoria.
     */
    fun speak(id: VoiceId, emotion: Emotion, intensity: Float, kind: VoiceKind, units: Int, seed: Int) {
        val p = profile(id)
        val shape = EmotionShapes.of(emotion)
        val rng = FastRng(seed * 7919 + 17 + id.ordinal * 101)
        val inten = intensity.coerceIn(0f, 1f)
        when (kind) {
            VoiceKind.HUM -> hum(p, shape, inten, units, rng)
            VoiceKind.HM -> hm(p, shape, inten, rng)
            VoiceKind.BABBLE -> babble(p, shape, inten, units.coerceIn(1, 12), rng)
        }
    }

    private fun setup(v: SynthVoice, p: VoiceProfile, shape: EmotionShape, inten: Float) {
        v.wave = p.wave
        v.noiseMix = (p.breath + shape.breath * (0.5f + inten)).coerceIn(0f, 0.7f)
        v.vibRate = p.vibRate
        v.vibDepth = p.vibDepth * shape.vibrato * (0.6f + inten)
        v.fmRatio = p.fmRatio
        v.fmDepth = p.fmDepth
        v.crush = p.crush
        v.formGain = p.formantGain
        v.send = p.reverbSend
        v.echo = p.echoSend
        v.pitchMul = core.pitchMul
    }

    private fun babble(p: VoiceProfile, shape: EmotionShape, inten: Float, count: Int, rng: FastRng) {
        var t = 0f
        for (k in 0 until count) {
            val vowel = Vowels.pick(rng)
            val st = rng.range(-p.pitchSpread, p.pitchSpread) * 0.5f + shape.contour * k
            val pitch = p.basePitch * shape.pitch * semitones(st)
            val dur = p.syllable * rng.range(0.8f, 1.25f) / shape.speed
            val v = core.pool.obtain(Bus.VOICE)
            setup(v, p, shape, inten)
            v.freq = pitch
            v.freqEnd = pitch * semitones(shape.contour * 0.8f + rng.range(-0.6f, 0.6f))
            v.glide = core.samples(dur)
            v.env(p.attack, p.decay, p.sustain * shape.sustain, dur, p.release)
            v.setFormants(Vowels.f1(vowel) * p.formantScale, Vowels.f2(vowel) * p.formantScale, 5f, 7f)
            v.level = p.level * (0.35f + 0.65f * inten) * rng.range(0.85f, 1.15f)
            v.delay = core.samples(t)
            // pequeño ataque consonántico (ruido filtrado) al inicio de algunas sílabas
            if (rng.chance(p.consonants)) {
                val c = core.pool.obtain(Bus.VOICE)
                c.wave = Wave.NOISE
                c.env(0.001f, 0f, 1f, 0.012f, 0.014f)
                c.setFilter(2, rng.range(1800f, 3200f), rng.range(1800f, 3200f), 2.2f)
                c.level = p.level * 0.5f * (0.4f + 0.6f * inten)
                c.send = p.reverbSend
                c.delay = core.samples(t)
            }
            t += (dur + p.gap / shape.speed * rng.range(0.7f, 1.3f))
        }
    }

    /** "Mmm...": un zumbido nasal largo que baja un poco de tono. */
    private fun hum(p: VoiceProfile, shape: EmotionShape, inten: Float, units: Int, rng: FastRng) {
        val dur = humSeconds(units)
        val pitch = p.basePitch * 0.62f * shape.pitch
        val v = core.pool.obtain(Bus.VOICE)
        setup(v, p, shape, inten)
        v.noiseMix = (v.noiseMix * 0.5f)
        v.freq = pitch
        v.freqEnd = pitch * semitones(-1.4f + rng.range(-0.3f, 0.3f))
        v.glide = core.samples(dur)
        v.env(min(0.12f, dur * 0.3f), 0.1f, 0.85f, dur, min(0.2f, dur * 0.4f))
        v.setFormants(Vowels.NASAL_F1 * p.formantScale, Vowels.NASAL_F2 * p.formantScale, 6f, 8f)
        v.f2Gain = 0.4f
        v.level = p.level * (0.4f + 0.6f * inten)
        v.vibDepth = p.vibDepth * 1.4f
    }

    /** "hm": exhalación breve + sonido corto. */
    private fun hm(p: VoiceProfile, shape: EmotionShape, inten: Float, rng: FastRng) {
        val b = core.pool.obtain(Bus.VOICE)
        b.wave = Wave.NOISE
        b.env(0.01f, 0f, 1f, 0.05f, 0.05f)
        b.setFilter(2, 1400f, 900f, 1.3f)
        b.level = p.level * 0.25f * (0.4f + 0.6f * inten)
        b.send = p.reverbSend
        val pitch = p.basePitch * 0.72f * shape.pitch
        val v = core.pool.obtain(Bus.VOICE)
        setup(v, p, shape, inten)
        v.freq = pitch
        v.freqEnd = pitch * semitones(2.2f + rng.range(-0.4f, 0.4f))
        v.glide = core.samples(HM_SECONDS)
        v.env(0.02f, 0.05f, 0.7f, HM_SECONDS, 0.08f)
        v.setFormants(Vowels.NASAL_F1 * p.formantScale, 1500f * p.formantScale, 6f, 8f)
        v.level = p.level * (0.4f + 0.6f * inten)
        v.delay = core.samples(0.04f)
    }

    private fun min(a: Float, b: Float): Float = if (a < b) a else b

    companion object {
        const val HM_SECONDS = 0.20f

        fun humSeconds(units: Int): Float = max(0.2f, units * 0.25f)

        /**
         * Duración aproximada (segundos) de una frase vocal, para que la escena de conversación pueda sincronizar el
         * silencio y el texto con el sonido sin conocer la síntesis.
         */
        fun estimateSeconds(kind: VoiceKind, units: Int, emotion: Emotion, voice: VoiceId): Float {
            val profile = VoiceProfiles.get(voice)
            val shape = EmotionShapes.of(emotion)
            return when (kind) {
                VoiceKind.HUM -> humSeconds(units) + 0.2f
                VoiceKind.HM -> HM_SECONDS + 0.12f
                VoiceKind.BABBLE -> units.coerceIn(1, 12) * (profile.syllable + profile.gap) / shape.speed + 0.1f
            }
        }
    }
}

/** Formantes (F1, F2) de las vocales: lo que da carácter "humano" al balbuceo. */
object Vowels {
    private val F1 = floatArrayOf(800f, 450f, 300f, 450f, 325f)    // a e i o u
    private val F2 = floatArrayOf(1200f, 1900f, 2300f, 900f, 700f)
    const val NASAL_F1 = 270f
    const val NASAL_F2 = 1100f

    fun pick(rng: FastRng): Int = rng.pick(5)
    fun f1(v: Int): Float = F1[v]
    fun f2(v: Int): Float = F2[v]
}
