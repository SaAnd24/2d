package com.terror2d.audio

/**
 * Efectos de sonido procedurales. Cada recibo es una receta corta de voces (tonos, golpes de ruido filtrado) con
 * pequeñas variaciones aleatorias para que dos pasos nunca suenen idénticos. Sin archivos de audio.
 */
class SfxSynth(private val core: EngineCore) {

    private var stepCount = 0

    fun play(sfx: SfxId, intensity: Float, surface: Surface) {
        val g = intensity.coerceIn(0f, 1.5f)
        when (sfx) {
            SfxId.FOOTSTEP -> footstep(surface, g)
            SfxId.PICKUP -> pickup(g)
            SfxId.DROP -> drop(g)
            SfxId.INTERACT -> interact(g)
            SfxId.DOCUMENT_OPEN -> paper(g, 0.34f, 5)
            SfxId.PAPER -> paper(g, 0.16f, 3)
            SfxId.GLASS -> glass(g)
            SfxId.WATER -> water(g)
            SfxId.MEDICINE -> medicine(g)
            SfxId.DOOR_OPEN -> doorOpen(g)
            SfxId.DOOR_CLOSE -> doorClose(g)
            SfxId.BREATH -> breath(g)
            SfxId.THUD -> thud(g, 80f, 0.5f)
            SfxId.CLICK -> click(g, 1700f)
            SfxId.HEARTBEAT -> heartbeat(g)
            SfxId.CLOTH -> cloth(g, 0.12f)
            SfxId.PLUSH_TAP -> plushTap(g)
            SfxId.TEXT_TICK -> textTick(g)
            SfxId.CHIME -> chime(g)
            SfxId.CREATURE_BREATH -> creatureBreath(g)
            SfxId.CREATURE_STEP -> creatureStep(g)
            SfxId.CREATURE_ARM -> creatureArm(g)
            SfxId.CREATURE_WET -> creatureWet(g)
            SfxId.CREATURE_MOUTH -> creatureMouth(g)
            SfxId.CREATURE_GROWL -> creatureGrowl(g)
            SfxId.CREATURE_ALERT -> creatureAlert(g)
            SfxId.CREATURE_CHASE -> creatureChase(g)
            SfxId.CREATURE_LOST -> creatureLost(g)
            SfxId.CREATURE_CAPTURE -> creatureCapture(g)
        }
    }

    // ---------------------------------------------------------------- bloques de construcción

    private fun tone(wave: Int, f0: Float, f1: Float, att: Float, hold: Float, rel: Float, level: Float, delayS: Float = 0f): SynthVoice {
        val v = core.pool.obtain(Bus.SFX)
        v.wave = wave
        v.freq = f0
        v.freqEnd = f1
        v.glide = core.samples(hold + rel)
        v.env(att, 0f, 1f, hold, rel)
        v.curve = 2
        v.level = level
        v.delay = core.samples(delayS)
        v.pitchMul = core.pitchMul
        v.send = 0.10f
        return v
    }

    private fun noise(att: Float, hold: Float, rel: Float, level: Float, mode: Int, c0: Float, c1: Float, q: Float, delayS: Float = 0f): SynthVoice {
        val v = core.pool.obtain(Bus.SFX)
        v.wave = Wave.NOISE
        v.env(att, 0f, 1f, hold, rel)
        v.curve = 2
        v.setFilter(mode, c0 * core.pitchMul, c1 * core.pitchMul, q)
        v.level = level
        v.delay = core.samples(delayS)
        v.send = 0.10f
        return v
    }

    private fun vary(): Float = core.rng.range(0.92f, 1.08f)

    // ---------------------------------------------------------------- recetas

    private fun footstep(surface: Surface, g: Float) {
        val r = core.rng
        val lvl = g * r.range(0.8f, 1.1f)
        // pie izquierdo / derecho: ligeramente distinto
        val side = if ((stepCount++ and 1) == 0) 1f else 0.93f
        when (surface) {
            Surface.WOOD -> {
                tone(Wave.SINE, 118f * vary() * side, 52f, 0.002f, 0.02f, 0.10f, 0.50f * lvl)
                noise(0.002f, 0.015f, 0.05f, 0.30f * lvl, 1, 1500f, 500f, 0.8f)
                if (r.chance(0.10f)) {          // madera que cruje de vez en cuando
                    val c = tone(Wave.SAW, r.range(190f, 260f), r.range(140f, 190f), 0.01f, 0.07f, 0.09f, 0.045f * lvl, 0.03f)
                    c.setFilter(1, 700f, 500f, 2.5f)
                    c.vibRate = 24f; c.vibDepth = 0.05f
                }
            }
            Surface.TILE -> {
                noise(0.001f, 0.006f, 0.03f, 0.45f * lvl, 2, 2600f * side, 1800f, 3.0f)
                tone(Wave.SINE, 1500f * vary(), 900f, 0.001f, 0.006f, 0.03f, 0.10f * lvl)
                tone(Wave.SINE, 95f, 60f, 0.002f, 0.01f, 0.07f, 0.25f * lvl)
            }
            Surface.GROUND -> {
                noise(0.004f, 0.02f, 0.08f, 0.40f * lvl, 1, 1900f, 700f, 0.7f)
                for (k in 0 until 3) noise(0.001f, 0.004f, 0.012f, 0.12f * lvl, 3, 3000f, 3000f, 1f, r.range(0.01f, 0.08f))
                tone(Wave.SINE, 85f, 55f, 0.003f, 0.015f, 0.07f, 0.22f * lvl)
            }
            Surface.HOSPITAL -> {
                noise(0.001f, 0.006f, 0.03f, 0.40f * lvl, 2, 2300f, 1700f, 3.0f)
                // chirrido de goma
                val sq = tone(Wave.SINE, 1700f * vary(), 2400f * vary(), 0.004f, 0.04f, 0.04f, 0.05f * lvl, 0.01f)
                sq.send = 0.35f
                tone(Wave.SINE, 100f, 60f, 0.002f, 0.01f, 0.06f, 0.20f * lvl)
            }
        }
    }

    private fun pickup(g: Float) {
        noise(0.01f, 0.05f, 0.07f, 0.20f * g, 2, 2800f, 4200f, 1.2f)
        tone(Wave.SINE, 520f * vary(), 700f * vary(), 0.005f, 0.05f, 0.08f, 0.11f * g, 0.02f)
        tone(Wave.TRI, 780f * vary(), 980f, 0.005f, 0.03f, 0.08f, 0.05f * g, 0.07f)
    }

    private fun drop(g: Float) {
        noise(0.004f, 0.03f, 0.06f, 0.20f * g, 2, 3600f, 2200f, 1.0f)
        tone(Wave.SINE, 150f * vary(), 70f, 0.002f, 0.03f, 0.10f, 0.40f * g, 0.03f)
    }

    private fun interact(g: Float) {
        tone(Wave.SINE, 640f * vary(), 640f, 0.003f, 0.02f, 0.07f, 0.10f * g)
        tone(Wave.SINE, 960f * vary(), 960f, 0.003f, 0.02f, 0.07f, 0.06f * g, 0.045f)
    }

    private fun paper(g: Float, length: Float, grains: Int) {
        val r = core.rng
        val step = length / grains
        for (k in 0 until grains) {
            val t = k * step * r.range(0.7f, 1.2f)
            noise(0.004f, step * 0.5f, step * 0.8f, 0.17f * g * r.range(0.6f, 1.1f), 2, r.range(2600f, 4200f), r.range(1800f, 3200f), 0.9f, t)
        }
        noise(0.02f, length * 0.6f, length * 0.4f, 0.05f * g, 3, 5000f, 3500f, 0.7f)
    }

    private fun glass(g: Float) {
        val base = 2350f * vary()
        tone(Wave.SINE, base, base, 0.001f, 0.01f, 0.30f, 0.12f * g).send = 0.30f
        tone(Wave.SINE, base * 1.51f, base * 1.51f, 0.001f, 0.01f, 0.20f, 0.07f * g).send = 0.30f
        tone(Wave.SINE, base * 2.19f, base * 2.19f, 0.001f, 0.005f, 0.12f, 0.04f * g).send = 0.30f
        noise(0.001f, 0.004f, 0.02f, 0.12f * g, 3, 4500f, 4500f, 1f)
    }

    private fun water(g: Float) {
        val r = core.rng
        noise(0.12f, 0.75f, 0.30f, 0.14f * g, 2, 1100f, 1500f, 1.6f)
        for (k in 0 until 7) {
            val f = r.range(380f, 900f)
            tone(Wave.SINE, f, f * 1.9f, 0.002f, 0.015f, 0.05f, 0.05f * g, r.range(0.05f, 1.0f))
        }
    }

    private fun medicine(g: Float) {
        val r = core.rng
        for (k in 0 until 4) noise(0.001f, 0.004f, 0.02f, 0.14f * g, 2, r.range(1800f, 2800f), 1800f, 2.5f, k * r.range(0.04f, 0.08f))
        tone(Wave.SINE, 190f, 110f, 0.002f, 0.02f, 0.08f, 0.22f * g, 0.02f)
    }

    private fun doorOpen(g: Float) {
        click(g * 0.6f, 900f)
        val c = tone(Wave.SAW, 130f, 190f, 0.05f, 0.40f, 0.12f, 0.07f * g, 0.04f)
        c.setFilter(1, 700f, 1100f, 2.8f)
        c.vibRate = 22f; c.vibDepth = 0.06f
        c.curve = 1
        noise(0.05f, 0.35f, 0.15f, 0.04f * g, 2, 500f, 800f, 2f, 0.05f)
    }

    private fun doorClose(g: Float) {
        thud(g, 70f, 0.6f)
        click(g * 0.7f, 1200f)
    }

    private fun thud(g: Float, f: Float, level: Float) {
        tone(Wave.SINE, f * vary() * 1.6f, f, 0.002f, 0.025f, 0.14f, level * g)
        noise(0.002f, 0.012f, 0.05f, 0.25f * g, 1, 900f, 400f, 0.8f)
    }

    private fun click(g: Float, f: Float) {
        noise(0.001f, 0.003f, 0.015f, 0.30f * g, 2, f * vary(), f, 3f)
        tone(Wave.SINE, f * 0.6f, f * 0.4f, 0.001f, 0.004f, 0.02f, 0.10f * g)
    }

    /** Una inhalación y una exhalación (ruido de banda estrecha con envolvente lenta). */
    private fun breath(g: Float) {
        val inhale = noise(0.30f, 0.20f, 0.32f, 0.10f * g, 2, 650f, 900f, 1.1f)
        inhale.send = 0.15f
        val exhale = noise(0.18f, 0.30f, 0.50f, 0.085f * g, 2, 900f, 520f, 1.0f, 0.95f)
        exhale.send = 0.15f
    }

    // ---------------------------------------------------------------- v0.8: la criatura

    /** Respiración húmeda y pesada: aire filtrado + un gorgoteo grave. */
    private fun creatureBreath(g: Float) {
        noise(0.35f, 0.25f, 0.45f, 0.11f * g, 2, 420f * vary(), 620f, 0.9f).send = 0.2f
        tone(Wave.TRI, 58f * vary(), 46f, 0.2f, 0.2f, 0.4f, 0.05f * g).setFilter(1, 220f, 180f, 1.2f)
        noise(0.2f, 0.35f, 0.5f, 0.08f * g, 2, 650f, 380f, 1.2f, 0.9f).send = 0.2f
    }

    /** Paso pesado y húmedo: golpe grave + chapoteo de piel. */
    private fun creatureStep(g: Float) {
        thud(g * 1.1f, 62f, 0.62f)
        noise(0.004f, 0.03f, 0.12f, 0.20f * g, 2, 520f * vary(), 260f, 1.4f, 0.015f)
        if (core.rng.chance(0.5f)) noise(0.01f, 0.02f, 0.06f, 0.10f * g, 2, 1400f, 900f, 2.2f, 0.05f)   // pegajoso
    }

    /** Brazos largos que rozan o arrastran. */
    private fun creatureArm(g: Float) {
        noise(0.05f, 0.12f, 0.22f, 0.10f * g, 2, 1100f * vary(), 520f, 0.8f)
        thud(g * 0.35f, 90f, 0.25f)
    }

    private fun creatureWet(g: Float) {
        noise(0.01f, 0.03f, 0.10f, 0.14f * g, 2, 900f * vary(), 1900f, 2.0f)
        tone(Wave.SINE, 240f * vary(), 520f, 0.004f, 0.02f, 0.05f, 0.05f * g)
    }

    /** Boca secundaria: chasquido, aire o gemido minúsculo (nunca habla). */
    private fun creatureMouth(g: Float) {
        when (core.rng.pick(3)) {
            0 -> click(g * 0.5f, 1400f)
            1 -> noise(0.03f, 0.05f, 0.12f, 0.07f * g, 2, 800f * vary(), 500f, 1.5f)
            else -> tone(Wave.TRI, 210f * vary(), 150f, 0.03f, 0.08f, 0.15f, 0.045f * g).setFilter(1, 700f, 400f, 1.4f)
        }
        creatureWet(g * 0.5f)
    }

    /** Gruñido de la boca principal. */
    private fun creatureGrowl(g: Float) {
        val a = tone(Wave.SAW, 70f * vary(), 52f, 0.06f, 0.35f, 0.40f, 0.20f * g)
        a.setFilter(1, 520f, 260f, 1.8f)
        tone(Wave.SQUARE, 35f, 30f, 0.08f, 0.30f, 0.40f, 0.05f * g).setFilter(1, 140f, 100f, 1f)
        noise(0.05f, 0.25f, 0.4f, 0.10f * g, 2, 700f, 400f, 1.0f)
    }

    /** Alerta: inspiración brusca y un tono triste y roto (no es una sirena). */
    private fun creatureAlert(g: Float) {
        noise(0.04f, 0.08f, 0.18f, 0.20f * g, 2, 500f, 1500f, 1.2f)
        tone(Wave.TRI, 190f, 120f, 0.04f, 0.25f, 0.35f, 0.10f * g, 0.12f).setFilter(1, 900f, 400f, 1.6f)
        creatureWet(g * 0.8f)
    }

    private fun creatureChase(g: Float) {
        creatureGrowl(g * 1.1f)
        noise(0.02f, 0.10f, 0.20f, 0.22f * g, 2, 900f, 2200f, 1.0f, 0.05f)
        tone(Wave.SAW, 140f, 90f, 0.01f, 0.12f, 0.18f, 0.10f * g, 0.08f).setFilter(1, 1100f, 500f, 2f)
    }

    private fun creatureLost(g: Float) {
        tone(Wave.TRI, 160f, 95f, 0.12f, 0.30f, 0.55f, 0.10f * g).setFilter(1, 600f, 260f, 1.4f)
        noise(0.3f, 0.3f, 0.6f, 0.10f * g, 2, 550f, 350f, 1.0f, 0.1f)
    }

    /** Captura: golpe, distorsión y un chillido húmedo que se corta. */
    private fun creatureCapture(g: Float) {
        thud(g * 1.3f, 48f, 0.8f)
        creatureGrowl(g * 1.4f)
        val v = tone(Wave.SAW, 320f, 80f, 0.005f, 0.30f, 0.35f, 0.16f * g, 0.05f)
        v.setFilter(1, 2400f, 300f, 2.4f)
        noise(0.01f, 0.20f, 0.30f, 0.25f * g, 2, 1800f, 400f, 1.6f, 0.04f)
    }

    private fun heartbeat(g: Float) {
        tone(Wave.SINE, 62f, 42f, 0.004f, 0.04f, 0.14f, 0.50f * g)
        tone(Wave.SINE, 56f, 40f, 0.004f, 0.04f, 0.16f, 0.38f * g, 0.20f)
    }

    private fun cloth(g: Float, length: Float) {
        noise(0.02f, length * 0.5f, length * 0.6f, 0.09f * g, 2, 1800f, 2600f, 0.7f)
        noise(0.03f, length * 0.4f, length * 0.5f, 0.05f * g, 1, 600f, 400f, 0.7f, 0.02f)
    }

    private fun plushTap(g: Float) {
        thud(g * 0.6f, 120f, 0.30f)
        cloth(g * 0.9f, 0.14f)
    }

    private fun textTick(g: Float) {
        tone(Wave.TRI, 1100f * vary(), 1100f, 0.001f, 0.004f, 0.025f, 0.04f * g)
    }

    private fun chime(g: Float) {
        val notes = floatArrayOf(784f, 988f, 1175f)
        for (k in 0 until 3) tone(Wave.SINE, notes[k], notes[k], 0.004f, 0.05f, 0.7f, 0.06f * g, k * 0.12f).send = 0.35f
    }
}
