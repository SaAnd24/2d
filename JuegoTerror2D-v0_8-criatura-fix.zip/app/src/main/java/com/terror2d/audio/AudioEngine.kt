package com.terror2d.audio

import com.terror2d.core.WorldMode
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Salida de audio de bajo nivel (PCM 16 bit mono). [AndroidAudioSink] usa AudioTrack; los tests usan [OfflineAudioSink]
 * o llaman directamente a [AudioEngine.renderBlock].
 */
interface AudioSink {
    /** Abre la salida. Devuelve false si no se puede (el juego sigue, sin sonido). */
    fun open(sampleRate: Int, blockFrames: Int): Boolean

    /** Se llama una vez desde el hilo de audio al empezar (prioridad del hilo, etc.). */
    fun onAudioThreadStart() {}

    /** Escribe [frames] muestras. Puede bloquear: se ejecuta SOLO en el hilo de audio. */
    fun write(buffer: ShortArray, frames: Int)

    fun close()
}

/** Sumidero que descarta todo (tests / sin audio). */
class OfflineAudioSink : AudioSink {
    var written = 0L
        private set

    override fun open(sampleRate: Int, blockFrames: Int): Boolean = true
    override fun write(buffer: ShortArray, frames: Int) {
        written += frames
    }

    override fun close() {}
}

/**
 * AudioEngine (v0.7): la arquitectura de audio procedural de TODO MYMom.
 *
 *   GAMEPLAY -> EVENTO -> [AudioPort / AudioDirector] -> cola de comandos -> hilo de audio -> SÍNTESIS
 *
 *  - [VoiceSynth] voces (CHILD, MOTHER, FROG...), [SfxSynth] efectos, [MusicSynth] música por capas,
 *    [AmbienceSynth] ambiente, [AudioEffects] reverb/eco/distorsión/mundo NORMAL-TRAUMA.
 *  - El hilo del juego solo encola comandos (baratos, sin bloquear). Toda la síntesis ocurre en un hilo propio con
 *    bloques de [BLOCK] muestras: el render y la interfaz nunca esperan al audio.
 *  - Sin archivos de audio: todo se genera en tiempo real. Memoria prealocada (reserva de voces + buffers de bloque).
 */
class AudioEngine(
    private val sink: AudioSink,
    val sampleRate: Int = 44100,
    seed: Int = 20260706
) : AudioPort {

    private class Cmd(val type: Int, val a: Int = 0, val b: Int = 0, val c: Int = 0, val d: Int = 0, val f1: Float = 0f, val f2: Float = 0f)

    private val queue = ConcurrentLinkedQueue<Cmd>()
    val core = EngineCore(sampleRate, seed)
    private val voices = VoiceSynth(core)
    private val sfx = SfxSynth(core)
    private val music = MusicSynth(core)
    private val ambience = AmbienceSynth(core)

    private val bus = Array(Bus.COUNT) { FloatArray(BLOCK) }
    private val busGain = floatArrayOf(0.95f, 1.0f, 0.75f, 0.85f)
    private val rvSend = FloatArray(BLOCK)
    private val ecSend = FloatArray(BLOCK)
    private val mix = FloatArray(BLOCK)
    private val pcm = ShortArray(BLOCK)

    @Volatile var masterVolume = 0.8f
    private var duckCur = 1f
    private var duckTarget = 1f
    private var duckRate = 1f

    @Volatile private var running = false
    private var thread: Thread? = null

    // Estado deseado (se reaplica al reanudar tras una pausa de la app)
    @Volatile private var desiredMusic = MusicId.SILENCE
    @Volatile private var desiredAmbience = AmbienceId.SILENT
    @Volatile private var desiredWorld = WorldMode.NORMAL

    val isRunning: Boolean get() = running
    val activeVoices: Int get() = core.pool.activeCount()
    val currentMusic: MusicId get() = music.current
    val currentAmbience: AmbienceId get() = ambience.current

    // ------------------------------------------------------------------ ciclo de vida

    /** Arranca el hilo de audio (onResume). Si la salida no se puede abrir, el juego sigue en silencio. */
    @Synchronized
    fun start() {
        if (running) return
        val ok = try {
            sink.open(sampleRate, BLOCK)
        } catch (t: Throwable) {
            false
        }
        if (!ok) return
        running = true
        queue.offer(Cmd(CMD_MUSIC, desiredMusic.ordinal, f1 = 1f))
        queue.offer(Cmd(CMD_AMBIENCE, desiredAmbience.ordinal, f1 = 1f))
        queue.offer(Cmd(CMD_WORLD, desiredWorld.ordinal))
        val t = Thread({ loop() }, "MYMomAudio")
        t.isDaemon = true
        thread = t
        t.start()
    }

    /** Detiene el hilo y libera la salida (onPause / al salir). Se puede volver a llamar a [start]. */
    @Synchronized
    fun stop() {
        if (!running && thread == null) return
        running = false
        val t = thread
        thread = null
        if (t != null) {
            try {
                t.join(800)
            } catch (e: InterruptedException) {
                // ignorar
            }
        }
        try {
            sink.close()
        } catch (t2: Throwable) {
            // ignorar
        }
        queue.clear()
    }

    /** Libera todo definitivamente. */
    fun release() {
        stop()
        core.pool.stopAll()
    }

    private fun loop() {
        try {
            sink.onAudioThreadStart()
            val f = FloatArray(BLOCK)
            while (running) {
                renderBlock(f, BLOCK)
                for (i in 0 until BLOCK) {
                    var s = (f[i] * 32767f).toInt()
                    if (s > 32767) s = 32767 else if (s < -32768) s = -32768
                    pcm[i] = s.toShort()
                }
                sink.write(pcm, BLOCK)
            }
        } catch (t: Throwable) {
            // el audio jamás debe tumbar el juego
            running = false
        }
    }

    // ------------------------------------------------------------------ AudioPort (hilo del juego)

    @Volatile private var offline = false

    /** Tests: acepta comandos aunque no haya hilo (se consumen con [renderBlock]). */
    fun enableOfflineMode() {
        offline = true
    }

    private fun post(c: Cmd) {
        if (running || offline) queue.offer(c)
    }

    override fun playVoice(voice: VoiceId, emotion: Emotion, intensity: Float, kind: VoiceKind, units: Int, seed: Int) =
        post(Cmd(CMD_VOICE, voice.ordinal, emotion.ordinal, kind.ordinal, units * 65536 + (seed and 0xFFFF), f1 = intensity))

    override fun playSfx(sfx: SfxId, intensity: Float, surface: Surface) =
        post(Cmd(CMD_SFX, sfx.ordinal, surface.ordinal, f1 = intensity))

    override fun playMusic(music: MusicId, fadeSeconds: Float) {
        desiredMusic = music
        post(Cmd(CMD_MUSIC, music.ordinal, f1 = fadeSeconds))
    }

    override fun setAmbience(ambience: AmbienceId, fadeSeconds: Float) {
        desiredAmbience = ambience
        post(Cmd(CMD_AMBIENCE, ambience.ordinal, f1 = fadeSeconds))
    }

    override fun setWorld(mode: WorldMode) {
        desiredWorld = mode
        post(Cmd(CMD_WORLD, mode.ordinal))
    }

    override fun duck(level: Float, seconds: Float) = post(Cmd(CMD_DUCK, f1 = level, f2 = seconds))

    override fun stopAll() {
        desiredMusic = MusicId.SILENCE
        desiredAmbience = AmbienceId.SILENT
        post(Cmd(CMD_STOP))
    }

    // ------------------------------------------------------------------ hilo de audio

    private fun execute(c: Cmd) {
        when (c.type) {
            CMD_VOICE -> voices.speak(
                VoiceId.values()[c.a], Emotion.values()[c.b], c.f1, VoiceKind.values()[c.c], c.d / 65536, c.d and 0xFFFF
            )
            CMD_SFX -> sfx.play(SfxId.values()[c.a], c.f1, Surface.values()[c.b])
            CMD_MUSIC -> music.set(MusicId.values()[c.a], c.f1)
            CMD_AMBIENCE -> ambience.set(AmbienceId.values()[c.a], c.f1)
            CMD_WORLD -> core.effects.target = WorldAudioProfile.of(WorldMode.values()[c.a])
            CMD_DUCK -> {
                duckTarget = c.f1.coerceIn(0f, 1f)
                duckRate = 1f / c.f2.coerceAtLeast(0.05f)
            }
            CMD_STOP -> {
                core.pool.stopAll()
                music.stopAll()
                ambience.stopAll()
            }
        }
    }

    /**
     * Sintetiza [n] (<= [BLOCK]) muestras a [out] en el rango -1..1. Público para poder probar el audio sin
     * dispositivo (render offline determinista). SOLO debe llamarlo el hilo de audio o un test.
     */
    fun renderBlock(out: FloatArray, n: Int) {
        val frames = if (n > BLOCK) BLOCK else n
        var c = queue.poll()
        var guard = 0
        while (c != null && guard < 64) {
            execute(c)
            guard++
            c = queue.poll()
        }
        for (b in 0 until Bus.COUNT) java.util.Arrays.fill(bus[b], 0, frames, 0f)
        java.util.Arrays.fill(rvSend, 0, frames, 0f)
        java.util.Arrays.fill(ecSend, 0, frames, 0f)

        val dt = frames / core.sr
        core.effects.glide(dt)
        val dd = duckTarget - duckCur
        val ds = duckRate * dt
        duckCur = if (dd > ds) duckCur + ds else if (dd < -ds) duckCur - ds else duckTarget

        music.process(frames)
        ambience.process(bus[Bus.AMBIENCE], frames)

        val vs = core.pool.voices
        for (i in vs.indices) {
            val v = vs[i]
            if (v.active) v.render(bus[v.bus], rvSend, ecSend, frames)
        }

        val mg = masterVolume
        val sfxG = busGain[Bus.SFX]
        val voiceG = busGain[Bus.VOICE]
        val musicG = busGain[Bus.MUSIC] * duckCur
        val ambG = busGain[Bus.AMBIENCE] * duckCur
        val bs = bus[Bus.SFX]
        val bv = bus[Bus.VOICE]
        val bm = bus[Bus.MUSIC]
        val ba = bus[Bus.AMBIENCE]
        for (i in 0 until frames) mix[i] = bs[i] * sfxG + bv[i] * voiceG + bm[i] * musicG + ba[i] * ambG
        core.effects.process(mix, rvSend, ecSend, frames)
        for (i in 0 until frames) {
            var x = softClip(mix[i] * mg)
            if (x != x) x = 0f          // NaN: nunca llega al altavoz
            out[i] = x
        }
    }

    companion object {
        /** Muestras por bloque (11,6 ms a 44,1 kHz): latencia baja y carga estable. */
        const val BLOCK = 512

        private const val CMD_VOICE = 1
        private const val CMD_SFX = 2
        private const val CMD_MUSIC = 3
        private const val CMD_AMBIENCE = 4
        private const val CMD_WORLD = 5
        private const val CMD_DUCK = 6
        private const val CMD_STOP = 7
    }
}
