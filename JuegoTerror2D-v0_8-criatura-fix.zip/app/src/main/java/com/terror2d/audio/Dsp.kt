package com.terror2d.audio

import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sin

/**
 * Bloques de síntesis (v0.7). Kotlin puro, sin Android: se pueden probar renderizando a un buffer.
 * Regla de oro: NADA aquí reserva memoria durante el render (todo se prealoca al crear el motor).
 */
const val TWO_PI = 6.2831855f

/** Generador pseudoaleatorio xorshift32: rápido, sin objetos, determinista por semilla. */
class FastRng(seed: Int) {
    private var s: Int = if (seed == 0) 0x1234ABCD else seed

    fun nextInt(): Int {
        var x = s
        x = x xor (x shl 13)
        x = x xor (x ushr 17)
        x = x xor (x shl 5)
        s = x
        return x
    }

    /** 0..1 */
    fun nextFloat(): Float = (nextInt() ushr 8) * (1f / 16777216f)

    /** -1..1 */
    fun noise(): Float = nextFloat() * 2f - 1f

    fun range(a: Float, b: Float): Float = a + (b - a) * nextFloat()

    fun chance(p: Float): Boolean = nextFloat() < p

    fun pick(n: Int): Int = ((nextInt() ushr 1) % n)
}

/** Limitador suave (x/(1+|x|) sería muy blando; esta aproximación de tanh conserva el cuerpo). */
fun softClip(x: Float): Float {
    val a = if (x < -3f) -3f else if (x > 3f) 3f else x
    return a * (27f + a * a) / (27f + 9f * a * a)
}

fun semitones(st: Float): Float = Math.pow(2.0, (st / 12f).toDouble()).toFloat()

/** Filtro de variable de estado (Chamberlin). Estable hasta ~sr/8; la frecuencia se limita. */
class Svf {
    var low = 0f
    var band = 0f
    var high = 0f
    private var f = 0.1f
    private var damp = 1f

    fun set(cutoff: Float, q: Float, sr: Float) {
        val maxC = sr * 0.12f
        val c = if (cutoff < 20f) 20f else if (cutoff > maxC) maxC else cutoff
        f = 2f * sin(Math.PI.toFloat() * c / sr)
        damp = 1f / (if (q < 0.6f) 0.6f else q)
    }

    fun process(x: Float): Float {
        low += f * band
        high = x - low - damp * band
        band += f * high
        return low
    }

    /** Salida paso-banda con ganancia ~1 en el centro. */
    fun bp(): Float = band * damp

    fun reset() {
        low = 0f; band = 0f; high = 0f
    }
}

/** Reverb sencilla (4 peines + 2 pasa-todo), mono. Buffers prealocados. */
class Reverb(sr: Int) {
    private val combLen = intArrayOf(1116, 1188, 1277, 1356).map { (it * sr / 44100).coerceAtLeast(64) }.toIntArray()
    private val combBuf = Array(4) { FloatArray(combLen[it]) }
    private val combPos = IntArray(4)
    private val combLp = FloatArray(4)
    private val apLen = intArrayOf(556, 441).map { (it * sr / 44100).coerceAtLeast(32) }.toIntArray()
    private val apBuf = Array(2) { FloatArray(apLen[it]) }
    private val apPos = IntArray(2)
    var feedback = 0.80f
    var damping = 0.35f

    /** Procesa [n] muestras de [src] y SUMA el resultado húmedo en [dst]. */
    fun process(src: FloatArray, dst: FloatArray, n: Int, level: Float) {
        for (i in 0 until n) {
            val x = src[i] * 0.2f
            var acc = 0f
            for (c in 0 until 4) {
                val b = combBuf[c]
                val p = combPos[c]
                val y = b[p]
                combLp[c] = y * (1f - damping) + combLp[c] * damping
                b[p] = x + combLp[c] * feedback
                combPos[c] = if (p + 1 >= b.size) 0 else p + 1
                acc += y
            }
            for (a in 0 until 2) {
                val b = apBuf[a]
                val p = apPos[a]
                val z = b[p]
                val y = -acc + z
                b[p] = acc + z * 0.5f
                apPos[a] = if (p + 1 >= b.size) 0 else p + 1
                acc = y
            }
            dst[i] += acc * level
        }
    }
}

/** Eco con realimentación (para el timbre "pequeño y extraño" de la rana y para TRAUMA). */
class Echo(sr: Int) {
    private val buf = FloatArray(sr)        // 1 s máx.
    private var pos = 0
    var delaySamples = (sr * 0.19f).toInt()
    var feedback = 0.38f

    fun process(src: FloatArray, dst: FloatArray, n: Int, level: Float) {
        val len = buf.size
        for (i in 0 until n) {
            var rp = pos - delaySamples
            if (rp < 0) rp += len
            val y = buf[rp]
            buf[pos] = src[i] + y * feedback
            pos = if (pos + 1 >= len) 0 else pos + 1
            dst[i] += y * level
        }
    }
}

object Wave {
    const val SINE = 0
    const val TRI = 1
    const val SAW = 2
    const val SQUARE = 3
    const val NOISE = 4
}

object Bus {
    const val SFX = 0
    const val VOICE = 1
    const val MUSIC = 2
    const val AMBIENCE = 3
    const val COUNT = 4
}

/**
 * Una voz de síntesis polivalente: oscilador (+FM, +vibrato, +ruido) -> filtro o formantes -> bitcrusher -> envolvente
 * ADSR-R. La usan los cuatro sintetizadores (voz, sfx, música, ambiente). Los tiempos van en MUESTRAS.
 */
class SynthVoice(private val sr: Float) {
    var active = false
    var bus = Bus.SFX
    var delay = 0
    var age = 0

    var wave = Wave.SINE
    var freq = 440f
    var freqEnd = 440f
    var glide = 0                 // muestras que tarda en ir de freq a freqEnd (0 = sin glissando)
    var level = 1f
    var pitchMul = 1f

    // envolvente: ataque, decay hasta [sustain], mantiene hasta [holdEnd] y se libera en [release]
    var attack = 0
    var decay = 0
    var sustain = 1f
    var holdEnd = 0
    var release = 0
    var curve = 1                 // 1 lineal, 2 cuadrática (percusiva)

    var noiseMix = 0f
    var vibRate = 0f
    var vibDepth = 0f
    var fmRatio = 0f
    var fmDepth = 0f
    var crush = 0

    var filter = 0                // 0 ninguno, 1 paso-bajo, 2 paso-banda, 3 paso-alto
    var cutoff = 1000f
    var cutoffEnd = 1000f
    var q = 1f

    var formant = false
    var f1 = 800f
    var f2 = 1200f
    var q1 = 5f
    var q2 = 7f
    var f2Gain = 0.7f
    var formGain = 3f

    var send = 0f
    var echo = 0f

    private var phase = 0f
    private var fmPhase = 0f
    private var vibPhase = 0f
    private var ctl = 0
    private val svf = Svf()
    private val svfA = Svf()
    private val svfB = Svf()
    private val rng = FastRng(0x51ED)

    fun reset() {
        delay = 0; age = 0
        wave = Wave.SINE; freq = 440f; freqEnd = 440f; glide = 0; level = 1f; pitchMul = 1f
        attack = 0; decay = 0; sustain = 1f; holdEnd = 0; release = 0; curve = 1
        noiseMix = 0f; vibRate = 0f; vibDepth = 0f; fmRatio = 0f; fmDepth = 0f; crush = 0
        filter = 0; cutoff = 1000f; cutoffEnd = 1000f; q = 1f
        formant = false; f1 = 800f; f2 = 1200f; q1 = 5f; q2 = 7f; f2Gain = 0.7f; formGain = 3f
        send = 0f; echo = 0f
        phase = 0f; fmPhase = 0f; vibPhase = 0f; ctl = 0
        svf.reset(); svfA.reset(); svfB.reset()
    }

    fun seed(s: Int) {
        rng.nextInt()
        phase = (s and 1023) / 1023f * 0.25f
    }

    /** Envolvente en segundos (conveniencia). */
    fun env(attackS: Float, decayS: Float, sustainLevel: Float, holdS: Float, releaseS: Float) {
        attack = (attackS * sr).toInt()
        decay = (decayS * sr).toInt()
        sustain = sustainLevel
        holdEnd = (holdS * sr).toInt()
        release = (releaseS * sr).toInt().coerceAtLeast(1)
    }

    fun setFilter(mode: Int, c0: Float, c1: Float, qq: Float) {
        filter = mode; cutoff = c0; cutoffEnd = c1; q = qq
    }

    fun setFormants(a: Float, b: Float, qa: Float, qb: Float) {
        formant = true; f1 = a; f2 = b; q1 = qa; q2 = qb
        svfA.set(a, qa, sr)
        svfB.set(b, qb, sr)
    }

    private fun updateFilter() {
        if (filter == 0) return
        val span = if (holdEnd > 0) holdEnd else 1
        var t = age.toFloat() / span
        if (t > 1f) t = 1f
        svf.set(cutoff + (cutoffEnd - cutoff) * t, q, sr)
    }

    /** Suma [n] muestras a [buf] (y a los envíos de reverb/eco). */
    fun render(buf: FloatArray, sendBuf: FloatArray, echoBuf: FloatArray, n: Int) {
        var i = 0
        val total = holdEnd + release
        while (i < n) {
            if (delay > 0) {
                val d = if (delay < n - i) delay else n - i
                delay -= d
                i += d
                continue
            }
            if (age >= total) {
                active = false
                return
            }
            if ((ctl and 15) == 0) updateFilter()
            ctl++

            var env: Float
            if (age < attack) {
                env = age.toFloat() / attack
            } else if (age < attack + decay) {
                env = 1f - (1f - sustain) * ((age - attack).toFloat() / decay)
            } else {
                env = sustain
            }
            if (age >= holdEnd) env *= 1f - (age - holdEnd).toFloat() / release
            if (curve == 2) env *= env

            var fr = freq
            if (glide > 0) {
                var t = age.toFloat() / glide
                if (t > 1f) t = 1f
                fr = freq + (freqEnd - freq) * t
            }
            fr *= pitchMul
            if (vibDepth > 0f) {
                vibPhase += vibRate / sr
                if (vibPhase >= 1f) vibPhase -= 1f
                fr *= 1f + vibDepth * sin(TWO_PI * vibPhase)
            }
            var ph = phase
            if (fmDepth > 0f) {
                fmPhase += fr * fmRatio / sr
                if (fmPhase >= 1f) fmPhase -= 1f
                ph += fmDepth * sin(TWO_PI * fmPhase)
                ph -= floor(ph)
            }
            var s: Float = when (wave) {
                Wave.SINE -> sin(TWO_PI * ph)
                Wave.TRI -> 4f * abs(ph - 0.5f) - 1f
                Wave.SAW -> 2f * ph - 1f
                Wave.SQUARE -> if (ph < 0.5f) 1f else -1f
                else -> rng.noise()
            }
            phase += fr / sr
            if (phase >= 1f) phase -= 1f
            if (noiseMix > 0f) s = s * (1f - noiseMix) + rng.noise() * noiseMix

            if (formant) {
                svfA.process(s)
                svfB.process(s)
                s = (svfA.bp() + f2Gain * svfB.bp()) * formGain
            } else if (filter != 0) {
                val lo = svf.process(s)
                s = when (filter) {
                    1 -> lo
                    2 -> svf.bp()
                    else -> svf.high
                }
            }
            if (crush > 0) s = Math.round(s * crush) / crush.toFloat()

            val o = s * env * level
            buf[i] += o
            if (send > 0f) sendBuf[i] += o * send
            if (echo > 0f) echoBuf[i] += o * echo
            age++
            i++
        }
    }
}

/** Reserva fija de voces. Si no hay libres, roba la más antigua (nunca reserva memoria nueva). */
class VoicePool(sr: Float, size: Int = 56) {
    val voices = Array(size) { SynthVoice(sr) }

    fun obtain(bus: Int): SynthVoice {
        var oldest = voices[0]
        for (i in voices.indices) {
            val v = voices[i]
            if (!v.active) return claim(v, bus)
            if (v.age > oldest.age) oldest = v
        }
        return claim(oldest, bus)
    }

    private fun claim(v: SynthVoice, bus: Int): SynthVoice {
        v.reset()
        v.bus = bus
        v.active = true
        return v
    }

    fun activeCount(): Int {
        var c = 0
        for (i in voices.indices) if (voices[i].active) c++
        return c
    }

    fun stopAll() {
        for (i in voices.indices) voices[i].active = false
    }

    fun stopBus(bus: Int) {
        for (i in voices.indices) if (voices[i].bus == bus) voices[i].active = false
    }
}
