package com.terror2d.audio

/** Capas de música: cada pieza ([MusicId]) es una mezcla de niveles de estas capas. */
enum class MusicLayer { PAD, CHILD, FROG, TENSION }

/**
 * Música procedural: un secuenciador de pasos (tempo, notas, escala) que dispara notas sintetizadas por capas.
 * No hay pistas pregrabadas. Cambiar de pieza = cambiar el objetivo de nivel de cada capa (fundidos suaves), de modo
 * que la música puede transicionar dinámicamente y llegar al silencio total (silencio dinámico).
 *
 * Escala base: re menor (D F G A C), con notas "de caja de música" para el niño y una capa ligeramente desafinada
 * (un cuarto de tono) para el peluche: sutil, no terrorífica.
 */
class MusicSynth(private val core: EngineCore) {

    private val level = FloatArray(MusicLayer.values().size)
    private val target = FloatArray(MusicLayer.values().size)
    private var fadeRate = 0.5f         // niveles por segundo
    private var stepClock = 0           // muestras hasta el próximo paso (relativas al inicio del bloque)
    private var step = 0
    private var bpm = 56f
    var current: MusicId = MusicId.SILENCE
        private set

    fun layerLevel(layer: MusicLayer): Float = level[layer.ordinal]

    fun set(id: MusicId, fadeSeconds: Float) {
        current = id
        fadeRate = 1f / fadeSeconds.coerceAtLeast(0.05f)
        for (i in target.indices) target[i] = 0f
        when (id) {
            MusicId.SILENCE -> {}
            MusicId.HOME -> { target[MusicLayer.PAD.ordinal] = 0.80f; bpm = 54f }
            MusicId.CHILD_THEME -> { target[MusicLayer.PAD.ordinal] = 0.35f; target[MusicLayer.CHILD.ordinal] = 0.85f; bpm = 66f }
            MusicId.FROG_SCENE -> { target[MusicLayer.PAD.ordinal] = 0.20f; target[MusicLayer.FROG.ordinal] = 0.90f; bpm = 52f }
            MusicId.TENSION -> { target[MusicLayer.PAD.ordinal] = 0.15f; target[MusicLayer.TENSION.ordinal] = 0.95f; bpm = 60f }
        }
    }

    /** Ajuste manual de una capa (para que una escena añada o quite capas sin cambiar de pieza). */
    fun setLayer(layer: MusicLayer, value: Float) {
        target[layer.ordinal] = value.coerceIn(0f, 1f)
    }

    fun stopAll() {
        for (i in target.indices) { target[i] = 0f; level[i] = 0f }
        current = MusicId.SILENCE
    }

    /** Avanza los niveles y dispara las notas que caen dentro de este bloque de [n] muestras. */
    fun process(n: Int) {
        val dt = n / core.sr
        for (i in level.indices) {
            val d = target[i] - level[i]
            val stepL = fadeRate * dt
            level[i] = if (d > stepL) level[i] + stepL else if (d < -stepL) level[i] - stepL else target[i]
        }
        val stepLen = (core.sr * 60f / bpm / 2f).toInt().coerceAtLeast(2000)
        while (stepClock < n) {
            trigger(step, stepClock)
            step++
            stepClock += stepLen
        }
        stepClock -= n
    }

    private fun note(wave: Int, freq: Float, att: Float, hold: Float, rel: Float, level: Float, offset: Int, send: Float = 0.30f): SynthVoice {
        val v = core.pool.obtain(Bus.MUSIC)
        v.wave = wave
        v.freq = freq
        v.freqEnd = freq
        v.env(att, 0f, 1f, hold, rel)
        v.level = level
        v.delay = offset
        v.pitchMul = core.pitchMul
        v.send = send
        return v
    }

    private fun trigger(s: Int, offset: Int) {
        val r = core.rng
        val pad = level[MusicLayer.PAD.ordinal]
        val child = level[MusicLayer.CHILD.ordinal]
        val frog = level[MusicLayer.FROG.ordinal]
        val tens = level[MusicLayer.TENSION.ordinal]

        if (pad > 0.02f) {
            if (s % 32 == 0) {                          // acorde-colchón largo: re - la - fa
                for (k in 0 until DRONE.size) {
                    val v = note(Wave.SAW, DRONE[k], 3.0f, 12.5f, 3.5f, 0.045f * pad, offset, 0.45f)
                    v.setFilter(1, 420f, 700f, 0.9f)
                    v.vibRate = 0.25f; v.vibDepth = 0.004f
                }
            }
            if (r.chance(0.11f * (0.4f + pad))) {       // campanitas sueltas
                val f = BELLS[r.pick(BELLS.size)]
                note(Wave.SINE, f, 0.004f, 0.04f, 1.5f, 0.060f * pad, offset + r.pick(900), 0.5f).curve = 2
                note(Wave.SINE, f * 2.76f, 0.002f, 0.01f, 0.5f, 0.016f * pad, offset + r.pick(900), 0.5f).curve = 2
            }
        }

        if (child > 0.02f && s % 2 == 0) {              // tema del niño: caja de música, frase de 8 notas
            val idx = (s / 2) % MELODY.size
            val deg = MELODY[idx]
            if (deg != REST) {
                val f = 293.66f * semitones(deg.toFloat())     // re4 = 293.66 Hz
                val human = r.pick(700)
                note(Wave.TRI, f, 0.003f, 0.05f, 0.9f, 0.075f * child, offset + human, 0.40f).curve = 2
                note(Wave.SINE, f * 2f, 0.002f, 0.02f, 0.5f, 0.022f * child, offset + human, 0.40f).curve = 2
            }
        }

        if (frog > 0.02f) {                             // capa del peluche: blips desafinados + un "hm" hueco
            if (s % 2 == 0 && r.chance(0.20f)) {
                val f = BLEEPS[r.pick(BLEEPS.size)] * QUARTER_TONE
                val v = note(Wave.TRI, f, 0.002f, 0.03f, 0.30f, 0.045f * frog, offset + r.pick(600), 0.4f)
                v.curve = 2
                v.echo = 0.4f
            }
            if (s % 48 == 0) {
                val v = note(Wave.SINE, 196f, 0.8f, 3.0f, 2.2f, 0.05f * frog, offset, 0.5f)
                v.fmRatio = 2.01f; v.fmDepth = 0.25f
                v.vibRate = 4.5f; v.vibDepth = 0.01f
            }
        }

        if (tens > 0.02f) {                             // tensión: zumbido grave con batido + latido lejano
            if (s % 16 == 0) {
                val a = note(Wave.SAW, 73.4f, 2.0f, 6.0f, 2.5f, 0.05f * tens, offset, 0.35f)
                a.setFilter(1, 260f, 480f, 1.2f)
                val b = note(Wave.SINE, 103.8f, 2.0f, 6.0f, 2.5f, 0.05f * tens, offset, 0.35f)
                val c = note(Wave.SINE, 105.4f, 2.0f, 6.0f, 2.5f, 0.035f * tens, offset, 0.35f)
                c.curve = 1
                b.curve = 1
            }
            if (s % 4 == 0) {
                val v = note(Wave.SINE, 55f, 0.004f, 0.04f, 0.16f, 0.07f * tens, offset, 0.2f)
                v.curve = 2
                v.freqEnd = 40f
                v.glide = core.samples(0.2f)
            }
        }
    }

    companion object {
        private const val REST = -99
        private const val QUARTER_TONE = 1.0293f      // 2^(1/24)
        private val DRONE = floatArrayOf(73.42f, 110.0f, 174.61f, 293.66f)      // D2 A2 F3 D4
        private val BELLS = floatArrayOf(587.33f, 659.25f, 698.46f, 880.0f, 1046.5f)   // D5 E5 F5 A5 C6
        private val BLEEPS = floatArrayOf(880f, 1046f, 1175f, 1397f)
        /** Frase del niño en semitonos sobre re4 (8 pasos de corchea x 2 = 2 compases suaves). */
        private val MELODY = intArrayOf(7, REST, 5, REST, 3, REST, 5, REST, 7, REST, 10, REST, 7, 5, 3, REST)
    }
}
