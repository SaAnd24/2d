package com.terror2d.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.Process

/**
 * Salida de audio de Android: AudioTrack en modo STREAM (PCM 16 bit mono). Se escribe desde el hilo de audio con
 * escritura bloqueante, de modo que el ritmo lo marca el propio dispositivo y el hilo del juego nunca espera.
 */
class AndroidAudioSink : AudioSink {

    private var track: AudioTrack? = null

    @Suppress("DEPRECATION")
    override fun open(sampleRate: Int, blockFrames: Int): Boolean {
        val min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return false
        val bytes = maxOf(min * 2, blockFrames * 2 * 4)
        val t: AudioTrack
        if (Build.VERSION.SDK_INT >= 23) {
            val builder = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(bytes)
                .setTransferMode(AudioTrack.MODE_STREAM)
            if (Build.VERSION.SDK_INT >= 26) builder.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            t = builder.build()
        } else {
            t = AudioTrack(
                AudioManager.STREAM_MUSIC, sampleRate, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, bytes, AudioTrack.MODE_STREAM
            )
        }
        if (t.state != AudioTrack.STATE_INITIALIZED) {
            t.release()
            return false
        }
        track = t
        t.play()
        return true
    }

    override fun onAudioThreadStart() {
        try {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
        } catch (e: Throwable) {
            // sin permiso: prioridad normal
        }
    }

    override fun write(buffer: ShortArray, frames: Int) {
        val t = track ?: return
        var off = 0
        while (off < frames) {
            val w = t.write(buffer, off, frames - off)
            if (w <= 0) return
            off += w
        }
    }

    override fun close() {
        val t = track ?: return
        track = null
        try {
            t.pause()
            t.flush()
        } catch (e: Throwable) {
            // ignorar
        }
        t.release()
    }
}
