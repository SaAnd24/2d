package com.terror2d.audio

import com.terror2d.events.EventListener
import com.terror2d.events.EventType
import com.terror2d.events.GameEvent
import com.terror2d.inventory.ItemRegistry

/**
 * El ÚNICO sitio que conoce qué suena con cada evento de juego:
 *
 *   GAMEPLAY -> EVENTO -> AudioDirector -> AudioPort (AudioEngine) -> SÍNTESIS
 *
 * Para cambiar cómo suena el juego se edita este archivo o los sintetizadores; la narrativa y el GameLogic no se
 * tocan. Equivalencias con los nombres conceptuales de la especificación: OBJECT_PICKED_UP = ON_ITEM_PICKED,
 * OBJECT_DROPPED = ON_ITEM_GIVEN / ON_ITEM_PLACED.
 *
 * @param surface superficie bajo los pies del niño ahora mismo (la escena la deduce del suelo del segmento).
 */
class AudioDirector(
    private val audio: AudioPort,
    private val surface: () -> Surface
) : EventListener {

    private var started = false
    private var lineCounter = 0

    override fun onEvent(event: GameEvent) {
        when (event.type) {
            EventType.FOOTSTEP -> audio.playSfx(SfxId.FOOTSTEP, 1f, surface())

            EventType.ON_ENTER_ROOM -> if (!started) {
                started = true
                audio.setAmbience(AmbienceId.HOUSE, 4f)
                audio.playMusic(MusicId.HOME, 5f)
            }

            EventType.ON_ITEM_PICKED -> when (event.sourceId) {
                ItemRegistry.FROG_PLUSH -> {}       // lo cubre COMPANION_PICKED_UP
                ItemRegistry.WATER_GLASS -> {
                    audio.playSfx(SfxId.PICKUP, 0.7f)
                    audio.playSfx(SfxId.GLASS, 0.6f)
                }
                else -> {
                    audio.playSfx(SfxId.PICKUP, 0.9f)
                    audio.playSfx(SfxId.MEDICINE, 0.7f)
                }
            }

            EventType.COMPANION_PICKED_UP -> {
                audio.playSfx(SfxId.CLOTH, 0.9f)
                audio.playSfx(SfxId.PLUSH_TAP, 0.8f)
            }

            EventType.ON_ITEM_GIVEN ->
                if (event.sourceId == ItemRegistry.WATER_GLASS) audio.playSfx(SfxId.GLASS, 0.9f)
                else audio.playSfx(SfxId.DROP, 0.8f)

            EventType.ON_ITEM_PLACED -> audio.playSfx(SfxId.DROP, 0.9f)
            EventType.WATER_DELIVERED -> audio.playSfx(SfxId.WATER, 0.6f)
            EventType.ON_DOOR_OPEN -> audio.playSfx(SfxId.DOOR_OPEN, 0.9f)
            EventType.ON_DOCUMENT_READ -> audio.playSfx(SfxId.DOCUMENT_OPEN, 0.9f)
            EventType.ON_INTERACT -> audio.playSfx(SfxId.INTERACT, 0.5f)
            EventType.ON_HIDE, EventType.ON_EXIT_HIDE -> audio.playSfx(SfxId.CLOTH, 0.8f)
            EventType.ON_PUZZLE_STARTED -> audio.playSfx(SfxId.PAPER, 0.8f)
            EventType.MEDICINE_PUZZLE_COMPLETED -> audio.playSfx(SfxId.CHIME, 0.9f)

            EventType.DIALOGUE_LINE -> dialogueVoice(event)

            // ---- v0.8: la criatura. value de CREATURE_STEP = bit0 persecución | (cercanía 0..100) << 1
            EventType.CREATURE_STEP -> {
                val chasing = (event.value and 1) == 1
                val prox = ((event.value shr 1) / 100f).coerceIn(0f, 1f)
                if (prox > 0.03f) audio.playSfx(SfxId.CREATURE_STEP, (if (chasing) 1.0f else 0.7f) * prox, surface())
            }
            EventType.CREATURE_STATE -> when (event.sourceId) {
                "INVESTIGATE" -> { audio.playSfx(SfxId.CREATURE_ALERT, 0.55f); audio.playSfx(SfxId.CREATURE_WET, 0.5f) }
                "CHASE" -> {
                    audio.playSfx(SfxId.CREATURE_CHASE, 1f)
                    audio.playMusic(MusicId.TENSION, 0.6f)
                }
                "LOST_TARGET" -> audio.playSfx(SfxId.CREATURE_LOST, 0.8f)
                "RETURN_TO_PATROL" -> audio.playMusic(MusicId.HOME, 8f)   // la tensión baja gradualmente
                else -> {}
            }
            EventType.CREATURE_CAPTURE -> audio.playSfx(SfxId.CREATURE_CAPTURE, 1f)

            EventType.FROG_TALK -> {
                audio.playSfx(SfxId.CLOTH, 0.6f)
                audio.playSfx(SfxId.PLUSH_TAP, 0.6f)
            }

            EventType.CONVERSATION_STARTED -> {
                audio.duck(0.30f, 1.0f)
                audio.setAmbience(AmbienceId.CONVERSATION, 1.5f)
                audio.playMusic(MusicId.FROG_SCENE, 2.5f)
            }

            EventType.CONVERSATION_ENDED -> {
                audio.duck(1f, 2.5f)
                audio.setAmbience(AmbienceId.HOUSE, 3f)
                audio.playMusic(MusicId.HOME, 4f)
            }

            else -> {}
        }
    }

    /** Voz del niño o de mamá al empezar cada línea de texto: balbuceo cuya longitud sigue a la del texto. */
    private fun dialogueVoice(e: GameEvent) {
        val units = (e.value / 6).coerceIn(2, 9)
        lineCounter++
        if (e.sourceId == KID) {
            audio.playVoice(VoiceId.CHILD, Emotion.SOFT, 0.55f, VoiceKind.BABBLE, units, lineCounter)
        } else if (e.sourceId.startsWith("MAM")) {
            audio.playVoice(VoiceId.MOTHER, Emotion.WARM, 0.55f, VoiceKind.BABBLE, units, lineCounter)
        }
    }

    companion object {
        const val KID = "KID"
    }
}
