package com.terror2d.audio

import kotlin.math.sin

/** Canales del ambiente. Cada uno tiene un nivel propio que puede aparecer y desaparecer dinámicamente. */
enum class AmbienceChannel { WIND, HUM, CLOCK, PIPES, ELECTRIC, CREAK, BREATH }

/**
 * Ambiente procedural. WIND y HUM son continuos (ruido filtrado y zumbido de red); CLOCK, PIPES, ELECTRIC, CREAK y
 * BREATH son eventos que aparecen con una frecuencia aleatoria proporcional a su nivel.
 * Objetivo: la casa nunca queda artificialmente en silencio (HUM mantiene un murmullo mínimo incluso en SILENT).
 */
class AmbienceSynth(private val core: EngineCore) {

    private val n = AmbienceChannel.values().size
    private val level = FloatArray(n)
    private val target = FloatArray(n)
    private var fadeRate = 0.5f
    private val countdown = IntArray(n)
    var current: AmbienceId = AmbienceId.SILENT
        private set

    private val windFilter = Svf()
    private val whistle = Svf()
    private var windPhase = 0f
    private var humPhase = 0f
    private var tickParity = 0
    private var ctl = 0

    init {
        set(AmbienceId.SILENT, 0.05f)
        for (i in level.indices) level[i] = target[i]
    }

    fun channelLevel(c: AmbienceChannel): Float = level[c.ordinal]

    fun set(id: AmbienceId, fadeSeconds: Float) {
        current = id
        fadeRate = 1f / fadeSeconds.coerceAtLeast(0.05f)
        for (i in target.indices) target[i] = 0f
        when (id) {
            AmbienceId.SILENT -> { target[AmbienceChannel.HUM.ordinal] = 0.12f }
            AmbienceId.HOUSE -> {
                target[AmbienceChannel.WIND.ordinal] = 0.45f
                target[AmbienceChannel.HUM.ordinal] = 0.55f
                target[AmbienceChannel.CLOCK.ordinal] = 0.60f
                target[AmbienceChannel.PIPES.ordinal] = 0.50f
                target[AmbienceChannel.ELECTRIC.ordinal] = 0.30f
                target[AmbienceChannel.CREAK.ordinal] = 0.50f
            }
            AmbienceId.CONVERSATION -> {
                target[AmbienceChannel.WIND.ordinal] = 0.10f
                target[AmbienceChannel.HUM.ordinal] = 0.22f
                target[AmbienceChannel.CLOCK.ordinal] = 0.20f
                target[AmbienceChannel.BREATH.ordinal] = 0.55f
            }
        }
    }

    fun setChannel(c: AmbienceChannel, value: Float) {
        target[c.ordinal] = value.coerceIn(0f, 1f)
    }

    fun stopAll() {
        set(AmbienceId.SILENT, 0.05f)
    }

    /** Renderiza la parte continua en [buf] (bus AMBIENCE) y programa los eventos de este bloque. */
    fun process(buf: FloatArray, count: Int) {
        val dt = count / core.sr
        for (i in level.indices) {
            val d = target[i] - level[i]
            val s = fadeRate * dt
            level[i] = if (d > s) level[i] + s else if (d < -s) level[i] - s else target[i]
        }
        val r = core.rng
        val wind = level[AmbienceChannel.WIND.ordinal]
        val hum = level[AmbienceChannel.HUM.ordinal]
        val sr = core.sr
        for (i in 0 until count) {
            var o = 0f
            if (wind > 0.005f) {
                windPhase += 1f / sr
                if ((ctl and 31) == 0) {
                    val lfo = 0.5f + 0.5f * sin(TWO_PI * 0.07f * windPhase)
                    val lfo2 = 0.5f + 0.5f * sin(TWO_PI * 0.19f * windPhase + 1.3f)
                    windFilter.set(260f + 520f * lfo, 0.9f, sr)
                    whistle.set(780f + 260f * lfo2, 9f, sr)
                    windGain = 0.35f + 0.65f * lfo2
                }
                val nz = r.noise()
                o += windFilter.process(nz) * 0.42f * wind * windGain
                whistle.process(nz)
                o += whistle.bp() * 0.05f * wind * windGain * windGain
            }
            ctl++
            if (hum > 0.005f) {
                humPhase += 50f / sr
                if (humPhase >= 1f) humPhase -= 1f
                val h = sin(TWO_PI * humPhase)
                o += (h * 0.024f + sin(TWO_PI * humPhase * 2f) * 0.012f + sin(TWO_PI * humPhase * 3f) * 0.004f) * hum
            }
            buf[i] += o
        }
        scheduleEvents(count)
    }

    private var windGain = 1f

    private fun scheduleEvents(count: Int) {
        val r = core.rng
        // reloj: tic-tac exacto cada segundo (alterna dos timbres)
        val clock = level[AmbienceChannel.CLOCK.ordinal]
        countdown[AmbienceChannel.CLOCK.ordinal] -= count
        while (countdown[AmbienceChannel.CLOCK.ordinal] <= 0) {
            val at = countdown[AmbienceChannel.CLOCK.ordinal] + count
            if (clock > 0.03f) tick(at.coerceAtLeast(0), clock)
            countdown[AmbienceChannel.CLOCK.ordinal] += core.sampleRate
        }
        event(AmbienceChannel.PIPES, count, 14f, 34f) { off, lv -> pipes(off, lv) }
        event(AmbienceChannel.ELECTRIC, count, 7f, 22f) { off, lv -> electric(off, lv) }
        event(AmbienceChannel.CREAK, count, 8f, 26f) { off, lv -> creak(off, lv) }
        // respiración cercana: ciclo de ~4.2 s mientras su nivel esté presente
        val b = AmbienceChannel.BREATH.ordinal
        countdown[b] -= count
        if (countdown[b] <= 0) {
            val at = (countdown[b] + count).coerceAtLeast(0)
            if (level[b] > 0.05f) breathing(at, level[b])
            countdown[b] += core.samples(r.range(3.8f, 4.8f))
        }
    }

    private inline fun event(c: AmbienceChannel, count: Int, minS: Float, maxS: Float, fire: (Int, Float) -> Unit) {
        val i = c.ordinal
        countdown[i] -= count
        if (countdown[i] <= 0) {
            val at = (countdown[i] + count).coerceAtLeast(0)
            val lv = level[i]
            if (lv > 0.05f) fire(at, lv)
            // más nivel = más frecuente
            countdown[i] += core.samples(core.rng.range(minS, maxS) / (0.4f + lv))
        }
    }

    private fun voice(wave: Int, f0: Float, f1: Float, att: Float, hold: Float, rel: Float, level: Float, offset: Int): SynthVoice {
        val v = core.pool.obtain(Bus.AMBIENCE)
        v.wave = wave
        v.freq = f0
        v.freqEnd = f1
        v.glide = core.samples(hold + rel)
        v.env(att, 0f, 1f, hold, rel)
        v.level = level
        v.delay = offset
        v.pitchMul = core.pitchMul
        v.send = 0.35f
        return v
    }

    private fun tick(offset: Int, lv: Float) {
        tickParity = tickParity xor 1
        val f = if (tickParity == 0) 1650f else 1380f
        val v = voice(Wave.SINE, f, f * 0.8f, 0.0005f, 0.003f, 0.025f, 0.060f * lv, offset)
        v.curve = 2
        val w = voice(Wave.NOISE, 0f, 0f, 0.0005f, 0.002f, 0.012f, 0.050f * lv, offset)
        w.setFilter(2, 2400f, 2000f, 3f)
        w.curve = 2
    }

    private fun pipes(offset: Int, lv: Float) {
        // golpe metálico sordo + resonancia grave que se apaga
        val k = voice(Wave.SINE, 140f, 90f, 0.002f, 0.02f, 0.45f, 0.10f * lv, offset)
        k.curve = 2
        val r = voice(Wave.TRI, 210f, 200f, 0.02f, 0.25f, 0.9f, 0.035f * lv, offset + core.samples(0.03f))
        r.setFilter(2, 420f, 360f, 6f)
    }

    private fun electric(offset: Int, lv: Float) {
        // zumbido eléctrico breve, con un pequeño parpadeo de amplitud
        val v = voice(Wave.SAW, 100f, 100f, 0.01f, 0.25f + core.rng.range(0f, 0.4f), 0.12f, 0.030f * lv, offset)
        v.setFilter(2, 2200f, 1500f, 4f)
        v.vibRate = 50f; v.vibDepth = 0.02f
    }

    private fun creak(offset: Int, lv: Float) {
        val r = core.rng
        val f = r.range(150f, 250f)
        val v = voice(Wave.SAW, f, f * r.range(0.75f, 1.35f), 0.04f, r.range(0.18f, 0.4f), 0.15f, 0.045f * lv, offset)
        v.setFilter(1, 650f, 950f, 3f)
        v.vibRate = r.range(16f, 28f); v.vibDepth = 0.05f
    }

    private fun breathing(offset: Int, lv: Float) {
        val inh = voice(Wave.NOISE, 0f, 0f, 0.35f, 0.25f, 0.4f, 0.075f * lv, offset)
        inh.setFilter(2, 650f, 950f, 1.1f)
        val exh = voice(Wave.NOISE, 0f, 0f, 0.2f, 0.35f, 0.6f, 0.065f * lv, offset + core.samples(1.1f))
        exh.setFilter(2, 900f, 520f, 1.0f)
    }
}
