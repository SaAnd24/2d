package com.terror2d.audio

import com.terror2d.core.WorldMode

/**
 * Parámetros sonoros de un MUNDO. NORMAL y TRAUMA comparten exactamente los mismos eventos de audio; solo cambian
 * estos números (tono, reverberación, eco, distorsión, brillo y resonancia). 0.7 solo usa NORMAL; TRAUMA está
 * definido y probado, listo para cuando exista ese mundo.
 */
class WorldAudioProfile(
    val pitchMul: Float,
    val reverbReturn: Float,
    val echoReturn: Float,
    val drive: Float,
    val lowpassHz: Float,
    val resonanceMix: Float,
    val resonanceHz: Float
) {
    companion object {
        val NORMAL = WorldAudioProfile(1.00f, 0.55f, 0.30f, 0.00f, 9000f, 0.00f, 220f)
        val TRAUMA = WorldAudioProfile(0.84f, 1.60f, 0.80f, 1.10f, 3600f, 0.22f, 190f)

        fun of(mode: WorldMode): WorldAudioProfile = if (mode == WorldMode.TRAUMA) TRAUMA else NORMAL
    }
}

/**
 * Cadena de efectos del mezclador: reverb y eco por envío, resonancia, distorsión suave y paso-bajo. Los parámetros se
 * acercan a los del mundo activo poco a poco (transición sin saltos).
 */
class AudioEffects(private val sr: Int) {
    private val reverb = Reverb(sr)
    private val echo = Echo(sr)
    private val resSvf = Svf()
    private var lp = 0f

    var target: WorldAudioProfile = WorldAudioProfile.NORMAL

    // valores actuales (suavizados)
    var pitchMul = 1f
        private set
    private var rv = WorldAudioProfile.NORMAL.reverbReturn
    private var ec = WorldAudioProfile.NORMAL.echoReturn
    private var drive = 0f
    private var lpHz = WorldAudioProfile.NORMAL.lowpassHz
    private var resMix = 0f
    private var resHz = 220f

    /** Mueve los parámetros hacia el perfil objetivo. [blockSeconds] = duración del bloque. */
    fun glide(blockSeconds: Float) {
        val k = (blockSeconds / 1.2f).coerceIn(0f, 1f)
        val t = target
        pitchMul += (t.pitchMul - pitchMul) * k
        rv += (t.reverbReturn - rv) * k
        ec += (t.echoReturn - ec) * k
        drive += (t.drive - drive) * k
        lpHz += (t.lowpassHz - lpHz) * k
        resMix += (t.resonanceMix - resMix) * k
        resHz += (t.resonanceHz - resHz) * k
    }

    /** Aplica los efectos sobre [mix] (ya con la mezcla seca). [rvSend] y [ecSend] son los envíos acumulados. */
    fun process(mix: FloatArray, rvSend: FloatArray, ecSend: FloatArray, n: Int) {
        reverb.process(rvSend, mix, n, rv)
        echo.process(ecSend, mix, n, ec)
        val a = (lpHz / (lpHz + sr / 6.2831855f)).coerceIn(0.01f, 1f)
        if (resMix > 0.001f) resSvf.set(resHz, 6f, sr.toFloat())
        val g = 1f + drive * 2.2f
        for (i in 0 until n) {
            var x = mix[i]
            if (resMix > 0.001f) {
                resSvf.process(x)
                x += resSvf.bp() * resMix * 2.5f
            }
            if (drive > 0.01f) x = softClip(x * g) / (1f + drive * 0.35f)
            lp += a * (x - lp)
            mix[i] = lp
        }
    }
}

/**
 * Estado compartido por todos los sintetizadores: la reserva de voces, el generador aleatorio y los parámetros del
 * mundo activo. Solo lo toca el hilo de audio (los comandos llegan por la cola del [AudioEngine]).
 */
class EngineCore(val sampleRate: Int, seed: Int) {
    val sr: Float = sampleRate.toFloat()
    val pool = VoicePool(sr)
    val rng = FastRng(seed)
    val effects = AudioEffects(sampleRate)

    val pitchMul: Float get() = effects.pitchMul

    fun samples(seconds: Float): Int = (seconds * sr).toInt()
}
