package com.terror2d.creature

import com.terror2d.pixel.CreatureSpriteData
import kotlin.math.abs

/** Índices de pose del cuerpo (orden de CreatureSpriteData.BODY_POSES). */
object CreaturePose {
    const val IDLE = 0
    const val INVESTIGATE = 1
    const val ALERT = 2
    const val CAPTURE = 3
    const val HURT = 4
    const val WALK0 = 5      // WALK_0..7
    const val RUN0 = 13      // RUN_0..7
    const val FRAMES = 8
}

/**
 * Brazo largo como PÉNDULO amortiguado colgado del hombro del cuerpo. Ángulos en grados: + = hacia delante (hacia donde
 * mira la criatura). Recibe (1) un objetivo suave del ciclo de paso (contrabalanceo de la pierna contraria) y (2)
 * empujones por inercia cuando el hombro se desplaza con el cuerpo, de modo que el brazo REACCIONA al peso y al paso en
 * vez de flotar por su cuenta. El antebrazo se retrasa respecto al brazo (codo) con su propio muelle.
 * Se cuantiza a los ángulos de los sprites con histéresis para que no parpadee entre dos.
 */
class ArmPendulum(private val stiffness: Float = 14f, private val damping: Float = 2.4f) {
    var angle = 0f
        private set
    var vel = 0f
        private set
    var elbow = 0f
        private set
    private var elbowVel = 0f
    var swingIdx = REST_SWING
        private set
    var bendIdx = REST_BEND
        private set

    /** Empujón de inercia (grados/segundo). */
    fun kick(v: Float) { vel += v }
    fun kickElbow(v: Float) { elbowVel += v }

    fun update(dt: Float, target: Float) {
        val h = minOf(dt, 1f / 30f)
        vel += (-stiffness * (angle - target) - damping * vel) * h
        angle += vel * h
        angle = angle.coerceIn(-48f, 70f)
        val et = (-vel * 0.28f).coerceIn(-14f, 14f)
        elbowVel += (-46f * (elbow - et) - 7f * elbowVel) * h
        elbow += elbowVel * h
        elbow = elbow.coerceIn(-16f, 16f)
        swingIdx = pick(CreatureSpriteData.ARM_SWING, swingIdx, angle)
        bendIdx = pick(CreatureSpriteData.ARM_BEND, bendIdx, elbow)
    }

    fun reset() { angle = 0f; vel = 0f; elbow = 0f; elbowVel = 0f; swingIdx = REST_SWING; bendIdx = REST_BEND }

    val index: Int get() = swingIdx * CreatureSpriteData.ARM_BEND.size + bendIdx

    companion object {
        /** Índice del balanceo 0° y del codo 0° (ver CreatureSpriteData.ARM_SWING / ARM_BEND). */
        val REST_SWING: Int = CreatureSpriteData.ARM_SWING.indexOf(0)
        val REST_BEND: Int = CreatureSpriteData.ARM_BEND.indexOf(0)

        fun pick(values: IntArray, prev: Int, v: Float): Int {
            var best = 0
            var bd = Float.MAX_VALUE
            for (i in values.indices) { val d = abs(v - values[i]); if (d < bd) { bd = d; best = i } }
            if (best == prev) return prev
            val gap = abs(values[best] - values[prev]).toFloat()
            return if (abs(v - values[prev]) > gap * 0.62f) best else prev     // histéresis
        }
    }
}
