package com.terror2d.creature

import kotlin.math.abs

/** Tipo de ruido. [base] es la intensidad típica (0..1): caminar poco, un florero caído muchísimo. */
enum class NoiseType(val base: Float, val duration: Float) {
    WALK(0.25f, 0.2f),
    RUN(0.5f, 0.3f),
    DOOR(0.5f, 0.5f),
    OBJECT_HIT(0.75f, 0.6f),
    PLAYER_FALL(0.75f, 0.6f),
    VASE_FALL(1.0f, 1.0f),
    OBJECT_BROKEN(1.0f, 1.0f)
}

/** Un ruido NO es «el jugador está aquí»: lleva posición, intensidad, duración, tipo y el momento en que sonó. */
class NoiseEvent(
    val x: Float,
    val segmentId: String,
    val type: NoiseType,
    val intensity: Float = type.base,
    val duration: Float = type.duration,
    val time: Float = 0f
)

/** Cola de ruidos recientes (el juego publica, la criatura consulta). Sin allocations por frame salvo el propio ruido. */
class NoiseBus {
    private val list = ArrayList<NoiseEvent>()
    val recent: List<NoiseEvent> get() = list

    fun emit(n: NoiseEvent) { list.add(n) }

    /** Descarta los ruidos que ya terminaron (duración + margen). */
    fun prune(now: Float) {
        var i = 0
        while (i < list.size) {
            if (now - list[i].time > list[i].duration + 0.25f) list.removeAt(i) else i++
        }
    }
}

/** Hash determinista (0..1) para variaciones que NO deben ser azar por frame. */
object Det {
    fun hash01(a: Int, b: Int, c: Int = 0): Float {
        var h = a * 374761393 + b * 668265263 + c * 2147483647
        h = (h xor (h ushr 13)) * 1274126177
        h = h xor (h ushr 16)
        return (h and 0xFFFFFF) / 16777216f
    }
}

/** Oído de la criatura: lo que percibe es posición APROXIMADA y se debilita con la distancia. */
object Hearing {
    const val RANGE = 260f
    const val THRESHOLD = 0.08f

    fun perceivedIntensity(n: NoiseEvent, listenerX: Float): Float {
        val d = abs(n.x - listenerX)
        if (d >= RANGE) return 0f
        return n.intensity * (1f - d / RANGE)
    }

    /** Posición que la criatura CREE haber oído: el error crece con la distancia y baja con la intensidad. */
    fun perceivedX(n: NoiseEvent, listenerX: Float, seed: Int): Float {
        val d = abs(n.x - listenerX)
        val err = (Det.hash01(seed, (n.time * 100f).toInt(), n.type.ordinal) - 0.5f) * 2f * d * 0.18f * (1f - n.intensity * 0.5f)
        return n.x + err
    }
}
