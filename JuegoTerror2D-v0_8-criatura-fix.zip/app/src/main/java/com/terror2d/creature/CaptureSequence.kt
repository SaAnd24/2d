package com.terror2d.creature

/**
 * Captura SIN Game Over: pausa, proximidad, audio cortado, negro, respiración, silencio y despertar en el dormitorio.
 * Solo lógica de tiempos; la escena pinta [blackAlpha] y aplica [audioDuck]. Al terminar ([done]) recoloca al niño.
 */
class CaptureSequence {
    enum class Phase { IDLE, FREEZE, CLOSE_UP, FADE_BLACK, BREATH, SILENCE, WAKE }

    var phase = Phase.IDLE
        private set
    private var t = 0f
    var done = false
        private set
    val active: Boolean get() = phase != Phase.IDLE && !done

    fun start() { phase = Phase.FREEZE; t = 0f; done = false }

    fun update(dt: Float) {
        if (!active) return
        t += dt
        val limit = when (phase) {
            Phase.FREEZE -> 0.5f
            Phase.CLOSE_UP -> 1.0f
            Phase.FADE_BLACK -> 0.8f
            Phase.BREATH -> 1.6f
            Phase.SILENCE -> 1.0f
            Phase.WAKE -> 1.2f
            else -> 0f
        }
        if (t >= limit) {
            t = 0f
            phase = when (phase) {
                Phase.FREEZE -> Phase.CLOSE_UP
                Phase.CLOSE_UP -> Phase.FADE_BLACK
                Phase.FADE_BLACK -> Phase.BREATH
                Phase.BREATH -> Phase.SILENCE
                Phase.SILENCE -> Phase.WAKE
                else -> { done = true; Phase.IDLE }
            }
        }
    }

    /** Estas fases ya han ocurrido en el dormitorio: la escena recoloca al niño al entrar en WAKE. */
    val shouldRelocate: Boolean get() = phase == Phase.WAKE

    val blackAlpha: Float get() = when (phase) {
        Phase.FADE_BLACK -> (t / 0.8f).coerceIn(0f, 1f)
        Phase.BREATH, Phase.SILENCE -> 1f
        Phase.WAKE -> 1f - (t / 1.2f).coerceIn(0f, 1f)
        else -> 0f
    }

    /** 1 = audio normal, 0 = cortado (se distorsiona en CLOSE_UP y desaparece en negro). */
    val audioDuck: Float get() = when (phase) {
        Phase.CLOSE_UP -> 1f - 0.7f * (t / 1.0f)
        Phase.FADE_BLACK, Phase.SILENCE -> 0f
        Phase.BREATH -> 0.15f
        Phase.WAKE -> t / 1.2f
        else -> 1f
    }

    /** Siempre falso: no existe Game Over tradicional. */
    val isGameOver: Boolean get() = false
}
