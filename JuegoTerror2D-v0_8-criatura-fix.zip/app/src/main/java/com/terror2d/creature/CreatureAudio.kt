package com.terror2d.creature

import com.terror2d.audio.AudioPort
import com.terror2d.audio.SfxId
import kotlin.math.abs

/**
 * Sonido CONTINUO de la criatura (respiración, brazos, bocas), reactivo a la IA. Los eventos puntuales (pasos, cambio
 * de estado, captura) llegan por el bus y los resuelve el AudioDirector. Todo es procedural: no hay archivos de audio.
 * Las bocas secundarias suenan por turnos (mínimo [MOUTH_GAP] entre sonidos y como mucho una por cambio), con el
 * mismo desfase que su animación, nunca todas a la vez.
 */
class CreatureAudio(private val audio: AudioPort) {
    private var breathT = 0f
    private var armT = 0f
    private var mouthGapT = 0f
    private var wetT = 0f
    private val wasOpen = BooleanArray(Creature.SECONDARY)
    private var lastMain = CreatureMouth.CLOSED

    /** Intensidad según estado: PATROL lenta ... CHASE fuerte. [dist] = distancia al niño. */
    fun update(dt: Float, c: Creature, dist: Float) {
        val prox = (1f - dist / FAR).coerceIn(0f, 1f)
        if (prox <= 0.03f) return
        val a = c.arousal
        breathT -= dt
        if (breathT <= 0f) {
            breathT = 3.4f - 2.5f * a
            audio.playSfx(SfxId.CREATURE_BREATH, (0.35f + 0.9f * a) * prox)
        }
        val moving = c.brain.speed > 1f
        armT -= dt
        if (moving && armT <= 0f) {
            armT = if (c.state == CreatureState.CHASE) 0.45f else 1.1f
            audio.playSfx(SfxId.CREATURE_ARM, (0.4f + 0.6f * a) * prox)
        }
        wetT -= dt
        if (wetT <= 0f) { wetT = 2.2f - 1.4f * a; audio.playSfx(SfxId.CREATURE_WET, (0.3f + 0.5f * a) * prox) }
        mouthGapT -= dt
        for (i in 0 until Creature.SECONDARY) {
            val open = c.mouths.openness(i, c.time, a) > 0.45f
            if (open && !wasOpen[i] && mouthGapT <= 0f) {
                audio.playSfx(SfxId.CREATURE_MOUTH, (0.4f + 0.5f * a) * prox)
                mouthGapT = MOUTH_GAP * (1.4f - a)
            }
            wasOpen[i] = open
        }
        if (c.mainMouth != lastMain) {
            if (c.mainMouth >= CreatureMouth.OPEN && lastMain < CreatureMouth.OPEN && a > 0.4f) audio.playSfx(SfxId.CREATURE_GROWL, (0.5f + 0.6f * a) * prox)
            lastMain = c.mainMouth
        }
    }

    companion object {
        const val FAR = 420f
        const val MOUTH_GAP = 0.35f
        fun proximity(dist: Float) = (1f - abs(dist) / FAR).coerceIn(0f, 1f)
    }
}
