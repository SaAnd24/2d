package com.terror2d.creature

import kotlin.math.floor
import kotlin.math.min

/** Parámetros propios de cada boca: nunca hay una animación global. */
class MouthParams(
    val phaseOffset: Float,
    val cycleSpeed: Float,
    val openDuration: Float,
    val closeDuration: Float,
    val randomVariation: Float,
    /** Probabilidad de que un ciclo se quede casi quieto. */
    val restChance: Float
)

/**
 * Apertura (0..1) de cada boca secundaria en función del TIEMPO: determinista (hash por boca y ciclo, sin azar por frame).
 * [arousal] acelera los ciclos (CHASE = bocas más activas) y reduce los descansos.
 */
class MouthAnimator(val count: Int, private val seed: Int) {
    val params: Array<MouthParams> = Array(count) { i ->
        MouthParams(
            phaseOffset = Det.hash01(seed, i, 1),
            cycleSpeed = 0.18f + 0.22f * Det.hash01(seed, i, 2),
            openDuration = 0.25f + 0.2f * Det.hash01(seed, i, 3),
            closeDuration = 0.15f + 0.2f * Det.hash01(seed, i, 4),
            randomVariation = 0.1f + 0.3f * Det.hash01(seed, i, 5),
            restChance = 0.25f + 0.35f * Det.hash01(seed, i, 6)
        )
    }

    fun openness(i: Int, time: Float, arousal: Float): Float {
        val p = params[i]
        val speed = p.cycleSpeed * (1f + arousal * 1.6f)
        val c = time * speed + p.phaseOffset
        val cycle = floor(c).toInt()
        val t = c - cycle                                   // 0..1 dentro del ciclo
        val rest = p.restChance * (1f - arousal * 0.7f)
        if (Det.hash01(seed + i, cycle, 7) < rest) return 0.08f * Det.hash01(seed, i, cycle)  // casi inmóvil
        val peak = (0.55f + 0.45f * (1f - p.randomVariation * Det.hash01(seed, i, cycle + 11))).coerceIn(0f, 1f)
        val total = p.openDuration + p.closeDuration
        val a = p.openDuration / total
        val w = 0.7f                                         // fracción activa del ciclo
        if (t > w) return 0f
        val u = t / w
        return peak * if (u < a) smooth(u / a) else smooth(1f - (u - a) / (1f - a))
    }

    private fun smooth(x: Float): Float { val v = min(1f, maxOf(0f, x)); return v * v * (3f - 2f * v) }

    /** Cuántas bocas están claramente abiertas ahora (para comprobar que no se mueven todas a la vez). */
    fun openCount(time: Float, arousal: Float): Int {
        var n = 0
        for (i in 0 until count) if (openness(i, time, arousal) > 0.3f) n++
        return n
    }
}
