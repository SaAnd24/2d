package com.terror2d.puzzle

import com.terror2d.inventory.ItemRegistry
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sqrt

/**
 * Geometría del puzzle en la pantalla lógica 320x180 de la PRIMERA PERSONA (el niño mira la mesa desde arriba).
 * Todo en píxeles lógicos. La mesa ocupa desde [TABLE_TOP] hasta el borde inferior; las manos entran por abajo.
 */
object PuzzleLayout {
    const val BOX_W = 44f
    const val BOX_H = 58f

    const val TABLE_TOP = 46f

    /** Centros de los tres huecos del pastillero de papel, de izquierda a derecha. */
    val SLOT_X = floatArrayOf(80f, 148f, 216f)
    const val SLOT_Y = 128f
    const val SLOT_W = 50f
    const val SLOT_H = 64f

    /** Distancia máxima (centro de la caja a centro del hueco) para que la caja encaje al soltarla. */
    const val SNAP_RADIUS = 34f

    /** Hoja de la farmacia (documento 3) sobre la mesa. */
    const val PAPER_X = 290f
    const val PAPER_Y = 112f
    const val PAPER_W = 40f
    const val PAPER_H = 52f

    /** Pestaña VOLVER (arriba a la izquierda). */
    const val BACK_X = 6f
    const val BACK_Y = 6f
    const val BACK_W = 46f
    const val BACK_H = 15f

    const val MIN_CX = BOX_W / 2f + 4f
    const val MAX_CX = 320f - BOX_W / 2f - 4f
    const val MIN_CY = TABLE_TOP + BOX_H / 2f - 8f
    const val MAX_CY = 180f - BOX_H / 2f + 16f
}

/** Una caja de medicinas sobre la mesa: un objeto físico que se arrastra y se puede dar la vuelta. */
class PuzzleBox(
    val itemId: String,
    /** 0 = mañana, 1 = tarde, 2 = noche: el hueco que le corresponde (de izquierda a derecha). */
    val timeSlot: Int,
    /** Letra grande de la tapa (inicial del nombre del medicamento inventado). */
    val letter: Char,
    val name: String,
    startX: Float,
    startY: Float,
    startTilt: Float
) {
    var x: Float = startX
    var y: Float = startY
    var targetX: Float = startX
    var targetY: Float = startY

    /** Inclinación en grados (se inclina con el movimiento del dedo). */
    var tilt: Float = startTilt
    var targetTilt: Float = startTilt

    /** 0 = apoyada en la mesa, 1 = levantada del todo (sombra más lejos y un poco más grande). */
    var lift: Float = 0f

    /** Hueco (0..2) en el que está encajada; -1 = suelta sobre la mesa. */
    var slot: Int = -1

    /** Dada la vuelta (se ve el reverso con las indicaciones). */
    var flipped: Boolean = false

    /** Progreso del giro: 0 = frente, 1 = reverso. */
    var flipT: Float = 0f

    internal var fromX = startX
    internal var fromY = startY
    internal var fromSlot = -1

    fun contains(px: Float, py: Float): Boolean =
        abs(px - x) <= PuzzleLayout.BOX_W / 2f && abs(py - y) <= PuzzleLayout.BOX_H / 2f

    val isCorrect: Boolean get() = slot == timeSlot
}

/**
 * Puzzle de las tres cajas de medicinas (v0.6). SIN menú de selección: las cajas se tocan, se mantienen, se
 * arrastran y se sueltan sobre la mesa como objetos físicos. Un toque corto da la vuelta a la caja (reverso).
 *
 * Solución (se descubre observando y leyendo, sin saber de medicina):
 *  - el pastillero de papel tiene tres huecos con un dibujo: el sol que sale, el sol alto y la luna;
 *  - cada caja dice por detrás cuándo se toma (mañana / tarde / noche) y lleva el mismo dibujo;
 *  - la hoja de la farmacia (documento 3) lo explica.
 * Orden correcto de izquierda a derecha: AZUL (mañana), NARANJA (tarde), BLANCA (noche). Las letras de las tapas
 * (S, O, L) forman la contraseña [PASSWORD]. Nunca se muestra un mensaje de error: una disposición incorrecta
 * simplemente no hace nada.
 *
 * Lógica pura (sin Android): la escena le pasa el puntero y la renderiza el renderer.
 */
class MedicinePuzzle {

    val boxes: Array<PuzzleBox> = arrayOf(
        PuzzleBox(ItemRegistry.PILL_BOX_WHITE, 2, 'L', "LUNETRA", 84f, 74f, 5f),
        PuzzleBox(ItemRegistry.PILL_BOX_ORANGE, 1, 'O', "ORPLAN", 150f, 70f, -4f),
        PuzzleBox(ItemRegistry.PILL_BOX_BLUE, 0, 'S', "SOLVEXA", 214f, 76f, 3f)
    )

    /** Orden de dibujo (la última es la de arriba). */
    private val order = ArrayList<PuzzleBox>(boxes.toList())

    val drawOrder: List<PuzzleBox> get() = order

    var dragging: PuzzleBox? = null
        private set

    /** true cuando las tres cajas están en su sitio (las cajas quedan bloqueadas). */
    var solved: Boolean = false
        private set

    /** Segundos desde que se resolvió (para el brillo y la salida). */
    var solvedTime: Float = 0f
        private set

    /** Se pone a true UNA vez al resolverse; la escena lo consume para publicar el evento. */
    var justSolved: Boolean = false

    /** Documento que el niño ha tocado para leer (la escena lo consume). */
    var requestedDocument: String? = null

    /** El niño ha pulsado VOLVER. */
    var wantsExit: Boolean = false

    /** Pista suave pendiente (1 = mira por detrás, 2 = la hoja de la farmacia); la escena la muestra y la limpia. */
    var pendingHint: Int = 0
    private var hintsGiven = 0

    /** Mano que se dibuja: 0 = apoyadas, 1 = agarrando, 2 = señalando. */
    val handKind: Int
        get() = when {
            dragging != null -> 1
            pokeTimer > 0f -> 2
            else -> 0
        }

    /** Posición del puntero (para dibujar la mano). */
    var pointerX: Float = 160f
        private set
    var pointerY: Float = 150f
        private set

    private var time = 0f
    private var idleTime = 0f
    private var pressX = 0f
    private var pressY = 0f
    private var pressTime = 0f
    private var moved = false
    private var pressedBox: PuzzleBox? = null
    private var pressedPaper = false
    private var pressedBack = false
    private var grabDX = 0f
    private var grabDY = 0f
    private var pokeTimer = 0f

    // ------------------------------------------------------------------ puntero

    fun onPress(px: Float, py: Float) {
        pointerX = px
        pointerY = py
        pressX = px
        pressY = py
        pressTime = time
        moved = false
        idleTime = 0f
        pressedBox = null
        pressedPaper = false
        pressedBack = false
        if (inRect(px, py, PuzzleLayout.BACK_X, PuzzleLayout.BACK_Y, PuzzleLayout.BACK_W, PuzzleLayout.BACK_H)) {
            pressedBack = true
            return
        }
        if (solved) return
        // la caja de más arriba bajo el dedo
        for (i in order.indices.reversed()) {
            val b = order[i]
            if (b.contains(px, py)) {
                pressedBox = b
                dragging = b
                grabDX = b.x - px
                grabDY = b.y - py
                b.fromX = b.x
                b.fromY = b.y
                b.fromSlot = b.slot
                order.remove(b)
                order.add(b)
                return
            }
        }
        if (inRect(px, py, PuzzleLayout.PAPER_X - PuzzleLayout.PAPER_W / 2f, PuzzleLayout.PAPER_Y - PuzzleLayout.PAPER_H / 2f,
                PuzzleLayout.PAPER_W, PuzzleLayout.PAPER_H)) {
            pressedPaper = true
        }
    }

    fun onDrag(px: Float, py: Float) {
        pointerX = px
        pointerY = py
        idleTime = 0f
        if (!moved && distance(px, py, pressX, pressY) > TAP_SLOP) moved = true
        val b = dragging ?: return
        if (!moved) return
        b.targetX = (px + grabDX).coerceIn(PuzzleLayout.MIN_CX, PuzzleLayout.MAX_CX)
        b.targetY = (py + grabDY).coerceIn(PuzzleLayout.MIN_CY, PuzzleLayout.MAX_CY)
        // al sacarla de un hueco lo deja libre
        if (b.slot >= 0) b.slot = -1
    }

    fun onRelease(px: Float, py: Float) {
        pointerX = px
        pointerY = py
        idleTime = 0f
        val tap = !moved && (time - pressTime) < TAP_TIME
        val b = dragging
        dragging = null
        if (pressedBack) {
            if (inRect(px, py, PuzzleLayout.BACK_X, PuzzleLayout.BACK_Y, PuzzleLayout.BACK_W, PuzzleLayout.BACK_H)) wantsExit = true
            pressedBack = false
            return
        }
        if (b != null) {
            if (tap) {
                // un toque corto: dar la vuelta a la caja (reverso con las indicaciones)
                b.targetX = b.fromX
                b.targetY = b.fromY
                b.slot = b.fromSlot
                b.flipped = !b.flipped
                pokeTimer = 0.45f
            } else {
                drop(b)
            }
            pressedBox = null
            return
        }
        if (pressedPaper && tap) requestedDocument = com.terror2d.story.Documents.PHARMACY
        pressedPaper = false
    }

    /** Suelta la caja: encaja en el hueco cercano (intercambiando si estaba ocupado) o se queda sobre la mesa. */
    private fun drop(b: PuzzleBox) {
        var best = -1
        var bestD = PuzzleLayout.SNAP_RADIUS
        for (s in 0 until 3) {
            val d = distance(b.targetX, b.targetY, PuzzleLayout.SLOT_X[s], PuzzleLayout.SLOT_Y)
            if (d <= bestD) {
                bestD = d
                best = s
            }
        }
        if (best < 0) {
            b.slot = -1
            b.targetTilt = b.tilt * 0.4f
            return
        }
        val other = boxes.firstOrNull { it !== b && it.slot == best }
        if (other != null) {
            // intercambio: la otra caja ocupa el lugar de origen de esta (su hueco o su sitio sobre la mesa)
            if (b.fromSlot >= 0) {
                other.slot = b.fromSlot
                other.targetX = PuzzleLayout.SLOT_X[b.fromSlot]
                other.targetY = PuzzleLayout.SLOT_Y
            } else {
                other.slot = -1
                other.targetX = b.fromX
                other.targetY = b.fromY
            }
            other.targetTilt = 0f
        }
        b.slot = best
        b.targetX = PuzzleLayout.SLOT_X[best]
        b.targetY = PuzzleLayout.SLOT_Y
        b.targetTilt = 0f
        checkSolved()
    }

    private fun checkSolved() {
        if (solved) return
        for (b in boxes) if (!b.isCorrect) return
        solved = true
        justSolved = true
        solvedTime = 0f
        dragging = null
    }

    /** true si las tres cajas están encajadas en su hueco correcto (sin efectos secundarios). */
    fun isSolution(): Boolean = boxes.all { it.isCorrect }

    // ------------------------------------------------------------------ simulación

    fun update(dt: Float) {
        time += dt
        if (pokeTimer > 0f) pokeTimer -= dt
        if (solved) solvedTime += dt else idleTime += dt
        for (b in boxes) {
            val rate = if (b === dragging) FOLLOW_DRAG else FOLLOW_SETTLE
            val k = 1f - exp(-rate * dt)
            val dx = b.targetX - b.x
            b.x += dx * k
            b.y += (b.targetY - b.y) * k
            if (b === dragging) {
                // se inclina hacia donde la arrastras (objeto físico con inercia)
                b.targetTilt = (dx * 0.9f).coerceIn(-9f, 9f)
            }
            b.tilt += (b.targetTilt - b.tilt) * (1f - exp(-12f * dt))
            val liftTarget = if (b === dragging && moved) 1f else 0f
            b.lift += (liftTarget - b.lift) * (1f - exp(-16f * dt))
            val flipTarget = if (b.flipped) 1f else 0f
            val step = FLIP_SPEED * dt
            b.flipT = when {
                b.flipT < flipTarget -> minOf(flipTarget, b.flipT + step)
                b.flipT > flipTarget -> maxOf(flipTarget, b.flipT - step)
                else -> b.flipT
            }
        }
        if (!solved && pendingHint == 0 && idleTime > HINT_AFTER && hintsGiven < 2) {
            hintsGiven++
            pendingHint = hintsGiven
            idleTime = 0f
        }
    }

    private fun inRect(px: Float, py: Float, x: Float, y: Float, w: Float, h: Float) = px >= x && px <= x + w && py >= y && py <= y + h

    private fun distance(ax: Float, ay: Float, bx: Float, by: Float): Float {
        val dx = ax - bx
        val dy = ay - by
        return sqrt(dx * dx + dy * dy)
    }

    companion object {
        /** Id del puzzle (eventos). */
        const val ID = "medicine_puzzle"

        const val PASSWORD = "SOL"
        const val TAP_SLOP = 5f
        const val TAP_TIME = 0.35f
        const val FOLLOW_DRAG = 24f
        const val FOLLOW_SETTLE = 14f
        const val FLIP_SPEED = 4.5f
        const val HINT_AFTER = 14f

        /** Tiempo (s) que se queda la imagen resuelta antes de volver a tercera persona. */
        const val SOLVED_HOLD = 2.6f
    }
}
