package com.terror2d.scene

/** La casa del protagonista (v0.4): primera zona real del juego. */
class HouseScene(seed: Long = HouseDefinition.DEFAULT_SEED) : Scene(HouseDefinition.create(seed))
