package com.terror2d.scene

import com.terror2d.core.CameraMode
import com.terror2d.draw.Cr
import com.terror2d.draw.CrayonBuilder
import com.terror2d.events.EventTrigger
import com.terror2d.events.EventType
import com.terror2d.interaction.InteractionIcon
import com.terror2d.inventory.ItemRegistry
import com.terror2d.interaction.InteractionResult
import com.terror2d.render.Palette
import com.terror2d.story.Documents
import com.terror2d.story.IntroScript
import com.terror2d.story.StoryFlags
import com.terror2d.ui.DialogueLine
import com.terror2d.world.DarkZone
import com.terror2d.world.Door
import com.terror2d.world.DoorTarget
import com.terror2d.world.ExamineSpot
import com.terror2d.world.HouseProps
import com.terror2d.world.Lamp
import com.terror2d.world.LightSource
import com.terror2d.world.LightType
import com.terror2d.world.PlushFrog
import com.terror2d.world.WorldPickup
import com.terror2d.world.ScriptedSpot
import com.terror2d.world.Wardrobe
import com.terror2d.world.WardrobeDeco
import com.terror2d.world.WardrobeStyle
import com.terror2d.world.WorldObject

/**
 * LA CASA (v0.4): un pasillo principal largo con acceso directo a siete espacios.
 *
 *   KidRoom · Bathroom · MomRoom · Laundry · Kitchen · Dining · Cellar   (todos salen del Hall)
 *
 * Cada espacio tiene su composición, iluminación y varios puntos examinables; las voces del niño son
 * las de un niño de 8 años. La estructura (posiciones, puertas, spawns, armarios, luces, textos) es
 * 100 % literal: la semilla solo cambia trazos, texturas y pequeños detalles.
 */
object HouseDefinition {
    const val ID = "house"
    const val DEFAULT_SEED = 20260404L

    const val HALL = "Hall"
    const val KID = "KidRoom"
    const val BATH = "Bathroom"
    const val MOM = "MomRoom"
    const val LAUNDRY = "Laundry"
    const val KITCHEN = "Kitchen"
    const val DINING = "Dining"
    const val CELLAR = "Cellar"

    /** Las siete habitaciones (el Hall es el pasillo). */
    val ROOMS = listOf(KID, BATH, MOM, LAUNDRY, KITCHEN, DINING, CELLAR)

    const val FLOOR_Y = 146f
    const val HALL_WIDTH = 960f

    /** v0.8: hueco bajo en el pasillo. El niño pasa; el cuerpo grande de la criatura NO cabe (ventaja física del mundo). */
    const val GAP_ID = "hall_narrow_gap"
    const val GAP_X = 410f
    const val GAP_W = 30f
    private const val WALL = 12f

    /** X de cada puerta del pasillo, de izquierda a derecha. */
    val HALL_DOOR_X: Map<String, Float> = mapOf(
        KID to 70f, BATH to 200f, MOM to 330f, LAUNDRY to 460f,
        KITCHEN to 590f, DINING to 720f, CELLAR to 860f
    )

    fun hallDoorId(room: String) = "door_hall_" + room
    fun roomDoorId(room: String) = "door_" + room + "_hall"
    fun fromSpawn(room: String) = "from_" + room

    const val WARDROBE_KID = "wardrobe_kid"
    const val WARDROBE_MOM = "wardrobe_mom"
    const val WARDROBE_LAUNDRY = "wardrobe_laundry"
    const val WARDROBE_CELLAR = "wardrobe_cellar"

    const val SPOT_SINK = "kitchen_sink"
    const val SPOT_KID_BED = "kid_bed"
    const val PLUSH = "plush_frog"
    const val PICKUP_BLUE = "pickup_pill_blue"
    const val PICKUP_ORANGE = "pickup_pill_orange"
    const val PICKUP_WHITE = "pickup_pill_white"

    private fun isPillBox(id: String?): Boolean =
        id == ItemRegistry.PILL_BOX_BLUE || id == ItemRegistry.PILL_BOX_ORANGE || id == ItemRegistry.PILL_BOX_WHITE
    const val SPOT_MOM = "mom_talk"
    const val SPOT_DOC_MEDICAL = "spot_doc_medical"
    const val SPOT_DOC_FINANCE = "spot_doc_finance"
    const val SPOT_PUZZLE = "spot_medicine_puzzle"
    const val SPOT_TABLE_DONE = "spot_mom_table_done"
    const val PUZZLE_ID = com.terror2d.puzzle.MedicinePuzzle.ID

    private val WARM = Palette.LIGHT_WARM or 0xFF000000.toInt()
    private val COLD = Palette.LIGHT_COLD or 0xFF000000.toInt()
    private val PALE = Palette.LIGHT_PALE or 0xFF000000.toInt()
    private const val F = FLOOR_Y

    private val DOOR_COLORS: Map<String, Int> = mapOf(
        KID to Cr.GREEN, BATH to Cr.BLUE, MOM to Cr.PURPLE, LAUNDRY to Cr.TEAL,
        KITCHEN to Cr.ORANGE, DINING to Cr.CORAL, CELLAR to Cr.DGRAY
    )

    /** Crea todo NUEVO en cada llamada: cada partida empieza con puertas, armarios y guiones limpios. */
    fun create(seed: Long = DEFAULT_SEED): SceneDefinition =
        SceneDefinition(
            id = ID,
            seed = seed,
            segments = listOf(hall(), kidRoom(), bathroom(), momRoom(), laundry(), kitchen(), dining(), cellar()),
            startSegmentId = KID,
            startSpawnId = "start",
            triggers = listOf(
                EventTrigger(EventType.ON_ENTER_ROOM, HALL, once = true) { ctx ->
                    ctx.dialogue.showMessage("El pasillo está muy largo hoy.")
                },
                // v0.8 (condición técnica de prueba, no narrativa): al terminar el puzzle la criatura patrulla el pasillo
                EventTrigger(EventType.ON_STORY_FLAG, com.terror2d.story.StoryFlags.MEDICINE_PUZZLE_DONE, once = true) { ctx ->
                    ctx.state.story.set(com.terror2d.story.StoryFlags.CREATURE_ACTIVE)
                },
                EventTrigger(EventType.ON_ENTER_ROOM, CELLAR, once = true) { ctx ->
                    ctx.dialogue.showMessage("Aquí abajo hace frío.")
                }
            ),
            scripts = listOf(IntroScript(KID)),
            conversations = com.terror2d.conversation.Conversations.defaults(),
            creature = CreatureSpawn(
                segmentId = HALL, x = 760f, minX = 470f, maxX = HALL_WIDTH - 60f, seed = 8,
                requiredFlag = com.terror2d.story.StoryFlags.CREATURE_ACTIVE
            )
        )

    // ------------------------------------------------------------------ ayudas

    private fun ex(id: String, x: Float, w: Float, text: String, margin: Float = 6f) =
        ExamineSpot(id, x, F - 70f, w, 70f, text, margin)

    private fun doorColor(room: String): Int = DOOR_COLORS[room] ?: Cr.WOOD

    private fun hallDoor(room: String): Door {
        val c = doorColor(room)
        return Door(
            hallDoorId(room), HALL_DOOR_X[room] ?: 0f, F,
            target = DoorTarget(room, "from_hall"),
            panelColor = c, panelHatch = CrayonBuilder.darker(c)
        )
    }

    private fun backDoor(room: String, x: Float = 24f): Door {
        val c = doorColor(room)
        return Door(
            roomDoorId(room), x, F,
            target = DoorTarget(HALL, fromSpawn(room)),
            panelColor = c, panelHatch = CrayonBuilder.darker(c)
        )
    }

    /** Aparición al volver de una habitación al pasillo: justo fuera de la zona de la puerta. */
    private fun hallSpawn(room: String) = SpawnPoint((HALL_DOOR_X[room] ?: 0f) + 57f, 1)

    private val WARDROBE_FRAME = Palette.WARDROBE_TRIM

    // ------------------------------------------------------------------ PASILLO (el corazón de la casa)

    private fun hall(): RoomSegment {
        val o = ArrayList<WorldObject>()
        val lampA = Lamp(135f, 38f, radius = 128f, intensity = 0.95f, color = WARM)
        val lampB = Lamp(395f, 38f, radius = 112f, intensity = 0.8f, color = WARM)
        val lampC = Lamp(655f, 40f, radius = 112f, intensity = 0.85f, color = PALE, flicker = 0.1f)
        val lampD = Lamp(905f, 44f, radius = 78f, intensity = 0.55f, color = COLD, flicker = 0.05f)

        o.add(HouseProps.rug(150f, 700f, Cr.CORAL, Cr.RED))
        o.add(HouseProps.windowFrame(396f, 34f, 44f, 52f, Cr.BLUE))
        o.add(HouseProps.photoFrame(118f, 38f, 58f, 40f, 2))
        o.add(HouseProps.clock(176f, 34f))
        o.add(HouseProps.kidDrawing(250f, 44f, 40f, 34f, 1))
        o.add(HouseProps.mirror(520f, 40f, 34f, 50f))
        o.add(HouseProps.kidDrawing(650f, 44f, 44f, 36f, 2))
        o.add(HouseProps.photoFrame(776f, 44f, 32f, 26f, 1))
        o.add(HouseProps.photoFrame(814f, 40f, 32f, 26f, 0))
        for (r in ROOMS) {
            val kind = when (r) {
                KID -> 0
                BATH -> 1
                MOM -> 2
                LAUNDRY -> 3
                KITCHEN -> 4
                DINING -> 5
                else -> 6
            }
            o.add(HouseProps.doorSign((HALL_DOOR_X[r] ?: 0f) + 5f, 48f, kind))
        }
        o.add(com.terror2d.world.NarrowGap(GAP_ID, GAP_X, F, GAP_W))
        o.add(HouseProps.coatRack(20f))
        o.add(HouseProps.hallTable(118f))
        o.add(HouseProps.plant(298f))
        o.add(HouseProps.shoeRack(388f))
        o.add(HouseProps.umbrellaStand(560f))
        o.add(HouseProps.umbrellaStand(904f))
        o.add(lampA)
        o.add(lampB)
        o.add(lampC)
        o.add(lampD)
        o.add(ex("ex_hall_coats", 16f, 40f, "El abrigo rojo es de mamá. Mi chaqueta está más abajo."))
        o.add(ex("ex_hall_photo", 118f, 58f, "Una foto de la playa. A uno le quedó rara la sonrisa."))
        o.add(ex("ex_hall_phone", 124f, 42f, "El teléfono de la casa. Casi nunca suena."))
        o.add(ex("ex_hall_clock", 174f, 28f, "Mamá dice que el reloj siempre va atrasado."))
        o.add(ex("ex_hall_frog_drawing", 250f, 40f, "Una rana con una cruz. Siempre la dibujo igual."))
        o.add(ex("ex_hall_plant", 296f, 28f, "La planta de mamá. Esa flor tiene muchos pétalos."))
        o.add(ex("ex_hall_shoes", 388f, 44f, "Los zapatos de mamá casi no se mueven de aquí."))
        o.add(ex("ex_hall_mirror", 520f, 34f, "El espejo del pasillo siempre está sucio."))
        o.add(ex("ex_hall_house_drawing", 650f, 44f, "Dibujé nuestra casa. La persona de la ventana me salió muy alta."))
        o.add(ex("ex_hall_frames", 776f, 70f, "Fotos chiquitas. Mamá sonreía más en esas."))
        o.add(ex("ex_hall_end", 902f, 22f, "Al fondo está oscuro. La bodega me da miedito."))

        val doors = ArrayList<Door>()
        val spawns = HashMap<String, SpawnPoint>()
        for (r in ROOMS) {
            doors.add(hallDoor(r))
            spawns[fromSpawn(r)] = hallSpawn(r)
        }
        return RoomSegment(
            id = HALL, width = HALL_WIDTH, floorY = F,
            leftBoundary = WALL, rightBoundary = HALL_WIDTH - WALL,
            cameraMode = CameraMode.SIDE_SCROLLING,
            objects = o, doors = doors, spawnPoints = spawns,
            lights = listOf(
                lampA.light, lampB.light, lampC.light, lampD.light,
                LightSource(418f, 62f, 72f, PALE, 0.3f, LightType.AMBIENT_SPOT, tintStrength = 0.5f)
            ),
            darkZones = listOf(DarkZone(770f, 0f, 96f, F, 0.35f), DarkZone(930f, 0f, 20f, F, 0.4f)),
            ambientDark = 0.86f, ambientColor = Palette.DARK_ZONE,
            wallColor = 0xFFD9CDB0.toInt(), wallStrokeColor = 0xFFB0A284.toInt(),
            floorColor = 0xFF8A6A48.toInt(), floorStrokeColor = 0xFF5E4630.toInt(),
            wallPattern = WallPattern.STRIPES, wallAccent = 0xFF9A8CB4.toInt(),
            floorPattern = FloorPattern.WOOD, floorAccent = 0xFF4A3322.toInt()
        )
    }

    // ------------------------------------------------------------------ HABITACIÓN DEL NIÑO (inicio del juego)

    private fun kidRoom(): RoomSegment {
        val o = ArrayList<WorldObject>()
        val lamp = Lamp(196f, 36f, radius = 138f, intensity = 1f, color = WARM)
        o.add(HouseProps.rug(104f, 130f, Cr.BLUE, Cr.DBLUE))
        o.add(HouseProps.doorSign(29f, 48f, 0))
        o.add(HouseProps.kidDrawing(104f, 40f, 40f, 34f, 0))
        o.add(HouseProps.windowFrame(262f, 34f, 44f, 50f, Cr.CORAL))
        o.add(HouseProps.poster(322f, 36f, 34f, 40f))
        o.add(HouseProps.bookshelf(372f, 34f, 46f))
        o.add(lamp)
        o.add(HouseProps.kidBed(150f, Cr.BLUE))
        o.add(HouseProps.toyChest(248f))
        o.add(HouseProps.toyBlocks(290f))
        o.add(HouseProps.smallTable(330f))
        val plush = PlushFrog(PLUSH, 112f, F)
        o.add(plush)
        o.add(Wardrobe(
            WARDROBE_KID, 374f, F,
            WardrobeStyle(
                Palette.WARDROBE_WARM_BODY, Palette.WARDROBE_WARM_HATCH, Palette.WARDROBE_WARM_DOOR,
                WARDROBE_FRAME, doorCount = 2, deco = WardrobeDeco.STAR
            )
        ))
        o.add(ex("ex_kid_drawing", 104f, 40f, "Ese dibujo lo hice yo. Somos mamá y yo."))
        o.add(ScriptedSpot(
            SPOT_KID_BED, 150f, F - 46f, 92f, 46f, "EXAMINAR", InteractionIcon.EXAMINE, 6f,
            // v0.7: el peluche ya no se sostiene en las manos (va al COMPANION SLOT), así que esta rama de "DEJAR" queda
            // inactiva a propósito; se conserva intacta por si un futuro objeto-compañero vuelve a las manos.
            promptProvider = { ctx -> if (ctx.inventory.isHolding(ItemRegistry.FROG_PLUSH)) "DEJAR" else "EXAMINAR" },
            iconProvider = { ctx -> if (ctx.inventory.isHolding(ItemRegistry.FROG_PLUSH)) InteractionIcon.GIVE else InteractionIcon.EXAMINE }
        ) { ctx ->
            if (ctx.inventory.isHolding(ItemRegistry.FROG_PLUSH)) {
                InteractionResult.give(ItemRegistry.FROG_PLUSH) { c ->
                    plush.placeAt(172f, 104f)
                    c.post(EventType.ON_ITEM_PLACED, ItemRegistry.FROG_PLUSH)
                    InteractionResult.message("Ranita se ve bien en mi cama.")
                }
            } else {
                InteractionResult.message("Mi cama. Todavía está calentita.")
            }
        })
        o.add(ex("ex_kid_window", 262f, 44f, "Ya es de noche. No se ve ninguna estrella."))
        o.add(ex("ex_kid_chest", 248f, 40f, "Mi caja de juguetes. Ese osito ya está viejo."))
        return RoomSegment(
            id = KID, width = 440f, floorY = F,
            leftBoundary = WALL, rightBoundary = 440f - WALL,
            cameraMode = CameraMode.SIDE_SCROLLING,
            objects = o, doors = listOf(backDoor(KID)),
            spawnPoints = mapOf("start" to SpawnPoint(80f, 1), "from_hall" to SpawnPoint(81f, 1)),
            lights = listOf(
                lamp.light,
                LightSource(350f, 100f, 56f, WARM, 0.55f, LightType.LAMP),
                LightSource(284f, 60f, 72f, PALE, 0.32f, LightType.AMBIENT_SPOT, tintStrength = 0.5f)
            ),
            darkZones = listOf(DarkZone(396f, 0f, 32f, F, 0.3f)),
            ambientDark = 0.76f, ambientColor = Palette.DARK_WARM,
            wallColor = 0xFFF2E3A6.toInt(), wallStrokeColor = 0xFFD9C77A.toInt(),
            floorColor = 0xFFC9A06A.toInt(), floorStrokeColor = 0xFF9A7242.toInt(),
            wallPattern = WallPattern.STRIPES, wallAccent = 0xFF7FB6E8.toInt(),
            floorPattern = FloorPattern.WOOD, floorAccent = 0xFF6B4A2A.toInt()
        )
    }

    // ------------------------------------------------------------------ BAÑO (pequeño, luz blanca/fría)

    private fun bathroom(): RoomSegment {
        val o = ArrayList<WorldObject>()
        val lamp = Lamp(150f, 30f, radius = 124f, intensity = 1f, color = PALE)
        o.add(HouseProps.mirror(100f, 40f, 36f, 46f))
        o.add(HouseProps.medCabinet(150f, 44f))
        o.add(HouseProps.towelRack(190f, 48f))
        o.add(lamp)
        o.add(HouseProps.bathSink(96f))
        o.add(HouseProps.toilet(150f))
        o.add(HouseProps.bathtub(204f, 82f))
        o.add(ex("ex_bath_mirror", 98f, 40f, "No me gusta ese espejo."))
        o.add(ex("ex_bath_medcab", 150f, 30f, "El botiquín de mamá. Yo no lo alcanzo."))
        o.add(ex("ex_bath_towels", 190f, 24f, "Toallas con florecitas."))
        o.add(ex("ex_bath_tub", 210f, 74f, "Hay un patito en la bañera. Siempre se está riendo."))
        return RoomSegment(
            id = BATH, width = 320f, floorY = F,
            leftBoundary = WALL, rightBoundary = 320f - WALL,
            cameraMode = CameraMode.FIXED,
            objects = o, doors = listOf(backDoor(BATH)),
            spawnPoints = mapOf("from_hall" to SpawnPoint(81f, 1)),
            lights = listOf(lamp.light),
            darkZones = listOf(DarkZone(262f, 0f, 38f, F, 0.3f)),
            ambientDark = 0.72f, ambientColor = Palette.DARK_COLD,
            wallColor = 0xFFDDEBEF.toInt(), wallStrokeColor = 0xFFB5CAD2.toInt(),
            floorColor = 0xFFC9D6DA.toInt(), floorStrokeColor = 0xFFA5B8BE.toInt(),
            wallPattern = WallPattern.TILES, wallAccent = 0xFF8FB3C2.toInt(),
            floorPattern = FloorPattern.TILES, floorAccent = 0xFF7E96A0.toInt()
        )
    }

    // ------------------------------------------------------------------ HABITACIÓN DE MAMÁ

    private fun momRoom(): RoomSegment {
        val o = ArrayList<WorldObject>()
        val blanket = 0xFFB59AC9.toInt()
        o.add(HouseProps.doorSign(29f, 48f, 2))
        o.add(HouseProps.photoFrame(78f, 44f, 24f, 20f, 0))
        o.add(HouseProps.photoFrame(106f, 42f, 24f, 22f, 2))
        o.add(HouseProps.frogPoster(212f, 30f, 36f, 44f))
        o.add(HouseProps.medShelf(322f, 54f, 46f))
        o.add(HouseProps.dresser(76f, 50f))
        o.add(HouseProps.bigBed(140f, blanket))
        o.add(HouseProps.momFigure(152f, 100f, blanket))
        o.add(HouseProps.nightstand(262f))
        o.add(WorldPickup(PICKUP_BLUE, ItemRegistry.PILL_BOX_BLUE, 278f, 101f, 8f, 11f,
            "La cajita azul. Esas son las de la mañana.", 3f,
            { c -> c.setFlag(StoryFlags.SAW_PILLS); c.setFlag(StoryFlags.GOT_PILLS) }
        , { c -> !c.hasFlag(StoryFlags.INTRO_DONE) }))
        o.add(WorldPickup(PICKUP_ORANGE, ItemRegistry.PILL_BOX_ORANGE, 288f, 101f, 8f, 11f,
            "La naranja. Esa sabe horrible.", 3f,
            { c -> c.setFlag(StoryFlags.SAW_PILLS) }
        , { c -> !c.hasFlag(StoryFlags.INTRO_DONE) }))
        o.add(WorldPickup(PICKUP_WHITE, ItemRegistry.PILL_BOX_WHITE, 298f, 101f, 8f, 11f,
            "La blanca. No sé para qué es.", 3f,
            { c -> c.setFlag(StoryFlags.SAW_PILLS) }
        , { c -> !c.hasFlag(StoryFlags.INTRO_DONE) }))
        o.add(Wardrobe(
            WARDROBE_MOM, 376f, F,
            WardrobeStyle(
                Palette.WARDROBE_PLUM_BODY, Palette.WARDROBE_PLUM_HATCH, Palette.WARDROBE_PLUM_DOOR,
                WARDROBE_FRAME, doorCount = 2, deco = WardrobeDeco.MOON
            )
        ))
        o.add(ex("ex_mom_dresser", 76f, 24f, "Fotos de mamá y mías. En todas mamá sonríe."))
        o.add(HouseProps.paperSheet(104f, F - 55f, 15f, 10f, Cr.BLUE))
        o.add(ScriptedSpot(
            SPOT_DOC_MEDICAL, 101f, F - 56f, 25f, 56f, "LEER", InteractionIcon.EXAMINE, 4f
        ) { _ -> InteractionResult.document(Documents.MEDICAL) })
        // Puzzle de las cajas: disponible tras la introducción (primera persona sobre la mesita)
        o.add(ScriptedSpot(
            SPOT_PUZZLE, 262f, F - 64f, 54f, 64f, "ORDENAR", InteractionIcon.USE, 8f,
            enabledWhen = { ctx -> ctx.hasFlag(StoryFlags.INTRO_DONE) && !ctx.hasFlag(StoryFlags.MEDICINE_PUZZLE_DONE) }
        ) { ctx ->
            if (ctx.held != null) InteractionResult.message("Tengo las manos ocupadas.")
            else InteractionResult.puzzle()
        })
        o.add(ScriptedSpot(
            SPOT_TABLE_DONE, 262f, F - 64f, 54f, 64f, "EXAMINAR", InteractionIcon.EXAMINE, 8f,
            enabledWhen = { ctx -> ctx.hasFlag(StoryFlags.MEDICINE_PUZZLE_DONE) }
        ) { _ -> InteractionResult.message("Las cajitas están en su lugar. Mamá estará contenta.") })
        o.add(ScriptedSpot(
            SPOT_MOM, 140f, F - 56f, 92f, 56f, "HABLAR", InteractionIcon.TALK, 6f,
            promptProvider = { ctx ->
                val h = ctx.held
                when {
                    h == ItemRegistry.WATER_GLASS -> "DAR AGUA"
                    isPillBox(h) -> "DAR CAJA"
                    else -> "HABLAR"
                }
            },
            iconProvider = { ctx -> if (ctx.held != null) InteractionIcon.GIVE else InteractionIcon.TALK }
        ) { ctx -> momTalk(ctx) })
        o.add(ex("ex_mom_poster", 212f, 36f, "La rana de la farmacia. Siempre se está riendo."))
        o.add(ex("ex_mom_shelf", 322f, 46f, "Más cajitas. Mamá sabe cuál es cuál."))
        return RoomSegment(
            id = MOM, width = 440f, floorY = F,
            leftBoundary = WALL, rightBoundary = 440f - WALL,
            cameraMode = CameraMode.SIDE_SCROLLING,
            objects = o, doors = listOf(backDoor(MOM)),
            spawnPoints = mapOf("from_hall" to SpawnPoint(81f, 1)),
            lights = listOf(
                LightSource(276f, 100f, 96f, WARM, 0.85f, LightType.LAMP),
                LightSource(70f, 56f, 56f, WARM, 0.3f, LightType.LAMP)
            ),
            darkZones = listOf(DarkZone(384f, 0f, 44f, F, 0.3f), DarkZone(12f, 0f, 40f, F, 0.2f)),
            ambientDark = 0.88f, ambientColor = Palette.DARK_ZONE,
            wallColor = 0xFFC8B4C0.toInt(), wallStrokeColor = 0xFF9D8896.toInt(),
            floorColor = 0xFF8E6A4E.toInt(), floorStrokeColor = 0xFF6A4A34.toInt(),
            wallPattern = WallPattern.DOTS, wallAccent = 0xFF8A6A82.toInt(),
            floorPattern = FloorPattern.WOOD, floorAccent = 0xFF4A3022.toInt()
        )
    }

    /** Conversación y entregas con mamá: agua primero, luego la cajita azul. */
    private fun momTalk(ctx: com.terror2d.interaction.InteractionContext): InteractionResult {
        val s = ctx.state.story
        val h = ctx.held
        if (h == ItemRegistry.WATER_GLASS) {
            if (s.has(StoryFlags.WATER_DELIVERED)) return InteractionResult.message("Mamá ya tiene su agua.")
            return InteractionResult.give(ItemRegistry.WATER_GLASS) { c ->
                c.setFlag(StoryFlags.WATER_DELIVERED)
                c.setFlag(StoryFlags.PILLS_REQUESTED)
                InteractionResult.dialogue(listOf(
                    DialogueLine("MAMÁ", "Gracias, mi vida. Qué bien me cuidas."),
                    DialogueLine("MAMÁ", "Ahora la cajita azul, la de la mañana. Está en la mesita.")
                ))
            }
        }
        if (isPillBox(h)) {
            if (s.has(StoryFlags.INTRO_DONE)) return InteractionResult.message("Mamá ya tomó sus pastillas.")
            if (!s.has(StoryFlags.PILLS_REQUESTED)) return InteractionResult.message("Mamá todavía no me pidió esa caja.")
            if (h != ItemRegistry.PILL_BOX_BLUE) return InteractionResult.message("Esa no, cariño. La azul.", "MAMÁ")
            return InteractionResult.give(ItemRegistry.PILL_BOX_BLUE) { c ->
                c.setFlag(StoryFlags.PILLS_DELIVERED)
                c.setFlag(StoryFlags.TALKED_TO_MOM)
                c.setFlag(StoryFlags.INTRO_DONE)
                // mamá deja la cajita en la mesita otra vez (el puzzle usará las tres)
                for (obj in c.segment.objects) {
                    if (obj is WorldPickup && obj.itemId == ItemRegistry.PILL_BOX_BLUE) obj.reset()
                }
                InteractionResult.dialogue(listOf(
                    DialogueLine("MAMÁ", "Gracias, mi amor."),
                    DialogueLine(null, "Estas cosas saben feo."),
                    DialogueLine(null, "No sé por qué mamá toma tantas.")
                ))
            }
        }
        return when {
            s.has(StoryFlags.INTRO_DONE) -> InteractionResult.message("Mamá se quedó dormidita. Mejor no la despierto.")
            s.has(StoryFlags.PILLS_REQUESTED) -> InteractionResult.dialogue(listOf(
                DialogueLine("MAMÁ", "La cajita azul, cariño. Está en la mesita.")
            ))
            else -> InteractionResult.dialogue(listOf(
                DialogueLine("MAMÁ", "Cariño, ¿trajiste el agua?"),
                DialogueLine(null, "Todavía no, mamá. Ya voy.")
            ))
        }
    }

    // ------------------------------------------------------------------ LAVANDERÍA (estrecha, luz fría artificial)

    private fun laundry(): RoomSegment {
        val o = ArrayList<WorldObject>()
        val lamp = Lamp(150f, 40f, radius = 112f, intensity = 0.95f, color = PALE, flicker = 0.04f)
        o.add(HouseProps.clothesLine(92f, 30f, 150f))
        o.add(HouseProps.handprint(64f, 58f, Cr.BLUE, 5))
        o.add(HouseProps.handprint(84f, 54f, Cr.RED, 6))
        o.add(HouseProps.laundryShelf(196f, 44f, 42f))
        o.add(lamp)
        o.add(HouseProps.washer(98f))
        o.add(HouseProps.basket(152f))
        o.add(Wardrobe(
            WARDROBE_LAUNDRY, 242f, F,
            WardrobeStyle(
                Palette.WARDROBE_GREEN_BODY, Palette.WARDROBE_GREEN_HATCH, Palette.WARDROBE_GREEN_DOOR,
                WARDROBE_FRAME, doorCount = 1, deco = WardrobeDeco.STRIPES
            )
        ))
        o.add(ex("ex_laundry_hands", 60f, 44f, "Esas manos son mías. Me quedaron torcidas."))
        o.add(ex("ex_laundry_washer", 98f, 46f, "La lavadora hace mucho ruido."))
        o.add(ex("ex_laundry_basket", 152f, 36f, "Ropa sucia. Hay una camisa mía."))
        o.add(ex("ex_laundry_shelf", 196f, 42f, "El detergente huele a limón."))
        return RoomSegment(
            id = LAUNDRY, width = 320f, floorY = F,
            leftBoundary = WALL, rightBoundary = 320f - WALL,
            cameraMode = CameraMode.FIXED,
            objects = o, doors = listOf(backDoor(LAUNDRY)),
            spawnPoints = mapOf("from_hall" to SpawnPoint(81f, 1)),
            lights = listOf(lamp.light),
            darkZones = listOf(DarkZone(236f, 0f, 52f, F, 0.3f)),
            ambientDark = 0.8f, ambientColor = Palette.DARK_COLD,
            wallColor = 0xFFC5D0C8.toInt(), wallStrokeColor = 0xFF9FAFA6.toInt(),
            floorColor = 0xFFA9A8A4.toInt(), floorStrokeColor = 0xFF858480.toInt(),
            wallPattern = WallPattern.DOTS, wallAccent = 0xFF7E9C94.toInt(),
            floorPattern = FloorPattern.CONCRETE, floorAccent = 0xFF6A6964.toInt()
        )
    }

    // ------------------------------------------------------------------ COCINA (cálida, usada todos los días)

    private fun kitchen(): RoomSegment {
        val o = ArrayList<WorldObject>()
        val lampA = Lamp(170f, 34f, radius = 142f, intensity = 1f, color = WARM)
        val lampB = Lamp(342f, 38f, radius = 120f, intensity = 0.9f, color = WARM)
        o.add(HouseProps.rug(300f, 92f, Cr.MINT, Cr.TEAL))
        o.add(HouseProps.doorSign(29f, 48f, 4))
        o.add(HouseProps.wallCabinet(130f, 36f, 60f))
        o.add(HouseProps.hangingPots(198f, 36f))
        o.add(HouseProps.calendar(284f, 44f))
        o.add(HouseProps.kidDrawing(392f, 40f, 34f, 30f, 0))
        o.add(lampA)
        o.add(lampB)
        o.add(HouseProps.fridge(76f))
        o.add(HouseProps.counterSink(124f, 96f))
        o.add(HouseProps.stove(232f))
        o.add(HouseProps.chair(284f, Cr.BLUE))
        o.add(HouseProps.kitchenTable(304f))
        o.add(HouseProps.chair(388f, Cr.GREEN))
        o.add(ex("ex_kitchen_fridge", 76f, 38f, "Mamá pone mis dibujos en el refri."))
        o.add(ex("ex_kitchen_glasses", 124f, 32f, "Cinco vasos. Todos iguales."))
        o.add(ScriptedSpot(
            SPOT_SINK, 160f, F - 60f, 44f, 60f, "USAR", InteractionIcon.USE, 6f,
            promptProvider = { ctx -> if (ctx.hasFlag(StoryFlags.HEARD_WATER) && !ctx.hasFlag(StoryFlags.GOT_WATER)) "TOMAR AGUA" else "USAR" },
            iconProvider = { ctx -> if (ctx.hasFlag(StoryFlags.HEARD_WATER) && !ctx.hasFlag(StoryFlags.GOT_WATER)) InteractionIcon.PICK else InteractionIcon.USE }
        ) { ctx ->
            when {
                ctx.hasFlag(StoryFlags.WATER_DELIVERED) -> InteractionResult.message("Ya le llevé agua a mamá.")
                ctx.hasFlag(StoryFlags.GOT_WATER) -> InteractionResult.message("Ya tengo el vaso con agua para mamá.")
                !ctx.hasFlag(StoryFlags.HEARD_WATER) -> InteractionResult.message("El grifo gotea. Plic, plic.")
                ctx.held != null -> InteractionResult.message("Tengo las manos ocupadas.")
                else -> InteractionResult.pickup(ItemRegistry.WATER_GLASS) { c ->
                    c.setFlag(StoryFlags.GOT_WATER)
                    InteractionResult.message("Lleno un vaso con agua. No lo derramo.")
                }
            }
        })
        o.add(ex("ex_kitchen_stove", 232f, 40f, "La estufa. Mamá dice que no la toque."))
        o.add(ex("ex_kitchen_calendar", 280f, 26f, "Mamá marca los días con rojo."))
        o.add(ex("ex_kitchen_table", 308f, 50f, "Mamá puso tres platos. A veces se equivoca."))
        o.add(HouseProps.paperSheet(366f, F - 33f, 16f, 11f, Cr.RED))
        o.add(ScriptedSpot(
            SPOT_DOC_FINANCE, 360f, F - 46f, 32f, 46f, "LEER", InteractionIcon.EXAMINE, 4f
        ) { _ -> InteractionResult.document(Documents.FINANCE) })
        o.add(ex("ex_kitchen_drawing", 392f, 34f, "Ese también lo hice yo."))
        return RoomSegment(
            id = KITCHEN, width = 440f, floorY = F,
            leftBoundary = WALL, rightBoundary = 440f - WALL,
            cameraMode = CameraMode.SIDE_SCROLLING,
            objects = o, doors = listOf(backDoor(KITCHEN)),
            spawnPoints = mapOf("from_hall" to SpawnPoint(81f, 1)),
            lights = listOf(lampA.light, lampB.light),
            darkZones = listOf(DarkZone(400f, 0f, 28f, F, 0.25f)),
            ambientDark = 0.70f, ambientColor = Palette.DARK_WARM,
            wallColor = 0xFFF4DDA0.toInt(), wallStrokeColor = 0xFFD7BA6A.toInt(),
            floorColor = 0xFFD8C8A0.toInt(), floorStrokeColor = 0xFFB4A276.toInt(),
            wallPattern = WallPattern.DOTS, wallAccent = 0xFFE88A5A.toInt(),
            floorPattern = FloorPattern.TILES, floorAccent = 0xFFB0603A.toInt()
        )
    }

    // ------------------------------------------------------------------ COMEDOR / SALA FAMILIAR

    private fun dining(): RoomSegment {
        val o = ArrayList<WorldObject>()
        val lamp = Lamp(210f, 40f, radius = 132f, intensity = 0.82f, color = WARM)
        o.add(HouseProps.rug(140f, 150f, Cr.RED, Cr.CORAL))
        o.add(HouseProps.doorSign(29f, 48f, 5))
        o.add(HouseProps.garland(150f, 14f, 180f))
        o.add(HouseProps.kidDrawing(96f, 38f, 44f, 38f, 0))
        o.add(HouseProps.photoFrame(314f, 44f, 26f, 22f, 0))
        o.add(HouseProps.photoFrame(346f, 42f, 26f, 22f, 2))
        o.add(lamp)
        o.add(HouseProps.chair(132f, Cr.CORAL))
        o.add(HouseProps.diningTable(150f, 120f))
        o.add(HouseProps.chair(268f, Cr.CORAL))
        o.add(HouseProps.balloon(284f, 58f))
        o.add(HouseProps.sideboard(310f, 70f))
        o.add(HouseProps.plant(396f))
        o.add(ex("ex_dining_drawing", 96f, 44f, "Mamá lo puso aquí para que todos lo vean."))
        o.add(ex("ex_dining_table", 150f, 118f, "Aquí cenamos mamá y yo. Antes había más ruido."))
        o.add(ex("ex_dining_balloon", 280f, 24f, "El globo de mi cumpleaños. Ya se está haciendo chiquito."))
        o.add(ex("ex_dining_photos", 312f, 70f, "Las fotos de mamá. Siempre las limpia con cuidado."))
        return RoomSegment(
            id = DINING, width = 440f, floorY = F,
            leftBoundary = WALL, rightBoundary = 440f - WALL,
            cameraMode = CameraMode.SIDE_SCROLLING,
            objects = o, doors = listOf(backDoor(DINING)),
            spawnPoints = mapOf("from_hall" to SpawnPoint(81f, 1)),
            lights = listOf(lamp.light, LightSource(346f, 70f, 80f, WARM, 0.45f, LightType.LAMP)),
            darkZones = listOf(DarkZone(396f, 0f, 32f, F, 0.3f)),
            ambientDark = 0.80f, ambientColor = Palette.DARK_WARM,
            wallColor = 0xFFE9C9B0.toInt(), wallStrokeColor = 0xFFC9A184.toInt(),
            floorColor = 0xFFB07848.toInt(), floorStrokeColor = 0xFF8A5C32.toInt(),
            wallPattern = WallPattern.FLOWERS, wallAccent = 0xFFFFF0F0.toInt(),
            floorPattern = FloorPattern.WOOD, floorAccent = 0xFF5A3A22.toInt()
        )
    }

    // ------------------------------------------------------------------ BODEGA (la más oscura)

    private fun cellar(): RoomSegment {
        val o = ArrayList<WorldObject>()
        val lamp = Lamp(210f, 60f, radius = 84f, intensity = 0.85f, color = WARM, flicker = 0.1f)
        o.add(HouseProps.toolWall(236f, 36f, 44f))
        o.add(lamp)
        o.add(HouseProps.crateStack(90f))
        o.add(HouseProps.coveredFurniture(160f, 60f, 56f))
        o.add(HouseProps.barrel(262f))
        o.add(HouseProps.oldDoll(300f))
        o.add(Wardrobe(
            WARDROBE_CELLAR, 340f, F,
            WardrobeStyle(
                Palette.WARDROBE_COLD_BODY, Palette.WARDROBE_COLD_HATCH, Palette.WARDROBE_COLD_DOOR,
                WARDROBE_FRAME, doorCount = 1, deco = WardrobeDeco.MOON
            )
        ))
        o.add(ex("ex_cellar_crates", 90f, 60f, "Cajas viejas. Huelen a polvo."))
        o.add(ex("ex_cellar_sheet", 160f, 60f, "Un mueble tapado con una sábana. Me da cosa."))
        o.add(ex("ex_cellar_tools", 236f, 44f, "Las herramientas de la casa. No se tocan."))
        o.add(ex("ex_cellar_doll", 300f, 34f, "A esa muñeca le falta un ojo. Ya estaba así."))
        return RoomSegment(
            id = CELLAR, width = 400f, floorY = F,
            leftBoundary = WALL, rightBoundary = 400f - WALL,
            cameraMode = CameraMode.SIDE_SCROLLING,
            objects = o, doors = listOf(backDoor(CELLAR)),
            spawnPoints = mapOf("from_hall" to SpawnPoint(81f, 1)),
            lights = listOf(lamp.light, LightSource(60f, 70f, 52f, WARM, 0.35f, LightType.LAMP)),
            darkZones = listOf(DarkZone(120f, 0f, 40f, F, 0.35f), DarkZone(330f, 0f, 58f, F, 0.4f)),
            ambientDark = 0.94f, ambientColor = Palette.DARK_DEEP,
            wallColor = 0xFF6E6478.toInt(), wallStrokeColor = 0xFF4E4660.toInt(),
            floorColor = 0xFF57535F.toInt(), floorStrokeColor = 0xFF3E3A48.toInt(),
            wallPattern = WallPattern.PLANKS, wallAccent = 0xFF2E2840.toInt(),
            floorPattern = FloorPattern.CONCRETE, floorAccent = 0xFF2E2A38.toInt()
        )
    }
}
