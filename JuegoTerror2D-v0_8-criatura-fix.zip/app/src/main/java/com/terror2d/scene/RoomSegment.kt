package com.terror2d.scene

import com.terror2d.core.CameraMode
import com.terror2d.core.GameConfig
import com.terror2d.render.Palette
import com.terror2d.world.DarkZone
import com.terror2d.world.Door
import com.terror2d.world.LightSource
import com.terror2d.world.WorldObject

/** Dibujo de la pared (se genera con trazos de crayón en [com.terror2d.draw.BackdropBuilder]). */
enum class WallPattern { PLAIN, STRIPES, DOTS, FLOWERS, TILES, PLANKS }

/** Dibujo del suelo. */
enum class FloorPattern { WOOD, TILES, CONCRETE, CARPET }

/**
 * Un tramo lateral independiente (dormitorio, pasillo, cocina...). Una [SceneDefinition]
 * agrupa varios, conectados por [Door]s. Es solo DATOS: la lógica vive en [Scene].
 *
 * Sistema de coordenadas: X crece a la derecha, Y hacia abajo. El suelo está en [floorY]:
 * los pies del jugador y la base de los objetos se apoyan en esa línea.
 *
 * Iluminación (v0.3): [ambientDark] es lo OSCURA que está la habitación (0 = clara, 1 = negro total)
 * y [ambientColor] el color de esa oscuridad; las [lights] la abren localmente.
 * Los [objects] que implementan Interactable (armarios, interruptores, zonas examinables)
 * se registran solos; las [doors] también.
 */
class RoomSegment(
    val id: String,
    val width: Float,
    val floorY: Float,
    val height: Float = GameConfig.LOGICAL_HEIGHT.toFloat(),
    /** Límites horizontales del cuerpo del jugador. */
    val leftBoundary: Float = 0f,
    val rightBoundary: Float = width,
    val cameraMode: CameraMode = CameraMode.SIDE_SCROLLING,
    val objects: List<WorldObject> = emptyList(),
    val doors: List<Door> = emptyList(),
    val spawnPoints: Map<String, SpawnPoint>,
    // Iluminación (solo datos; el dibujo lo hace la capa de iluminación)
    val lights: List<LightSource> = emptyList(),
    val darkZones: List<DarkZone> = emptyList(),
    val ambientDark: Float = 0f,
    val ambientColor: Int = Palette.DARK_ZONE,
    // Aspecto
    val wallColor: Int = Palette.WALL_A,
    val wallStrokeColor: Int = Palette.WALL_A_STROKE,
    val floorColor: Int = Palette.FLOOR_WOOD,
    val floorStrokeColor: Int = Palette.FLOOR_WOOD_STROKE,
    val wallPattern: WallPattern = WallPattern.STRIPES,
    val wallAccent: Int = 0xFFFFFFFF.toInt(),
    val floorPattern: FloorPattern = FloorPattern.WOOD,
    val floorAccent: Int = 0xFF000000.toInt(),
    /** Mundo al que pertenece este segmento (v0.5: todos NORMAL). */
    val worldMode: com.terror2d.core.WorldMode = com.terror2d.core.WorldMode.NORMAL
) {
    fun spawn(spawnId: String): SpawnPoint =
        spawnPoints[spawnId] ?: throw IllegalArgumentException("Spawn no definido en $id: $spawnId")
}
