package com.terror2d.scene

import com.terror2d.world.Door
import com.terror2d.world.DoorTarget

/**
 * Transición entre segmentos con fases claras (v0.3, antes era un corte directo):
 *
 *   DOOR_OPENING (la hoja termina de abrirse) -> FADE_OUT (a negro) -> [carga del destino] -> FADE_IN
 *
 * Es solo la máquina de estados (sin Android). La escena la consulta: mientras [isActive] el jugador
 * no se mueve ni interactúa; en el instante en que [update] devuelve true debe cargar el destino.
 */
class SceneTransition {

    enum class Phase { NONE, DOOR_OPENING, FADE_OUT, FADE_IN }

    var phase: Phase = Phase.NONE
        private set

    var target: DoorTarget? = null
        private set

    private var door: Door? = null
    private var timer = 0f

    val isActive: Boolean get() = phase != Phase.NONE

    /** Opacidad del negro (0 = nada, 1 = pantalla negra). */
    val fadeAlpha: Float
        get() = when (phase) {
            Phase.FADE_OUT -> (timer / FADE_OUT_TIME).coerceIn(0f, 1f)
            Phase.FADE_IN -> (1f - timer / FADE_IN_TIME).coerceIn(0f, 1f)
            else -> 0f
        }

    fun start(newTarget: DoorTarget, openingDoor: Door?) {
        target = newTarget
        door = openingDoor
        timer = 0f
        phase = if (openingDoor != null) Phase.DOOR_OPENING else Phase.FADE_OUT
    }

    /** Avanza. Devuelve true UNA vez: justo cuando hay que cargar el segmento destino. */
    fun update(dt: Float): Boolean {
        var load = false
        if (phase == Phase.DOOR_OPENING) {
            val d = door
            if (d == null || d.openProgress >= 1f) {
                phase = Phase.FADE_OUT
                timer = 0f
            }
        } else if (phase == Phase.FADE_OUT) {
            timer += dt
            if (timer >= FADE_OUT_TIME) {
                phase = Phase.FADE_IN
                timer = 0f
                load = true
            }
        } else if (phase == Phase.FADE_IN) {
            timer += dt
            if (timer >= FADE_IN_TIME) {
                phase = Phase.NONE
                target = null
                door = null
            }
        }
        return load
    }

    companion object {
        const val FADE_OUT_TIME = 0.22f
        const val FADE_IN_TIME = 0.30f
    }
}
