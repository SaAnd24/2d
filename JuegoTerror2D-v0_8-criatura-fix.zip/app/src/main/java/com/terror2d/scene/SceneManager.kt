package com.terror2d.scene

import com.terror2d.core.GameState
import com.terror2d.input.InputController
import com.terror2d.render.WorldRenderer

/** Registro, carga y cambio de escenas. */
class SceneManager(private val state: GameState) {

    private val factories = HashMap<String, () -> Scene>()

    @Volatile
    var current: Scene? = null
        private set

    fun register(id: String, factory: () -> Scene) {
        factories[id] = factory
    }

    fun loadScene(id: String) {
        val factory = factories[id] ?: throw IllegalArgumentException("Escena no registrada: $id")
        val scene = factory()
        scene.load(state)
        current = scene
    }

    /** Descarga la actual y carga otra. Futuro: transiciones/fundidos. */
    fun changeScene(id: String) {
        current?.unload(state)
        loadScene(id)
    }

    fun update(dt: Float, input: InputController) {
        current?.update(dt, input, state)
    }

    fun render(renderer: WorldRenderer) {
        current?.render(renderer)
    }
}
