package com.terror2d.scene

/**
 * Cambio TEMPORAL de TERCERA PERSONA a PRIMERA PERSONA y de vuelta (puzzle de medicamentos, v0.6).
 *
 *   NONE (tercera persona) -> ENTERING (la cámara "se acerca" a los ojos del niño) -> ACTIVE (mesa vista desde sus ojos)
 *   -> LEAVING (se aleja) -> NONE
 *
 * Es solo la máquina de estados (sin Android): el renderer usa [blend] para hacer el acercamiento y fundir
 * entre el mundo lateral y la mesa; la escena la consulta para congelar al niño mientras dura.
 */
class FirstPersonView {

    enum class Phase { NONE, ENTERING, ACTIVE, LEAVING }

    var phase: Phase = Phase.NONE
        private set

    private var timer = 0f

    /** true en cualquier fase distinta de NONE (el jugador no se mueve y los botones se ocultan). */
    val isActive: Boolean get() = phase != Phase.NONE

    /** true solo mientras se puede jugar con las cajas. */
    val isPlayable: Boolean get() = phase == Phase.ACTIVE

    /** 0 = tercera persona, 1 = primera persona (suavizado). */
    val blend: Float
        get() = when (phase) {
            Phase.NONE -> 0f
            Phase.ENTERING -> smooth(timer / ENTER_TIME)
            Phase.ACTIVE -> 1f
            Phase.LEAVING -> 1f - smooth(timer / LEAVE_TIME)
        }

    fun begin() {
        if (phase != Phase.NONE) return
        phase = Phase.ENTERING
        timer = 0f
    }

    /** Empieza a volver a tercera persona (solo desde ACTIVE). */
    fun end() {
        if (phase != Phase.ACTIVE && phase != Phase.ENTERING) return
        phase = Phase.LEAVING
        timer = 0f
    }

    /** Avanza. Devuelve true UNA vez: justo cuando se completa el regreso a tercera persona. */
    fun update(dt: Float): Boolean {
        when (phase) {
            Phase.ENTERING -> {
                timer += dt
                if (timer >= ENTER_TIME) {
                    phase = Phase.ACTIVE
                    timer = 0f
                }
            }
            Phase.LEAVING -> {
                timer += dt
                if (timer >= LEAVE_TIME) {
                    phase = Phase.NONE
                    timer = 0f
                    return true
                }
            }
            else -> {}
        }
        return false
    }

    private fun smooth(t: Float): Float {
        val c = t.coerceIn(0f, 1f)
        return c * c * (3f - 2f * c)
    }

    companion object {
        const val ENTER_TIME = 0.75f
        const val LEAVE_TIME = 0.6f
    }
}
