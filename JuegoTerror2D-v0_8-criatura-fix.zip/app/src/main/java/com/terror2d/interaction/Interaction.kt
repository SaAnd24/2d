package com.terror2d.interaction

import com.terror2d.core.GameState
import com.terror2d.events.EventBus
import com.terror2d.events.EventType
import com.terror2d.inventory.Inventory
import com.terror2d.scene.RoomSegment
import com.terror2d.ui.DialogueLine
import com.terror2d.world.Door
import com.terror2d.world.DoorTarget
import com.terror2d.world.Player

/** Icono que muestra el botón de acción para el interactuable enfocado. */
enum class InteractionIcon { DOOR, HIDE, EXIT, EXAMINE, USE, NEXT, TALK, PICK, GIVE }

/**
 * Lo que un interactuable puede ver y tocar al ejecutarse. Una sola instancia reutilizada por la
 * escena (sin allocations por frame). Los objetos NO conocen la escena: solo este contexto.
 */
class InteractionContext(
    val events: EventBus,
    val state: GameState
) {
    lateinit var player: Player
    lateinit var segment: RoomSegment

    /** Segundos de juego (para animaciones). */
    var time: Float = 0f

    fun post(type: EventType, sourceId: String) {
        events.post(type, sourceId, segment.id)
    }

    /** Activa un hito narrativo; publica ON_STORY_FLAG la primera vez. */
    fun setFlag(flag: String): Boolean {
        val isNew = state.story.set(flag)
        if (isNew) events.post(EventType.ON_STORY_FLAG, flag, segment.id)
        return isNew
    }

    fun hasFlag(flag: String): Boolean = state.story.has(flag)

    /** Inventario del jugador (y objeto en las manos). */
    val inventory: Inventory get() = state.inventory

    /** Objeto que lleva en las manos (null = manos libres). */
    val held: String? get() = state.inventory.held
}

/** Tipo de animación del niño que acompaña a una interacción. */
enum class PlayerActionKind { PICKUP, GIVE }

/**
 * Petición de una acción con animación: el niño se agacha a recoger / extiende la mano para entregar y,
 * al terminar la animación, la escena actualiza el inventario y ejecuta [after] (texto, hitos...).
 */
class PlayerActionRequest(
    val kind: PlayerActionKind,
    val itemId: String,
    val after: ((InteractionContext) -> InteractionResult)? = null
)

/**
 * Resultado de ejecutar una interacción. La escena lo interpreta; el objeto solo describe qué
 * quiere que ocurra (mostrar texto, un diálogo, cambiar de habitación...).
 */
class InteractionResult private constructor(
    val handled: Boolean,
    val message: String? = null,
    val speaker: String? = null,
    val transition: DoorTarget? = null,
    val transitionDoor: Door? = null,
    val lines: List<DialogueLine>? = null,
    val action: PlayerActionRequest? = null,
    /** Id de un documento que hay que abrir para leerlo (v0.6). */
    val documentId: String? = null,
    /** true = empieza el puzzle de medicamentos (pasa a primera persona). */
    val startPuzzle: Boolean = false
) {
    val hasDocument: Boolean get() = documentId != null
    val hasMessage: Boolean get() = message != null
    val hasTransition: Boolean get() = transition != null
    val hasDialogue: Boolean get() = lines != null
    val hasAction: Boolean get() = action != null

    companion object {
        /** Nada ocurrió (p. ej. la puerta ya estaba abierta). */
        val IGNORED = InteractionResult(false)

        /** Ocurrió algo sin más consecuencias para la escena. */
        val DONE = InteractionResult(true)

        fun message(text: String, speaker: String? = null) =
            InteractionResult(true, text, speaker)

        fun transition(target: DoorTarget, door: Door? = null) =
            InteractionResult(true, null, null, target, door)

        /** Hace algo y además muestra un texto. */
        fun doneWithMessage(text: String) = InteractionResult(true, text)

        /** Inicia un diálogo de varias líneas (bloquea el movimiento hasta terminar). */
        fun dialogue(lines: List<DialogueLine>) = InteractionResult(true, null, null, null, null, lines)

        /** Abre un documento para leerlo (la escena muestra el papel y luego la reacción del niño). */
        fun document(id: String) = InteractionResult(true, documentId = id)

        /** Empieza el puzzle de medicamentos: tercera persona -> primera persona. */
        fun puzzle() = InteractionResult(true, startPuzzle = true)

        /** El niño recoge [itemId]: animación, luego el objeto entra al inventario y queda en sus manos. */
        fun pickup(itemId: String, after: ((InteractionContext) -> InteractionResult)? = null) =
            InteractionResult(true, null, null, null, null, null, PlayerActionRequest(PlayerActionKind.PICKUP, itemId, after))

        /** El niño entrega [itemId]: animación, luego el objeto sale del inventario. */
        fun give(itemId: String, after: ((InteractionContext) -> InteractionResult)? = null) =
            InteractionResult(true, null, null, null, null, null, PlayerActionRequest(PlayerActionKind.GIVE, itemId, after))
    }
}

/**
 * Cualquier cosa con la que el jugador puede actuar: puertas, armarios, muebles, interruptores,
 * notas, medicamentos, personajes... La escena detecta el más cercano, muestra su acción en el
 * botón y llama a [executeInteraction]. NUNCA hay lógica específica por tipo en el botón.
 */
interface Interactable {
    val interactionId: String

    /** Texto corto del botón de acción ("ABRIR", "ESCONDERSE"...). Puede depender del estado. */
    val promptText: String

    val promptIcon: InteractionIcon

    /** Zona horizontal (coordenadas del mundo) en la que el jugador puede actuar. */
    val zoneLeft: Float
    val zoneRight: Float

    /** Punto sobre el que se dibuja la marca de interacción (X centro, Y arriba). */
    val markerX: Float
    val markerY: Float

    /** Texto del botón según el estado actual (por defecto, [promptText]). */
    fun promptFor(ctx: InteractionContext): String = promptText

    /** Icono del botón según el estado actual (por defecto, [promptIcon]). */
    fun iconFor(ctx: InteractionContext): InteractionIcon = promptIcon

    /** true = el jugador puede usarlo estando escondido (solo el escondite del que sale). */
    val worksWhileHidden: Boolean get() = false

    /** ¿Se puede interactuar ahora mismo? (p. ej. un armario ocupado por otro no) */
    fun canInteract(ctx: InteractionContext): Boolean = true

    fun executeInteraction(ctx: InteractionContext): InteractionResult

    /** ¿Está el jugador dentro de la zona? */
    fun isInRange(p: Player): Boolean = p.right > zoneLeft && p.x < zoneRight
}
