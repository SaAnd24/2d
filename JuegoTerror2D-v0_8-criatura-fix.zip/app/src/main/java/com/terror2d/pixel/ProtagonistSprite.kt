package com.terror2d.pixel

/**
 * EL PROTAGONISTA (v0.6): un niño de 8 años en pixel art de 96x128 píxeles internos, de perfil mirando a la
 * derecha (el renderer lo voltea). Se dibuja a ESCALA 0.5: ocupa exactamente la misma silueta en pantalla que el
 * sprite de 48x64 de v0.5 (~50 px lógicos de alto), pero con el DOBLE de píxeles dentro de ella.
 *
 * Pelo castaño despeinado con mechones, suéter de lana naranja con línea roja, pantalón caqui, zapatos blancos,
 * bufanda rojo oscuro y una marca en la mejilla. 38 colores. Ojos y boca son parches intercambiables ([FaceLayer]):
 * abrir, cerrar, parpadear y cambiar de expresión.
 *
 * Los datos los genera `tools/sprite_gen` (Python) y viven en [SpriteData]; aquí solo se decodifican. Cada pose es
 * una matriz de índices de paleta; la mano delantera de las poses con objeto es una capa aparte (primer plano) para
 * que los dedos queden POR ENCIMA del objeto sostenido.
 */
object ProtagonistSprite {

    const val W = SpriteData.PROTAGONIST_W
    const val H = SpriteData.PROTAGONIST_H
    const val CX = SpriteData.PROTAGONIST_ANCHOR_X

    /** Lado lógico de un píxel del sprite: 0.5 => mismo tamaño en pantalla que el 48x64 anterior. */
    const val SCALE = 0.5f

    val PALETTE: IntArray = SpriteData.PROTAGONIST_PALETTE

    /** Paleta alternativa (recuerdos): los mismos datos en sepia desaturado. */
    val PALETTE_FLASHBACK: IntArray by lazy { sepia(PALETTE) }

    private fun sepia(src: IntArray): IntArray {
        val out = IntArray(src.size)
        for (i in src.indices) {
            val c = src[i]
            val a = (c ushr 24) and 0xFF
            if (a == 0) {
                out[i] = 0
                continue
            }
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            val gray = r * 0.30f + g * 0.59f + b * 0.11f
            val rr = (gray * 1.06f + 8f).toInt().coerceIn(0, 255)
            val gg = (gray * 0.94f + 6f).toInt().coerceIn(0, 255)
            val bb = (gray * 0.76f + 4f).toInt().coerceIn(0, 255)
            out[i] = (a shl 24) or (rr shl 16) or (gg shl 8) or bb
        }
        return out
    }

    fun create(): PixelCharacterData {
        val n = PixelPose.values().size
        val size = W * H
        val frames = arrayOfNulls<IntArray>(n)
        val front = arrayOfNulls<IntArray>(n)
        val hands = arrayOfNulls<IntArray>(n)
        val heads = arrayOfNulls<IntArray>(n)
        for (pose in PixelPose.values()) {
            val i = pose.ordinal
            frames[i] = SpriteCodec.decode(SpriteData.PROTAGONIST_BASE[i], size)
            val f = SpriteData.PROTAGONIST_FRONT[i]
            if (f.isNotEmpty()) front[i] = SpriteCodec.decode(f, size)
            val hp = SpriteData.PROTAGONIST_HAND[i]
            if (hp.size == 2) hands[i] = intArrayOf(hp[0] - CX, hp[1] - H)
            heads[i] = SpriteData.PROTAGONIST_HEAD[i]
        }
        val eyes = Array(EyeState.values().size) { k ->
            val m = SpriteData.EYE_META[k]
            PixelPatch(m[0], m[1], m[2], m[3], SpriteCodec.decode(SpriteData.EYE_DATA[k], m[0] * m[1]))
        }
        val mouths = Array(MouthState.values().size) { k ->
            val m = SpriteData.MOUTH_META[k]
            PixelPatch(m[0], m[1], m[2], m[3], SpriteCodec.decode(SpriteData.MOUTH_DATA[k], m[0] * m[1]))
        }
        return PixelCharacterData(
            "protagonista", W, H, PALETTE, frames, CX, hands, SCALE, front,
            FaceLayer(eyes, mouths, heads)
        )
    }
}

/**
 * Objetos pixelados con ESCALA CANÓNICA ÚNICA (1 píxel = 0.5 px lógicos, como el protagonista). Un solo dibujo por
 * objeto: suelo, cama, mano, inventario, HOLD_ITEM y PLACED usan exactamente el mismo sprite.
 *
 *   ranita 32x32 (16x16 lógicos) · caja de medicinas 16x22 (8x11) · vaso 14x22 (7x11)
 */
object ItemSprites {
    const val SCALE = 0.5f

    private val cache = HashMap<String, PixelCharacterData>()

    fun has(id: String): Boolean = SpriteData.ITEM_IDS.contains(id)

    /** Sprite del objeto (null si no tiene dibujo). */
    fun get(id: String): PixelCharacterData? {
        val c = cache[id]
        if (c != null) return c
        val k = SpriteData.ITEM_IDS.indexOf(id)
        if (k < 0) return null
        val m = SpriteData.ITEM_META[k]
        val w = m[0]
        val h = m[1]
        val frames = arrayOfNulls<IntArray>(PixelPose.values().size)
        frames[PixelPose.IDLE.ordinal] = SpriteCodec.decode(SpriteData.ITEM_DATA[k], w * h)
        val d = PixelCharacterData(id, w, h, SpriteData.ITEM_PALETTES[k], frames, w / 2, scale = SCALE, gripX = m[2], gripY = m[3])
        cache[id] = d
        return d
    }

    /** Tamaño lógico (ancho, alto) del objeto en pantalla. */
    fun logicalWidth(id: String): Float = (get(id)?.width ?: 0) * SCALE

    fun logicalHeight(id: String): Float = (get(id)?.height ?: 0) * SCALE
}

/** Manos del niño en PRIMERA PERSONA (puzzle): REST (apoyada), GRAB (agarrando) y POINT (señalando). 72x80 a escala 0.5. */
object FirstPersonHands {
    const val REST = 0
    const val GRAB = 1
    const val POINT = 2

    private val cache = arrayOfNulls<PixelCharacterData>(3)

    fun get(kind: Int): PixelCharacterData {
        val c = cache[kind]
        if (c != null) return c
        val frames = arrayOfNulls<IntArray>(PixelPose.values().size)
        frames[PixelPose.IDLE.ordinal] = SpriteCodec.decode(SpriteData.HAND_DATA[kind], SpriteData.HANDS_W * SpriteData.HANDS_H)
        val d = PixelCharacterData("mano_" + SpriteData.HAND_KINDS[kind], SpriteData.HANDS_W, SpriteData.HANDS_H,
            SpriteData.PROTAGONIST_PALETTE, frames, 34, scale = ProtagonistSprite.SCALE)
        cache[kind] = d
        return d
    }
}
