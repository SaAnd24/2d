package com.terror2d.pixel

import kotlin.math.abs

/**
 * LA CRIATURA (v0.8, rediseño) en pixel art. USA LA MISMA DENSIDAD QUE EL NIÑO: [SCALE] es exactamente la escala del
 * protagonista (1 píxel de sprite = 0,5 px lógicos). No se parece en nada a la escena de Ranita en primera
 * persona (640×360): ahí un píxel de arte mide 0,5 px lógicos pero el dibujo es ~30 veces más detallado en un
 * encuadre cercano; aquí la criatura es mucho más grande (160×176) pero cada píxel pesa lo mismo que los del niño.
 *
 * Datos: [CreatureSpriteData] (generado por tools/sprite_gen/creature.py con el motor pixelado procedural; la app NO
 * contiene ninguna imagen de la criatura). Capas: brazo trasero, cuerpo (una pose por frame de la caminata), cabeza
 * (2 variantes), ojos, boca principal (sonrisa) y las 7 bocas del vientre, cada una con su parche y sus 4 estados,
 * para que se animen por separado sin redibujar la criatura. Brazo delantero al final.
 */
object CreatureSprite {
    const val SCALE = ProtagonistSprite.SCALE
    const val BODY_W = CreatureSpriteData.BODY_W
    const val BODY_H = CreatureSpriteData.BODY_H
    /** Columna del cuerpo que cae sobre el centro de la criatura (la cadera). */
    const val ANCHOR_X = CreatureSpriteData.ANCHOR_X
    val SECONDARY_MOUTHS: Int = CreatureSpriteData.HEAD_MOUTHS.size + CreatureSpriteData.TORSO_MOUTHS.size

    val PALETTE: IntArray = CreatureSpriteData.PALETTE

    val bodies: Array<IntArray> by lazy { Array(CreatureSpriteData.BODY_DATA.size) { joinStrays(bridgeGaps(SpriteCodec.decode(CreatureSpriteData.BODY_DATA[it], BODY_W * BODY_H), BODY_W, BODY_H), BODY_W, BODY_H) } }

    /** Brazos recortados: índice = balanceo * ARM_BEND.size + codo (ver [armIndex]). */
    val armLead: Array<IntArray> by lazy { decodeArms(CreatureSpriteData.ARM_LEAD, CreatureSpriteData.ARM_LEAD_INFO) }
    val armTrail: Array<IntArray> by lazy { decodeArms(CreatureSpriteData.ARM_TRAIL, CreatureSpriteData.ARM_TRAIL_INFO) }

    private fun decodeArms(data: Array<String>, info: Array<IntArray>): Array<IntArray> =
        Array(data.size) { fillNotches(bridgeGaps(SpriteCodec.decode(data[it], info[it][0] * info[it][1]), info[it][0], info[it][1]), info[it][0], info[it][1]) }

    /** Rótula del hombro: disco de piel (radio [SHOULDER_R]) que une cada brazo con el torso en cualquier ángulo. */
    const val SHOULDER_R = 7
    const val SHOULDER_D = SHOULDER_R * 2 + 1
    val shoulderJoint: IntArray by lazy {
        IntArray(SHOULDER_D * SHOULDER_D) { i ->
            val dx = i % SHOULDER_D - SHOULDER_R; val dy = i / SHOULDER_D - SHOULDER_R
            if (dx * dx + dy * dy <= SHOULDER_R * SHOULDER_R) 23 else PixelIndex.TRANSPARENT
        }
    }

    /** Rellena grietas estrechas dentro de cada pieza (píxel vacío con material sólido a ambos lados a menos de GAP_R). */
    fun bridgeGaps(src: IntArray, w: Int, h: Int): IntArray {
        val out = src.copyOf()
        val dirs = arrayOf(intArrayOf(1, 0), intArrayOf(0, 1), intArrayOf(1, 1), intArrayOf(1, -1))
        for (y in 0 until h) for (x in 0 until w) {
            if (src[y * w + x] != PixelIndex.TRANSPARENT) continue
            for (d in dirs) {
                var a = 0; var b = 0
                for (k in 1..GAP_R) { val xx = x - d[0] * k; val yy = y - d[1] * k
                    if (xx in 0 until w && yy in 0 until h && src[yy * w + xx] != PixelIndex.TRANSPARENT) { a = src[yy * w + xx]; break } }
                if (a == 0) continue
                for (k in 1..GAP_R) { val xx = x + d[0] * k; val yy = y + d[1] * k
                    if (xx in 0 until w && yy in 0 until h && src[yy * w + xx] != PixelIndex.TRANSPARENT) { b = src[yy * w + xx]; break } }
                if (b != 0) { out[y * w + x] = a; break }
            }
        }
        return out
    }
    private const val GAP_R = 6

    /**
     * Piezas sueltas del cuerpo (rodillas, dedos, restos de pierna): cada trozo pequeño desconectado se une a la
     * silueta principal con un puente de 2 px de su mismo color, y los agujeritos de <= 6 px se rellenan.
     */
    fun joinStrays(src: IntArray, w: Int, h: Int): IntArray {
        val out = src.copyOf()
        val label = IntArray(w * h)
        val comps = ArrayList<IntArray>()
        val queue = IntArray(w * h)
        for (s0 in 0 until w * h) {
            if (out[s0] == PixelIndex.TRANSPARENT || label[s0] != 0) continue
            val id = comps.size + 1
            var qh = 0; var qt = 0
            queue[qt++] = s0; label[s0] = id
            while (qh < qt) {
                val c = queue[qh++]; val cx = c % w; val cy = c / w
                for (dy in -1..1) for (dx in -1..1) {
                    val xx = cx + dx; val yy = cy + dy
                    if (xx !in 0 until w || yy !in 0 until h) continue
                    val n = yy * w + xx
                    if (out[n] != PixelIndex.TRANSPARENT && label[n] == 0) { label[n] = id; queue[qt++] = n }
                }
            }
            comps.add(queue.copyOf(qt))
        }
        if (comps.size > 1) {
            val mainIdx = comps.indices.maxByOrNull { comps[it].size }!!
            val main = comps[mainIdx]
            for ((ci, cells) in comps.withIndex()) {
                if (ci == mainIdx || cells.size >= 80) continue
                var best = Int.MAX_VALUE; var from = 0; var to = 0
                for (a in cells) for (b in main) {
                    val dx = a % w - b % w; val dy = a / w - b / w; val d = dx * dx + dy * dy
                    if (d < best) { best = d; from = a; to = b }
                }
                if (best > 14 * 14) continue
                val col = out[from]
                val x0 = from % w; val y0 = from / w; val x1 = to % w; val y1 = to / w
                val steps = maxOf(abs(x1 - x0), abs(y1 - y0), 1)
                for (i in 0..steps) {
                    val px = x0 + (x1 - x0) * i / steps; val py = y0 + (y1 - y0) * i / steps
                    for ((ox, oy) in arrayOf(0 to 0, 1 to 0, 0 to 1)) {
                        val xx = px + ox; val yy = py + oy
                        if (xx in 0 until w && yy in 0 until h && out[yy * w + xx] == PixelIndex.TRANSPARENT) out[yy * w + xx] = col
                    }
                }
            }
        }
        // agujeritos cerrados (<= 6 px) dentro de la silueta
        val seen = BooleanArray(w * h)
        for (s0 in 0 until w * h) {
            if (out[s0] != PixelIndex.TRANSPARENT || seen[s0]) continue
            var qh = 0; var qt = 0; var edge = false; var color = 0
            queue[qt++] = s0; seen[s0] = true
            while (qh < qt) {
                val c = queue[qh++]; val cx = c % w; val cy = c / w
                if (cx == 0 || cy == 0 || cx == w - 1 || cy == h - 1) edge = true
                for ((dx, dy) in arrayOf(1 to 0, -1 to 0, 0 to 1, 0 to -1)) {
                    val xx = cx + dx; val yy = cy + dy
                    if (xx !in 0 until w || yy !in 0 until h) continue
                    val n = yy * w + xx
                    if (out[n] == PixelIndex.TRANSPARENT) { if (!seen[n]) { seen[n] = true; if (qt < queue.size) queue[qt++] = n } }
                    else color = out[n]
                }
            }
            if (!edge && qt <= 6 && color != 0) for (i in 0 until qt) out[queue[i]] = color
        }
        return out
    }

    /** Codo: tapa las muescas del borde del brazo (píxel vacío rodeado de material en 3 de las 4 direcciones a <= 3 px). */
    fun fillNotches(src: IntArray, w: Int, h: Int): IntArray {
        var cur = src
        repeat(2) {
            val out = cur.copyOf()
            for (y in 0 until h) for (x in 0 until w) {
                if (cur[y * w + x] != PixelIndex.TRANSPARENT) continue
                var hits = 0; var color = 0
                for (d in arrayOf(intArrayOf(1, 0), intArrayOf(-1, 0), intArrayOf(0, 1), intArrayOf(0, -1))) {
                    for (k in 1..3) { val xx = x + d[0] * k; val yy = y + d[1] * k
                        if (xx in 0 until w && yy in 0 until h && cur[yy * w + xx] != PixelIndex.TRANSPARENT) { hits++; color = cur[yy * w + xx]; break } }
                }
                if (hits >= 3) out[y * w + x] = color
            }
            cur = out
        }
        return cur
    }

    fun armIndex(swing: Int, bend: Int) = swing * CreatureSpriteData.ARM_BEND.size + bend

    /** Cabezas: 0 = frontal, 1 = girada hacia donde camina. */
    val heads: Array<IntArray> by lazy { Array(CreatureSpriteData.HEAD_DATA.size) { SpriteCodec.decode(CreatureSpriteData.HEAD_DATA[it], headW(it) * headH(it)) } }
    fun headW(variant: Int) = CreatureSpriteData.HEAD_SIZES[variant * 2]
    fun headH(variant: Int) = CreatureSpriteData.HEAD_SIZES[variant * 2 + 1]
    val head: IntArray get() = heads[0]

    /** Ojo trasero (L) y delantero (R); índice = variante * 5 + estado. */
    val eyesL: Array<IntArray> by lazy { Array(CreatureSpriteData.EYE_DATA_L.size) { val s = eyeSizeL(it / 5); SpriteCodec.decode(CreatureSpriteData.EYE_DATA_L[it], s * s) } }
    val eyesR: Array<IntArray> by lazy { Array(CreatureSpriteData.EYE_DATA_R.size) { val s = eyeSizeR(it / 5); SpriteCodec.decode(CreatureSpriteData.EYE_DATA_R[it], s * s) } }
    fun eyeSizeL(variant: Int) = CreatureSpriteData.EYE_SIZES[variant * 2]
    fun eyeSizeR(variant: Int) = CreatureSpriteData.EYE_SIZES[variant * 2 + 1]

    /** Boca principal; índice = variante * 4 + estado. */
    val mainMouths: Array<IntArray> by lazy {
        Array(CreatureSpriteData.MAIN_MOUTH_DATA.size) {
            val v = it / CreatureSpriteData.MAIN_MOUTH_STATES.size
            SpriteCodec.decode(CreatureSpriteData.MAIN_MOUTH_DATA[it], mainW(v) * mainH(v))
        }
    }
    fun mainW(variant: Int) = CreatureSpriteData.MAIN_MOUTH_SIZES[variant * 2]
    fun mainH(variant: Int) = CreatureSpriteData.MAIN_MOUTH_SIZES[variant * 2 + 1]

    /** Bocas del vientre; índice = boca * SEC_STATES + estado (0 cerrada, 1 entreabierta, 2 abierta, 3 muy abierta). */
    val secMouths: Array<IntArray> by lazy {
        Array(CreatureSpriteData.SEC_DATA.size) {
            val mouth = it / CreatureSpriteData.SEC_STATES
            SpriteCodec.decode(CreatureSpriteData.SEC_DATA[it], secW(mouth) * secH(mouth))
        }
    }

    fun secW(mouth: Int) = CreatureSpriteData.SEC_SIZES[mouth * 2]
    fun secH(mouth: Int) = CreatureSpriteData.SEC_SIZES[mouth * 2 + 1]
    fun secOriginX(mouth: Int) = CreatureSpriteData.SEC_ORIGINS[mouth * 2]
    fun secOriginY(mouth: Int) = CreatureSpriteData.SEC_ORIGINS[mouth * 2 + 1]
    fun secIndex(mouth: Int, state: Int) = mouth * CreatureSpriteData.SEC_STATES + state

    /**
     * Misma fórmula de iluminación que [PixelRasterizer] (brillo con suelo SHADE_FLOOR + tinte), así el niño y la
     * criatura reaccionan igual a una misma luz. Lógica pura (testeable sin Android).
     */
    fun shade(indices: IntArray, w: Int, h: Int, light: LightingSample?, out: IntArray) {
        val shade = if (light == null) 1f else PixelRasterizer.SHADE_FLOOR + (1f - PixelRasterizer.SHADE_FLOOR) * light.brightness.coerceIn(0f, 1f)
        val tr = if (light == null) 1f else 1f + (light.tintR - 1f) * PixelRasterizer.TINT_STRENGTH
        val tg = if (light == null) 1f else 1f + (light.tintG - 1f) * PixelRasterizer.TINT_STRENGTH
        val tb = if (light == null) 1f else 1f + (light.tintB - 1f) * PixelRasterizer.TINT_STRENGTH
        for (i in 0 until w * h) {
            val idx = indices[i]
            val c = if (idx in PALETTE.indices) PALETTE[idx] else 0
            val a = (c ushr 24) and 0xFF
            if (idx == PixelIndex.TRANSPARENT || a == 0) { out[i] = 0; continue }
            val r = (((c shr 16) and 0xFF) * shade * tr).toInt().coerceIn(0, 255)
            val g = (((c shr 8) and 0xFF) * shade * tg).toInt().coerceIn(0, 255)
            val b = ((c and 0xFF) * shade * tb).toInt().coerceIn(0, 255)
            out[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
    }
}
