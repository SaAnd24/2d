package com.terror2d.pixel

/** Decodifica las matrices de [SpriteData] (tramos de 2 caracteres: índice de paleta + longitud, ambos como 48 + n). */
object SpriteCodec {
    fun decode(s: String, size: Int): IntArray {
        val out = IntArray(size)
        var o = 0
        var i = 0
        while (i + 1 < s.length) {
            val v = s[i].code - 48
            val n = s[i + 1].code - 48
            var k = 0
            while (k < n && o < size) {
                out[o] = v
                o++
                k++
            }
            i += 2
        }
        return out
    }
}
