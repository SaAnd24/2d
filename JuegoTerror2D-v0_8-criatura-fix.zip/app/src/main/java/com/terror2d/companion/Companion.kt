package com.terror2d.companion

import com.terror2d.inventory.ItemRegistry

/**
 * Estado del COMPAÑERO (el peluche) desde v0.7. Es un PERSONAJE, no un objeto de inventario normal:
 *
 *   NOT_FOUND -> ON_FLOOR -> (PICKUP) -> ON_BACK <-> TALKING
 *
 * Extensible: añadir estados (p. ej. HIDDEN_IN_POCKET, LOST) no obliga a rehacer nada; el resto del juego solo
 * pregunta [CompanionSlot.isCarried] y [CompanionSlot.canTalk].
 */
enum class CompanionState {
    /** Todavía no se ha visto en el mundo. */
    NOT_FOUND,

    /** Está tirado en el suelo, a la espera de que el niño lo recoja. */
    ON_FLOOR,

    /** El niño lo lleva a la espalda (COMPANION SLOT ocupado; las manos siguen libres). */
    ON_BACK,

    /** Escena de conversación en curso (primera persona). */
    TALKING
}

/** Lo que el niño lleva en las manos (HAND SLOT). Un solo objeto físico a la vez. */
enum class HandState { EMPTY, HOLDING_WATER, HOLDING_MEDICINE, HOLDING_OBJECT }

object Hands {
    fun stateOf(heldItemId: String?): HandState = when (heldItemId) {
        null -> HandState.EMPTY
        ItemRegistry.WATER_GLASS -> HandState.HOLDING_WATER
        ItemRegistry.PILL_BOX_BLUE, ItemRegistry.PILL_BOX_ORANGE, ItemRegistry.PILL_BOX_WHITE -> HandState.HOLDING_MEDICINE
        else -> HandState.HOLDING_OBJECT
    }
}

/**
 * COMPANION SLOT: espacio reservado PERMANENTEMENTE para el peluche una vez recogido. No consume las manos, no puede
 * ser reemplazado por vasos, medicinas ni otros objetos, y su estado forma parte del GameLogic ([GameState.inventory]).
 *
 * PELUCHE = compañero. HAND SLOT ([com.terror2d.inventory.Inventory.held]) = objeto físico que el niño lleva.
 */
class CompanionSlot {

    var state: CompanionState = CompanionState.NOT_FOUND
        private set

    /** Objeto-compañero (id del catálogo) cuando ya se lleva; null mientras no. */
    var itemId: String? = null
        private set

    /** Nombre con el que el niño lo llama (aparece en "HABLAR CON ...". */
    var name: String = "RANITA"
        set(value) {
            field = value
            talkLabel = "HABLAR CON " + value
        }

    /** Texto del botón contextual (cacheado: no se construye cada frame). */
    var talkLabel: String = "HABLAR CON RANITA"
        private set

    /** El compañero ya está con el niño (a la espalda o en conversación). */
    val isCarried: Boolean get() = state == CompanionState.ON_BACK || state == CompanionState.TALKING

    /** La escena registra que el compañero existe en el mundo (NOT_FOUND -> ON_FLOOR). */
    fun discover() {
        if (state == CompanionState.NOT_FOUND) state = CompanionState.ON_FLOOR
    }

    /** PICKUP: lo recoge el niño. Devuelve false si ya lo llevaba. */
    fun pickUp(id: String): Boolean {
        if (isCarried) return false
        itemId = id
        state = CompanionState.ON_BACK
        return true
    }

    /** ¿Se puede ofrecer "HABLAR CON ..." ahora? Solo a la espalda y con las manos vacías (lógica física del mundo). */
    fun canTalk(hand: HandState): Boolean = state == CompanionState.ON_BACK && hand == HandState.EMPTY

    fun beginTalk(): Boolean {
        if (state != CompanionState.ON_BACK) return false
        state = CompanionState.TALKING
        return true
    }

    fun endTalk() {
        if (state == CompanionState.TALKING) state = CompanionState.ON_BACK
    }

    fun reset() {
        state = CompanionState.NOT_FOUND
        itemId = null
    }
}
