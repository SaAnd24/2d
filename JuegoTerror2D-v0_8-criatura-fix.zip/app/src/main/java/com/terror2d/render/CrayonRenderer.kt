package com.terror2d.render

import android.graphics.Paint
import android.graphics.Path
import com.terror2d.core.GameConfig
import com.terror2d.draw.CrayonKind
import com.terror2d.draw.CrayonSprite
import com.terror2d.scene.RoomSegment
import com.terror2d.world.Door

/**
 * Estilo CRAYÓN (v0.4): recorre los dibujos precalculados ([CrayonSprite]) con el mínimo de llamadas
 * a Canvas. Todo el azar se resolvió al cargar el segmento con SeededRandom; aquí no hay ni una
 * llamada aleatoria ni allocations por frame (los Path se crean una vez y se cachean en la operación).
 *
 * Futuro: GraphiteRenderer / ScratchRenderer / DistortionRenderer heredarán de [WorldRenderer] y
 * podrán mezclar estilos usando `visualCorruption` (el gancho [tint] ya está en la base).
 */
class CrayonRenderer : WorldRenderer() {

    /** Solo se dibujan los tramos de fondo que la cámara puede ver. */
    override fun drawBackdrop(seg: RoomSegment, chunks: Array<CrayonSprite>, camX: Float) {
        if (chunks.isEmpty()) {
            super.drawBackdrop(seg, chunks, camX)
            return
        }
        val chunkW = BACKDROP_CHUNK.toFloat()
        var first = ((camX - 6f) / chunkW).toInt()
        var last = ((camX + GameConfig.LOGICAL_WIDTH + 6f) / chunkW).toInt()
        if (first < 0) first = 0
        if (last > chunks.size - 1) last = chunks.size - 1
        for (i in first..last) drawSprite(chunks[i])
    }

    override fun drawSprite(sprite: CrayonSprite) {
        val ops = sprite.ops
        for (i in ops.indices) {
            val op = ops[i]
            val d = op.data
            when (op.kind) {
                CrayonKind.FILL_RECT -> {
                    paint.style = Paint.Style.FILL
                    paint.color = tint(op.color)
                    canvas.drawRect(d[0], d[1], d[2], d[3], paint)
                }
                CrayonKind.FILL_OVAL -> {
                    paint.style = Paint.Style.FILL
                    paint.color = tint(op.color)
                    canvas.drawOval(d[0], d[1], d[2], d[3], paint)
                }
                CrayonKind.FILL_POLY -> {
                    var p = op.cache as Path?
                    if (p == null) {
                        p = Path()
                        p.moveTo(d[0], d[1])
                        var k = 2
                        while (k + 1 < d.size) {
                            p.lineTo(d[k], d[k + 1])
                            k += 2
                        }
                        p.close()
                        op.cache = p
                    }
                    paint.style = Paint.Style.FILL
                    paint.color = tint(op.color)
                    canvas.drawPath(p, paint)
                }
                CrayonKind.STROKES -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = op.width
                    paint.color = tint(op.color)
                    canvas.drawLines(d, paint)
                }
                CrayonKind.DOTS -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = op.width
                    paint.color = tint(op.color)
                    canvas.drawPoints(d, paint)
                }
            }
        }
    }

    /** Las puertas del crayón llevan además un trazo extra de relieve en el marco. */
    override fun drawDoor(d: Door) {
        super.drawDoor(d)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 0.8f
        paint.color = tint(0x66000000)
        canvas.drawLine(d.x - 4.5f, d.y - 4f, d.right + 4.5f, d.y - 4f, paint)
        canvas.drawLine(d.x - 4.5f, d.y - 4f, d.x - 4.5f, d.bottom, paint)
    }

    companion object {
        /** Ancho (px) de cada tramo de fondo precalculado. */
        const val BACKDROP_CHUNK = 160
    }
}
