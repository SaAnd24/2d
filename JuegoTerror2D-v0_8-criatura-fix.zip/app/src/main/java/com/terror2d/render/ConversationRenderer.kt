package com.terror2d.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import com.terror2d.conversation.ConversationView
import com.terror2d.conversation.Speaker
import com.terror2d.core.GameConfig
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Dibuja la ESCENA DE CONVERSACIÓN: negro casi total, las dos manos del niño y el peluche, todo en pixel art de
 * altísima densidad (1 píxel de arte = 0,5 px lógicos, el doble de fino que el mundo de crayón: el contraste es
 * deliberado). No dibuja HUD ni habitación.
 *
 * Las MANOS están vivas: respiración (subida/bajada y pequeñas derivas) y temblor (cada dedo por separado), ambos
 * escalados por [ConversationView.breathingIntensity] y [ConversationView.handTremorIntensity].
 * El PELUCHE (capa 0) se dibuja SIEMPRE en su sitio exacto: sin parpadeo, sin pupilas, sin boca, sin respirar.
 */
class ConversationRenderer {

    private var art: ConversationArt? = null

    private val paint = Paint().apply {
        isAntiAlias = false
        isFilterBitmap = false
        isDither = false
    }
    private val textPaint = Paint().apply {
        isAntiAlias = true
        typeface = Typeface.MONOSPACE
        textSize = 8.6f
    }
    private val shadowPaint = Paint().apply {
        isAntiAlias = true
        typeface = Typeface.MONOSPACE
        textSize = 8.6f
        color = 0xFF000000.toInt()
    }
    private val arrow = Path()

    // ajuste de texto de la línea actual (sin allocations por frame)
    private var wrappedSerial = -1
    private var wrapCount = 0
    private val wrapStart = IntArray(6)
    private val wrapEnd = IntArray(6)

    fun draw(canvas: Canvas, v: ConversationView) {
        val blend = v.blend
        if (blend <= 0.002f) {
            release()
            return
        }
        val w = GameConfig.LOGICAL_WIDTH.toFloat()
        val h = GameConfig.LOGICAL_HEIGHT.toFloat()

        // fondo: el mundo se apaga hasta un negro casi absoluto
        paint.style = Paint.Style.FILL
        paint.color = ((blend.coerceIn(0f, 1f) * 255f).toInt() shl 24) or 0x040405
        canvas.drawRect(0f, 0f, w, h, paint)

        val a = ((blend - 0.45f) / 0.55f).coerceIn(0f, 1f)
        if (a > 0.01f) {
            val art = this.art ?: ConversationArt().also { this.art = it }
            drawArt(canvas, art, v, a)
        }
        drawText(canvas, v, a)
    }

    private fun drawArt(canvas: Canvas, art: ConversationArt, v: ConversationView, alpha: Float) {
        paint.alpha = (alpha * 255f).toInt()
        val t = v.time
        val breath = v.breathingIntensity
        val tremor = v.handTremorIntensity
        canvas.save()
        canvas.scale(0.5f, 0.5f)           // 640x360 de arte -> 320x180 lógicos
        for (l in art.layers) {
            var dx = 0
            var dy = 0
            if (l.group != ConversationArt.GROUP_PLUSH) {
                val hand = if (l.group == ConversationArt.GROUP_LEFT) 0 else 1
                // respiración: las dos manos suben y bajan juntas con un pequeño desfase y deriva lateral
                val ph = (t / BREATH_PERIOD) * (2.0 * PI).toFloat() + hand * 0.45f
                val by = sin(ph) * (0.6f + 2.4f * breath)
                val bx = sin(ph * 0.5f + hand) * (0.2f + 0.8f * breath)
                var tx = 0f
                var ty = 0f
                // temblor: cada dedo (y la base de la mano) con su propia fase y frecuencia
                val k = if (l.finger >= 0) l.finger + 1 else 0
                val amp = TREMOR_PX * tremor * (if (l.finger >= 0) 1f else 0.55f)
                tx = (sin(t * (27f + k * 3.1f) + hand * 2.1f + k * 1.7f) * 0.6f + sin(t * (43f + k * 2.3f) + k * 3.9f) * 0.4f) * amp
                ty = (sin(t * (31f + k * 2.7f) + hand * 1.3f + k * 2.2f) * 0.6f + sin(t * (53f + k * 1.9f) + k * 0.8f) * 0.4f) * amp
                dx = (bx + tx).roundToInt()
                dy = (by + ty).roundToInt()
            }
            canvas.drawBitmap(l.bitmap, (l.x + dx).toFloat(), (l.y + dy).toFloat(), paint)
        }
        canvas.restore()
        paint.alpha = 255
    }

    private fun drawText(canvas: Canvas, v: ConversationView, alpha: Float) {
        val l = v.line ?: return
        val shown = v.visibleChars
        if (shown <= 0) return
        val text = l.text
        ensureWrapped(text, v.lineSerial, GameConfig.LOGICAL_WIDTH - 56f)
        val companion = l.speaker == Speaker.COMPANION
        textPaint.color = if (companion) 0xFFE9E2C4.toInt() else 0xFF9DB4C6.toInt()
        textPaint.alpha = (alpha * 255f).toInt()
        shadowPaint.alpha = (alpha * 255f).toInt()
        val lineH = 10.5f
        var y = GameConfig.LOGICAL_HEIGHT - 12f - (wrapCount - 1) * lineH
        for (i in 0 until wrapCount) {
            val s = wrapStart[i]
            val e = min(wrapEnd[i], shown)
            if (e > s) {
                val tw = textPaint.measureText(text, s, wrapEnd[i])
                val x = (GameConfig.LOGICAL_WIDTH - tw) / 2f
                canvas.drawText(text, s, e, x + 0.7f, y + 0.7f, shadowPaint)
                canvas.drawText(text, s, e, x, y, textPaint)
            }
            y += lineH
        }
        if (v.waitingForTap && ((v.time * 1.6f).toInt() and 1) == 0) {
            val cx = GameConfig.LOGICAL_WIDTH / 2f
            val cy = GameConfig.LOGICAL_HEIGHT - 3.5f
            arrow.reset()
            arrow.moveTo(cx - 3f, cy - 2.5f)
            arrow.lineTo(cx + 3f, cy - 2.5f)
            arrow.lineTo(cx, cy + 1f)
            arrow.close()
            paint.style = Paint.Style.FILL
            paint.color = if (companion) 0x99E9E2C4.toInt() else 0x999DB4C6.toInt()
            canvas.drawPath(arrow, paint)
        }
    }

    private fun ensureWrapped(text: String, serial: Int, maxWidth: Float) {
        if (serial == wrappedSerial) return
        wrappedSerial = serial
        wrapCount = 0
        var start = 0
        val n = text.length
        while (start < n && wrapCount < wrapStart.size) {
            var count = textPaint.breakText(text, start, n, true, maxWidth, null)
            if (count <= 0) count = 1
            var end = start + count
            if (end < n) {
                // cortar en el último espacio, si lo hay
                var sp = end
                while (sp > start && text[sp - 1] != ' ') sp--
                if (sp > start) end = sp
            }
            wrapStart[wrapCount] = start
            wrapEnd[wrapCount] = end
            wrapCount++
            start = end
        }
    }

    /** Libera los bitmaps del arte (al salir de la escena). */
    fun release() {
        art?.release()
        art = null
        wrappedSerial = -1
    }

    companion object {
        private const val BREATH_PERIOD = 4.2f
        private const val TREMOR_PX = 2.6f
    }
}
