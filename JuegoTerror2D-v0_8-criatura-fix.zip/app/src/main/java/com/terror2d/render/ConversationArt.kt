package com.terror2d.render

import android.graphics.Bitmap
import com.terror2d.pixel.ConversationArtData

/**
 * Decodifica el arte hiperdetallado de la escena de conversación ([ConversationArtData], generado por
 * tools/sprite_gen/conversation_art.py) en bitmaps ARGB, uno por capa. Se crea al ENTRAR a la escena y se libera
 * al salir ([release]): el arte solo ocupa memoria mientras dura la conversación.
 */
class ConversationArt {

    class Layer(val name: String, val x: Int, val y: Int, val bitmap: Bitmap, val group: Int, val finger: Int)

    val layers: Array<Layer>

    init {
        val d = ConversationArtData
        val list = ArrayList<Layer>(d.LAYER_NAMES.size)
        for (i in d.LAYER_NAMES.indices) {
            val r = d.LAYER_RECT[i]
            val w = r[2]
            val h = r[3]
            val px = IntArray(w * h)
            decode(d.LAYER_DATA[i], px)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.setPixels(px, 0, w, 0, 0, w, h)
            val name = d.LAYER_NAMES[i]
            val group = when {
                name == "plush" -> GROUP_PLUSH
                name == "hand_l" || name.startsWith("l_") -> GROUP_LEFT
                else -> GROUP_RIGHT
            }
            val finger = if (name.length == 3 && (name.startsWith("l_") || name.startsWith("r_"))) name[2] - '0' else -1
            list.add(Layer(name, r[0], r[1], bmp, group, finger))
        }
        layers = list.toTypedArray()
    }

    private fun decode(chunks: Array<String>, out: IntArray) {
        val alphabet = ConversationArtData.ALPHABET
        val palette = ConversationArtData.PALETTE
        var pos = 0
        for (c in chunks.indices) {
            val s = chunks[c]
            var i = 0
            while (i + 2 < s.length && pos < out.size) {
                val idx = alphabet.indexOf(s[i]) * 64 + alphabet.indexOf(s[i + 1])
                val run = s[i + 2].code - 48
                val color = palette[idx]
                var k = 0
                while (k < run && pos < out.size) {
                    out[pos++] = color
                    k++
                }
                i += 3
            }
        }
    }

    fun release() {
        for (l in layers) l.bitmap.recycle()
    }

    companion object {
        const val GROUP_PLUSH = 0
        const val GROUP_LEFT = 1
        const val GROUP_RIGHT = 2
    }
}
