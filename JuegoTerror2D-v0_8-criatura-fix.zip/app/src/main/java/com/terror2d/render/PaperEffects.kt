package com.terror2d.render

import com.terror2d.draw.CrayonBuilder
import com.terror2d.draw.CrayonSprite
import com.terror2d.util.SeededRandom
import kotlin.math.cos
import kotlin.math.sin

/**
 * Efectos de PAPEL PEGADO sobre el personaje (v0.6): lágrimas, sudor, temblor, marcas de dolor y respiración fría.
 *
 * El protagonista NO se convierte en un recorte: siguen siendo píxeles. Estos efectos son trocitos de papel con
 * borde irregular, fibras y una sombra mínima, "pegados" encima de la cabeza y el cuerpo. Se construyen UNA vez con
 * [SeededRandom] (misma semilla = mismo recorte) en coordenadas relativas al CENTRO DE LA CABEZA, mirando a la
 * derecha, en píxeles lógicos. Son sutiles (pequeños, translúcidos) y todavía NO los dispara ningún evento del juego:
 * [com.terror2d.world.Player.paperEffects] es la máscara de bits que los activará en versiones futuras.
 */
object PaperEffects {
    const val TEARS = 1
    const val SWEAT = 2
    const val TREMBLE = 4
    const val PAIN = 8
    const val COLD_BREATH = 16

    val ALL_KINDS = intArrayOf(TEARS, SWEAT, TREMBLE, PAIN, COLD_BREATH)

    private const val SEED = 0x7A9E12L

    private const val PAPER = 0xFFF2F6F8.toInt()
    private const val PAPER_BLUE = 0xFFD6E8F4.toInt()
    private const val EDGE = 0xFF8A8A98.toInt()
    private val cache = HashMap<Int, CrayonSprite>()

    fun sprite(kind: Int): CrayonSprite {
        val c = cache[kind]
        if (c != null) return c
        val b = CrayonBuilder(SeededRandom(SeededRandom.derive(SEED, kind)))
        when (kind) {
            TEARS -> tears(b)
            SWEAT -> sweat(b)
            TREMBLE -> tremble(b)
            PAIN -> pain(b)
            COLD_BREATH -> breath(b)
        }
        val s = b.finish()
        cache[kind] = s
        return s
    }

    /** Trocito de papel con borde irregular: sombra mínima, relleno, fibras y borde fino. */
    private fun scrap(
        b: CrayonBuilder, rng: SeededRandom, cx: Float, cy: Float, rx: Float, ry: Float,
        fill: Int, edge: Int, sides: Int = 7
    ) {
        val pts = FloatArray(sides * 2)
        val sh = FloatArray(sides * 2)
        for (i in 0 until sides) {
            val a = 6.2831853f * i / sides + rng.nextSigned() * 0.22f
            val r = 0.78f + rng.nextFloat() * 0.42f
            pts[i * 2] = cx + cos(a) * rx * r
            pts[i * 2 + 1] = cy + sin(a) * ry * r
            sh[i * 2] = pts[i * 2] + 0.6f
            sh[i * 2 + 1] = pts[i * 2 + 1] + 0.8f
        }
        b.fillPoly(sh, 0x33000000)
        b.fillPoly(pts, fill)
        val fibers = FloatArray(6)
        for (k in 0 until 3) {
            fibers[k * 2] = cx + rng.nextSigned() * rx * 0.55f
            fibers[k * 2 + 1] = cy + rng.nextSigned() * ry * 0.55f
        }
        b.dotsAt(fibers, CrayonBuilder.darker(fill, 0.9f), 0.7f)
        b.outlinePoly(pts, edge, 0.6f)
    }

    /** Lágrimas: dos gotas de papel azulado bajo el ojo, una más grande que la otra. */
    private fun tears(b: CrayonBuilder) {
        val rng = SeededRandom(11)
        scrap(b, rng, 5.5f, 5.0f, 1.5f, 2.1f, PAPER_BLUE, EDGE, 6)
        scrap(b, rng, 7.4f, 9.0f, 1.2f, 1.7f, PAPER_BLUE, EDGE, 6)
        b.fillRect(5.0f, 4.0f, 0.8f, 1.2f, 0xFFFFFFFF.toInt())
    }

    /** Sudor: gotitas de papel pálido en la frente y la sien. */
    private fun sweat(b: CrayonBuilder) {
        val rng = SeededRandom(12)
        scrap(b, rng, 1.0f, -9.0f, 1.3f, 1.8f, PAPER, EDGE, 6)
        scrap(b, rng, 6.5f, -10.5f, 1.1f, 1.5f, PAPER, EDGE, 6)
        scrap(b, rng, -6.0f, -6.0f, 1.2f, 1.6f, PAPER, EDGE, 6)
    }

    /** Temblor: tres tiritas de papel en zigzag alrededor de la cabeza y los hombros. */
    private fun tremble(b: CrayonBuilder) {
        val rng = SeededRandom(13)
        val xs = floatArrayOf(-15f, 14f, -13f)
        val ys = floatArrayOf(-2f, 4f, 14f)
        for (i in 0 until 3) {
            val x = xs[i]
            val y = ys[i]
            val pts = floatArrayOf(
                x, y, x + 3f, y - 1.2f, x + 2.2f, y + 1.6f, x + 5.4f, y + 0.4f,
                x + 5.0f, y + 2.4f, x + 1.4f, y + 3.0f, x - 0.4f, y + 1.8f
            )
            b.fillPoly(floatArrayOf(pts[0] + 0.6f, pts[1] + 0.8f, pts[2] + 0.6f, pts[3] + 0.8f, pts[4] + 0.6f, pts[5] + 0.8f,
                pts[6] + 0.6f, pts[7] + 0.8f, pts[8] + 0.6f, pts[9] + 0.8f, pts[10] + 0.6f, pts[11] + 0.8f, pts[12] + 0.6f, pts[13] + 0.8f), 0x33000000)
            b.fillPoly(pts, PAPER)
            b.outlinePoly(pts, EDGE, 0.6f)
            b.dotsAt(floatArrayOf(x + 2f + rng.nextSigned(), y + 1f), 0xFFC8C8D0.toInt(), 0.7f)
        }
    }

    /** Marcas de dolor: estrellitas/rayas de papel rojo (lápiz) a los lados de la cabeza. */
    private fun pain(b: CrayonBuilder) {
        val rng = SeededRandom(14)
        val red = 0xFFE05A48.toInt()
        val edge = 0xFF8E2A22.toInt()
        val cxs = floatArrayOf(13f, -12f, 16f)
        val cys = floatArrayOf(-12f, -11f, -3f)
        for (i in 0 until 3) {
            val cx = cxs[i]
            val cy = cys[i]
            val pts = FloatArray(16)
            for (k in 0 until 8) {
                val a = 6.2831853f * k / 8f + rng.nextSigned() * 0.12f
                val r = if (k % 2 == 0) 3.4f + rng.nextFloat() else 1.2f
                pts[k * 2] = cx + cos(a) * r
                pts[k * 2 + 1] = cy + sin(a) * r
            }
            b.fillPoly(pts, red)
            b.outlinePoly(pts, edge, 0.6f)
        }
    }

    /** Respiración fría: tres bocanadas de papel casi transparente que suben delante de la cara. */
    private fun breath(b: CrayonBuilder) {
        val rng = SeededRandom(15)
        val puff = 0x99EEF4FA.toInt()
        val edge = 0x66AAB4C4.toInt()
        scrap(b, rng, 14f, 7f, 2.6f, 1.8f, puff, edge, 7)
        scrap(b, rng, 19f, 4.5f, 3.2f, 2.2f, puff, edge, 7)
        scrap(b, rng, 25f, 1.5f, 3.6f, 2.5f, puff, edge, 8)
    }
}
