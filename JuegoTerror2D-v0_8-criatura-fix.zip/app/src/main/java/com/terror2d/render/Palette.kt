package com.terror2d.render

/** Paleta inicial (etapa crayón). Valores ARGB. Futuras etapas aportarán paletas de grafito. */
object Palette {
    const val PAPER = 0xFFF4ECD8.toInt()
    const val FLOOR = 0xFFF3E0A8.toInt()
    const val FLOOR_STROKE = 0x66E0A84A.toInt()
    const val SPECKLE = 0x44806040.toInt()
    const val OUTLINE = 0xFF3A2A20.toInt()

    const val WALL_FILL = 0xB07B5FC7.toInt()
    const val WALL_HATCH = 0xCC5B3FA8.toInt()
    const val WALL_LINE = 0xFF2B2140.toInt()

    const val CRATE_FILL = 0xB0E8944A.toInt()
    const val CRATE_HATCH = 0xCCC46A1F.toInt()

    const val BLUE_FILL = 0xB05AA6E8.toInt()
    const val BLUE_HATCH = 0xCC2F7BC4.toInt()

    const val GREEN_FILL = 0xB07CC96B.toInt()
    const val GREEN_HATCH = 0xCC4F9A3E.toInt()

    const val RUG_FILL = 0x80E8604C.toInt()
    const val RUG_HATCH = 0xAAC93B2E.toInt()

    const val PLAYER_DRESS = 0xFFE8604C.toInt()
    const val PLAYER_SKIN = 0xFFFFD9B3.toInt()
    const val PLAYER_HAIR = 0xFF6B4226.toInt()
    const val SHADOW = 0x33000000
    const val PLAYER_SHOE = 0xFF5A3A2A.toInt()
    const val PLAYER_DRESS_TRIM = 0xFFFFE066.toInt()
    const val PLAYER_BLUSH = 0xAAFF8FA0.toInt()

    // --- v0.2: escenarios laterales (coloridos, con un punto inquietante) ---
    const val WALL_A = 0xFFA9D2BC.toInt()          // menta apagado
    const val WALL_A_STROKE = 0x669BBFA6.toInt()
    const val WALL_B = 0xFFD6A9C9.toInt()          // rosa polvoriento
    const val WALL_B_STROKE = 0x66B27FA3.toInt()
    const val FLOOR_WOOD = 0xFFD8B278.toInt()
    const val FLOOR_WOOD_STROKE = 0x66A8722C.toInt()
    const val SKIRTING = 0xFF7A5238.toInt()
    const val EDGE_WALL = 0xFF3A2C52.toInt()

    const val DOOR_FRAME = 0xFF5A3A2A.toInt()
    const val DOOR_PANEL = 0xFFC9782E.toInt()
    const val DOOR_HATCH = 0xCC8F4A18.toInt()
    const val DOOR_INSIDE = 0xFF1E1230.toInt()
    const val DOOR_KNOB = 0xFFF3D26B.toInt()

    const val PICTURE_FRAME_FILL = 0xB07A4B2B.toInt()
    const val PICTURE_FRAME_HATCH = 0xCC4F2F18.toInt()
    const val PICTURE_INNER_FILL = 0xB0F5E6A8.toInt()
    const val PICTURE_INNER_HATCH = 0xCCE0B84A.toInt()

    const val LAMP_SHADE_FILL = 0xB0F5C85A.toInt()
    const val LAMP_SHADE_HATCH = 0xCCD99A2B.toInt()
    const val LAMP_CORD = 0xFF3A2A20.toInt()

    // --- v0.3: armarios, interruptor, texto ---
    const val WARDROBE_INSIDE = 0xFF0E0716.toInt()
    const val WARDROBE_WARM_BODY = 0xFFD9904E.toInt()
    const val WARDROBE_WARM_HATCH = 0xCCA9622A.toInt()
    const val WARDROBE_WARM_DOOR = 0xFFE8A862.toInt()
    const val WARDROBE_COLD_BODY = 0xFF6F8FBF.toInt()
    const val WARDROBE_COLD_HATCH = 0xCC4A6A9C.toInt()
    const val WARDROBE_COLD_DOOR = 0xFF88A8D4.toInt()
    const val WARDROBE_GREEN_BODY = 0xFF7DB87A.toInt()
    const val WARDROBE_GREEN_HATCH = 0xCC4E8C50.toInt()
    const val WARDROBE_GREEN_DOOR = 0xFF9CCF96.toInt()
    const val WARDROBE_PLUM_BODY = 0xFF8C6BB0.toInt()
    const val WARDROBE_PLUM_HATCH = 0xCC634488.toInt()
    const val WARDROBE_PLUM_DOOR = 0xFFA98BC9.toInt()
    const val WARDROBE_TRIM = 0xFF4A2F22.toInt()
    const val EYE_WHITE = 0xFFFFF6D6.toInt()
    const val SWITCH_PLATE = 0xFFF2E6C4.toInt()

    const val TEXT_BOX_FILL = 0xF2F4ECD8.toInt()
    const val TEXT_INK = 0xFF3A2A20.toInt()

    // --- Iluminación (la capa de luz usa estos colores sin pasar por tint) ---
    // Color de la oscuridad (RGB). Es azul-violeta, no gris: el color sigue vivo dentro de la luz.
    const val DARK_ZONE = 0x1B0F2E
    const val DARK_WARM = 0x1E0F16      // oscuridad con un fondo cálido (habitación acogedora)
    const val DARK_COLD = 0x0A1230      // oscuridad fría y azulada
    const val DARK_DEEP = 0x07040F      // oscuridad profunda
    const val LIGHT_WARM = 0xFFD27A
    const val LIGHT_COLD = 0x9FD0FF
    const val LIGHT_PALE = 0xE8F0FF
    const val LIGHT_GLOW = 0xFFE8C0
    const val VIGNETTE_EDGE = 0x66100820
}
