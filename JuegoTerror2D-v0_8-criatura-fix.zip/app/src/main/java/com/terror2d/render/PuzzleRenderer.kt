package com.terror2d.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import com.terror2d.core.GameConfig
import com.terror2d.pixel.FirstPersonHands
import com.terror2d.pixel.LightingSample
import com.terror2d.puzzle.MedicinePuzzle
import com.terror2d.puzzle.PuzzleBox
import com.terror2d.puzzle.PuzzleLayout
import com.terror2d.story.DocumentDef
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * Dibuja la PRIMERA PERSONA del puzzle de medicamentos (mesa vista desde los ojos del niño) y los documentos
 * legibles. Todo en coordenadas lógicas 320x180. La mesa, las cajas y los papeles son de papel/crayón (vectores);
 * las manos son pixel art (personaje). Sin allocations por frame: paints y rectángulos reutilizados.
 */
class PuzzleRenderer {

    private val fill = Paint().apply { style = Paint.Style.FILL; isAntiAlias = false }
    private val stroke = Paint().apply { style = Paint.Style.STROKE; isAntiAlias = false; strokeCap = Paint.Cap.SQUARE }
    private val text = Paint().apply {
        isAntiAlias = true
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()
    private val pixels = PlayerPixelRenderer()
    private val glow = Paint().apply { isAntiAlias = true }
    private val lampShader = RadialGradient(262f, 14f, 150f, intArrayOf(0x88FFD58A.toInt(), 0x00FFD58A), null, Shader.TileMode.CLAMP)
    private val tableShader = RadialGradient(190f, 110f, 210f, intArrayOf(0x30FFE6A0, 0x00FFE6A0), null, Shader.TileMode.CLAMP)

    private class BoxColors(val body: Int, val light: Int, val dark: Int, val accent: Int)

    private fun colorsFor(itemId: String): BoxColors = when (itemId) {
        "pill_box_blue" -> BoxColors(0xFF5A8FE0.toInt(), 0xFF86B4F2.toInt(), 0xFF3A68B4.toInt(), 0xFF3C84C8.toInt())
        "pill_box_orange" -> BoxColors(0xFFE8944A.toInt(), 0xFFF8B878.toInt(), 0xFFB86828.toInt(), 0xFFD94F3D.toInt())
        else -> BoxColors(0xFFF2EEE0.toInt(), 0xFFFFFFF4.toInt(), 0xFFC9C4B4.toInt(), 0xFF4F9A3E.toInt())
    }

    // ------------------------------------------------------------------ puzzle

    /** [alpha] 0..1: opacidad de toda la vista (el cambio de cámara la funde con el mundo). */
    fun drawPuzzle(canvas: Canvas, p: MedicinePuzzle, alpha: Float, time: Float, corruption: Float) {
        if (alpha <= 0.01f) return
        val layer = canvas.saveLayerAlpha(0f, 0f, GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat(), (alpha.coerceIn(0f, 1f) * 255f).toInt())
        drawRoomAndTable(canvas, time)
        drawMat(canvas, p, time)
        drawPaper(canvas)
        for (b in p.drawOrder) drawBox(canvas, b, p, time)
        drawHands(canvas, p, time, corruption)
        if (!p.solved) drawBackTab(canvas)
        if (p.solved) {
            val k = (p.solvedTime / 0.8f).coerceIn(0f, 1f)
            fill.shader = null
            fill.color = ((0x22 * k).toInt() shl 24) or 0x00FFD27A
            canvas.drawRect(0f, 0f, GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat(), fill)
        }
        canvas.restoreToCount(layer)
    }

    private fun drawRoomAndTable(canvas: Canvas, time: Float) {
        val w = GameConfig.LOGICAL_WIDTH.toFloat()
        val h = GameConfig.LOGICAL_HEIGHT.toFloat()
        val top = PuzzleLayout.TABLE_TOP
        // pared del cuarto de mamá (tenue) con el resplandor de la lámpara
        fill.shader = null
        fill.color = 0xFF3A2E3E.toInt()
        canvas.drawRect(0f, 0f, w, top + 4f, fill)
        stroke.strokeWidth = 1f
        stroke.color = 0x33FFFFFF
        for (i in 0 until 8) {
            val x = 20f + i * 42f
            canvas.drawLine(x, 4f, x, top, stroke)
        }
        fill.shader = lampShader
        canvas.drawRect(0f, 0f, w, top + 4f, fill)
        fill.shader = null
        // tablero de la mesa
        fill.color = 0xFFB98A5A.toInt()
        canvas.drawRect(0f, top, w, h, fill)
        // tablas en perspectiva (convergen hacia el fondo)
        stroke.strokeWidth = 1.2f
        stroke.color = 0x66603A1E
        for (i in -2..9) {
            val xTop = 160f + (i * 40f - 160f) * 0.78f
            val xBot = 160f + (i * 40f - 160f) * 1.3f
            canvas.drawLine(xTop, top, xBot, h, stroke)
        }
        // vetas de la madera (fijas, sin azar)
        stroke.strokeWidth = 1f
        stroke.color = 0x33603A1E
        for (i in 0 until 26) {
            val y = top + 6f + (i * 37 % 120)
            val x = (i * 53 % 280) + 10f
            canvas.drawLine(x, y, x + 12f + (i % 4) * 5f, y + 0.8f, stroke)
        }
        // canto del fondo de la mesa
        fill.color = 0xFF7A5230.toInt()
        canvas.drawRect(0f, top - 2f, w, top + 2f, fill)
        fill.color = 0xFFD9B27E.toInt()
        canvas.drawRect(0f, top + 2f, w, top + 3.2f, fill)
        fill.shader = tableShader
        canvas.drawRect(0f, top, w, h, fill)
        fill.shader = null
    }

    private fun drawMat(canvas: Canvas, p: MedicinePuzzle, time: Float) {
        // pastillero de papel hecho a mano
        rect.set(36f, 76f, 258f, 168f)
        fill.color = 0x33000000
        canvas.drawRoundRect(rect.left + 2f, rect.top + 3f, rect.right + 2f, rect.bottom + 3f, 3f, 3f, fill)
        fill.color = 0xFFF4ECD8.toInt()
        canvas.drawRoundRect(rect, 3f, 3f, fill)
        stroke.strokeWidth = 1.3f
        stroke.color = 0xFF8C6A48.toInt()
        canvas.drawRoundRect(rect, 3f, 3f, stroke)
        stroke.strokeWidth = 0.8f
        stroke.color = 0x558C6A48
        rect.set(39f, 79f, 255f, 165f)
        canvas.drawRoundRect(rect, 2f, 2f, stroke)
        for (s in 0 until 3) {
            val cx = PuzzleLayout.SLOT_X[s]
            rect.set(cx - PuzzleLayout.SLOT_W / 2f, PuzzleLayout.SLOT_Y - PuzzleLayout.SLOT_H / 2f,
                cx + PuzzleLayout.SLOT_W / 2f, PuzzleLayout.SLOT_Y + PuzzleLayout.SLOT_H / 2f)
            fill.color = 0x14000000
            canvas.drawRoundRect(rect, 3f, 3f, fill)
            if (p.solved) {
                val pulse = 0.65f + 0.35f * sin(time * 3f)
                stroke.strokeWidth = 2f
                stroke.color = ((0xFF * pulse).toInt() shl 24) or 0xE8B84A
            } else {
                stroke.strokeWidth = 1.4f
                stroke.color = 0xFFB89B7A.toInt()
            }
            canvas.drawRoundRect(rect, 3f, 3f, stroke)
            pictogram(canvas, cx, 86f, s, 0xFF7A4A2A.toInt())
        }
    }

    /** Dibujo de un momento del día: 0 = el sol que sale, 1 = el sol alto, 2 = la luna. */
    private fun pictogram(canvas: Canvas, cx: Float, cy: Float, kind: Int, color: Int) {
        stroke.color = color
        stroke.strokeWidth = 1.3f
        fill.color = color
        when (kind) {
            0 -> {
                rect.set(cx - 4.5f, cy - 4f, cx + 4.5f, cy + 5f)
                canvas.drawArc(rect, 180f, 180f, true, fill)
                canvas.drawLine(cx - 8f, cy + 5f, cx + 8f, cy + 5f, stroke)
                canvas.drawLine(cx, cy - 8f, cx, cy - 6f, stroke)
                canvas.drawLine(cx - 6.5f, cy - 5f, cx - 5f, cy - 3.6f, stroke)
                canvas.drawLine(cx + 6.5f, cy - 5f, cx + 5f, cy - 3.6f, stroke)
            }
            1 -> {
                canvas.drawCircle(cx, cy, 3.2f, fill)
                for (i in 0 until 8) {
                    val a = i * (PI.toFloat() / 4f)
                    canvas.drawLine(cx + cos(a) * 5f, cy + sin(a) * 5f, cx + cos(a) * 7.4f, cy + sin(a) * 7.4f, stroke)
                }
            }
            else -> {
                canvas.drawCircle(cx, cy, 5.4f, fill)
                fill.color = 0xFFF4ECD8.toInt()
                canvas.drawCircle(cx + 3f, cy - 1.6f, 4.6f, fill)
            }
        }
    }

    private fun drawPaper(canvas: Canvas) {
        // hoja de la farmacia (documento 3): se puede tocar para leerla
        canvas.save()
        canvas.translate(PuzzleLayout.PAPER_X, PuzzleLayout.PAPER_Y)
        canvas.rotate(4f)
        val hw = PuzzleLayout.PAPER_W / 2f
        val hh = PuzzleLayout.PAPER_H / 2f
        fill.color = 0x44000000
        canvas.drawRect(-hw + 2f, -hh + 3f, hw + 2f, hh + 3f, fill)
        fill.color = 0xFFFFFCF0.toInt()
        canvas.drawRect(-hw, -hh, hw, hh, fill)
        stroke.strokeWidth = 0.9f
        stroke.color = 0xFF8A7A6A.toInt()
        canvas.drawRect(-hw, -hh, hw, hh, stroke)
        text.textSize = 4.6f
        text.color = 0xFF2F7A3A.toInt()
        canvas.drawText("FARMACIA", 0f, -hh + 8f, text)
        stroke.color = 0x99806040.toInt()
        var y = -hh + 14f
        for (i in 0 until 6) {
            canvas.drawLine(-hw + 4f, y, hw - 4f - (i % 3) * 4f, y, stroke)
            y += 4.6f
        }
        fill.color = 0xFF4F9A3E.toInt()
        canvas.drawRect(hw - 10f, hh - 9f, hw - 5f, hh - 7.4f, fill)
        canvas.drawRect(hw - 8.4f, hh - 10.6f, hw - 6.6f, hh - 5.8f, fill)
        canvas.restore()
    }

    private fun drawBox(canvas: Canvas, b: PuzzleBox, p: MedicinePuzzle, time: Float) {
        val c = colorsFor(b.itemId)
        val lift = b.lift
        val hw = PuzzleLayout.BOX_W / 2f
        val hh = PuzzleLayout.BOX_H / 2f
        // sombra sobre la mesa: se aleja y se agranda al levantar la caja
        fill.color = ((0x44 - (lift * 0x14).toInt()) shl 24)
        rect.set(b.x - hw + 2f + lift * 5f, b.y - hh + 3f + lift * 7f, b.x + hw + 2f + lift * 5f, b.y + hh + 3f + lift * 7f)
        canvas.drawRoundRect(rect, 2f, 2f, fill)
        canvas.save()
        canvas.translate(b.x, b.y - lift * 4f)
        canvas.rotate(b.tilt)
        val sx = abs(cos(b.flipT * PI.toFloat())) * (1f + 0.06f * lift)
        canvas.scale(maxOf(0.04f, sx), 1f + 0.06f * lift)
        if (b.flipT < 0.5f) drawFront(canvas, b, c) else drawBack(canvas, b, c)
        if (p.solved) {
            val pulse = 0.5f + 0.5f * sin(time * 3f)
            stroke.strokeWidth = 2f
            stroke.color = ((0x99 * (0.5f + 0.5f * pulse)).toInt() shl 24) or 0xFFD27A
            canvas.drawRect(-hw - 1f, -hh - 1f, hw + 1f, hh + 1f, stroke)
        }
        canvas.restore()
    }

    private fun drawFront(canvas: Canvas, b: PuzzleBox, c: BoxColors) {
        val hw = PuzzleLayout.BOX_W / 2f
        val hh = PuzzleLayout.BOX_H / 2f
        fill.color = c.body
        canvas.drawRect(-hw, -hh, hw, hh, fill)
        fill.color = c.light
        canvas.drawRect(-hw, -hh, hw, -hh + 8f, fill)
        canvas.drawRect(-hw, -hh, -hw + 3f, hh, fill)
        fill.color = c.dark
        canvas.drawRect(hw - 3f, -hh + 8f, hw, hh, fill)
        canvas.drawRect(-hw, hh - 3f, hw, hh, fill)
        // etiqueta con la cruz de la farmacia y el nombre inventado
        fill.color = 0xFFF8F2E0.toInt()
        canvas.drawRect(-hw + 6f, -hh + 12f, hw - 6f, hh - 20f, fill)
        fill.color = c.accent
        canvas.drawRect(-1.6f, -hh + 14f, 1.6f, -hh + 24f, fill)
        canvas.drawRect(-5f, -hh + 17.4f, 5f, -hh + 20.6f, fill)
        text.textSize = 5.2f
        text.color = c.dark
        canvas.drawText(b.name, 0f, -hh + 31f, text)
        // insignia con la letra grande de la tapa
        fill.color = c.accent
        canvas.drawCircle(0f, hh - 10.5f, 7.6f, fill)
        text.textSize = 10f
        text.color = 0xFFFFFFFF.toInt()
        canvas.drawText(b.letter.toString(), 0f, hh - 7f, text)
        stroke.strokeWidth = 1.1f
        stroke.color = Palette.OUTLINE
        canvas.drawRect(-hw, -hh, hw, hh, stroke)
    }

    private fun drawBack(canvas: Canvas, b: PuzzleBox, c: BoxColors) {
        val hw = PuzzleLayout.BOX_W / 2f
        val hh = PuzzleLayout.BOX_H / 2f
        fill.color = c.light
        canvas.drawRect(-hw, -hh, hw, hh, fill)
        fill.color = c.dark
        canvas.drawRect(hw - 3f, -hh, hw, hh, fill)
        canvas.drawRect(-hw, hh - 3f, hw, hh, fill)
        // etiqueta posterior: cuándo se toma
        fill.color = 0xFFFFFCF0.toInt()
        canvas.drawRect(-hw + 4f, -hh + 4f, hw - 4f, hh - 4f, fill)
        pictogram(canvas, 0f, -hh + 15f, b.timeSlot, c.dark)
        val lines = when (b.timeSlot) {
            0 -> arrayOf("MAÑANA", "con el", "desayuno")
            1 -> arrayOf("TARDE", "con la", "comida")
            else -> arrayOf("NOCHE", "antes de", "dormir")
        }
        text.color = c.dark
        text.textSize = 6.2f
        canvas.drawText(lines[0], 0f, -hh + 30f, text)
        text.textSize = 5.2f
        text.color = 0xFF5A4A3A.toInt()
        canvas.drawText(lines[1], 0f, -hh + 38f, text)
        canvas.drawText(lines[2], 0f, -hh + 45f, text)
        stroke.strokeWidth = 1.1f
        stroke.color = Palette.OUTLINE
        canvas.drawRect(-hw, -hh, hw, hh, stroke)
    }

    private fun drawHands(canvas: Canvas, p: MedicinePuzzle, time: Float, corruption: Float) {
        val h = GameConfig.LOGICAL_HEIGHT.toFloat()
        val bob = sin(time * 1.6f) * 0.8f
        val kind = p.handKind
        val active = p.dragging
        val activeLeft = if (active != null) active.x < 160f else (p.pointerX < 160f)
        val moving = kind != FirstPersonHands.REST
        // mano en reposo (la que no se usa), apoyada en el borde de la mesa
        if (!moving || !activeLeft) hand(canvas, FirstPersonHands.REST, 30f, h + 4f + bob, true, corruption)
        if (!moving || activeLeft) hand(canvas, FirstPersonHands.REST, 292f, h + 4f - bob, false, corruption)
        if (moving) {
            val x = if (active != null) active.x + (if (activeLeft) -6f else 6f) else p.pointerX
            val bottom = (if (active != null) active.y + 36f else p.pointerY + 34f)
            val bx = x.coerceIn(20f, 300f)
            // el antebrazo sigue hasta el borde inferior de la pantalla
            fill.color = 0xFFF08A2E.toInt()
            canvas.drawRect(bx - 8f, bottom - 2f, bx + 8f, h + 2f, fill)
            fill.color = 0xFFC96A1A.toInt()
            canvas.drawRect(bx + 4f, bottom - 2f, bx + 8f, h + 2f, fill)
            fill.color = 0xFFD03A2E.toInt()
            canvas.drawRect(bx - 8f, bottom + 14f, bx + 8f, bottom + 16f, fill)
            hand(canvas, kind, bx, bottom, activeLeft, corruption)
        }
    }

    private fun hand(canvas: Canvas, kind: Int, cx: Float, bottom: Float, flip: Boolean, corruption: Float) {
        pixels.renderStanding(canvas, FirstPersonHands.get(kind), cx, bottom, 1f, LightingSample.NEUTRAL, corruption, flip)
    }

    private fun drawBackTab(canvas: Canvas) {
        rect.set(PuzzleLayout.BACK_X, PuzzleLayout.BACK_Y, PuzzleLayout.BACK_X + PuzzleLayout.BACK_W, PuzzleLayout.BACK_Y + PuzzleLayout.BACK_H)
        fill.color = 0xE0F4ECD8.toInt()
        canvas.drawRoundRect(rect, 3f, 3f, fill)
        stroke.strokeWidth = 1.1f
        stroke.color = 0xAA402A1E.toInt()
        canvas.drawRoundRect(rect, 3f, 3f, stroke)
        text.textSize = 6.2f
        text.color = 0xFF402A1E.toInt()
        canvas.drawText("< VOLVER", rect.centerX(), rect.centerY() + 2.2f, text)
    }

    // ------------------------------------------------------------------ documentos

    /** Papel legible a pantalla completa; [t] = segundos desde que se abrió (el papel entra deslizándose). */
    fun drawDocument(canvas: Canvas, d: DocumentDef, t: Float) {
        val w = GameConfig.LOGICAL_WIDTH.toFloat()
        val h = GameConfig.LOGICAL_HEIGHT.toFloat()
        val k = (t / 0.25f).coerceIn(0f, 1f)
        fill.color = ((0x99 * k).toInt() shl 24)
        canvas.drawRect(0f, 0f, w, h, fill)
        val lineH = 8.2f
        val bodyH = d.lines.size * lineH
        val noteH = if (d.handwritten != null) 16f else 0f
        val ph = minOf(h - 10f, 38f + bodyH + noteH)
        val pw = 206f
        canvas.save()
        canvas.translate(w / 2f, h / 2f + (1f - k) * 22f)
        canvas.rotate(-1.1f)
        fill.color = 0x55000000
        canvas.drawRect(-pw / 2f + 2f, -ph / 2f + 3f, pw / 2f + 2f, ph / 2f + 3f, fill)
        fill.color = 0xFFFFFCF0.toInt()
        canvas.drawRect(-pw / 2f, -ph / 2f, pw / 2f, ph / 2f, fill)
        stroke.strokeWidth = 1f
        stroke.color = 0xFF8A7A6A.toInt()
        canvas.drawRect(-pw / 2f, -ph / 2f, pw / 2f, ph / 2f, stroke)
        // cabecera y título
        text.textAlign = Paint.Align.CENTER
        text.textSize = 6.4f
        text.color = 0xFF2F5FA8.toInt()
        canvas.drawText(d.header, 0f, -ph / 2f + 11f, text)
        stroke.color = 0x882F5FA8.toInt()
        canvas.drawLine(-pw / 2f + 10f, -ph / 2f + 14f, pw / 2f - 10f, -ph / 2f + 14f, stroke)
        text.textSize = 7.4f
        text.color = 0xFF3A2A20.toInt()
        canvas.drawText(d.title, 0f, -ph / 2f + 26f, text)
        // cuerpo (monoespaciado, alineado a la izquierda)
        text.textAlign = Paint.Align.LEFT
        text.textSize = 6.3f
        text.typeface = Typeface.MONOSPACE
        text.color = 0xFF4A3A2E.toInt()
        var y = -ph / 2f + 38f
        for (line in d.lines) {
            if (line.isNotEmpty()) canvas.drawText(line, -pw / 2f + 12f, y, text)
            y += lineH
        }
        text.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        // nota manuscrita al margen
        val note = d.handwritten
        if (note != null) {
            canvas.save()
            canvas.translate(0f, ph / 2f - 9f)
            canvas.rotate(-2.4f)
            text.textAlign = Paint.Align.CENTER
            text.typeface = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
            text.textSize = 6.6f
            text.color = 0xFF2F5FA8.toInt()
            canvas.drawText(note, 0f, 0f, text)
            text.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            canvas.restore()
        }
        canvas.restore()
        text.textAlign = Paint.Align.CENTER
        text.textSize = 5.4f
        text.color = 0xAAF4ECD8.toInt()
        canvas.drawText("toca para cerrar", w / 2f, h - 4f, text)
    }
}
