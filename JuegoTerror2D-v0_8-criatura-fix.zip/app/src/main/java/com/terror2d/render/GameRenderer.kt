package com.terror2d.render

import android.graphics.Canvas
import android.graphics.Color
import com.terror2d.core.GameConfig
import com.terror2d.core.GameState
import com.terror2d.core.Viewport
import com.terror2d.input.InputController
import com.terror2d.scene.SceneManager

/**
 * Orquesta un frame: barras negras, escala a resolución lógica 320x180, cámara lateral, mundo
 * (fondo -> objetos -> personaje -> iluminación, vía SceneManager), viñeta, texto, HUD y fundido
 * de transición. El estilo visual lo decide [renderer].
 */
class GameRenderer(private val viewport: Viewport) {

    /** Intercambiable en el futuro (CrayonRenderer, GraphiteRenderer...). */
    var renderer: WorldRenderer = CrayonRenderer()

    fun render(
        canvas: Canvas,
        sceneManager: SceneManager,
        state: GameState,
        input: InputController,
        debugText: CharSequence?
    ) {
        canvas.drawColor(Color.BLACK)
        val scene = sceneManager.current ?: return

        canvas.save()
        canvas.translate(viewport.offsetX, viewport.offsetY)
        canvas.scale(viewport.scale, viewport.scale)
        canvas.clipRect(0f, 0f, GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat())

        renderer.beginFrame(canvas, state.visualCorruption, state.elapsedTime)
        renderer.drawBackground()

        // Mundo: coordenadas del mundo -> cámara -> pantalla lógica. En el cambio a PRIMERA PERSONA la cámara
        // "se acerca" a la mesita (zoom hacia ella) y el mundo se funde con la mesa vista desde los ojos del niño.
        val fp = scene.firstPerson
        val blend = fp.blend
        if (blend < 0.98f) {
            canvas.save()
            if (blend > 0.001f) {
                val fx = scene.player.centerX + 16f - scene.camera.snappedX
                val fy = scene.currentSegment.floorY - 34f - scene.camera.snappedY
                val z = 1f + 2.6f * blend
                canvas.translate(fx, fy)
                canvas.scale(z, z)
                canvas.translate(-fx, -fy)
            }
            canvas.translate(-scene.camera.snappedX, -scene.camera.snappedY)
            sceneManager.render(renderer)
            canvas.restore()
        }
        val pz = scene.puzzle
        if (pz != null && blend > 0.02f) {
            renderer.drawPuzzleView(pz, ((blend - 0.35f) / 0.65f).coerceIn(0f, 1f))
        }

        // Escena de conversación (v0.7): negro + manos + peluche, SIN HUD ni texto del mundo.
        val conv = scene.conversation
        if (conv.isActive) {
            renderer.drawConversation(conv)
        } else {
            renderer.releaseConversation()
        }

        // Viñeta, texto, HUD y fundido (coordenadas lógicas de pantalla)
        if (!conv.isActive) {
            renderer.drawVignette()
            val doc = scene.reading
            if (doc != null) renderer.drawDocument(doc, scene.readingTime)
            renderer.drawTextBox(scene.dialogue)
            renderer.drawHud(input)
        }
        renderer.drawFade(scene.transitionAlpha)
        if (debugText != null) renderer.drawDebug(debugText)

        canvas.restore()
    }
}
