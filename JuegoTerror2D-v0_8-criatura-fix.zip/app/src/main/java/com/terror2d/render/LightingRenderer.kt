package com.terror2d.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import com.terror2d.core.GameConfig
import com.terror2d.world.DarkZone
import com.terror2d.world.LightSource

/**
 * Iluminación v0.3: EL MUNDO ES OSCURO, LAS LÁMPARAS PERMITEN VER.
 *
 * No es una viñeta ni un círculo translúcido encima. Cada frame se construye una MÁSCARA DE
 * OSCURIDAD (un bitmap pequeño, la mitad de la resolución lógica):
 *
 *   1. se rellena con el color de la oscuridad de la habitación (casi opaco);
 *   2. cada fuente de luz activa ABRE un agujero suave en esa oscuridad (PorterDuff DST_OUT);
 *   3. las zonas oscuras añaden sombra incluso dentro de la luz;
 *   4. la máscara se dibuja sobre el mundo ya renderizado (fondo, objetos, personaje), de modo
 *      que TODO —suelo, paredes, muebles, puertas, jugador— solo se ve donde llega la luz;
 *   5. por último, cada luz tiñe ligeramente su zona (cálida/fría).
 *
 * Coste: un bitmap de 160x90 reutilizado, un solo shader unitario compartido para los agujeros y
 * un shader cacheado por luz para el tinte. Sin allocations por frame.
 *
 * Orden de dibujo: escena -> objetos -> jugador -> ESTA capa -> viñeta -> HUD.
 */
class LightingRenderer {

    private val zonePaint = Paint().apply {
        style = Paint.Style.FILL
        isAntiAlias = false
    }

    /** Borra (DST_OUT) la oscuridad de la máscara donde dibuja. */
    private val punchPaint = Paint().apply {
        style = Paint.Style.FILL
        isAntiAlias = false
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }

    private val maskPaint = Paint().apply {
        isFilterBitmap = true
        isAntiAlias = false
        isDither = false
    }

    private val tintPaint = Paint().apply {
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private val vignettePaint = Paint().apply {
        style = Paint.Style.FILL
        isAntiAlias = true
    }

    private var maskBitmap: Bitmap? = null
    private var maskCanvas: Canvas? = null
    private var unitPunch: RadialGradient? = null
    private var vignette: RadialGradient? = null

    private val maskSrc = Rect(0, 0, MASK_W, MASK_H)
    private val maskDst = RectF()

    /**
     * En coordenadas del MUNDO (la transformación de cámara ya está aplicada).
     * [camX]/[camY]: esquina de la cámara (la máscara cubre exactamente la pantalla).
     * [extra]: luz adicional que no pertenece al segmento (el resplandor del jugador).
     */
    fun drawWorldLighting(
        canvas: Canvas,
        camX: Float,
        camY: Float,
        ambientDark: Float,
        ambientColor: Int,
        zones: List<DarkZone>,
        lights: List<LightSource>,
        extra: LightSource?,
        time: Float
    ) {
        val bmp = ensureMask()
        val mc = maskCanvas ?: return

        // 1. Oscuridad ambiental
        bmp.eraseColor(argb(ambientDark.coerceIn(0f, 1f) * 255f, ambientColor))

        // 2. Las luces abren la oscuridad
        for (i in 0 until lights.size) punch(mc, lights[i], camX, camY, time)
        if (extra != null) punch(mc, extra, camX, camY, time)

        // 3. Zonas oscuras: sombra que ni la luz elimina del todo
        for (i in 0 until zones.size) drawDarkZone(mc, zones[i], camX, camY, ambientColor)

        // 4. La máscara cubre el mundo ya dibujado
        maskDst.set(camX, camY, camX + GameConfig.LOGICAL_WIDTH, camY + GameConfig.LOGICAL_HEIGHT)
        canvas.drawBitmap(bmp, maskSrc, maskDst, maskPaint)

        // 5. Tinte cálido/frío de cada luz (solo donde la luz llega)
        for (i in 0 until lights.size) tint(canvas, lights[i], camX, camY, time)
    }

    private fun ensureMask(): Bitmap {
        var b = maskBitmap
        if (b == null) {
            b = Bitmap.createBitmap(MASK_W, MASK_H, Bitmap.Config.ARGB_8888)
            maskBitmap = b
            maskCanvas = Canvas(b)
            // Perfil de caída: centro pleno, meseta y desvanecido suave hasta el borde.
            unitPunch = RadialGradient(
                0f, 0f, 1f,
                intArrayOf(0xFF000000.toInt(), 0xE6000000.toInt(), 0x96000000.toInt(), 0x3C000000, 0x00000000),
                floatArrayOf(0f, 0.22f, 0.5f, 0.78f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        return b
    }

    private fun punch(mc: Canvas, l: LightSource, camX: Float, camY: Float, time: Float) {
        val k = l.effectiveIntensity(time)
        if (k <= 0.003f) return
        val sx = (l.x - camX) * MASK_SCALE
        val sy = (l.y - camY) * MASK_SCALE
        val r = l.radius * MASK_SCALE
        if (sx + r < 0f || sx - r > MASK_W || sy + r < 0f || sy - r > MASK_H) return
        punchPaint.shader = unitPunch
        punchPaint.alpha = (k * 255f).toInt().coerceIn(0, 255)
        mc.save()
        mc.translate(sx, sy)
        mc.scale(r, r)
        mc.drawCircle(0f, 0f, 1f, punchPaint)
        mc.restore()
    }

    /** Zona oscura con borde "de crayón": tres capas apiladas, cada una más pequeña. */
    private fun drawDarkZone(mc: Canvas, z: DarkZone, camX: Float, camY: Float, color: Int) {
        val a = z.strength.coerceIn(0f, 1f) * 255f * 0.30f
        zonePaint.color = argb(a, color)
        var inset = 0f
        for (layer in 0 until 3) {
            val w = z.width - inset * 2f
            val h = z.height - inset * 2f
            if (w <= 0f || h <= 0f) break
            val l = (z.x + inset - camX) * MASK_SCALE
            val t = (z.y + inset - camY) * MASK_SCALE
            mc.drawRect(l, t, l + w * MASK_SCALE, t + h * MASK_SCALE, zonePaint)
            inset += 7f
        }
    }

    private fun tint(canvas: Canvas, l: LightSource, camX: Float, camY: Float, time: Float) {
        if (l.tintStrength <= 0f) return
        val k = l.effectiveIntensity(time) * l.tintStrength
        if (k <= 0.003f) return
        if (l.x + l.radius < camX || l.x - l.radius > camX + GameConfig.LOGICAL_WIDTH) return
        var g = l.renderCache as RadialGradient?
        if (g == null) {
            val rgb = l.color and 0x00FFFFFF
            g = RadialGradient(
                0f, 0f, l.radius,
                intArrayOf((0x40 shl 24) or rgb, (0x1C shl 24) or rgb, rgb),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
            l.renderCache = g
        }
        tintPaint.shader = g
        tintPaint.alpha = (k * 255f).toInt().coerceIn(0, 255)
        canvas.save()
        canvas.translate(l.x, l.y)
        canvas.drawCircle(0f, 0f, l.radius, tintPaint)
        canvas.restore()
        tintPaint.shader = null
    }

    /** Viñeta de pantalla (coordenadas lógicas): bordes algo más oscuros, centro intacto. */
    fun drawVignette(canvas: Canvas) {
        var g = vignette
        if (g == null) {
            val cx = GameConfig.LOGICAL_WIDTH / 2f
            val cy = GameConfig.LOGICAL_HEIGHT / 2f
            val edge = Palette.VIGNETTE_EDGE
            g = RadialGradient(
                cx, cy, 190f,
                intArrayOf(edge and 0x00FFFFFF, edge and 0x00FFFFFF, edge),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            vignette = g
        }
        vignettePaint.shader = g
        canvas.drawRect(0f, 0f, GameConfig.LOGICAL_WIDTH.toFloat(), GameConfig.LOGICAL_HEIGHT.toFloat(), vignettePaint)
        vignettePaint.shader = null
    }

    private fun argb(alpha: Float, rgb: Int): Int =
        (alpha.toInt().coerceIn(0, 255) shl 24) or (rgb and 0x00FFFFFF)

    companion object {
        /** La máscara tiene la mitad de la resolución lógica (suave y barata). */
        const val MASK_W = GameConfig.LOGICAL_WIDTH / 2
        const val MASK_H = GameConfig.LOGICAL_HEIGHT / 2
        const val MASK_SCALE = 0.5f
    }
}
