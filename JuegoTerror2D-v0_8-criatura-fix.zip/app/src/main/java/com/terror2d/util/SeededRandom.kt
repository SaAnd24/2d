package com.terror2d.util

private val GOLDEN: Long = 0x9E3779B97F4A7C15UL.toLong()
private val MUL1: Long = 0xBF58476D1CE4E5B9UL.toLong()
private val MUL2: Long = 0x94D049BB133111EBUL.toLong()

/**
 * Generador pseudoaleatorio determinista (SplitMix64).
 * MISMA SEMILLA = MISMA SECUENCIA, en cualquier dispositivo.
 *
 * Uso permitido: imperfecciones visuales, trazos secundarios, textura, decoración.
 * NO usar para gameplay (puzzles, eventos, posiciones críticas, progresión...).
 */
class SeededRandom(seed: Long) {
    private var state: Long = seed

    fun nextLong(): Long {
        state += GOLDEN
        return mix(state)
    }

    fun nextInt(): Int = (nextLong() ushr 32).toInt()

    fun nextInt(bound: Int): Int {
        require(bound > 0) { "bound debe ser > 0" }
        return ((nextLong() ushr 33) % bound.toLong()).toInt()
    }

    /** Float en [0, 1). */
    fun nextFloat(): Float = (nextLong() ushr 40).toInt() / 16777216f

    fun nextFloat(min: Float, max: Float): Float = min + (max - min) * nextFloat()

    /** Float en [-1, 1). */
    fun nextSigned(): Float = nextFloat() * 2f - 1f

    fun nextBoolean(): Boolean = (nextLong() ushr 63) == 1L

    companion object {
        /** Mezcla de 64 bits sin estado (función hash). */
        fun mix(value: Long): Long {
            var z = value
            z = (z xor (z ushr 30)) * MUL1
            z = (z xor (z ushr 27)) * MUL2
            return z xor (z ushr 31)
        }

        /** Deriva una semilla hija estable a partir de una semilla base y una sal. */
        fun derive(seed: Long, salt: Int): Long =
            mix(seed xor mix(salt.toLong() + 0x1234567L))
    }
}
