package com.terror2d.core

import kotlin.math.floor
import kotlin.math.min

/**
 * Relación entre la resolución lógica (320x180) y la pantalla real.
 * Mantiene la proporción (letterbox) y evita deformaciones.
 */
class Viewport {
    @Volatile var screenWidth: Int = 1
    @Volatile var screenHeight: Int = 1
    @Volatile var scale: Float = 1f
    @Volatile var offsetX: Float = 0f
    @Volatile var offsetY: Float = 0f

    fun update(width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        screenWidth = width
        screenHeight = height
        var s = min(
            width.toFloat() / GameConfig.LOGICAL_WIDTH,
            height.toFloat() / GameConfig.LOGICAL_HEIGHT
        )
        if (GameConfig.INTEGER_SCALING && s >= 1f) s = floor(s)
        scale = s
        offsetX = (width - GameConfig.LOGICAL_WIDTH * s) / 2f
        offsetY = (height - GameConfig.LOGICAL_HEIGHT * s) / 2f
    }

    fun toLogicalX(screenX: Float): Float = (screenX - offsetX) / scale

    fun toLogicalY(screenY: Float): Float = (screenY - offsetY) / scale
}
