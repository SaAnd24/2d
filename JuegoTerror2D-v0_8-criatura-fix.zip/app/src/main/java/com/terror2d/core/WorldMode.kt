package com.terror2d.core

/**
 * Los dos mundos del juego. v0.5 SOLO prepara la arquitectura: todo ocurre en [NORMAL].
 *
 * NORMAL = terror infantil colorido (crayón). TRAUMA (futuro) = gris/negro, líneas fuertes, perspectiva
 * incorrecta: los mismos lugares, mal reconstruidos. No son "bueno" y "malo": son dos manifestaciones del horror.
 * Un objeto o una acción de un mundo podrá resolver un problema del otro.
 */
enum class WorldMode {
    NORMAL,
    TRAUMA
}
