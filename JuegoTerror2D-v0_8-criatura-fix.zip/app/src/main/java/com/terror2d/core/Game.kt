package com.terror2d.core

import android.graphics.Canvas
import com.terror2d.audio.AndroidAudioSink
import com.terror2d.audio.AudioDirector
import com.terror2d.audio.AudioEngine
import com.terror2d.audio.Surface
import com.terror2d.input.InputController
import com.terror2d.render.GameRenderer
import com.terror2d.scene.SceneManager
import com.terror2d.scene.HouseDefinition
import com.terror2d.scene.HouseScene

/**
 * Controlador principal: coordina estado, escena actual, input, update y render.
 * No contiene lógica de juego; la delega en SceneManager / Scene.
 */
class Game {
    val state = GameState()
    val input = InputController()
    val viewport = Viewport()
    val sceneManager = SceneManager(state)
    private val gameRenderer = GameRenderer(viewport)

    /**
     * v0.7: motor de audio procedural. Arranca/para con el ciclo de vida de la app ([resumeAudio]/[pauseAudio]); toda
     * la síntesis ocurre en su propio hilo, nunca en el del juego ni en el de render.
     */
    val audio = AudioEngine(AndroidAudioSink())
    private var lastWorld = state.worldMode

    // Debug (sin allocations por frame: StringBuilder reutilizado)
    private val debugText = StringBuilder(160)
    private var fpsFrames = 0
    private var fpsTimer = 0L
    private var fps = 0

    init {
        // GAMEPLAY -> EVENTO -> AudioDirector -> AudioEngine: la lógica solo publica eventos y pide audio de alto nivel
        state.audio = audio
        state.audioListener = AudioDirector(audio) { sceneManager.current?.footstepSurface ?: Surface.WOOD }
        sceneManager.register(HouseDefinition.ID) { HouseScene() }
        sceneManager.loadScene(HouseDefinition.ID)
    }

    /** Un paso de simulación con deltaTime (segundos). */
    fun update(dt: Float) {
        state.elapsedTime += dt
        if (state.worldMode != lastWorld) {
            lastWorld = state.worldMode
            audio.setWorld(lastWorld)
        }
        sceneManager.update(dt, input)
        input.endFrame()
    }

    fun resumeAudio() {
        audio.start()
    }

    fun pauseAudio() {
        audio.stop()
    }

    /** Libera el audio definitivamente (la actividad se destruye). */
    fun releaseAudio() {
        audio.release()
    }

    fun render(canvas: Canvas) {
        if (GameConfig.DEBUG_OVERLAY) updateDebug()
        gameRenderer.render(canvas, sceneManager, state, input, if (GameConfig.DEBUG_OVERLAY) debugText else null)
    }

    private fun updateDebug() {
        val now = System.nanoTime()
        fpsFrames++
        if (fpsTimer == 0L) fpsTimer = now
        if (now - fpsTimer >= 500_000_000L) {
            fps = (fpsFrames * 1_000_000_000L / (now - fpsTimer)).toInt()
            fpsFrames = 0
            fpsTimer = now
            debugText.setLength(0)
            debugText.append("FPS ").append(fps)
                .append("  ").append(state.currentSegmentId)
                .append("  X ").append(state.playerX.toInt())
                .append("  C ").append(state.visualCorruption)
                .append(if (state.playerHidden) "  HIDDEN" else "")
                .append("  ").append(state.lastEvent)
        }
    }
}
