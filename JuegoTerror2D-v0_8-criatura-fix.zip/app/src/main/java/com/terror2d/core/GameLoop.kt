package com.terror2d.core

import android.view.SurfaceHolder

/**
 * Game Loop con paso fijo de simulación (60 Hz) y render desacoplado.
 * Calcula deltaTime, acumula, ejecuta update() en pasos fijos y luego render().
 */
class GameLoop(
    private val holder: SurfaceHolder,
    private val game: Game
) : Thread("GameLoop") {

    @Volatile
    private var running = false

    fun startLoop() {
        running = true
        start()
    }

    fun stopLoop() {
        running = false
        var joined = false
        while (!joined) {
            try {
                join()
                joined = true
            } catch (e: InterruptedException) {
                // reintentar
            }
        }
    }

    override fun run() {
        val frameNs = 1_000_000_000L / GameConfig.TARGET_FPS
        var last = System.nanoTime()
        var accumulator = 0f

        while (running) {
            val frameStart = System.nanoTime()
            var dt = (frameStart - last) / 1_000_000_000f
            last = frameStart
            if (dt > GameConfig.MAX_FRAME_TIME) dt = GameConfig.MAX_FRAME_TIME

            // --- update (paso fijo) ---
            accumulator += dt
            var steps = 0
            while (accumulator >= GameConfig.FIXED_STEP && steps < GameConfig.MAX_STEPS_PER_FRAME) {
                game.update(GameConfig.FIXED_STEP)
                accumulator -= GameConfig.FIXED_STEP
                steps++
            }
            if (steps >= GameConfig.MAX_STEPS_PER_FRAME) accumulator = 0f

            // --- render ---
            val canvas = try {
                holder.lockCanvas()
            } catch (e: Exception) {
                null
            }
            if (canvas != null) {
                try {
                    game.render(canvas)
                } finally {
                    try {
                        holder.unlockCanvasAndPost(canvas)
                    } catch (e: IllegalStateException) {
                        // superficie destruida durante el frame
                    }
                }
            }

            // --- limitador de FPS ---
            val sleepNs = frameNs - (System.nanoTime() - frameStart)
            if (sleepNs > 0) {
                try {
                    sleep(sleepNs / 1_000_000L, (sleepNs % 1_000_000L).toInt())
                } catch (e: InterruptedException) {
                    // ignorar
                }
            }
        }
    }
}
