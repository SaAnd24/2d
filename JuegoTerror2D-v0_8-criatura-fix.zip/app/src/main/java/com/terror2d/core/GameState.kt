package com.terror2d.core

import com.terror2d.audio.AudioPort
import com.terror2d.audio.NullAudioPort
import com.terror2d.events.EventListener
import com.terror2d.inventory.Inventory
import com.terror2d.story.StoryState

/**
 * Estado global del juego. Sigue siendo mínimo.
 * Futuro: progreso, inventario, flags, estado narrativo, guardado.
 */
class GameState {
    var currentSceneId: String = ""

    /** Segmento lateral activo dentro de la escena actual. */
    var currentSegmentId: String = ""

    var playerX: Float = 0f
    var playerY: Float = 0f

    /** v0.4: hitos narrativos (introducción, y más adelante medicamentos, puzzle, etc.). */
    val story = StoryState()

    /** v0.5: inventario reutilizable (y objeto en las manos). */
    val inventory = Inventory()

    /**
     * v0.7: puerto de audio (peticiones de alto nivel). La lógica de juego NUNCA sintetiza: pide eventos de audio.
     * Por defecto es silencio; [Game] instala el motor real.
     */
    var audio: AudioPort = NullAudioPort

    /** v0.7: oyente de eventos que traduce el juego a audio (AudioDirector). Las escenas lo conectan a su bus. */
    var audioListener: EventListener? = null

    /** v0.5: mundo activo. Solo NORMAL existe todavía; TRAUMA está preparado en la arquitectura. */
    var worldMode: WorldMode = WorldMode.NORMAL

    /** v0.8: cuántas veces la criatura ha atrapado al niño (el dormitorio puede cambiar un poco tras cada captura). */
    var captureCount: Int = 0

    /** v0.3: el jugador está escondido dentro de un armario. */
    var playerHidden: Boolean = false

    /** v0.3: descripción del último evento del juego (depuración). */
    var lastEvent: String = ""

    /** Tiempo de juego acumulado (segundos). */
    var elapsedTime: Float = 0f

    /**
     * 0.0 = visualmente normal, 1.0 = completamente deteriorado.
     * En v0.3 permanece en 0.0. Futuras versiones lo usarán para saturación,
     * textura, grafito, rasguños, distorsión y sombras.
     */
    var visualCorruption: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
        }
}
