package com.terror2d.conversation

import com.terror2d.audio.AudioPort
import com.terror2d.audio.NullAudioPort
import com.terror2d.audio.SfxId
import com.terror2d.audio.VoiceId
import com.terror2d.audio.VoiceSynth

/**
 * ESCENA DE CONVERSACIÓN en primera persona (v0.7): fondo casi negro, las manos del niño y el peluche.
 *
 *   NONE -> ENTERING (fundido a negro) -> RUNNING (líneas) -> LEAVING (vuelta al gameplay) -> NONE
 *
 * Es solo la máquina de estados (sin Android, como [com.terror2d.scene.FirstPersonView]): el renderer lee
 * [blend], [handTremorIntensity], [breathingIntensity] y el texto; la escena la consulta para congelar al niño.
 * El peluche NO tiene ningún parámetro de animación: permanece completamente inmóvil. Lo vivo son las MANOS
 * ([breathingIntensity], [handTremorIntensity]), y esos dos números pueden subirlos futuras escenas para aumentar el miedo.
 */
class ConversationView {

    enum class Phase { NONE, ENTERING, RUNNING, LEAVING }

    private enum class Sub { LEAD, SOUND, GAP, TEXT, WAIT }

    var phase: Phase = Phase.NONE
        private set

    var def: ConversationDef? = null
        private set

    private var audio: AudioPort = NullAudioPort
    private var timer = 0f
    private var lineIndex = 0
    private var sub = Sub.LEAD
    private var subTimer = 0f

    // runner de sonidos vocales de la línea actual
    private var cueIdx = 0
    private var cueTimer = 0f

    /** Línea en pantalla (null fuera de una línea). */
    var line: ConversationLine? = null
        private set

    /** Texto ya mostrado (efecto máquina de escribir). */
    var visibleChars: Int = 0
        private set

    /** Incrementa con cada línea nueva (el renderer recalcula el ajuste de texto). */
    var lineSerial: Int = 0
        private set

    /** Segundos de escena (animan respiración y temblor de las manos). */
    var time: Float = 0f
        private set

    /** Respiración de las manos (0..1): subida/bajada y pequeños cambios de posición. Configurable por escena. */
    var breathingIntensity: Float = BASE_BREATHING
        private set

    /** Temblor de las manos (0..1). Configurable por escena. */
    var handTremorIntensity: Float = BASE_TREMOR
        private set

    private var breathingTarget = BASE_BREATHING
    private var tremorTarget = BASE_TREMOR

    val isActive: Boolean get() = phase != Phase.NONE

    /** El jugador puede tocar para continuar. */
    val waitingForTap: Boolean get() = phase == Phase.RUNNING && sub == Sub.WAIT

    /** 0 = mundo, 1 = escena de conversación completa (suavizado). */
    val blend: Float
        get() = when (phase) {
            Phase.NONE -> 0f
            Phase.ENTERING -> smooth(timer / ENTER_TIME)
            Phase.RUNNING -> 1f
            Phase.LEAVING -> 1f - smooth(timer / LEAVE_TIME)
        }

    /** Fija la respiración/temblor base de la escena (futuras escenas más tensas). */
    fun setHandState(breathing: Float, tremor: Float) {
        breathingTarget = breathing.coerceIn(0f, 1f)
        tremorTarget = tremor.coerceIn(0f, 1f)
    }

    fun begin(d: ConversationDef, port: AudioPort) {
        if (phase != Phase.NONE) return
        def = d
        audio = port
        phase = if (d.transition == ConversationTransition.CUT) Phase.RUNNING else Phase.ENTERING
        timer = 0f
        time = 0f
        lineIndex = -1
        line = null
        visibleChars = 0
        breathingIntensity = BASE_BREATHING
        handTremorIntensity = BASE_TREMOR
        breathingTarget = BASE_BREATHING
        tremorTarget = BASE_TREMOR
        if (phase == Phase.RUNNING) nextLine()
    }

    /**
     * Avanza. [tap] = el jugador ha tocado la pantalla. Devuelve true UNA vez: justo al terminar la vuelta al gameplay.
     */
    fun update(dt: Float, tap: Boolean): Boolean {
        if (phase == Phase.NONE) return false
        time += dt
        approach(dt)
        when (phase) {
            Phase.ENTERING -> {
                timer += dt
                if (timer >= ENTER_TIME) {
                    phase = Phase.RUNNING
                    timer = 0f
                    nextLine()
                }
            }
            Phase.RUNNING -> updateLine(dt, tap)
            Phase.LEAVING -> {
                timer += dt
                if (timer >= LEAVE_TIME) {
                    phase = Phase.NONE
                    timer = 0f
                    line = null
                    def = null
                    audio = NullAudioPort
                    return true
                }
            }
            else -> {}
        }
        return false
    }

    private fun approach(dt: Float) {
        val k = RAMP * dt
        breathingIntensity = move(breathingIntensity, breathingTarget, k)
        handTremorIntensity = move(handTremorIntensity, tremorTarget, k)
    }

    private fun move(v: Float, t: Float, k: Float): Float = if (v < t - k) v + k else if (v > t + k) v - k else t

    private fun nextLine() {
        val d = def ?: return
        lineIndex++
        if (lineIndex >= d.lines.size) {
            // fin: el texto se desvanece y las manos devuelven la mirada al mundo
            phase = Phase.LEAVING
            timer = 0f
            line = null
            tremorTarget = BASE_TREMOR
            breathingTarget = BASE_BREATHING
            return
        }
        val l = d.lines[lineIndex]
        line = l
        lineSerial++
        visibleChars = 0
        sub = Sub.LEAD
        subTimer = 0f
        startCues()
    }

    private fun startCues() {
        cueIdx = 0
        cueTimer = 0f
    }

    /** Dispara los sonidos vocales uno tras otro. Devuelve true cuando ya han sonado todos y ha pasado su pausa. */
    private fun updateCues(dt: Float): Boolean {
        val l = line ?: return true
        val d = def ?: return true
        cueTimer -= dt
        if (cueTimer > 0f) return false
        if (cueIdx >= l.cues.size) return true
        val c = l.cues[cueIdx++]
        val voice = if (l.speaker == Speaker.CHILD) VoiceId.CHILD else d.voice
        audio.playVoice(voice, c.emotion, (c.intensity * d.intensity).coerceIn(0f, 1f), c.kind, c.units, lineSerial * 31 + cueIdx)
        cueTimer = VoiceSynth.estimateSeconds(c.kind, c.units, c.emotion, voice) + c.pauseAfter
        return false
    }

    private fun updateLine(dt: Float, tap: Boolean) {
        val l = line ?: return
        subTimer += dt
        when (sub) {
            Sub.LEAD -> if (subTimer >= l.leadSilence) {
                subTimer = 0f
                if (l.soundWithText || l.cues.isEmpty()) {
                    enterGap(l)
                } else {
                    sub = Sub.SOUND
                    startCues()
                }
            }
            Sub.SOUND -> if (updateCues(dt)) enterGap(l)
            Sub.GAP -> if (subTimer >= l.gapAfterSound) {
                sub = Sub.TEXT
                subTimer = 0f
                visibleChars = 0
                if (l.soundWithText) startCues()
            }
            Sub.TEXT -> {
                if (l.soundWithText) updateCues(dt)
                val n = (subTimer * CHARS_PER_SECOND).toInt()
                visibleChars = if (n > l.text.length) l.text.length else n
                if (tap && subTimer > 0.15f) visibleChars = l.text.length
                if (visibleChars >= l.text.length) {
                    sub = Sub.WAIT
                    subTimer = 0f
                }
            }
            Sub.WAIT -> {
                if (l.soundWithText) updateCues(dt)
                val auto = l.autoAdvance > 0f && subTimer >= l.autoAdvance
                if ((tap && subTimer > MIN_WAIT) || auto) nextLine()
            }
        }
    }

    private fun enterGap(l: ConversationLine) {
        sub = Sub.GAP
        subTimer = 0f
        if (l.tremor >= 0f) tremorTarget = l.tremor
        if (l.breathing >= 0f) breathingTarget = l.breathing
        if (l.breathSfx) audio.playSfx(SfxId.BREATH, 1f)
        if (l.soundWithText && l.gapAfterSound <= 0f) {
            // sin silencio previo: el texto empieza ya
            sub = Sub.TEXT
            startCues()
        }
    }

    /** Fuerza el final inmediato (p. ej. al descargar la escena). */
    fun abort() {
        phase = Phase.NONE
        timer = 0f
        line = null
        def = null
        audio = NullAudioPort
        tremorTarget = BASE_TREMOR
        breathingTarget = BASE_BREATHING
        handTremorIntensity = BASE_TREMOR
        breathingIntensity = BASE_BREATHING
    }

    private fun smooth(t: Float): Float {
        val c = t.coerceIn(0f, 1f)
        return c * c * (3f - 2f * c)
    }

    companion object {
        const val ENTER_TIME = 1.1f
        const val LEAVE_TIME = 0.9f
        const val CHARS_PER_SECOND = 26f
        const val MIN_WAIT = 0.35f
        const val RAMP = 0.45f             // cambio máximo de intensidad por segundo (temblor/respiración)
        const val BASE_BREATHING = 0.35f
        const val BASE_TREMOR = 0.12f      // un niño nervioso: casi imperceptible
    }
}
