package com.terror2d.conversation

import com.terror2d.audio.Emotion
import com.terror2d.audio.VoiceId
import com.terror2d.audio.VoiceKind
import com.terror2d.core.GameState
import com.terror2d.core.WorldMode
import com.terror2d.events.EventType
import com.terror2d.events.GameEvent

/** Quién dice una línea de la escena de conversación. */
enum class Speaker { COMPANION, CHILD }

/** Cómo se entra a la escena (hoy solo hay fundido a negro; CUT queda preparado para futuras escenas bruscas). */
enum class ConversationTransition { FADE_TO_BLACK, CUT }

/**
 * Un sonido vocal sintético del compañero ("Mmm...", "hm"). El texto NO se pronuncia: la voz solo da feedback
 * emocional. [units]: sílabas (BABBLE) o ~0.25 s por unidad (HUM).
 */
class VoiceCue(
    val kind: VoiceKind,
    val units: Int,
    val emotion: Emotion,
    val intensity: Float,
    val pauseAfter: Float = 0.12f
)

/**
 * Una línea de una conversación. El ritmo de una línea del compañero es:
 *   silencio inicial -> sonido(s) -> silencio ([gapAfterSound], con respiración/temblor) -> texto -> espera al toque.
 * Las líneas del niño ([Speaker.CHILD]) suenan A LA VEZ que su texto ([soundWithText]).
 */
class ConversationLine(
    val speaker: Speaker,
    val text: String,
    val cues: List<VoiceCue> = emptyList(),
    val leadSilence: Float = 0.4f,
    val gapAfterSound: Float = 0.3f,
    /** Objetivo de temblor de manos desde esta línea (0..1); negativo = no cambiar. */
    val tremor: Float = -1f,
    /** Objetivo de respiración de las manos (0..1); negativo = no cambiar. */
    val breathing: Float = -1f,
    /** Suena una respiración al empezar el silencio previo al texto. */
    val breathSfx: Boolean = false,
    val soundWithText: Boolean = speaker == Speaker.CHILD,
    /** Segundos que se espera tras mostrar todo el texto antes de pasar solo a la siguiente (0 = esperar un toque). */
    val autoAdvance: Float = 0f
)

/**
 * Definición de una conversación: DATOS puros. Añadir conversaciones nuevas = añadir definiciones, no código.
 *
 * @param triggerType evento que la dispara (null = solo manual, desde HABLAR).
 * @param triggerSource fuente concreta del evento (null = cualquiera).
 * @param manual disponible al pulsar HABLAR CON [compañero].
 * @param condition condición extra sobre el estado del juego (p. ej. el compañero a la espalda y manos vacías).
 * @param voice perfil de voz del compañero en esta conversación.
 * @param intensity multiplica la intensidad de sus sonidos.
 * @param delay pausa (segundos de calma) entre el disparador y el inicio de la conversación.
 * @param cooldown segundos mínimos desde que terminó la última vez.
 * @param repeatable si puede repetirse; si no, solo se reproduce una vez.
 * @param priority si hay varias listas, gana la de mayor prioridad.
 * @param context mundo en el que puede ocurrir (null = en cualquiera).
 */
class ConversationDef(
    val id: String,
    val lines: List<ConversationLine>,
    val triggerType: EventType? = null,
    val triggerSource: String? = null,
    val manual: Boolean = false,
    val condition: (GameState) -> Boolean = { true },
    val voice: VoiceId = VoiceId.FROG,
    val intensity: Float = 1f,
    val delay: Float = 1.2f,
    val transition: ConversationTransition = ConversationTransition.FADE_TO_BLACK,
    val cooldown: Float = 0f,
    val repeatable: Boolean = false,
    val priority: Int = 0,
    val context: WorldMode? = null
)

/**
 * Cola y reglas de las conversaciones (lógica pura, sin Android). Recibe eventos, decide cuándo una conversación
 * pendiente puede empezar (calma + condición + pausa) y recuerda cuáles ya se han reproducido.
 *
 * Los disparadores temporales de 0.7 (agua entregada, puzzle completado) son solo DEFINICIONES: se sustituyen por
 * condiciones narrativas definitivas cambiando datos, sin tocar este sistema.
 */
class ConversationSystem(val defs: List<ConversationDef>) {

    private class Pending(val def: ConversationDef, var timer: Float)

    private val pending = ArrayList<Pending>()
    private val played = HashMap<String, Int>()
    private val lastEnd = HashMap<String, Float>()
    private var clock = 0f

    val pendingCount: Int get() = pending.size

    fun timesPlayed(id: String): Int = played[id] ?: 0

    fun isPending(id: String): Boolean {
        for (i in 0 until pending.size) if (pending[i].def.id == id) return true
        return false
    }

    /** ¿Puede reproducirse todavía (no agotada y fuera de cooldown)? No mira la condición de estado. */
    fun available(def: ConversationDef): Boolean {
        if (!def.repeatable && timesPlayed(def.id) > 0) return false
        val end = lastEnd[def.id]
        return end == null || clock - end >= def.cooldown
    }

    private fun conditionOk(def: ConversationDef, state: GameState): Boolean =
        (def.context == null || def.context == state.worldMode) && def.condition(state)

    /** Un evento del juego: encola las conversaciones que dispara. */
    fun onEvent(e: GameEvent) {
        for (i in 0 until defs.size) {
            val d = defs[i]
            val t = d.triggerType ?: continue
            if (t != e.type) continue
            if (d.triggerSource != null && d.triggerSource != e.sourceId) continue
            if (!available(d) || isPending(d.id)) continue
            pending.add(Pending(d, d.delay))
        }
    }

    /**
     * Avanza las pendientes. [quiet] = el mundo está en calma (sin texto, transición, puzzle ni documento). La pausa
     * previa solo corre mientras hay calma Y la condición se cumple; si algo la interrumpe, vuelve a empezar.
     * Devuelve la conversación que debe empezar ahora (o null).
     */
    fun update(dt: Float, quiet: Boolean, state: GameState): ConversationDef? {
        clock += dt
        if (pending.isEmpty()) return null
        var best: Pending? = null
        var i = 0
        while (i < pending.size) {
            val p = pending[i]
            if (!available(p.def) && !p.def.repeatable) {
                pending.removeAt(i)
                continue
            }
            if (quiet && conditionOk(p.def, state)) p.timer -= dt else p.timer = p.def.delay
            if (p.timer <= 0f && (best == null || p.def.priority > best.def.priority)) best = p
            i++
        }
        if (best != null) {
            pending.remove(best)
            return best.def
        }
        return null
    }

    /** HABLAR: la conversación manual disponible de mayor prioridad (null si no hay ninguna). */
    fun requestManual(state: GameState): ConversationDef? {
        var best: ConversationDef? = null
        for (i in 0 until defs.size) {
            val d = defs[i]
            if (!d.manual || !available(d) || !conditionOk(d, state)) continue
            if (best == null || d.priority > best.priority) best = d
        }
        return best
    }

    fun markStarted(def: ConversationDef) {
        played[def.id] = timesPlayed(def.id) + 1
        // si estaba pendiente (p. ej. se eligió HABLAR mientras esperaba), ya no hace falta
        var i = 0
        while (i < pending.size) {
            if (pending[i].def.id == def.id) pending.removeAt(i) else i++
        }
    }

    fun markEnded(def: ConversationDef) {
        lastEnd[def.id] = clock
    }
}
