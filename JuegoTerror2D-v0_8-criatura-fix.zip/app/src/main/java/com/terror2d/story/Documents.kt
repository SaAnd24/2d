package com.terror2d.story

import com.terror2d.ui.DialogueLine

/**
 * Un documento legible de la casa (v0.6). Los documentos son sobre todo para que el JUGADOR entienda la situación;
 * el niño de 8 años no comprende casi nada y reacciona como un niño ([reaction]: frases sencillas, nunca una
 * explicación de la enfermedad). Todos los nombres son inventados (sin marcas ni logos reales).
 */
class DocumentDef(
    val id: String,
    /** Cabecera del papel (clínica, aviso, farmacia...). */
    val header: String,
    val title: String,
    /** Líneas de texto del documento (máx. ~34 caracteres por línea para que quepan en la pantalla lógica). */
    val lines: List<String>,
    /** Nota manuscrita al margen (opcional). */
    val handwritten: String?,
    /** Lo que dice el niño al cerrarlo. */
    val reaction: List<DialogueLine>,
    /** Hito que se activa al leerlo. */
    val readFlag: String,
    /** Dónde está en la casa (para documentación y tests). */
    val location: String
)

/** Los TRES documentos relevantes de esta fase: médico, económico y farmacia/tratamiento. */
object Documents {
    const val MEDICAL = "doc_medical"
    const val FINANCE = "doc_finance"
    const val PHARMACY = "doc_pharmacy"

    val medical = DocumentDef(
        id = MEDICAL,
        header = "CLÍNICA DEL VALLE",
        title = "Consulta de seguimiento",
        lines = listOf(
            "Paciente: M. R.",
            "Fecha: 12 de marzo",
            "Consulta: control mensual",
            "",
            "Tratamiento: continuar el",
            "esquema actual. Ajuste de la",
            "dosis de la noche.",
            "",
            "Indicaciones: reposo. Evitar",
            "esfuerzos. Anotar los dolores.",
            "",
            "Observaciones: sin cambios.",
            "Próxima cita en 3 meses."
        ),
        handwritten = null,
        reaction = listOf(DialogueLine(null, "No entiendo…")),
        readFlag = StoryFlags.READ_DOC_MEDICAL,
        location = "MomRoom: cómoda de mamá"
    )

    val finance = DocumentDef(
        id = FINANCE,
        header = "CENTRO MÉDICO DEL VALLE",
        title = "SEGUNDO AVISO DE PAGO",
        lines = listOf(
            "Concepto: tratamiento del mes",
            "Importe:               842,00",
            "Saldo anterior:        638,00",
            "",
            "TOTAL ADEUDADO:      1.480,00",
            "",
            "Vence: 28 de marzo.",
            "Pasada esa fecha se aplicarán",
            "recargos y se suspenderá la",
            "próxima consulta."
        ),
        handwritten = "Pagar la mitad esta semana. Luego vemos.",
        reaction = listOf(
            DialogueLine(null, "¿Por qué mamá tiene tantas cartas?"),
            DialogueLine(null, "Tienen números grandes y rayas rojas.")
        ),
        readFlag = StoryFlags.READ_DOC_FINANCE,
        location = "Kitchen: mesa de la cocina"
    )

    val pharmacy = DocumentDef(
        id = PHARMACY,
        header = "FARMACIA DE LA ESQUINA",
        title = "Hoja de tratamiento",
        lines = listOf(
            "Una caja para cada momento del",
            "día. Colócalas siempre así,",
            "de izquierda a derecha:",
            "",
            "1  el sol que sale  = MAÑANA",
            "2  el sol bien alto = TARDE",
            "3  la luna          = NOCHE",
            "",
            "Cada caja dice por detrás",
            "cuándo se toma.",
            "No mezclar. No saltarse ninguna."
        ),
        handwritten = null,
        reaction = listOf(DialogueLine(null, "¿Otra vez las medicinas?")),
        readFlag = StoryFlags.READ_DOC_PHARMACY,
        location = "MomRoom: mesita de mamá (puzzle de las cajas)"
    )

    /** EXACTAMENTE tres documentos en la casa en esta fase. */
    val ALL: List<DocumentDef> = listOf(medical, finance, pharmacy)

    fun get(id: String): DocumentDef? = ALL.firstOrNull { it.id == id }
}
