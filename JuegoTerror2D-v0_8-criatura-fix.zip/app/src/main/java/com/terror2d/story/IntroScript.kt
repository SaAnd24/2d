package com.terror2d.story

import com.terror2d.events.EventType
import com.terror2d.events.GameEvent

/**
 * Introducción de v0.4. El juego empieza en la habitación del niño; tras unos momentos la madre lo
 * llama desde otra habitación, con cariño y de forma cotidiana:
 *
 *   "Cariño, ¿puedes ayudarme?"  ->  "Ya es hora de mis pastillas."  ->  "¿Me traes un poco de agua también?"
 *
 * Cada línea se dice UNA sola vez (los hitos de [StoryState] lo garantizan, aunque se cambie de
 * habitación o se vuelva a la inicial). Los tiempos solo avanzan mientras no hay texto en pantalla.
 */
class IntroScript(private val startRoom: String) : SceneScript {

    private var timer = 0f
    private var stage = 0

    override fun onEvent(e: GameEvent, ctx: ScriptContext) {
        if (e.type == EventType.ON_ENTER_ROOM && e.sourceId == startRoom) {
            if (ctx.state.story.set(StoryFlags.INTRO_STARTED)) {
                timer = 0f
                stage = 0
            }
        }
    }

    override fun update(dt: Float, ctx: ScriptContext) {
        val story = ctx.state.story
        if (!story.has(StoryFlags.INTRO_STARTED) || story.has(StoryFlags.INTRO_CALLS_DONE)) return
        if (ctx.dialogue.isActive) return
        timer += dt
        when (stage) {
            0 -> if (timer >= FIRST_CALL_DELAY) {
                ctx.dialogue.showMessage("Cariño, ¿puedes ayudarme?", MOM)
                ctx.setFlag(StoryFlags.HEARD_CALL)
                stage = 1
                timer = 0f
            }
            1 -> if (timer >= SECOND_CALL_DELAY) {
                ctx.dialogue.showMessage("Ya es hora de mis pastillas.", MOM)
                ctx.setFlag(StoryFlags.HEARD_PILLS)
                stage = 2
                timer = 0f
            }
            2 -> if (timer >= THIRD_CALL_DELAY) {
                ctx.dialogue.showMessage("¿Me traes un poco de agua también?", MOM)
                ctx.setFlag(StoryFlags.HEARD_WATER)
                stage = 3
                timer = 0f
            }
            3 -> if (timer >= REPLY_DELAY) {
                ctx.dialogue.showMessage("Ya voy, mamá. Voy a buscar agua.")
                ctx.setFlag(StoryFlags.INTRO_CALLS_DONE)
                stage = 4
            }
        }
    }

    companion object {
        const val MOM = "MAMÁ"
        const val FIRST_CALL_DELAY = 5f
        const val SECOND_CALL_DELAY = 6f
        const val THIRD_CALL_DELAY = 7f
        const val REPLY_DELAY = 1.2f
    }
}
