package com.terror2d.draw

import com.terror2d.scene.FloorPattern
import com.terror2d.scene.RoomSegment
import com.terror2d.scene.WallPattern
import com.terror2d.util.SeededRandom

/**
 * Genera el fondo de un segmento (pared, suelo, rodapié, manchas) como tramos de 160 px, todos con
 * trazos de crayón: varias pasadas, presión variable, motas de papel, manchas y patrones dibujados
 * a mano. Cada tramo usa su propia semilla derivada: misma semilla = mismo fondo, y el renderer
 * solo dibuja los tramos visibles.
 */
object BackdropBuilder {

    const val CHUNK = 160

    fun build(seg: RoomSegment, seed: Long): Array<CrayonSprite> {
        val n = ((seg.width + CHUNK - 1) / CHUNK).toInt()
        return Array(n) { i -> buildChunk(seg, i, SeededRandom(SeededRandom.derive(seed, 0x1000 + i))) }
    }

    private fun buildChunk(seg: RoomSegment, index: Int, rng: SeededRandom): CrayonSprite {
        val b = CrayonBuilder(rng)
        val x0 = (index * CHUNK).toFloat()
        val x1 = minOf(seg.width, x0 + CHUNK)
        val w = x1 - x0
        val fy = seg.floorY
        val h = seg.height

        // --- Pared: base + frotado vertical en dos pasadas + frotado horizontal suave
        b.fillRect(x0, 0f, w, fy, seg.wallColor)
        b.hatchRect(x0, 0f, w, fy, seg.wallStrokeColor, 6.5f, true)
        b.hatchRect(x0, 0f, w, fy, seg.wallStrokeColor and 0x55FFFFFF, 11f, false)

        wallPattern(b, rng, seg, x0, x1, fy)

        // --- Sombra del techo (bandas translúcidas) y garabato de presión en el borde
        b.fillRect(x0, 0f, w, 8f, 0x22000000)
        b.fillRect(x0, 0f, w, 18f, 0x22000000)
        b.fillRect(x0, 0f, w, 32f, 0x1A000000)
        b.fillRect(x0, 0f, w, 50f, 0x14000000)
        b.scribble(x0, 0f, w, 6f, 0x40000000, 7, 1.4f)

        // --- Manchas de humedad / de crayón en la pared (1 o 2 por tramo)
        val stains = 1 + rng.nextInt(2)
        for (i in 0 until stains) {
            b.smudge(x0 + rng.nextFloat(10f, w - 10f), rng.nextFloat(30f, fy - 30f), rng.nextFloat(8f, 20f), rng.nextFloat(6f, 14f), 0x14000000)
        }

        // --- Suelo
        b.fillRect(x0, fy, w, h - fy, seg.floorColor)
        b.hatchRect(x0, fy, w, h - fy, seg.floorStrokeColor, 4.5f)
        floorPattern(b, rng, seg, x0, x1, fy, h)

        // --- Rodapié con doble línea
        b.fillRect(x0, fy - 8f, w, 8f, 0xFF7A5A48.toInt())
        b.hatchRect(x0, fy - 8f, w, 8f, 0xFF4A3426.toInt(), 3f)
        b.line(x0, fy - 8f, x1, fy - 8f, CrayonBuilder.INK, 1.2f)
        b.line(x0, fy, x1, fy, CrayonBuilder.INK, 1.3f)
        b.line(x0, fy - 7f, x1, fy - 6.5f, 0x55000000, 1f)

        // --- Motas de papel
        b.dots(x0, 0f, w, h, (w * h / 700f).toInt(), 0x30FFFFFF, 1f)
        b.dots(x0, 0f, w, h, (w * h / 900f).toInt(), 0x22000000, 1f)

        // --- Muros laterales del segmento
        if (seg.leftBoundary > x0) edge(b, x0, minOf(seg.leftBoundary, x1), h)
        if (seg.rightBoundary < x1 && seg.rightBoundary < seg.width) edge(b, maxOf(seg.rightBoundary, x0), x1, h)
        return b.finish()
    }

    private fun edge(b: CrayonBuilder, xa: Float, xb: Float, h: Float) {
        if (xb <= xa) return
        b.fillRect(xa, 0f, xb - xa, h, 0xFF3A2C52.toInt())
        b.hatchRect(xa, 0f, xb - xa, h, 0xFF22183A.toInt(), 4f, true)
        b.line(if (xa == 0f) xb else xa, 0f, if (xa == 0f) xb else xa, h, CrayonBuilder.INK, 1.2f)
    }

    private fun firstMultiple(x0: Float, step: Float): Float {
        var k = (x0 / step).toInt() * step
        if (k < x0) k += step
        return k
    }

    private fun wallPattern(b: CrayonBuilder, rng: SeededRandom, seg: RoomSegment, x0: Float, x1: Float, fy: Float) {
        val accent = seg.wallAccent
        when (seg.wallPattern) {
            WallPattern.PLAIN -> {}
            WallPattern.STRIPES -> {
                var x = firstMultiple(x0, 22f)
                while (x < x1) {
                    b.line(x + rng.nextSigned(), 0f, x + rng.nextSigned() * 2f, fy - 8f, accent and 0x99FFFFFF.toInt(), 3.2f, 0.8f)
                    x += 22f
                }
            }
            WallPattern.DOTS -> {
                val pts = ArrayList<Float>()
                var yy = 14f
                var row = 0
                while (yy < fy - 12f) {
                    var x = firstMultiple(x0, 20f) + (if (row % 2 == 0) 0f else 10f)
                    while (x < x1) {
                        pts.add(x + rng.nextSigned() * 1.2f)
                        pts.add(yy + rng.nextSigned() * 1.2f)
                        x += 20f
                    }
                    yy += 17f
                    row++
                }
                b.dotsAt(pts.toFloatArray(), accent and 0xAAFFFFFF.toInt(), 4f)
            }
            WallPattern.FLOWERS -> {
                val petals = ArrayList<Float>()
                val centers = ArrayList<Float>()
                val stems = ArrayList<Float>()
                var x = firstMultiple(x0, 38f) + 10f
                var row = 0
                while (x < x1) {
                    var yy = 26f + (row % 2) * 16f
                    while (yy < fy - 24f) {
                        // pétalos irregulares: a veces 4, 5 o 7 (flores "mal dibujadas")
                        val count = 4 + rng.nextInt(4)
                        for (k in 0 until count) {
                            val a = k * 6.2832f / count + rng.nextSigned() * 0.25f
                            petals.add(x + kotlin.math.cos(a) * (3.4f + rng.nextSigned() * 0.8f))
                            petals.add(yy + kotlin.math.sin(a) * (3.4f + rng.nextSigned() * 0.8f))
                        }
                        centers.add(x)
                        centers.add(yy)
                        stems.add(x)
                        stems.add(yy + 4f)
                        stems.add(x + rng.nextSigned() * 2f)
                        stems.add(yy + 12f)
                        yy += 40f
                    }
                    x += 38f
                    row++
                }
                b.strokes(stems.toFloatArray(), 0x884F9A3E.toInt(), 1.2f)
                b.dotsAt(petals.toFloatArray(), accent and 0xCCFFFFFF.toInt(), 3.2f)
                b.dotsAt(centers.toFloatArray(), 0xCCF2C94C.toInt(), 2.4f)
            }
            WallPattern.TILES -> {
                val lines = ArrayList<Float>()
                var yy = 56f
                while (yy < fy - 8f) {
                    lines.add(x0); lines.add(yy + rng.nextSigned() * 0.5f)
                    lines.add(x1); lines.add(yy + rng.nextSigned() * 0.5f)
                    yy += 14f
                }
                var x = firstMultiple(x0, 14f)
                while (x < x1) {
                    lines.add(x + rng.nextSigned() * 0.4f); lines.add(56f)
                    lines.add(x + rng.nextSigned() * 0.4f); lines.add(fy - 8f)
                    x += 14f
                }
                // la mitad de arriba de la pared sigue pintada: una línea de remate de azulejos
                b.fillRect(x0, 54f, x1 - x0, 4f, accent)
                b.strokes(lines.toFloatArray(), accent and 0xCCFFFFFF.toInt(), 1.1f)
                b.fillRect(x0, 56f, x1 - x0, fy - 64f, 0x12FFFFFF)
            }
            WallPattern.PLANKS -> {
                val lines = ArrayList<Float>()
                var x = firstMultiple(x0, 24f)
                while (x < x1) {
                    lines.add(x + rng.nextSigned()); lines.add(0f)
                    lines.add(x + rng.nextSigned() * 1.5f); lines.add(fy - 8f)
                    x += 24f
                }
                b.strokes(lines.toFloatArray(), accent and 0xCCFFFFFF.toInt(), 1.5f)
                // nudos de la madera
                b.dots(x0, 8f, x1 - x0, fy - 24f, 3, 0x66000000, 4f)
            }
        }
    }

    private fun floorPattern(b: CrayonBuilder, rng: SeededRandom, seg: RoomSegment, x0: Float, x1: Float, fy: Float, h: Float) {
        val accent = seg.floorAccent
        when (seg.floorPattern) {
            FloorPattern.WOOD -> {
                val lines = ArrayList<Float>()
                val rows = 2
                for (r in 1..rows) {
                    val yy = fy + r * (h - fy) / (rows + 1)
                    lines.add(x0); lines.add(yy)
                    lines.add(x1); lines.add(yy + rng.nextSigned() * 0.7f)
                }
                var x = firstMultiple(x0, 56f)
                while (x < x1) {
                    lines.add(x); lines.add(fy)
                    lines.add(x + rng.nextSigned()); lines.add(fy + (h - fy) / 3f)
                    x += 56f
                }
                b.strokes(lines.toFloatArray(), accent and 0xAAFFFFFF.toInt(), 1.2f)
            }
            FloorPattern.TILES -> {
                val tile = 20f
                var x = firstMultiple(x0, tile)
                var xi = (x / tile).toInt()
                while (x < x1) {
                    for (r in 0 until 2) {
                        if ((xi + r) % 2 == 0) b.fillRect(x, fy + r * 17f, tile, 17f, accent and 0x55FFFFFF.toInt())
                    }
                    x += tile
                    xi++
                }
                val lines = ArrayList<Float>()
                x = firstMultiple(x0, tile)
                while (x < x1) {
                    lines.add(x); lines.add(fy); lines.add(x + rng.nextSigned() * 0.4f); lines.add(h)
                    x += tile
                }
                lines.add(x0); lines.add(fy + 17f); lines.add(x1); lines.add(fy + 17f)
                b.strokes(lines.toFloatArray(), 0x66000000, 1.1f)
            }
            FloorPattern.CONCRETE -> {
                b.scribble(x0, fy + 2f, x1 - x0, h - fy - 4f, 0x33000000, 9, 1.1f)
                b.dots(x0, fy, x1 - x0, h - fy, 26, 0x40000000, 1.6f)
            }
            FloorPattern.CARPET -> {
                b.hatchRect(x0, fy, x1 - x0, h - fy, accent and 0x88FFFFFF.toInt(), 2.4f, true)
                b.dots(x0, fy, x1 - x0, h - fy, 22, accent and 0xAAFFFFFF.toInt(), 2f)
            }
        }
    }
}
