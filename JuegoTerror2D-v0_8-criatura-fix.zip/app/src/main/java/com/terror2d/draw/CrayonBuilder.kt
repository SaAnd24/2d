package com.terror2d.draw

import com.terror2d.render.Palette
import com.terror2d.util.SeededRandom
import com.terror2d.world.SketchBuilder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Tipos de operación de dibujo de un [CrayonSprite]. */
object CrayonKind {
    const val FILL_RECT = 0
    const val FILL_OVAL = 1
    const val FILL_POLY = 2
    const val STROKES = 3
    const val DOTS = 4
}

/**
 * Una operación de dibujo precalculada: solo DATOS (sin clases de Android), para que el aspecto
 * se genere una sola vez con [SeededRandom] y el renderizador únicamente lo recorra.
 */
class CrayonOp(
    @JvmField val kind: Int,
    @JvmField val color: Int,
    @JvmField val width: Float,
    @JvmField val data: FloatArray
) {
    /** Caché reservada al renderizador (p. ej. el Path de un polígono). */
    @JvmField var cache: Any? = null
}

/** Dibujo de crayón ya generado: lista ordenada de operaciones. */
class CrayonSprite(@JvmField val ops: Array<CrayonOp>) {

    /** Huella del contenido (misma semilla => mismo valor). Usada en tests. */
    fun hash(seed: Long): Long {
        var h = seed
        for (i in ops.indices) {
            val op = ops[i]
            h = 31L * h + op.kind
            h = 31L * h + op.color
            val d = op.data
            for (j in d.indices) h = 31L * h + d[j].toRawBits().toLong()
        }
        return h
    }

    companion object {
        val EMPTY = CrayonSprite(emptyArray<CrayonOp>())
    }
}

/**
 * Constructor de dibujos de crayón. Todo el azar sale del [SeededRandom] recibido: misma semilla =
 * mismo dibujo. Se usa SOLO al preparar los visuales (nunca por frame).
 *
 * Un relleno "de crayón" son: base de color + trazos inclinados en dos pasadas con distinta presión
 * + contorno doble imperfecto que se pasa un poco de las esquinas.
 */
class CrayonBuilder(private val rng: SeededRandom) {

    private val ops = ArrayList<CrayonOp>()

    fun finish(): CrayonSprite = CrayonSprite(ops.toTypedArray())

    val opCount: Int get() = ops.size

    // ------------------------------------------------------------------ primitivas

    fun fillRect(x: Float, y: Float, w: Float, h: Float, color: Int) {
        ops.add(CrayonOp(CrayonKind.FILL_RECT, color, 0f, floatArrayOf(x, y, x + w, y + h)))
    }

    fun fillOval(cx: Float, cy: Float, rx: Float, ry: Float, color: Int) {
        ops.add(CrayonOp(CrayonKind.FILL_OVAL, color, 0f, floatArrayOf(cx - rx, cy - ry, cx + rx, cy + ry)))
    }

    fun fillPoly(pts: FloatArray, color: Int) {
        ops.add(CrayonOp(CrayonKind.FILL_POLY, color, 0f, pts))
    }

    fun strokes(lines: FloatArray, color: Int, width: Float) {
        if (lines.isNotEmpty()) ops.add(CrayonOp(CrayonKind.STROKES, color, width, lines))
    }

    fun dotsAt(pts: FloatArray, color: Int, size: Float) {
        if (pts.isNotEmpty()) ops.add(CrayonOp(CrayonKind.DOTS, color, size, pts))
    }

    /** Línea ligeramente temblorosa (se parte en tramos con pequeñas desviaciones). */
    fun line(x1: Float, y1: Float, x2: Float, y2: Float, color: Int = INK, width: Float = 1.2f, wobble: Float = 0.55f) {
        val dx = x2 - x1
        val dy = y2 - y1
        val len = sqrt(dx * dx + dy * dy)
        val n = max(1, (len / 9f).toInt())
        val arr = FloatArray(n * 4)
        var px = x1
        var py = y1
        for (i in 0 until n) {
            val t = (i + 1) / n.toFloat()
            var nx = x1 + dx * t
            var ny = y1 + dy * t
            if (i < n - 1) {
                nx += rng.nextSigned() * wobble
                ny += rng.nextSigned() * wobble
            }
            arr[i * 4] = px
            arr[i * 4 + 1] = py
            arr[i * 4 + 2] = nx
            arr[i * 4 + 3] = ny
            px = nx
            py = ny
        }
        strokes(arr, color, width)
    }

    // ------------------------------------------------------------------ rellenos de trazos

    /** Trazos casi horizontales (o verticales) en dos pasadas con distinta presión. */
    fun hatchRect(x: Float, y: Float, w: Float, h: Float, color: Int, spacing: Float = 3.5f, vertical: Boolean = false) {
        val span = if (vertical) w else h
        val count = max(1, (span / spacing).toInt())
        val na = (count + 1) / 2
        val nb = count / 2
        val a = FloatArray(na * 4)
        val b = FloatArray(nb * 4)
        for (i in 0 until count) {
            val t = (i + 0.5f) * spacing
            val s0 = rng.nextFloat(0f, 2.4f)
            val s1 = rng.nextFloat(0f, 2.4f)
            val j1 = rng.nextSigned() * 0.7f
            val j2 = rng.nextSigned() * 1.1f
            val arr = if (i % 2 == 0) a else b
            val k = (i / 2) * 4
            if (vertical) {
                arr[k] = x + t + j1
                arr[k + 1] = y + 0.5f + s0
                arr[k + 2] = x + t + j2
                arr[k + 3] = y + h - 0.5f - s1
            } else {
                arr[k] = x + 0.5f + s0
                arr[k + 1] = y + t + j1
                arr[k + 2] = x + w - 0.5f - s1
                arr[k + 3] = y + t + j2
            }
        }
        val rgb = color and 0x00FFFFFF
        strokes(a, (0xB8 shl 24) or rgb, 1.5f)
        strokes(b, (0x70 shl 24) or rgb, 1.3f)
    }

    fun hatchOval(cx: Float, cy: Float, rx: Float, ry: Float, color: Int, spacing: Float = 3.5f) {
        val count = max(1, (2f * ry / spacing).toInt())
        val rgb = color and 0x00FFFFFF
        val arr = FloatArray(count * 4)
        var n = 0
        for (i in 0 until count) {
            val yy = cy - ry + (i + 0.5f) * spacing
            val t = (yy - cy) / ry
            val inside = 1f - t * t
            if (inside <= 0.02f) continue
            val hw = rx * sqrt(inside)
            if (hw < 1.2f) continue
            arr[n * 4] = cx - hw + rng.nextFloat(0f, 1.6f)
            arr[n * 4 + 1] = yy + rng.nextSigned() * 0.6f
            arr[n * 4 + 2] = cx + hw - rng.nextFloat(0f, 1.6f)
            arr[n * 4 + 3] = yy + rng.nextSigned() * 1.0f
            n++
        }
        if (n > 0) strokes(arr.copyOf(n * 4), (0xB0 shl 24) or rgb, 1.5f)
    }

    /** Trazos que rellenan un polígono cualquiera (barrido por líneas, regla par-impar). */
    fun hatchPoly(pts: FloatArray, color: Int, spacing: Float = 3.5f) {
        val np = pts.size / 2
        if (np < 3) return
        var minY = pts[1]
        var maxY = pts[1]
        for (i in 1 until np) {
            minY = min(minY, pts[i * 2 + 1])
            maxY = max(maxY, pts[i * 2 + 1])
        }
        val rows = max(1, ((maxY - minY) / spacing).toInt())
        val out = FloatArray(rows * 4 * 4)
        var n = 0
        val xs = FloatArray(16)
        for (r in 0 until rows) {
            val yy = minY + (r + 0.5f) * spacing
            var c = 0
            for (i in 0 until np) {
                val j = (i + 1) % np
                val y1 = pts[i * 2 + 1]
                val y2 = pts[j * 2 + 1]
                if ((y1 <= yy && y2 > yy) || (y2 <= yy && y1 > yy)) {
                    if (c < xs.size) {
                        xs[c] = pts[i * 2] + (yy - y1) * (pts[j * 2] - pts[i * 2]) / (y2 - y1)
                        c++
                    }
                }
            }
            for (a in 1 until c) {
                val v = xs[a]
                var b = a - 1
                while (b >= 0 && xs[b] > v) {
                    xs[b + 1] = xs[b]
                    b--
                }
                xs[b + 1] = v
            }
            var k = 0
            while (k + 1 < c && (n + 1) * 4 <= out.size) {
                out[n * 4] = xs[k] + rng.nextFloat(0f, 1.4f)
                out[n * 4 + 1] = yy + rng.nextSigned() * 0.6f
                out[n * 4 + 2] = xs[k + 1] - rng.nextFloat(0f, 1.4f)
                out[n * 4 + 3] = yy + rng.nextSigned() * 1.0f
                n++
                k += 2
            }
        }
        if (n > 0) strokes(out.copyOf(n * 4), (0xB0 shl 24) or (color and 0x00FFFFFF), 1.5f)
    }

    // ------------------------------------------------------------------ contornos imperfectos

    fun outlineRect(x: Float, y: Float, w: Float, h: Float, color: Int = INK, width: Float = 1.1f) {
        strokes(SketchBuilder.buildOutline(x, y, w, h, rng), color, width)
    }

    /** Óvalo dibujado en dos pasadas, con desfase y radio irregular; el trazo no cierra del todo. */
    fun outlineOval(cx: Float, cy: Float, rx: Float, ry: Float, color: Int = INK, width: Float = 1.1f) {
        val segs = 16
        val arr = FloatArray(segs * 4 * 2)
        for (pass in 0 until 2) {
            val phase = rng.nextFloat(0f, 6.283f)
            val jit = 0.35f + pass * 0.45f
            var px = 0f
            var py = 0f
            for (i in 0..segs) {
                val a = phase + i * (2f * PI.toFloat() / segs) * (0.97f + pass * 0.03f)
                val k = 1f + rng.nextSigned() * jit / max(max(rx, ry), 1f)
                val nx = cx + cos(a) * rx * k
                val ny = cy + sin(a) * ry * k
                if (i > 0) {
                    val base = (pass * segs + (i - 1)) * 4
                    arr[base] = px
                    arr[base + 1] = py
                    arr[base + 2] = nx
                    arr[base + 3] = ny
                }
                px = nx
                py = ny
            }
        }
        strokes(arr, color, width)
    }

    fun outlinePoly(pts: FloatArray, color: Int = INK, width: Float = 1.1f) {
        val np = pts.size / 2
        if (np < 2) return
        val arr = FloatArray(np * 4 * 2)
        for (pass in 0 until 2) {
            val j = 0.5f + pass * 0.6f
            for (i in 0 until np) {
                val k = (i + 1) % np
                val x1 = pts[i * 2] + rng.nextSigned() * j
                val y1 = pts[i * 2 + 1] + rng.nextSigned() * j
                val dx = pts[k * 2] - pts[i * 2]
                val dy = pts[k * 2 + 1] - pts[i * 2 + 1]
                val len = max(0.001f, sqrt(dx * dx + dy * dy))
                val over = rng.nextFloat(0f, 1.4f)
                val base = (pass * np + i) * 4
                arr[base] = x1
                arr[base + 1] = y1
                arr[base + 2] = pts[k * 2] + dx / len * over + rng.nextSigned() * j
                arr[base + 3] = pts[k * 2 + 1] + dy / len * over + rng.nextSigned() * j
            }
        }
        strokes(arr, color, width)
    }

    // ------------------------------------------------------------------ formas compuestas

    /** Caja de crayón: base + trazos en dos direcciones + contorno doble. [hatch] = 0 -> tono más oscuro del relleno. */
    fun box(x: Float, y: Float, w: Float, h: Float, fill: Int, hatch: Int = 0, outline: Int = INK, spacing: Float = 3.5f) {
        val hc = if (hatch == 0) darker(fill) else hatch
        fillRect(x, y, w, h, fill)
        hatchRect(x, y, w, h, hc, spacing)
        if (w > 12f && h > 12f) hatchRect(x + 1f, y + 1f, w - 2f, h - 2f, hc and 0x66FFFFFF, spacing * 2.6f, true)
        outlineRect(x, y, w, h, outline)
    }

    fun ball(cx: Float, cy: Float, rx: Float, ry: Float, fill: Int, hatch: Int = 0, outline: Int = INK, spacing: Float = 3.5f) {
        val hc = if (hatch == 0) darker(fill) else hatch
        fillOval(cx, cy, rx, ry, fill)
        hatchOval(cx, cy, rx, ry, hc, spacing)
        outlineOval(cx, cy, rx, ry, outline)
    }

    fun poly(pts: FloatArray, fill: Int, hatch: Int = 0, outline: Int = INK, spacing: Float = 3.5f) {
        val hc = if (hatch == 0) darker(fill) else hatch
        fillPoly(pts, fill)
        hatchPoly(pts, hc, spacing)
        outlinePoly(pts, outline)
    }

    /** Garabato: zigzag aleatorio dentro de un rectángulo. */
    fun scribble(x: Float, y: Float, w: Float, h: Float, color: Int, n: Int = 6, width: Float = 1.2f) {
        val arr = FloatArray(n * 4)
        var px = x + rng.nextFloat(0f, w)
        var py = y + rng.nextFloat(0f, h)
        for (i in 0 until n) {
            val nx = x + rng.nextFloat(0f, w)
            val ny = y + rng.nextFloat(0f, h)
            arr[i * 4] = px
            arr[i * 4 + 1] = py
            arr[i * 4 + 2] = nx
            arr[i * 4 + 3] = ny
            px = nx
            py = ny
        }
        strokes(arr, color, width)
    }

    fun spiral(cx: Float, cy: Float, r: Float, color: Int, width: Float = 1.4f) {
        val segs = 34
        val arr = FloatArray(segs * 4)
        var px = cx
        var py = cy
        for (i in 0 until segs) {
            val t = (i + 1) / segs.toFloat()
            val ang = t * 3.4f * 2f * PI.toFloat()
            val rr = r * t + rng.nextSigned() * 0.5f
            val nx = cx + cos(ang) * rr
            val ny = cy + sin(ang) * rr
            arr[i * 4] = px
            arr[i * 4 + 1] = py
            arr[i * 4 + 2] = nx
            arr[i * 4 + 3] = ny
            px = nx
            py = ny
        }
        strokes(arr, color, width)
    }

    /** Mancha translúcida (el color lleva su alfa). */
    fun smudge(cx: Float, cy: Float, rx: Float, ry: Float, color: Int) {
        fillOval(cx, cy, rx, ry, color)
    }

    /** Puntos repartidos al azar dentro de un rectángulo. */
    fun dots(x: Float, y: Float, w: Float, h: Float, count: Int, color: Int, size: Float = 1.5f) {
        val arr = FloatArray(count * 2)
        for (i in 0 until count) {
            arr[i * 2] = x + rng.nextFloat(0f, w)
            arr[i * 2 + 1] = y + rng.nextFloat(0f, h)
        }
        dotsAt(arr, color, size)
    }

    fun cross(cx: Float, cy: Float, r: Float, color: Int, width: Float = 1.6f) {
        line(cx - r, cy, cx + r, cy, color, width, 0.2f)
        line(cx, cy - r, cx, cy + r, color, width, 0.2f)
    }

    fun star(cx: Float, cy: Float, r: Float, color: Int, width: Float = 1.3f) {
        val arr = FloatArray(5 * 4)
        for (i in 0 until 5) {
            val a0 = (-PI / 2.0 + i * 4.0 * PI / 5.0).toFloat()
            val a1 = (-PI / 2.0 + (i + 1) * 4.0 * PI / 5.0).toFloat()
            arr[i * 4] = cx + cos(a0) * r + rng.nextSigned() * 0.4f
            arr[i * 4 + 1] = cy + sin(a0) * r + rng.nextSigned() * 0.4f
            arr[i * 4 + 2] = cx + cos(a1) * r + rng.nextSigned() * 0.4f
            arr[i * 4 + 3] = cy + sin(a1) * r + rng.nextSigned() * 0.4f
        }
        strokes(arr, color, width)
    }

    /** Sonrisa en arco; con [teeth] se dibujan dientecitos (demasiados: es la sonrisa incómoda). */
    fun smile(cx: Float, cy: Float, halfW: Float, depth: Float, color: Int = INK, teeth: Boolean = false) {
        val segs = 8
        val arr = FloatArray(segs * 4)
        var px = cx - halfW
        var py = cy
        for (i in 0 until segs) {
            val t = (i + 1) / segs.toFloat()
            val nx = cx - halfW + 2f * halfW * t
            val u = 2f * t - 1f
            val ny = cy + depth * (1f - u * u) + rng.nextSigned() * 0.25f
            arr[i * 4] = px
            arr[i * 4 + 1] = py
            arr[i * 4 + 2] = nx
            arr[i * 4 + 3] = ny
            px = nx
            py = ny
        }
        strokes(arr, color, 1.3f)
        if (teeth) {
            val n = 7
            val tt = FloatArray(n * 4)
            for (i in 0 until n) {
                val t = (i + 0.5f) / n
                val u = 2f * t - 1f
                val x = cx - halfW + 2f * halfW * t
                val y = cy + depth * (1f - u * u)
                tt[i * 4] = x
                tt[i * 4 + 1] = y
                tt[i * 4 + 2] = x
                tt[i * 4 + 3] = y - depth * 0.55f
            }
            strokes(tt, color, 1f)
        }
    }

    /**
     * Carita de dibujo infantil. [mood]: 0 = sonrisa pequeña, 1 = sonrisa DEMASIADO grande con
     * dientes, 2 = boca recta, 3 = sin boca (solo ojos enormes). Los ojos siempre son un poco grandes.
     */
    fun face(cx: Float, cy: Float, r: Float, skin: Int, mood: Int, ink: Int = INK) {
        ball(cx, cy, r, r * 1.05f, skin, 0, ink, 3f)
        val ex = r * 0.38f
        val er = r * 0.27f
        for (s in 0 until 2) {
            val sx = if (s == 0) cx - ex else cx + ex
            fillOval(sx, cy - r * 0.15f, er, er * 1.1f, 0xFFFFFFFF.toInt())
            outlineOval(sx, cy - r * 0.15f, er, er * 1.1f, ink, 0.9f)
            fillOval(sx + (if (s == 0) 0.6f else -0.4f), cy - r * 0.1f, er * 0.45f, er * 0.55f, ink)
        }
        when (mood) {
            0 -> smile(cx, cy + r * 0.38f, r * 0.34f, r * 0.2f, ink, false)
            1 -> smile(cx, cy + r * 0.3f, r * 0.72f, r * 0.42f, ink, true)
            2 -> line(cx - r * 0.3f, cy + r * 0.5f, cx + r * 0.3f, cy + r * 0.5f, ink, 1.2f, 0.2f)
            else -> {}
        }
    }

    companion object {
        const val INK = Palette.OUTLINE

        /** Mismo color con menor luminosidad (para los trazos de sombreado). */
        fun darker(c: Int, f: Float = 0.74f): Int {
            val r = (((c shr 16) and 0xFF) * f).toInt()
            val g = (((c shr 8) and 0xFF) * f).toInt()
            val b = ((c and 0xFF) * f).toInt()
            return (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }

        fun lighter(c: Int, f: Float = 0.35f): Int {
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            return (0xFF shl 24) or
                ((r + ((255 - r) * f).toInt()) shl 16) or
                ((g + ((255 - g) * f).toInt()) shl 8) or
                (b + ((255 - b) * f).toInt())
        }

        fun withAlpha(c: Int, a: Int): Int = (a.coerceIn(0, 255) shl 24) or (c and 0x00FFFFFF)
    }
}
