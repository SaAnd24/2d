package com.terror2d.pixel

/**
 * LA CRIATURA (v0.8, rediseño) en pixel art. USA LA MISMA DENSIDAD QUE EL NIÑO: [SCALE] es exactamente la escala del
 * protagonista (1 píxel de sprite = 0,5 px lógicos). No se parece en nada a la escena de Ranita en primera
 * persona (640×360): ahí un píxel de arte mide 0,5 px lógicos pero el dibujo es ~30 veces más detallado en un
 * encuadre cercano; aquí la criatura es mucho más grande (160×176) pero cada píxel pesa lo mismo que los del niño.
 *
 * Datos: [CreatureSpriteData] (generado por tools/sprite_gen/creature.py con el motor pixelado procedural; la app NO
 * contiene ninguna imagen de la criatura). Capas: brazo trasero, cuerpo (una pose por frame de la caminata), cabeza
 * (2 variantes), ojos, boca principal (sonrisa) y las 7 bocas del vientre, cada una con su parche y sus 4 estados,
 * para que se animen por separado sin redibujar la criatura. Brazo delantero al final.
 */
object CreatureSprite {
    const val SCALE = ProtagonistSprite.SCALE
    const val BODY_W = CreatureSpriteData.BODY_W
    const val BODY_H = CreatureSpriteData.BODY_H
    /** Columna del cuerpo que cae sobre el centro de la criatura (la cadera). */
    const val ANCHOR_X = CreatureSpriteData.ANCHOR_X
    val SECONDARY_MOUTHS: Int = CreatureSpriteData.HEAD_MOUTHS.size + CreatureSpriteData.TORSO_MOUTHS.size

    val PALETTE: IntArray = CreatureSpriteData.PALETTE

    val bodies: Array<IntArray> by lazy { Array(CreatureSpriteData.BODY_DATA.size) { SpriteCodec.decode(CreatureSpriteData.BODY_DATA[it], BODY_W * BODY_H) } }

    /** Brazos recortados: índice = balanceo * ARM_BEND.size + codo (ver [armIndex]). */
    val armLead: Array<IntArray> by lazy { decodeArms(CreatureSpriteData.ARM_LEAD, CreatureSpriteData.ARM_LEAD_INFO) }
    val armTrail: Array<IntArray> by lazy { decodeArms(CreatureSpriteData.ARM_TRAIL, CreatureSpriteData.ARM_TRAIL_INFO) }

    private fun decodeArms(data: Array<String>, info: Array<IntArray>): Array<IntArray> =
        Array(data.size) { SpriteCodec.decode(data[it], info[it][0] * info[it][1]) }

    fun armIndex(swing: Int, bend: Int) = swing * CreatureSpriteData.ARM_BEND.size + bend

    /** Cabezas: 0 = frontal, 1 = girada hacia donde camina. */
    val heads: Array<IntArray> by lazy { Array(CreatureSpriteData.HEAD_DATA.size) { SpriteCodec.decode(CreatureSpriteData.HEAD_DATA[it], headW(it) * headH(it)) } }
    fun headW(variant: Int) = CreatureSpriteData.HEAD_SIZES[variant * 2]
    fun headH(variant: Int) = CreatureSpriteData.HEAD_SIZES[variant * 2 + 1]
    val head: IntArray get() = heads[0]

    /** Ojo trasero (L) y delantero (R); índice = variante * 5 + estado. */
    val eyesL: Array<IntArray> by lazy { Array(CreatureSpriteData.EYE_DATA_L.size) { val s = eyeSizeL(it / 5); SpriteCodec.decode(CreatureSpriteData.EYE_DATA_L[it], s * s) } }
    val eyesR: Array<IntArray> by lazy { Array(CreatureSpriteData.EYE_DATA_R.size) { val s = eyeSizeR(it / 5); SpriteCodec.decode(CreatureSpriteData.EYE_DATA_R[it], s * s) } }
    fun eyeSizeL(variant: Int) = CreatureSpriteData.EYE_SIZES[variant * 2]
    fun eyeSizeR(variant: Int) = CreatureSpriteData.EYE_SIZES[variant * 2 + 1]

    /** Boca principal; índice = variante * 4 + estado. */
    val mainMouths: Array<IntArray> by lazy {
        Array(CreatureSpriteData.MAIN_MOUTH_DATA.size) {
            val v = it / CreatureSpriteData.MAIN_MOUTH_STATES.size
            SpriteCodec.decode(CreatureSpriteData.MAIN_MOUTH_DATA[it], mainW(v) * mainH(v))
        }
    }
    fun mainW(variant: Int) = CreatureSpriteData.MAIN_MOUTH_SIZES[variant * 2]
    fun mainH(variant: Int) = CreatureSpriteData.MAIN_MOUTH_SIZES[variant * 2 + 1]

    /** Bocas del vientre; índice = boca * SEC_STATES + estado (0 cerrada, 1 entreabierta, 2 abierta, 3 muy abierta). */
    val secMouths: Array<IntArray> by lazy {
        Array(CreatureSpriteData.SEC_DATA.size) {
            val mouth = it / CreatureSpriteData.SEC_STATES
            SpriteCodec.decode(CreatureSpriteData.SEC_DATA[it], secW(mouth) * secH(mouth))
        }
    }

    fun secW(mouth: Int) = CreatureSpriteData.SEC_SIZES[mouth * 2]
    fun secH(mouth: Int) = CreatureSpriteData.SEC_SIZES[mouth * 2 + 1]
    fun secOriginX(mouth: Int) = CreatureSpriteData.SEC_ORIGINS[mouth * 2]
    fun secOriginY(mouth: Int) = CreatureSpriteData.SEC_ORIGINS[mouth * 2 + 1]
    fun secIndex(mouth: Int, state: Int) = mouth * CreatureSpriteData.SEC_STATES + state

    /**
     * Misma fórmula de iluminación que [PixelRasterizer] (brillo con suelo SHADE_FLOOR + tinte), así el niño y la
     * criatura reaccionan igual a una misma luz. Lógica pura (testeable sin Android).
     */
    fun shade(indices: IntArray, w: Int, h: Int, light: LightingSample?, out: IntArray) {
        val shade = if (light == null) 1f else PixelRasterizer.SHADE_FLOOR + (1f - PixelRasterizer.SHADE_FLOOR) * light.brightness.coerceIn(0f, 1f)
        val tr = if (light == null) 1f else 1f + (light.tintR - 1f) * PixelRasterizer.TINT_STRENGTH
        val tg = if (light == null) 1f else 1f + (light.tintG - 1f) * PixelRasterizer.TINT_STRENGTH
        val tb = if (light == null) 1f else 1f + (light.tintB - 1f) * PixelRasterizer.TINT_STRENGTH
        for (i in 0 until w * h) {
            val idx = indices[i]
            val c = if (idx in PALETTE.indices) PALETTE[idx] else 0
            val a = (c ushr 24) and 0xFF
            if (idx == PixelIndex.TRANSPARENT || a == 0) { out[i] = 0; continue }
            val r = (((c shr 16) and 0xFF) * shade * tr).toInt().coerceIn(0, 255)
            val g = (((c shr 8) and 0xFF) * shade * tg).toInt().coerceIn(0, 255)
            val b = ((c and 0xFF) * shade * tb).toInt().coerceIn(0, 255)
            out[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
    }
}
