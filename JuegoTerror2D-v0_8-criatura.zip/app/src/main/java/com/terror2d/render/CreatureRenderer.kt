package com.terror2d.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import com.terror2d.creature.Creature
import com.terror2d.pixel.CreatureSprite
import com.terror2d.pixel.CreatureSpriteData
import com.terror2d.pixel.LightingSample
import kotlin.math.round

/**
 * Dibuja la criatura por CAPAS (brazo trasero, cuerpo, cabeza, ojos, sonrisa, 7 bocas del vientre, brazo delantero)
 * con la MISMA iluminación y la MISMA escala de píxel que el niño ([CreatureSprite.SCALE]). Todo sale de matrices
 * de píxeles procedurales: no hay ninguna imagen. Cada capa se rasteriza una vez por nivel de luz y se cachea: por
 * frame solo hay drawBitmap sin filtrado.
 *
 * Los brazos cuelgan de los hombros que trae CADA pose del cuerpo, y las bocas del vientre del centro del vientre de
 * esa misma pose, así todo se mueve junto con el peso del cuerpo al caminar.
 */
class CreatureRenderer {
    private val paint = Paint().apply { isAntiAlias = false; isFilterBitmap = false; isDither = false }
    private val cache = HashMap<Long, Bitmap>()
    private val quantized = LightingSample()
    private var buffer = IntArray(0)

    fun render(canvas: Canvas, c: Creature, centerX: Float, bottomY: Float, alpha: Float) {
        if (alpha <= 0.01f) return
        c.light.quantizeInto(quantized)
        val lk = c.light.key()
        paint.alpha = (alpha.coerceIn(0f, 1f) * 255f).toInt()
        val pose = c.bodyPose()
        val a = CreatureSpriteData.BODY_ANCHORS[pose]
        val breathY = round(c.breath()).toInt()
        val hx = a[0]; val hy = a[1] + breathY
        val bx = a[2]; val by = a[3]
        val variant = a[8]

        canvas.save()
        canvas.translate(round(centerX), round(bottomY))
        if (c.facing < 0f) canvas.scale(-1f, 1f)
        canvas.scale(CreatureSprite.SCALE, CreatureSprite.SCALE)
        canvas.translate(-CreatureSprite.ANCHOR_X.toFloat(), -CreatureSprite.BODY_H.toFloat())

        // brazo trasero (detrás), cuerpo, cabeza y sus capas, bocas del vientre, brazo delantero (delante)
        val ti = c.trailArmIndex()
        val tinfo = CreatureSpriteData.ARM_TRAIL_INFO[ti]
        draw(canvas, 1000 + ti, CreatureSprite.armTrail[ti], tinfo[0], tinfo[1], lk, (a[6] - tinfo[2]).toFloat(), (a[7] - tinfo[3]).toFloat())
        draw(canvas, 100 + pose, CreatureSprite.bodies[pose], CreatureSprite.BODY_W, CreatureSprite.BODY_H, lk, 0f, 0f)
        draw(canvas, 400 + variant, CreatureSprite.heads[variant], CreatureSpriteData.HEAD_W, CreatureSpriteData.HEAD_H, lk, hx.toFloat(), hy.toFloat())

        val es = c.eyeState
        val el = CreatureSprite.eyeSizeL(variant); val er = CreatureSprite.eyeSizeR(variant)
        val ec = CreatureSpriteData.EYE_CENTERS
        val eo = variant * 4
        draw(canvas, 500 + variant * 5 + es, CreatureSprite.eyesL[variant * 5 + es], el, el, lk, (hx + ec[eo] - el / 2).toFloat(), (hy + ec[eo + 1] - el / 2).toFloat())
        draw(canvas, 520 + variant * 5 + es, CreatureSprite.eyesR[variant * 5 + es], er, er, lk, (hx + ec[eo + 2] - er / 2).toFloat(), (hy + ec[eo + 3] - er / 2).toFloat())

        val mm = c.mainMouth
        val mp = CreatureSpriteData.MAIN_MOUTH_POS
        draw(canvas, 700 + variant * 4 + mm, CreatureSprite.mainMouths[variant * CreatureSpriteData.MAIN_MOUTH_STATES.size + mm],
            CreatureSprite.mainW(variant), CreatureSprite.mainH(variant), lk, (hx + mp[variant * 2]).toFloat(), (hy + mp[variant * 2 + 1]).toFloat())

        // bocas del vientre: cada una con su propia apertura (asíncronas, deterministas)
        val tm = CreatureSpriteData.TORSO_MOUTHS
        for (j in 0 until tm.size) belly(canvas, c, j, tm[j], bx, by, lk)

        val li = c.leadArmIndex()
        val linfo = CreatureSpriteData.ARM_LEAD_INFO[li]
        draw(canvas, 1100 + li, CreatureSprite.armLead[li], linfo[0], linfo[1], lk, (a[4] - linfo[2]).toFloat(), (a[5] - linfo[3]).toFloat())
        canvas.restore()
    }

    private fun belly(canvas: Canvas, c: Creature, i: Int, m: IntArray, ox: Int, oy: Int, lk: Int) {
        val o = c.mouths.openness(i, c.time, c.arousal)
        val state = if (o < 0.08f) 0 else if (o < 0.32f) 1 else if (o < 0.62f) 2 else 3
        val id = m[0]
        val idx = CreatureSprite.secIndex(id, state)
        draw(canvas, 2000 + idx, CreatureSprite.secMouths[idx], CreatureSprite.secW(id), CreatureSprite.secH(id), lk,
            (ox + m[1] - CreatureSprite.secOriginX(id)).toFloat(), (oy + m[2] - CreatureSprite.secOriginY(id)).toFloat())
    }

    private fun draw(canvas: Canvas, layer: Int, indices: IntArray, w: Int, h: Int, lightKey: Int, x: Float, y: Float) {
        val key = (layer.toLong() shl 16) or lightKey.toLong()
        var bmp = cache[key]
        if (bmp == null) {
            if (cache.size >= MAX_CACHED) cache.clear()
            val n = w * h
            if (buffer.size < n) buffer = IntArray(n)
            CreatureSprite.shade(indices, w, h, quantized, buffer)
            bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.setPixels(buffer, 0, w, 0, 0, w, h)
            cache[key] = bmp
        }
        canvas.drawBitmap(bmp, x, y, paint)
    }

    fun clear() {
        for (b in cache.values) b.recycle()
        cache.clear()
    }

    companion object { private const val MAX_CACHED = 900 }
}
