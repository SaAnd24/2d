"""Genera app/src/main/java/com/terror2d/pixel/CreatureSpriteData.kt (NO edita SpriteData.kt).

Uso:  python3 emit_creature.py   (desde tools/sprite_gen)
Misma codificación RLE que emit_kotlin.py (índice de paleta + longitud, ambos como chr(48+n)).
Las matrices las dibuja creature.py con el motor pixelado procedural; no se incluye ninguna imagen.
"""
import os
import creature as cr
from emit_kotlin import rle, argb

OUT = os.path.join(os.path.dirname(__file__), '..', '..', 'app', 'src', 'main', 'java', 'com', 'terror2d', 'pixel', 'CreatureSpriteData.kt')


def ks(cv):
    return '        "%s"' % rle(cv.a)


def ints(vals):
    return 'intArrayOf(' + ', '.join(str(int(v)) for v in vals) + ')'


def main():
    L = []
    w = L.append
    w('package com.terror2d.pixel')
    w('')
    w('/**')
    w(' * DATOS GENERADOS por tools/sprite_gen (python3 emit_creature.py). NO editar a mano: edita creature.py.')
    w(' * La criatura usa la MISMA densidad de pixel art que el protagonista (1 píxel = 0,5 px lógicos).')
    w(' * Diseño v0.8 (humanoide encorvado, sonrisa de dientes finos, 7 bocas en el vientre, brazos larguísimos).')
    w(' * Todo son matrices de índices de paleta dibujadas proceduralmente: no hay imágenes en la app.')
    w(' */')
    w('object CreatureSpriteData {')
    w(f'    const val BODY_W = {cr.W}')
    w(f'    const val BODY_H = {cr.H}')
    w(f'    /** Columna del cuerpo que cae sobre el centro de la criatura (la cadera). */')
    w(f'    const val ANCHOR_X = {cr.ANCHOR_X}')
    w(f'    const val HEAD_W = {cr.HW}')
    w(f'    const val HEAD_H = {cr.HH}')
    w('    val PALETTE: IntArray = intArrayOf(' + ', '.join(argb(c) + '.toInt()' for c in cr.PAL) + ')')
    names = list(cr.POSES.keys())
    w('    /** Orden: IDLE, INVESTIGATE, ALERT, CAPTURE, HURT_LIGHT, WALK_0..7, RUN_0..7. */')
    w('    val BODY_POSES: Array<String> = arrayOf(' + ', '.join('"%s"' % n for n in names) + ')')
    bodies = [cr.build_body(n) for n in names]
    w('    val BODY_DATA: Array<String> = arrayOf(')
    w(',\n'.join(ks(b) for b, _ in bodies))
    w('    )')
    w('    /** Por pose: [headX, headY (esquina sup. izq. de la cabeza), bellyX, bellyY (centro del vientre), hombro delantero x,y, hombro trasero x,y, variante de cabeza]. */')
    w('    val BODY_ANCHORS: Array<IntArray> = arrayOf(' + ', '.join(
        ints(list(i['head']) + list(i['belly']) + list(i['lead']) + list(i['trail']) + [i['variant']]) for _, i in bodies) + ')')
    # brazos
    w(f'    val ARM_SWING: IntArray = {ints(cr.ARM_SWING)}')
    w(f'    val ARM_BEND: IntArray = {ints(cr.ARM_BEND)}')
    for lead, nm in ((True, 'LEAD'), (False, 'TRAIL')):
        arms = [cr.build_arm(si, bi, lead) for si in range(len(cr.ARM_SWING)) for bi in range(len(cr.ARM_BEND))]
        w(f'    /** Brazo {"delantero (delante del cuerpo)" if lead else "trasero (detrás del cuerpo)"}: índice = balanceo * {len(cr.ARM_BEND)} + codo. */')
        w(f'    val ARM_{nm}: Array<String> = arrayOf(')
        w(',\n'.join(ks(a) for a, _ in arms))
        w('    )')
        w(f'    /** [ancho, alto, hombroX, hombroY] de cada recorte de ARM_{nm}. */')
        w(f'    val ARM_{nm}_INFO: Array<IntArray> = arrayOf(' + ', '.join(ints([a.w, a.h, o[0], o[1]]) for a, o in arms) + ')')
    # cabeza (2 variantes)
    w('    val HEAD_DATA: Array<String> = arrayOf(')
    w(',\n'.join(ks(cr.build_head(v)) for v in (0, 1)))
    w('    )')
    w(f'    val HEAD_CENTER: IntArray = {ints(cr.HEAD_C)}')
    # ojos
    w('    val EYE_STATES: Array<String> = arrayOf(' + ', '.join('"%s"' % s for s in cr.EYE_STATES) + ')')
    ec, esz, eyeL, eyeR = [], [], [], []
    for v in (0, 1):
        (e0, e1) = cr.EYE_CENTERS[v]
        ec += [e0[0], e0[1], e1[0], e1[1]]
        r0, r1 = cr.EYE_R[v]
        pl = [cr.eye_patch(r0, s, -1) for s in cr.EYE_STATES]
        pr = [cr.eye_patch(r1, s, +1) for s in cr.EYE_STATES]
        esz += [pl[0].w, pr[0].w]
        eyeL += pl
        eyeR += pr
    w('    /** Por variante de cabeza: ojo trasero x,y, ojo delantero x,y (coords de cabeza). */')
    w(f'    val EYE_CENTERS: IntArray = {ints(ec)}')
    w('    /** Por variante: lado del parche del ojo trasero y del delantero. */')
    w(f'    val EYE_SIZES: IntArray = {ints(esz)}')
    w('    /** Índice = variante * 5 + estado. */')
    w('    val EYE_DATA_L: Array<String> = arrayOf(')
    w(',\n'.join(ks(p) for p in eyeL))
    w('    )')
    w('    val EYE_DATA_R: Array<String> = arrayOf(')
    w(',\n'.join(ks(p) for p in eyeR))
    w('    )')
    # boca principal
    w('    val MAIN_MOUTH_STATES: Array<String> = arrayOf(' + ', '.join('"%s"' % s for s in cr.MOUTH_NAMES) + ')')
    msz, mpos, mdata = [], [], []
    for v in (0, 1):
        ps = [cr.main_mouth(v, s) for s in range(4)]
        # todos los estados comparten lienzo: se recolocan por el centro
        cw = max(p[0].w for p in ps)
        ch = max(p[0].h for p in ps)
        for (cv, cx, cy) in ps:
            full = cr.Cv(cw, ch)
            full.a[:] = 0
            ox, oy = cw // 2 - cx, ch // 2 - cy
            cr.paste(full, cv, ox, oy)
            mdata.append(full)
        msz += [cw, ch]
        mpos += [cr.MOUTH_AT[v][0] - cw // 2, cr.MOUTH_AT[v][1] - ch // 2]
    w('    /** Por variante: ancho y alto del parche de la boca principal. */')
    w(f'    val MAIN_MOUTH_SIZES: IntArray = {ints(msz)}')
    w('    /** Por variante: esquina sup. izq. del parche en coords de cabeza. */')
    w(f'    val MAIN_MOUTH_POS: IntArray = {ints(mpos)}')
    w('    /** Índice = variante * 4 + estado (la sonrisa de dientes finos SIEMPRE se ve; WIDE = mandíbula caída). */')
    w('    val MAIN_MOUTH_DATA: Array<String> = arrayOf(')
    w(',\n'.join(ks(p) for p in mdata))
    w('    )')
    # 7 bocas del vientre: cada una con su parche y 4 estados
    sizes, origins, sdata, tm = [], [], [], []
    for i, (dx, dy, *_r) in enumerate(cr.BELLY_MOUTHS):
        ps = [cr.belly_mouth(i, s) for s in range(4)]
        cw = max(p[0].w for p in ps)
        ch = max(p[0].h for p in ps)
        for (cv, cx, cy) in ps:
            full = cr.Cv(cw, ch)
            cr.paste(full, cv, cw // 2 - cx, ch // 2 - cy)
            sdata.append(full)
        sizes += [cw, ch]
        origins += [cw // 2, ch // 2]
        tm.append([i, dx, dy, 0])
    w('    /** 7 bocas del vientre; 4 estados cada una (0 cerrada, 1 entreabierta, 2 abierta, 3 muy abierta). Índice = boca * 4 + estado. */')
    w('    const val SEC_STATES = 4')
    w('    /** Ancho y alto del parche de cada boca. */')
    w(f'    val SEC_SIZES: IntArray = {ints(sizes)}')
    w('    /** Centro de la boca dentro de su parche. */')
    w(f'    val SEC_ORIGINS: IntArray = {ints(origins)}')
    w('    val SEC_DATA: Array<String> = arrayOf(')
    w(',\n'.join(ks(p) for p in sdata))
    w('    )')
    w('    /** El diseño no tiene bocas secundarias en la cabeza (la sonrisa grande es la boca principal). */')
    w('    val HEAD_MOUTHS: Array<IntArray> = arrayOf()')
    w('    /** Bocas del vientre: [id de boca, x, y relativos al centro del vientre, 0]. */')
    w('    val TORSO_MOUTHS: Array<IntArray> = arrayOf(' + ', '.join(ints(t) for t in tm) + ')')
    w('}')
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    open(OUT, 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    print('escrito', os.path.abspath(OUT), os.path.getsize(OUT), 'bytes')


if __name__ == '__main__':
    main()
