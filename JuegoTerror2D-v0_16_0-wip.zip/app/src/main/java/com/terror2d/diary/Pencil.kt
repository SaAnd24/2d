package com.terror2d.diary

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Un trazo de lápiz ya generado: polilínea en el espacio del dibujo (100 x 60). */
class PencilStroke(
    val pts: FloatArray,
    /** Presión del lápiz 0..1 (grosor y opacidad). */
    val pressure: Float,
    /** 0 = grafito, 1 = mancha de lápiz difuminada, 2 = goma de borrar (clarea lo ya dibujado). */
    val kind: Int
)

/**
 * v0.16: «mano» de un niño con un lápiz de grafito. Genera trazos DETERMINISTAS (misma semilla => mismo dibujo): temblorosos,
 * repasados, con líneas que se pasan de largo, rayones de sombra, manchas y zonas borradas. Lógica pura (sin Android);
 * [DiaryRenderer] solo recorre los trazos. No hay trazos geométricos limpios: cada línea lleva su propio temblor.
 */
class Pencil(seed: Int) {
    val strokes = ArrayList<PencilStroke>()
    private var s = (seed * 747796405 + 2891336453L.toInt()) or 1

    private fun r(): Float {
        s = s xor (s shl 13); s = s xor (s ushr 17); s = s xor (s shl 5)
        return ((s ushr 8) and 0xFFFF) / 65535f
    }

    private fun wob(a: Float): Float = (r() - 0.5f) * a

    /** Línea temblorosa. [redo] la repasa una segunda vez con otra presión (trazo «repasado»). */
    fun line(x1: Float, y1: Float, x2: Float, y2: Float, p: Float = 0.7f, jit: Float = 0.8f, redo: Boolean = false) {
        val dx = x2 - x1
        val dy = y2 - y1
        val len = sqrt(dx * dx + dy * dy)
        val n = (len / 4f).toInt().coerceIn(2, 14)
        val over = 0.02f + r() * 0.05f       // a veces se pasa de largo
        val pts = FloatArray((n + 1) * 2)
        for (i in 0..n) {
            val t = i.toFloat() / n * (1f + over)
            pts[i * 2] = x1 + dx * t + wob(jit)
            pts[i * 2 + 1] = y1 + dy * t + wob(jit)
        }
        strokes.add(PencilStroke(pts, p * (0.75f + r() * 0.35f), 0))
        if (redo) line(x1 + wob(1f), y1 + wob(1f), x2 + wob(1f), y2 + wob(1f), p * 0.7f, jit * 1.2f, false)
    }

    fun poly(p: Float, vararg c: Float) {
        var i = 0
        while (i + 3 < c.size) { line(c[i], c[i + 1], c[i + 2], c[i + 3], p, 0.7f, false); i += 2 }
    }

    /** Óvalo hecho a mano: no cierra bien (el final se pasa o se queda corto). */
    fun loop(cx: Float, cy: Float, rx: Float, ry: Float, p: Float = 0.7f, turns: Float = 1.15f, redo: Boolean = true) {
        val n = 18
        val pts = FloatArray((n + 1) * 2)
        val a0 = r() * 6.28f
        for (i in 0..n) {
            val a = a0 + i.toFloat() / n * turns * 2f * PI.toFloat()
            val k = 1f + wob(0.14f)
            pts[i * 2] = cx + cos(a) * rx * k
            pts[i * 2 + 1] = cy + sin(a) * ry * k
        }
        strokes.add(PencilStroke(pts, p, 0))
        if (redo) loop(cx + wob(0.8f), cy + wob(0.8f), rx * 0.97f, ry * 1.03f, p * 0.6f, 0.9f, false)
    }

    /** Rayas rápidas de sombra (todas con la misma inclinación aproximada). */
    fun hatch(x: Float, y: Float, w: Float, h: Float, n: Int, p: Float = 0.5f) {
        for (i in 0 until n) {
            val yy = y + h * (i + r() * 0.6f) / n
            line(x + wob(1.5f), yy, x + w + wob(1.5f), yy - h * 0.25f + wob(1.5f), p, 0.5f, false)
        }
    }

    /** Garabato denso (masa oscura). */
    fun blob(cx: Float, cy: Float, rad: Float, p: Float = 0.9f, n: Int = 16) {
        val pts = FloatArray(n * 2)
        var a = 0f
        for (i in 0 until n) {
            a += 2.3f + r()
            val k = rad * (0.35f + r() * 0.65f)
            pts[i * 2] = cx + cos(a) * k
            pts[i * 2 + 1] = cy + sin(a) * k * 0.9f
        }
        strokes.add(PencilStroke(pts, p, 0))
        strokes.add(PencilStroke(floatArrayOf(cx, cy, rad * 1.3f, rad), 0.5f, 1))
    }

    /** Mancha de grafito difuminada. */
    fun smudge(cx: Float, cy: Float, rx: Float, ry: Float) {
        strokes.add(PencilStroke(floatArrayOf(cx, cy, rx, ry), 0.6f, 1))
    }

    /** Zona borrada y corregida. */
    fun erase(x: Float, y: Float, w: Float, h: Float) {
        strokes.add(PencilStroke(floatArrayOf(x, y, w, h), 0.8f, 2))
    }

    // ------------------------------------------------------------------ figuras (proporciones torpes de niño)

    /** El niño: cabeza enorme, cuerpo palito, brazos desiguales. [mood] 0 = serio, 1 = triste. */
    fun kid(x: Float, y: Float, sc: Float, mood: Int = 0) {
        val hr = 4.2f * sc
        loop(x, y - 11f * sc, hr, hr * 1.05f, 0.75f)
        line(x, y - 6.5f * sc, x + wob(1f), y + 1f * sc, 0.75f, 0.5f, true)
        line(x, y - 4.5f * sc, x - 4.5f * sc, y - 1f * sc, 0.65f)
        line(x, y - 4.5f * sc, x + 5f * sc, y - 3f * sc, 0.65f)
        line(x, y + 1f * sc, x - 3f * sc, y + 7f * sc, 0.7f)
        line(x, y + 1f * sc, x + 3.5f * sc, y + 7f * sc, 0.7f)
        strokes.add(PencilStroke(floatArrayOf(x - 1.6f * sc, y - 11.8f * sc, x - 1.3f * sc, y - 11.6f * sc), 0.95f, 0))
        strokes.add(PencilStroke(floatArrayOf(x + 1.6f * sc, y - 11.8f * sc, x + 1.9f * sc, y - 11.6f * sc), 0.95f, 0))
        if (mood == 1) line(x - 1.4f * sc, y - 9f * sc, x + 1.4f * sc, y - 9.6f * sc, 0.6f, 0.3f)
        else line(x - 1.4f * sc, y - 9.4f * sc, x + 1.4f * sc, y - 9.4f * sc, 0.6f, 0.3f)
    }

    /** Mamá: más alta, vestido triangular, pelo en rayas largas. */
    fun mom(x: Float, y: Float, sc: Float) {
        val hr = 3.4f * sc
        loop(x, y - 21f * sc, hr, hr * 1.1f, 0.7f)
        for (i in -1..2) line(x + i * 1.6f * sc, y - 24f * sc, x + i * 2.2f * sc, y - 15f * sc, 0.45f, 0.6f)
        poly(0.7f, x, y - 17f * sc, x - 6f * sc, y + 2f * sc, x + 6f * sc, y + 2f * sc, x, y - 17f * sc)
        line(x - 3f * sc, y - 14f * sc, x - 8f * sc, y - 9f * sc, 0.6f)
        line(x + 3f * sc, y - 14f * sc, x + 8f * sc, y - 11f * sc, 0.6f)
        line(x - 2f * sc, y + 2f * sc, x - 2.5f * sc, y + 8f * sc, 0.65f)
        line(x + 2f * sc, y + 2f * sc, x + 2.5f * sc, y + 8f * sc, 0.65f)
    }

    /** Casa torcida: paredes inclinadas, ventanas desiguales. */
    fun house(x: Float, y: Float, w: Float, h: Float, windows: Int = 2) {
        poly(0.75f, x, y, x + wob(2f), y - h, x + w * 0.5f, y - h - h * 0.38f, x + w + wob(2f), y - h, x + w, y)
        line(x, y, x + w, y + wob(2f), 0.75f, 0.9f, true)
        for (i in 0 until windows) {
            val wx = x + w * (0.18f + 0.45f * i) + wob(2f)
            val wy = y - h * (0.72f + wob(0.15f))
            val ws = w * (0.16f + r() * 0.08f)
            poly(0.65f, wx, wy, wx + ws, wy + wob(1.5f), wx + ws, wy + ws, wx + wob(1f), wy + ws, wx, wy)
        }
        line(x + w * 0.42f, y, x + w * 0.42f, y - h * 0.4f, 0.65f)
        line(x + w * 0.62f, y, x + w * 0.62f, y - h * 0.42f, 0.65f)
    }

    fun windowFrame(x: Float, y: Float, w: Float, h: Float) {
        poly(0.7f, x, y, x + w, y + wob(1.5f), x + w, y + h, x + wob(1f), y + h, x, y)
        line(x + w * 0.5f, y, x + w * 0.5f + wob(1f), y + h, 0.55f)
        line(x, y + h * 0.5f, x + w, y + h * 0.5f + wob(1f), 0.55f)
    }

    fun rain(x: Float, y: Float, w: Float, h: Float, n: Int) {
        for (i in 0 until n) {
            val rx = x + r() * w
            val ry = y + r() * h
            line(rx, ry, rx - 1.2f, ry + 3.2f, 0.4f, 0.2f)
        }
    }

    fun bed(x: Float, y: Float, w: Float) {
        line(x, y, x + w, y + wob(1.2f), 0.75f, 0.8f, true)
        line(x, y - 6f, x + w * 0.9f, y - 6f + wob(1.5f), 0.65f)
        line(x, y - 12f, x, y + 4f, 0.7f)
        line(x + w, y - 5f, x + w, y + 4f, 0.7f)
        loop(x + 5f, y - 9f, 5f, 2.5f, 0.55f)
        hatch(x + 10f, y - 6f, w * 0.7f, 5f, 4, 0.45f)
    }

    fun cup(x: Float, y: Float, sc: Float = 1f) {
        poly(0.7f, x, y - 5f * sc, x + wob(0.8f), y, x + 5f * sc, y + wob(0.5f), x + 5f * sc, y - 5f * sc)
        loop(x + 2.5f * sc, y - 5f * sc, 2.6f * sc, 0.9f * sc, 0.6f, 1.05f, false)
        loop(x + 7f * sc, y - 2.8f * sc, 1.8f * sc, 1.8f * sc, 0.6f, 0.7f, false)
    }

    fun steam(x: Float, y: Float, n: Int = 3) {
        for (i in 0 until n) {
            val sx = x + i * 2.4f
            poly(0.35f, sx, y, sx + 1.4f, y - 2.6f, sx - 1.2f, y - 5f, sx + 1f, y - 7.5f)
        }
    }

    fun bottle(x: Float, y: Float, sc: Float = 1f) {
        poly(0.7f, x, y, x + wob(0.8f), y - 9f * sc, x + 1.5f * sc, y - 12f * sc, x + 4f * sc, y - 12f * sc, x + 5.5f * sc, y - 9f * sc, x + 5.5f * sc, y)
        line(x, y, x + 5.5f * sc, y + wob(0.8f), 0.7f)
        line(x + 1.2f * sc, y - 12f * sc, x + 4.4f * sc, y - 13.2f * sc, 0.6f)
        hatch(x + 0.8f, y - 8f * sc, 4f * sc, 6f * sc, 3, 0.45f)
    }

    fun lamp(x: Float, y: Float) {
        line(x, 0f, x, y - 5f, 0.5f)
        poly(0.65f, x - 4f, y, x - 2f, y - 5f, x + 2f, y - 5f, x + 4f, y)
        loop(x, y + 2.5f, 1.6f, 1.6f, 0.5f, 1f, false)
    }

    fun moon(x: Float, y: Float, rad: Float) {
        loop(x, y, rad, rad, 0.65f, 1.0f)
        hatch(x - rad * 0.2f, y - rad * 0.6f, rad * 1.1f, rad * 1.2f, 4, 0.35f)
    }

    fun frog(x: Float, y: Float, sc: Float = 1f) {
        loop(x, y - 3f * sc, 4f * sc, 3f * sc, 0.65f)
        loop(x - 2.5f * sc, y - 7f * sc, 1.4f * sc, 1.4f * sc, 0.6f, 1.1f, false)
        loop(x + 2.5f * sc, y - 7f * sc, 1.4f * sc, 1.4f * sc, 0.6f, 1.1f, false)
        line(x - 1f * sc, y - 2.4f * sc, x + 2.2f * sc, y - 2.8f * sc, 0.5f, 0.3f)
        line(x - 1.5f * sc, y - 6f * sc, x + 2f * sc, y - 1f * sc, 0.4f, 0.4f)
        line(x + 1.5f * sc, y - 6f * sc, x - 2f * sc, y - 1f * sc, 0.4f, 0.4f)
    }

    fun envelope(x: Float, y: Float, w: Float, h: Float) {
        poly(0.7f, x, y, x + w, y + wob(1f), x + w, y + h, x + wob(1f), y + h, x, y)
        poly(0.6f, x, y, x + w * 0.5f, y + h * 0.55f, x + w, y)
    }

    fun paper(x: Float, y: Float, w: Float, h: Float, lines: Int = 4) {
        poly(0.7f, x, y, x + w, y + wob(1f), x + w + wob(1f), y + h, x, y + h + wob(1f), x, y)
        for (i in 0 until lines) {
            val ly = y + 4f + i * (h - 6f) / lines
            line(x + 2.5f, ly, x + w - 2.5f - r() * w * 0.3f, ly + wob(0.8f), 0.45f, 0.5f)
        }
    }

    fun door(x: Float, y: Float, h: Float) {
        poly(0.7f, x, y, x + wob(1f), y - h, x + h * 0.45f, y - h + wob(1f), x + h * 0.45f, y)
        loop(x + h * 0.36f, y - h * 0.5f, 0.8f, 0.8f, 0.6f, 1f, false)
    }

    fun clock(x: Float, y: Float, rad: Float) {
        loop(x, y, rad, rad, 0.7f)
        line(x, y, x, y - rad * 0.7f, 0.65f, 0.3f)
        line(x, y, x + rad * 0.5f, y + rad * 0.1f, 0.65f, 0.3f)
    }

    fun table(x: Float, y: Float, w: Float) {
        line(x, y, x + w, y + wob(1f), 0.75f, 0.9f, true)
        line(x + 3f, y, x + 2f, y + 14f, 0.7f)
        line(x + w - 3f, y, x + w - 2f, y + 14f, 0.7f)
    }

    fun eye(x: Float, y: Float, w: Float) {
        poly(0.65f, x - w, y, x, y - w * 0.5f, x + w, y)
        poly(0.65f, x - w, y, x, y + w * 0.5f, x + w, y)
        blob(x, y, w * 0.28f, 0.95f, 8)
    }
}
