package com.terror2d.diary

/**
 * v0.16: el dibujo de grafito que el niño hizo DESPUÉS de leer cada documento. Un dibujo propio por documento, generado con
 * [Pencil] y una semilla fija derivada del id (siempre el mismo, nunca aleatorio al abrir el diario). Se dibujan en un espacio
 * de 100 x 60; no añaden hechos: representan lo que dice cada texto, con proporciones torpes y trazos nerviosos.
 */
object ChildDrawings {

    const val W = 100f
    const val H = 60f

    private val cache = HashMap<String, List<PencilStroke>>()

    /** Trazos del dibujo del documento [docId] (o de su id base). Estable entre llamadas. */
    fun strokesFor(docId: String): List<PencilStroke> {
        val base = DiaryState.baseOf(docId)
        return cache.getOrPut(base) { build(base) }
    }

    /** Ids base de los documentos con dibujo propio (los 22 del capítulo + variantes d14 + los 4 de la rutina). */
    val ALL_BASES: List<String> = listOf(
        "doc_mom_note", "doc_medical", "doc_finance", "doc_pharmacy",
        "d01", "d02", "d03", "d04", "d05", "d06", "d07", "d08", "d09", "d10", "d11", "d12", "d13",
        "d14a", "d14b", "d14c", "d15", "d16", "d17", "d18", "d19", "d20", "d21", "d22"
    )

    fun hasDrawing(base: String): Boolean = ALL_BASES.contains(DiaryState.baseOf(base))

    private fun seedOf(base: String): Int {
        var h = 17
        for (ch in base) h = h * 31 + ch.code
        return h
    }

    private fun build(base: String): List<PencilStroke> {
        val p = Pencil(seedOf(base))
        when (base) {
            // mamá se va al hospital; el niño la mira desde la ventana de la casa
            "doc_mom_note" -> {
                p.house(52f, 50f, 34f, 22f, 2); p.line(74f, 14f, 74f, 22f, 0.8f); p.line(70f, 18f, 78f, 18f, 0.8f)
                p.mom(22f, 46f, 1f); p.line(28f, 28f, 44f, 36f, 0.4f, 1.2f); p.kid(90f, 48f, 0.8f, 1)
                p.smudge(60f, 30f, 14f, 6f)
            }
            // papel médico: un cuerpo esquemático en una cama y un frasco
            "doc_medical" -> {
                p.bed(8f, 44f, 56f); p.line(16f, 36f, 40f, 37f, 0.7f); p.loop(13f, 34f, 3.4f, 3.4f, 0.7f)
                p.bottle(78f, 48f, 1.2f); p.cross(86f, 22f)
                p.hatch(44f, 30f, 18f, 8f, 5, 0.5f)
            }
            // aviso de pago: sobre con círculos (monedas) tachados
            "doc_finance" -> {
                p.envelope(12f, 22f, 36f, 24f); p.blob(30f, 36f, 4f, 0.85f)
                p.loop(66f, 22f, 5f, 5f, 0.7f); p.loop(78f, 30f, 5f, 5f, 0.7f); p.loop(68f, 40f, 5f, 5f, 0.7f)
                p.line(60f, 16f, 86f, 46f, 0.9f, 0.8f, true); p.erase(10f, 10f, 12f, 8f)
            }
            // hoja de tratamiento: frascos en fila y Ranita
            "doc_pharmacy" -> {
                p.bottle(10f, 46f); p.bottle(26f, 46f, 1.15f); p.bottle(44f, 46f, 0.9f); p.bottle(60f, 46f, 1.1f)
                p.frog(84f, 46f, 1.3f); p.line(8f, 47f, 70f, 48f, 0.6f, 1f, true)
                p.line(80f, 30f, 88f, 30f, 0.7f); p.line(84f, 26f, 84f, 34f, 0.7f)
            }
            // d01: la nota junto a la cama; no salir con la lluvia; cuidar a Ranita
            "d01" -> {
                p.windowFrame(58f, 6f, 30f, 24f); p.rain(52f, 4f, 40f, 30f, 14)
                p.bed(8f, 46f, 44f); p.kid(18f, 40f, 0.65f, 0); p.frog(40f, 40f, 0.9f)
                p.paper(60f, 40f, 14f, 10f, 2); p.smudge(72f, 20f, 16f, 8f)
            }
            // d02: el mantel dibujado: mesa, taza azul junto a la pared, plato con muesca
            "d02" -> {
                p.table(10f, 36f, 70f); p.cup(16f, 36f, 1.1f); p.loop(48f, 33f, 8f, 2.4f, 0.7f)
                p.line(53f, 30f, 56f, 32f, 0.8f, 0.2f); p.erase(54f, 29f, 4f, 3f)
                p.line(6f, 8f, 6f, 50f, 0.7f, 0.9f, true); p.hatch(66f, 40f, 24f, 8f, 5, 0.4f)
            }
            // d03: mi horario: luz en la cortina, la taza se enfría, el pasillo oscuro
            "d03" -> {
                p.windowFrame(8f, 8f, 20f, 22f); p.line(8f, 8f, 26f, 28f, 0.4f)
                p.cup(40f, 40f, 1.1f); p.steam(41f, 28f, 2)
                p.door(66f, 50f, 34f); p.hatch(62f, 20f, 30f, 32f, 12, 0.7f); p.clock(86f, 12f, 5f)
            }
            // d04: cuatro dibujos pequeños: ventana abierta, taza junto a la cama, sombra hasta el armario, mamá
            "d04" -> {
                p.windowFrame(4f, 3f, 20f, 18f); p.line(4f, 3f, 12f, 12f, 0.5f)
                p.bed(30f, 20f, 18f); p.cup(40f, 14f, 0.6f)
                p.hatch(6f, 32f, 38f, 8f, 6, 0.6f); p.line(8f, 52f, 44f, 52f, 0.6f); p.door(44f, 52f, 18f)
                p.mom(78f, 56f, 0.7f); p.erase(70f, 30f, 6f, 6f)
                p.line(0f, 28f, 100f, 28f, 0.3f, 0.5f); p.line(52f, 0f, 52f, 60f, 0.3f, 0.5f)
            }
            // d05: instrucciones para colgar cuadros: cuatro marcos, uno torcido, ganchos
            "d05" -> {
                for (i in 0 until 4) {
                    val x = 6f + i * 23f
                    p.paper(x, 14f + (if (i == 2) 5f else 0f), 16f, 20f, 0)
                    p.line(x + 8f, 6f, x + 8f, 14f, 0.4f, 0.3f)
                    p.loop(x + 8f, 25f, 3f, 3.4f, 0.4f, 1f, false)
                }
                p.line(0f, 48f, 100f, 48f, 0.5f, 1f, true); p.smudge(60f, 20f, 8f, 4f)
            }
            // d06: la nota del electricista: caja de fusibles, cables y focos
            "d06" -> {
                p.paper(8f, 8f, 26f, 32f, 0)
                for (i in 0 until 4) { p.line(12f, 14f + i * 7f, 30f, 14f + i * 7f + (if (i % 2 == 0) 2f else -2f), 0.7f) }
                p.line(34f, 20f, 56f, 30f, 0.5f, 1.5f); p.line(56f, 30f, 62f, 44f, 0.5f, 1.5f)
                p.lamp(70f, 18f); p.lamp(84f, 24f); p.blob(70f, 44f, 3f, 0.8f, 8)
            }
            // d07: siete marcas raspadas y una oreja
            "d07" -> {
                for (i in 0 until 7) p.line(10f + i * 6f, 14f, 11f + i * 6f, 36f, 0.85f, 0.6f, i % 2 == 0)
                p.line(8f, 38f, 52f, 36f, 0.6f, 0.8f); p.loop(78f, 30f, 6f, 9f, 0.7f); p.loop(78f, 30f, 2.4f, 4f, 0.6f, 1f, false)
                p.hatch(60f, 46f, 30f, 8f, 5, 0.4f)
            }
            // d08: el retrato sin rostro: óvalo sin cara, cabello y borde borrado
            "d08" -> {
                p.paper(26f, 4f, 40f, 52f, 0); p.loop(46f, 28f, 12f, 16f, 0.7f)
                p.hatch(34f, 12f, 24f, 10f, 6, 0.8f); p.erase(40f, 22f, 12f, 12f); p.smudge(46f, 28f, 8f, 8f)
                p.line(34f, 50f, 58f, 50f, 0.5f)
            }
            // d09: un pasillo largo con puertas que no están donde deben y una grieta
            "d09" -> {
                p.line(4f, 14f, 96f, 22f, 0.7f, 1f, true); p.line(4f, 50f, 96f, 40f, 0.7f, 1f, true)
                p.door(14f, 50f, 24f); p.door(48f, 46f, 16f); p.door(76f, 42f, 10f)
                p.poly(0.9f, 60f, 14f, 64f, 24f, 58f, 30f, 63f, 40f); p.erase(10f, 20f, 6f, 8f)
            }
            // d10: caldera: tanque, tuberías y dos golpes de válvula
            "d10" -> {
                p.loop(26f, 34f, 14f, 18f, 0.75f); p.line(40f, 28f, 90f, 28f, 0.7f, 0.9f, true)
                p.line(40f, 36f, 84f, 38f, 0.7f, 0.9f, true); p.loop(60f, 28f, 3f, 3f, 0.7f); p.loop(74f, 28f, 3f, 3f, 0.7f)
                p.steam(60f, 20f, 2); p.hatch(12f, 24f, 28f, 20f, 8, 0.5f); p.blob(88f, 40f, 3f, 0.6f, 8)
            }
            // d11: antena con tres brazos de distinto largo, sombra larga y una torre oscura
            "d11" -> {
                p.line(30f, 52f, 30f, 8f, 0.8f, 0.7f, true)
                p.line(30f, 14f, 22f, 12f, 0.7f); p.line(30f, 22f, 16f, 18f, 0.7f); p.line(30f, 30f, 6f, 24f, 0.7f)
                p.line(30f, 52f, 96f, 52f, 0.45f, 1f); p.hatch(32f, 46f, 60f, 6f, 5, 0.6f)
                p.line(70f, 50f, 70f, 14f, 0.9f, 0.9f); p.line(78f, 50f, 78f, 14f, 0.9f, 0.9f); p.blob(74f, 30f, 7f, 0.85f)
            }
            // d12: huellas que no llevan adonde terminan: zapatos junto a la puerta, otras huellas lejos
            "d12" -> {
                p.door(6f, 52f, 30f)
                for (i in 0 until 5) { p.loop(22f + i * 10f, 50f - (i % 2) * 3f, 2.2f, 3.4f, 0.65f, 1f, false) }
                p.loop(86f, 40f, 3f, 4.5f, 0.75f); p.loop(92f, 44f, 3f, 4.5f, 0.75f); p.smudge(60f, 40f, 20f, 6f)
                p.erase(40f, 36f, 6f, 6f)
            }
            // d13: un vaso con agua y la lámpara rota en muchas partes
            "d13" -> {
                p.poly(0.75f, 38f, 20f, 40f, 48f, 56f, 48f, 58f, 20f); p.line(40f, 30f, 56f, 29f, 0.45f, 0.9f)
                p.lamp(48f, 10f); p.line(44f, 36f, 52f, 42f, 0.5f, 0.6f); p.line(52f, 36f, 44f, 42f, 0.5f, 0.6f)
                p.line(48f, 33f, 48f, 44f, 0.4f, 0.4f); p.hatch(40f, 32f, 16f, 14f, 5, 0.3f)
            }
            // d14a: mitad de la carta, mamá y el niño juntos pero separados por un borde roto
            "d14a" -> {
                p.poly(0.7f, 6f, 4f, 52f, 4f, 48f, 12f, 54f, 20f, 48f, 28f, 53f, 36f, 50f, 44f, 52f, 54f, 6f, 54f, 6f, 4f)
                for (i in 0 until 5) p.line(10f, 10f + i * 8f, 40f - (i % 2) * 8f, 10f + i * 8f, 0.45f, 0.5f)
                p.mom(70f, 50f, 0.9f); p.kid(86f, 50f, 0.8f, 1); p.clock(70f, 8f, 4f); p.line(66f, 4f, 74f, 12f, 0.9f)
            }
            // d14b: la otra mitad: el recuerdo y lo que se sintió, sin que una cosa borre la otra
            "d14b" -> {
                p.poly(0.7f, 50f, 4f, 94f, 4f, 94f, 54f, 50f, 54f, 54f, 46f, 48f, 38f, 53f, 28f, 48f, 20f, 52f, 12f, 50f, 4f)
                for (i in 0 until 4) p.line(58f, 12f + i * 9f, 88f - (i % 2) * 6f, 12f + i * 9f, 0.45f, 0.5f)
                p.kid(20f, 48f, 1f, 1); p.erase(8f, 20f, 8f, 8f); p.blob(34f, 34f, 4f, 0.5f, 8)
            }
            // d14c: la carta completa con el margen: zigzag, rectángulo, línea alta
            "d14c" -> {
                p.paper(12f, 4f, 50f, 52f, 6)
                p.poly(0.8f, 70f, 40f, 74f, 30f, 78f, 40f, 82f, 30f, 86f, 40f)
                p.poly(0.8f, 70f, 56f, 70f, 46f, 84f, 46f, 84f, 56f, 70f, 56f)
                p.line(68f, 8f, 90f, 8f, 0.9f, 0.5f, true); p.smudge(40f, 30f, 20f, 8f)
            }
            // d15: lista de compras; las últimas líneas cubiertas de trazos oscuros
            "d15" -> {
                p.paper(10f, 4f, 40f, 52f, 0)
                for (i in 0 until 7) p.line(15f, 10f + i * 6.5f, 44f - (i % 3) * 6f, 10f + i * 6.5f, 0.45f, 0.6f)
                p.blob(30f, 46f, 9f, 0.95f, 20); p.loop(76f, 36f, 11f, 12f, 0.65f); p.line(66f, 26f, 70f, 14f, 0.6f); p.line(86f, 26f, 82f, 14f, 0.6f)
            }
            // d16: entrada de la feria, dos personas bajo la lluvia, Ranita con costura
            "d16" -> {
                p.paper(6f, 8f, 30f, 20f, 2); p.rain(40f, 2f, 54f, 30f, 14)
                p.mom(58f, 54f, 0.85f); p.kid(78f, 54f, 0.75f, 0); p.frog(16f, 50f, 1.4f); p.line(12f, 46f, 20f, 47f, 0.7f, 0.3f)
            }
            // d17: tarjeta de cita: calendario, carpeta y reloj
            "d17" -> {
                p.paper(8f, 8f, 34f, 28f, 0)
                for (i in 0 until 3) for (j in 0 until 4) p.loop(14f + j * 7f, 16f + i * 7f, 1.4f, 1.4f, 0.4f, 1f, false)
                p.line(54f, 24f, 90f, 24f, 0.7f, 0.9f, true); p.line(54f, 24f, 56f, 52f, 0.7f); p.line(90f, 24f, 90f, 52f, 0.7f)
                p.line(56f, 52f, 90f, 52f, 0.7f); p.clock(20f, 48f, 5f)
            }
            // d18: el vecino: una puerta ajena, el niño pequeño diciendo que se encarga de todo
            "d18" -> {
                p.door(10f, 54f, 40f); p.kid(48f, 52f, 0.9f, 0)
                p.loop(76f, 20f, 16f, 10f, 0.55f); p.line(60f, 28f, 54f, 36f, 0.5f)
                p.line(66f, 18f, 86f, 18f, 0.4f, 0.4f); p.line(68f, 22f, 82f, 22f, 0.4f, 0.4f)
            }
            // d19: la ventana cerrada, lluvia fuera y una figura pequeña en un cuarto iluminado
            "d19" -> {
                p.windowFrame(8f, 4f, 50f, 40f); p.rain(10f, 6f, 46f, 36f, 18)
                p.kid(76f, 48f, 0.7f, 1); p.lamp(76f, 12f); p.house(64f, 54f, 30f, 20f, 1); p.smudge(30f, 24f, 18f, 8f)
            }
            // d20: la nota sin entregar: sobre cerrado, mamá y el niño, un abrazo torpe
            "d20" -> {
                p.envelope(8f, 8f, 34f, 22f); p.mom(62f, 52f, 1f); p.kid(80f, 50f, 0.9f, 0)
                p.line(68f, 36f, 76f, 38f, 0.5f, 0.6f); p.loop(60f, 8f, 3f, 3f, 0.5f, 1.1f, false); p.erase(52f, 4f, 4f, 4f)
            }
            // d21: la casa lo conserva todo en su sitio: taza, silla, cama, ventana en fila; nadie entra
            "d21" -> {
                p.cup(8f, 48f); p.line(30f, 28f, 30f, 48f, 0.7f); p.line(30f, 36f, 44f, 36f, 0.7f); p.line(44f, 36f, 44f, 48f, 0.7f)
                p.bed(52f, 48f, 26f); p.windowFrame(82f, 20f, 14f, 18f); p.hatch(2f, 52f, 96f, 6f, 4, 0.3f)
            }
            // d22: una envoltura vacía y una cara de disgusto («la mía sabe peor»)
            "d22" -> {
                p.poly(0.75f, 8f, 20f, 50f, 18f, 54f, 40f, 12f, 42f, 8f, 20f)
                p.line(8f, 20f, 2f, 14f, 0.6f); p.line(8f, 42f, 2f, 48f, 0.6f); p.line(54f, 18f, 60f, 12f, 0.6f)
                p.loop(78f, 26f, 10f, 10f, 0.7f); p.line(72f, 22f, 74f, 24f, 0.9f, 0.2f); p.line(82f, 22f, 84f, 24f, 0.9f, 0.2f)
                p.line(72f, 34f, 78f, 31f, 0.7f); p.line(78f, 31f, 84f, 34f, 0.7f)
            }
            else -> {
                p.loop(50f, 30f, 14f, 12f, 0.7f); p.hatch(34f, 22f, 32f, 16f, 6, 0.5f)
            }
        }
        return p.strokes
    }
}

/** Cruz pequeña dibujada a mano (señal de hospital / farmacia). */
private fun Pencil.cross(x: Float, y: Float) {
    line(x, y - 4f, x, y + 4f, 0.85f, 0.4f)
    line(x - 4f, y, x + 4f, y, 0.85f, 0.4f)
}
