package com.terror2d.diary

import com.terror2d.chapter.ChapterDocuments
import com.terror2d.story.Documents

/** Una hoja del cuaderno. Una nota larga ocupa varias hojas; el dibujo va DEBAJO del texto (o en la hoja siguiente si no cabe). */
class DiaryLeaf(
    val entryIndex: Int,
    val docId: String,
    val header: String,
    val title: String,
    val lines: List<String>,
    /** Número de hoja dentro de la nota (0..pages-1) y total de hojas de texto. */
    val pageInEntry: Int,
    val pagesInEntry: Int,
    /** Dibujo del niño en esta hoja: debajo del texto ([drawingBelow]) o ocupando la hoja entera ([drawingOnly]). */
    val hasDrawing: Boolean,
    val drawingOnly: Boolean
)

/**
 * v0.16: reparte el contenido del diario en hojas. Lógica pura y determinista:
 *  - orden = orden de DESCUBRIMIENTO (no el id interno);
 *  - el texto es el ORIGINAL del documento, sin resumir ni recortar: si no cabe se continúa en la hoja siguiente;
 *  - debajo del texto de cada nota va el dibujo del niño: en la misma hoja si sobran renglones, o en la hoja siguiente.
 */
object DiaryLayout {

    /** Renglones de texto por hoja (la letra es grande: legible en un móvil). */
    const val LINES_PER_PAGE = 8

    /** Si la última hoja de texto tiene como mucho estos renglones, el dibujo cabe debajo en la misma hoja. */
    const val DRAWING_FITS_BELOW = 4

    fun build(diary: DiaryState): List<DiaryLeaf> {
        val out = ArrayList<DiaryLeaf>()
        for (i in 0 until diary.size) {
            val e = diary.entries[i]
            val d = Documents.get(e.docId) ?: continue
            val all = ArrayList<String>(d.lines)
            val hw = d.handwritten
            if (hw != null) { all.add(""); all.addAll(ChapterDocuments.wrap(hw)) }
            val chunks = chunk(all)
            for (c in chunks.indices) {
                val last = c == chunks.size - 1
                val below = last && chunks[c].size <= DRAWING_FITS_BELOW
                out.add(DiaryLeaf(i, e.docId, d.header, d.title, chunks[c], c, chunks.size, below, false))
            }
            if (chunks.isNotEmpty() && chunks.last().size > DRAWING_FITS_BELOW) {
                out.add(DiaryLeaf(i, e.docId, d.header, d.title, emptyList(), chunks.size - 1, chunks.size, true, true))
            }
        }
        return out
    }

    /** Parte en hojas de [LINES_PER_PAGE] renglones; las hojas de continuación no empiezan con un renglón vacío. */
    fun chunk(lines: List<String>): List<List<String>> {
        val out = ArrayList<List<String>>()
        var cur = ArrayList<String>()
        for (ln in lines) {
            if (cur.size >= LINES_PER_PAGE) { out.add(cur); cur = ArrayList() }
            if (cur.isEmpty() && ln.isEmpty()) continue
            cur.add(ln)
        }
        if (cur.isNotEmpty() || out.isEmpty()) out.add(cur)
        // quita renglones vacíos sobrantes al final de cada hoja
        return out.map { pg -> var n = pg.size; while (n > 0 && pg[n - 1].isEmpty()) n--; pg.subList(0, n).toList() }
    }
}
