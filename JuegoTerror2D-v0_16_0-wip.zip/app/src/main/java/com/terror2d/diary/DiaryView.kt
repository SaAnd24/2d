package com.terror2d.diary

/**
 * v0.16: estado de la vista de «MI DIARIO» (el libro abierto). Lógica pura: abrir, cerrar, pasar hojas con una transición breve.
 * Mientras está abierto la escena NO simula (ni el niño, ni la criatura, ni el reloj): al cerrarlo todo sigue exactamente igual.
 */
class DiaryView {

    var isOpen: Boolean = false
        private set

    /** 0..1: apertura del libro (tapa -> abierto). */
    var openT: Float = 0f
        private set

    /** Hoja actual: -1 = portada; 0.. = hojas de [leaves]. */
    var page: Int = -1
        private set

    /** Hoja de la que se viene mientras dura el pase de hoja, y progreso 0..1 (1 = sin animación). */
    var flipFrom: Int = -1
        private set
    var flipT: Float = 1f
        private set

    var leaves: List<DiaryLeaf> = emptyList()
        private set

    /** Última hoja que el niño estaba mirando (el libro se abre donde lo dejó). */
    private var lastPage: Int = -1
    private var lastLeafCount = 0

    val isFlipping: Boolean get() = flipT < 1f

    /** Abre el libro. Si hay notas nuevas sin ver, se abre en la primera; si no, donde se quedó. */
    fun open(diary: DiaryState) {
        leaves = DiaryLayout.build(diary)
        val firstUnread = if (diary.unread > 0) firstLeafOfEntry(diary.size - diary.unread) else -1
        page = when {
            leaves.isEmpty() -> -1
            firstUnread >= 0 -> firstUnread
            lastPage in -1 until leaves.size && lastLeafCount == leaves.size -> lastPage
            else -> 0
        }
        lastLeafCount = leaves.size
        flipT = 1f
        flipFrom = page
        openT = 0f
        isOpen = true
    }

    private fun firstLeafOfEntry(entry: Int): Int {
        for (i in leaves.indices) if (leaves[i].entryIndex >= entry) return i
        return -1
    }

    fun close() {
        if (isOpen) lastPage = page
        isOpen = false
    }

    fun canNext(): Boolean = page < leaves.size - 1
    fun canPrev(): Boolean = page > -1

    fun next() { if (canNext()) flipTo(page + 1) }
    fun prev() { if (canPrev()) flipTo(page - 1) }

    private fun flipTo(p: Int) {
        flipFrom = page
        page = p
        flipT = 0f
    }

    /** Avanza animaciones y atiende un toque ([pressed]) en coordenadas lógicas. */
    fun update(dt: Float, pressed: Boolean, px: Float, py: Float) {
        if (!isOpen) return
        if (openT < 1f) openT = (openT + dt / OPEN_TIME).coerceAtMost(1f)
        if (flipT < 1f) flipT = (flipT + dt / FLIP_TIME).coerceAtMost(1f)
        if (!pressed || openT < 0.6f) return
        when {
            hitClose(px, py) -> close()
            hitPrev(px, py) -> prev()
            hitNext(px, py) -> next()
            // tocar el lado de la página también pasa de hoja (sin gestos difíciles)
            py < PAGE_BOTTOM && px < 90f -> prev()
            py < PAGE_BOTTOM && px > 230f -> next()
            page == -1 && py < PAGE_BOTTOM && px in 90f..230f && leaves.isNotEmpty() -> next()
        }
    }

    companion object {
        const val OPEN_TIME = 0.35f
        const val FLIP_TIME = 0.28f
        const val PAGE_BOTTOM = 146f

        // Controles táctiles (coordenadas lógicas 320 x 180)
        const val CLOSE_X0 = 286f; const val CLOSE_Y0 = 2f; const val CLOSE_X1 = 318f; const val CLOSE_Y1 = 30f
        const val PREV_X0 = 4f; const val PREV_Y0 = 148f; const val PREV_X1 = 78f; const val PREV_Y1 = 178f
        const val NEXT_X0 = 242f; const val NEXT_Y0 = 148f; const val NEXT_X1 = 316f; const val NEXT_Y1 = 178f

        fun hitClose(x: Float, y: Float) = x in CLOSE_X0..CLOSE_X1 && y in CLOSE_Y0..CLOSE_Y1
        fun hitPrev(x: Float, y: Float) = x in PREV_X0..PREV_X1 && y in PREV_Y0..PREV_Y1
        fun hitNext(x: Float, y: Float) = x in NEXT_X0..NEXT_X1 && y in NEXT_Y0..NEXT_Y1

        // Icono del diario (esquina superior izquierda)
        const val ICON_X0 = 3f; const val ICON_Y0 = 3f; const val ICON_X1 = 31f; const val ICON_Y1 = 31f
        fun hitIcon(x: Float, y: Float) = x in ICON_X0..ICON_X1 && y in ICON_Y0..ICON_Y1

        // Botón de soltar objeto (junto al objeto de las manos, arriba a la derecha)
        const val DROP_X0 = 224f; const val DROP_Y0 = 3f; const val DROP_X1 = 256f; const val DROP_Y1 = 33f
        fun hitDrop(x: Float, y: Float) = x in DROP_X0..DROP_X1 && y in DROP_Y0..DROP_Y1
    }
}
