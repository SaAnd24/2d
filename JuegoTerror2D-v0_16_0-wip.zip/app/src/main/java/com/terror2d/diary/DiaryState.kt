package com.terror2d.diary

/** Una nota archivada en «Mi diario». [order] es el orden de descubrimiento (0 = la primera). */
class DiaryEntry(
    val docId: String,
    val segmentId: String,
    val x: Float,
    val time: Float,
    val order: Int
) {
    /** Id base del documento (sin la variante «_t» del mundo TRAUMA). */
    val baseId: String get() = DiaryState.baseOf(docId)
}

/**
 * v0.16: contenido PERMANENTE de «Mi diario». Vive en [com.terror2d.core.GameState]: sobrevive a cambiar de habitación, de
 * mundo (NORMAL/TRAUMA) y a las capturas. Lógica pura (serializable a texto para un guardado futuro).
 */
class DiaryState {
    private val list = ArrayList<DiaryEntry>()
    private var seenCount = 0

    val entries: List<DiaryEntry> get() = list
    val size: Int get() = list.size

    /** Notas añadidas que el niño aún no ha visto al abrir el diario. */
    val unread: Int get() = (list.size - seenCount).coerceAtLeast(0)

    /** ¿Ya está archivado este documento (en cualquiera de sus variantes de mundo)? */
    fun has(docIdOrBase: String): Boolean {
        val b = baseOf(docIdOrBase)
        for (e in list) if (e.baseId == b) return true
        return false
    }

    /** Archiva el documento SOLO la primera vez. Devuelve true si se añadió ahora. */
    fun add(docId: String, segmentId: String, x: Float, time: Float): Boolean {
        if (has(docId)) return false
        list.add(DiaryEntry(docId, segmentId, x, time, list.size))
        return true
    }

    fun markAllSeen() { seenCount = list.size }

    /** Texto estable: una línea por nota «docId|segmento|x|tiempo». */
    fun toSaveString(): String {
        val sb = StringBuilder()
        sb.append(seenCount)
        for (e in list) sb.append('\n').append(e.docId).append('|').append(e.segmentId).append('|').append(e.x).append('|').append(e.time)
        return sb.toString()
    }

    fun loadSaveString(text: String) {
        list.clear()
        seenCount = 0
        val lines = text.split("\n")
        if (lines.isEmpty()) return
        seenCount = lines[0].trim().toIntOrNull() ?: 0
        for (i in 1 until lines.size) {
            val p = lines[i].split("|")
            if (p.size < 4) continue
            add(p[0], p[1], p[2].toFloatOrNull() ?: 0f, p[3].toFloatOrNull() ?: 0f)
        }
        if (seenCount > list.size) seenCount = list.size
    }

    companion object {
        fun baseOf(id: String): String = if (id.endsWith("_t")) id.substring(0, id.length - 2) else id
    }
}
