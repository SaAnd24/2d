package com.terror2d.scene

import com.terror2d.audio.SfxId
import com.terror2d.chapter.ChapterFlags
import com.terror2d.core.GameState
import com.terror2d.events.EventType
import com.terror2d.world.LightSource
import kotlin.math.abs

/**
 * v0.16: el APAGÓN narrativo. Se dispara UNA sola vez, al completar la primera lectura de la carta de la cama (la madre ya
 * gritó y desapareció: este evento no repite ni cambia nada de eso).
 *
 *  - Los focos revientan de uno en uno, en un orden con sentido físico (primero la planta de arriba, luego la baja, el sótano,
 *    la azotea), con un breve parpadeo previo y chispazos. Solo el foco de la habitación del niño suena fuerte; los de las
 *    demás salas llegan lejanos y apagados. Nunca suenan dos a la vez.
 *  - Al terminar quedan EXACTAMENTE cuatro luces funcionales, una por planta jugable ([SURVIVORS]). Los focos rotos siguen
 *    dibujados como decoración ([LightSource.broken]) pero no iluminan.
 *  - El circuito del sótano es el de N5: hasta restaurarlo da bajones intermitentes; al resolverlo queda estable. Resolver N5
 *    NUNCA enciende más luces ni anula el apagón.
 */
class BlackoutDirector(private val scene: Scene) {

    enum class Phase { IDLE, RUNNING, DONE }

    class Spark(val segId: String, val x: Float, val y: Float, var age: Float = 0f)

    private class Step(val at: Float, val segId: String, val light: LightSource)

    var phase: Phase = Phase.IDLE
        private set

    /** Chispazos activos (la escena los dibuja). */
    val sparks = ArrayList<Spark>()

    private val steps = ArrayList<Step>()
    private var clock = 0f
    private var next = 0
    private var strobing: Step? = null
    private var applied = false
    private var cellarLight: LightSource? = null

    /** Cuántas luces funcionales quedan en toda la casa (diagnóstico y tests). */
    fun functionalLights(): Int {
        val seen = java.util.Collections.newSetFromMap(java.util.IdentityHashMap<LightSource, Boolean>())
        for (seg in allSegments()) for (l in seg.lights) if (!l.broken) seen.add(l)
        return seen.size
    }

    private fun allSegments(): List<RoomSegment> {
        val out = ArrayList<RoomSegment>()
        out.addAll(scene.definition.segments)
        out.addAll(scene.definition.traumaSegments)
        return out
    }

    private fun findSegment(id: String): RoomSegment? = scene.definition.segments.firstOrNull { it.id == id }

    /** Las luces que sobreviven: (planta -> habitación, X del foco). */
    fun survivorOf(segId: String, light: LightSource): Boolean {
        for (s in SURVIVORS) if (s.first == segId && abs(s.second - light.x) < 1.5f) return true
        return false
    }

    /** Dispara el evento si aún no ocurrió. Devuelve true si empezó ahora. */
    fun start(state: GameState): Boolean {
        if (state.blackoutDone || phase != Phase.IDLE) return false
        state.blackoutDone = true
        phase = Phase.RUNNING
        steps.clear()
        clock = 0f
        next = 0
        var t = 1.1f
        for (segId in ORDER) {
            val seg = findSegment(segId) ?: continue
            for (l in seg.lights) {
                if (survivorOf(segId, l)) continue
                if (l.broken) continue
                // solo se «revientan» las que dan luz de verdad; las pasivas (ya apagadas) se rompen sin ruido al final
                if (!l.active && l.level < 0.05f) continue
                steps.add(Step(t, segId, l))
                t += 0.55f + 0.35f * ((steps.size * 37 % 5) / 4f)
            }
        }
        scene.events.post(EventType.BLACKOUT_STARTED, "blackout", scene.currentSegment.id)
        return true
    }

    fun update(dt: Float, state: GameState) {
        advanceSparks(dt)
        if (state.blackoutDone && phase == Phase.IDLE) phase = Phase.DONE   // partida cargada con el apagón ya hecho
        if (phase == Phase.RUNNING) {
            clock += dt
            // parpadeo previo (0.4 s antes de reventar)
            val upcoming = if (next < steps.size) steps[next] else null
            if (upcoming != null && clock >= upcoming.at - 0.4f && clock < upcoming.at) {
                strobing = upcoming
                val on = ((clock * 22f).toInt() % 2) == 0
                upcoming.light.active = on
            }
            while (next < steps.size && clock >= steps[next].at) {
                val st = steps[next]
                next++
                st.light.breakBulb()
                strobing = null
                emitPop(st, state)
            }
            if (next >= steps.size && clock > (steps.lastOrNull()?.at ?: 0f) + 1.2f) {
                phase = Phase.DONE
                applied = false
            }
        }
        if (phase == Phase.DONE && !applied) applyAll()
        syncCircuit(state)
    }

    private fun emitPop(st: Step, state: GameState) {
        val here = scene.currentSegment.id == st.segId
        if (here) {
            // el foco de ESTA sala: estallido claro, chispazo y un destello breve
            state.audio.playSfx(SfxId.LIGHT_BREAK, 0.75f)
            state.audio.playSfx(SfxId.MECH_ZAP, 0.3f)
            for (k in 0 until 4) sparks.add(Spark(st.segId, st.light.x + (k - 1.5f) * 2.2f, st.light.y + 2f, -0.04f * k))
        } else {
            // en otras salas llega lejano y apagado (nunca ensordecedor)
            state.audio.playSfx(SfxId.LIGHT_BREAK, 0.2f)
        }
    }

    private fun advanceSparks(dt: Float) {
        var i = sparks.size - 1
        while (i >= 0) {
            val s = sparks[i]
            s.age += dt
            if (s.age > 0.45f) sparks.removeAt(i)
            i--
        }
    }

    /** Rompe todos los focos que no sobreviven (en ambos mundos). Idempotente. */
    private fun applyAll() {
        for (seg in allSegments()) for (l in seg.lights) {
            if (!survivorOf(seg.id, l) && !l.broken) l.breakBulb()
        }
        applied = true
    }

    /** N5: el circuito del sótano es inestable hasta que se restaura; es una consecuencia persistente del puzzle. */
    private fun syncCircuit(state: GameState) {
        var l = cellarLight
        if (l == null) {
            val seg = findSegment(CELLAR_ID) ?: return
            l = seg.lights.firstOrNull { abs(it.x - CELLAR_LIGHT_X) < 1.5f } ?: return
            cellarLight = l
        }
        l.unstable = state.blackoutDone && !state.story.has(ChapterFlags.solved("N5"))
    }

    companion object {
        const val CELLAR_ID = "Cellar"
        const val CELLAR_LIGHT_X = 210f

        /** Una luz por planta jugable: arriba (pasillo), planta baja (vestíbulo), sótano (descansillo) y azotea. */
        val SURVIVORS: List<Pair<String, Float>> = listOf(
            "Hall" to 655f, "Foyer" to 120f, CELLAR_ID to CELLAR_LIGHT_X, "Roof" to 300f
        )

        /** Orden del apagón: de la habitación de mamá hacia abajo por la casa. */
        val ORDER: List<String> = listOf(
            "MomRoom", "Hall", "KidRoom", "Bathroom", "Closet", "Study",
            "Foyer", "Living", "Dining", "Kitchen", "Pantry", "ServiceBath",
            "Cellar", "Laundry", "Electric", "Boiler", "Storage", "Roof", "Impossible"
        )
    }
}
