package com.terror2d.creature

import kotlin.math.abs

enum class ConnectorKind { DOOR, WINDOW }

/**
 * v0.10: una conexión física entre dos segmentos (puerta o ventana). Es DATO: la escena la deriva de la definición de
 * la casa, así la casa de prueba es reemplazable (en 0.11 serán escaleras, huecos, atajos...) sin tocar la IA.
 */
class Connector(
    val id: String,
    val kind: ConnectorKind,
    val fromSeg: String,
    val fromX: Float,
    val toSeg: String,
    val toX: Float
)

/** La criatura aparece en [segmentId] porque llegó por una conexión. */
class Arrival(
    val segmentId: String,
    val x: Float,
    val state: CreatureState,
    val lastKnownX: Float,
    val facing: Float,
    val via: ConnectorKind
)

/**
 * Presencia PERSISTENTE de la criatura en la casa. La escena solo simula (con [Creature]/[CreatureBrain]) el segmento
 * donde está el niño; este rastreador mantiene a la criatura viva fuera de pantalla: dónde está, qué estado tenía y
 * qué conexión va a usar. Reglas de 0.10:
 *
 *  - PUERTA: si la criatura PERSEGUÍA al niño, va hasta la puerta y lo sigue en CHASE.
 *  - VENTANA: rompe la persecución. Pierde el foco (LOST_TARGET), conserva la última posición conocida (la ventana),
 *    la investiga y puede cruzarla (más despacio que el niño) para seguir buscando en la otra habitación.
 */
class CreatureTracker(
    private val connectors: List<Connector>,
    startSeg: String,
    startX: Float
) {
    var segId: String = startSeg
        private set
    var x: Float = startX
        private set
    var state: CreatureState = CreatureState.PATROL
        private set
    var lastKnownX: Float = startX
        private set
    var facing: Float = 1f
        private set
    var arousal: Float = 0f
        private set
    /** true = la criatura está materializada en la escena actual (la simula el [Creature]). */
    var live: Boolean = false
        private set

    private var plan: Connector? = null
    private var climbing = false
    private var timer = 0f
    private var idleLost = 0f

    // ---- v0.16: ronda persistente por toda la casa
    /** Ronda activa (la escena la habilita cuando termina la introducción de la criatura). */
    var patrolEnabled = false
    val route = HousePatrol(connectors)
    /** Tiempo (s) que le queda en la sala actual antes de continuar la ronda. */
    private var dwell = 6f
    /** El plan actual es un tramo de ronda (no una persecución ni una búsqueda). */
    private var patrolLeg = false
    /** Sala y X de un ruido fuerte oído desde lejos: va hacia allí (INVESTIGATE). */
    private var alertSeg: String? = null
    private var alertX = 0f
    private var liveExit: Connector? = null
    /** Salas por las que ha pasado (diagnóstico y tests). */
    var roomsVisited = 1
        private set

    val alertTarget: String? get() = alertSeg
    val liveExitConnector: Connector? get() = liveExit
    val isPatrolLeg: Boolean get() = patrolLeg

    val isCrossing: Boolean get() = plan != null
    val plannedConnector: Connector? get() = plan

    fun connectorById(id: String): Connector? = connectors.firstOrNull { it.id == id }

    /** Vuelve a patrulla en su sitio de origen (tras una captura el niño despierta a salvo). */
    fun resetTo(seg: String, cx: Float) {
        segId = seg; x = cx; lastKnownX = cx; state = CreatureState.PATROL
        plan = null; climbing = false; idleLost = 0f; live = false
        patrolLeg = false; alertSeg = null; liveExit = null; dwell = RESPAWN_DWELL
        route.forgetGoal()
    }

    /** v0.16: empieza la ronda en [seg]/[cx] (tras la primera aparición). */
    fun startPatrol(seg: String, cx: Float) {
        patrolEnabled = true
        segId = seg; x = cx; lastKnownX = cx; state = CreatureState.PATROL
        plan = null; climbing = false; idleLost = 0f; live = false
        patrolLeg = false; alertSeg = null; liveExit = null; dwell = FIRST_DWELL
        route.noteVisit(seg)
    }

    /** La escena marca si la criatura está (o no) materializada. */
    fun setLive(v: Boolean) { if (v && !live) liveExit = null; live = v }

    /** Copia el estado real de la criatura simulada. */
    fun syncLive(seg: String, cx: Float, st: CreatureState, known: Float, face: Float, arousalNow: Float) {
        segId = seg; x = cx; state = st; lastKnownX = known; facing = face; arousal = arousalNow
        plan = null; climbing = false; idleLost = 0f; patrolLeg = false
        if (st != CreatureState.PATROL) { liveExit = null; if (dwell < 3f) dwell = 3f }
    }

    /**
     * v0.16: la criatura materializada en la sala del niño sigue su ronda. Cuando agota su estancia (solo mientras está en
     * PATROL) elige el siguiente conector de la ronda; la escena le pide a la criatura que camine hasta él.
     * Devuelve el conector elegido UNA vez (null el resto del tiempo).
     */
    fun liveRoundStep(dt: Float): Connector? {
        if (!patrolEnabled || liveExit != null) return null
        dwell -= dt
        if (dwell > 0f) return null
        val c = route.nextConnector(segId)
        if (c == null) { dwell = 6f; return null }
        liveExit = c
        return c
    }

    /** La criatura materializada llegó a la salida de la ronda: sale de la sala. Devuelve true si cruzó. */
    fun liveCrossed(playerSeg: String): Boolean {
        val c = liveExit ?: return false
        liveExit = null
        patrolLeg = false
        live = false
        state = CreatureState.PATROL
        cross(c, playerSeg)
        return true
    }

    /** La salida de la ronda se canceló (p. ej. empezó a perseguir). */
    fun cancelLiveExit() { liveExit = null }

    /**
     * v0.16: un ruido FUERTE sonó en [seg] (X = [nx]); la criatura, si no está materializada y no persigue, va a esa sala
     * por los caminos reales de la casa y llega investigando. Devuelve true si se puso en marcha.
     */
    fun hearLoudNoise(seg: String, nx: Float): Boolean {
        if (live || !patrolEnabled) return false
        if (state == CreatureState.CHASE) return false
        if (seg == segId) {
            // ya está en esa sala (fuera de pantalla): investiga el punto
            state = CreatureState.INVESTIGATE; lastKnownX = nx
            return false
        }
        val path = route.pathTo(segId, seg) ?: return false
        if (path.isEmpty()) return false
        alertSeg = seg
        alertX = nx
        state = CreatureState.INVESTIGATE
        plan = path[0]
        climbing = false
        patrolLeg = false
        timer = 0f
        idleLost = 0f
        return true
    }

    /**
     * El niño acaba de cruzar [c]. Si la criatura estaba en el segmento de origen decide qué hace.
     * Devuelve true si la criatura pasa a tener un plan de cruce.
     */
    fun onPlayerLeft(c: Connector): Boolean {
        if (segId != c.fromSeg) return false
        when (c.kind) {
            ConnectorKind.WINDOW -> {
                // LA VENTANA ROMPE LA PERSECUCIÓN: pierde el foco directo, sin teletransporte ni invulnerabilidad.
                if (state == CreatureState.CHASE || state == CreatureState.INVESTIGATE || state == CreatureState.LOST_TARGET) {
                    state = CreatureState.LOST_TARGET
                    lastKnownX = c.fromX
                    plan = c; climbing = false; timer = 0f
                    return true
                }
            }
            ConnectorKind.DOOR -> {
                // v0.16: solo SIGUE al niño por la puerta si lo tenía cerca; si no, va a la puerta a buscar (no persigue sin ver)
                if (state == CreatureState.CHASE) {
                    val near = abs(c.fromX - x) <= FOLLOW_RANGE
                    lastKnownX = c.fromX
                    if (!near) state = CreatureState.LOST_TARGET
                    plan = c; climbing = false; timer = 0f; patrolLeg = false; alertSeg = null
                    return true
                }
            }
        }
        return false
    }

    /** Avanza la criatura fuera de pantalla. Devuelve una [Arrival] cuando entra en el segmento del jugador. */
    fun update(dt: Float, playerSeg: String): Arrival? {
        if (live) return null
        val p = plan
        if (p != null) {
            if (!climbing) {
                val sp = when (state) {
                    CreatureState.CHASE -> CreatureBrain.CHASE_SPEED
                    CreatureState.PATROL -> OFFSCREEN_PATROL_SPEED
                    CreatureState.INVESTIGATE -> OFFSCREEN_ALERT_SPEED
                    else -> CreatureBrain.LOST_SPEED
                }
                val dx = p.fromX - x
                facing = if (dx >= 0f) 1f else -1f
                val step = sp * dt
                if (abs(dx) <= step) {
                    x = p.fromX; climbing = true
                    timer = if (p.kind == ConnectorKind.WINDOW) WINDOW_CLIMB_TIME
                    else if (state == CreatureState.CHASE) DOOR_DELAY_CHASE else DOOR_DELAY
                } else x += facing * step
            } else {
                timer -= dt
                if (timer <= 0f) return cross(p, playerSeg)
            }
            return null
        }
        // sin plan: la búsqueda fuera de pantalla se enfría sola y la ronda continúa
        if (state == CreatureState.LOST_TARGET || state == CreatureState.INVESTIGATE) {
            idleLost += dt
            if (idleLost > OFFSCREEN_SEARCH_TIME) { state = CreatureState.PATROL; idleLost = 0f; dwell = 2f; route.forgetGoal() }
            return null
        }
        if (patrolEnabled && state == CreatureState.PATROL) {
            dwell -= dt
            if (dwell <= 0f) {
                val c = route.nextConnector(segId)
                if (c == null) { dwell = 6f }
                else { plan = c; climbing = false; patrolLeg = true; timer = 0f }
            }
        }
        return null
    }

    private fun cross(c: Connector, playerSeg: String): Arrival? {
        val wasPatrol = patrolLeg || state == CreatureState.PATROL
        val wasState = state
        plan = null; climbing = false; patrolLeg = false
        segId = c.toSeg
        x = c.toX
        roomsVisited++
        route.noteVisit(c.toSeg)
        // ---- v0.16: alerta por ruido: sigue el camino real hasta la sala del ruido
        val aSeg = alertSeg
        if (aSeg != null) {
            if (c.toSeg == aSeg) {
                alertSeg = null
                state = CreatureState.INVESTIGATE
                lastKnownX = alertX
                facing = 1f
                idleLost = 0f
                return if (playerSeg == c.toSeg) Arrival(c.toSeg, c.toX, CreatureState.INVESTIGATE, alertX, 1f, c.kind) else null
            }
            val rest = route.pathTo(c.toSeg, aSeg)
            if (rest != null && rest.isNotEmpty()) {
                plan = rest[0]; climbing = false; state = CreatureState.INVESTIGATE
                return null
            }
            alertSeg = null
        }
        if (wasPatrol && wasState == CreatureState.PATROL) {
            // ronda tranquila: llega en PATROL y se queda un rato antes de seguir
            state = CreatureState.PATROL
            dwell = DWELL_MIN + (DWELL_MAX - DWELL_MIN) * Det.hash01(11, roomsVisited, c.toSeg.hashCode())
            lastKnownX = c.toX + 120f
            facing = 1f
            idleLost = 0f
            return if (playerSeg == c.toSeg) Arrival(c.toSeg, c.toX, CreatureState.PATROL, lastKnownX, 1f, c.kind) else null
        }
        val intoFacing = 1f   // las llegadas se colocan junto al lado de entrada: mira hacia el interior
        facing = intoFacing
        val newState: CreatureState
        val known: Float
        if (c.kind == ConnectorKind.WINDOW) {
            newState = CreatureState.LOST_TARGET          // sigue SIN ver al niño: busca, no persigue
            known = c.toX + 60f
        } else {
            // v0.16: si venía persiguiendo de cerca lo sigue en CHASE; si solo investigaba la puerta, llega buscando
            newState = if (playerSeg == c.toSeg && wasState == CreatureState.CHASE) CreatureState.CHASE else CreatureState.LOST_TARGET
            known = c.toX + 120f
        }
        state = newState
        lastKnownX = known
        idleLost = 0f
        return if (playerSeg == c.toSeg) Arrival(c.toSeg, c.toX, newState, known, intoFacing, c.kind) else null
    }

    companion object {
        const val WINDOW_CLIMB_TIME = 1.9f
        const val DOOR_DELAY = 1.2f
        /** v0.16: al seguir al niño tarda más en cruzar la puerta (le da tiempo de correr o esconderse). */
        const val DOOR_DELAY_CHASE = 1.8f
        const val OFFSCREEN_SEARCH_TIME = 9f
        /** v0.16: velocidades fuera de pantalla (ronda y alerta). */
        const val OFFSCREEN_PATROL_SPEED = 30f
        const val OFFSCREEN_ALERT_SPEED = 46f
        /** v0.16: solo sigue por una puerta a menos de esta distancia del niño al irse. */
        const val FOLLOW_RANGE = 260f
        const val DWELL_MIN = 5f
        const val DWELL_MAX = 11f
        const val FIRST_DWELL = 10f
        const val RESPAWN_DWELL = 10f
    }
}
