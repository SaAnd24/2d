package com.terror2d.creature

/**
 * v0.16: planificador de la RONDA de la criatura por TODA la casa. Lógica pura (sin Android) que solo conoce la lista de
 * [Connector] reales (puertas y escaleras derivadas de la definición de la casa): NUNCA inventa una conexión.
 *
 * Reglas:
 *  - Elige como meta la sala menos visitada que sea alcanzable (desempate determinista con [Det]); al llegar elige otra.
 *    Así recorre todas las plantas con el tiempo y también vuelve a zonas ya visitadas, sin repetir siempre el mismo vaivén.
 *  - El camino hasta la meta es un BFS sobre los conectores (escaleras incluidas). Devuelve el siguiente conector.
 *  - Si por cualquier motivo no hay camino (conexión inexistente), la meta se descarta y se prueba con otra: nunca se bloquea.
 *  - Es independiente del niño: la ronda no depende de en qué planta esté.
 */
class HousePatrol(private val connectors: List<Connector>, private val seed: Int = 11) {

    private val rooms: List<String>
    private val visits = HashMap<String, Int>()
    private var goal: String? = null
    private var steps = 0

    init {
        val set = LinkedHashSet<String>()
        for (c in connectors) { set.add(c.fromSeg); set.add(c.toSeg) }
        rooms = set.toList()
    }

    /** Todas las salas que aparecen en alguna conexión. */
    val allRooms: List<String> get() = rooms

    fun visitsOf(seg: String): Int = visits[seg] ?: 0

    val currentGoal: String? get() = goal

    /** Anota que la criatura estuvo en [seg]. */
    fun noteVisit(seg: String) {
        visits[seg] = visitsOf(seg) + 1
        if (goal == seg) goal = null
    }

    /** Conectores que salen de [seg]. */
    fun exitsOf(seg: String): List<Connector> {
        val out = ArrayList<Connector>()
        for (c in connectors) if (c.fromSeg == seg) out.add(c)
        return out
    }

    /** Camino más corto (lista de conectores) de [from] a [to]; null si no existe. Vacío si ya está allí. */
    fun pathTo(from: String, to: String): List<Connector>? {
        if (from == to) return emptyList()
        val prev = HashMap<String, Connector>()
        val queue = ArrayDeque<String>()
        queue.add(from)
        val seen = HashSet<String>()
        seen.add(from)
        while (queue.isNotEmpty()) {
            val cur = queue.removeFirst()
            for (c in connectors) {
                if (c.fromSeg != cur || !seen.add(c.toSeg)) continue
                prev[c.toSeg] = c
                if (c.toSeg == to) {
                    val path = ArrayList<Connector>()
                    var at = to
                    while (at != from) {
                        val pc = prev[at] ?: return null
                        path.add(0, pc)
                        at = pc.fromSeg
                    }
                    return path
                }
                queue.add(c.toSeg)
            }
        }
        return null
    }

    fun isReachable(from: String, to: String): Boolean = pathTo(from, to) != null

    /**
     * Siguiente conector de la ronda desde [from]. Mantiene la meta hasta alcanzarla. Devuelve null solo si [from] no tiene
     * ninguna salida (sala aislada).
     */
    fun nextConnector(from: String): Connector? {
        for (attempt in 0 until rooms.size + 1) {
            var g = goal
            if (g == null || g == from) {
                g = chooseGoal(from)
                goal = g
            }
            if (g == null) break
            val path = pathTo(from, g)
            if (path != null && path.isNotEmpty()) { steps++; return path[0] }
            // la meta ya no es alcanzable: se descarta y se elige otra
            visits[g] = visitsOf(g) + 1
            goal = null
        }
        val exits = exitsOf(from)
        if (exits.isEmpty()) return null
        steps++
        return exits[(Det.hash01(seed, steps, 3) * exits.size).toInt().coerceIn(0, exits.size - 1)]
    }

    private fun chooseGoal(from: String): String? {
        var best: String? = null
        var bestScore = Float.MAX_VALUE
        for (i in rooms.indices) {
            val r = rooms[i]
            if (r == from) continue
            val path = pathTo(from, r) ?: continue
            // menos visitada primero; la distancia desempata a favor de las cercanas; el azar determinista rompe empates
            val score = visitsOf(r) * 10f + path.size * 0.6f + Det.hash01(seed, i, steps) * 2.2f
            if (score < bestScore) { bestScore = score; best = r }
        }
        return best
    }

    /** Descarta la meta actual (p. ej. tras perseguir al niño: la ronda se retoma desde donde esté). */
    fun forgetGoal() { goal = null }
}
