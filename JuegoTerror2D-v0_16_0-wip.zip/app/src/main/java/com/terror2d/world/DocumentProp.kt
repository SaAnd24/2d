package com.terror2d.world

import com.terror2d.chapter.ChapterDocuments
import com.terror2d.draw.Cr
import com.terror2d.draw.CrayonBuilder
import com.terror2d.draw.CrayonSprite
import com.terror2d.events.EventType
import com.terror2d.interaction.Interactable
import com.terror2d.interaction.InteractionContext
import com.terror2d.interaction.InteractionIcon
import com.terror2d.interaction.InteractionResult
import com.terror2d.render.WorldRenderer
import com.terror2d.story.Documents
import com.terror2d.util.SeededRandom

/** Aspecto del papel físico. */
enum class PaperKind { SHEET, LETTER, DRAWING, CARD, LIST, WRAPPER }

/**
 * v0.16: documento FÍSICO del mundo. Antes los documentos del capítulo eran zonas táctiles invisibles («LEER» sin nada que
 * leer). Ahora el objeto que se lee ES el que se ve: un papel dibujado en la habitación, con su zona táctil alrededor de lo que
 * se ve y una señal discreta (contorno y brillo suave) al acercarse.
 *
 *  - La interacción pertenece a este objeto: si no se dibuja, no se puede leer.
 *  - [collectible]: al archivarse en «Mi diario» el papel desaparece del mundo (no se recoge dos veces). Los que forman parte
 *    del escenario (dibujo de la pared, marcas, huellas...) se quedan, marcados como ya descubiertos: «RELEER», sin repetir nada.
 *  - Se dibuja en la capa OBJECT y la escena lo ordena DESPUÉS de los muebles, así parece apoyado sobre ellos y nunca queda tapado.
 *  - Los dos mundos (NORMAL/TRAUMA) reconstruyen sus objetos, pero el estado «descubierto» vive en el diario (global): nunca
 *    reaparece un papel ya archivado ni se duplica.
 */
class DocumentProp(
    val id: String,
    val baseId: String,
    x: Float,
    surfaceY: Float,
    w: Float,
    h: Float,
    val kind: PaperKind,
    val collectible: Boolean,
    private val gate: (InteractionContext) -> Boolean,
    private val priorityValue: Int = 10,
    /** Efecto propio al LEERLO (p. ej. «tengo la segunda mitad de la carta»). Solo la acción, nunca el archivado. */
    private val onRead: ((InteractionContext) -> Unit)? = null
) : WorldObject(x, surfaceY - h, w, h), Interactable {

    /** La introducción ya terminó (el papel existe y se puede usar). Lo actualiza la escena cada fotograma. */
    var gateOpen: Boolean = false
        private set
    /** Ya archivado en el diario (en cualquiera de sus variantes de mundo). */
    var discovered: Boolean = false
        private set
    /** Es el objetivo actual de interacción (la escena lo marca): se dibuja con un brillo discreto. */
    var hint: Boolean = false

    private var base: CrayonSprite = CrayonSprite.EMPTY
    private var glow: CrayonSprite = CrayonSprite.EMPTY
    private var pulse = 0f

    init {
        collidable = false
        layer = Layer.OBJECT
    }

    override val priority: Int get() = priorityValue
    override val interactionId: String get() = id
    override val promptText: String get() = "LEER"
    override val promptIcon: InteractionIcon get() = InteractionIcon.EXAMINE

    // la zona táctil rodea EXACTAMENTE el papel visible (mínimo cómodo para el dedo)
    private val zoneHalf: Float get() = maxOf(width * 0.5f + 12f, 26f)
    override val zoneLeft: Float get() = centerX - zoneHalf
    override val zoneRight: Float get() = centerX + zoneHalf
    override val markerX: Float get() = centerX
    override val markerY: Float get() = y - 6f

    /** ¿Se ve y se puede usar ahora? (misma condición para dibujarlo y para ofrecer «Leer»). */
    val isPresent: Boolean get() = gateOpen && !(collectible && discovered)

    /** La escena lo llama cada fotograma: sincroniza visibilidad e interacción con el estado REAL (historia + diario). */
    fun sync(ctx: InteractionContext) {
        gateOpen = gate(ctx)
        discovered = ctx.state.diary.has(baseId)
        visible = isPresent
    }

    override fun promptFor(ctx: InteractionContext): String {
        val docId = ChapterDocuments.idFor(baseId, ctx.state.worldMode)
        val t = Documents.get(docId)?.title ?: return if (discovered) "RELEER" else "LEER"
        val s = (if (discovered) "RELEER — " else "LEER — ") + t
        return if (s.length <= 24) s else s.substring(0, 23) + "…"
    }

    override fun canInteract(ctx: InteractionContext): Boolean {
        sync(ctx)
        return isPresent
    }

    override fun executeInteraction(ctx: InteractionContext): InteractionResult {
        ctx.post(EventType.ON_OBJECT_EXAMINED, id)
        onRead?.invoke(ctx)
        return InteractionResult.document(ChapterDocuments.idFor(baseId, ctx.state.worldMode))
    }

    override fun update(dt: Float) {
        pulse += dt
    }

    override fun prepareVisuals(rng: SeededRandom) {
        val b = CrayonBuilder(rng)
        buildPaper(b)
        base = b.finish()
        val g = CrayonBuilder(rng)
        g.outlineRect(x - 2f, y - 2f, width + 4f, height + 4f, 0xFFFFE9A8.toInt(), 1.1f)
        g.dots(x - 4f, y - 4f, width + 8f, height + 8f, 6, 0xFFFFF2C4.toInt(), 1.2f)
        glow = g.finish()
        outline = EMPTY
        hatch = EMPTY
    }

    private fun buildPaper(b: CrayonBuilder) {
        val paper = 0xFFEFE6CE.toInt()
        val ink = 0xFF4A3A2C.toInt()
        // sombra suave en el apoyo para que parezca puesto sobre la superficie
        b.fillOval(x + width * 0.5f, y + height + 0.5f, width * 0.55f, 1.6f, 0x55000000)
        when (kind) {
            PaperKind.LETTER -> {
                b.box(x, y, width, height, 0xFFE9DDBA.toInt(), 0, ink)
                b.line(x, y, x + width * 0.5f, y + height * 0.55f, ink, 1f)
                b.line(x + width, y, x + width * 0.5f, y + height * 0.55f, ink, 1f)
                b.fillRect(x + width * 0.42f, y + height * 0.5f, 3f, 3f, Cr.RED)
            }
            PaperKind.DRAWING -> {
                b.box(x, y, width, height, paper, 0, ink)
                b.scribble(x + 2f, y + 2f, width - 4f, height - 4f, Cr.BLUE, 4, 1f)
                b.fillRect(x + 3f, y + height - 5f, 4f, 3f, Cr.YELLOW)
            }
            PaperKind.CARD -> {
                b.box(x, y, width, height, 0xFFF4F0E4.toInt(), 0, ink)
                b.fillRect(x, y, width, 3f, Cr.TEAL)
                b.line(x + 2f, y + 7f, x + width - 3f, y + 7f, ink, 0.9f)
                b.line(x + 2f, y + 10f, x + width * 0.7f, y + 10f, ink, 0.9f)
            }
            PaperKind.LIST -> {
                b.box(x, y, width, height, 0xFFF2EAD0.toInt(), 0, ink)
                var k = 3f
                while (k < height - 2f) { b.line(x + 3f, y + k, x + width - 3f, y + k, ink, 0.8f); k += 3f }
                b.line(x + 2f, y, x + 2f, y + height, Cr.RED, 0.8f)
            }
            PaperKind.WRAPPER -> {
                b.box(x, y + 2f, width, height - 2f, 0xFFD7C9A0.toInt(), 0, ink)
                b.fillRect(x + 3f, y + 4f, width * 0.5f, 4f, Cr.ORANGE)
                b.line(x + width - 4f, y + 2f, x + width - 1f, y - 1f, ink, 0.9f)
            }
            PaperKind.SHEET -> {
                b.box(x, y, width, height, paper, 0, ink)
                var k = 4f
                while (k < height - 2f) { b.line(x + 3f, y + k, x + width - 4f, y + k, ink, 0.8f); k += 3.5f }
                b.line(x + width - 5f, y, x + width, y + 5f, 0xFFC9BC98.toInt(), 1f)
            }
        }
    }

    override fun visualHash(seed: Long): Long = base.hash(seed)

    override fun render(r: WorldRenderer) {
        if (!isPresent) return
        r.drawSprite(base)
        if (hint) {
            val a = 0.5f + 0.5f * kotlin.math.sin(pulse * 4f)
            if (a > 0.25f) r.drawSprite(glow)
        }
    }
}
