package com.terror2d.world

import com.terror2d.events.EventType
import com.terror2d.interaction.Interactable
import com.terror2d.interaction.InteractionContext
import com.terror2d.interaction.InteractionIcon
import com.terror2d.interaction.InteractionResult
import com.terror2d.inventory.DroppedItem
import com.terror2d.render.WorldRenderer
import com.terror2d.util.SeededRandom

/**
 * v0.16: un objeto que el niño soltó en el suelo. El estado vive en [com.terror2d.core.GameState.dropped] (el mundo recuerda
 * dónde lo dejó); este objeto es solo su presencia visible y la interacción «RECOGER» de la habitación donde cayó.
 */
class DroppedItemProp(val entry: DroppedItem, floorY: Float) :
    WorldObject(entry.x - 9f, floorY - 18f, 18f, 18f), Interactable {

    var gone: Boolean = false
        private set

    init {
        collidable = false
        layer = Layer.OBJECT
    }

    override fun prepareVisuals(rng: SeededRandom) {
        outline = EMPTY
        hatch = EMPTY
    }

    override fun visualHash(seed: Long): Long = entry.itemId.hashCode().toLong() + seed

    override fun render(r: WorldRenderer) {
        if (!gone) r.drawItemOnGround(entry.itemId, centerX, bottom)
    }

    override val priority: Int get() = 4
    override val interactionId: String get() = "dropped_" + entry.itemId
    override val promptText: String get() = "RECOGER"
    override val promptIcon: InteractionIcon get() = InteractionIcon.PICK
    override val zoneLeft: Float get() = x - 14f
    override val zoneRight: Float get() = right + 14f
    override val markerX: Float get() = centerX
    override val markerY: Float get() = y - 3f

    override fun canInteract(ctx: InteractionContext): Boolean = !gone

    override fun executeInteraction(ctx: InteractionContext): InteractionResult {
        if (ctx.held != null) return InteractionResult.message("Tengo las manos ocupadas.")
        return InteractionResult.pickup(entry.itemId) { c ->
            gone = true
            visible = false
            c.state.dropped.remove(entry)
            c.post(EventType.DROPPED_ITEM_PICKED, entry.itemId)
            InteractionResult.message("Lo recojo otra vez.")
        }
    }
}
