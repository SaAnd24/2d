package com.terror2d.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import com.terror2d.diary.ChildDrawings
import com.terror2d.diary.DiaryLayout
import com.terror2d.diary.DiaryLeaf
import com.terror2d.diary.DiaryState
import com.terror2d.diary.DiaryView
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.PI

/**
 * v0.16: dibuja el icono de «Mi diario», el botón de soltar objeto y el LIBRO abierto: portada artesanal, hojas de papel con
 * grano, líneas de lápiz y margen imperfecto, el texto original legible y, debajo, el dibujo de grafito del niño.
 * Sin lógica de juego (solo recorre [DiaryView], [DiaryLeaf] y los trazos de [ChildDrawings]). Sin imágenes: todo con Canvas.
 */
class DiaryRenderer {

    private val paint = Paint().apply { isAntiAlias = true }
    private val path = Path()
    private val rect = RectF()

    private val serifItalic = Typeface.create(Typeface.SERIF, Typeface.ITALIC)
    private val serifBold = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
    private val sans = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)

    // grano del papel: posiciones fijas (nada aleatorio en cada fotograma)
    private val grain = FloatArray(220) { i -> ((i * 7919 + 13) % 1000) / 1000f }

    // ---------------------------------------------------------------- icono y botón de soltar

    /** Cuadernito infantil dibujado a mano, discreto, esquina superior izquierda. [unread] = punto sutil de «nota nueva». */
    fun drawIcon(c: Canvas, unread: Boolean, pressed: Boolean) {
        val x = 6f
        val y = 6f
        val w = 20f
        val h = 24f
        paint.style = Paint.Style.FILL
        paint.color = if (pressed) 0xCCB9824C.toInt() else 0x99B9824C.toInt()
        path.reset()
        path.moveTo(x, y + 0.8f); path.lineTo(x + w - 0.6f, y); path.lineTo(x + w, y + h - 0.8f); path.lineTo(x + 0.4f, y + h)
        path.close()
        c.drawPath(path, paint)
        // páginas imperfectas asomando a la derecha
        paint.color = 0xCCF2E8CE.toInt()
        c.drawRect(x + w - 1.2f, y + 2f, x + w + 1.8f, y + h - 1.5f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = if (pressed) 0xEE402A1E.toInt() else 0xAA402A1E.toInt()
        c.drawPath(path, paint)
        c.drawLine(x + 4f, y + 1f, x + 4.4f, y + h - 0.5f, paint)       // lomo
        // garabato en la tapa: una estrellita torcida
        paint.strokeWidth = 0.9f
        c.drawLine(x + 11f, y + 6f, x + 12.4f, y + 11f, paint)
        c.drawLine(x + 12.4f, y + 11f, x + 16.5f, y + 8.6f, paint)
        c.drawLine(x + 16.5f, y + 8.6f, x + 10.2f, y + 8.4f, paint)
        c.drawLine(x + 7.6f, y + 15f, x + 17f, y + 15.6f, paint)
        c.drawLine(x + 8f, y + 18.5f, x + 14.5f, y + 18.2f, paint)
        if (unread) {
            paint.style = Paint.Style.FILL
            paint.color = 0xDDE9D58A.toInt()
            c.drawCircle(x + w - 1f, y + 2f, 2.1f, paint)
        }
    }

    /** Botón pequeño de soltar el objeto que lleva en las manos (solo aparece con un objeto). */
    fun drawDropButton(c: Canvas, pressed: Boolean) {
        val cx = 240f
        val cy = 18f
        paint.style = Paint.Style.FILL
        paint.color = if (pressed) 0x88F4ECD8.toInt() else 0x44F4ECD8
        c.drawCircle(cx, cy, 10f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.4f
        paint.color = if (pressed) 0xEE402A1E.toInt() else 0xAA402A1E.toInt()
        c.drawCircle(cx, cy, 10f, paint)
        c.drawLine(cx, cy - 5f, cx, cy + 3f, paint)
        c.drawLine(cx, cy + 4f, cx - 3.4f, cy, paint)
        c.drawLine(cx, cy + 4f, cx + 3.4f, cy, paint)
        c.drawLine(cx - 5f, cy + 6.4f, cx + 5f, cy + 6.4f, paint)
    }

    // ---------------------------------------------------------------- libro

    fun drawBook(c: Canvas, view: DiaryView, diary: DiaryState, time: Float) {
        val open = view.openT.coerceIn(0f, 1f)
        paint.style = Paint.Style.FILL
        paint.color = ((open * 0xCC).toInt() shl 24)
        c.drawRect(0f, 0f, 320f, 180f, paint)

        c.save()
        val sc = 0.93f + 0.07f * open
        c.translate(160f, 78f)
        c.scale(sc, sc)
        c.translate(-160f, -78f)

        // sombra del libro y cubierta que asoma por los bordes
        paint.color = 0x66000000
        c.drawRect(14f, 10f, 312f, 150f, paint)
        paint.color = 0xFF6B4A32.toInt()
        c.drawRect(8f, 4f, 308f, 146f, paint)

        if (view.isFlipping) {
            val f = view.flipT
            val s = abs(cos(f * PI.toFloat()))
            val idx = if (f < 0.5f) view.flipFrom else view.page
            // la hoja que cae por debajo ya se ve (la nueva) mientras gira la antigua
            if (f < 0.5f) drawPage(c, view, diary, view.page, time)
            c.save()
            c.translate(12f, 0f)
            c.scale(maxOf(s, 0.02f), 1f)
            c.translate(-12f, 0f)
            drawPage(c, view, diary, idx, time)
            paint.style = Paint.Style.FILL
            paint.color = (((1f - s) * 90f).toInt() shl 24)
            c.drawRect(12f, 6f, 308f, 146f, paint)
            c.restore()
        } else {
            drawPage(c, view, diary, view.page, time)
        }
        c.restore()
        drawControls(c, view)
    }

    private fun drawPage(c: Canvas, view: DiaryView, diary: DiaryState, page: Int, time: Float) {
        if (page < 0) drawCover(c, diary) else if (page < view.leaves.size) drawLeaf(c, view.leaves[page], diary)
    }

    private fun drawCover(c: Canvas, diary: DiaryState) {
        paint.style = Paint.Style.FILL
        paint.color = 0xFFA8693B.toInt()
        wobblyRect(12f, 6f, 308f, 146f)
        c.drawPath(path, paint)
        paint.color = 0x33000000
        for (i in 0 until 14) c.drawRect(12f, 12f + i * 9.5f, 308f, 13f + i * 9.5f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.4f
        paint.color = 0xFF3A2416.toInt()
        c.drawPath(path, paint)
        // etiqueta de papel pegada, con el título a mano
        paint.style = Paint.Style.FILL
        paint.color = 0xFFF0E6CC.toInt()
        rect.set(60f, 34f, 262f, 84f)
        c.save(); c.rotate(-1.6f, 160f, 60f)
        c.drawRect(rect, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 1f; paint.color = 0xFF3A2416.toInt()
        c.drawRect(rect, paint)
        paint.style = Paint.Style.FILL
        paint.typeface = serifBold
        paint.textSize = 26f
        paint.color = 0xFF2B2018.toInt()
        paint.textAlign = Paint.Align.CENTER
        c.drawText("Mi diario", 161f, 68f, paint)
        paint.textAlign = Paint.Align.LEFT
        c.restore()
        // garabatos infantiles en la tapa
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.2f
        paint.color = 0xFF3A2416.toInt()
        c.drawLine(80f, 112f, 96f, 104f, paint); c.drawLine(96f, 104f, 104f, 118f, paint); c.drawLine(104f, 118f, 82f, 120f, paint)
        c.drawLine(226f, 102f, 232f, 120f, paint); c.drawLine(232f, 120f, 244f, 108f, paint)
        paint.style = Paint.Style.FILL
        paint.typeface = serifItalic
        paint.textSize = 9f
        paint.color = 0xFFF0E6CC.toInt()
        paint.textAlign = Paint.Align.CENTER
        val msg = if (diary.size == 0) "Todavía no he guardado nada." else "Lo que he encontrado: " + diary.size
        c.drawText(msg, 160f, 136f, paint)
        paint.textAlign = Paint.Align.LEFT
    }

    private fun drawLeaf(c: Canvas, leaf: DiaryLeaf, diary: DiaryState) {
        // papel
        paint.style = Paint.Style.FILL
        paint.color = 0xFFF0E6CC.toInt()
        wobblyRect(12f, 6f, 308f, 146f)
        c.drawPath(path, paint)
        // textura ligera: grano
        paint.color = 0x22806A44
        for (i in 0 until grain.size step 2) c.drawCircle(14f + grain[i] * 292f, 8f + grain[(i + 1) % grain.size] * 136f, 0.5f + grain[i] * 0.5f, paint)
        // líneas de lápiz discretas y margen imperfecto
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 0.5f
        paint.color = 0x33585048
        var ly = 36f
        var k = 0
        while (ly < 142f) { c.drawLine(18f, ly + sin(k * 1.7f) * 0.5f, 304f, ly + 0.8f + sin(k * 2.3f) * 0.6f, paint); ly += 12f; k++ }
        paint.color = 0x55A05040
        c.drawLine(32f, 8f, 33.4f, 146f, paint)
        paint.strokeWidth = 1.1f
        paint.color = 0xFF4A3A28.toInt()
        c.drawPath(path, paint)
        paint.style = Paint.Style.FILL

        val left = 40f
        // cabecera pequeña (tipo de papel) y título
        paint.typeface = sans
        paint.textSize = 6.5f
        paint.color = 0xFF7A6A52.toInt()
        c.drawText(leaf.header + "  ·  " + (leaf.entryIndex + 1), left, 17f, paint)
        paint.typeface = serifBold
        paint.textSize = 12f
        paint.color = 0xFF2B2018.toInt()
        val title = if (leaf.pagesInEntry > 1) leaf.title + "  (" + (leaf.pageInEntry + 1) + "/" + leaf.pagesInEntry + ")" else leaf.title
        c.drawText(title, left, 31f, paint)

        // texto original
        paint.typeface = serifItalic
        paint.textSize = 10.5f
        paint.color = 0xFF2E2620.toInt()
        var ty = 46f
        for (ln in leaf.lines) { if (ln.isNotEmpty()) c.drawText(ln, left, ty, paint); ty += 12f }

        if (leaf.hasDrawing) {
            val top = if (leaf.drawingOnly) 40f else ty + 2f
            val x0 = left
            val x1 = 296f
            val y1 = 142f
            drawDrawing(c, leaf.docId, x0, top, x1, y1)
        }
    }

    /** El dibujo del niño: trazos de grafito (presión variable), manchas y zonas borradas. */
    private fun drawDrawing(c: Canvas, docId: String, x0: Float, y0: Float, x1: Float, y1: Float) {
        val w = x1 - x0
        val h = y1 - y0
        if (h < 20f) return
        val s = minOf(w / ChildDrawings.W, h / ChildDrawings.H)
        val ox = x0 + (w - ChildDrawings.W * s) * 0.5f
        val oy = y0 + (h - ChildDrawings.H * s) * 0.5f
        val strokes = ChildDrawings.strokesFor(docId)
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        for (st in strokes) {
            val pts = st.pts
            when (st.kind) {
                1 -> {
                    paint.style = Paint.Style.FILL
                    paint.color = 0x22302C30
                    rect.set(ox + (pts[0] - pts[2]) * s, oy + (pts[1] - pts[3]) * s, ox + (pts[0] + pts[2]) * s, oy + (pts[1] + pts[3]) * s)
                    c.drawOval(rect, paint)
                }
                2 -> {
                    paint.style = Paint.Style.FILL
                    paint.color = 0xB0F0E6CC.toInt()
                    c.drawRect(ox + pts[0] * s, oy + pts[1] * s, ox + (pts[0] + pts[2]) * s, oy + (pts[1] + pts[3]) * s, paint)
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = 0.6f
                    paint.color = 0x33404040
                    c.drawLine(ox + pts[0] * s, oy + (pts[1] + pts[3] * 0.6f) * s, ox + (pts[0] + pts[2]) * s, oy + (pts[1] + pts[3] * 0.3f) * s, paint)
                }
                else -> {
                    if (pts.size < 4) continue
                    path.reset()
                    path.moveTo(ox + pts[0] * s, oy + pts[1] * s)
                    var i = 2
                    while (i + 1 < pts.size) { path.lineTo(ox + pts[i] * s, oy + pts[i + 1] * s); i += 2 }
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = (0.55f + st.pressure * 1.1f).coerceAtLeast(0.5f)
                    val a = (95 + st.pressure * 150f).toInt().coerceIn(60, 245)
                    paint.color = (a shl 24) or 0x00282830
                    c.drawPath(path, paint)
                }
            }
        }
        paint.strokeCap = Paint.Cap.BUTT
    }

    private fun drawControls(c: Canvas, view: DiaryView) {
        // cerrar
        pill(c, DiaryView.CLOSE_X0, DiaryView.CLOSE_Y0, DiaryView.CLOSE_X1, DiaryView.CLOSE_Y1)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.8f
        paint.color = 0xFF402A1E.toInt()
        c.drawLine(295f, 9f, 309f, 23f, paint)
        c.drawLine(309f, 9f, 295f, 23f, paint)
        paint.style = Paint.Style.FILL
        paint.typeface = sans
        paint.textSize = 8f
        paint.textAlign = Paint.Align.CENTER
        if (view.canPrev()) {
            pill(c, DiaryView.PREV_X0, DiaryView.PREV_Y0, DiaryView.PREV_X1, DiaryView.PREV_Y1)
            paint.color = 0xFF402A1E.toInt()
            c.drawText("◀ ATRÁS", (DiaryView.PREV_X0 + DiaryView.PREV_X1) / 2f, 166f, paint)
        }
        if (view.canNext()) {
            pill(c, DiaryView.NEXT_X0, DiaryView.NEXT_Y0, DiaryView.NEXT_X1, DiaryView.NEXT_Y1)
            paint.color = 0xFF402A1E.toInt()
            c.drawText("SIGUE ▶", (DiaryView.NEXT_X0 + DiaryView.NEXT_X1) / 2f, 166f, paint)
        }
        paint.color = 0xCCF0E6CC.toInt()
        val label = if (view.page < 0) "Portada" else (view.page + 1).toString() + " / " + view.leaves.size
        c.drawText(label, 160f, 166f, paint)
        paint.textAlign = Paint.Align.LEFT
    }

    private fun pill(c: Canvas, x0: Float, y0: Float, x1: Float, y1: Float) {
        paint.style = Paint.Style.FILL
        paint.color = 0xE6F0E6CC.toInt()
        rect.set(x0, y0, x1, y1)
        c.drawRoundRect(rect, 5f, 5f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = 0xFF402A1E.toInt()
        c.drawRoundRect(rect, 5f, 5f, paint)
    }

    /** Rectángulo de bordes irregulares (páginas imperfectas), siempre igual. */
    private fun wobblyRect(x0: Float, y0: Float, x1: Float, y1: Float) {
        path.reset()
        path.moveTo(x0 + 0.5f, y0 + 1.2f)
        path.lineTo((x0 + x1) * 0.5f, y0 - 0.4f)
        path.lineTo(x1 - 0.6f, y0 + 0.8f)
        path.lineTo(x1 + 0.4f, (y0 + y1) * 0.5f)
        path.lineTo(x1 - 0.8f, y1 - 0.6f)
        path.lineTo((x0 + x1) * 0.5f, y1 + 0.5f)
        path.lineTo(x0 + 0.2f, y1 - 1f)
        path.lineTo(x0 - 0.4f, (y0 + y1) * 0.5f)
        path.close()
    }
}
