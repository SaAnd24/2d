package com.terror2d

import com.terror2d.chapter.ChapterDocuments
import com.terror2d.creature.CreatureState
import com.terror2d.creature.CreatureTracker
import com.terror2d.creature.HousePatrol
import com.terror2d.creature.NoiseType
import com.terror2d.diary.ChildDrawings
import com.terror2d.diary.DiaryLayout
import com.terror2d.diary.DiaryState
import com.terror2d.diary.DiaryView
import com.terror2d.inventory.DroppedItems
import com.terror2d.scene.BlackoutDirector
import com.terror2d.scene.ChapterHouse
import com.terror2d.scene.HouseDefinition
import com.terror2d.scene.buildConnectors
import com.terror2d.story.Documents
import com.terror2d.world.DocumentProp
import com.terror2d.world.Wardrobe
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** v0.16: patrullaje por toda la casa, escondites, documentos físicos, apagón, diario y objetos soltados. */
class Update016Test {

    private val def = ChapterHouse.create()

    // ------------------------------------------------------------------ 1. patrullaje

    @Test
    fun patrolRouteVisitsEveryReachableRoomUsingOnlyRealConnectors() {
        val cons = def.buildConnectors()
        val patrol = HousePatrol(cons)
        var at = HouseDefinition.HALL
        patrol.noteVisit(at)
        val seen = HashSet<String>()
        seen.add(at)
        for (i in 0 until 300) {
            val c = patrol.nextConnector(at) ?: break
            assertTrue("conector real", cons.contains(c))
            assertEquals(at, c.fromSeg)
            at = c.toSeg
            patrol.noteVisit(at)
            seen.add(at)
        }
        // todas las salas alcanzables a pie (sin los pasos secretos: estudio e imposible)
        val expected = def.segments.map { it.id }.toSet() - setOf(ChapterHouse.STUDY, ChapterHouse.IMPOSSIBLE)
        assertEquals(expected, seen)
    }

    @Test
    fun patrolGoesBackToAlreadyVisitedRooms() {
        val patrol = HousePatrol(def.buildConnectors())
        var at = HouseDefinition.HALL
        patrol.noteVisit(at)
        var returns = 0
        val visited = HashSet<String>()
        for (i in 0 until 200) {
            val c = patrol.nextConnector(at) ?: break
            at = c.toSeg
            if (visited.contains(at)) returns++
            visited.add(at)
            patrol.noteVisit(at)
        }
        assertTrue(returns > 5)
    }

    @Test
    fun offscreenCreatureKeepsPatrollingAcrossFloorsWhileThePlayerStaysPut() {
        val tr = CreatureTracker(def.buildConnectors(), HouseDefinition.HALL, 760f)
        tr.startPatrol(HouseDefinition.HALL, 760f)
        val rooms = HashSet<String>()
        var t = 0f
        while (t < 60f * 12f) { tr.update(0.1f, HouseDefinition.KID); rooms.add(tr.segId); t += 0.1f }
        assertTrue("recorre varias plantas: " + rooms, rooms.size >= 6)
        assertTrue(rooms.contains(ChapterHouse.FOYER))
        assertTrue(rooms.contains(HouseDefinition.CELLAR) || rooms.contains(ChapterHouse.ROOF))
    }

    @Test
    fun loudNoiseSendsTheCreatureToThatRoomAlongRealPaths() {
        val tr = CreatureTracker(def.buildConnectors(), HouseDefinition.CELLAR, 200f)
        tr.startPatrol(HouseDefinition.CELLAR, 200f)
        assertTrue(tr.hearLoudNoise(HouseDefinition.KID, 120f))
        var arrived = false
        var t = 0f
        while (t < 400f && !arrived) {
            val a = tr.update(0.1f, HouseDefinition.KID)
            if (a != null) { arrived = true; assertEquals(CreatureState.INVESTIGATE, a.state) }
            t += 0.1f
        }
        assertTrue(arrived)
        assertEquals(HouseDefinition.KID, tr.segId)
    }

    @Test
    fun droppedObjectsMakeANoiseThatCarriesAcrossTheHouse() {
        assertTrue(NoiseType.OBJECT_DROP.carries)
        assertFalse(NoiseType.WALK.carries)
    }

    // ------------------------------------------------------------------ 2. escondites

    @Test
    fun everyRoomHasItsOwnWardrobeWithAUniqueId() {
        val ids = HashSet<String>()
        for (s in def.segments) {
            val w = s.objects.filterIsInstance<Wardrobe>()
            assertTrue(s.id + " sin escondite", w.isNotEmpty())
            for (x in w) {
                assertTrue("id repetido " + x.id, ids.add(x.id))
                assertTrue(s.id, x.x >= s.leftBoundary - 1f && x.right <= s.rightBoundary + 1f)
            }
        }
    }

    @Test
    fun wardrobesDoNotOverlapDoorsOrDocuments() {
        for (s in def.segments) {
            val w = s.objects.filterIsInstance<Wardrobe>()
            for (x in w) {
                for (d in s.doors) assertFalse(s.id + " armario sobre puerta", x.right > d.x + 6f && x.x < d.right - 6f)
                for (o in s.objects) if (o is DocumentProp) assertFalse(s.id + " armario sobre documento " + o.id, x.right > o.x && x.x < o.right)
            }
        }
    }

    // ------------------------------------------------------------------ 3. documentos físicos

    @Test
    fun everyChapterDocumentHasAVisiblePhysicalPaperInsideItsRoom() {
        val bases = HashSet<String>()
        for (s in def.segments + def.traumaSegments) {
            for (o in s.objects) if (o is DocumentProp) {
                bases.add(o.baseId)
                assertTrue(o.id, o.width >= 18f && o.height >= 14f)
                assertTrue(o.id, o.x >= s.leftBoundary && o.right <= s.rightBoundary)
                assertTrue(o.zoneRight - o.zoneLeft >= 44f)
            }
        }
        // d13 (vaso) y d14a/c (puzles) se entregan por el mecanismo del puzle; el resto son papeles físicos
        for (b in listOf("d01", "d02", "d03", "d04", "d05", "d06", "d07", "d08", "d09", "d10", "d11", "d12", "d14b",
            "d15", "d16", "d17", "d18", "d19", "d20", "d21", "d22")) assertTrue(b, bases.contains(b))
    }

    @Test
    fun noDocumentIsDuplicatedInsideOneWorld() {
        for (list in listOf(def.segments, def.traumaSegments)) for (s in list) {
            val ids = s.objects.filterIsInstance<DocumentProp>().map { it.id }
            assertEquals(s.id, ids.size, ids.toSet().size)
        }
    }

    // ------------------------------------------------------------------ 4. Mi diario

    @Test
    fun diaryKeepsDiscoveryOrderAndAddsEachNoteOnlyOnce() {
        val d = DiaryState()
        assertTrue(d.add("d05", "Hall", 10f, 1f))
        assertTrue(d.add("d01", "KidRoom", 20f, 2f))
        assertFalse("segunda vez", d.add("d01", "KidRoom", 20f, 3f))
        assertFalse("variante del mismo documento", d.add("d01_t", "KidRoom", 20f, 4f))
        assertEquals(listOf("d05", "d01"), d.entries.map { it.docId })
        assertEquals(2, d.unread)
        d.markAllSeen()
        assertEquals(0, d.unread)
    }

    @Test
    fun diarySurvivesSaveAndLoad() {
        val d = DiaryState()
        d.add("d05", "Hall", 10f, 1f); d.add("d19", "KidRoom", 5f, 2f)
        val e = DiaryState()
        e.loadSaveString(d.toSaveString())
        assertEquals(d.entries.map { it.docId }, e.entries.map { it.docId })
    }

    @Test
    fun layoutNeverCutsTheOriginalTextAndKeepsTheDrawingUnderIt() {
        val d = DiaryState()
        val all = ChapterDocuments.ALL.filter { !it.id.endsWith("_t") }.map { it.id } + Documents.ALL.map { it.id } + Documents.momNote.id
        for (id in all) d.add(id, "Hall", 0f, 0f)
        val leaves = DiaryLayout.build(d)
        for (i in 0 until d.size) {
            val def = Documents.get(d.entries[i].docId)!!
            val rebuilt = leaves.filter { it.entryIndex == i }.flatMap { it.lines }.filter { it.isNotEmpty() }
            assertEquals(d.entries[i].docId, def.lines.filter { it.isNotEmpty() }, rebuilt.take(def.lines.count { it.isNotEmpty() }))
            assertTrue(leaves.any { it.entryIndex == i && it.hasDrawing })
        }
    }

    @Test
    fun everyDocumentHasItsOwnStableChildDrawing() {
        val sigs = HashSet<Int>()
        for (b in ChildDrawings.ALL_BASES) {
            val a = ChildDrawings.strokesFor(b)
            val again = ChildDrawings.strokesFor(b)
            assertTrue(b, a.isNotEmpty())
            assertTrue("estable", a === again)
            var h = a.size
            for (s in a) for (v in s.pts) h = h * 31 + v.toRawBits()
            assertTrue("dibujo repetido: $b", sigs.add(h))
        }
        assertEquals(28, ChildDrawings.ALL_BASES.size)
        assertNotEquals(ChildDrawings.strokesFor("d01").size, ChildDrawings.strokesFor("d15").size)
    }

    @Test
    fun diaryViewOpensWhereYouLeftItAndPagesWithBigTouchTargets() {
        val d = DiaryState()
        d.add("d01", "KidRoom", 0f, 0f); d.add("d02", "Dining", 0f, 0f)
        val v = DiaryView()
        v.open(d)
        assertTrue(v.isOpen)
        v.update(1f, false, 0f, 0f)
        v.next(); v.update(1f, false, 0f, 0f)
        val p = v.page
        v.close()
        d.markAllSeen()
        v.open(d)
        assertEquals(p, v.page)
        v.update(1f, true, 300f, 10f)
        assertFalse("la X cierra", v.isOpen)
        assertTrue(DiaryView.hitIcon(10f, 10f))
        assertTrue(DiaryView.NEXT_X1 - DiaryView.NEXT_X0 >= 40f)
    }

    // ------------------------------------------------------------------ 2. apagón

    @Test
    fun exactlyFourLightsSurviveTheBlackoutOnePerFloor() {
        assertEquals(4, BlackoutDirector.SURVIVORS.size)
        val floors = BlackoutDirector.SURVIVORS.map { s -> ChapterHouse.FLOORS.entries.first { it.value.contains(s.first) }.key }
        assertEquals("una por planta", floors.toSet().size, 4)
        for ((segId, x) in BlackoutDirector.SURVIVORS) {
            val seg = def.segment(segId)
            assertNotNull(segId, seg.lights.firstOrNull { Math.abs(it.x - x) < 1.5f })
        }
    }

    @Test
    fun aBrokenBulbNeverLightsAgain() {
        val l = def.segment(ChapterHouse.FOYER).lights.first()
        l.breakBulb()
        l.active = true
        assertFalse(l.active)
        assertTrue(l.broken)
    }

    // ------------------------------------------------------------------ objetos soltados

    @Test
    fun theWorldRemembersWhereAnItemWasDropped() {
        val di = DroppedItems()
        val e = di.drop("water_glass", "Bathroom", 120f, 3f)
        assertEquals(e, di.whereIs("water_glass"))
        assertEquals(1, di.inSegment("Bathroom").size)
        assertEquals(0, di.inSegment("Hall").size)
        di.remove(e)
        assertEquals(null, di.whereIs("water_glass"))
    }
}
