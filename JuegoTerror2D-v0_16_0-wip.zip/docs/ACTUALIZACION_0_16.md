# Actualización 0.16 — monstruo, oscuridad, documentos, «Mi diario», escondites y objetos soltados

**Estado de verificación: el código está ESCRITO, NO compilado ni ejecutado** (el entorno donde se escribió no tiene Kotlin/Gradle).
Hay pruebas nuevas en `Update016Test.kt` y una prueba existente adaptada (`NarrativeTest`, fin de la introducción), pero **no se han corrido**.
Lo primero al abrir el proyecto: `./gradlew testDebugUnitTest` y jugar la secuencia carta → apagón → criatura.

## 1. Patrullaje y persecución
- Causa real del patrullaje roto: la criatura solo se movía dentro de su sala, nunca cambiaba de habitación por sí sola, y los focos fuertes (zonas seguras) la frenaban también al patrullar.
- `creature/HousePatrol.kt` (nuevo): ronda por TODA la casa sobre los conectores reales (puertas/escaleras/trampilla); meta = sala menos visitada alcanzable, BFS, vuelve a salas ya visitadas, nunca inventa conexiones.
- `CreatureTracker`: ronda persistente fuera de pantalla (velocidad propia), estancias en cada sala, alerta por ruidos fuertes siguiendo caminos reales.
- `Scene.updateLiveRound`: en pantalla la criatura camina a la puerta/escalera elegida, la abre y sale; el rastreador la sigue.
- El patrullaje arranca al terminar la introducción (`beginPatrolAfterIntro`), ya no al cambiar de sala.
- Las luces solo la frenan mientras PERSIGUE; el hueco estrecho del pasillo lo cruza en ronda tranquila (si no, partía el pasillo en dos).
- Ritmo: pisadas del niño mucho más discretas (`WALK` 0.25→0.14), reacción 0.45→0.85 s, pierde el rastro a 1.2 s, arranque de persecución más lento, tras investigar ignora ruidos pequeños 7 s, solo sigue por una puerta si estaba a ≤260 px, tarda más en cruzarla (1.8 s), no aparece a <110 px del niño al cargar una sala.
- Capturas: sin cambios (no tocan progreso).

## 2. Escondites
- Armario/ropero/gabinete real en cada sala (mismo `Wardrobe` de siempre: entrar, esperar, salir). Nuevos en: Pasillo (ropero de abrigos, sustituye al perchero), Baño, Vestíbulo, Sala, Comedor, Cocina, Despensa, Baño de servicio, Armario, Estudio, Cuadro eléctrico, Caldera, Almacén, Azotea (gabinete) y Habitación imposible.
- Para que cupieran sin tapar puertas ni puzles se ensancharon: Baño 400, Comedor 520, Cocina 600, Despensa 380, Baño de servicio 340, Armario 460, Estudio 440, Eléctrico 340, Caldera 420, Azotea 500 (las que eran de cámara FIJA pasan a SIDE_SCROLLING).
- Solo cuenta como testigo de la entrada si la criatura está a ≤170 px; el armario «olvida» un uso cada 40 s (no se vuelve sospechoso para siempre).

## 3. Oscuridad
- `scene/BlackoutDirector.kt`: se dispara UNA vez al CERRAR la primera lectura de la carta de la cama (`doc_mom_note`). Focos reventándose en secuencia (parpadeo previo, chispazo, sonido fuerte solo en la sala actual, lejano en las demás).
- Quedan 4 luces: Pasillo (x655), Vestíbulo (x120), Descansillo del sótano (x210), Azotea (x300). Los demás focos se dibujan rotos y no iluminan (`LightSource.breakBulb`, irreversible; también la luz de la ventana).
- N5: el circuito del sótano da bajones intermitentes hasta que se resuelve; entonces queda estable. Nunca enciende más luces.
- La pista de N5 de la cocina se conserva (texto adaptado: «el foco reventó, pero antes…»).

## 4. Documentos físicos
- `world/DocumentProp.kt`: los documentos del capítulo eran zonas táctiles invisibles. Ahora son papeles dibujados, con zona táctil alrededor de lo visible, contorno suave al acercarse, ordenados DESPUÉS de los muebles. La acción «Leer» solo existe si el papel se ve.
- Recogibles desaparecen al archivarse; los de escenario (d02, d04, d05, d07, d08, d12) se quedan y pasan a «RELEER» sin repetir nada.
- Todos van en el suelo (no se usaron superficies de mesa/cama).
- d14b (segunda mitad de la carta) ahora es un papel visible en vez de una zona «RECOGER» invisible.
- d13, d14a y d14c los entrega el mecanismo del puzle (vaso / discos / carta), sin papel propio.

## 5. «MI DIARIO»
- Icono de cuaderno arriba a la izquierda (punto sutil si hay notas sin ver). Libro con portada, hojas con grano, líneas de lápiz, texto original en hojas de 8 renglones y el dibujo de grafito del niño debajo.
- Orden de descubrimiento, una sola vez por documento (mundo NORMAL/TRAUMA comparten entrada). Releer desde el diario no dispara nada.
- Mientras está abierto, el mundo se congela por completo (también `elapsedTime`).
- `diary/Pencil.kt` + `diary/ChildDrawings.kt`: 28 dibujos procedurales deterministas (22 del capítulo + variantes d14 + mamá/medical/finance/pharmacy). **No se ha visto ninguno renderizado: su calidad artística hay que juzgarla en el dispositivo.**
- No existe sistema de guardado en el proyecto: `DiaryState.toSaveString/loadSaveString` están listos, pero nada los persiste a disco todavía.

## 6. Objetos soltados
- Botón de soltar (junto al objeto de las manos, arriba a la derecha). El objeto queda en el suelo, el mundo recuerda dónde (`GameState.dropped`) y se puede recoger. Hace ruido (`OBJECT_DROP`) que avisa a la criatura de la HABITACIÓN y va hacia allí por caminos reales.
- No se pueden soltar compañeros (Ranita).
- **Ojo:** el texto original donde se describe esta mecánica llegó cortado; implementé lo que dijiste en el mensaje. Si había más reglas, no las conozco.

## Limitaciones conocidas
- La criatura no entra en el Estudio ni en la habitación imposible (solo se llega por pasos secretos/finales, que no son conexiones del mapa).
- Los 15 puzzles no se han tocado salvo la consecuencia de N5 sobre la luz del sótano.
