package com.terror2d

import com.terror2d.creature.Blocker
import com.terror2d.creature.CaptureSequence
import com.terror2d.creature.CreatureBrain
import com.terror2d.creature.CreatureState
import com.terror2d.creature.MouthAnimator
import com.terror2d.creature.NoiseEvent
import com.terror2d.creature.NoiseType
import com.terror2d.creature.Senses
import com.terror2d.world.Player
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CreatureTest {
    private val seg = "hall"

    private fun brain(x: Float = 400f) = CreatureBrain(x, seg, 100f, 700f, seed = 3)
    private fun senses(px: Float, now: Float = 0f) = Senses(playerX = px, playerSegmentId = seg, now = now)

    private fun run(b: CreatureBrain, s: Senses, seconds: Float, noises: List<NoiseEvent> = emptyList()) {
        var t = 0f
        while (t < seconds) { b.update(1f / 60f, s, noises); t += 1f / 60f }
    }

    @Test fun patrolMovesAndStaysPatrol() {
        val b = brain()
        val x0 = b.x
        run(b, senses(5000f), 8f)
        assertEquals(CreatureState.PATROL, b.state)
        assertNotEquals(x0, b.x)
        assertTrue(b.speed <= CreatureBrain.PATROL_SPEED + 0.01f)
    }

    @Test fun noiseTriggersInvestigateNotChase() {
        val b = brain()
        val n = NoiseEvent(250f, seg, NoiseType.VASE_FALL, time = 0f)
        run(b, senses(5000f), 0.3f, listOf(n))
        assertEquals(CreatureState.INVESTIGATE, b.state)
        assertNotEquals(5000f, b.lastKnownX)
    }

    @Test fun noiseHasPositionAndIsHeardApproximately() {
        val n = NoiseEvent(250f, seg, NoiseType.DOOR, time = 1f)
        assertEquals(250f, n.x, 0f)
        assertEquals(seg, n.segmentId)
        assertTrue(n.intensity > 0f && n.duration > 0f)
        val b = brain()
        run(b, senses(5000f), 0.3f, listOf(n))
        assertTrue(Math.abs(b.targetX - 250f) < 60f)
    }

    @Test fun visionTriggersChase() {
        val b = brain(400f)
        b.update(0.2f, senses(480f), emptyList())
        run(b, senses(480f), 0.3f)
        assertEquals(CreatureState.CHASE, b.state)
    }

    @Test fun visionDoesNotCrossWalls() {
        val b = brain(400f)
        val s = senses(500f)
        s.blockers = listOf(Blocker(440f, 460f, blocksSight = true))
        run(b, s, 1f)
        assertFalse(b.canSee(s))
        assertNotEquals(CreatureState.CHASE, b.state)
    }

    @Test fun hiddenPlayerIsNotSeenAndOtherSegmentIsNot() {
        val b = brain(400f)
        val s = senses(380f); s.playerHidden = true
        assertFalse(b.canSee(s))
        val s2 = Senses(playerX = 380f, playerSegmentId = "kitchen")
        assertFalse(b.canSee(s2))
    }

    @Test fun darknessShortensVision() {
        val b = brain(400f)
        val lit = senses(550f)
        val dark = senses(550f).also { it.playerLight = 0f }
        assertTrue(b.canSee(lit))
        assertFalse(b.canSee(dark))
    }

    @Test fun chaseIsAlwaysFasterThanChild() {
        assertTrue(CreatureBrain.CHASE_SPEED > Player.SPEED * 1.2f)
        assertTrue(CreatureBrain.PATROL_SPEED < Player.SPEED * 0.5f)
    }

    @Test fun losingTargetGoesLostThenReturnsToPatrol() {
        val b = brain(400f)
        run(b, senses(480f), 0.5f)
        assertEquals(CreatureState.CHASE, b.state)
        val hidden = senses(480f).also { it.playerHidden = true }
        run(b, hidden, 2f)
        assertEquals(CreatureState.LOST_TARGET, b.state)
        run(b, hidden, 12f)
        assertTrue(b.state == CreatureState.RETURN_TO_PATROL || b.state == CreatureState.PATROL)
        run(b, hidden, 20f)
        assertEquals(CreatureState.PATROL, b.state)
    }

    @Test fun smallGapBlocksTheBigBody() {
        val b = brain(400f)
        val s = senses(120f)
        s.blockers = listOf(Blocker(200f, 230f, blocksSight = false)) // ventilación: se ve, pero no cabe
        run(b, s, 6f)
        assertTrue(b.x > 230f)
    }

    @Test fun captureReturnsToBedroomWithoutGameOver() {
        val c = CaptureSequence()
        c.start()
        var relocated = false
        var t = 0f
        var maxBlack = 0f
        while (!c.done && t < 20f) {
            c.update(1f / 60f)
            if (c.shouldRelocate) relocated = true
            maxBlack = maxOf(maxBlack, c.blackAlpha)
            assertFalse(c.isGameOver)
            t += 1f / 60f
        }
        assertTrue(c.done)
        assertTrue(relocated)
        assertEquals(1f, maxBlack, 0.001f)
    }

    @Test fun capturingSetsFlagWhenReached() {
        val b = brain(400f)
        run(b, senses(410f), 0.5f)
        assertTrue(b.captured)
    }

    @Test fun mouthsUseDifferentPhasesAndNeverAllOpenTogether() {
        val m = MouthAnimator(9, 42)
        val phases = m.params.map { it.phaseOffset }.toSet()
        assertTrue(phases.size > 6)
        var maxOpen = 0
        var t = 0f
        while (t < 120f) { maxOpen = maxOf(maxOpen, m.openCount(t, 0.15f)); t += 0.05f }
        assertTrue(maxOpen < 9)
    }

    @Test fun mouthAnimationIsDeterministic() {
        val a = MouthAnimator(6, 7)
        val b = MouthAnimator(6, 7)
        for (i in 0 until 6) assertEquals(a.openness(i, 3.3f, 0.5f), b.openness(i, 3.3f, 0.5f), 0f)
    }
}
