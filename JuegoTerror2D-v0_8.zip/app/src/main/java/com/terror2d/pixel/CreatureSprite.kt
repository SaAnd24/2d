package com.terror2d.pixel

/**
 * LA CRIATURA (v0.8) en pixel art. USA LA MISMA DENSIDAD QUE EL NIÑO: [SCALE] es exactamente la escala del
 * protagonista (1 píxel de sprite = 0,5 px lógicos). No se parece en nada a la escena de Ranita en primera
 * persona (640×360): ahí un píxel de arte mide 0,5 px lógicos pero el dibujo es ~30 veces más detallado en un
 * encuadre cercano; aquí la criatura es mucho más grande (160×176) pero cada píxel pesa lo mismo que los del niño.
 *
 * Datos: [CreatureSpriteData] (generado por tools/sprite_gen/creature.py). Capas: cuerpo, brazos, cabeza, ojos,
 * boca principal, bocas secundarias y fluidos; así las bocas se animan por separado sin redibujar la criatura.
 */
object CreatureSprite {
    const val SCALE = ProtagonistSprite.SCALE
    const val BODY_W = CreatureSpriteData.BODY_W
    const val BODY_H = CreatureSpriteData.BODY_H
    /** Columna del cuerpo que cae sobre el centro de la criatura (la cadera). */
    const val ANCHOR_X = 70
    const val SECONDARY_MOUTHS = 9

    val PALETTE: IntArray = CreatureSpriteData.PALETTE

    val bodies: Array<IntArray> by lazy { Array(CreatureSpriteData.BODY_DATA.size) { SpriteCodec.decode(CreatureSpriteData.BODY_DATA[it], BODY_W * BODY_H) } }
    val armNear: Array<IntArray> by lazy { Array(CreatureSpriteData.ARM_NEAR.size) { SpriteCodec.decode(CreatureSpriteData.ARM_NEAR[it], CreatureSpriteData.ARM_W * CreatureSpriteData.ARM_H) } }
    val armFar: Array<IntArray> by lazy { Array(CreatureSpriteData.ARM_FAR.size) { SpriteCodec.decode(CreatureSpriteData.ARM_FAR[it], CreatureSpriteData.ARM_W * CreatureSpriteData.ARM_H) } }
    val head: IntArray by lazy { SpriteCodec.decode(CreatureSpriteData.HEAD_DATA, CreatureSpriteData.HEAD_W * CreatureSpriteData.HEAD_H) }
    val fluids: IntArray by lazy { SpriteCodec.decode(CreatureSpriteData.FLUIDS_DATA, CreatureSpriteData.HEAD_W * CreatureSpriteData.HEAD_H) }
    val eyesL: Array<IntArray> by lazy { Array(CreatureSpriteData.EYE_DATA_L.size) { SpriteCodec.decode(CreatureSpriteData.EYE_DATA_L[it], CreatureSpriteData.EYE_SIZE_L * CreatureSpriteData.EYE_SIZE_L) } }
    val eyesR: Array<IntArray> by lazy { Array(CreatureSpriteData.EYE_DATA_R.size) { SpriteCodec.decode(CreatureSpriteData.EYE_DATA_R[it], CreatureSpriteData.EYE_SIZE_R * CreatureSpriteData.EYE_SIZE_R) } }
    val mainMouths: Array<IntArray> by lazy { Array(CreatureSpriteData.MAIN_MOUTH_DATA.size) { SpriteCodec.decode(CreatureSpriteData.MAIN_MOUTH_DATA[it], CreatureSpriteData.MAIN_MOUTH_W * CreatureSpriteData.MAIN_MOUTH_H) } }
    val secMouths: Array<IntArray> by lazy {
        Array(CreatureSpriteData.SEC_DATA.size) {
            val size = it / 6
            SpriteCodec.decode(CreatureSpriteData.SEC_DATA[it], secW(size) * secH(size))
        }
    }

    fun secW(size: Int) = CreatureSpriteData.SEC_SIZES[size * 2]
    fun secH(size: Int) = CreatureSpriteData.SEC_SIZES[size * 2 + 1]

    /** Índice de [secMouths]: tamaño × sangre × estado (0 cerrada, 1 entreabierta, 2 abierta). */
    fun secIndex(size: Int, bloody: Boolean, state: Int) = size * 6 + (if (bloody) 3 else 0) + state

    /**
     * Misma fórmula de iluminación que [PixelRasterizer] (brillo con suelo SHADE_FLOOR + tinte), así el niño y la
     * criatura reaccionan igual a una misma luz. Lógica pura (testeable sin Android).
     */
    fun shade(indices: IntArray, w: Int, h: Int, light: LightingSample?, out: IntArray) {
        val shade = if (light == null) 1f else PixelRasterizer.SHADE_FLOOR + (1f - PixelRasterizer.SHADE_FLOOR) * light.brightness.coerceIn(0f, 1f)
        val tr = if (light == null) 1f else 1f + (light.tintR - 1f) * PixelRasterizer.TINT_STRENGTH
        val tg = if (light == null) 1f else 1f + (light.tintG - 1f) * PixelRasterizer.TINT_STRENGTH
        val tb = if (light == null) 1f else 1f + (light.tintB - 1f) * PixelRasterizer.TINT_STRENGTH
        for (i in 0 until w * h) {
            val idx = indices[i]
            val c = if (idx in PALETTE.indices) PALETTE[idx] else 0
            val a = (c ushr 24) and 0xFF
            if (idx == PixelIndex.TRANSPARENT || a == 0) { out[i] = 0; continue }
            val r = (((c shr 16) and 0xFF) * shade * tr).toInt().coerceIn(0, 255)
            val g = (((c shr 8) and 0xFF) * shade * tg).toInt().coerceIn(0, 255)
            val b = ((c and 0xFF) * shade * tb).toInt().coerceIn(0, 255)
            out[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
    }
}
