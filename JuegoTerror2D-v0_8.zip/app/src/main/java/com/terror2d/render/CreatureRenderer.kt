package com.terror2d.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import com.terror2d.creature.Creature
import com.terror2d.pixel.CreatureSprite
import com.terror2d.pixel.CreatureSpriteData
import com.terror2d.pixel.LightingSample
import kotlin.math.round
import kotlin.math.sin

/**
 * Dibuja la criatura por CAPAS (cuerpo, brazo lejano, cabeza, ojos, boca principal, bocas secundarias, fluidos,
 * brazo cercano) con la MISMA iluminación y la MISMA escala de píxel que el niño ([CreatureSprite.SCALE]).
 * Cada capa se rasteriza una vez por nivel de luz y se cachea: por frame solo hay drawBitmap sin filtrado.
 */
class CreatureRenderer {
    private val paint = Paint().apply { isAntiAlias = false; isFilterBitmap = false; isDither = false }
    private val dropPaint = Paint().apply { isAntiAlias = false; isFilterBitmap = false }
    private val cache = HashMap<Long, Bitmap>()
    private val quantized = LightingSample()
    private var buffer = IntArray(0)

    fun render(canvas: Canvas, c: Creature, centerX: Float, bottomY: Float, alpha: Float) {
        if (alpha <= 0.01f) return
        c.light.quantizeInto(quantized)
        val lk = c.light.key()
        paint.alpha = (alpha.coerceIn(0f, 1f) * 255f).toInt()
        val pose = c.bodyPose()
        val anchors = CreatureSpriteData.BODY_ANCHORS[pose]
        val breathY = round(c.breath())
        val hx = anchors[0]; val hy = anchors[1] + breathY.toInt()
        val tx = anchors[2]; val ty = anchors[3]
        val shx = anchors[4]; val shy = anchors[5]
        val armIdx = c.armPose()
        val ash = CreatureSpriteData.ARM_SHOULDER

        canvas.save()
        canvas.translate(round(centerX), round(bottomY))
        if (c.facing < 0f) canvas.scale(-1f, 1f)
        canvas.scale(CreatureSprite.SCALE, CreatureSprite.SCALE)
        canvas.translate(-CreatureSprite.ANCHOR_X.toFloat(), -CreatureSprite.BODY_H.toFloat())

        // brazo lejano, cuerpo, cabeza y sus capas, brazo cercano
        draw(canvas, 300 + armIdx, CreatureSprite.armFar[armIdx], CreatureSpriteData.ARM_W, CreatureSpriteData.ARM_H, lk, (shx - ash[0] - 6).toFloat(), (shy - ash[1]).toFloat())
        draw(canvas, 100 + pose, CreatureSprite.bodies[pose], CreatureSprite.BODY_W, CreatureSprite.BODY_H, lk, 0f, 0f)
        draw(canvas, 400, CreatureSprite.head, CreatureSpriteData.HEAD_W, CreatureSpriteData.HEAD_H, lk, hx.toFloat(), hy.toFloat())
        val es = c.eyeState
        val el = CreatureSpriteData.EYE_SIZE_L; val er = CreatureSpriteData.EYE_SIZE_R
        val ec = CreatureSpriteData.EYE_CENTERS
        draw(canvas, 500 + es, CreatureSprite.eyesL[es], el, el, lk, (hx + ec[0] - el / 2).toFloat(), (hy + ec[1] - el / 2).toFloat())
        draw(canvas, 600 + es, CreatureSprite.eyesR[es], er, er, lk, (hx + ec[2] - er / 2).toFloat(), (hy + ec[3] - er / 2).toFloat())
        val mm = c.mainMouth
        val mp = CreatureSpriteData.MAIN_MOUTH_POS
        draw(canvas, 700 + mm, CreatureSprite.mainMouths[mm], CreatureSpriteData.MAIN_MOUTH_W, CreatureSpriteData.MAIN_MOUTH_H, lk, (hx + mp[0]).toFloat(), (hy + mp[1]).toFloat())
        // bocas secundarias: cada una con su propia apertura
        val hm = CreatureSpriteData.HEAD_MOUTHS
        val tm = CreatureSpriteData.TORSO_MOUTHS
        for (i in 0 until hm.size) secondary(canvas, c, i, hm[i], hx, hy, lk)
        for (j in 0 until tm.size) secondary(canvas, c, hm.size + j, tm[j], tx, ty, lk)
        draw(canvas, 900, CreatureSprite.fluids, CreatureSpriteData.HEAD_W, CreatureSpriteData.HEAD_H, lk, hx.toFloat(), hy.toFloat())
        drawTears(canvas, c, hx, hy)
        draw(canvas, 200 + armIdx, CreatureSprite.armNear[armIdx], CreatureSpriteData.ARM_W, CreatureSpriteData.ARM_H, lk, (shx - ash[0]).toFloat(), (shy - ash[1]).toFloat())
        canvas.restore()
    }

    private fun secondary(canvas: Canvas, c: Creature, i: Int, m: IntArray, ox: Int, oy: Int, lk: Int) {
        val o = c.mouths.openness(i, c.time, c.arousal)
        val state = if (o < 0.12f) 0 else if (o < 0.5f) 1 else 2
        val idx = CreatureSprite.secIndex(m[0], m[3] != 0, state)
        val w = CreatureSprite.secW(m[0]); val h = CreatureSprite.secH(m[0])
        draw(canvas, 800 + idx + m[0] * 100, CreatureSprite.secMouths[idx], w, h, lk, (ox + m[1] - w / 2).toFloat(), (oy + m[2] - h / 2).toFloat())
    }

    /** Gotas que recorren las rutas de las lágrimas hasta entrar en las bocas. */
    private fun drawTears(canvas: Canvas, c: Creature, hx: Int, hy: Int) {
        val paths = CreatureSpriteData.TEAR_PATHS
        val col = shadeColor(CreatureSpriteData.PALETTE[22])
        dropPaint.color = col
        for (p in 0 until paths.size) {
            val path = paths[p]
            val n = path.size / 2 - 1
            for (d in 0 until 2) {
                val u = ((c.time * (0.35f + 0.25f * c.arousal) + p * 0.37f + d * 0.5f) % 1f) * n
                val seg = u.toInt().coerceIn(0, n - 1)
                val f = u - seg
                val x = path[seg * 2] + (path[seg * 2 + 2] - path[seg * 2]) * f
                val y = path[seg * 2 + 1] + (path[seg * 2 + 3] - path[seg * 2 + 1]) * f
                canvas.drawRect(hx + round(x), hy + round(y), hx + round(x) + 2f, hy + round(y) + 2f, dropPaint)
            }
        }
    }

    private fun shadeColor(c: Int): Int {
        val s = com.terror2d.pixel.PixelRasterizer.SHADE_FLOOR + (1f - com.terror2d.pixel.PixelRasterizer.SHADE_FLOOR) * quantized.brightness
        val r = (((c shr 16) and 0xFF) * s * quantized.tintR).toInt().coerceIn(0, 255)
        val g = (((c shr 8) and 0xFF) * s * quantized.tintG).toInt().coerceIn(0, 255)
        val b = ((c and 0xFF) * s * quantized.tintB).toInt().coerceIn(0, 255)
        return (paint.alpha shl 24) or (r shl 16) or (g shl 8) or b
    }

    private fun draw(canvas: Canvas, layer: Int, indices: IntArray, w: Int, h: Int, lightKey: Int, x: Float, y: Float) {
        val key = (layer.toLong() shl 16) or lightKey.toLong()
        var bmp = cache[key]
        if (bmp == null) {
            if (cache.size >= MAX_CACHED) cache.clear()
            val n = w * h
            if (buffer.size < n) buffer = IntArray(n)
            CreatureSprite.shade(indices, w, h, quantized, buffer)
            bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.setPixels(buffer, 0, w, 0, 0, w, h)
            cache[key] = bmp
        }
        canvas.drawBitmap(bmp, x, y, paint)
    }

    fun clear() {
        for (b in cache.values) b.recycle()
        cache.clear()
    }

    companion object { private const val MAX_CACHED = 384 }
}
