package com.terror2d.creature

import com.terror2d.pixel.LightingSample
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.sin

/** Animaciones pedidas para la criatura (las poses de cuerpo base se reutilizan; ver [Creature.bodyPose]). */
enum class CreatureAnim {
    IDLE, PATROL, WALK_1, WALK_2, WALK_3, INVESTIGATE, ALERT, CHASE_1, CHASE_2, LOST_TARGET, RETURN_TO_PATROL, HURT_LIGHT, CAPTURE
}

/** Estados de los ojos (índice = orden de CreatureSpriteData.EYE_STATES). */
object CreatureEye { const val OPEN = 0; const val HALF = 1; const val CLOSED = 2; const val LOOK_DOWN = 3; const val WIDE = 4 }

/** Estados de la boca principal (índice = orden de CreatureSpriteData.MAIN_MOUTH_STATES). */
object CreatureMouth { const val CLOSED = 0; const val TENSE = 1; const val OPEN = 2; const val WIDE = 3 }

/**
 * La criatura en el mundo: cerebro de IA + animación (pasos, brazos con inercia, ojos, bocas) + iluminación.
 * Todo es determinista y dependiente del tiempo; no hay objetos nuevos por frame.
 */
class Creature(
    x: Float,
    val segmentId: String,
    minX: Float,
    maxX: Float,
    seed: Int = 7
) {
    val brain = CreatureBrain(x, segmentId, minX, maxX, seed)
    val mouths = MouthAnimator(SECONDARY, seed * 31 + 5)
    private val seedI = seed

    val x: Float get() = brain.x
    /** Sentido en que mira: +1 derecha, -1 izquierda. */
    val facing: Float get() = brain.facing
    val state: CreatureState get() = brain.state
    val arousal: Float get() = brain.arousal

    /** Iluminación recibida (la calcula la escena con LightField, igual que el niño). */
    val light = LightingSample()
    var time = 0f
        private set

    /** 0 = quieto, 1..3 = WALK_1..3 (ciclo 1-2-3-2). */
    var walkFrame = 0
        private set
    private var walkClock = 0f
    private var chasePhase = 0
    var anim = CreatureAnim.IDLE
        private set
    /** Brazo con inercia (0..1): sube despacio al arrancar y se queda rezagado al frenar. */
    var armLag = 0f
        private set
    var eyeState = CreatureEye.HALF
        private set
    var mainMouth = CreatureMouth.CLOSED
        private set
    private var blinkClock = 0f
    var hurtTimer = 0f
    var capturing = false
    /** Y del suelo del segmento (la escena la fija al colocar a la criatura). */
    var floorY = 0f

    /** Aviso de paso (para el audio): se llama con (intensidad 0..1, esChase). */
    var onStep: ((Float, Boolean) -> Unit)? = null
    /** Aviso de sonido de boca/alarma por cambio de estado (para el audio). */
    var onStateChanged: ((CreatureState, CreatureState) -> Unit)? = null
    private var lastState = CreatureState.PATROL

    fun update(dt: Float, senses: Senses, noises: List<NoiseEvent>) {
        time += dt
        brain.update(dt, senses, noises)
        val st = brain.state
        if (st != lastState) { onStateChanged?.invoke(lastState, st); lastState = st }
        val sp = brain.speed
        val moving = sp > 1f
        val chasing = st == CreatureState.CHASE
        // pasos: más rápidos y largos al perseguir
        if (moving) {
            val period = if (chasing) 0.17f else 0.62f
            walkClock += dt
            if (walkClock >= period) {
                walkClock -= period
                val prev = walkFrame
                walkFrame = when (walkFrame) { 0 -> 1; 1 -> 2; 2 -> 3; else -> 2 }
                chasePhase = 1 - chasePhase
                if ((walkFrame == 1 || walkFrame == 3) && prev != walkFrame) onStep?.invoke(if (chasing) 1f else 0.55f, chasing)
            }
        } else { walkFrame = 0; walkClock = 0f }
        // brazos: siguen con retraso a la velocidad
        val target = min(1f, sp / CreatureBrain.CHASE_SPEED * 1.1f)
        armLag += (target - armLag) * min(1f, (if (target > armLag) 2.2f else 1.1f) * dt)
        updateFace(dt, st)
        anim = pickAnim(st, moving)
        if (hurtTimer > 0f) hurtTimer -= dt
    }

    private fun pickAnim(st: CreatureState, moving: Boolean): CreatureAnim {
        if (capturing) return CreatureAnim.CAPTURE
        if (hurtTimer > 0f) return CreatureAnim.HURT_LIGHT
        return when (st) {
            CreatureState.CHASE -> if (chasePhase == 0) CreatureAnim.CHASE_1 else CreatureAnim.CHASE_2
            CreatureState.INVESTIGATE -> if (moving) CreatureAnim.INVESTIGATE else CreatureAnim.ALERT
            CreatureState.LOST_TARGET -> CreatureAnim.LOST_TARGET
            CreatureState.RETURN_TO_PATROL -> if (moving) walkAnim() else CreatureAnim.RETURN_TO_PATROL
            CreatureState.PATROL -> if (moving) walkAnim() else CreatureAnim.IDLE
        }
    }

    private fun walkAnim() = when (walkFrame) { 1 -> CreatureAnim.WALK_1; 2 -> CreatureAnim.WALK_2; 3 -> CreatureAnim.WALK_3; else -> CreatureAnim.PATROL }

    /** Pose de cuerpo base (orden de CreatureSpriteData.BODY_POSES). */
    fun bodyPose(): Int = when (anim) {
        CreatureAnim.IDLE, CreatureAnim.PATROL, CreatureAnim.RETURN_TO_PATROL -> 0
        CreatureAnim.WALK_1 -> 1
        CreatureAnim.WALK_2 -> 2
        CreatureAnim.WALK_3 -> 3
        CreatureAnim.INVESTIGATE, CreatureAnim.LOST_TARGET -> 4
        CreatureAnim.ALERT -> 5
        CreatureAnim.CHASE_1 -> 6
        CreatureAnim.CHASE_2 -> 7
        CreatureAnim.CAPTURE -> 8
        CreatureAnim.HURT_LIGHT -> 9
    }

    /** Ángulo de brazo (índice de CreatureSpriteData.ARM_*): atrás con peso; adelante en la captura. */
    fun armPose(): Int {
        if (capturing) return 5
        val flick = target() - armLag
        if (flick < -0.35f) return 0               // frenó de golpe: los brazos se adelantan por inercia
        return (1 + (armLag * 3f + 0.5f).toInt()).coerceIn(1, 4)
    }
    private fun target() = min(1f, brain.speed / CreatureBrain.CHASE_SPEED * 1.1f)

    /** Respiración visual (0..1 de amplitud): lenta en PATROL, fuerte en CHASE. */
    fun breath(): Float = sin(time * (1.4f + 5.5f * arousal)) * (0.4f + 1.4f * arousal)

    private fun updateFace(dt: Float, st: CreatureState) {
        blinkClock += dt
        val blinkEvery = 3.2f + 2.4f * Det.hash01(seedI, floor(time / 3f).toInt())
        val blink = (blinkClock % blinkEvery) < 0.16f
        eyeState = when {
            blink -> CreatureEye.CLOSED
            st == CreatureState.CHASE -> CreatureEye.WIDE                 // miran al niño, siguen siendo tristes
            st == CreatureState.INVESTIGATE || st == CreatureState.LOST_TARGET -> CreatureEye.OPEN
            else -> if ((time * 0.35f).toInt() % 3 == 2) CreatureEye.LOOK_DOWN else CreatureEye.HALF   // mirada perdida
        }
        mainMouth = when (st) {
            CreatureState.CHASE -> if (sin(time * 9f) > 0f) CreatureMouth.WIDE else CreatureMouth.OPEN
            CreatureState.LOST_TARGET -> if (sin(time * 2.2f) > 0.2f) CreatureMouth.OPEN else CreatureMouth.TENSE
            CreatureState.INVESTIGATE -> CreatureMouth.TENSE
            else -> if (sin(time * 0.6f + seedI) > 0.85f) CreatureMouth.TENSE else CreatureMouth.CLOSED
        }
    }

    /** Distancia al niño (para el audio de proximidad). */
    fun distanceTo(px: Float) = abs(px - x)

    companion object {
        /** Nº de bocas secundarias: sale de los datos del sprite (cabeza + torso). */
        val SECONDARY: Int = com.terror2d.pixel.CreatureSpriteData.HEAD_MOUTHS.size + com.terror2d.pixel.CreatureSpriteData.TORSO_MOUTHS.size
        /** Alto lógico aproximado (176 px de sprite × 0,5). */
        const val HEIGHT = 88f
        /** Ancho lógico del cuerpo (para huecos que no puede cruzar). */
        const val BODY_WIDTH = 52f
    }
}
