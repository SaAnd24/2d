# MYMom — v0.7 — El peluche y el sistema de audio procedural

Juego de terror psicológico 2D para Android. Kotlin + Android Canvas, motor propio, 100 % offline
(sin Internet, sin backend, sin assets descargados). Resolución lógica 320×180, landscape, 16:9.

## Versión actual: v0.7.0
Extiende v0.6 sin reescribirla (todo lo de v0.6 y v0.4 sigue ahí, más abajo). **Dirección narrativa completa en
[`docs/DESIGN_BIBLE.md`](docs/DESIGN_BIBLE.md)** (canon, arco, reglas, los dos mundos).

### Novedades de v0.7 (compañero persistente + conversaciones + identidad sonora)
0.7 no es una colección de funciones: es el momento en que MYMom adquiere **un compañero persistente, conversaciones
reales e identidad sonora propia**. El mundo sigue siendo de papel y crayón y el protagonista pixel art de 96×128.

**Compañero (peluche) — `companion/`**
- **Dos espacios conceptuales**: **COMPANION SLOT** (`Inventory.companion`, reservado al peluche, no consume las manos,
  nada lo reemplaza) y **HAND SLOT** (`Inventory.held`, un único objeto físico: vaso, cajas de medicina, futuros).
  El inventario de 0.5 no cambia: se **extiende** (`ItemDef.companion`, `Inventory.add` rechaza compañeros).
- `CompanionState`: `NOT_FOUND → ON_FLOOR → (PICKUP) → ON_BACK ↔ TALKING`. `HandState`: `EMPTY, HOLDING_WATER,
  HOLDING_MEDICINE, HOLDING_OBJECT` (`Inventory.handState`). Añadir estados no obliga a rehacer nada.
- Al recogerlo va **a la espalda** del niño (`Player.companionItemId`): MISMO sprite 32×32 y MISMA escala que siempre,
  dibujado detrás del cuerpo, con la **misma iluminación** que el niño, balanceo sutil al caminar (sube/baja con los
  pasos, se rezaga al arrancar, respira apenas quieto) y posición pegada a la cabeza de cada pose. No se teletransporta.
- **Diseño**: sigue siendo claramente una ranita de peluche infantil, pero **ligeramente incómoda desde su primera
  aparición**: cabeza grande y ancha, ojos saltones y desiguales con **pupilas pequeñas**, **sonrisa cosida demasiado
  ancha** (con un hilo suelto), asimetrías, costuras visibles, remiendo, tela con trama, colores apagados. Sin sangre,
  ojos rojos ni deformaciones. (`tools/sprite_gen/items.py` → `SpriteData.kt`.)

**HABLAR y conversación — `conversation/`**
- Con el peluche `ON_BACK` y **las manos vacías** aparece el botón contextual **«HABLAR CON RANITA»** (segundo botón sobre el
  de acción; tecla T/Q). Con un objeto en las manos no aparece: primero hay que dejarlo.
- `ConversationView` (primera persona, mismo patrón que `FirstPersonView`): fundido a **negro casi absoluto**; solo las
  **dos manos del niño sosteniendo el peluche**. Sin habitación, sin HUD, sin caja de texto del mundo.
- **Arte hiperdetallado** (`tools/sprite_gen/conversation_art.py` → `ConversationArtData.kt`): 640×360 (1 px de arte =
  0,5 px lógicos), 176 colores, sombreado por mapa de alturas (dedos separados con 3 falanges, uñas con cutícula y
  brillo, nudillos, arrugas, tendones, pecas, un rasguño, una marca de bolígrafo, una uña mordida, manga de lana; peluche
  con trama, fibras, costuras, ojos de plástico con reflejo, parche y sombras de contacto). Se decodifica al entrar y
  se **libera** al salir.
- **Manos vivas, peluche inmóvil**: respiración y temblor por dedo, con `breathingIntensity` y `handTremorIntensity`
  configurables por escena (`ConversationView.setHandState`, `ConversationLine.tremor/breathing`). El peluche **no**
  parpadea, no mueve pupilas, boca, cabeza ni respira: la inquietud sale de que el niño está vivo y nervioso.
- **Sistema de conversaciones** (datos, no código): `ConversationDef` = trigger, condición, líneas, perfil de voz,
  intensidad, pausa previa, transición, cooldown, repetible, prioridad, contexto (mundo). `ConversationSystem` gestiona
  cola, calma, condición y «solo una vez». Las definiciones viven en `Conversations.kt`.
- **Triggers temporales (solo para demostrar el sistema)**: **A** `WATER_DELIVERED` (tras entregar el agua a mamá, pausa,
  escena breve «¿Ya terminaste?»); **B** `MEDICINE_PUZZLE_COMPLETED` (sonido suave → silencio → respiración/temblor →
  «Sabía que eres un niño especial.»). Si el peluche aún no va a la espalda o hay un objeto en las manos, esperan.
  Se sustituyen por condiciones narrativas cambiando definiciones, sin tocar el sistema.

**Audio procedural — `audio/`** (sin MP3/WAV: el APK no incluye ningún archivo de audio)
```
GAMEPLAY → EVENTO → AudioDirector → AudioPort (AudioEngine) → cola de comandos → hilo de audio → SÍNTESIS
AudioEngine ├─ VoiceSynth    perfiles CHILD, MOTHER, FROG (+ DOCTOR, NEIGHBOR, MONSTER preparados)
            ├─ SfxSynth      pasos (WOOD/TILE/GROUND/HOSPITAL), recoger/dejar, interacción, papel, vaso, agua,
            │                medicina, puerta, respiración, latido, tela, peluche…
            ├─ MusicSynth    secuenciador por capas (PAD, CHILD, FROG, TENSION): HOME, CHILD_THEME, FROG_SCENE, TENSION, SILENCE
            ├─ AmbienceSynth viento, zumbido de casa, reloj, tuberías, electricidad, crujidos, respiración
            └─ AudioEffects  reverb, eco, resonancia, distorsión suave, paso-bajo; perfiles de MUNDO NORMAL / TRAUMA
```
- `AudioPort` es la API de alto nivel (`playVoice`, `playSfx`, `playMusic`, `setAmbience`, `setWorld`, `duck`).
  `GameState.audio` la expone; el GameLogic no contiene síntesis. `AudioDirector` es el único sitio que sabe qué suena
  con cada evento (`FOOTSTEP`, `ON_ITEM_PICKED` ≡ OBJECT_PICKED_UP, `ON_ITEM_GIVEN/PLACED` ≡ OBJECT_DROPPED, `WATER_DELIVERED`,
  `MEDICINE_PUZZLE_COMPLETED`, `FROG_TALK`, `COMPANION_PICKED_UP`, `DIALOGUE_LINE`, `CONVERSATION_*`…).
- **Voz**: balbuceo de sílabas no lingüísticas + «mmm» (`HUM`) + «hm» (`HM`); oscilador → formantes de vocal → bitcrusher
  → envolvente ADSR; pitch, velocidad, duración, intensidad, timbre, vibrato, ruido de aire y envíos de reverb/eco por
  perfil y por emoción. El texto no se pronuncia: la voz es feedback emocional. La del niño es suave, corta y aguda;
  la de mamá, cálida y más grave; la de la rana, artificial, pequeña y algo extraña (FM + bitcrusher suave + eco), **no** terrorífica.
- **Motor**: PCM 16 bit mono 44,1 kHz en `AudioTrack` (modo STREAM, escritura bloqueante **solo en su hilo**), bloques de 512
  muestras, 56 voces prealocadas (sin objetos por muestra, voz robada si se llena), limitador final y protección NaN.
  El hilo del juego solo encola comandos. Arranca en `onResume`, se detiene y libera la salida en `onPause`, `release()` en `onDestroy`.
- **NORMAL / TRAUMA**: mismos eventos con otros parámetros (`WorldAudioProfile`: tono, reverb, eco, distorsión, brillo, resonancia).
  `GameState.worldMode` ya se refleja en el audio; todavía no existe ningún mapa Trauma.

**Deliberadamente fuera de 0.7**: criatura, persecución, muerte, desaparición de mamá, espejo, mundo Trauma, hospital,
parque, cementerio, transformación o rotura del peluche, sangre, explicación de la enfermedad, personalidad completa del
peluche y memoria narrativa. Tampoco se rehacen las animaciones del protagonista (caminar, idle, pickup, hurt, hide,
flashback) ni se tocan `Player.paperEffects` (conservado sin activar nada).

### Novedades de v0.6 (puzzle de medicamentos + correcciones visuales)
- **Protagonista a 96×128 píxeles internos** (antes 48×64), dibujado a **escala 0.5**: ocupa la misma silueta en pantalla
  (~50 px lógicos) con el DOBLE de detalle. Pixel art real, `nearest-neighbor`, sin blur ni antialiasing, 38 colores.
  Mechones de pelo, oreja, rubor y marca de la mejilla, bufanda con vueltas de lana, suéter con trama, pliegues, línea roja
  con relieve y dobladillo acanalado, manos con dedos, pantalón con rodilla y dobladillo, zapatillas con suela, puntera y cordones.
- **Cara intercambiable** (`FaceLayer`): ojos (`OPEN/HALF/CLOSED/WIDE/DOWN`: esclerótica, iris, pupila, brillo, párpados, cejas)
  y boca (`NEUTRAL/SMILE/SAD/OPEN/SPEAK`) son parches sobre la cabeza de cada pose. **Parpadea** solo (intervalo variable
  determinista) y la boca se mueve cuando el niño habla. HURT cierra los ojos, HIDE los abre mucho, PICKUP mira al suelo.
- **Objetos bien sujetos**: el objeto se dibuja entre el cuerpo y la **mano delantera** (capa de primer plano), así los dedos
  quedan por encima del vaso, las cajas y el peluche.
- **Escala canónica única** (`ItemSprites`): ranita 32×32 px = 16×16 lógicos, caja 16×22 = 8×11, vaso 14×22 = 7×11.
  El MISMO sprite sirve para el suelo, la cama, la mano, el inventario, `HOLD_ITEM` y `PLACED`.
- **Efectos de papel** (`PaperEffects`): lágrimas, sudor, temblor, marcas de dolor y respiración fría como recortes de papel
  pegados sobre la cabeza (bordes irregulares, fibras, sombra mínima). Preparados (`Player.paperEffects`, máscara de bits); aún sin disparador.
- **Puzzle de las 3 cajas** en la mesita de mamá (tras la introducción, botón `ORDENAR`): cambio **temporal a primera persona**
  (`FirstPersonView`: la cámara se acerca y se funde con la mesa vista desde los ojos del niño). Se ven la mesa, un pastillero de papel
  con 3 huecos, las 3 cajas, la hoja de la farmacia y las manos del niño. **Tocar + mantener + arrastrar + soltar**; un toque corto
  da la vuelta a la caja. Sin menús ni mensajes de error. Al resolver: brillo discreto, evento `MEDICINE_PUZZLE_COMPLETED` y vuelta a tercera persona.
- **Tres documentos** (`Documents`): médico (cómoda de mamá), económico (mesa de la cocina) y farmacia/tratamiento (la hoja de la mesita,
  pista del puzzle). Nombres inventados, sin logos. El niño reacciona como un niño de 8 años.
- Los datos de sprites los genera `tools/sprite_gen` (Python, solo para generar; el juego no lo usa): `python3 emit_kotlin.py`
  reescribe `pixel/SpriteData.kt`.

### Novedades de v0.5
- **Protagonista definitivo** (48×64, 17 colores): pelo castaño despeinado, suéter naranja de lana con línea roja,
  pantalón caqui, zapatos blancos, bufanda corta rojo oscuro y una pequeña marca en la mejilla.
  Poses: `IDLE`, `WALK_1..3`, `PICKUP`, `HOLD_ITEM`, `GIVE_ITEM`, `HURT`, `HIDE`, `FLASHBACK` y `HOLD_WALK_1..3`
  (caminar con un objeto). `Player.pose` las elige según estado y objeto en mano; `Player.poseOverride` queda
  para HURT/FLASHBACK en eventos futuros. Las manos tienen punto de agarre por pose (`PixelCharacterData.hand`).
- **Inventario reutilizable** (`inventory/`): `ItemDef` (id, nombre, icono, descripción, apilable, usable, mundo),
  `ItemRegistry`, `Inventory` (cantidad, capacidad, objeto en las manos). Vive en `GameState.inventory`; el HUD
  dibuja el objeto en una casilla discreta arriba a la derecha.
- **Recoger y entregar con animación**: `InteractionResult.pickup(...)` / `give(...)` (+ continuación con texto o hitos).
  El niño se agacha (`PICKUP`), el objeto pasa a su mano (`HOLD_ITEM`) y entrega con `GIVE_ITEM`.
  Eventos `ON_ITEM_PICKED`, `ON_ITEM_GIVEN`, `ON_ITEM_PLACED`.
- **Vaso de agua**: en la cocina (grifo, "TOMAR AGUA") tras pedirlo mamá; se ve en la mano y se entrega a mamá.
- **Medicamentos como objetos**: tres cajitas (azul, naranja, blanca) en la mesita de mamá (`WorldPickup`: recoger,
  dejar en su sitio, "Tengo las manos ocupadas."). Mamá pide la azul; otra caja la rechaza ("Esa no, cariño. La azul.").
  **Sin puzzle ni contraseña**: eso es v0.6.
- **Base de objetos utilizables**: `Interactable.promptFor/iconFor` (botón según estado), `ScriptedSpot` con prompts
  dinámicos y receptores de objetos (mamá, la cama del niño).
- **Peluche de rana completo** (`PlushFrog`): `ON_FLOOR → HELD → PLACED`; se recoge, se transporta y se deja en la cama.
  No habla ni tiene personalidad todavía (v0.7).
- **Preparación NORMAL/TRAUMA**: `WorldMode`, `GameState.worldMode`, `RoomSegment.worldMode`,
  `SceneDefinition.traumaSegments` + `segmentFor`. Sin mapas ni transición del Mundo Trauma.

### Flujo de la introducción (v0.5)
mamá llama → agua en la cocina → entregar el agua → mamá pide la cajita azul → recoger la azul en la mesita →
entregarla → «Estas cosas saben feo. No sé por qué mamá toma tantas.»

---

## Versión v0.4.0 (base)
La escena de prueba de v0.3 se convierte en **la casa del protagonista**: un niño de 8 años en una casa
que parece normal. El mundo está dibujado a crayón; el niño es pixel art. Empiezas en tu cuarto, mamá te
llama desde otra habitación y recorres la casa observando, escuchando y examinando.
Sin monstruo, sin persecución, sin sustos: el malestar sale de la luz, la composición y los detalles.

### La casa
Un **pasillo principal** largo (960 px, `SIDE_SCROLLING`) con acceso directo a siete espacios:

| Espacio | Luz | Notas |
|---|---|---|
| `KidRoom` (inicio) | cálida | cama, juguetes, dibujos, libros, ventana, **Ranita** (peluche de rana/farmacia, solo objeto ambiental), armario |
| `Bathroom` | blanca/fría | pequeño (`FIXED`), espejo, botiquín, bañera con patito |
| `MomRoom` | tenue | cama de mamá, mesita con pastillas como props, póster de la rana, armario |
| `Laundry` | fría/artificial | estrecha (`FIXED`), lavadora, cesto, tendedero, armario |
| `Kitchen` | cálida | refri con dibujos, fregadero, estufa, mesa con tres platos |
| `Dining` | cálida apagada | mesa familiar, fotos, dibujo del niño, globo de cumpleaños |
| `Cellar` | oscuridad fuerte | cajas, mueble tapado, herramientas, muñeca vieja, armario |

Armarios (esconderse como en v0.3) en: habitación del niño, de mamá, bodega y lavandería.
Cada espacio tiene 4–11 puntos examinables con la voz de un niño de 8 años (frases breves y simples).

### Introducción
`IntroScript` (guion de escena basado en hitos `StoryFlags`): ~5 s después de empezar, mamá dice
*«Cariño, ¿puedes ayudarme?»*, luego *«Ya es hora de mis pastillas.»* y *«¿Me traes un poco de agua también?»*.
Cada línea ocurre **una sola vez**. Puedes tomar agua en la cocina (grifo) y llevársela a mamá.
No hay inventario ni puzzle: solo hitos narrativos (`StoryState`), la base sobre la que v0.5/v0.6 construirán.

### Nuevo estilo visual: crayón detallado
`draw/CrayonBuilder`: rellenos de trazos en dos pasadas con distinta presión, contornos dobles que se pasan
de las esquinas, manchas, garabatos, caritas de dibujo infantil. Todo se genera **una vez** al cargar el segmento
con `SeededRandom` (misma semilla = mismo dibujo); el renderer solo recorre las operaciones.
`BackdropBuilder` dibuja paredes (rayas, lunares, flores irregulares, azulejos, tablones) y suelos
(madera, baldosas, cemento) en tramos de 160 px; solo se pintan los visibles.
Lo "grotesco bonito" es sutil y parece accidental: un tic de más en el reloj, flores con demasiados pétalos,
un patito con sonrisa demasiado grande, una silueta borrosa en el espejo, cinco vasos iguales, tres platos,
la persona demasiado alta en la ventana del dibujo, la rana de la farmacia que siempre sonríe.

### Protagonista pixel art
`pixel/`: `PixelCharacterData` (48×64, paleta de 13 colores, matriz de índices por pose), `PixelPose`
(`IDLE`, `WALK_1..3`, y preparadas `HIDE`, `HURT`, `FLASHBACK`), `PixelRasterizer` (matriz → ARGB, lógica pura)
y `render/PlayerPixelRenderer` (bitmap cacheado por pose y luz, sin allocations por frame).
El renderer **no sabe quién es el personaje**: sirve para flashbacks, otros niños o versiones del protagonista
(`withPalette`). ~50 px visibles: la cámara cercana de v0.3 no cambia.

### La luz afecta al personaje
`world/LightField` calcula la luz que recibe un punto con las **mismas luces y la misma caída** que la máscara de
oscuridad. Esa muestra (`LightingSample`: brillo + tinte) se aplica a los píxeles del niño: se oscurece en la
sombra y se tiñe con lámparas cálidas/frías. Además lo cubre la propia máscara de oscuridad de v0.3.

### Arquitectura de render
```
GameRenderer → BaseRenderer (lienzo, tint/visualCorruption, HUD, texto)
                 └ WorldRenderer (puertas, armarios, luces, personaje)
                      └ CrayonRenderer (fondos y objetos de crayón)
PlayerPixelRenderer · LightingRenderer · máscara de oscuridad
Futuro: GraphiteRenderer · ScratchRenderer · DistortionRenderer (heredan de WorldRenderer)
```
`visualCorruption` sigue en `0.0` (`BaseRenderer.tint` ya lo respeta, también en el personaje).

### Se conserva de v0.3
Cámara cercana, movimiento lateral, `RoomSegment`, puertas y transiciones con fundido, colisiones, interacción
contextual y botón de acción genérico, texto con borde de crayón, `EventBus` (+ `ON_STORY_FLAG`), `ExamineSpot`,
`Wardrobe`, `LightSwitch`, iluminación localizada, ocultarse (HIDDEN, ojos en la rendija), `SeededRandom`
(solo para trazos y detalles, nunca posiciones, puertas, colisiones ni progreso) y separación update/render.

## Tests
`./gradlew testDebugUnitTest` (v0.7: `CompanionAudioTest` — slots, HABLAR, conversaciones y su ritmo, triggers A/B, arte, motor de audio offline: determinismo, superficies, mundos, voces, música, ambiente, ciclo de vida; incluye v0.5: inventario, flujo agua → mamá → cajita azul, peluche, poses, NORMAL/TRAUMA): 8 espacios y conexiones con el pasillo, destinos y spawns de cada puerta,
recorrido completo de la casa, límites y colisiones, cámara cercana/FIXED/SIDE_SCROLLING, interacción,
`ExamineSpot`, `Wardrobe` en las cuatro habitaciones, intro de una sola vez, agua + mamá, matriz pixel
(misma matriz = mismo personaje, otras paletas = otro resultado), iluminación sobre el personaje,
crayón y fondos deterministas, estructura independiente de la semilla, transiciones sin romper el estado.

## Build
`.github/workflows/build.yml` (sin cambios): Actions → `assembleDebug` → artifact **JuegoTerror2D-debug-apk**
→ tests unitarios. La raíz del ZIP es la raíz del repositorio.

## Hoja de ruta (todo sobre esta misma arquitectura)
- **v0.5 — inventario y medicamentos como objetos** (hecho)
- **v0.6 — puzzle de medicamentos** (hecho: cajas arrastrables en primera persona, letras S-O-L, 3 documentos)
- **v0.7 — compañero persistente + conversaciones + audio procedural** (hecho: COMPANION/HAND slot, HABLAR, escena en primera persona, voz y motor de audio)
- Todas las versiones futuras continúan sobre esta base: `StoryState`, `SceneScript`, `Interactable`,
  `PixelCharacterData` y la cadena de renderers (`visualCorruption` irá de crayón a grafito, rasguños y distorsión).

---

## v0.8 — Primera criatura

La primera criatura de MYMom: una **gran rana deforme, triste y con muchas bocas**, con IA jugable completa
(patrulla, oído, vista, investigación, persecución, pérdida del objetivo, captura). Todo se integra con los
sistemas de 0.7 (Scene, Renderer, iluminación, AudioEngine, ruido); no se reescribió nada.

**Código nuevo** (`app/src/main/java/com/terror2d/creature/`): `Noise.kt` (ruido con posición/intensidad/duración/tipo y
oído aproximado), `CreatureBrain.kt` (máquina de estados), `MouthAnimator.kt` (bocas independientes y deterministas),
`CaptureSequence.kt` (captura sin Game Over), `Creature.kt` (animación, ojos, brazos con inercia), `CreatureAudio.kt`.
Dibujo: `pixel/CreatureSprite.kt`, `render/CreatureRenderer.kt`. Datos generados: `pixel/CreatureSpriteData.kt`
(`tools/sprite_gen/creature.py` + `emit_creature.py`; **no editar a mano**).

**Cómo probarla** (condición técnica, no narrativa): al terminar el puzzle de medicinas se activa
`StoryFlags.CREATURE_ACTIVE` y la criatura patrulla el pasillo. En código, `Scene.forceCreature(...)`.
El pasillo tiene un **hueco bajo** (`NarrowGap`, x=410..440) por el que el niño pasa y el cuerpo grande NO cabe.

**Regenerar sprites:** `cd tools/sprite_gen && python3 emit_creature.py` (criatura) y `python3 conversation_art.py` (manos de Ranita).

**Tests nuevos:** `CreatureTest`, `CreatureSceneTest`, `HandsFixTest`. `CompanionAudioTest` se actualizó a 13 capas de arte.

**Estado de verificación:** esta versión se escribió sin poder compilar en el entorno de trabajo. Compila con GitHub Actions
y corrige cualquier error de compilación antes de dar 0.8 por cerrada.
