"""LA CRIATURA de MYMom: gran rana deforme, triste y con muchas bocas.

MISMO LENGUAJE Y DENSIDAD DE PIXEL ART QUE EL NIÑO: píxel = 0,5 px lógicos (igual que el protagonista de 96x128),
contorno de 1 px 2B1A22, sombreado direccional (luz arriba-izquierda) con las mismas utilidades de pixlib.
NO usa la densidad 640x360 de la escena de Ranita en primera persona. Es mucho mayor (cuerpo 160x176) pero
cada píxel mide lo mismo que los del niño.

Capas: BODY (torso+piernas, por pose), ARMS (brazos largos, 6 ángulos; el juego elige por inercia),
HEAD (cabeza asimétrica), EYES (parches), MAIN MOUTH (parches), SECONDARY MOUTHS (parches por tamaño/estado/sangre),
FLUIDS (surcos de lágrimas y saliva; las gotas las anima el juego sobre las rutas).
Todo mira a la DERECHA; el juego espeja.
"""
import math
import numpy as np
from pixlib import Cv

PAL = [
    (0, 0, 0, 0),
    (0x2B, 0x1A, 0x22, 255),   # 1 contorno (el mismo que el niño)
    (0x7E, 0x8C, 0x58, 255),   # 2 piel
    (0xA2, 0xAE, 0x72, 255),   # 3 piel clara
    (0x5C, 0x6A, 0x42, 255),   # 4 sombra
    (0x3E, 0x4A, 0x30, 255),   # 5 sombra profunda
    (0xC8, 0xC0, 0x8A, 255),   # 6 vientre
    (0x9C, 0x94, 0x66, 255),   # 7 sombra vientre
    (0x56, 0x5E, 0x3A, 255),   # 8 mancha
    (0xDC, 0xE6, 0xB4, 255),   # 9 brillo húmedo
    (0xE4, 0xDC, 0xB0, 255),   # 10 esclerótica
    (0x9A, 0x6E, 0x3A, 255),   # 11 iris
    (0x1C, 0x14, 0x24, 255),   # 12 pupila
    (0x6E, 0x78, 0x4C, 255),   # 13 párpado
    (0x48, 0x52, 0x34, 255),   # 14 sombra párpado
    (0x5A, 0x1A, 0x24, 255),   # 15 interior boca
    (0xA8, 0x4A, 0x52, 255),   # 16 lengua
    (0xE8, 0xE0, 0xC0, 255),   # 17 dientes
    (0xB4, 0xAA, 0x86, 255),   # 18 sombra dientes
    (0xA0, 0x1E, 0x28, 255),   # 19 sangre
    (0x6A, 0x12, 0x1C, 255),   # 20 sangre oscura
    (0x8E, 0xC6, 0xD8, 255),   # 21 lágrima
    (0xD6, 0xF0, 0xF4, 255),   # 22 lágrima brillo
    (0xCE, 0xD2, 0xA0, 255),   # 23 saliva
    (0x94, 0x7A, 0x56, 255),   # 24 verruga
    (0xB8, 0xA8, 0x78, 255),   # 25 uña/garra
]
OUT, SK, SKL, SKS, SKD, BEL, BELS, BLO, WET, SCL, IRIS, PUP, LID, LIDS, MIN, TON, TEE, TEES, BLD, BLDD, TEAR, TEARL, SAL, WART, CLAW = range(1, 26)

W, H = 160, 176
AW, AH, ASH = 120, 110, (64, 10)      # lienzo de brazos y ancla del hombro
HW, HH, HC = 84, 76, (42, 40)         # lienzo de cabeza y su centro


def body_part(cv, m, light=True):
    cv.shaded(m, SK, SKL if light else None, SKS, SKD, hb=1, sb=2)


# ------------------------------------------------------------------ cuerpo (torso + piernas)
POSES = {
    #        lean bob  near-foot(x,lift) far-foot(x,lift)  head(dx,dy)  knee
    'IDLE':        dict(lean=0,  bob=0, nf=(4, 0),   ff=(-10, 0),  head=(0, 0),   knee=12),
    'WALK_1':      dict(lean=2,  bob=0, nf=(24, 0),  ff=(-22, 0),  head=(2, 1),   knee=8),
    'WALK_2':      dict(lean=2,  bob=-3, nf=(2, 0),  ff=(-4, 10),  head=(2, -2),  knee=14),
    'WALK_3':      dict(lean=2,  bob=0, nf=(-22, 0), ff=(24, 0),   head=(2, 1),   knee=8),
    'INVESTIGATE': dict(lean=10, bob=2, nf=(8, 0),   ff=(-12, 0),  head=(12, 10), knee=16),
    'ALERT':       dict(lean=-4, bob=-4, nf=(2, 0),  ff=(-12, 0),  head=(-4, -10), knee=8),
    'CHASE_1':     dict(lean=18, bob=2, nf=(40, 0),  ff=(-36, 0),  head=(18, 6),  knee=10),
    'CHASE_2':     dict(lean=18, bob=-6, nf=(-6, 12), ff=(-10, 14), head=(18, 4), knee=20),
    'CAPTURE':     dict(lean=26, bob=4, nf=(26, 0),  ff=(-18, 0),  head=(24, 8),  knee=14),
    'HURT_LIGHT':  dict(lean=-10, bob=2, nf=(0, 0),  ff=(-14, 0),  head=(-8, 8),  knee=14),
}
HIP = (70, 104)


def leg(cv, hip, foot, knee_out, far):
    hx, hy = hip
    fx, fy = foot
    kx = (hx + fx) / 2 + knee_out
    ky = (hy + fy) / 2 - 4
    thigh = cv.capsule((hx, hy), (kx, ky), 10, 7)
    shin = cv.capsule((kx, ky), (fx, fy - 5), 6, 4)
    m = thigh | shin
    foot_m = cv.ellipse(fx + 8, fy, 13, 3) | cv.rect(fx - 2, fy - 4, fx + 4, fy)
    m |= foot_m
    cv.shaded(m, SKS if far else SK, SK if far else SKL, SKD if far else SKS, SKD, hb=1, sb=2)
    # dedos palmeados
    for i in range(3):
        cv.put(fx + 12 + i * 3, fy + 1, OUT)
    return m


def build_body(name):
    p = POSES[name]
    cv = Cv(W, H)
    lean, bob = p['lean'], p['bob']
    base_y = 175
    hip = (HIP[0] + lean // 2, HIP[1] + bob)
    far = (hip[0] - 6, hip[1] + 2)
    near = (hip[0] + 6, hip[1] + 2)
    ff = (far[0] + p['ff'][0], base_y - p['ff'][1])
    nf = (near[0] + p['nf'][0], base_y - p['nf'][1])
    leg(cv, far, ff, p['knee'] * 0.5, True)
    # torso encorvado (cuelga hacia delante)
    tx, ty = 64 + lean, 84 + bob
    torso = cv.ellipse(tx, ty, 31, 28) | cv.ellipse(tx + 8, ty + 6, 26, 26) | cv.ellipse(tx - 16, ty - 12, 18, 16)  # joroba
    cv.shaded(torso, SK, SKL, SKS, SKD, hb=2, sb=3)
    belly = cv.ellipse(tx + 16, ty + 10, 17, 19) & torso
    cv.shaded(belly, BEL, WET, BELS, None, hb=1, sb=2)
    for (dx, dy) in ((-18, -14), (-6, -22), (-26, 0), (6, -8)):   # manchas y verrugas
        blob = cv.ellipse(tx + dx, ty + dy, 4, 3) & torso
        cv.a[blob] = BLO
    for (dx, dy) in ((-10, -4), (-22, 10), (12, -16), (-2, 14)):
        cv.put(tx + dx, ty + dy, WART)
        cv.put(tx + dx + 1, ty + dy, WART)
    leg(cv, near, nf, p['knee'], False)
    cv.outline(OUT)
    info = dict(head=(tx + 28 + p['head'][0] - HC[0] + 0, ty - 34 + p['head'][1] - HC[1] + 10),
                torso=(tx, ty), shoulder=(tx - 6, ty - 12))
    return cv, info


# ------------------------------------------------------------------ brazos largos
ARM_ANGLES = [-30, 4, 18, 32, 48, -62]     # grados hacia atrás (+) / adelante (-); el último = captura
def build_arm(idx, far=False):
    a = math.radians(ARM_ANGLES[idx])
    cv = Cv(AW, AH)
    sx, sy = ASH
    ex, ey = sx - 34 * math.sin(a), sy + 34 * math.cos(a)
    a2 = a + math.radians(14 if idx != 5 else -10)
    hx, hy = ex - 36 * math.sin(a2), ey + 36 * math.cos(a2)
    up = cv.capsule((sx, sy), (ex, ey), 8, 6)
    lo = cv.capsule((ex, ey), (hx, hy), 6, 4)
    m = up | lo
    cv.shaded(m, SKS if far else SK, SK if far else SKL, SKD if far else SKS, SKD, hb=1, sb=2)
    # mano larga: tres dedos finos con garra
    fm = cv.blank()
    for k, da in enumerate((-18, 0, 18)):
        ang = a2 + math.radians(da)
        fx, fy = hx - 17 * math.sin(ang), hy + 17 * math.cos(ang)
        fm |= cv.capsule((hx, hy), (fx, fy), 2.2, 1.2)
        cv.put(int(round(fx)), int(round(fy)), CLAW)
    cv.shaded(fm, SKS if far else SK, None, SKD, None)
    cv.outline(OUT)
    for k, da in enumerate((-18, 0, 18)):
        ang = a2 + math.radians(da)
        cv.put(int(round(hx - 17 * math.sin(ang))), int(round(hy + 17 * math.cos(ang))), CLAW)
    return cv


# ------------------------------------------------------------------ cabeza (asimétrica, frontal)
def build_head():
    cv = Cv(HW, HH)
    cx, cy = HC
    head = cv.ellipse(cx - 2, cy, 38, 31) | cv.ellipse(cx + 8, cy + 6, 33, 30) | cv.ellipse(cx - 24, cy - 4, 14, 20)  # lado izq. más blando
    head |= cv.ellipse(cx + 20, cy - 24, 14, 10)    # abultamiento superior derecho
    head &= ~cv.ellipse(cx + 34, cy - 12, 5, 6)     # pequeña hendidura
    cv.shaded(head, SK, SKL, SKS, SKD, hb=2, sb=3)
    cv.a[cv.ellipse(cx, cy + 20, 26, 9) & head] = BEL        # papada pálida
    for (dx, dy) in ((-14, -10), (4, -20), (24, 8), (-28, 10), (10, 14)):
        cv.a[cv.ellipse(cx + dx, cy + dy, 3, 2) & head] = BLO
    for (dx, dy) in ((-6, -12), (16, -4), (-24, 0), (30, 0)):
        cv.put(cx + dx, cy + dy, WART)
    cv.outline(OUT)
    return cv


EYE_L = (28, 17)    # centros de ojo en coordenadas de cabeza (el derecho es algo más pequeño y más alto)
EYE_R = (57, 14)
EYE_STATES = ['OPEN', 'HALF', 'CLOSED', 'LOOK_DOWN', 'WIDE']


def eye_patch(r, state, side):
    """Ojo grande y triste: párpado superior pesado y comisura caída. Parche r*2+1 de lado."""
    d = r * 2 + 3
    cv = Cv(d, d)
    c = d // 2
    eye = cv.ellipse(c, c, r, r)
    droop = {'OPEN': 0.38, 'HALF': 0.62, 'CLOSED': 1.1, 'LOOK_DOWN': 0.5, 'WIDE': 0.22}[state]
    cv.shaded(cv.ellipse(c, c, r + 1, r + 1), LID, SKL, LIDS, None)
    if state != 'CLOSED':
        cv.a[eye] = SCL
        ix = c + (1 if side == 'L' else -1) + (0 if state != 'LOOK_DOWN' else 0)
        iy = c + (4 if state == 'LOOK_DOWN' else 2)
        ir = max(3, r // 2 + 1)
        cv.a[cv.ellipse(ix, iy, ir, ir) & eye] = IRIS
        cv.a[cv.ellipse(ix, iy + 1, ir - 2, ir - 2) & eye] = PUP
        cv.put(ix - 1, iy - 1, WET)
        cv.put(c + 2, c + r - 2, TEARL)                         # humedad en el borde inferior
        cv.a[cv.rect(0, c + r - 1, d, c + r) & eye] = TEAR      # línea de lágrima acumulada
    # párpado pesado: tapa la parte superior según droop
    lid_m = cv.ellipse(c, c, r + 1, r + 1) & (np.mgrid[0:d, 0:d][0] <= c - r + int(droop * 2 * r))
    cv.a[lid_m] = LID
    cv.a[lid_m & ~cv.shift(lid_m, 0, -1)] = LIDS                # borde del párpado
    # comisura caída hacia fuera
    ys = c - r + int(droop * 2 * r)
    cv.put(c + (r if side == 'L' else -r) * 0, ys + 1, LIDS)
    cv.outline(OUT)
    return cv


MOUTH_Y = 51
def main_mouth(state):
    """Boca principal enorme: sonrisa grotesca con 3 filas de dientes irregulares. Parche 70x26."""
    w, h = 70, 26
    cv = Cv(w, h)
    open_h = {'CLOSED': 3, 'TENSE': 5, 'OPEN': 12, 'WIDE': 18}[state]
    cx = w // 2
    for x in range(2, w - 2):
        t = (x - cx) / (cx - 2)
        curve = int(round(7 * t * t))                  # comisuras hacia arriba: sonrisa
        top = 6 - curve + (1 if x % 7 == 0 else 0)
        bot = top + open_h + (2 if x % 11 == 3 else 0)
        for y in range(top, min(h - 1, bot + 1)):
            cv.put(x, y, MIN)
        # dientes superiores, irregulares
        n = 2 + (x * 7 % 3)
        for k in range(n):
            if (x + k) % 5 != 0 or k == 0:
                cv.put(x, top + k, TEE if (x + k) % 3 else TEES)
        # fila inferior y segunda fila interior
        m = 1 + (x * 5 % 3)
        for k in range(m):
            if bot - k > top + n:
                cv.put(x, bot - k, TEE if (x * 3 + k) % 4 else TEES)
        if open_h >= 12 and x % 4 == 1:
            cv.put(x, top + n + 1, TEES)                   # segunda fila
        if open_h >= 12 and 14 < x < w - 14:
            cv.put(x, bot - 3, TON)
    if open_h >= 12:
        cv.a[cv.ellipse(cx, 6 + open_h - 2, 18, 3) & (cv.a == MIN)] = TON
    cv.outline(OUT)
    return cv


# bocas secundarias: tamaños S/M/L, estado 0 cerrada, 1 entreabierta, 2 abierta, con o sin sangre
SIZES = {'S': (9, 7), 'M': (13, 9), 'L': (19, 12)}
def sec_mouth(size, state, bloody):
    w, h = SIZES[size]
    cv = Cv(w, h)
    cx, cy = w // 2, h // 2
    oh = [0, 2, h // 2 + 1][state]
    for x in range(1, w - 1):
        t = (x - cx) / max(1, cx)
        y0 = cy - int(round(oh / 2)) + int(round(1.5 * t * t))
        for y in range(y0, y0 + oh + 1):
            cv.put(x, y, MIN)
        cv.put(x, y0, OUT if state == 0 else MIN)
        if state >= 1:
            if x % 2 == 1:
                cv.put(x, y0 + 1, TEE)
            if state == 2 and x % 3 == 0:
                cv.put(x, y0 + oh, TEE if x % 2 else TEES)
    if state == 2 and w >= 13:
        cv.a[cv.rect(cx - 2, cy, cx + 2, cy + 1) & (cv.a == MIN)] = TON
    cv.outline(OUT)
    if bloody:
        for x in range(2, w - 2, 3):
            cv.put(x, h - 1 if state == 0 else cy + oh // 2 + 2, BLD)
        cv.put(cx, h - 1, BLDD)
    return cv


# Posiciones de las bocas: 3 en la cabeza (coordenadas de cabeza) y 6 en el torso (relativas al centro del torso).
HEAD_MOUTHS = [('S', 20, 38, False), ('M', 66, 36, True), ('S', 44, 24, False)]
TORSO_MOUTHS = [('M', -18, -8, True), ('S', 8, -22, False), ('L', 4, 8, True), ('S', -26, 14, False),
                ('M', 18, 14, False), ('S', -6, -26, False)]
MAIN_MOUTH_POS = (HC[0] - 35, MOUTH_Y)   # esquina sup. izquierda del parche, en coords de cabeza

# Rutas de lágrima: ojo -> junto a una boca secundaria -> boca principal / otras bocas
TEAR_PATHS = [
    [(26, 28), (24, 33), (21, 37), (20, 41), (17, 46), (15, 51), (14, 54)],           # izq: pasa por la boca (20,38) -> comisura
    [(58, 25), (60, 30), (63, 34), (66, 38), (66, 42), (64, 47), (62, 52), (59, 55)],  # der: entra en la boca (66,36) -> boca principal
]


def fluids_layer():
    cv = Cv(HW, HH)
    for path in TEAR_PATHS:
        for (x0, y0), (x1, y1) in zip(path, path[1:]):
            cv.line(x0, y0, x1, y1, TEAR)
        for x, y in path[::2]:
            cv.put(x, y, TEARL)
    # hilos de saliva y goteo desde la boca principal
    for x, ln in ((22, 6), (36, 9), (50, 5), (60, 7)):
        for k in range(ln):
            cv.put(x, 63 + k, SAL if k % 3 else WET)
        cv.put(x, 63 + ln, SAL)
    return cv


# ------------------------------------------------------------------ vista previa y comprobación
def to_rgba(cv):
    arr = np.zeros((cv.h, cv.w, 4), dtype=np.uint8)
    for i, c in enumerate(PAL):
        arr[cv.a == i] = c
    return arr


def compose(name='IDLE', arm_idx=2, eye='OPEN', mouth='CLOSED', open_mask=(1, 0, 2, 0, 1, 2, 0, 0, 1), scale=3):
    from PIL import Image
    body, info = build_body(name)
    img = Image.new('RGBA', (W + 60, H), (236, 226, 200, 255))
    def paste(cv, x, y):
        im = Image.fromarray(to_rgba(cv), 'RGBA')
        img.alpha_composite(im, (x + 30, y)) if x + 30 >= 0 and y >= 0 else None
    sh = info['shoulder']
    paste(build_arm(arm_idx, True), sh[0] - ASH[0] - 6, sh[1] - ASH[1])
    paste(body, 0, 0)
    hx, hy = info['head']
    hd = build_head()
    paste(hd, hx, hy)
    for (cx, cy), side, r in ((EYE_L, 'L', 11), (EYE_R, 'R', 10)):
        e = eye_patch(r, eye, side)
        paste(e, hx + cx - e.w // 2, hy + cy - e.h // 2)
    mm = main_mouth(mouth)
    paste(mm, hx + MAIN_MOUTH_POS[0], hy + MAIN_MOUTH_POS[1] - 6)
    for i, (sz, mx, my, bl) in enumerate(HEAD_MOUTHS):
        m = sec_mouth(sz, open_mask[i], bl)
        paste(m, hx + mx - m.w // 2, hy + my - m.h // 2)
    tx, ty = info['torso']
    for j, (sz, mx, my, bl) in enumerate(TORSO_MOUTHS):
        m = sec_mouth(sz, open_mask[3 + j], bl)
        paste(m, tx + mx - m.w // 2, ty + my - m.h // 2)
    paste(fluids_layer(), hx, hy)
    paste(build_arm(arm_idx, False), sh[0] - ASH[0], sh[1] - ASH[1])
    return img.resize((img.width * scale, img.height * scale), Image.NEAREST)


if __name__ == '__main__':
    import sys
    from PIL import Image
    names = ['IDLE', 'WALK_1', 'CHASE_1', 'CAPTURE']
    ims = [compose(n, arm_idx=(5 if n == 'CAPTURE' else (4 if n.startswith('CHASE') else 2)),
                   mouth=('WIDE' if n.startswith('CHASE') else 'CLOSED'), scale=2) for n in names]
    sheet = Image.new('RGBA', (sum(i.width for i in ims), ims[0].height))
    x = 0
    for i in ims:
        sheet.paste(i, (x, 0)); x += i.width
    sheet.save('/home/claude/creature_preview.png')
    print('ok', sheet.size)
