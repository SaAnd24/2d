"""LA CRIATURA de MYMom: gran rana deforme, triste y con muchas bocas.

MISMO LENGUAJE Y DENSIDAD DE PIXEL ART QUE EL NIÑO: píxel = 0,5 px lógicos (igual que el protagonista de 96x128),
contorno de 1 px 2B1A22, sombreado direccional (luz arriba-izquierda) con las mismas utilidades de pixlib.
NO usa la densidad 640x360 de la escena de Ranita en primera persona. Es mucho mayor (cuerpo 160x176) pero
cada píxel mide lo mismo que los del niño.

Capas: BODY (torso+piernas, por pose), ARMS (brazos largos, 6 ángulos; el juego elige por inercia),
HEAD (cabeza asimétrica), EYES (parches), MAIN MOUTH (parches), SECONDARY MOUTHS (parches por tamaño/estado/sangre),
FLUIDS (surcos de lágrimas y saliva; las gotas las anima el juego sobre las rutas).
Todo mira a la DERECHA; el juego espeja.
"""
import math
import numpy as np
from pixlib import Cv

PAL = [
    (0, 0, 0, 0),
    (0x2B, 0x1A, 0x22, 255),   # 1 contorno (el mismo que el niño)
    (0x7E, 0x8C, 0x58, 255),   # 2 piel
    (0xA2, 0xAE, 0x72, 255),   # 3 piel clara
    (0x5C, 0x6A, 0x42, 255),   # 4 sombra
    (0x3E, 0x4A, 0x30, 255),   # 5 sombra profunda
    (0xC8, 0xC0, 0x8A, 255),   # 6 vientre
    (0x9C, 0x94, 0x66, 255),   # 7 sombra vientre
    (0x56, 0x5E, 0x3A, 255),   # 8 mancha
    (0xDC, 0xE6, 0xB4, 255),   # 9 brillo húmedo
    (0xE4, 0xDC, 0xB0, 255),   # 10 esclerótica
    (0x9A, 0x6E, 0x3A, 255),   # 11 iris
    (0x1C, 0x14, 0x24, 255),   # 12 pupila
    (0x6E, 0x78, 0x4C, 255),   # 13 párpado
    (0x48, 0x52, 0x34, 255),   # 14 sombra párpado
    (0x5A, 0x1A, 0x24, 255),   # 15 interior boca
    (0xA8, 0x4A, 0x52, 255),   # 16 lengua
    (0xE8, 0xE0, 0xC0, 255),   # 17 dientes
    (0xB4, 0xAA, 0x86, 255),   # 18 sombra dientes
    (0xA0, 0x1E, 0x28, 255),   # 19 sangre
    (0x6A, 0x12, 0x1C, 255),   # 20 sangre oscura
    (0x8E, 0xC6, 0xD8, 255),   # 21 lágrima
    (0xD6, 0xF0, 0xF4, 255),   # 22 lágrima brillo
    (0xCE, 0xD2, 0xA0, 255),   # 23 saliva
    (0x94, 0x7A, 0x56, 255),   # 24 verruga
    (0xB8, 0xA8, 0x78, 255),   # 25 uña/garra
    (0xD2, 0xC6, 0x60, 255),   # 26 pus
    (0x6C, 0x4C, 0x70, 255),   # 27 moratón
    (0x8A, 0x3C, 0x58, 255),   # 28 vena
    (0xB0, 0x48, 0x58, 255),   # 29 carne viva
    (0xB8, 0xA0, 0x74, 255),   # 30 verruga clara
    (0xB4, 0xD0, 0x96, 255),   # 31 moco
    (0xDC, 0xD2, 0xA0, 255),   # 32 piel pálida enferma
]
OUT, SK, SKL, SKS, SKD, BEL, BELS, BLO, WET, SCL, IRIS, PUP, LID, LIDS, MIN, TON, TEE, TEES, BLD, BLDD, TEAR, TEARL, SAL, WART, CLAW, PUS, BRU, VEIN, RAW, WARTL, MUCUS, PALE = range(1, 33)

W, H = 160, 176
AW, AH, ASH = 120, 110, (64, 10)      # lienzo de brazos y ancla del hombro
HW, HH, HC = 108, 106, (54, 52)       # lienzo de cabeza (MUY grande) y su centro
MM_W, MM_H = 88, 32                    # parche de la boca principal


def body_part(cv, m, light=True):
    cv.shaded(m, SK, SKL if light else None, SKS, SKD, hb=1, sb=2)


# ------------------------------------------------------------------ repugnancia: tumores, pus, llagas, venas, moco
def _rs(seed):
    return np.random.RandomState(seed)


def _inside(cv, m, pts):
    return [(x, y) for x, y in pts if 0 <= x < cv.w and 0 <= y < cv.h and m[y, x]]


def mottle(cv, m, seed, n=9):
    """Piel enferma: manchas oscuras, moratones y zonas pálidas amarillentas."""
    rs = _rs(seed)
    ys, xs = np.nonzero(m)
    if len(xs) == 0:
        return
    for k in range(n):
        i = rs.randint(len(xs))
        c = (BLO, BRU, PALE, BLO)[k % 4]
        blob = cv.ellipse(xs[i], ys[i], rs.randint(2, 6), rs.randint(2, 5)) & m & (cv.a != OUT)
        cv.a[blob & (cv.a == SK)] = c


def warts(cv, m, seed, n=10, big=2):
    """Verrugas con brillo húmedo y sombra; algunas son tumores grandes con poro oscuro."""
    rs = _rs(seed)
    ys, xs = np.nonzero(m)
    if len(xs) == 0:
        return
    for k in range(n):
        i = rs.randint(len(xs))
        x, y = int(xs[i]), int(ys[i])
        r = 3 if k < big else 1
        bump = cv.ellipse(x, y, r, r) & m
        cv.a[bump] = WART
        cv.put(x - r + 1, y - r + 1, WARTL)
        cv.put(x + r, y + r, SKD)
        if r == 3:
            cv.put(x + 1, y + 1, SKD)
            cv.put(x, y, BLO)


def pustules(cv, m, seed, n=5):
    """Pústulas de pus; alguna reventada con sangre."""
    rs = _rs(seed)
    ys, xs = np.nonzero(m)
    if len(xs) == 0:
        return
    for k in range(n):
        i = rs.randint(len(xs))
        x, y = int(xs[i]), int(ys[i])
        r = 2
        cv.a[cv.ellipse(x, y, r, r) & m] = PUS
        cv.put(x - 1, y - 1, WET)
        if k % 3 == 0:
            cv.put(x, y, BLD)
            cv.put(x, y + 1, BLD)
            cv.put(x, y + 2, BLDD)          # gotea
        cv.put(x + 2, y + 1, SKD)


def sores(cv, m, seed, n=2):
    """Llagas abiertas: carne viva con borde de pus y centro oscuro."""
    rs = _rs(seed)
    ys, xs = np.nonzero(m)
    if len(xs) == 0:
        return
    for k in range(n):
        i = rs.randint(len(xs))
        x, y = int(xs[i]), int(ys[i])
        rx, ry = rs.randint(3, 6), rs.randint(2, 4)
        o = cv.ellipse(x, y, rx + 1, ry + 1) & m
        cv.a[o] = PUS
        cv.a[cv.ellipse(x, y, rx, ry) & m] = RAW
        cv.a[cv.ellipse(x + 1, y, max(1, rx - 2), max(1, ry - 1)) & m] = BLD
        cv.put(x, y, BLDD)
        cv.put(x - 1, y - 1, WET)
        for d in range(rs.randint(2, 5)):
            cv.put(x + rx - 1, y + ry + d, BLD if d < 2 else BLDD)


def veins(cv, m, seed, n=5, length=14):
    """Venas moradas que serpentean por la piel."""
    rs = _rs(seed)
    ys, xs = np.nonzero(m)
    if len(xs) == 0:
        return
    for _ in range(n):
        i = rs.randint(len(xs))
        x, y = float(xs[i]), float(ys[i])
        ang = rs.uniform(0, 6.28)
        for _s in range(length):
            ang += rs.uniform(-0.7, 0.7)
            x += np.cos(ang)
            y += np.sin(ang)
            xi, yi = int(round(x)), int(round(y))
            if 0 <= xi < cv.w and 0 <= yi < cv.h and m[yi, xi] and cv.a[yi, xi] in (SK, SKL, SKS, BEL, BELS, PALE, BLO):
                cv.a[yi, xi] = VEIN


def drips(cv, m, seed, n=4, maxlen=9):
    """Hilos de moco/saliva que cuelgan del borde inferior de la piel."""
    rs = _rs(seed)
    low = m & ~cv.shift(m, 0, -1)
    ys, xs = np.nonzero(low)
    if len(xs) == 0:
        return
    for _ in range(n):
        i = rs.randint(len(xs))
        x, y = int(xs[i]), int(ys[i])
        ln = rs.randint(3, maxlen)
        for d in range(1, ln):
            cv.put(x, y + d, MUCUS if d % 3 else WET)
        cv.put(x, y + ln, MUCUS)
        cv.put(x, y + ln + 1, WET)


def grotesque(cv, m, seed, wartn=10, pust=4, sor=2, vein=4):
    mottle(cv, m, seed + 1)
    veins(cv, m, seed + 2, vein)
    warts(cv, m, seed + 3, wartn)
    pustules(cv, m, seed + 4, pust)
    sores(cv, m, seed + 5, sor)


# ------------------------------------------------------------------ cuerpo (torso + piernas)
POSES = {
    #        lean bob  near-foot(x,lift) far-foot(x,lift)  head(dx,dy)  knee
    'IDLE':        dict(lean=0,  bob=0, nf=(4, 0),   ff=(-10, 0),  head=(0, 0),   knee=12),
    'WALK_1':      dict(lean=2,  bob=0, nf=(24, 0),  ff=(-22, 0),  head=(2, 1),   knee=8),
    'WALK_2':      dict(lean=2,  bob=-3, nf=(2, 0),  ff=(-4, 10),  head=(2, -2),  knee=14),
    'WALK_3':      dict(lean=2,  bob=0, nf=(-22, 0), ff=(24, 0),   head=(2, 1),   knee=8),
    'INVESTIGATE': dict(lean=10, bob=2, nf=(8, 0),   ff=(-12, 0),  head=(12, 10), knee=16),
    'ALERT':       dict(lean=-4, bob=-4, nf=(2, 0),  ff=(-12, 0),  head=(-4, -10), knee=8),
    'CHASE_1':     dict(lean=18, bob=2, nf=(40, 0),  ff=(-36, 0),  head=(18, 6),  knee=10),
    'CHASE_2':     dict(lean=18, bob=-6, nf=(-6, 12), ff=(-10, 14), head=(18, 4), knee=20),
    'CAPTURE':     dict(lean=26, bob=4, nf=(26, 0),  ff=(-18, 0),  head=(24, 8),  knee=14),
    'HURT_LIGHT':  dict(lean=-10, bob=2, nf=(0, 0),  ff=(-14, 0),  head=(-8, 8),  knee=14),
}
HIP = (70, 104)


def leg(cv, hip, foot, knee_out, far, seed):
    hx, hy = hip
    fx, fy = foot
    kx = (hx + fx) / 2 + knee_out
    ky = (hy + fy) / 2 - 4
    thigh = cv.capsule((hx, hy), (kx, ky), 11, 7)
    shin = cv.capsule((kx, ky), (fx, fy - 5), 6, 4)
    m = thigh | shin
    foot_m = cv.ellipse(fx + 8, fy, 14, 3) | cv.rect(fx - 2, fy - 4, fx + 4, fy)
    m |= foot_m
    cv.shaded(m, SKS if far else SK, SK if far else SKL, SKD if far else SKS, SKD, hb=1, sb=2)
    grotesque(cv, m, seed, wartn=7, pust=2, sor=1, vein=3)
    for i in range(3):                        # dedos palmeados
        cv.put(fx + 12 + i * 3, fy + 1, OUT)
        cv.put(fx + 12 + i * 3, fy, SKD)
    return m


def build_body(name):
    p = POSES[name]
    cv = Cv(W, H)
    lean, bob = p['lean'], p['bob']
    base_y = 175
    hip = (HIP[0] + lean // 2, HIP[1] + bob)
    far = (hip[0] - 6, hip[1] + 2)
    near = (hip[0] + 6, hip[1] + 2)
    ff = (far[0] + p['ff'][0], base_y - p['ff'][1])
    nf = (near[0] + p['nf'][0], base_y - p['nf'][1])
    leg(cv, far, ff, p['knee'] * 0.5, True, 11)
    # torso encorvado, hinchado y desigual (joroba, michelines que cuelgan)
    tx, ty = 64 + lean, 84 + bob
    torso = (cv.ellipse(tx, ty, 32, 29) | cv.ellipse(tx + 8, ty + 6, 28, 28) | cv.ellipse(tx - 16, ty - 12, 20, 18)
             | cv.ellipse(tx + 20, ty + 26, 16, 12) | cv.ellipse(tx - 24, ty + 18, 12, 14))      # panza caída + bulto lateral
    cv.shaded(torso, SK, SKL, SKS, SKD, hb=2, sb=3)
    belly = (cv.ellipse(tx + 16, ty + 12, 18, 21) | cv.ellipse(tx + 20, ty + 26, 14, 10)) & torso
    cv.shaded(belly, BEL, WET, BELS, None, hb=1, sb=2)
    for k in range(4):                      # pliegues de grasa de la barriga
        yy = ty + 2 + k * 7
        for xx in range(tx + 2, tx + 34):
            if belly[yy, xx] if 0 <= yy < cv.h and 0 <= xx < cv.w else False:
                cv.put(xx, yy + int(1.5 * np.sin((xx - tx) / 4.0)), BELS if k % 2 else SKD)
    grotesque(cv, torso, 21, wartn=16, pust=7, sor=3, vein=6)
    leg(cv, near, nf, p['knee'], False, 12)
    cv.outline(OUT)
    info = dict(head=(tx + 28 + p['head'][0] - HC[0] + 0, ty - 34 + p['head'][1] - HC[1] + 10),
                torso=(tx, ty), shoulder=(tx - 6, ty - 12))
    return cv, info


# ------------------------------------------------------------------ brazos largos
ARM_ANGLES = [-30, 4, 18, 32, 48, -62]     # grados hacia atrás (+) / adelante (-); el último = captura
def build_arm(idx, far=False):
    a = math.radians(ARM_ANGLES[idx])
    cv = Cv(AW, AH)
    sx, sy = ASH
    ex, ey = sx - 34 * math.sin(a), sy + 34 * math.cos(a)
    a2 = a + math.radians(14 if idx != 5 else -10)
    hx, hy = ex - 36 * math.sin(a2), ey + 36 * math.cos(a2)
    up = cv.capsule((sx, sy), (ex, ey), 9, 6)
    lo = cv.capsule((ex, ey), (hx, hy), 6, 4)
    m = up | lo | cv.ellipse(ex, ey, 8, 8)                    # codo hinchado
    cv.shaded(m, SKS if far else SK, SK if far else SKL, SKD if far else SKS, SKD, hb=1, sb=2)
    fm = cv.blank()
    for k, da in enumerate((-20, 0, 20)):                       # dedos larguísimos y finos
        ang = a2 + math.radians(da)
        fx, fy = hx - 20 * math.sin(ang), hy + 20 * math.cos(ang)
        fm |= cv.capsule((hx, hy), (fx, fy), 2.2, 1.0)
    cv.shaded(fm, SKS if far else SK, None, SKD, None)
    grotesque(cv, m, 31 + idx + (7 if far else 0), wartn=8, pust=3, sor=2, vein=4)
    cv.outline(OUT)
    for k, da in enumerate((-20, 0, 20)):
        ang = a2 + math.radians(da)
        cv.put(int(round(hx - 20 * math.sin(ang))), int(round(hy + 20 * math.cos(ang))), CLAW)
    return cv


# ------------------------------------------------------------------ cabeza (enorme, asimétrica, enferma)
EYE_L = (34, 26)    # ojo izquierdo (más grande y más bajo)
EYE_R = (76, 19)    # ojo derecho (más pequeño, más alto)
EYE_RL, EYE_RR = 13, 10


def build_head():
    cv = Cv(HW, HH)
    cx, cy = HC
    head = (cv.ellipse(cx - 2, cy + 2, 48, 36) | cv.ellipse(cx + 8, cy + 10, 42, 36) | cv.ellipse(cx - 30, cy + 2, 18, 28)   # lado izq. blando
            | cv.ellipse(cx + 28, cy - 26, 16, 12)                                                                      # bulto superior derecho
            | cv.ellipse(cx + 38, cy + 20, 14, 20)                                                                       # saco/papada colgante derecha
            | cv.ellipse(cx - 34, cy + 24, 10, 12))                                                                      # bolsa izquierda
    head |= cv.ellipse(EYE_L[0], EYE_L[1], EYE_RL + 3, EYE_RL + 3) | cv.ellipse(EYE_R[0], EYE_R[1], EYE_RR + 3, EYE_RR + 3)  # ojos saltones
    head &= ~cv.ellipse(cx + 44, cy - 14, 5, 7)                      # mordisco/hendidura
    # papadas: tres colgajos de piel bajo la mandíbula
    for (x0, y0, x1, y1, r) in ((cx - 22, cy + 32, cx - 26, cy + 50, 6), (cx + 2, cy + 36, cx + 4, cy + 52, 7), (cx + 26, cy + 34, cx + 32, cy + 48, 5)):
        head |= cv.capsule((x0, y0), (x1, y1), r, 3)
    cv.shaded(head, SK, SKL, SKS, SKD, hb=2, sb=3)
    cv.a[cv.ellipse(cx, cy + 28, 30, 11) & head] = BEL           # papada pálida
    cv.a[(cv.capsule((cx + 2, cy + 36), (cx + 4, cy + 52), 5, 2)) & head] = BEL
    grotesque(cv, head, 41, wartn=22, pust=7, sor=3, vein=7)
    drips(cv, head, 47, n=5, maxlen=11)
    cv.outline(OUT)
    return cv


EYE_STATES = ['OPEN', 'HALF', 'CLOSED', 'LOOK_DOWN', 'WIDE']


def eye_patch(r, state, side):
    """Ojo enorme, triste, inyectado en sangre, con párpados hinchados y pus en la comisura."""
    d = r * 2 + 5
    cv = Cv(d, d)
    c = d // 2
    eye = cv.ellipse(c, c, r, r)
    droop = {'OPEN': 0.42, 'HALF': 0.66, 'CLOSED': 1.1, 'LOOK_DOWN': 0.55, 'WIDE': 0.26}[state]
    cv.shaded(cv.ellipse(c, c, r + 2, r + 2), LID, SKL, LIDS, None)
    cv.a[(cv.ellipse(c, c, r + 2, r + 2) & ~cv.ellipse(c, c, r + 1, r + 1))] = VEIN       # párpados enrojecidos
    if state != 'CLOSED':
        cv.a[eye] = SCL
        for k in range(7):                                                                   # venas rotas en el ojo
            ang = k * 0.9 + (0.4 if side == 'L' else 1.2)
            for t in range(2, r - 1):
                x = int(round(c + math.cos(ang) * t + 0.4 * math.sin(t)))
                y = int(round(c + math.sin(ang) * t))
                if (x - c) ** 2 + (y - c) ** 2 <= (r - 1) ** 2 and (t > r // 2 or k % 2):
                    cv.put(x, y, VEIN)
        ix = c + (1 if side == 'L' else -1)
        iy = c + (5 if state == 'LOOK_DOWN' else 3)
        ir = max(3, r // 2 + 1)
        cv.a[cv.ellipse(ix, iy, ir, ir) & eye] = IRIS
        cv.a[cv.ellipse(ix, iy + 1, ir - 2, ir - 2) & eye] = PUP
        cv.put(ix - 1, iy - 1, WET)
        cv.a[cv.rect(0, c + r - 1, d, c + r) & eye] = TEAR                                   # lágrima acumulada
        cv.put(c + 2, c + r - 2, TEARL)
        cv.put(c - r + 2, c + 1, PUS)                                                         # legaña/pus en el lagrimal
        cv.put(c - r + 2, c + 2, PUS)
    lid_m = cv.ellipse(c, c, r + 2, r + 2) & (np.mgrid[0:d, 0:d][0] <= c - r + int(droop * 2 * r))
    cv.a[lid_m] = LID
    cv.a[lid_m & ~cv.shift(lid_m, 0, -1)] = VEIN                                              # borde del párpado enrojecido
    for k in range(3):                                                                        # pliegues del párpado hinchado
        yy = c - r + int(droop * 2 * r) - 2 - k * 2
        for xx in range(c - r + 3, c + r - 2):
            if 0 <= yy < d and lid_m[yy, xx] and (xx + k) % 3:
                cv.put(xx, yy, LIDS)
    cv.outline(OUT)
    return cv


MOUTH_Y = 60
MAIN_MOUTH_POS = (HC[0] - MM_W // 2, MOUTH_Y)   # esquina sup. izquierda del parche, en coords de cabeza


def main_mouth(state):
    """Boca principal enorme: sonrisa grotesca con 3-4 filas de dientes torcidos, encías de carne viva, colmillos."""
    w, h = MM_W, MM_H
    cv = Cv(w, h)
    open_h = {'CLOSED': 4, 'TENSE': 6, 'OPEN': 14, 'WIDE': 21}[state]
    cx = w // 2
    for x in range(2, w - 2):
        t = (x - cx) / (cx - 2)
        curve = int(round(8 * t * t))
        top = 7 - curve + (1 if x % 7 == 0 else 0) + (1 if x % 13 == 4 else 0)
        bot = top + open_h + (2 if x % 11 == 3 else 0) - (1 if x % 9 == 5 else 0)
        for y in range(max(0, top), min(h - 1, bot + 1)):
            cv.put(x, y, MIN)
        cv.put(x, top - 1, RAW)                                     # labio hinchado de carne viva
        cv.put(x, min(h - 1, bot + 1), RAW)
        n = 2 + (x * 7 % 4)                                         # dientes de longitud muy irregular
        for k in range(n):
            if (x + k) % 5 != 0 or k == 0:
                cv.put(x, top + k, TEE if (x + k) % 3 else TEES)
        if x % 6 == 2:                                              # dientes que sobresalen fuera del labio
            cv.put(x, top - 2, TEE)
            cv.put(x, top - 3, TEES)
        cv.put(x, top, PUS if x % 17 == 4 else cv.a[min(h - 1, max(0, top)), x])   # encía infectada
        m = 1 + (x * 5 % 4)
        for k in range(m):
            if bot - k > top + n:
                cv.put(x, bot - k, TEE if (x * 3 + k) % 4 else TEES)
        if open_h >= 14 and x % 4 == 1:
            cv.put(x, top + n + 1, TEES)                            # segunda fila
        if open_h >= 14 and x % 5 == 3:
            cv.put(x, top + n + 3, TEE)                             # tercera fila
        if open_h >= 14 and 14 < x < w - 14:
            cv.put(x, bot - 3, TON)
        if x % 19 == 7 and open_h >= 6:                             # colmillos grandes
            for k in range(6):
                cv.put(x, top + k, TEE)
            cv.put(x, top + 6, TEES)
    if open_h >= 14:
        cv.a[cv.ellipse(cx, 7 + open_h - 2, 20, 4) & (cv.a == MIN)] = TON
        for x in range(10, w - 10, 6):
            cv.put(x, 9 + open_h // 2, MUCUS)                       # hilos de baba entre las filas
    cv.outline(OUT)
    return cv


# bocas secundarias (más grandes y más enfermas): tamaños S/M/L, estado 0 cerrada, 1 entreabierta, 2 abierta, con o sin sangre
SIZES = {'S': (11, 8), 'M': (15, 10), 'L': (22, 14)}
def sec_mouth(size, state, bloody):
    w, h = SIZES[size]
    cv = Cv(w, h)
    cx, cy = w // 2, h // 2
    oh = [0, 3, h // 2 + 2][state]
    for x in range(1, w - 1):
        t = (x - cx) / max(1, cx)
        y0 = cy - int(round(oh / 2)) + int(round(1.5 * t * t))
        for y in range(y0, y0 + oh + 1):
            cv.put(x, y, MIN)
        cv.put(x, y0 - 1, RAW)                                      # labios hinchados
        cv.put(x, y0 + oh + 1, RAW)
        cv.put(x, y0, OUT if state == 0 else MIN)
        if state >= 1:
            if x % 2 == 1:
                cv.put(x, y0 + 1, TEE)
            if x % 3 == 0:
                cv.put(x, y0 + 2, TEES)
            if state == 2 and x % 2 == 0:
                cv.put(x, y0 + oh, TEE if x % 3 else TEES)
    if state == 2 and w >= 15:
        cv.a[cv.rect(cx - 3, cy, cx + 3, cy + 1) & (cv.a == MIN)] = TON
    cv.outline(OUT)
    if bloody:
        for x in range(2, w - 2, 2):
            cv.put(x, h - 1 if state == 0 else cy + oh // 2 + 2, BLD)
        for d in range(3):
            cv.put(cx, h + d - 1, BLD if d < 2 else BLDD)
        cv.put(cx - 2, cy - 1, PUS)
    return cv


# 5 bocas en la cabeza (coords de cabeza) y 8 en el torso (relativas al centro del torso): 13 en total
HEAD_MOUTHS = [('S', 24, 52, False), ('M', 88, 50, True), ('S', 56, 34, False), ('S', 40, 50, True), ('M', 70, 46, False)]
TORSO_MOUTHS = [('M', -18, -8, True), ('S', 8, -22, False), ('L', 4, 8, True), ('S', -26, 14, False),
                ('M', 18, 14, False), ('S', -6, -26, False), ('M', -12, 22, True), ('S', 24, -2, False)]

# Rutas de lágrima: ojo -> junto a una boca secundaria -> boca principal
TEAR_PATHS = [
    [(32, 39), (29, 44), (26, 49), (24, 53), (21, 58), (18, 62), (16, 66)],                    # izq: pasa por la boca (24,52) -> comisura
    [(78, 30), (81, 36), (85, 42), (88, 48), (88, 54), (86, 59), (84, 63), (80, 67)],          # der: entra en la boca (88,50) -> boca principal
]


def fluids_layer():
    cv = Cv(HW, HH)
    for path in TEAR_PATHS:
        for (x0, y0), (x1, y1) in zip(path, path[1:]):
            cv.line(x0, y0, x1, y1, TEAR)
            cv.line(x0 + 1, y0, x1 + 1, y1, TEAR)
        for x, y in path[::2]:
            cv.put(x, y, TEARL)
    # baba: hilos largos desde la boca principal y las comisuras
    for x, ln in ((18, 10), (30, 14), (44, 9), (58, 16), (70, 11), (82, 8)):
        for k in range(ln):
            cv.put(x, 82 + k, MUCUS if k % 3 else WET)
        cv.put(x, 82 + ln, MUCUS)
        cv.put(x, 83 + ln, WET)
    return cv


# ------------------------------------------------------------------ vista previa y comprobación
def to_rgba(cv):
    arr = np.zeros((cv.h, cv.w, 4), dtype=np.uint8)
    for i, c in enumerate(PAL):
        arr[cv.a == i] = c
    return arr


def compose(name='IDLE', arm_idx=2, eye='OPEN', mouth='CLOSED', open_mask=(1, 0, 2, 0, 1, 2, 0, 0, 1, 0, 2, 1, 0), scale=3):
    from PIL import Image
    body, info = build_body(name)
    img = Image.new('RGBA', (W + 80, H + 20), (236, 226, 200, 255))
    def paste(cv, x, y):
        im = Image.fromarray(to_rgba(cv), 'RGBA')
        if x + 30 >= 0 and y + 8 >= 0:
            img.alpha_composite(im, (x + 30, y + 8))
    sh = info['shoulder']
    paste(build_arm(arm_idx, True), sh[0] - ASH[0] - 6, sh[1] - ASH[1])
    paste(body, 0, 0)
    hx, hy = info['head']
    paste(build_head(), hx, hy)
    for (cx, cy), side, r in ((EYE_L, 'L', EYE_RL), (EYE_R, 'R', EYE_RR)):
        e = eye_patch(r, eye, side)
        paste(e, hx + cx - e.w // 2, hy + cy - e.h // 2)
    mm = main_mouth(mouth)
    paste(mm, hx + MAIN_MOUTH_POS[0], hy + MAIN_MOUTH_POS[1])
    for i, (sz, mx, my, bl) in enumerate(HEAD_MOUTHS):
        m = sec_mouth(sz, open_mask[i], bl)
        paste(m, hx + mx - m.w // 2, hy + my - m.h // 2)
    tx, ty = info['torso']
    for j, (sz, mx, my, bl) in enumerate(TORSO_MOUTHS):
        m = sec_mouth(sz, open_mask[len(HEAD_MOUTHS) + j], bl)
        paste(m, tx + mx - m.w // 2, ty + my - m.h // 2)
    paste(fluids_layer(), hx, hy)
    paste(build_arm(arm_idx, False), sh[0] - ASH[0], sh[1] - ASH[1])
    return img.resize((img.width * scale, img.height * scale), Image.NEAREST)


if __name__ == '__main__':
    from PIL import Image
    names = ['IDLE', 'WALK_1', 'CHASE_1', 'CAPTURE']
    ims = [compose(n, arm_idx=(5 if n == 'CAPTURE' else (4 if n.startswith('CHASE') else 2)),
                   mouth=('WIDE' if n.startswith('CHASE') else 'CLOSED'), scale=2) for n in names]
    sheet = Image.new('RGBA', (sum(i.width for i in ims), ims[0].height))
    x = 0
    for i in ims:
        sheet.paste(i, (x, 0)); x += i.width
    sheet.save('/home/claude/creature_preview.png')
    print('ok', sheet.size, 'colores', len(PAL))
