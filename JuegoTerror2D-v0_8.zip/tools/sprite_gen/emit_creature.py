"""Genera app/src/main/java/com/terror2d/pixel/CreatureSpriteData.kt (NO edita SpriteData.kt).

Uso:  python3 emit_creature.py   (desde tools/sprite_gen)
Misma codificación RLE que emit_kotlin.py (índice de paleta + longitud, ambos como chr(48+n)).
"""
import os
import creature as cr
from emit_kotlin import rle, argb

OUT = os.path.join(os.path.dirname(__file__), '..', '..', 'app', 'src', 'main', 'java', 'com', 'terror2d', 'pixel', 'CreatureSpriteData.kt')


def ks(cv):
    return '        "%s"' % rle(cv.a)


def ints(vals):
    return 'intArrayOf(' + ', '.join(str(int(v)) for v in vals) + ')'


def main():
    L = []
    w = L.append
    w('package com.terror2d.pixel')
    w('')
    w('/**')
    w(' * DATOS GENERADOS por tools/sprite_gen (python3 emit_creature.py). NO editar a mano: edita creature.py.')
    w(' * La criatura usa la MISMA densidad de pixel art que el protagonista (1 píxel = 0,5 px lógicos).')
    w(' */')
    w('object CreatureSpriteData {')
    w(f'    const val BODY_W = {cr.W}')
    w(f'    const val BODY_H = {cr.H}')
    w(f'    const val ARM_W = {cr.AW}')
    w(f'    const val ARM_H = {cr.AH}')
    w(f'    const val HEAD_W = {cr.HW}')
    w(f'    const val HEAD_H = {cr.HH}')
    w('    val PALETTE: IntArray = intArrayOf(' + ', '.join(argb(c) + '.toInt()' for c in cr.PAL) + ')')
    names = list(cr.POSES.keys())
    w('    val BODY_POSES: Array<String> = arrayOf(' + ', '.join('"%s"' % n for n in names) + ')')
    bodies = [cr.build_body(n) for n in names]
    w('    val BODY_DATA: Array<String> = arrayOf(')
    w(',\n'.join(ks(b) for b, _ in bodies))
    w('    )')
    w('    /** [headX, headY, torsoX, torsoY, shoulderX, shoulderY] por pose (esquina sup. izq. de la cabeza). */')
    w('    val BODY_ANCHORS: Array<IntArray> = arrayOf(' + ', '.join(ints(list(i['head']) + list(i['torso']) + list(i['shoulder'])) for _, i in bodies) + ')')
    w(f'    val ARM_ANGLES: IntArray = {ints(cr.ARM_ANGLES)}')
    w(f'    val ARM_SHOULDER: IntArray = {ints(cr.ASH)}')
    w('    val ARM_NEAR: Array<String> = arrayOf(')
    w(',\n'.join(ks(cr.build_arm(i, False)) for i in range(len(cr.ARM_ANGLES))))
    w('    )')
    w('    val ARM_FAR: Array<String> = arrayOf(')
    w(',\n'.join(ks(cr.build_arm(i, True)) for i in range(len(cr.ARM_ANGLES))))
    w('    )')
    w('    val HEAD_DATA: String =')
    w(ks(cr.build_head()))
    w(f'    val HEAD_CENTER: IntArray = {ints(cr.HC)}')
    # ojos
    w('    val EYE_STATES: Array<String> = arrayOf(' + ', '.join('"%s"' % s for s in cr.EYE_STATES) + ')')
    w(f'    val EYE_CENTERS: IntArray = {ints(list(cr.EYE_L) + list(cr.EYE_R))}   // izq x,y, der x,y')
    eyes = [(cr.eye_patch(11, s, 'L'), cr.eye_patch(10, s, 'R')) for s in cr.EYE_STATES]
    w('    val EYE_DATA_L: Array<String> = arrayOf(')
    w(',\n'.join(ks(a) for a, b in eyes))
    w('    )')
    w('    val EYE_DATA_R: Array<String> = arrayOf(')
    w(',\n'.join(ks(b) for a, b in eyes))
    w('    )')
    w('    val EYE_SIZE_L: Int = %d' % eyes[0][0].w)
    w('    val EYE_SIZE_R: Int = %d' % eyes[0][1].w)
    # boca principal
    ms = ['CLOSED', 'TENSE', 'OPEN', 'WIDE']
    w('    val MAIN_MOUTH_STATES: Array<String> = arrayOf(' + ', '.join('"%s"' % s for s in ms) + ')')
    w('    val MAIN_MOUTH_W: Int = 70')
    w('    val MAIN_MOUTH_H: Int = 26')
    w(f'    val MAIN_MOUTH_POS: IntArray = {ints([cr.MAIN_MOUTH_POS[0], cr.MAIN_MOUTH_POS[1] - 6])}')
    w('    val MAIN_MOUTH_DATA: Array<String> = arrayOf(')
    w(',\n'.join(ks(cr.main_mouth(s)) for s in ms))
    w('    )')
    # bocas secundarias: [tamaño][sangre][estado]
    w('    /** Orden: tamaño S,M,L × sangre no/sí × estado 0,1,2 (índice = tamaño*6 + sangre*3 + estado). */')
    w('    val SEC_SIZES: IntArray = ' + ints([v for s in 'SML' for v in cr.SIZES[s]]) + '   // w,h por tamaño')
    w('    val SEC_DATA: Array<String> = arrayOf(')
    rows = []
    for s in 'SML':
        for bl in (False, True):
            for st in range(3):
                rows.append(ks(cr.sec_mouth(s, st, bl)))
    w(',\n'.join(rows))
    w('    )')
    w('    /** Bocas: tamaño (0=S,1=M,2=L), x, y, sangre. Cabeza en coords de cabeza; torso relativo al centro del torso. */')
    w('    val HEAD_MOUTHS: Array<IntArray> = arrayOf(' + ', '.join(ints(['SML'.index(s), x, y, int(b)]) for s, x, y, b in cr.HEAD_MOUTHS) + ')')
    w('    val TORSO_MOUTHS: Array<IntArray> = arrayOf(' + ', '.join(ints(['SML'.index(s), x, y, int(b)]) for s, x, y, b in cr.TORSO_MOUTHS) + ')')
    # fluidos
    w('    val FLUIDS_DATA: String =')
    w(ks(cr.fluids_layer()))
    w('    /** Rutas de las lágrimas (x0,y0,x1,y1,... en coords de cabeza): el juego anima gotas sobre ellas. */')
    w('    val TEAR_PATHS: Array<IntArray> = arrayOf(' + ', '.join(ints([c for p in path for c in p]) for path in cr.TEAR_PATHS) + ')')
    w('}')
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    open(OUT, 'w', encoding='utf-8').write('\n'.join(L) + '\n')
    print('escrito', os.path.abspath(OUT), os.path.getsize(OUT), 'bytes')


if __name__ == '__main__':
    main()
